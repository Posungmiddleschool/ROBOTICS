#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 - 핀레이 언더액추에이티드 그리퍼
Jihun Robot V8.5 - Fin Ray Underactuated Gripper

Features:
  - 핀레이 언더액추에이티드 그리퍼 (2-DOF)
  - 3x TPU 핀레이 핑거 (각각 3D 프린트 원피스)
  - 텐던 케이블 라우팅 (핑거 베이스 통해)
  - MG996R 서보 #1: 열기/닫기 (3개 핑거 텐던 케이블 당김)
  - MG996R 서보 #2: 손목 회전
  - FSR-402 촉각 센서 포켓 (3개 핑거 끝)
  - 자석 퀵 체인지 마운트 (Tier 1 커넥터)
  - 계란에서 상자까지 모든 형태 적응 가능

V8.5 Changes from V6:
  - 버전 V8.5 업데이트 (치수 변경 없음)
  - 한국어 주석 보강

Author: Jihun Robot V8.5 Team
License: MIT
"""

import adsk.core
import adsk.fusion
import math
import traceback

# ============================================================================
# 상수 정의 / Constants
# ============================================================================
MM = 0.1  # cm per mm

# 핀레이 핑거 / Fin Ray Finger
FINGER_LENGTH = 80.0
FINGER_BASE_WIDTH = 25.0
FINGER_TIP_WIDTH = 12.0
FINGER_THICKNESS = 3.0
FINGER_SLOT_COUNT = 12
FINGER_SLOT_WIDTH = 1.0
FINGER_SLOT_DEPTH_RATIO = 0.6
FINGER_CURVE_ANGLE = 30.0

# 핑거 배열
FINGER_COUNT = 3
FINGER_SPREAD_ANGLE = 120.0
FINGER_BASE_RADIUS = 18.0

# 텐던 케이블
TENDON_DIAMETER = 0.8
TENDON_ROUTING_WIDTH = 2.0
TENDON_PULL_TRAVEL = 15.0

# MG996R 서보
SERVO_WIDTH = 40.5
SERVO_DEPTH = 20.0
SERVO_HEIGHT = 38.0
SERVO_HORN_RADIUS = 12.0
SERVO_MOUNT_HOLE_SPACING_X = 10.0
SERVO_MOUNT_HOLE_SPACING_Y = 48.0
SERVO_MOUNT_HOLE_DIA = 2.2

# 손목 회전
WRIST_DIAMETER = 45.0
WRIST_HEIGHT = 15.0
WRIST_BEARING_OD = 35.0
WRIST_BEARING_ID = 22.0

# FSR-402 촉각 센서
FSR_DIAMETER = 18.0
FSR_THICKNESS = 1.0

# 자석 퀵 체인지
MAGNET_DIAMETER = 10.0
MAGNET_DEPTH = 3.0
SNAP_HOOK_WIDTH = 4.0
SNAP_HOOK_HEIGHT = 3.0

# 그리퍼 베이스
BASE_DIAMETER = 55.0
BASE_HEIGHT = 10.0

# 허용 오차
CLEARANCE = 0.2


def mm(val):
    return val * 0.1

def create_comp(root, name):
    try:
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = occ.component
        comp.name = name
        return comp
    except:
        return None

def draw_circle(sketch, cx, cy, dia):
    center = adsk.core.Point3D.create(mm(cx), mm(cy), 0)
    circles = sketch.sketchCurves.sketchCircles
    return circles.addByCenterRadius(center, mm(dia / 2.0))

def draw_rect(sketch, cx, cy, w, h):
    hw = mm(w / 2.0)
    hh = mm(h / 2.0)
    lines = sketch.sketchCurves.sketchLines
    p1 = adsk.core.Point3D.create(mm(cx) - hw, mm(cy) - hh, 0)
    p2 = adsk.core.Point3D.create(mm(cx) + hw, mm(cy) - hh, 0)
    p3 = adsk.core.Point3D.create(mm(cx) + hw, mm(cy) + hh, 0)
    p4 = adsk.core.Point3D.create(mm(cx) - hw, mm(cy) + hh, 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)

def extrude(sketch, idx, depth, op='join', direction=1):
    profiles = sketch.profiles
    if profiles.count <= idx:
        return None
    profile = profiles.item(idx)
    comp = sketch.parentComponent
    extrudes = comp.features.extrudeFeatures
    ops = {
        'join': adsk.fusion.FeatureOperations.JoinFeatureOperation,
        'cut': adsk.fusion.FeatureOperations.CutFeatureOperation,
        'new_body': adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
    }
    ext_input = extrudes.createInput(profile, ops.get(op, ops['join']))
    dist = adsk.core.ValueInput.createByReal(mm(depth) * direction)
    ext_input.setDistanceExtent(False, dist)
    return extrudes.add(ext_input)


def create_fin_ray_finger(root_comp, finger_index=0):
    """TPU 핀레이 핑거 생성"""
    comp = create_comp(root_comp, f"FinRayFinger_{finger_index}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_finger = sketches.add(comp.xZConstructionPlane)
    lines = sketch_finger.sketchCurves.sketchLines
    hw_base = mm(FINGER_BASE_WIDTH / 2.0)
    hw_tip = mm(FINGER_TIP_WIDTH / 2.0)
    length = mm(FINGER_LENGTH)
    p1 = adsk.core.Point3D.create(-hw_base, 0, 0)
    p2 = adsk.core.Point3D.create(hw_base, 0, 0)
    p3 = adsk.core.Point3D.create(hw_tip, length, 0)
    p4 = adsk.core.Point3D.create(-hw_tip, length, 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)
    extrude(sketch_finger, 0, FINGER_THICKNESS, 'new_body')

    slot_depth = FINGER_BASE_WIDTH * FINGER_SLOT_DEPTH_RATIO / 2.0
    for i in range(FINGER_SLOT_COUNT):
        z_pos = 8.0 + i * (FINGER_LENGTH - 16.0) / FINGER_SLOT_COUNT
        t = z_pos / FINGER_LENGTH
        current_hw = FINGER_BASE_WIDTH / 2.0 - t * (FINGER_BASE_WIDTH - FINGER_TIP_WIDTH) / 2.0
        if i % 2 == 0:
            slot_x = -current_hw + slot_depth / 2.0
        else:
            slot_x = current_hw - slot_depth / 2.0
        sketch_slot = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_slot, slot_x, z_pos, slot_depth, FINGER_SLOT_WIDTH)
        try:
            extrude(sketch_slot, 0, FINGER_THICKNESS + 1.0, 'cut')
        except:
            pass

    # 텐던 케이블 채널
    sketch_tendon = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_tendon, 0, FINGER_LENGTH / 2.0, TENDON_ROUTING_WIDTH, FINGER_LENGTH - 15.0)
    try:
        extrude(sketch_tendon, 0, 1.5, 'cut')
    except:
        pass

    # 텐던 앵커
    sketch_anchor = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_anchor, 0, FINGER_LENGTH - 5.0, TENDON_ROUTING_WIDTH + 1.0, 3.0)
    try:
        extrude(sketch_anchor, 0, FINGER_THICKNESS + 1.0, 'cut')
    except:
        pass

    # FSR-402 촉각 센서 포켓
    sketch_fsr = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_fsr, 0, FINGER_LENGTH - FSR_DIAMETER / 2.0 - 2.0, FSR_DIAMETER)
    try:
        extrude(sketch_fsr, 0, 1.5, 'cut')
    except:
        pass

    sketch_fsr_wire = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_fsr_wire, 3.0, FINGER_LENGTH - FSR_DIAMETER, 1.5, FSR_DIAMETER + 5.0)
    try:
        extrude(sketch_fsr_wire, 0, 1.0, 'cut')
    except:
        pass

    # 핑거 끝 라운드
    sketch_tip = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_tip, 0, FINGER_LENGTH, FINGER_TIP_WIDTH / 2.0)
    try:
        extrude(sketch_tip, 0, FINGER_THICKNESS, 'join')
    except:
        pass

    # 핑거 베이스 마운팅 탭
    sketch_tab = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_tab, 0, -5.0, FINGER_BASE_WIDTH, 10.0)
    try:
        extrude(sketch_tab, 0, FINGER_THICKNESS, 'join')
    except:
        pass
    for hx in [-FINGER_BASE_WIDTH / 3.0, FINGER_BASE_WIDTH / 3.0]:
        sketch_mh = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_mh, hx, -5.0, 2.2)
        try:
            extrude(sketch_mh, 0, FINGER_THICKNESS + 2.0, 'cut')
        except:
            pass

    return comp


def create_tendon_cable_system(root_comp):
    """텐던 케이블 라우팅 시스템 (3개 핑거 통합)"""
    comp = create_comp(root_comp, "TendonCableSystem")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_guide = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_guide, 0, 0, 15.0)
    extrude(sketch_guide, 0, 5.0, 'new_body')

    for i in range(FINGER_COUNT):
        angle_rad = math.radians(i * FINGER_SPREAD_ANGLE)
        finger_x = FINGER_BASE_RADIUS * math.cos(angle_rad)
        finger_y = FINGER_BASE_RADIUS * math.sin(angle_rad)
        sketch_ch = sketches.add(comp.xZConstructionPlane)
        lines = sketch_ch.sketchCurves.sketchLines
        p1 = adsk.core.Point3D.create(0, 0, 0)
        p2 = adsk.core.Point3D.create(mm(finger_x), mm(finger_y), 0)
        dx = mm(TENDON_ROUTING_WIDTH) * math.cos(angle_rad + math.pi / 2)
        dy = mm(TENDON_ROUTING_WIDTH) * math.sin(angle_rad + math.pi / 2)
        p3 = adsk.core.Point3D.create(mm(finger_x) + dx, mm(finger_y) + dy, 0)
        p4 = adsk.core.Point3D.create(dx, dy, 0)
        lines.addByTwoPoints(p1, p2)
        lines.addByTwoPoints(p2, p3)
        lines.addByTwoPoints(p3, p4)
        lines.addByTwoPoints(p4, p1)
        try:
            extrude(sketch_ch, 0, TENDON_ROUTING_WIDTH, 'cut')
        except:
            pass

    sketch_servo_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_servo_cable, 0, -15.0, TENDON_ROUTING_WIDTH, 15.0)
    try:
        extrude(sketch_servo_cable, 0, TENDON_ROUTING_WIDTH, 'cut')
    except:
        pass

    return comp


def create_grip_servo_mount(root_comp):
    """MG996R 서보 마운트 #1: 그립 열기/닫기"""
    comp = create_comp(root_comp, "GripServo_MG996R")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_housing = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_housing, 0, 0, SERVO_WIDTH + 6.0, SERVO_DEPTH + 6.0)
    extrude(sketch_housing, 0, SERVO_HEIGHT + 4.0, 'new_body')

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, 0, 0, SERVO_WIDTH + CLEARANCE * 2, SERVO_DEPTH + CLEARANCE * 2)
    try:
        extrude(sketch_pocket, 0, SERVO_HEIGHT, 'cut')
    except:
        pass

    sketch_horn = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_horn, 0, 0, SERVO_HORN_RADIUS + 2.0)
    try:
        extrude(sketch_horn, 0, 5.0, 'cut')
    except:
        pass

    # 텐던 풀리 마운트
    sketch_pulley = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_pulley, SERVO_HORN_RADIUS, 0, 8.0)
    try:
        extrude(sketch_pulley, 0, 5.0, 'new_body')
    except:
        pass
    sketch_groove = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_groove, SERVO_HORN_RADIUS, 0, 5.0)
    try:
        extrude(sketch_groove, 0, 2.0, 'cut')
    except:
        pass

    for hx in [-SERVO_MOUNT_HOLE_SPACING_X / 2.0, SERVO_MOUNT_HOLE_SPACING_X / 2.0]:
        for hz in [-SERVO_MOUNT_HOLE_SPACING_Y / 2.0, SERVO_MOUNT_HOLE_SPACING_Y / 2.0]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hz, SERVO_MOUNT_HOLE_DIA)
            try:
                extrude(sketch_mh, 0, 5.0, 'cut')
            except:
                pass

    # 서보 케이블 라우팅
    sketch_servo_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_servo_cable, 0, -SERVO_DEPTH / 2.0 - 5.0, 4.0, 10.0)
    try:
        extrude(sketch_servo_cable, 0, 2.0, 'cut')
    except:
        pass

    # FSR 센서 케이블 라우팅
    sketch_fsr_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_fsr_cable, 8.0, 0, 2.0, SERVO_HEIGHT / 2.0)
    try:
        extrude(sketch_fsr_cable, 0, 2.0, 'cut')
    except:
        pass

    # 텐던 입출구
    sketch_entry = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_entry, 0, -SERVO_DEPTH / 2.0 - 5.0, TENDON_ROUTING_WIDTH + 2.0, 8.0)
    try:
        extrude(sketch_entry, 0, 3.0, 'cut')
    except:
        pass

    for sx in [-15.0, 15.0]:
        sketch_spring = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_spring, sx, 0, 3.0)
        try:
            extrude(sketch_spring, 0, 5.0, 'new_body')
        except:
            pass

    return comp


def create_wrist_rotation_mount(root_comp):
    """MG996R 서보 마운트 #2: 손목 회전"""
    comp = create_comp(root_comp, "WristServo_MG996R")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_housing = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_housing, 0, 0, WRIST_DIAMETER)
    extrude(sketch_housing, 0, WRIST_HEIGHT + SERVO_HEIGHT + 10.0, 'new_body')

    sketch_bearing = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_bearing, 0, 0, WRIST_BEARING_OD + CLEARANCE)
    try:
        extrude(sketch_bearing, 0, 5.0, 'cut')
    except:
        pass

    sketch_bbore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_bbore, 0, 0, WRIST_BEARING_ID)
    try:
        extrude(sketch_bbore, 0, WRIST_HEIGHT + 2.0, 'cut')
    except:
        pass

    sketch_servo = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_servo, 0, 0, SERVO_WIDTH + 4.0, SERVO_DEPTH + 4.0)
    try:
        extrude(sketch_servo, 0, SERVO_HEIGHT + 2.0, 'cut')
    except:
        pass

    sketch_shaft = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_shaft, 0, 0, 8.0)
    try:
        extrude(sketch_shaft, 0, WRIST_HEIGHT + 5.0, 'cut')
    except:
        pass

    for hx in [-SERVO_MOUNT_HOLE_SPACING_X / 2.0, SERVO_MOUNT_HOLE_SPACING_X / 2.0]:
        sketch_mh = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_mh, hx, 0, SERVO_MOUNT_HOLE_DIA)
        try:
            extrude(sketch_mh, 0, 5.0, 'cut')
        except:
            pass
    for hz in [-SERVO_MOUNT_HOLE_SPACING_Y / 2.0, SERVO_MOUNT_HOLE_SPACING_Y / 2.0]:
        sketch_mh2 = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_mh2, 0, hz, SERVO_MOUNT_HOLE_DIA)
        try:
            extrude(sketch_mh2, 0, 5.0, 'cut')
        except:
            pass

    sketch_cable_ch = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_cable_ch, SERVO_WIDTH / 2.0 + 3.0, 0, 3.0, SERVO_HEIGHT / 2.0)
    try:
        extrude(sketch_cable_ch, 0, 2.0, 'cut')
    except:
        pass

    sketch_stop = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_stop, WRIST_DIAMETER / 2.0 - 3.0, 0, 6.0, 8.0)
    try:
        extrude(sketch_stop, 0, 3.0, 'new_body')
    except:
        pass

    return comp


def create_gripper_base(root_comp):
    """그리퍼 베이스 (3개 핑거 마운팅 + 서보 장착)"""
    comp = create_comp(root_comp, "GripperBase")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_base = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_base, 0, 0, BASE_DIAMETER)
    extrude(sketch_base, 0, BASE_HEIGHT, 'new_body')

    for i in range(FINGER_COUNT):
        angle_rad = math.radians(i * FINGER_SPREAD_ANGLE)
        fx = FINGER_BASE_RADIUS * math.cos(angle_rad)
        fy = FINGER_BASE_RADIUS * math.sin(angle_rad)
        sketch_fslot = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_fslot, fx, fy, FINGER_BASE_WIDTH + 2.0, 10.0)
        try:
            extrude(sketch_fslot, 0, FINGER_THICKNESS + 1.0, 'cut')
        except:
            pass
        for hx_offset in [-FINGER_BASE_WIDTH / 3.0, FINGER_BASE_WIDTH / 3.0]:
            hfx = fx + hx_offset * math.cos(angle_rad)
            hfy = fy + hx_offset * math.sin(angle_rad)
            sketch_fmh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_fmh, hfx, hfy, 2.2)
            try:
                extrude(sketch_fmh, 0, BASE_HEIGHT + 2.0, 'cut')
            except:
                pass

    for i in range(FINGER_COUNT):
        angle_rad = math.radians(i * FINGER_SPREAD_ANGLE)
        tx = 8.0 * math.cos(angle_rad)
        ty = 8.0 * math.sin(angle_rad)
        sketch_th = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_th, tx, ty, TENDON_ROUTING_WIDTH)
        try:
            extrude(sketch_th, 0, BASE_HEIGHT + 2.0, 'cut')
        except:
            pass

    sketch_sm = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_sm, 0, 0, SERVO_WIDTH + 4.0, SERVO_DEPTH + 4.0)
    try:
        extrude(sketch_sm, 0, SERVO_HEIGHT + 2.0, 'cut')
    except:
        pass

    return comp


def create_quick_change_mount(root_comp):
    """자석 퀵 체인지 마운트 (Tier 1 커넥터)"""
    comp = create_comp(root_comp, "QuickChangeMount_T1")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_plate = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_plate, 0, 0, BASE_DIAMETER + 5.0)
    extrude(sketch_plate, 0, 6.0, 'new_body')

    sketch_mag = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_mag, 0, 0, MAGNET_DIAMETER + CLEARANCE)
    try:
        extrude(sketch_mag, 0, MAGNET_DEPTH + 1.0, 'cut')
    except:
        pass

    for i in range(4):
        angle_rad = math.radians(i * 90.0)
        hook_r = MAGNET_DIAMETER / 2.0 + SNAP_HOOK_WIDTH / 2.0 + 2.0
        hx = hook_r * math.cos(angle_rad)
        hy = hook_r * math.sin(angle_rad)
        sketch_hook = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_hook, hx, hy, SNAP_HOOK_WIDTH, SNAP_HOOK_HEIGHT)
        try:
            extrude(sketch_hook, 0, 4.0, 'new_body')
        except:
            pass

    sketch_hall = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_hall, BASE_DIAMETER / 2.0 - 8.0, 0, 4.5, 5.5)
    try:
        extrude(sketch_hall, 0, 2.5, 'cut')
    except:
        pass

    sketch_key = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_key, 0, MAGNET_DIAMETER / 2.0 + 5.0, 3.0)
    try:
        extrude(sketch_key, 0, 5.0, 'new_body')
    except:
        pass

    for i in range(4):
        angle_rad = math.radians(i * 90.0 + 45.0)
        bhx = (BASE_DIAMETER / 2.0 - 2.0) * math.cos(angle_rad)
        bhy = (BASE_DIAMETER / 2.0 - 2.0) * math.sin(angle_rad)
        sketch_bh = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_bh, bhx, bhy, 3.2)
        try:
            extrude(sketch_bh, 0, 8.0, 'cut')
        except:
            pass

    return comp


def create_fsr_mount(root_comp, finger_index=0):
    """FSR-402 촉각 센서 마운트"""
    comp = create_comp(root_comp, f"FSR402_Mount_F{finger_index}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_housing = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_housing, 0, 0, FSR_DIAMETER + 4.0)
    extrude(sketch_housing, 0, FSR_THICKNESS + 2.0, 'new_body')

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_pocket, 0, 0, FSR_DIAMETER)
    try:
        extrude(sketch_pocket, 0, FSR_THICKNESS, 'cut')
    except:
        pass

    sketch_wire = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_wire, 5.0, 0, 3.0, 1.5)
    try:
        extrude(sketch_wire, 0, 2.0, 'cut')
    except:
        pass

    sketch_cushion = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_cushion, 0, 0, FSR_DIAMETER - 2.0)
    try:
        extrude(sketch_cushion, 0, 0.5, 'new_body', -1)
    except:
        pass

    return comp


def create_gripper_assembly(root_comp):
    """완전 핀레이 그리퍼 어셈블리 생성"""
    comp = create_comp(root_comp, "GripperHand_FinRay")
    if not comp:
        return None

    for i in range(FINGER_COUNT):
        create_fin_ray_finger(comp, i)
    create_tendon_cable_system(comp)
    create_grip_servo_mount(comp)
    create_wrist_rotation_mount(comp)
    create_gripper_base(comp)
    create_quick_change_mount(comp)
    for i in range(FINGER_COUNT):
        create_fsr_mount(comp, i)

    return comp


def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct
        if not design:
            ui.messageBox('활성 디자인이 없습니다 / No active design')
            return
        root_comp = design.rootComponent

        ui.messageBox('핀레이 그리퍼 생성 중...\nCreating Fin Ray gripper...')
        create_gripper_assembly(root_comp)

        ui.messageBox(
            '지훈 로봇 V8.5 그리퍼 생성 완료!\n'
            'Jihun Robot V8.5 Gripper Complete!\n\n'
            f'핀레이 핑거: {FINGER_COUNT}x TPU ({FINGER_LENGTH}mm)\n'
            f'서보: MG996R x2 (그립 + 손목)\n'
            f'FSR-402: {FINGER_COUNT}x (핑거 끝)\n'
            '퀵 체인지: Tier 1 (자석 + 스냅)\n'
            '적응: 계란→상자 모든 형태'
        )
    except:
        if ui:
            ui.messageBox('실패:\nFailed:\n{}'.format(traceback.format_exc()))


def stop(context):
    pass
