#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 - 메인 바디 (알루미늄 스파인 섀시)
Jihun Robot V8.5 - Main Body (Aluminum Spine Chassis)

Body: 48cm x 32cm x 20cm 박스형, 평탄한 상부 카고 영역
Chassis: 1mm 알루미늄 플레이트 코어 (구조 + 방열 + EMI 차폐)
Shell: 3D 프린트 쉘 + TPU 가스켓 (IP54)

V8.5 Changes from V6:
  - Jetson Orin NX 16GB (8GB→16GB, 치수 동일, 마운팅 동일)
  - 40mm 쿨링팬 마운트 홀 추가 (각 Jetson SoC 직상부)
  - CC/CV Buck 모듈 베이 추가 (USB-C PD 20V→14.6V 충전)
  - B-G431B-ESC1 드라이버 보드 베이 (트레이에 위치)
  - MKS XDRIVE Mini CAN 드라이버 마운트 (2다리 피치 + 2예비)
  - 모터 소프트웨어 전류 제한 25A 반영 (방열 강화)
  - 버전 V8.5 업데이트

Features:
  - 듀얼 Jetson Orin NX 16GB 마운팅 (Sorbothane 진동 절연)
  - 배터리 컴파트먼트 (캠락 접근)
  - 열 굴뚝 환기 (하부 냉각 공기 유입, 상부 열 공기 배출)
  - GC9A01 원형 TFT 아이 마운트 (전면)
  - ICS-43434 MEMS 마이크 마운트 (좌/우)
  - MAX98357A + 스피커 마운트 (좌/우)
  - 케이블 라우팅 채널
  - ESP32-S3 마운트 (하부 근처)
  - 스마트 카고 플랫폼 (상부, HX711 로드셀 + TPU 매트)

Author: Jihun Robot V8.5 Team
License: MIT
"""

import adsk.core
import adsk.fusion
import math
import traceback

# ============================================================================
# 상수 정의 / Constants
# ============================================================================
# 바디 치수 / Body dimensions (mm)
BODY_WIDTH = 480.0    # X축 / X-axis (좌→우)
BODY_DEPTH = 320.0   # Y축 / Y-axis (전→후)
BODY_HEIGHT = 200.0  # Z축 / Z-axis (하→상) - 200mm for stair-climbing stability

# 알루미늄 스파인 / Aluminum spine
SPINE_THICKNESS = 1.0  # mm (1mm 알루미늄 플레이트)
SPINE_MATERIAL = "AL6061-T6"

# 쉘 / Shell
SHELL_WALL = 3.0    # mm (PLA 프린트 벽)
SHELL_TOLERANCE = 0.3  # mm

# TPU 가스켓 / TPU gasket
GASKET_WIDTH = 3.0   # mm
GASKET_HEIGHT = 2.0  # mm
GASKET_SHORE = "60A"

# IP54 환기 / IP54 vents
VENT_WIDTH = 80.0
VENT_HEIGHT = 4.0
VENT_COUNT_BOTTOM = 6
VENT_COUNT_TOP = 4

# GC9A01 디스플레이 / GC9A01 circular TFT
EYE_DISPLAY_DIAMETER = 31.0  # mm (1.09" 원형)
EYE_BEZEL_DIAMETER = 36.0    # mm
EYE_SPACING = 80.0           # mm (눈 사이 간격)
EYE_Z_OFFSET = 20.0          # mm from top

# ICS-43434 마이크 / ICS-43434 MEMS mic
MIC_WIDTH = 3.5
MIC_HEIGHT = 2.5
MIC_DEPTH = 1.0

# MAX98357A 앰프 / MAX98357A amplifier
AMP_WIDTH = 12.0
AMP_HEIGHT = 10.0
AMP_DEPTH = 2.0

# 스피커 / Speaker
SPEAKER_DIAMETER = 36.0
SPEAKER_DEPTH = 15.0

# Jetson Orin NX 16GB (V7: 16GB, 치수 동일)
JETSON_WIDTH = 100.0
JETSON_DEPTH = 80.0
JETSON_HEIGHT = 30.0
JETSON_MOUNT_HOLE_SPACING_X = 88.0
JETSON_MOUNT_HOLE_SPACING_Y = 56.0  # Verified from NVIDIA docs

# Sorbothane 패드 / Sorbothane isolation pads
SORBOTHANE_THICKNESS = 3.0
SORBOTHANE_SIZE = 20.0  # mm square

# 열 굴뚝 / Thermal chimney
CHIMNEY_INLET_HEIGHT = 20.0  # mm from bottom
CHIMNEY_OUTLET_HEIGHT = 20.0  # mm from top
CHIMNEY_WIDTH = 60.0

# V7: 40mm 쿨링팬 (각 Jetson SoC 직상부)
FAN_SIZE = 40.0             # mm (정사각)
FAN_HEIGHT = 10.0           # mm
FAN_MOUNT_HOLE_SPACING = 32.0  # mm (M2.5 PCD)
FAN_MOUNT_HOLE_DIA = 2.8    # mm (M2.5 클리어런스)

# V7: CC/CV Buck 충전 모듈 베이
BUCK_CC_WIDTH = 52.0        # mm (XL4015 보드)
BUCK_CC_DEPTH = 26.0        # mm
BUCK_CC_HEIGHT = 18.0       # mm
BUCK_CC_BAY_COUNT = 2       # 개수

# ESP32-S3
ESP32_WIDTH = 55.0   # ESP32-S3 DevKit actual width
ESP32_DEPTH = 28.0    # ESP32-S3 DevKit actual depth
ESP32_HEIGHT = 5.0

# MCP2515 CAN 모듈 / MCP2515 CAN module
MCP2515_WIDTH = 45.0    # mm actual
MCP2515_DEPTH = 30.0    # mm actual
MCP2515_HEIGHT = 15.0   # mm actual (with headers)

# 카고 플랫폼 / Cargo platform
CARGO_LOAD_CELL_SIZE = 20.0  # HX711 로드셀 / load cell
CARGO_MAT_THICKNESS = 3.0    # TPU 안틸립 매트 / anti-slip mat
CARGO_EDGE_HEIGHT = 8.0      # mm
CARGO_EDGE_THICKNESS = 3.0   # mm

# 케이블 라우팅 / Cable routing
CABLE_CHANNEL_WIDTH = 10.0
CABLE_CHANNEL_DEPTH = 5.0

# 일반 / General
CLEARANCE = 0.2  # mm
MM = 0.1  # cm/mm 변환


def mm(val):
    """mm를 cm로 변환 / Convert mm to cm"""
    return val * 0.1


def create_comp(root, name):
    """새 컴포넌트 생성 / Create new component"""
    try:
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = occ.component
        comp.name = name
        return comp
    except:
        return None


def draw_rect(sketch, cx, cy, w, h):
    """중심 기준 사각형 / Draw rectangle centered at (cx, cy)"""
    hw = mm(w / 2.0)
    hh = mm(h / 2.0)
    cx_cm = mm(cx)
    cy_cm = mm(cy)
    lines = sketch.sketchCurves.sketchLines
    p1 = adsk.core.Point3D.create(cx_cm - hw, cy_cm - hh, 0)
    p2 = adsk.core.Point3D.create(cx_cm + hw, cy_cm - hh, 0)
    p3 = adsk.core.Point3D.create(cx_cm + hw, cy_cm + hh, 0)
    p4 = adsk.core.Point3D.create(cx_cm - hw, cy_cm + hh, 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)


def draw_circle(sketch, cx, cy, dia):
    """원 그리기 / Draw circle"""
    center = adsk.core.Point3D.create(mm(cx), mm(cy), 0)
    circles = sketch.sketchCurves.sketchCircles
    return circles.addByCenterRadius(center, mm(dia / 2.0))


def extrude(sketch, idx, depth, op='join', direction=1):
    """돌출 / Extrude profile"""
    profiles = sketch.profiles
    if profiles.count <= idx:
        return None
    profile = profiles.item(idx)
    comp = sketch.parentComponent
    extrudes = comp.features.extrudeFeatures

    ops = {
        'join': adsk.fusion.FeatureOperations.JoinFeatureOperation,
        'cut': adsk.fusion.FeatureOperations.CutFeatureOperation,
        'new_body': adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
        'intersect': adsk.fusion.FeatureOperations.IntersectFeatureOperation,
    }
    ext_input = extrudes.createInput(profile, ops.get(op, ops['join']))
    dist = adsk.core.ValueInput.createByReal(mm(depth) * direction)
    ext_input.setDistanceExtent(False, dist)
    return extrudes.add(ext_input)


# ============================================================================
# 알루미늄 스파인 섀시 / Aluminum Spine Chassis
# ============================================================================

def create_aluminum_spine(root_comp):
    """
    1mm 알루미늄 스파인 플레이트 생성
    Create 1mm aluminum spine plate (structural core + heat sink + EMI shield)
    """
    comp = create_comp(root_comp, "AluminumSpine")
    if not comp:
        return None

    sketches = comp.sketches

    # 스파인 플레이트 / Spine plate
    sketch = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch, 0, 0, BODY_WIDTH, BODY_HEIGHT)
    extrude(sketch, 0, SPINE_THICKNESS, 'new_body')

    # 수평 스파인 (하부 구조 보강)
    sketch_h = sketches.add(comp.xYConstructionPlane)
    draw_rect(sketch_h, 0, 0, BODY_WIDTH, BODY_DEPTH)
    profiles = sketch_h.profiles
    if profiles.count > 0:
        extrudes = comp.features.extrudeFeatures
        dist = adsk.core.ValueInput.createByReal(-mm(SPINE_THICKNESS))
        ext_input = extrudes.createInput(profiles.item(0),
                                         adsk.fusion.FeatureOperations.JoinFeatureOperation)
        ext_input.setDistanceExtent(False, dist)
        extrudes.add(ext_input)

    # 방출 핀
    for i in range(5):
        z_pos = 40.0 + i * 40.0
        sketch_fin = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_fin, 0, z_pos, BODY_DEPTH - 20, SPINE_THICKNESS + 4.0)
        try:
            extrude(sketch_fin, 0, 30.0, 'join')
        except:
            pass

    # EMI 차폐 접지 탭
    for x_offset in [-BODY_WIDTH / 2.0 + 20.0, BODY_WIDTH / 2.0 - 20.0]:
        sketch_tab = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_tab, x_offset, 0, 15.0, 10.0)
        try:
            extrude(sketch_tab, 0, 5.0, 'join')
        except:
            pass

    # 케이블 관통 구멍
    for z_pos in [60.0, 120.0, 180.0]:
        sketch_hole = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_hole, 0, z_pos, 20.0)
        try:
            extrude(sketch_hole, 0, SPINE_THICKNESS + 2.0, 'cut')
        except:
            pass

    return comp


# ============================================================================
# 3D 프린트 쉘 / 3D Printed Shell
# ============================================================================

def create_shell(root_comp):
    """
    3D 프린트 PLA 쉘 + TPU 가스켓
    """
    comp = create_comp(root_comp, "BodyShell")
    if not comp:
        return None

    sketches = comp.sketches

    # 외부 쉘
    sketch_out = sketches.add(comp.xYConstructionPlane)
    draw_rect(sketch_out, 0, 0, BODY_WIDTH, BODY_DEPTH)
    extrude(sketch_out, 0, BODY_HEIGHT, 'new_body')

    # 내부 공동
    inner_w = BODY_WIDTH - SHELL_WALL * 2
    inner_d = BODY_DEPTH - SHELL_WALL * 2
    inner_h = BODY_HEIGHT - SHELL_WALL

    sketch_in = sketches.add(comp.xYConstructionPlane)
    draw_rect(sketch_in, 0, 0, inner_w, inner_d)
    try:
        extrude(sketch_in, 0, inner_h, 'cut')
    except:
        pass

    # TPU 가스켓 홈 (분할선)
    gasket_z = BODY_HEIGHT / 2.0
    sketch_gasket = sketches.add(comp.xZConstructionPlane)
    hw = mm(inner_w / 2.0)
    lines = sketch_gasket.sketchCurves.sketchLines
    p1 = adsk.core.Point3D.create(-hw, mm(gasket_z - GASKET_HEIGHT / 2.0), 0)
    p2 = adsk.core.Point3D.create(hw, mm(gasket_z - GASKET_HEIGHT / 2.0), 0)
    p3 = adsk.core.Point3D.create(hw, mm(gasket_z + GASKET_HEIGHT / 2.0), 0)
    p4 = adsk.core.Point3D.create(-hw, mm(gasket_z + GASKET_HEIGHT / 2.0), 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)
    try:
        extrude(sketch_gasket, 0, GASKET_WIDTH, 'cut')
    except:
        pass

    return comp


# ============================================================================
# 열 굴뚝 환기 / Thermal Chimney Vents
# ============================================================================

def create_thermal_chimney(root_comp):
    """
    열 굴뚝 환기 시스템
    """
    comp = create_comp(root_comp, "ThermalChimney")
    if not comp:
        return None

    sketches = comp.sketches

    # 하부 유입 환기 (양쪽 측면)
    for side in [-1, 1]:
        y_offset = side * (BODY_DEPTH / 2.0 - 10.0)
        for i in range(VENT_COUNT_BOTTOM):
            x_offset = -BODY_WIDTH / 2.0 + 40.0 + i * (BODY_WIDTH - 80.0) / (VENT_COUNT_BOTTOM - 1)
            sketch_vent = sketches.add(comp.xYConstructionPlane)
            draw_rect(sketch_vent, x_offset, y_offset, VENT_WIDTH / 3.0, VENT_HEIGHT)
            try:
                extrude(sketch_vent, 0, SHELL_WALL + 5.0, 'new_body')
            except:
                pass

    # 상부 배출 환기 (상판)
    for i in range(VENT_COUNT_TOP):
        x_offset = -BODY_WIDTH / 2.0 + 80.0 + i * (BODY_WIDTH - 160.0) / max(VENT_COUNT_TOP - 1, 1)
        sketch_vent_top = sketches.add(comp.xYConstructionPlane)
        draw_rect(sketch_vent_top, x_offset, 0, CHIMNEY_WIDTH / 2.0, 30.0)
        try:
            extrude(sketch_vent_top, 0, BODY_HEIGHT, 'new_body')
        except:
            pass

    # 내부 굴뚝 가이드
    for i in range(2):
        x_offset = (-1 + i * 2) * 60.0
        sketch_guide = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_guide, x_offset, 0, 3.0, BODY_HEIGHT - 40.0)
        try:
            extrude(sketch_guide, 0, 40.0, 'join')
        except:
            pass

    return comp


# ============================================================================
# V7: 40mm 쿨링팬 마운트 홀 / V7: 40mm Cooling Fan Mount Holes
# ============================================================================

def create_fan_mount_holes(root_comp):
    """
    V8.5 추가: 각 Jetson SoC 직상부에 40mm 쿨링팬 마운트 홀 추가
    V8.5 New: 40mm cooling fan mount holes directly above each Jetson SoC

    팬 위치: Jetson 보드 중앙 SoC 위, 열 패드 채널과 연결
    Fan position: above Jetson SoC center, connected to thermal pad channel
    """
    comp = create_comp(root_comp, "FanMountHoles_V7")
    if not comp:
        return None

    sketches = comp.sketches

    # 각 Jetson 위에 팬 마운트 / Fan mount above each Jetson
    for idx, x_center in enumerate([-80.0, 80.0]):
        z_center = BODY_HEIGHT / 2.0 + 10.0 + 20.0  # Jetson 상부 + 20mm

        # 팬 개구 / Fan opening
        sketch_opening = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_opening, x_center, z_center, FAN_SIZE, FAN_SIZE)
        try:
            extrude(sketch_opening, 0, SHELL_WALL + 3.0, 'cut')
        except:
            pass

        # M2.5 마운팅 홀 (4개 코너) / M2.5 mounting holes (4 corners)
        for hx in [-FAN_MOUNT_HOLE_SPACING / 2.0, FAN_MOUNT_HOLE_SPACING / 2.0]:
            for hz in [-FAN_MOUNT_HOLE_SPACING / 2.0, FAN_MOUNT_HOLE_SPACING / 2.0]:
                sketch_mh = sketches.add(comp.xZConstructionPlane)
                draw_circle(sketch_mh, x_center + hx, z_center + hz, FAN_MOUNT_HOLE_DIA)
                try:
                    extrude(sketch_mh, 0, SHELL_WALL + 5.0, 'cut')
                except:
                    pass

    return comp


# ============================================================================
# V7: CC/CV Buck 모듈 베이 / V7: CC/CV Buck Module Bay
# ============================================================================

def create_buck_cc_bay(root_comp):
    """
    V8.5 추가: CC/CV Buck 충전 모듈 베이 (USB-C PD 20V→14.6V)
    V8.5 New: CC/CV Buck charging module bay (USB-C PD 20V→14.6V)

    XL4015 보드: 52×26×18mm, 베이 내부에 2개 장착
    """
    comp = create_comp(root_comp, "BuckCC_Bay_V7")
    if not comp:
        return None

    sketches = comp.sketches

    # 배터리 컴파트먼트 근처 후면 하단 / Near battery compartment, rear bottom
    bay_x = 0.0
    bay_z = 40.0

    # --- 베이 하우징 / Bay housing ---
    sketch_housing = sketches.add(comp.xZConstructionPlane)
    bay_w = BUCK_CC_WIDTH + 20.0
    bay_h = BUCK_CC_HEIGHT + 10.0
    draw_rect(sketch_housing, bay_x, bay_z, bay_w, bay_h)
    try:
        extrude(sketch_housing, 0, BUCK_CC_DEPTH + 20.0, 'new_body')
    except:
        pass

    # --- 모듈 포켓 (2개) / Module pockets (2x) ---
    for idx in range(BUCK_CC_BAY_COUNT):
        mod_x = bay_x + (idx - 0.5) * (BUCK_CC_WIDTH + 5.0)
        sketch_pocket = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_pocket, mod_x, bay_z,
                  BUCK_CC_WIDTH + CLEARANCE * 2, BUCK_CC_HEIGHT + CLEARANCE * 2)
        try:
            extrude(sketch_pocket, 0, BUCK_CC_DEPTH + 5.0, 'cut')
        except:
            pass

        # M3 마운팅 홀 / M3 mounting holes
        for hx in [-BUCK_CC_WIDTH / 2.0 + 4.0, BUCK_CC_WIDTH / 2.0 - 4.0]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, mod_x + hx, bay_z, 3.0)
            try:
                extrude(sketch_mh, 0, 8.0, 'cut')
            except:
                pass

    # --- USB-C 입력 포트 (후면 패널) / USB-C input port (rear panel) ---
    for idx in range(BUCK_CC_BAY_COUNT):
        usbc_x = bay_x + (idx - 0.5) * (BUCK_CC_WIDTH + 5.0)
        sketch_usbc = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_usbc, usbc_x, bay_z - BUCK_CC_HEIGHT / 2.0 - 3.0, 14.0, 6.0)
        try:
            extrude(sketch_usbc, 0, SHELL_WALL + 5.0, 'cut')
        except:
            pass

    # --- 방열 슬롯 / Ventilation slots ---
    for i in range(3):
        slot_z = bay_z - BUCK_CC_HEIGHT / 2.0 + 3.0 + i * 5.0
        sketch_vent = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_vent, bay_x, slot_z, bay_w - 10.0, 2.0)
        try:
            extrude(sketch_vent, 0, BUCK_CC_DEPTH + 5.0, 'cut')
        except:
            pass

    return comp


# ============================================================================
# GC9A01 원형 TFT 아이 마운트 / GC9A01 Circular TFT Eye Mounts
# ============================================================================

def create_eye_mounts(root_comp):
    """
    GC9A01 1.09" 원형 TFT 디스플레이 아이 마운트 (전면 패널)
    """
    comp = create_comp(root_comp, "EyeMounts_GC9A01")
    if not comp:
        return None

    sketches = comp.sketches

    for side in [-1, 1]:
        x_offset = side * EYE_SPACING / 2.0
        z_offset = BODY_HEIGHT - EYE_Z_OFFSET

        # 베젤 마운트
        sketch_bezel = sketches.add(comp.yZConstructionPlane)
        center = adsk.core.Point3D.create(mm(x_offset), mm(z_offset), 0)
        circles = sketch_bezel.sketchCurves.sketchCircles
        circles.addByCenterRadius(center, mm(EYE_BEZEL_DIAMETER / 2.0))
        extrude(sketch_bezel, 0, SHELL_WALL + 5.0, 'new_body')

        # 디스플레이 포켓
        sketch_display = sketches.add(comp.yZConstructionPlane)
        center2 = adsk.core.Point3D.create(mm(x_offset), mm(z_offset), 0)
        circles2 = sketch_display.sketchCurves.sketchCircles
        circles2.addByCenterRadius(center2, mm(EYE_DISPLAY_DIAMETER / 2.0))
        try:
            extrude(sketch_display, 0, SHELL_WALL + 3.0, 'cut')
        except:
            pass

        # PCB 마운팅 포켓
        sketch_pcb = sketches.add(comp.yZConstructionPlane)
        center3 = adsk.core.Point3D.create(mm(x_offset), mm(z_offset), 0)
        circles3 = sketch_pcb.sketchCurves.sketchCircles
        circles3.addByCenterRadius(center3, mm(EYE_DISPLAY_DIAMETER / 2.0 + 3.0))
        try:
            extrude(sketch_pcb, 0, 6.0, 'new_body')
        except:
            pass

        # PCB 마운팅 홀 (M2)
        for angle_deg in [0, 90, 180, 270]:
            angle_rad = math.radians(angle_deg)
            hx = x_offset + (EYE_DISPLAY_DIAMETER / 2.0 + 1.0) * math.cos(angle_rad)
            hz = z_offset + (EYE_DISPLAY_DIAMETER / 2.0 + 1.0) * math.sin(angle_rad)
            sketch_m2 = sketches.add(comp.yZConstructionPlane)
            draw_circle(sketch_m2, hx, hz, 2.2)
            try:
                extrude(sketch_m2, 0, 8.0, 'cut')
            except:
                pass

        # 케이블 라우팅 홀
        sketch_cable = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_cable, x_offset, z_offset - EYE_DISPLAY_DIAMETER / 2.0 - 8.0, 6.0, 4.0)
        try:
            extrude(sketch_cable, 0, 10.0, 'cut')
        except:
            pass

    return comp


# ============================================================================
# ICS-43434 마이크 마운트 / ICS-43434 MEMS Mic Mounts
# ============================================================================

def create_mic_mounts(root_comp):
    """
    ICS-43434 MEMS 마이크 마운트 (좌/우, 전면 하단)
    """
    comp = create_comp(root_comp, "MicMounts_ICS43434")
    if not comp:
        return None

    sketches = comp.sketches

    for side in [-1, 1]:
        x_offset = side * (BODY_WIDTH / 2.0 - 30.0)
        z_offset = BODY_HEIGHT / 3.0

        sketch_mic = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_mic, x_offset, z_offset, MIC_WIDTH + 6.0, MIC_HEIGHT + 6.0)
        extrude(sketch_mic, 0, SHELL_WALL + MIC_DEPTH + 3.0, 'new_body')

        sketch_port = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_port, x_offset, z_offset, MIC_WIDTH, MIC_HEIGHT)
        try:
            extrude(sketch_port, 0, SHELL_WALL + 2.0, 'cut')
        except:
            pass

        sketch_chamber = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_chamber, x_offset, z_offset, MIC_WIDTH + 4.0, MIC_HEIGHT + 4.0)
        try:
            extrude(sketch_chamber, 0, MIC_DEPTH + 1.0, 'cut')
        except:
            pass

        sketch_wire = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_wire, x_offset, z_offset - MIC_HEIGHT, 2.0, 5.0)
        try:
            extrude(sketch_wire, 0, 8.0, 'cut')
        except:
            pass

    return comp


# ============================================================================
# MAX98357A + 스피커 마운트 / MAX98357A + Speaker Mounts
# ============================================================================

def create_speaker_mounts(root_comp):
    """
    MAX98357A 앰프 + 스피커 마운트 (좌/우, 측면)
    """
    comp = create_comp(root_comp, "SpeakerMounts_MAX98357A")
    if not comp:
        return None

    sketches = comp.sketches

    for side in [-1, 1]:
        x_offset = side * (BODY_WIDTH / 2.0 - 5.0)
        z_offset = BODY_HEIGHT / 2.0 + 30.0

        # 스피커 하우징
        sketch_spk = sketches.add(comp.yZConstructionPlane)
        center = adsk.core.Point3D.create(mm(x_offset), mm(z_offset), 0)
        circles = sketch_spk.sketchCurves.sketchCircles
        circles.addByCenterRadius(center, mm(SPEAKER_DIAMETER / 2.0 + 2.0))
        extrude(sketch_spk, 0, SPEAKER_DEPTH + 5.0, 'new_body')

        sketch_opening = sketches.add(comp.yZConstructionPlane)
        center2 = adsk.core.Point3D.create(mm(x_offset), mm(z_offset), 0)
        circles2 = sketch_opening.sketchCurves.sketchCircles
        circles2.addByCenterRadius(center2, mm(SPEAKER_DIAMETER / 2.0))
        try:
            extrude(sketch_opening, 0, SHELL_WALL + 2.0, 'cut')
        except:
            pass

        # 스피커 그릴
        for row in range(3):
            for col in range(3):
                gx = x_offset + (col - 1) * 8.0
                gz = z_offset + (row - 1) * 8.0
                dist_from_center = math.sqrt((gx - x_offset) ** 2 + (gz - z_offset) ** 2)
                if dist_from_center < SPEAKER_DIAMETER / 2.0 - 5.0:
                    sketch_grill = sketches.add(comp.yZConstructionPlane)
                    draw_circle(sketch_grill, gx, gz, 3.0)
                    try:
                        extrude(sketch_grill, 0, SHELL_WALL + 1.0, 'cut')
                    except:
                        pass

        # MAX98357A 앰프 마운트
        amp_z = z_offset - SPEAKER_DIAMETER / 2.0 - 15.0
        sketch_amp = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_amp, x_offset, amp_z, AMP_WIDTH + 4.0, AMP_HEIGHT + 4.0)
        try:
            extrude(sketch_amp, 0, AMP_DEPTH + 5.0, 'new_body')
        except:
            pass

        sketch_amp_pocket = sketches.add(comp.yZConstructionPlane)
        draw_rect(sketch_amp_pocket, x_offset, amp_z, AMP_WIDTH, AMP_HEIGHT)
        try:
            extrude(sketch_amp_pocket, 0, AMP_DEPTH + 2.0, 'cut')
        except:
            pass

        for corner_x in [-1, 1]:
            for corner_y in [-1, 1]:
                hx = x_offset + corner_x * (AMP_WIDTH / 2.0 - 3.0)
                hz = amp_z + corner_y * (AMP_HEIGHT / 2.0 - 3.0)
                sketch_ah = sketches.add(comp.yZConstructionPlane)
                draw_circle(sketch_ah, hx, hz, 2.2)
                try:
                    extrude(sketch_ah, 0, 5.0, 'cut')
                except:
                    pass

    return comp


# ============================================================================
# Jetson Orin NX 16GB 마운팅 / Jetson Orin NX 16GB Mounting
# ============================================================================

def create_jetson_mounts(root_comp):
    """
    듀얼 Jetson Orin NX 16GB 마운팅 (Sorbothane 진동 절연)
    V7: 8GB→16GB 업그레이드, 치수 동일, 마운팅 동일
    """
    comp = create_comp(root_comp, "JetsonMounts_OrinNX")
    if not comp:
        return None

    sketches = comp.sketches

    for idx, x_center in enumerate([-80.0, 80.0]):
        jetson_name = f"Jetson_{idx + 1}"
        z_center = BODY_HEIGHT / 2.0 + 10.0

        # 마운팅 브래킷
        sketch_bracket = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_bracket, x_center, z_center,
                  JETSON_WIDTH + 20.0, JETSON_HEIGHT + 10.0)
        try:
            extrude(sketch_bracket, 0, JETSON_DEPTH + 10.0, 'new_body')
        except:
            pass

        # Jetson 포켓
        sketch_pocket = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_pocket, x_center, z_center, JETSON_WIDTH, JETSON_HEIGHT)
        try:
            extrude(sketch_pocket, 0, JETSON_DEPTH + 5.0, 'cut')
        except:
            pass

        # Sorbothane 패드 포켓 (4개 코너)
        for corner_x in [-1, 1]:
            for corner_y in [-1, 1]:
                pad_x = x_center + corner_x * (JETSON_WIDTH / 2.0 - SORBOTHANE_SIZE / 2.0 - 2.0)
                pad_z = z_center + corner_y * (JETSON_HEIGHT / 2.0 - SORBOTHANE_SIZE / 2.0 - 2.0)
                sketch_pad = sketches.add(comp.xZConstructionPlane)
                draw_rect(sketch_pad, pad_x, pad_z, SORBOTHANE_SIZE, SORBOTHANE_SIZE)
                try:
                    extrude(sketch_pad, 0, SORBOTHANE_THICKNESS + 1.0, 'cut')
                except:
                    pass

        # 마운팅 홀
        for corner_x in [-1, 1]:
            for corner_y in [-1, 1]:
                hx = x_center + corner_x * (JETSON_MOUNT_HOLE_SPACING_X / 2.0)
                hz = z_center + corner_y * (JETSON_MOUNT_HOLE_SPACING_Y / 2.0)
                sketch_mh = sketches.add(comp.xZConstructionPlane)
                draw_circle(sketch_mh, hx, hz, 3.0)
                try:
                    extrude(sketch_mh, 0, JETSON_DEPTH + 12.0, 'cut')
                except:
                    pass

        # 열 결합 패드 (SoC → 알루미늄 스파인)
        sketch_thermal = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_thermal, x_center, z_center + 5.0, 40.0, 40.0)
        try:
            extrude(sketch_thermal, 0, 5.0, 'cut')
        except:
            pass

    return comp


# ============================================================================
# 배터리 컴파트먼트 / Battery Compartment
# ============================================================================

def create_battery_compartment(root_comp):
    """
    배터리 컴파트먼트 (캠락 접근, 후면)
    """
    comp = create_comp(root_comp, "BatteryCompartment")
    if not comp:
        return None

    sketches = comp.sketches

    batt_w = 150.0
    batt_d = 70.0
    batt_h = 55.0

    sketch_tray = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_tray, 0, 40.0, batt_w + 10.0, batt_h + 10.0)
    try:
        extrude(sketch_tray, 0, batt_d + 10.0, 'new_body')
    except:
        pass

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, 0, 40.0, batt_w, batt_h)
    try:
        extrude(sketch_pocket, 0, batt_d + 5.0, 'cut')
    except:
        pass

    # 캠락 마운트 (2개, 상단)
    for cam_x in [-batt_w / 2.0 + 15.0, batt_w / 2.0 - 15.0]:
        cam_z = 40.0 + batt_h / 2.0 + 5.0
        sketch_cam = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_cam, cam_x, cam_z, 16.0)
        try:
            extrude(sketch_cam, 0, 10.0, 'new_body')
        except:
            pass
        sketch_cam_slot = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_cam_slot, cam_x, cam_z, 8.0)
        try:
            extrude(sketch_cam_slot, 0, 12.0, 'cut')
        except:
            pass

    # 가이드 레일
    for rail_x in [-batt_w / 2.0 + 5.0, batt_w / 2.0 - 5.0]:
        sketch_rail = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_rail, rail_x, 40.0, 3.0, batt_h)
        try:
            extrude(sketch_rail, 0, 5.0, 'join')
        except:
            pass

    # 충전 포트 컷아웃
    sketch_charge = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_charge, 0, 10.0, 16.0, 8.0)
    try:
        extrude(sketch_charge, 0, SHELL_WALL + 5.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# MCP2515 CAN 모듈 마운트 / MCP2515 CAN Module Mount
# ============================================================================

def create_mcp2515_mount(root_comp):
    """
    MCP2515 CAN 모듈 마운트 (Jetson #2 근처)
    """
    comp = create_comp(root_comp, "MCP2515_CAN_Mount")
    if not comp:
        return None

    sketches = comp.sketches

    x_center = 80.0 + JETSON_WIDTH / 2.0 + 15.0
    z_center = BODY_HEIGHT / 2.0 + 10.0

    sketch_bracket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_bracket, x_center, z_center,
              MCP2515_WIDTH + 8.0, MCP2515_HEIGHT + 8.0)
    try:
        extrude(sketch_bracket, 0, MCP2515_DEPTH + 6.0, 'new_body')
    except:
        pass

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, x_center, z_center, MCP2515_WIDTH, MCP2515_HEIGHT)
    try:
        extrude(sketch_pocket, 0, MCP2515_DEPTH + 2.0, 'cut')
    except:
        pass

    for corner_x in [-1, 1]:
        for corner_y in [-1, 1]:
            hx = x_center + corner_x * (MCP2515_WIDTH / 2.0 - 3.0)
            hz = z_center + corner_y * (MCP2515_HEIGHT / 2.0 - 3.0)
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hz, 2.2)
            try:
                extrude(sketch_mh, 0, 8.0, 'cut')
            except:
                pass

    sketch_can = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_can, x_center, z_center - MCP2515_HEIGHT / 2.0 - 3.0, 8.0, 5.0)
    try:
        extrude(sketch_can, 0, MCP2515_DEPTH + 4.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# 케이블 라우팅 채널 / Cable Routing Channels
# ============================================================================

def create_cable_channels(root_comp):
    """
    케이블 라우팅 채널 (내부)
    """
    comp = create_comp(root_comp, "CableChannels")
    if not comp:
        return None

    sketches = comp.sketches

    for z_pos in [30.0, 70.0]:
        sketch_ch = sketches.add(comp.xYConstructionPlane)
        draw_rect(sketch_ch, 0, 0, BODY_WIDTH - 40.0, CABLE_CHANNEL_WIDTH)
        try:
            extrude(sketch_ch, 0, CABLE_CHANNEL_DEPTH, 'new_body')
        except:
            pass
        sketch_ch_in = sketches.add(comp.xYConstructionPlane)
        draw_rect(sketch_ch_in, 0, 0, BODY_WIDTH - 44.0, CABLE_CHANNEL_WIDTH - 4.0)
        try:
            extrude(sketch_ch_in, 0, CABLE_CHANNEL_DEPTH - 2.0, 'cut')
        except:
            pass

    for x_offset in [-BODY_WIDTH / 2.0 + 15.0, BODY_WIDTH / 2.0 - 15.0]:
        sketch_vch = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_vch, x_offset, BODY_HEIGHT / 2.0, 10.0, BODY_HEIGHT - 60.0)
        try:
            extrude(sketch_vch, 0, CABLE_CHANNEL_DEPTH, 'new_body')
        except:
            pass

    for x_pos in range(-5, 6, 2):
        x_mm = x_pos * 40.0
        sketch_tie = sketches.add(comp.xYConstructionPlane)
        draw_rect(sketch_tie, x_mm, -BODY_DEPTH / 2.0 + 20.0, 5.0, 2.0)
        try:
            extrude(sketch_tie, 0, 3.0, 'new_body')
        except:
            pass

    return comp


# ============================================================================
# ESP32-S3 마운트 / ESP32-S3 Mount
# ============================================================================

def create_esp32_mount(root_comp):
    """
    ESP32-S3 마운트 (하부 근처, 안테나 클리어런스)
    """
    comp = create_comp(root_comp, "ESP32S3_Mount")
    if not comp:
        return None

    sketches = comp.sketches

    x_center = BODY_WIDTH / 2.0 - 40.0
    z_center = 35.0

    sketch_bracket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_bracket, x_center, z_center, ESP32_WIDTH + 10.0, ESP32_HEIGHT + 10.0)
    try:
        extrude(sketch_bracket, 0, ESP32_DEPTH + 8.0, 'new_body')
    except:
        pass

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, x_center, z_center, ESP32_WIDTH, ESP32_HEIGHT)
    try:
        extrude(sketch_pocket, 0, ESP32_DEPTH + 4.0, 'cut')
    except:
        pass

    for corner_x in [-1, 1]:
        for corner_y in [-1, 1]:
            hx = x_center + corner_x * (ESP32_WIDTH / 2.0 - 3.0)
            hz = z_center + corner_y * (ESP32_HEIGHT / 2.0 - 2.0)
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hz, 2.2)
            try:
                extrude(sketch_mh, 0, 6.0, 'cut')
            except:
                pass

    # 안테나 클리어런스
    sketch_ant = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_ant, x_center + 20.0, z_center, 30.0, 20.0)
    try:
        extrude(sketch_ant, 0, 3.0, 'new_body')
    except:
        pass
    sketch_ant_clear = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_ant_clear, x_center + 20.0, z_center, 28.0, 18.0)
    try:
        extrude(sketch_ant_clear, 0, 5.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# 스마트 카고 플랫폼 / Smart Cargo Platform
# ============================================================================

def create_cargo_platform(root_comp):
    """
    스마트 카고 플랫폼 (상부, HX711 로드셀 + TPU 매트 + 모서리)
    """
    comp = create_comp(root_comp, "SmartCargoPlatform")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_base = sketches.add(comp.xYConstructionPlane)
    draw_rect(sketch_base, 0, 0, BODY_WIDTH - 10.0, BODY_DEPTH - 10.0)
    extrude(sketch_base, 0, 8.0, 'new_body')

    sketch_mat = sketches.add(comp.xYConstructionPlane)
    draw_rect(sketch_mat, 0, 0, BODY_WIDTH - 20.0, BODY_DEPTH - 20.0)
    try:
        extrude(sketch_mat, 0, CARGO_MAT_THICKNESS, 'new_body')
    except:
        pass

    edge_w = BODY_WIDTH - 10.0
    edge_d = BODY_DEPTH - 10.0

    # 전면/후면/좌/우 엣지
    for (ex, ey, ew, eh) in [
        (0, -edge_d / 2.0 + CARGO_EDGE_THICKNESS / 2.0, edge_w, CARGO_EDGE_THICKNESS),
        (0, edge_d / 2.0 - CARGO_EDGE_THICKNESS / 2.0, edge_w, CARGO_EDGE_THICKNESS),
        (-edge_w / 2.0 + CARGO_EDGE_THICKNESS / 2.0, 0, CARGO_EDGE_THICKNESS, edge_d - CARGO_EDGE_THICKNESS * 2),
        (edge_w / 2.0 - CARGO_EDGE_THICKNESS / 2.0, 0, CARGO_EDGE_THICKNESS, edge_d - CARGO_EDGE_THICKNESS * 2),
    ]:
        sketch_edge = sketches.add(comp.xYConstructionPlane)
        draw_rect(sketch_edge, ex, ey, ew, eh)
        try:
            extrude(sketch_edge, 0, CARGO_EDGE_HEIGHT, 'new_body')
        except:
            pass

    # HX711 로드셀 포켓 (4개 코너)
    for corner_x in [-1, 1]:
        for corner_y in [-1, 1]:
            lc_x = corner_x * (edge_w / 2.0 - CARGO_LOAD_CELL_SIZE / 2.0 - 8.0)
            lc_y = corner_y * (edge_d / 2.0 - CARGO_LOAD_CELL_SIZE / 2.0 - 8.0)
            sketch_lc = sketches.add(comp.xYConstructionPlane)
            draw_rect(sketch_lc, lc_x, lc_y, CARGO_LOAD_CELL_SIZE + 4.0, CARGO_LOAD_CELL_SIZE + 4.0)
            try:
                extrude(sketch_lc, 0, 5.0, 'cut')
            except:
                pass
            for chx in [-1, 1]:
                for chy in [-1, 1]:
                    hx = lc_x + chx * (CARGO_LOAD_CELL_SIZE / 2.0 - 2.0)
                    hy = lc_y + chy * (CARGO_LOAD_CELL_SIZE / 2.0 - 2.0)
                    sketch_lch = sketches.add(comp.xYConstructionPlane)
                    draw_circle(sketch_lch, hx, hy, 2.2)
                    try:
                        extrude(sketch_lch, 0, 4.0, 'cut')
                    except:
                        pass

    return comp


# ============================================================================
# Tier 커넥터 인터페이스 / Tier Connector Interfaces
# ============================================================================

def create_connector_interfaces(root_comp):
    """
    바디에 3-티어 커넥터 인터페이스 생성
    """
    comp = create_comp(root_comp, "BodyConnectors")
    if not comp:
        return None

    # Tier 1 인터페이스 (모듈: 그리퍼, 카메라)
    t1_positions = [
        (0.0, -BODY_DEPTH / 2.0, 60.0),
        (0.0, -BODY_DEPTH / 2.0, 140.0),
    ]

    for i, (x, y, z) in enumerate(t1_positions):
        sketch = comp.sketches.add(comp.yZConstructionPlane)
        draw_circle(sketch, x, z, 12.0)
        try:
            extrude(sketch, 0, 5.0, 'new_body')
        except:
            pass

    # Tier 2 인터페이스 (구조: 다리, 바퀴)
    t2_positions = [
        (-BODY_WIDTH / 2.0, 0.0, 0.0),
        (BODY_WIDTH / 2.0, 0.0, 0.0),
        (-BODY_WIDTH / 2.0 + 30.0, -BODY_DEPTH / 2.0 + 20.0, 0.0),
        (BODY_WIDTH / 2.0 - 30.0, -BODY_DEPTH / 2.0 + 20.0, 0.0),
        (-BODY_WIDTH / 2.0 + 30.0, BODY_DEPTH / 2.0 - 20.0, 0.0),
        (BODY_WIDTH / 2.0 - 30.0, BODY_DEPTH / 2.0 - 20.0, 0.0),
    ]

    for i, (x, y, z) in enumerate(t2_positions):
        sketch = comp.sketches.add(comp.xYConstructionPlane)
        draw_circle(sketch, x, y, 8.0)
        try:
            extrude(sketch, 0, 10.0, 'new_body')
        except:
            pass

    # Tier 3 인터페이스 (배터리, 패널)
    for cam_x in [-40.0, 40.0]:
        sketch = comp.sketches.add(comp.yZConstructionPlane)
        draw_circle(sketch, cam_x, 70.0, 16.0)
        try:
            extrude(sketch, 0, 5.0, 'new_body')
        except:
            pass

    return comp


# ============================================================================
# 메인 실행 / Main Execution
# ============================================================================

def run(context):
    """메인 실행 함수 / Main execution function"""
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct

        if not design:
            ui.messageBox('활성 디자인이 없습니다 / No active design')
            return

        root_comp = design.rootComponent

        # 각 서브시스템 생성 / Create each subsystem
        ui.messageBox('알루미늄 스파인 생성 중...\nCreating aluminum spine...')
        create_aluminum_spine(root_comp)

        ui.messageBox('바디 쉘 생성 중...\nCreating body shell...')
        create_shell(root_comp)

        ui.messageBox('열 굴뚝 생성 중...\nCreating thermal chimney...')
        create_thermal_chimney(root_comp)

        ui.messageBox('V7: 쿨링팬 마운트 홀 생성 중...\nCreating V7: fan mount holes...')
        create_fan_mount_holes(root_comp)

        ui.messageBox('V7: CC/CV Buck 베이 생성 중...\nCreating V7: CC/CV Buck bay...')
        create_buck_cc_bay(root_comp)

        ui.messageBox('GC9A01 아이 마운트 생성 중...\nCreating GC9A01 eye mounts...')
        create_eye_mounts(root_comp)

        ui.messageBox('마이크 마운트 생성 중...\nCreating mic mounts...')
        create_mic_mounts(root_comp)

        ui.messageBox('스피커 마운트 생성 중...\nCreating speaker mounts...')
        create_speaker_mounts(root_comp)

        ui.messageBox('Jetson Orin NX 16GB 마운트 생성 중...\nCreating Jetson Orin NX 16GB mounts...')
        create_jetson_mounts(root_comp)

        ui.messageBox('배터리 컴파트먼트 생성 중...\nCreating battery compartment...')
        create_battery_compartment(root_comp)

        ui.messageBox('케이블 채널 생성 중...\nCreating cable channels...')
        create_cable_channels(root_comp)

        ui.messageBox('ESP32-S3 마운트 생성 중...\nCreating ESP32-S3 mount...')
        create_esp32_mount(root_comp)

        ui.messageBox('MCP2515 CAN 모듈 마운트 생성 중...\nCreating MCP2515 CAN module mount...')
        create_mcp2515_mount(root_comp)

        ui.messageBox('카고 플랫폼 생성 중...\nCreating cargo platform...')
        create_cargo_platform(root_comp)

        ui.messageBox('커넥터 인터페이스 생성 중...\nCreating connector interfaces...')
        create_connector_interfaces(root_comp)

        ui.messageBox(
            '지훈 로봇 V8.5 메인 바디 생성 완료!\n'
            'Jihun Robot V8.5 Main Body Complete!\n\n'
            f'바디: {BODY_WIDTH}×{BODY_DEPTH}×{BODY_HEIGHT}mm\n'
            f'Jetson Orin NX 16GB: x2 (Sorbothane 진동 절연)\n'
            f'V7: 40mm 쿨링팬 마운트 (각 SoC 직상부)\n'
            f'V7: CC/CV Buck 베이 (USB-C PD→14.6V)\n'
            f'열 굴뚝 환기 (IP54)\n'
            f'GC9A01 아이 디스플레이: x2\n'
            f'스피커 + 앰프: 좌/우\n'
            f'배터리: LiFePO4 4S 3000mAh (캠락)\n'
            f'카고 플랫폼: HX711 로드셀 x4\n'
            f'MCP2515 CAN 모듈: x1'
        )

    except:
        if ui:
            ui.messageBox('실패:\nFailed:\n{}'.format(traceback.format_exc()))


def stop(context):
    """정리 함수 / Cleanup function"""
    pass
