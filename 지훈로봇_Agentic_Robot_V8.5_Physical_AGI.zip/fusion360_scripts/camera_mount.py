#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 - 카메라 마운트 + 센서 어셈블리
Jihun Robot V8.5 - Camera Mount + Sensor Assembly

Features:
  - OAK-D Pro 마운트 (팬/틸트 기능)
  - 컴플라이언트 메커니즘 팬/틸트 (3D 프린트 플렉스처)
  - IR 프로젝터 윈도우
  - 케이블 라우팅 (Jetson #1 → USB 3.0)
  - VL53L5CX ToF 센서 마운트 (전면 + 후면)
  - LD19 LiDAR 마운트 (바디 상부, 360° 회전)

V8.5 Changes from V6:
  - 버전 V8.5 업데이트 (치수 변경 없음)
  - 한국어 주석 보강

Author: Jihun Robot V8.5 Team
License: MIT
"""

import adsk.core
import adsk.fusion
import math
import traceback

# ============================================================================
# 상수 정의 / Constants
# ============================================================================
MM = 0.1  # cm per mm

# OAK-D Pro 카메라
OAKD_WIDTH = 90.0
OAKD_DEPTH = 25.0
OAKD_HEIGHT = 23.0
OAKD_LENS_SPACING = 75.0
OAKD_LENS_DIAMETER = 8.0
OAKD_USB_PORT_WIDTH = 12.0
OAKD_MOUNT_HOLE_SPACING_X = 80.0
OAKD_MOUNT_HOLE_SPACING_Y = 18.0
OAKD_MOUNT_HOLE_DIA = 3.0

# 컴플라이언트 팬/틸트
PAN_RANGE = 60.0
TILT_RANGE = 40.0
FLEXURE_THICKNESS = 1.5
FLEXURE_LENGTH = 15.0
FLEXURE_WIDTH = 8.0
PAN_ARM_LENGTH = 35.0
TILT_ARM_LENGTH = 25.0

# IR 프로젝터 윈도우
IR_WINDOW_WIDTH = 10.0
IR_WINDOW_HEIGHT = 6.0
IR_WINDOW_THICKNESS = 1.5

# VL53L5CX ToF 센서
TOF_WIDTH = 6.0
TOF_DEPTH = 3.5
TOF_HEIGHT = 2.0
TOF_LENS_DIAMETER = 4.5

# LD19 LiDAR
LIDAR_DIAMETER = 68.0
LIDAR_HEIGHT = 42.0
LIDAR_CABLE_DIAMETER = 4.0

# 마운팅 브래킷
BRACKET_WALL = 3.0
MOUNT_HOLE_DIA = 4.0

# 케이블 라우팅
USB_CABLE_DIAMETER = 4.5
CABLE_CHANNEL_WIDTH = 8.0
CABLE_CHANNEL_DEPTH = 4.0

# 허용 오차
CLEARANCE = 0.2


def mm(val):
    return val * 0.1

def create_comp(root, name):
    try:
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = occ.component
        comp.name = name
        return comp
    except:
        return None

def draw_circle(sketch, cx, cy, dia):
    center = adsk.core.Point3D.create(mm(cx), mm(cy), 0)
    circles = sketch.sketchCurves.sketchCircles
    return circles.addByCenterRadius(center, mm(dia / 2.0))

def draw_rect(sketch, cx, cy, w, h):
    hw = mm(w / 2.0)
    hh = mm(h / 2.0)
    lines = sketch.sketchCurves.sketchLines
    p1 = adsk.core.Point3D.create(mm(cx) - hw, mm(cy) - hh, 0)
    p2 = adsk.core.Point3D.create(mm(cx) + hw, mm(cy) - hh, 0)
    p3 = adsk.core.Point3D.create(mm(cx) + hw, mm(cy) + hh, 0)
    p4 = adsk.core.Point3D.create(mm(cx) - hw, mm(cy) + hh, 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)

def extrude(sketch, idx, depth, op='join', direction=1):
    profiles = sketch.profiles
    if profiles.count <= idx:
        return None
    profile = profiles.item(idx)
    comp = sketch.parentComponent
    extrudes = comp.features.extrudeFeatures
    ops = {
        'join': adsk.fusion.FeatureOperations.JoinFeatureOperation,
        'cut': adsk.fusion.FeatureOperations.CutFeatureOperation,
        'new_body': adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
    }
    ext_input = extrudes.createInput(profile, ops.get(op, ops['join']))
    dist = adsk.core.ValueInput.createByReal(mm(depth) * direction)
    ext_input.setDistanceExtent(False, dist)
    return extrudes.add(ext_input)


# ============================================================================
# OAK-D Pro 카메라 마운트
# ============================================================================

def create_oakd_mount(root_comp):
    """OAK-D Pro 카메라 마운트 (컴플라이언트 팬/틸트)"""
    comp = create_comp(root_comp, "OAKD_Pro_Mount")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_housing = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_housing, 0, 0, OAKD_WIDTH + 6.0, OAKD_DEPTH + 6.0)
    extrude(sketch_housing, 0, OAKD_HEIGHT + 4.0, 'new_body')

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, 0, 0, OAKD_WIDTH + CLEARANCE * 2, OAKD_DEPTH + CLEARANCE * 2)
    try:
        extrude(sketch_pocket, 0, OAKD_HEIGHT, 'cut')
    except:
        pass

    # 렌즈 포트 (3개)
    lens_positions = [-OAKD_LENS_SPACING / 2.0, 0.0, OAKD_LENS_SPACING / 2.0]
    for lx in lens_positions:
        sketch_lens = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_lens, lx, OAKD_DEPTH / 2.0 + 1.0, OAKD_LENS_DIAMETER)
        try:
            extrude(sketch_lens, 0, BRACKET_WALL + 2.0, 'cut')
        except:
            pass

    # IR 프로젝터 윈도우
    sketch_ir = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_ir, -OAKD_LENS_SPACING / 4.0, OAKD_DEPTH / 2.0 + 1.0,
              IR_WINDOW_WIDTH, IR_WINDOW_HEIGHT)
    try:
        extrude(sketch_ir, 0, BRACKET_WALL + 2.0, 'cut')
    except:
        pass

    sketch_bezel = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_bezel, -OAKD_LENS_SPACING / 4.0, OAKD_DEPTH / 2.0 + 1.0,
              IR_WINDOW_WIDTH + 2.0, IR_WINDOW_HEIGHT + 2.0)
    try:
        extrude(sketch_bezel, 0, 1.0, 'new_body')
    except:
        pass

    # 마운팅 홀
    for hx in [-OAKD_MOUNT_HOLE_SPACING_X / 2.0, OAKD_MOUNT_HOLE_SPACING_X / 2.0]:
        for hz in [-OAKD_MOUNT_HOLE_SPACING_Y / 2.0, OAKD_MOUNT_HOLE_SPACING_Y / 2.0]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hz, OAKD_MOUNT_HOLE_DIA)
            try:
                extrude(sketch_mh, 0, 8.0, 'cut')
            except:
                pass

    # USB-C 케이블 출구 슬롯 (6mm × 3mm)
    sketch_usbc_exit = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_usbc_exit, 0, -OAKD_DEPTH / 2.0 - 2.0, 6.0, 3.0)
    try:
        extrude(sketch_usbc_exit, 0, OAKD_HEIGHT + 5.0, 'cut')
    except:
        pass

    sketch_usb = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_usb, 0, -OAKD_DEPTH / 2.0 - 2.0, OAKD_USB_PORT_WIDTH + 2.0, 6.0)
    try:
        extrude(sketch_usb, 0, 8.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# 컴플라이언트 팬/틸트 메커니즘
# ============================================================================

def create_compliant_pan_tilt(root_comp):
    """컴플라이언트 메커니즘 팬/틸트 (3D 프린트 플렉스처)"""
    comp = create_comp(root_comp, "CompliantPanTilt")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_base = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_base, 0, 0, 60.0, 40.0)
    extrude(sketch_base, 0, BRACKET_WALL, 'new_body')

    for side in [-1, 1]:
        arm_x = side * (30.0 - FLEXURE_WIDTH / 2.0)
        sketch_arm = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_arm, arm_x, -PAN_ARM_LENGTH / 2.0,
                  FLEXURE_WIDTH, PAN_ARM_LENGTH)
        try:
            extrude(sketch_arm, 0, BRACKET_WALL, 'join')
        except:
            pass

        sketch_hinge = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_hinge, arm_x, -5.0,
                  FLEXURE_WIDTH, FLEXURE_LENGTH)
        try:
            extrude(sketch_hinge, 0, FLEXURE_THICKNESS, 'cut')
        except:
            pass

    # 틸트 플랫폼
    sketch_tilt = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_tilt, 0, -PAN_ARM_LENGTH - 10.0, OAKD_WIDTH + 10.0, 10.0)
    try:
        extrude(sketch_tilt, 0, BRACKET_WALL, 'new_body')
    except:
        pass

    for side in [-1, 1]:
        tilt_y = -PAN_ARM_LENGTH - 10.0 + side * 5.0
        sketch_tf = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_tf, 0, tilt_y,
                  OAKD_WIDTH - 10.0, FLEXURE_LENGTH)
        try:
            extrude(sketch_tf, 0, FLEXURE_THICKNESS, 'cut')
        except:
            pass

    # 카메라 마운팅 플랫폼
    sketch_platform = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_platform, 0, -PAN_ARM_LENGTH - 25.0,
              OAKD_WIDTH + 4.0, OAKD_DEPTH + 4.0)
    try:
        extrude(sketch_platform, 0, 5.0, 'new_body')
    except:
        pass

    # 서보 마운트 (옵션)
    for side in [-1, 1]:
        servo_x = side * 25.0
        sketch_servo = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_servo, servo_x, 15.0, 20.0, 10.0)
        try:
            extrude(sketch_servo, 0, 25.0, 'new_body')
        except:
            pass
        sketch_smh = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_smh, servo_x, 15.0, 3.0)
        try:
            extrude(sketch_smh, 0, 30.0, 'cut')
        except:
            pass

    # 틸트 엄지나사 조절
    thumbscrew_x = OAKD_WIDTH / 2.0 + 5.0
    sketch_thumbscrew = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_thumbscrew, thumbscrew_x, -PAN_ARM_LENGTH - 20.0, 6.0)
    try:
        extrude(sketch_thumbscrew, 0, 10.0, 'cut')
    except:
        pass
    sketch_thread = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_thread, thumbscrew_x, -PAN_ARM_LENGTH - 20.0, 5.0)
    try:
        extrude(sketch_thread, 0, 15.0, 'new_body')
    except:
        pass

    # 바디 체결 홀
    for hx in [-22.0, 22.0]:
        for hz in [-15.0, 15.0]:
            sketch_bh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_bh, hx, hz, MOUNT_HOLE_DIA)
            try:
                extrude(sketch_bh, 0, 8.0, 'cut')
            except:
                pass

    return comp


# ============================================================================
# VL53L5CX ToF 센서 마운트
# ============================================================================

def create_tof_sensor_mount(root_comp, position="Front"):
    """VL53L5CX ToF 센서 마운트"""
    comp = create_comp(root_comp, f"ToF_VL53L5CX_{position}")
    if not comp:
        return None

    sketches = comp.sketches

    housing_w = TOF_WIDTH + 8.0
    housing_h = TOF_HEIGHT + 8.0
    sketch_housing = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_housing, 0, 0, housing_w, housing_h)
    extrude(sketch_housing, 0, TOF_DEPTH + 6.0, 'new_body')

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, 0, 0, TOF_WIDTH + CLEARANCE * 2, TOF_HEIGHT + CLEARANCE * 2)
    try:
        extrude(sketch_pocket, 0, TOF_DEPTH + 2.0, 'cut')
    except:
        pass

    sketch_lens = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_lens, 0, 0, TOF_LENS_DIAMETER + 0.5)
    try:
        extrude(sketch_lens, 0, BRACKET_WALL + 3.0, 'cut')
    except:
        pass

    for hx in [-TOF_WIDTH / 2.0 - 1.0, TOF_WIDTH / 2.0 + 1.0]:
        for hz in [-TOF_HEIGHT / 2.0 - 1.0, TOF_HEIGHT / 2.0 + 1.0]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hz, 2.0)
            try:
                extrude(sketch_mh, 0, 6.0, 'cut')
            except:
                pass

    sketch_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_cable, 0, -housing_h / 2.0 - 3.0, 3.0, 6.0)
    try:
        extrude(sketch_cable, 0, 3.0, 'cut')
    except:
        pass

    sketch_cover = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_cover, 0, 0, TOF_LENS_DIAMETER + 4.0, TOF_LENS_DIAMETER + 4.0)
    try:
        extrude(sketch_cover, 0, 1.0, 'new_body')
    except:
        pass

    return comp


# ============================================================================
# LD19 LiDAR 마운트
# ============================================================================

def create_lidar_mount(root_comp):
    """LD19 LiDAR 마운트 (바디 상부, 360° 회전)"""
    comp = create_comp(root_comp, "LiDAR_LD19_Mount")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_housing = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_housing, 0, 0, LIDAR_DIAMETER / 2.0 + 5.0)
    extrude(sketch_housing, 0, LIDAR_HEIGHT + 10.0, 'new_body')

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_pocket, 0, 0, LIDAR_DIAMETER / 2.0 + CLEARANCE)
    try:
        extrude(sketch_pocket, 0, LIDAR_HEIGHT + 2.0, 'cut')
    except:
        pass

    sketch_window = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_window, 0, 0, LIDAR_DIAMETER / 2.0 - 3.0)
    try:
        extrude(sketch_window, 0, 2.0, 'cut')
    except:
        pass

    sketch_cable = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_cable, 0, 0, LIDAR_CABLE_DIAMETER + 2.0)
    try:
        extrude(sketch_cable, 0, LIDAR_HEIGHT + 15.0, 'cut')
    except:
        pass

    sketch_flange = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_flange, 0, 0, LIDAR_DIAMETER / 2.0 + 12.0)
    try:
        extrude(sketch_flange, 0, 3.0, 'new_body')
    except:
        pass

    for i in range(6):
        angle_rad = math.radians(i * 60.0)
        hx = (LIDAR_DIAMETER / 2.0 + 8.0) * math.cos(angle_rad)
        hy = (LIDAR_DIAMETER / 2.0 + 8.0) * math.sin(angle_rad)
        sketch_fh = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_fh, hx, hy, MOUNT_HOLE_DIA)
        try:
            extrude(sketch_fh, 0, 8.0, 'cut')
        except:
            pass

    sketch_cover = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_cover, 0, 0, LIDAR_DIAMETER / 2.0 + 3.0)
    try:
        extrude(sketch_cover, 0, 2.0, 'new_body')
    except:
        pass

    sketch_cover_in = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_cover_in, 0, 0, LIDAR_DIAMETER / 2.0 + 1.0)
    try:
        extrude(sketch_cover_in, 0, 3.0, 'cut')
    except:
        pass

    for i in range(3):
        angle_rad = math.radians(i * 120.0)
        clamp_x = (LIDAR_DIAMETER / 2.0 + 5.0) * math.cos(angle_rad)
        clamp_y = (LIDAR_DIAMETER / 2.0 + 5.0) * math.sin(angle_rad)
        sketch_clamp = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_clamp, clamp_x, clamp_y, 10.0, 6.0)
        try:
            extrude(sketch_clamp, 0, 4.0, 'new_body')
        except:
            pass

    return comp


# ============================================================================
# 케이블 라우팅
# ============================================================================

def create_cable_routing(root_comp):
    """카메라 → Jetson #1 USB 3.0 케이블 라우팅"""
    comp = create_comp(root_comp, "CameraCableRouting")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_ch = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_ch, 0, 0, CABLE_CHANNEL_WIDTH, 80.0)
    extrude(sketch_ch, 0, CABLE_CHANNEL_DEPTH, 'new_body')

    sketch_ch_in = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_ch_in, 0, 0, USB_CABLE_DIAMETER + 2.0, 78.0)
    try:
        extrude(sketch_ch_in, 0, CABLE_CHANNEL_DEPTH - 1.5, 'cut')
    except:
        pass

    for z_pos in [10.0, 40.0, 70.0]:
        sketch_tie = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_tie, 0, z_pos, CABLE_CHANNEL_WIDTH + 2.0, 2.0)
        try:
            extrude(sketch_tie, 0, 1.0, 'new_body')
        except:
            pass

    sketch_ferrite = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_ferrite, 0, 50.0, 15.0, 10.0)
    try:
        extrude(sketch_ferrite, 0, 8.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# 전면 센서 패널
# ============================================================================

def create_front_sensor_panel(root_comp):
    """전면 센서 패널 (OAK-D + ToF)"""
    comp = create_comp(root_comp, "FrontSensorPanel")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_panel = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_panel, 0, 0, 120.0, 50.0)
    extrude(sketch_panel, 0, BRACKET_WALL, 'new_body')

    sketch_oakd_open = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_oakd_open, 0, -5.0, OAKD_WIDTH + 2.0, OAKD_DEPTH + 2.0)
    try:
        extrude(sketch_oakd_open, 0, BRACKET_WALL + 2.0, 'cut')
    except:
        pass

    for tof_x in [-50.0, 50.0]:
        sketch_tof_open = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_tof_open, tof_x, 10.0, TOF_WIDTH + 2.0, TOF_HEIGHT + 2.0)
        try:
            extrude(sketch_tof_open, 0, BRACKET_WALL + 2.0, 'cut')
        except:
            pass

    for tof_x in [-50.0, 50.0]:
        sketch_tof_rear = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_tof_rear, tof_x, 20.0, TOF_WIDTH + 2.0, TOF_HEIGHT + 2.0)
        try:
            extrude(sketch_tof_rear, 0, BRACKET_WALL + 2.0, 'cut')
        except:
            pass

    for hx in [-55.0, 55.0]:
        for hz in [-20.0, 20.0]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hz, MOUNT_HOLE_DIA)
            try:
                extrude(sketch_mh, 0, 8.0, 'cut')
            except:
                pass

    return comp


# ============================================================================
# 완전 카메라 어셈블리
# ============================================================================

def create_camera_assembly(root_comp):
    """완전 카메라 + 센서 어셈블리 생성"""
    comp = create_comp(root_comp, "CameraSensorAssembly")
    if not comp:
        return None

    create_oakd_mount(comp)
    create_compliant_pan_tilt(comp)
    create_tof_sensor_mount(comp, "Front")
    create_tof_sensor_mount(comp, "Rear")
    create_lidar_mount(comp)
    create_cable_routing(comp)
    create_front_sensor_panel(comp)

    return comp


def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct
        if not design:
            ui.messageBox('활성 디자인이 없습니다 / No active design')
            return
        root_comp = design.rootComponent

        ui.messageBox('카메라 + 센서 어셈블리 생성 중...\nCreating camera + sensor assembly...')
        create_camera_assembly(root_comp)

        ui.messageBox(
            '지훈 로봇 V8.5 카메라 마운트 생성 완료!\n'
            'Jihun Robot V8.5 Camera Mount Complete!\n\n'
            f'OAK-D Pro: {OAKD_WIDTH}x{OAKD_DEPTH}x{OAKD_HEIGHT}mm\n'
            f'컴플라이언트 팬/틸트: ±{PAN_RANGE/2}°/±{TILT_RANGE/2}°\n'
            f'VL53L5CX ToF: 전면+후면\n'
            f'LD19 LiDAR: {LIDAR_DIAMETER}mm, 360° 회전\n'
            'IR 프로젝터 윈도우 포함\n'
            'USB 3.0 케이블 라우팅 (Jetson #1)'
        )
    except:
        if ui:
            ui.messageBox('실패:\nFailed:\n{}'.format(traceback.format_exc()))


def stop(context):
    pass
