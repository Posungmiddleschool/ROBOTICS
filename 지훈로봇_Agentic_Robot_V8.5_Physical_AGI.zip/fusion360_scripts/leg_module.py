#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 - 카본 파이버 신축 다리 모듈
Jihun Robot V8.5 - Carbon Fiber Telescoping Leg Module

Features:
  - 2개 신축 다리 (좌, 우) / 2 telescoping legs (left, right)
  - 3단 카본 파이버 튜브: 30mm/26mm/22mm 지름
  - GT2 벨트 드라이브 (동력 신축/수축)
  - 일정 하중 스프링 어시스트 (모터 토크 60% 감소)
  - 5cm 간격 핀 디텐트 홀 (대략적 위치 결정)
  - 캠락 미세 영력 유지 / Cam-lock fine zero-power holding
  - 각 단 자기 엔코더 (위치 피드백)
  - 발 패드 FSR-402 압력 센서 (2x2 그리드)
  - 범위: 0cm(완전 수축) ~ 150cm(완전 신축)

V8.5 Changes from V6:
  - B-G431B-ESC1 드라이버 보드 마운트 추가 (다리 리프트 모터용, 2개)
  - SimpleFOC Mini → B-G431B-ESC1 교체에 따른 GT2 벨트 라우팅 업데이트
  - 모터 소프트웨어 전류 제한 25A 반영 (방열 강화)
  - 버전 V8.5 업데이트

Author: Jihun Robot V8.5 Team
License: MIT
"""

import adsk.core
import adsk.fusion
import math
import traceback

# ============================================================================
# 상수 정의 / Constants
# ============================================================================
MM = 0.1  # cm per mm

# 카본 파이버 튜브 치수 / Carbon fiber tube dimensions
STAGE1_OD = 30.0   # mm (외경, 최외각)
STAGE1_ID = 26.5   # mm (inner diameter, 0.5mm diametral clearance for Ø26 stage)
STAGE2_OD = 26.0   # mm
STAGE2_ID = 22.5   # mm
STAGE3_OD = 22.0   # mm (최내각)
STAGE3_ID = 19.0   # mm

# 튜브 길이 / Tube lengths
STAGE1_LENGTH = 550.0   # mm
STAGE2_LENGTH = 530.0   # mm
STAGE3_LENGTH = 510.0   # mm

# GT2 벨트 드라이브 / GT2 belt drive
GT2_BELT_WIDTH = 6.0    # mm
GT2_PULLEY_TEETH = 20
GT2_PULLEY_OD = 12.0    # mm
GT2_PULLEY_BORE = 8.0   # mm (2806 BLDC motor D-shaft, 8mm)
GT2_BELT_PITCH = 2.0    # mm

# 일정 하중 스프링 / Constant-force spring
SPRING_FORCE = 15.0     # N
SPRING_LENGTH = 500.0   # mm
SPRING_COILED_OD = 25.0 # mm
SPRING_MOUNT_WIDTH = 30.0

# 핀 디텐트 / Pin detent
DETENT_HOLE_DIA = 4.0   # mm
DETENT_SPACING = 50.0   # mm (5cm 간격)
DETENT_PIN_DIA = 3.5    # mm
DETENT_SPRING_FORCE = 5.0  # N

# 캠락 / Cam-lock
CAM_LOCK_DIAMETER = 10.0
CAM_LOCK_TRAVEL = 2.0

# 자기 엔코더 / Magnetic encoder
ENCODER_DIAMETER = 10.0  # mm
ENCODER_THICKNESS = 2.0  # mm
ENCODER_MAGNET_DIA = 3.0

# 발 패드 / Foot pad
FOOT_PAD_DIAMETER = 60.0
FOOT_PAD_THICKNESS = 5.0
FSR_DIAMETER = 18.0     # FSR-402
FSR_GRID_SPACING = 20.0

# 마운팅 브래킷 / Mounting bracket
BRACKET_WIDTH = 50.0
BRACKET_DEPTH = 40.0
BRACKET_HEIGHT = 80.0

# 전체 범위 / Full range
MIN_HEIGHT = 0.0    # mm (완전 수축)
MAX_HEIGHT = 1500.0 # mm (완전 신축, 150cm)

# 모터 / Motor
MOTOR_WIDTH = 35.0   # NEMA 14 사이즈
MOTOR_LENGTH = 36.0
MOTOR_SHAFT_DIA = 8.0  # 2806 BLDC motor D-shaft diameter

# V7: B-G431B-ESC1 드라이버 보드 (다리 리프트 모터용)
BG431_WIDTH = 33.0         # mm
BG431_DEPTH = 33.0         # mm
BG431_HEIGHT = 15.0        # mm (커넥터 포함)
BG431_MOUNT_HOLE_SPACING = 28.0  # mm (코너 M3 홀 간격)
BG431_MOUNT_HOLE_DIA = 3.0 # mm (M3)

# 모터 소프트웨어 전류 제한 / Motor software current limit
MOTOR_CURRENT_LIMIT = 25.0  # A (V7: 25A 소프트웨어 제한)

# 허용 오차 / Tolerances
CLEARANCE = 0.3  # mm
SLIDE_CLEARANCE = 0.5  # mm (슬라이딩 피트)


def mm(val):
    """mm → cm 변환 / Convert mm to cm"""
    return val * 0.1


def create_comp(root, name):
    """새 컴포넌트 생성 / Create new component"""
    try:
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = occ.component
        comp.name = name
        return comp
    except:
        return None


def draw_circle(sketch, cx, cy, dia):
    """원 그리기 / Draw circle"""
    center = adsk.core.Point3D.create(mm(cx), mm(cy), 0)
    circles = sketch.sketchCurves.sketchCircles
    return circles.addByCenterRadius(center, mm(dia / 2.0))


def draw_rect(sketch, cx, cy, w, h):
    """중심 기준 사각형 / Centered rectangle"""
    hw = mm(w / 2.0)
    hh = mm(h / 2.0)
    cx_cm = mm(cx)
    cy_cm = mm(cy)
    lines = sketch.sketchCurves.sketchLines
    p1 = adsk.core.Point3D.create(cx_cm - hw, cy_cm - hh, 0)
    p2 = adsk.core.Point3D.create(cx_cm + hw, cy_cm - hh, 0)
    p3 = adsk.core.Point3D.create(cx_cm + hw, cy_cm + hh, 0)
    p4 = adsk.core.Point3D.create(cx_cm - hw, cy_cm + hh, 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)


def extrude(sketch, idx, depth, op='join', direction=1):
    """돌출 / Extrude"""
    profiles = sketch.profiles
    if profiles.count <= idx:
        return None
    profile = profiles.item(idx)
    comp = sketch.parentComponent
    extrudes = comp.features.extrudeFeatures
    ops = {
        'join': adsk.fusion.FeatureOperations.JoinFeatureOperation,
        'cut': adsk.fusion.FeatureOperations.CutFeatureOperation,
        'new_body': adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
    }
    ext_input = extrudes.createInput(profile, ops.get(op, ops['join']))
    dist = adsk.core.ValueInput.createByReal(mm(depth) * direction)
    ext_input.setDistanceExtent(False, dist)
    return extrudes.add(ext_input)


# ============================================================================
# 카본 파이버 튜브 스테이지 / Carbon Fiber Tube Stages
# ============================================================================

def create_tube_stage(root_comp, stage_name, outer_dia, inner_dia, length):
    """단일 카본 파이버 튜브 스테이지 생성"""
    comp = create_comp(root_comp, stage_name)
    if not comp:
        return None

    sketches = comp.sketches

    sketch_out = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_out, 0, 0, outer_dia)
    extrude(sketch_out, 0, length, 'new_body')

    sketch_in = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_in, 0, 0, inner_dia)
    try:
        extrude(sketch_in, 0, length + 2.0, 'cut')
    except:
        pass

    # GT2 벨트 통과용 슬롯
    for side_x in [outer_dia / 2.0 - 2.0, -(outer_dia / 2.0 - 2.0)]:
        sketch_slot = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_slot, side_x, 0, GT2_BELT_WIDTH + 1.0, length - 40.0)
        try:
            extrude(sketch_slot, 0, 4.0, 'cut')
        except:
            pass

    # 핀 디텐트 홀
    num_holes = int((length - 80.0) / DETENT_SPACING)
    for i in range(num_holes):
        z_pos = 40.0 + i * DETENT_SPACING
        for angle_deg in [0, 90, 180, 270]:
            angle_rad = math.radians(angle_deg)
            hx = (outer_dia / 2.0 - 2.0) * math.cos(angle_rad)
            hy = (outer_dia / 2.0 - 2.0) * math.sin(angle_rad)
            sketch_hole = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_hole, hx, hy, DETENT_HOLE_DIA)
            try:
                extrude(sketch_hole, 0, 5.0, 'cut')
            except:
                pass

    # 스톱 링 홈 (상단)
    sketch_stop = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_stop, 0, 0, inner_dia + 1.0)
    try:
        extrude(sketch_stop, 0, 3.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# GT2 벨트 드라이브 메커니즘 / GT2 Belt Drive Mechanism
# ============================================================================

def create_gt2_belt_drive(root_comp):
    """GT2 벨트 드라이브 메커니즘 (동력 신축)"""
    comp = create_comp(root_comp, "GT2_BeltDrive")
    if not comp:
        return None

    sketches = comp.sketches

    # 구동 풀리
    sketch_pulley = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_pulley, 0, 0, GT2_PULLEY_OD)
    extrude(sketch_pulley, 0, GT2_BELT_WIDTH + 2.0, 'new_body')

    # 풀리 보어
    sketch_bore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_bore, 0, 0, GT2_PULLEY_BORE)
    try:
        extrude(sketch_bore, 0, GT2_BELT_WIDTH + 4.0, 'cut')
    except:
        pass

    # M3 세트 스크류 홀 (모터 샤프트 커플링)
    sketch_setscrew = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_setscrew, GT2_PULLEY_BORE / 2.0 + 1.0, GT2_BELT_WIDTH / 2.0, 3.0)
    try:
        extrude(sketch_setscrew, 0, GT2_PULLEY_BORE / 2.0, 'cut')
    except:
        pass

    # V7: GT2 벨트 텐셔닝 슬롯 (B-G431B-ESC1 교체 후 벨트 장력 조절)
    # Belt tensioning slot for B-G431B-ESC1 replacement
    sketch_tension = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_tension, 0, -GT2_PULLEY_OD - 10.0, 20.0, 30.0)
    try:
        extrude(sketch_tension, 0, 4.0, 'new_body')
    except:
        pass
    sketch_tslot = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_tslot, 0, -GT2_PULLEY_OD - 10.0, 3.2, 20.0)
    try:
        extrude(sketch_tslot, 0, 6.0, 'cut')
    except:
        pass

    # 풀리 이빨 (간소화 홈)
    for i in range(GT2_PULLEY_TEETH):
        angle_rad = math.radians(i * 360.0 / GT2_PULLEY_TEETH)
        r = (GT2_PULLEY_OD - 2.0) / 2.0
        tx = r * math.cos(angle_rad)
        ty = r * math.sin(angle_rad)
        sketch_tooth = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_tooth, tx, ty, 1.0)
        try:
            extrude(sketch_tooth, 0, GT2_BELT_WIDTH + 1.0, 'cut')
        except:
            pass

    # 아이들러 풀리
    idler_z = STAGE1_LENGTH - 30.0
    sketch_idler = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_idler, 0, idler_z, GT2_PULLEY_OD * 0.8)
    try:
        extrude(sketch_idler, 0, GT2_BELT_WIDTH + 2.0, 'new_body')
    except:
        pass

    sketch_ibore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_ibore, 0, idler_z, 3.0)
    try:
        extrude(sketch_ibore, 0, GT2_BELT_WIDTH + 4.0, 'cut')
    except:
        pass

    # 벨트 가이드 레일
    for side in [-1, 1]:
        rail_x = side * (STAGE1_OD / 2.0 + 5.0)
        sketch_rail = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_rail, rail_x, STAGE1_LENGTH / 2.0, 3.0, STAGE1_LENGTH - 60.0)
        try:
            extrude(sketch_rail, 0, 5.0, 'new_body')
        except:
            pass

    # 벨트 클램프 (각 스테이지 연결)
    for stage_z in [200.0, 450.0]:
        sketch_clamp = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_clamp, STAGE1_OD / 2.0 + 3.0, stage_z, 15.0, 10.0)
        try:
            extrude(sketch_clamp, 0, GT2_BELT_WIDTH + 4.0, 'new_body')
        except:
            pass

    return comp


# ============================================================================
# V7: B-G431B-ESC1 다리 리프트 모터 드라이버 마운트 / V7: B-G431B-ESC1 Leg Lift Motor Driver Mount
# ============================================================================

def create_bg431_leg_mount(root_comp, leg_side="Left"):
    """
    V8.5 추가: B-G431B-ESC1 다리 리프트 모터 드라이버 마운트
    V8.5 New: B-G431B-ESC1 leg lift motor driver mount

    SimpleFOC Mini → B-G431B-ESC1 교체 (33×33mm, 4×M3, 15mm 높이)
    모터 소프트웨어 전류 제한 25A 반영
    """
    comp = create_comp(root_comp, f"BG431_LegLift_{leg_side}")
    if not comp:
        return None

    sketches = comp.sketches

    # 마운트 위치: 브래킷 측면 / Mount position: bracket side
    cx = 0
    cy = -BRACKET_HEIGHT / 2.0 - 25.0

    # --- 마운트 플레이트 / Mount plate ---
    sketch_plate = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_plate, cx, cy, BG431_WIDTH + 10.0, BG431_DEPTH + 10.0)
    extrude(sketch_plate, 0, 3.0, 'new_body')

    # --- 보드 포켓 / Board pocket ---
    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, cx, cy, BG431_WIDTH + CLEARANCE, BG431_DEPTH + CLEARANCE)
    try:
        extrude(sketch_pocket, 0, 2.0, 'cut')
    except:
        pass

    # --- M3 마운팅 홀 (4개 코너) / M3 mounting holes ---
    for hx in [-1, 1]:
        for hy in [-1, 1]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh,
                        cx + hx * (BG431_MOUNT_HOLE_SPACING / 2.0),
                        cy + hy * (BG431_MOUNT_HOLE_SPACING / 2.0),
                        BG431_MOUNT_HOLE_DIA)
            try:
                extrude(sketch_mh, 0, 6.0, 'cut')
            except:
                pass

    # --- 열 패드 리세스 (25A 전류 제한 방열) / Thermal pad recess (25A current limit cooling) ---
    sketch_thermal = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_thermal, cx, cy, 20.0, 20.0)
    try:
        extrude(sketch_thermal, 0, 1.5, 'cut')
    except:
        pass

    # --- 모터 케이블 컷아웃 / Motor cable cutout ---
    sketch_motor_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_motor_cable, cx, cy + BG431_DEPTH / 2.0 + 2.0, 15.0, 5.0)
    try:
        extrude(sketch_motor_cable, 0, 10.0, 'cut')
    except:
        pass

    # --- 전원/통신 케이블 컷아웃 / Power/comm cable cutout ---
    sketch_power_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_power_cable, cx - BG431_WIDTH / 2.0 - 2.0, cy, 5.0, 8.0)
    try:
        extrude(sketch_power_cable, 0, 8.0, 'cut')
    except:
        pass

    # --- 방열 필름 가이드 / Heat dissipation film guide ---
    # V7: 25A 전류 제한으로 방열 필름 추가 / Added for 25A current limit
    sketch_heatsink = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_heatsink, cx, cy, BG431_WIDTH - 4.0, BG431_DEPTH - 4.0)
    try:
        extrude(sketch_heatsink, 0, -0.5, 'new_body', -1)
    except:
        pass

    return comp


# ============================================================================
# 일정 하중 스프링 / Constant-Force Spring
# ============================================================================

def create_constant_force_spring(root_comp):
    """일정 하중 스프링 어시스트"""
    comp = create_comp(root_comp, "ConstantForceSpring")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_drum = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_drum, -30.0, 30.0, SPRING_COILED_OD)
    extrude(sketch_drum, 0, SPRING_MOUNT_WIDTH, 'new_body')

    sketch_dbore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_dbore, -30.0, 30.0, 8.0)
    try:
        extrude(sketch_dbore, 0, SPRING_MOUNT_WIDTH + 2.0, 'cut')
    except:
        pass

    for layer in range(5):
        layer_dia = SPRING_COILED_OD - layer * 3.0
        if layer_dia > 8.0:
            sketch_coil = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_coil, -30.0, 30.0, layer_dia)
            try:
                extrude(sketch_coil, 0, SPRING_MOUNT_WIDTH, 'new_body')
            except:
                pass

    # 테이프 인출 경로
    sketch_tape = sketches.add(comp.xZConstructionPlane)
    lines = sketch_tape.sketchCurves.sketchLines
    tape_start_x = -30.0 + SPRING_COILED_OD / 2.0
    p1 = adsk.core.Point3D.create(mm(tape_start_x), mm(30.0), 0)
    p2 = adsk.core.Point3D.create(mm(tape_start_x + 5.0), mm(-50.0), 0)
    p3 = adsk.core.Point3D.create(mm(tape_start_x + 5.0), mm(-200.0), 0)
    p4 = adsk.core.Point3D.create(mm(tape_start_x), mm(-200.0), 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)
    try:
        extrude(sketch_tape, 0, 2.0, 'new_body')
    except:
        pass

    sketch_mount = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_mount, -30.0, 30.0, SPRING_MOUNT_WIDTH + 10.0, 40.0)
    try:
        extrude(sketch_mount, 0, 5.0, 'new_body')
    except:
        pass

    for hx in [-40.0, -20.0]:
        for hz in [18.0, 42.0]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hz, 3.2)
            try:
                extrude(sketch_mh, 0, 8.0, 'cut')
            except:
                pass

    return comp


# ============================================================================
# 캠락 미세 고정 / Cam-Lock Fine Holding
# ============================================================================

def create_cam_lock_hold(root_comp):
    """캠락 미세 영력 유지 메커니즘"""
    comp = create_comp(root_comp, "CamLockHold")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_cam = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_cam, 0, 0, CAM_LOCK_DIAMETER)
    extrude(sketch_cam, 0, 8.0, 'new_body')

    sketch_bore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_bore, 2.0, 0, 3.0)
    try:
        extrude(sketch_bore, 0, 10.0, 'cut')
    except:
        pass

    sketch_handle = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_handle, CAM_LOCK_DIAMETER / 2.0 + 5.0, 0, 15.0, 6.0)
    try:
        extrude(sketch_handle, 0, 4.0, 'join')
    except:
        pass

    sketch_rcv = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_rcv, 0, 0, CAM_LOCK_DIAMETER + 10.0, CAM_LOCK_DIAMETER + 10.0)
    try:
        extrude(sketch_rcv, 0, 12.0, 'new_body')
    except:
        pass

    sketch_slot = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_slot, 0, 0, CAM_LOCK_DIAMETER + 1.0)
    try:
        extrude(sketch_slot, 0, 10.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# 자기 엔코더 마운트 / Magnetic Encoder Mount
# ============================================================================

def create_encoder_mount(root_comp, stage_index):
    """자기 엔코더 마운트 (각 스테이지)"""
    comp = create_comp(root_comp, f"MagneticEncoder_Stage{stage_index}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_pcb = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pcb, 0, 0, ENCODER_DIAMETER + 6.0, ENCODER_DIAMETER + 6.0)
    extrude(sketch_pcb, 0, ENCODER_THICKNESS + 2.0, 'new_body')

    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, 0, 0, ENCODER_DIAMETER + 2.0, ENCODER_DIAMETER + 2.0)
    try:
        extrude(sketch_pocket, 0, ENCODER_THICKNESS, 'cut')
    except:
        pass

    sketch_mag = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_mag, 0, 15.0, ENCODER_MAGNET_DIA)
    try:
        extrude(sketch_mag, 0, 2.0, 'new_body')
    except:
        pass

    for corner in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
        hx = corner[0] * (ENCODER_DIAMETER / 2.0 + 1.0)
        hz = corner[1] * (ENCODER_DIAMETER / 2.0 + 1.0)
        sketch_mh = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_mh, hx, hz, 2.0)
        try:
            extrude(sketch_mh, 0, 5.0, 'cut')
        except:
            pass

    sketch_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_cable, 0, -ENCODER_DIAMETER / 2.0 - 5.0, 4.0, 8.0)
    try:
        extrude(sketch_cable, 0, 2.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# 발 패드 / Foot Pad
# ============================================================================

def create_foot_pad(root_comp):
    """발 패드 (FSR-402 압력 센서 2x2 그리드)"""
    comp = create_comp(root_comp, "FootPad")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_base = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_base, 0, 0, FOOT_PAD_DIAMETER)
    extrude(sketch_base, 0, FOOT_PAD_THICKNESS, 'new_body')

    for row in range(2):
        for col in range(2):
            sx = (col - 0.5) * FSR_GRID_SPACING
            sy = (row - 0.5) * FSR_GRID_SPACING
            sketch_fsr = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_fsr, sx, sy, FSR_DIAMETER + 2.0)
            try:
                extrude(sketch_fsr, 0, 2.0, 'cut')
            except:
                pass
            sketch_smh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_smh, sx, sy, 2.0)
            try:
                extrude(sketch_smh, 0, FOOT_PAD_THICKNESS + 1.0, 'cut')
            except:
                pass

    sketch_cushion = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_cushion, 0, 0, FOOT_PAD_DIAMETER - 3.0)
    try:
        extrude(sketch_cushion, 0, -3.0, 'new_body', -1)
    except:
        pass

    sketch_conn = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_conn, 0, 0, STAGE3_OD + 10.0)
    try:
        extrude(sketch_conn, 0, 15.0, 'new_body')
    except:
        pass

    sketch_cbore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_cbore, 0, 0, STAGE3_ID + CLEARANCE)
    try:
        extrude(sketch_cbore, 0, 18.0, 'cut')
    except:
        pass

    for angle_deg in [0, 120, 240]:
        angle_rad = math.radians(angle_deg)
        hx = (STAGE3_OD / 2.0 + 3.0) * math.cos(angle_rad)
        hy = (STAGE3_OD / 2.0 + 3.0) * math.sin(angle_rad)
        sketch_pin = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_pin, hx, hy, 4.0)
        try:
            extrude(sketch_pin, 0, 10.0, 'cut')
        except:
            pass

    return comp


# ============================================================================
# 상부 마운팅 브래킷 / Top Mounting Bracket
# ============================================================================

def create_mounting_bracket(root_comp, side="Left"):
    """상부 마운팅 브래킷 (바디 연결)"""
    comp = create_comp(root_comp, f"LegBracket_{side}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_bracket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_bracket, 0, BRACKET_HEIGHT / 2.0, BRACKET_WIDTH, BRACKET_HEIGHT)
    extrude(sketch_bracket, 0, BRACKET_DEPTH, 'new_body')

    sketch_tube = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_tube, 0, BRACKET_HEIGHT - 15.0, STAGE1_OD + CLEARANCE)
    try:
        extrude(sketch_tube, 0, BRACKET_DEPTH + 2.0, 'cut')
    except:
        pass

    sketch_motor = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_motor, 0, 20.0, MOTOR_WIDTH + 6.0, MOTOR_LENGTH + 6.0)
    try:
        extrude(sketch_motor, 0, BRACKET_DEPTH + 2.0, 'cut')
    except:
        pass

    sketch_shaft = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_shaft, 0, 20.0, MOTOR_SHAFT_DIA + CLEARANCE)
    try:
        extrude(sketch_shaft, 0, BRACKET_DEPTH + 4.0, 'cut')
    except:
        pass

    for hx in [-BRACKET_WIDTH / 2.0 + 8.0, BRACKET_WIDTH / 2.0 - 8.0]:
        for hz in [8.0, BRACKET_HEIGHT - 8.0]:
            sketch_bh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_bh, hx, hz, 6.0)
            try:
                extrude(sketch_bh, 0, 12.0, 'cut')
            except:
                pass

    for rib_x in [-BRACKET_WIDTH / 2.0 + 5.0, BRACKET_WIDTH / 2.0 - 5.0]:
        sketch_rib = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_rib, rib_x, BRACKET_HEIGHT / 2.0, 3.0, BRACKET_HEIGHT - 20.0)
        try:
            extrude(sketch_rib, 0, BRACKET_DEPTH / 2.0, 'join')
        except:
            pass

    return comp


# ============================================================================
# 핀 디텐트 메커니즘 / Pin Detent Mechanism
# ============================================================================

def create_pin_detent(root_comp):
    """핀 디텐트 메커니즘 (대략적 위치 결정)"""
    comp = create_comp(root_comp, "PinDetent")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_housing = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_housing, 0, 0, 10.0, 20.0)
    extrude(sketch_housing, 0, 10.0, 'new_body')

    sketch_pin = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pin, 0, 2.0, DETENT_PIN_DIA, 15.0)
    try:
        extrude(sketch_pin, 0, 5.0, 'new_body')
    except:
        pass

    sketch_spring = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_spring, 0, -3.0, 5.0, 6.0)
    try:
        extrude(sketch_spring, 0, 5.0, 'cut')
    except:
        pass

    sketch_guide = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_guide, 0, 10.0, DETENT_PIN_DIA + 0.5, 8.0)
    try:
        extrude(sketch_guide, 0, 5.0, 'cut')
    except:
        pass

    sketch_button = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_button, 0, -8.0, 8.0, 4.0)
    try:
        extrude(sketch_button, 0, 3.0, 'new_body')
    except:
        pass

    return comp


# ============================================================================
# 완전 다리 어셈블리 / Complete Leg Assembly
# ============================================================================

def create_leg_assembly(root_comp, side="Left"):
    """완전 다리 어셈블리 생성"""
    leg_name = f"Leg_{side}"
    comp = create_comp(root_comp, leg_name)
    if not comp:
        return None

    # 서브 컴포넌트 생성
    create_tube_stage(comp, f"Stage1_30mm_{side}", STAGE1_OD, STAGE1_ID, STAGE1_LENGTH)
    create_tube_stage(comp, f"Stage2_26mm_{side}", STAGE2_OD, STAGE2_ID, STAGE2_LENGTH)
    create_tube_stage(comp, f"Stage3_22mm_{side}", STAGE3_OD, STAGE3_ID, STAGE3_LENGTH)

    create_gt2_belt_drive(comp)
    create_constant_force_spring(comp)
    create_cam_lock_hold(comp)
    create_foot_pad(comp)
    create_mounting_bracket(comp, side)
    create_pin_detent(comp)

    # V7: B-G431B-ESC1 다리 리프트 모터 드라이버 마운트
    create_bg431_leg_mount(comp, side)

    # 각 스테이지 자기 엔코더
    for i in range(3):
        create_encoder_mount(comp, i)

    return comp


# ============================================================================
# 메인 실행 / Main Execution
# ============================================================================

def run(context):
    """메인 실행 함수 / Main execution function"""
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct

        if not design:
            ui.messageBox('활성 디자인이 없습니다 / No active design')
            return

        root_comp = design.rootComponent

        ui.messageBox('좌측 다리 생성 중...\nCreating left leg...')
        create_leg_assembly(root_comp, "Left")

        ui.messageBox('우측 다리 생성 중...\nCreating right leg...')
        create_leg_assembly(root_comp, "Right")

        ui.messageBox(
            '지훈 로봇 V8.5 다리 모듈 생성 완료!\n'
            'Jihun Robot V8.5 Leg Module Complete!\n\n'
            f'3단 카본 파이버: {STAGE1_OD}/{STAGE2_OD}/{STAGE3_OD}mm\n'
            f'GT2 벨트 드라이브: {GT2_PULLEY_TEETH}T 풀리\n'
            f'일정 하중 스프링: {SPRING_FORCE}N\n'
            f'핀 디텐트: {DETENT_SPACING}mm 간격\n'
            f'범위: {MIN_HEIGHT}~{MAX_HEIGHT}mm\n'
            f'FSR-402: 2x2 그리드\n'
            f'자기 엔코더: 스테이지당 1개\n'
            f'V7: B-G431B-ESC1 다리 리프트 마운트 (x2)\n'
            f'V7: 모터 전류 제한 {MOTOR_CURRENT_LIMIT}A'
        )

    except:
        if ui:
            ui.messageBox('실패:\nFailed:\n{}'.format(traceback.format_exc()))


def stop(context):
    """정리 함수 / Cleanup function"""
    pass
