#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 - 듀얼 메카넘 휠 어셈블리
Jihun Robot V8.5 - Dual Mecanum Wheel Assembly

Features:
  - 4x 80mm 메카넘 휠 (알루미늄 허브)
  - 듀얼 로우 TPU 롤러 (향상된 접지력)
  - MR105ZZ 베어링 (모든 롤러 축)
  - B-G431B-ESC1 모터 드라이버 마운팅 (V7: SimpleFOC Mini 교체)
  - 2204 BLDC 모터 마운팅
  - 간단 컴플라이언트 서스펜션 (3D 프린트 TPU 플렉스처)
  - 퀵 릴리즈 휠 마운트 (볼 락 핀)

V8.5 Changes from V6:
  - B-G431B-ESC1 드라이버 보드 마운트 추가 (각 휠 허브 위치, 4개)
    SimpleFOC Mini → B-G431B-ESC1 교체 (33×33mm, 4×M3 코너, 15mm 높이)
  - 모터 소프트웨어 전류 제한 25A 반영
  - 열 패드 리세스 추가 (B-G431B-ESC1 방열용)
  - 버전 V8.5 업데이트

Author: Jihun Robot V8.5 Team
License: MIT
"""

import adsk.core
import adsk.fusion
import math
import traceback

# ============================================================================
# 상수 정의 / Constants
# ============================================================================
MM = 0.1  # cm per mm

# 메카넘 휠 / Mecanum wheel
WHEEL_DIAMETER = 80.0
WHEEL_WIDTH = 35.0
HUB_DIAMETER = 30.0
HUB_WIDTH = WHEEL_WIDTH
HUB_BORE = 5.0  # 2204 BLDC motor shaft

# 롤러 / Rollers
ROLLER_DIAMETER = 12.0
ROLLER_LENGTH = 18.0
ROLLER_ANGLE = 45.0
ROLLERS_PER_WHEEL = 9
ROLLER_ROWS = 2

# MR105ZZ 베어링
BEARING_OD = 10.0
BEARING_ID = 5.0
BEARING_WIDTH = 4.0

# 2204 BLDC 모터
MOTOR_DIAMETER = 27.7
MOTOR_HEIGHT = 16.0
MOTOR_SHAFT_DIA = 5.0
MOTOR_MOUNT_HOLE_PCD = 19.0
MOTOR_MOUNT_HOLE_DIA = 3.0
MOTOR_MOUNT_HOLE_COUNT = 4
MOTOR_MOUNT_SPACING_X = 19.0
MOTOR_MOUNT_SPACING_Y = 19.0

# V7: B-G431B-ESC1 드라이버 보드 (SimpleFOC Mini 교체)
BG431_WIDTH = 33.0         # mm
BG431_DEPTH = 33.0         # mm
BG431_HEIGHT = 15.0        # mm (커넥터 포함)
BG431_MOUNT_HOLE_SPACING = 28.0  # mm (코너 M3 홀 간격)
BG431_MOUNT_HOLE_DIA = 3.0 # mm (M3)

# 모터 소프트웨어 전류 제한 / Motor software current limit
MOTOR_CURRENT_LIMIT = 25.0  # A (V7: 25A 소프트웨어 제한)

# 서스펜션
SUSPENSION_TRAVEL = 15.0
SUSPENSION_WIDTH = 30.0
SUSPENSION_LENGTH = 50.0
SUSPENSION_THICKNESS = 4.0
SUSPENSION_ARM_LENGTH = 60.0
SUSPENSION_ARM_WIDTH = 10.0

# 퀵 릴리즈
QUICK_RELEASE_PIN_DIA = 6.0
QUICK_RELEASE_PIN_LENGTH = 25.0

# 허용 오차
CLEARANCE = 0.2
PRESS_FIT = -0.05


def mm(val):
    return val * 0.1

def create_comp(root, name):
    try:
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = occ.component
        comp.name = name
        return comp
    except:
        return None

def draw_circle(sketch, cx, cy, dia):
    center = adsk.core.Point3D.create(mm(cx), mm(cy), 0)
    circles = sketch.sketchCurves.sketchCircles
    return circles.addByCenterRadius(center, mm(dia / 2.0))

def draw_rect(sketch, cx, cy, w, h):
    hw = mm(w / 2.0)
    hh = mm(h / 2.0)
    lines = sketch.sketchCurves.sketchLines
    p1 = adsk.core.Point3D.create(mm(cx) - hw, mm(cy) - hh, 0)
    p2 = adsk.core.Point3D.create(mm(cx) + hw, mm(cy) - hh, 0)
    p3 = adsk.core.Point3D.create(mm(cx) + hw, mm(cy) + hh, 0)
    p4 = adsk.core.Point3D.create(mm(cx) - hw, mm(cy) + hh, 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)

def extrude(sketch, idx, depth, op='join', direction=1):
    profiles = sketch.profiles
    if profiles.count <= idx:
        return None
    profile = profiles.item(idx)
    comp = sketch.parentComponent
    extrudes = comp.features.extrudeFeatures
    ops = {
        'join': adsk.fusion.FeatureOperations.JoinFeatureOperation,
        'cut': adsk.fusion.FeatureOperations.CutFeatureOperation,
        'new_body': adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
    }
    ext_input = extrudes.createInput(profile, ops.get(op, ops['join']))
    dist = adsk.core.ValueInput.createByReal(mm(depth) * direction)
    ext_input.setDistanceExtent(False, dist)
    return extrudes.add(ext_input)


# ============================================================================
# 알루미늄 허브 / Aluminum Hub
# ============================================================================

def create_aluminum_hub(root_comp, wheel_index=0):
    """80mm 메카넘 휠 알루미늄 허브"""
    comp = create_comp(root_comp, f"AluminumHub_W{wheel_index}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_hub = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_hub, 0, 0, HUB_DIAMETER)
    extrude(sketch_hub, 0, HUB_WIDTH, 'new_body')

    sketch_bore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_bore, 0, 0, HUB_BORE + CLEARANCE)
    try:
        extrude(sketch_bore, 0, HUB_WIDTH + 2.0, 'cut')
    except:
        pass

    sketch_key = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_key, HUB_BORE / 2.0 - 1.0, 0, 2.0, HUB_WIDTH)
    try:
        extrude(sketch_key, 0, 1.5, 'cut')
    except:
        pass

    # M3 세트 스크류 홀
    sketch_setscrew = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_setscrew, HUB_BORE / 2.0 + 1.0, 0, 3.0)
    try:
        extrude(sketch_setscrew, 0, HUB_BORE / 2.0 + 1.0, 'cut')
    except:
        pass

    # 롤러 마운팅 플랜지
    for side in [-1, 1]:
        flange_z = side * (HUB_WIDTH / 2.0 + 2.0)
        sketch_flange = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_flange, 0, 0, WHEEL_DIAMETER / 2.0 - ROLLER_DIAMETER / 2.0 + 3.0)
        try:
            ext_dir = 1 if side > 0 else -1
            extrude(sketch_flange, 0, 4.0, 'join', ext_dir)
        except:
            pass

    # 롤러 액슬 홀
    for row_idx in range(ROLLER_ROWS):
        row_offset = (row_idx - (ROLLER_ROWS - 1) / 2.0) * (ROLLER_LENGTH + 2.0)
        angle_offset = row_idx * (180.0 / ROLLERS_PER_WHEEL)

        for i in range(ROLLERS_PER_WHEEL):
            angle_deg = i * (360.0 / ROLLERS_PER_WHEEL) + angle_offset
            angle_rad = math.radians(angle_deg)
            pitch_r = WHEEL_DIAMETER / 2.0 - ROLLER_DIAMETER / 2.0

            ax = pitch_r * math.cos(angle_rad)
            ay = pitch_r * math.sin(angle_rad)

            sketch_axle = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_axle, ax, ay, BEARING_ID)
            try:
                extrude(sketch_axle, 0, ROLLER_LENGTH + 6.0, 'cut')
            except:
                pass

            sketch_bearing = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_bearing, ax, ay, BEARING_OD)
            try:
                extrude(sketch_bearing, 0, BEARING_WIDTH, 'cut')
            except:
                pass

    # 모터 마운팅 홀 (19×19mm 사각)
    for hx in [-MOTOR_MOUNT_SPACING_X / 2.0, MOTOR_MOUNT_SPACING_X / 2.0]:
        for hy in [-MOTOR_MOUNT_SPACING_Y / 2.0, MOTOR_MOUNT_SPACING_Y / 2.0]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hy, MOTOR_MOUNT_HOLE_DIA)
            try:
                extrude(sketch_mh, 0, 10.0, 'cut')
            except:
                pass

    # 휠 타이 마운팅 홀
    for i in range(6):
        angle_rad = math.radians(i * 60.0)
        r = HUB_DIAMETER / 2.0 - 3.0
        hx = r * math.cos(angle_rad)
        hy = r * math.sin(angle_rad)
        sketch_tmh = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_tmh, hx, hy, 2.2)
        try:
            extrude(sketch_tmh, 0, HUB_WIDTH + 2.0, 'cut')
        except:
            pass

    return comp


# ============================================================================
# TPU 듀얼 로우 롤러
# ============================================================================

def create_tpu_roller(root_comp, roller_index=0):
    """TPU 듀얼 로우 롤러 (메카넘 45도 경사)"""
    comp = create_comp(root_comp, f"TPURoller_R{roller_index}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_roller = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_roller, 0, 0, ROLLER_DIAMETER)
    extrude(sketch_roller, 0, ROLLER_LENGTH, 'new_body')

    for z_pos in [2.0, ROLLER_LENGTH - 2.0]:
        sketch_bearing = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_bearing, 0, 0, BEARING_OD)
        try:
            extrude(sketch_bearing, 0, BEARING_WIDTH, 'cut')
        except:
            pass

    sketch_bbore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_bbore, 0, 0, BEARING_ID)
    try:
        extrude(sketch_bbore, 0, ROLLER_LENGTH + 2.0, 'cut')
    except:
        pass

    for z in range(int(ROLLER_LENGTH / 4)):
        z_pos = 2.0 + z * 4.0
        sketch_grip = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_grip, 0, z_pos, ROLLER_DIAMETER + 0.5)
        try:
            extrude(sketch_grip, 0, 1.0, 'new_body')
        except:
            pass

    return comp


def create_all_rollers(root_comp, wheel_index=0):
    """휠 하나의 모든 롤러 생성"""
    comp = create_comp(root_comp, f"AllRollers_W{wheel_index}")
    if not comp:
        return None

    roller_count = ROLLERS_PER_WHEEL * ROLLER_ROWS
    for i in range(roller_count):
        create_tpu_roller(comp, i)

    return comp


# ============================================================================
# MR105ZZ 베어링
# ============================================================================

def create_bearing(root_comp, name="MR105ZZ"):
    """MR105ZZ 미니어처 베어링 모델"""
    comp = create_comp(root_comp, name)
    if not comp:
        return None

    sketches = comp.sketches

    sketch_outer = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_outer, 0, 0, BEARING_OD)
    extrude(sketch_outer, 0, BEARING_WIDTH, 'new_body')

    sketch_inner = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_inner, 0, 0, BEARING_ID)
    try:
        extrude(sketch_inner, 0, BEARING_WIDTH + 1.0, 'cut')
    except:
        pass

    sketch_channel = sketches.add(comp.xZConstructionPlane)
    mid_r = (BEARING_OD + BEARING_ID) / 4.0
    draw_circle(sketch_channel, 0, 0, mid_r + 1.0)
    try:
        extrude(sketch_channel, 0, BEARING_WIDTH, 'cut')
    except:
        pass

    for z in [0, BEARING_WIDTH]:
        sketch_seal = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_seal, 0, 0, BEARING_OD - 0.5)
        try:
            ext_dir = 1 if z == 0 else -1
            extrude(sketch_seal, 0, 0.5, 'new_body', ext_dir)
        except:
            pass

    return comp


# ============================================================================
# 2204 BLDC 모터 마운트
# ============================================================================

def create_motor_mount(root_comp, wheel_index=0):
    """2204 BLDC 모터 마운팅 브래킷"""
    comp = create_comp(root_comp, f"MotorMount_W{wheel_index}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_plate = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_plate, 0, 0, 45.0, 45.0)
    extrude(sketch_plate, 0, 5.0, 'new_body')

    sketch_mbore = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_mbore, 0, 0, MOTOR_DIAMETER + CLEARANCE)
    try:
        extrude(sketch_mbore, 0, 8.0, 'cut')
    except:
        pass

    for hx in [-MOTOR_MOUNT_SPACING_X / 2.0, MOTOR_MOUNT_SPACING_X / 2.0]:
        for hy in [-MOTOR_MOUNT_SPACING_Y / 2.0, MOTOR_MOUNT_SPACING_Y / 2.0]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh, hx, hy, MOTOR_MOUNT_HOLE_DIA + 0.2)
            try:
                extrude(sketch_mh, 0, 10.0, 'cut')
            except:
                pass

    sketch_shaft = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_shaft, 0, 0, MOTOR_SHAFT_DIA + CLEARANCE)
    try:
        extrude(sketch_shaft, 0, 12.0, 'cut')
    except:
        pass

    for hx in [-17.0, 17.0]:
        for hy in [-17.0, 17.0]:
            sketch_bh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_bh, hx, hy, 4.0)
            try:
                extrude(sketch_bh, 0, 8.0, 'cut')
            except:
                pass

    sketch_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_cable, 20.0, 0, 5.0, 3.0)
    try:
        extrude(sketch_cable, 0, 8.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# V7: B-G431B-ESC1 모터 드라이버 마운트 / V7: B-G431B-ESC1 Motor Driver Mount
# ============================================================================

def create_bg431_wheel_mount(root_comp, wheel_index=0):
    """
    V8.5 추가: B-G431B-ESC1 모터 드라이버 마운트 (각 휠 허브 위치)
    V8.5 New: B-G431B-ESC1 motor driver mount at each wheel hub position

    SimpleFOC Mini → B-G431B-ESC1 교체 (33×33mm, 4×M3 코너, 15mm 높이)
    모터 소프트웨어 전류 제한 25A 반영, 방열 강화
    """
    comp = create_comp(root_comp, f"BG431_WheelMount_W{wheel_index}")
    if not comp:
        return None

    sketches = comp.sketches

    # --- 마운트 플레이트 / Mount plate ---
    sketch_plate = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_plate, 0, 0, BG431_WIDTH + 10.0, BG431_DEPTH + 10.0)
    extrude(sketch_plate, 0, 3.0, 'new_body')

    # --- 보드 포켓 / Board pocket ---
    sketch_pocket = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_pocket, 0, 0, BG431_WIDTH + CLEARANCE * 2, BG431_DEPTH + CLEARANCE * 2)
    try:
        extrude(sketch_pocket, 0, 2.0, 'cut')
    except:
        pass

    # --- M3 마운팅 홀 (4개 코너) / M3 mounting holes (4 corners) ---
    for hx in [-1, 1]:
        for hy in [-1, 1]:
            sketch_mh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_mh,
                        hx * (BG431_MOUNT_HOLE_SPACING / 2.0),
                        hy * (BG431_MOUNT_HOLE_SPACING / 2.0),
                        BG431_MOUNT_HOLE_DIA)
            try:
                extrude(sketch_mh, 0, 6.0, 'cut')
            except:
                pass

    # --- 열 패드 리세스 (25A 전류 제한 방열용) / Thermal pad recess ---
    # V7: B-G431B-ESC1은 SimpleFOC Mini보다 전류 처리량이 높아 방열 필수
    sketch_thermal = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_thermal, 0, 0, 20.0, 20.0)
    try:
        extrude(sketch_thermal, 0, 1.5, 'cut')
    except:
        pass

    # --- 모터 케이블 컷아웃 / Motor cable cutout ---
    sketch_motor_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_motor_cable, 0, -BG431_DEPTH / 2.0 - 2.0, 15.0, 5.0)
    try:
        extrude(sketch_motor_cable, 0, 10.0, 'cut')
    except:
        pass

    # --- 전원 케이블 컷아웃 / Power cable cutout ---
    sketch_power_cable = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_power_cable, BG431_WIDTH / 2.0 + 2.0, 5.0, 4.0, 6.0)
    try:
        extrude(sketch_power_cable, 0, 5.0, 'cut')
    except:
        pass

    # --- 엔코더/I2C 케이블 슬롯 / Encoder/I2C cable slot ---
    sketch_i2c = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_i2c, -BG431_WIDTH / 2.0 - 2.0, 5.0, 4.0, 6.0)
    try:
        extrude(sketch_i2c, 0, 5.0, 'cut')
    except:
        pass

    # --- 측면 스냅핏 리테이너 탭 (4개) / Side snap-fit retainer tabs ---
    for (tab_x, tab_y, tab_w, tab_h) in [
        (0, BG431_DEPTH / 2.0 + 2.0, 10.0, 3.0),
        (0, -(BG431_DEPTH / 2.0 + 2.0), 10.0, 3.0),
        (BG431_WIDTH / 2.0 + 2.0, 0, 3.0, 10.0),
        (-(BG431_WIDTH / 2.0 + 2.0), 0, 3.0, 10.0),
    ]:
        sketch_tab = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_tab, tab_x, tab_y, tab_w, tab_h)
        try:
            extrude(sketch_tab, 0, BG431_HEIGHT - 2.0, 'new_body')
        except:
            pass

    # --- 방열 필름 (25A 대응) / Thermal film (25A support) ---
    sketch_heatsink = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_heatsink, 0, 0, BG431_WIDTH - 4.0, BG431_DEPTH - 4.0)
    try:
        extrude(sketch_heatsink, 0, -0.5, 'new_body', -1)
    except:
        pass

    return comp


# ============================================================================
# 컴플라이언트 서스펜션 (TPU 플렉스처)
# ============================================================================

def create_compliant_suspension(root_comp, wheel_index=0):
    """간단 컴플라이언트 서스펜션 (3D 프린트 TPU 플렉스처)"""
    comp = create_comp(root_comp, f"CompliantSuspension_W{wheel_index}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_upper = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_upper, 0, 0, SUSPENSION_WIDTH + 20.0, SUSPENSION_WIDTH + 20.0)
    extrude(sketch_upper, 0, 4.0, 'new_body')

    sketch_lower = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_lower, 0, 0, SUSPENSION_WIDTH + 10.0, SUSPENSION_WIDTH + 10.0)
    try:
        extrude(sketch_lower, 0, 4.0, 'new_body')
    except:
        pass

    for arm_angle in [0, 90, 180, 270]:
        angle_rad = math.radians(arm_angle)
        arm_cx = SUSPENSION_ARM_LENGTH / 2.0 * math.cos(angle_rad)
        arm_cy = SUSPENSION_ARM_LENGTH / 2.0 * math.sin(angle_rad)

        sketch_arm = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_arm, arm_cx, arm_cy,
                  SUSPENSION_ARM_LENGTH, SUSPENSION_ARM_WIDTH)
        try:
            extrude(sketch_arm, 0, SUSPENSION_THICKNESS, 'new_body')
        except:
            pass

        hinge_x = arm_cx * 0.6
        hinge_y = arm_cy * 0.6
        sketch_hinge = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_hinge, hinge_x, hinge_y, 8.0, SUSPENSION_ARM_WIDTH - 2.0)
        try:
            extrude(sketch_hinge, 0, SUSPENSION_THICKNESS - 2.0, 'cut')
        except:
            pass

    for hx in [-12.0, 12.0]:
        for hy in [-12.0, 12.0]:
            sketch_umh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_umh, hx, hy, 3.2)
            try:
                extrude(sketch_umh, 0, 8.0, 'cut')
            except:
                pass

    for hx in [-8.0, 8.0]:
        for hy in [-8.0, 8.0]:
            sketch_lmh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_lmh, hx, hy, 3.2)
            try:
                extrude(sketch_lmh, 0, 8.0, 'cut')
            except:
                pass

    for stop_angle in [45, 135, 225, 315]:
        angle_rad = math.radians(stop_angle)
        sx = 10.0 * math.cos(angle_rad)
        sy = 10.0 * math.sin(angle_rad)
        sketch_stop = sketches.add(comp.xZConstructionPlane)
        draw_rect(sketch_stop, sx, sy, 5.0, 5.0)
        try:
            extrude(sketch_stop, 0, 6.0, 'new_body')
        except:
            pass

    return comp


# ============================================================================
# 퀵 릴리즈 휠 마운트
# ============================================================================

def create_quick_release(root_comp, wheel_index=0):
    """퀵 릴리즈 휠 마운트 (볼 락 핀, Tier 2 커넥터)"""
    comp = create_comp(root_comp, f"QuickRelease_W{wheel_index}")
    if not comp:
        return None

    sketches = comp.sketches

    sketch_block = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_block, 0, 0, 40.0, 40.0)
    extrude(sketch_block, 0, 25.0, 'new_body')

    sketch_pin = sketches.add(comp.xZConstructionPlane)
    draw_circle(sketch_pin, 0, 0, QUICK_RELEASE_PIN_DIA + CLEARANCE)
    try:
        extrude(sketch_pin, 0, QUICK_RELEASE_PIN_LENGTH + 5.0, 'cut')
    except:
        pass

    sketch_retainer = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_retainer, 0, 0, 12.0, 3.0)
    try:
        extrude(sketch_retainer, 0, 5.0, 'cut')
    except:
        pass

    for i in range(3):
        angle_rad = math.radians(i * 120.0)
        gx = (QUICK_RELEASE_PIN_DIA / 2.0 + 0.5) * math.cos(angle_rad)
        gy = (QUICK_RELEASE_PIN_DIA / 2.0 + 0.5) * math.sin(angle_rad)
        sketch_groove = sketches.add(comp.xZConstructionPlane)
        draw_circle(sketch_groove, gx, gy, 2.0)
        try:
            extrude(sketch_groove, 0, 4.0, 'cut')
        except:
            pass

    for hx in [-15.0, 15.0]:
        for hy in [-15.0, 15.0]:
            sketch_bh = sketches.add(comp.xZConstructionPlane)
            draw_circle(sketch_bh, hx, hy, 4.0)
            try:
                extrude(sketch_bh, 0, 8.0, 'cut')
            except:
                pass

    sketch_dcut = sketches.add(comp.xZConstructionPlane)
    draw_rect(sketch_dcut, MOTOR_SHAFT_DIA / 2.0 - 0.5, 0, 1.0, 10.0)
    try:
        extrude(sketch_dcut, 0, 3.0, 'cut')
    except:
        pass

    return comp


# ============================================================================
# 완전 휠 어셈블리 / Complete Wheel Assembly
# ============================================================================

def create_wheel_assembly(root_comp, wheel_index=0, position_name="FL"):
    """
    완전 메카넘 휠 어셈블리 생성 (V7: B-G431B-ESC1 포함)
    Create complete mecanum wheel assembly (V7: with B-G431B-ESC1)
    """
    wheel_name = f"Wheel_{position_name}"
    comp = create_comp(root_comp, wheel_name)
    if not comp:
        return None

    # 서브 컴포넌트 생성
    create_aluminum_hub(comp, wheel_index)
    create_all_rollers(comp, wheel_index)
    create_motor_mount(comp, wheel_index)
    create_compliant_suspension(comp, wheel_index)
    create_quick_release(comp, wheel_index)

    # V7: B-G431B-ESC1 모터 드라이버 마운트 (SimpleFOC Mini 교체)
    create_bg431_wheel_mount(comp, wheel_index)

    # 베어링 모델 (참조용)
    create_bearing(comp, f"Bearing_W{wheel_index}")

    return comp


# ============================================================================
# 4휠 메카넘 어셈블리
# ============================================================================

def create_4wheel_mecanum(root_comp):
    """4휠 메카넘 드라이브 어셈블리"""
    positions = ["FL", "FR", "RL", "RR"]
    for i, pos in enumerate(positions):
        create_wheel_assembly(root_comp, i, pos)
    return root_comp


# ============================================================================
# 메인 실행 / Main Execution
# ============================================================================

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct
        if not design:
            ui.messageBox('활성 디자인이 없습니다 / No active design')
            return
        root_comp = design.rootComponent

        ui.messageBox('V7: 4휠 메카넘 어셈블리 생성 중...\nCreating V7: 4-wheel mecanum assembly...')
        create_4wheel_mecanum(root_comp)

        ui.messageBox(
            '지훈 로봇 V8.5 휠 어셈블리 생성 완료!\n'
            'Jihun Robot V8.5 Wheel Assembly Complete!\n\n'
            f'메카넘 휠: {WHEEL_DIAMETER}mm (4x)\n'
            f'알루미늄 허브: {HUB_DIAMETER}mm\n'
            f'TPU 듀얼 로우 롤러: {ROLLERS_PER_WHEEL}x{ROLLER_ROWS}\n'
            f'베어링: MR105ZZ\n'
            f'모터: 2204 BLDC\n'
            f'V7: B-G431B-ESC1 드라이버 (SimpleFOC Mini 교체)\n'
            f'  - {BG431_WIDTH}×{BG431_DEPTH}mm, 4×M3 코너\n'
            f'  - 열 패드 리세스 포함 (방열)\n'
            f'  - 전류 제한 {MOTOR_CURRENT_LIMIT}A\n'
            f'서스펜션: TPU 플렉스처 ({SUSPENSION_TRAVEL}mm)\n'
            '퀵 릴리즈: 볼 락 핀 (Tier 2)'
        )
    except:
        if ui:
            ui.messageBox('실패:\nFailed:\n{}'.format(traceback.format_exc()))


def stop(context):
    pass
