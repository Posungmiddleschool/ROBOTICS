"""
Jihun Robot V8.5 - Fusion 360 Auto-Assembly Script
==================================================
Automates the complete assembly pipeline:
  1. Import all sub-modules (body, legs, wheels, gripper, camera, tray)
  2. Build component hierarchy
  3. Apply joints (rigid, revolute, slider)
  4. Generate Bill of Materials (BOM)
  5. Export STL files for 3D printing (oriented for best print quality)
  6. Export STEP files for manufacturing
  7. Create drawing sheets with dimensions

V8.5 Changes from V6:
  - Version 7.0.0 (was 6.0.0)
  - B-G431B-ESC1 driver board mounts (6x: 4 wheel + 2 leg lift)
  - CC/CV Buck charging module bays (2x: USB-C PD 20V→14.6V)
  - 40mm cooling fan mounts (2x: each Jetson SoC)
  - MKS XDRIVE Mini CAN driver mounts (4x: 2 leg pitch + 2 spare)
  - Jetson Orin NX 16GB (8GB→16GB upgrade)
  - Motor software current limit 25A
  - All V6→V8.5 references updated

Usage:
  Open Fusion 360 → Scripts and Add-Ins → Run generate_all.py

Author  : Jihun Robot Project
Version : 7.0.0
License : MIT
"""

import adsk.core
import adsk.fusion
import traceback
import os
import math
import json
from datetime import datetime

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
PROJECT_NAME = "JihunRobot_V7"
EXPORT_ROOT = os.path.join(os.path.expanduser("~"), "JihunRobot_V7", "exports")
STL_REFINEMENT = "high"          # low | medium | high
STEP_VERSION = 214               # STEP AP214 for color support

# Module file paths (relative to this script's directory)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MODULE_FILES = {
    "snap_fit_library": os.path.join(SCRIPT_DIR, "snap_fit_library.py"),
    "body_main":        os.path.join(SCRIPT_DIR, "body_main.py"),
    "leg_module":       os.path.join(SCRIPT_DIR, "leg_module.py"),
    "wheel_assembly":   os.path.join(SCRIPT_DIR, "wheel_assembly.py"),
    "gripper_hand":     os.path.join(SCRIPT_DIR, "gripper_hand.py"),
    "camera_mount":     os.path.join(SCRIPT_DIR, "camera_mount.py"),
    "internal_tray":    os.path.join(SCRIPT_DIR, "internal_tray.py"),
}

# Joint definitions: (parent_comp, child_comp, joint_type, offset_vector)
# joint_type: "rigid" | "revolute" | "slider"
JOINT_DEFS = [
    # Structural – body is the root
    ("Body_Main",        "Internal_Tray",    "rigid",    adsk.core.Vector3D.create(0, 0, 5)),
    ("Body_Main",        "Camera_Mount",     "rigid",    adsk.core.Vector3D.create(0, 65, 30)),
    ("Body_Main",        "Gripper_Hand_L",   "rigid",    adsk.core.Vector3D.create(-45, 90, 0)),
    ("Body_Main",        "Gripper_Hand_R",   "rigid",    adsk.core.Vector3D.create(45, 90, 0)),

    # Legs – slider for telescoping extension
    ("Body_Main",        "Leg_FL",           "slider",   adsk.core.Vector3D.create(-55, -10, -60)),
    ("Body_Main",        "Leg_FR",           "slider",   adsk.core.Vector3D.create(55, -10, -60)),
    ("Body_Main",        "Leg_RL",           "slider",   adsk.core.Vector3D.create(-55, -70, -60)),
    ("Body_Main",        "Leg_RL",           "slider",   adsk.core.Vector3D.create(55, -70, -60)),

    # Wheels – revolute for rotation
    ("Leg_FL",           "Wheel_FL",         "revolute", adsk.core.Vector3D.create(-20, 0, -35)),
    ("Leg_FR",           "Wheel_FR",         "revolute", adsk.core.Vector3D.create(20, 0, -35)),
    ("Leg_RL",           "Wheel_RL",         "revolute", adsk.core.Vector3D.create(-20, 0, -35)),
    ("Leg_RR",           "Wheel_RR",         "revolute", adsk.core.Vector3D.create(20, 0, -35)),

    # V7: CC/CV Buck module bays (rigid, near battery compartment)
    ("Body_Main",        "BuckCC_Bay_V7",    "rigid",    adsk.core.Vector3D.create(0, -70, 40)),

    # V7: Fan mounts (rigid, above each Jetson)
    ("Body_Main",        "FanMount_1_V7",    "rigid",    adsk.core.Vector3D.create(-80, 30, 50)),
    ("Body_Main",        "FanMount_2_V7",    "rigid",    adsk.core.Vector3D.create(80, 30, 50)),
]

# Print orientation overrides per component
PRINT_ORIENTATION = {
    "Body_Main":      "Z",
    "Internal_Tray":  "Z",
    "Camera_Mount":   "X",
    "Gripper_Fin_L":  "Y",
    "Gripper_Fin_R":  "Y",
    "Gripper_Base":   "Z",
    "Leg_Inner_FL":   "X",
    "Leg_Inner_FR":   "X",
    "Leg_Inner_RL":   "X",
    "Leg_Inner_RR":   "X",
    "Leg_Outer_FL":   "X",
    "Leg_Outer_FR":   "X",
    "Leg_Outer_RL":   "X",
    "Leg_Outer_RR":   "X",
    "Wheel_FL":       "X",
    "Wheel_FR":       "X",
    "Wheel_RL":       "X",
    "Wheel_RR":       "X",
    "Snap_Clips":     "Z",
    # V8.5 new components
    "BG431_Mount":    "Z",
    "BG431_WheelMount": "Z",
    "BG431_LegLift":  "Z",
    "BuckCC_Bay_V7":  "Z",
    "BuckCC_Mount":   "Z",
    "CoolingFan_V7":  "Z",
    "XDrive_Mount":   "Z",
}

# BOM metadata — V8.5 updated
BOM_METADATA = {
    "Body_Main":      {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "V7: Main chassis shell, fan mount holes, CC/CV bay"},
    "Internal_Tray":  {"material": "PETG",    "qty": 1, "infill": "25%", "notes": "V7: B-G431B-ESC1 x6, Buck CC x2, Fan x2, XDrive x4"},
    "Camera_Mount":   {"material": "PETG",    "qty": 1, "infill": "30%", "notes": "OAK-D Pro bracket"},
    "Gripper_Fin_L":  {"material": "TPU-95A", "qty": 3, "infill": "20%", "notes": "Fin Ray finger left"},
    "Gripper_Fin_R":  {"material": "TPU-95A", "qty": 3, "infill": "20%", "notes": "Fin Ray finger right"},
    "Gripper_Base":   {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "Gripper servo mount"},
    "Leg_Inner_FL":  {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "V7: Inner leg + B-G431B-ESC1 lift mount"},
    "Leg_Inner_FR":  {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "V7: Inner leg + B-G431B-ESC1 lift mount"},
    "Leg_Inner_RL":  {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "V7: Inner leg + B-G431B-ESC1 lift mount"},
    "Leg_Inner_RR":  {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "V7: Inner leg + B-G431B-ESC1 lift mount"},
    "Leg_Outer_FL":  {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "Outer leg housing"},
    "Leg_Outer_FR":  {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "Outer leg housing"},
    "Leg_Outer_RL":  {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "Outer leg housing"},
    "Leg_Outer_RR":  {"material": "PETG-CF", "qty": 1, "infill": "40%", "notes": "Outer leg housing"},
    "Wheel_FL":       {"material": "TPU-95A", "qty": 1, "infill": "15%", "notes": "V7: Tire + B-G431B-ESC1 mount"},
    "Wheel_FR":       {"material": "TPU-95A", "qty": 1, "infill": "15%", "notes": "V7: Tire + B-G431B-ESC1 mount"},
    "Wheel_RL":       {"material": "TPU-95A", "qty": 1, "infill": "15%", "notes": "V7: Tire + B-G431B-ESC1 mount"},
    "Wheel_RR":       {"material": "TPU-95A", "qty": 1, "infill": "15%", "notes": "V7: Tire + B-G431B-ESC1 mount"},
    "Snap_Clips":     {"material": "PETG",    "qty": 8, "infill": "35%", "notes": "V7: Snap-fit clips x8 + B-G431B-ESC1 snaps"},
    # V8.5 new BOM entries
    "BG431_Driver":   {"material": "PCB",     "qty": 6, "infill": "N/A", "notes": "V7: B-G431B-ESC1 motor driver (4 wheel + 2 leg lift)"},
    "Fan_40mm":       {"material": "Assembly", "qty": 2, "infill": "N/A", "notes": "V7: 40mm cooling fan (Jetson SoC direct)"},
    "BuckCC_Module":  {"material": "PCB",     "qty": 2, "infill": "N/A", "notes": "V7: XL4015 CC/CV Buck (USB-C PD 20V→14.6V)"},
    "XDrive_Mini":    {"material": "PCB",     "qty": 4, "infill": "N/A", "notes": "V7: MKS XDRIVE Mini CAN driver (2 leg + 2 spare)"},
    "Thermal_Pad":    {"material": "Silicone", "qty": 8, "infill": "N/A", "notes": "V7: Thermal pad (B-G431B + Jetson SoC)"},
}


# ===========================================================================
# Utility helpers
# ===========================================================================

def _msg(ui: adsk.core.UserInterface, text: str):
    """Print to Fusion 360 text commands palette."""
    ui.palettes.itemById("TextCommands").text = f"[JihunV7] {text}"


def _ensure_folder(path: str) -> str:
    """Create directory if it doesn't exist."""
    os.makedirs(path, exist_ok=True)
    return path


def _rotation_for_orientation(orient: str) -> adsk.core.Matrix3D:
    """Return a rotation matrix that re-orients a body for 3D printing."""
    mat = adsk.core.Matrix3D.create()
    if orient == "X":
        mat.setToRotation(math.pi / 2, adsk.core.Vector3D.create(0, 1, 0),
                          adsk.core.Point3D.create(0, 0, 0))
    elif orient == "Y":
        mat.setToRotation(math.pi / 2, adsk.core.Vector3D.create(1, 0, 0),
                          adsk.core.Point3D.create(0, 0, 0))
    # "Z" → identity (no rotation needed)
    return mat


def _get_or_create_component(parent: adsk.fusion.Component, name: str) -> adsk.fusion.Component:
    """Return existing child component or create a new one."""
    for occ in parent.occurrences:
        if occ.component.name == name:
            return occ.component
    new_occ = parent.occurrences.addNewComponent(adsk.core.Matrix3D.create())
    new_occ.component.name = name
    return new_occ.component


def _find_occurrence(root: adsk.fusion.Component, name: str) -> adsk.fusion.Occurrence:
    """Find an occurrence by component name under root."""
    for occ in root.allOccurrences:
        if occ.component.name == name:
            return occ
    return None


# ===========================================================================
# Module import – dynamically load sub-module scripts
# ===========================================================================

def import_modules(app: adsk.core.Application):
    """
    Import all sub-module scripts that generate individual parts.
    Each module must expose a `build(component)` function that
    creates bodies inside the given component.
    """
    ui = app.userInterface
    imported = {}

    for mod_name, mod_path in MODULE_FILES.items():
        if not os.path.isfile(mod_path):
            _msg(ui, f"WARNING: Module not found – {mod_name} at {mod_path}")
            continue

        try:
            import importlib.util as ilu
            spec = ilu.spec_from_file_location(mod_name, mod_path)
            mod = ilu.module_from_spec(spec)
            spec.loader.exec_module(mod)
            imported[mod_name] = mod
            _msg(ui, f"Loaded module: {mod_name}")
        except Exception as e:
            _msg(ui, f"ERROR loading {mod_name}: {str(e)}")

    return imported


# ===========================================================================
# Assembly builder
# ===========================================================================

def build_hierarchy(design: adsk.fusion.Design, modules: dict):
    """
    Create the full component tree and invoke each module's build().

    Hierarchy (V7):
        JihunRobot_V8.5 (root)
        ├── Body_Main
        │   ├── Internal_Tray
        │   │   ├── BG431_Mount_[0-5]     (V7: B-G431B-ESC1 x6)
        │   │   ├── BuckCC_Mount_[0-1]     (V7: CC/CV Buck x2)
        │   │   ├── XDrive_Mount_[0-3]     (V7: MKS XDRIVE Mini x4)
        │   │   └── CoolingFan_[0-1]        (V7: 40mm fan x2)
        │   ├── Camera_Mount
        │   ├── Snap_Clips
        │   ├── Gripper_Hand_L
        │   │   ├── Gripper_Base
        │   │   ├── Gripper_Fin_L
        │   │   └── Gripper_Fin_R
        │   ├── Gripper_Hand_R
        │   │   ├── Gripper_Base
        │   │   ├── Gripper_Fin_L
        │   │   └── Gripper_Fin_R
        │   ├── BuckCC_Bay_V8.5              (V7: CC/CV Buck charging bay)
        │   ├── FanMount_1_V8.5              (V7: 40mm cooling fan, Jetson #1)
        │   └── FanMount_2_V8.5              (V7: 40mm cooling fan, Jetson #2)
        ├── Leg_FL
        │   ├── Leg_Outer_FL
        │   ├── Leg_Inner_FL
        │   ├── BG431_LegLift_Left         (V7: B-G431B-ESC1 leg lift)
        │   └── Wheel_FL
        │       └── BG431_WheelMount_FL     (V7: B-G431B-ESC1 wheel driver)
        ├── Leg_FR  (same structure)
        ├── Leg_RL  (same structure)
        └── Leg_RR  (same structure)
    """
    ui = design.parentApplication.userInterface
    root = design.rootComponent

    # Root component naming
    root.name = PROJECT_NAME

    # --- Body main ---
    body_comp = _get_or_create_component(root, "Body_Main")
    if "body_main" in modules:
        try:
            modules["body_main"].build(body_comp)
            _msg(ui, "Built Body_Main geometry")
        except Exception as e:
            _msg(ui, f"body_main build error: {e}")

    # --- Snap-fit clips (inside body) ---
    clips_comp = _get_or_create_component(body_comp, "Snap_Clips")
    if "snap_fit_library" in modules:
        try:
            modules["snap_fit_library"].build(clips_comp)
            _msg(ui, "Built Snap_Clips geometry (V7: + B-G431B-ESC1 snap mount)")
        except Exception as e:
            _msg(ui, f"snap_fit_library build error: {e}")

    # --- Internal tray ---
    tray_comp = _get_or_create_component(body_comp, "Internal_Tray")
    if "internal_tray" in modules:
        try:
            modules["internal_tray"].build(tray_comp)
            _msg(ui, "Built Internal_Tray geometry (V7: + BG431/BuckCC/Fan/XDrive)")
        except Exception as e:
            _msg(ui, f"internal_tray build error: {e}")

    # --- Camera mount ---
    cam_comp = _get_or_create_component(body_comp, "Camera_Mount")
    if "camera_mount" in modules:
        try:
            modules["camera_mount"].build(cam_comp)
            _msg(ui, "Built Camera_Mount geometry")
        except Exception as e:
            _msg(ui, f"camera_mount build error: {e}")

    # --- Gripper hands (L / R) ---
    for side, suffix in [("Left", "L"), ("Right", "R")]:
        gripper_parent = _get_or_create_component(body_comp, f"Gripper_Hand_{suffix}")
        gripper_base = _get_or_create_component(gripper_parent, "Gripper_Base")
        gripper_fin_l = _get_or_create_component(gripper_parent, "Gripper_Fin_L")
        gripper_fin_r = _get_or_create_component(gripper_parent, "Gripper_Fin_R")

        if "gripper_hand" in modules:
            try:
                modules["gripper_hand"].build(gripper_parent, side=side)
                _msg(ui, f"Built Gripper_Hand_{suffix} geometry")
            except Exception as e:
                _msg(ui, f"gripper_hand build error ({suffix}): {e}")

    # --- Legs & wheels (4 corners) ---
    corners = ["FL", "FR", "RL", "RR"]
    for corner in corners:
        leg_comp = _get_or_create_component(root, f"Leg_{corner}")
        outer_leg = _get_or_create_component(leg_comp, f"Leg_Outer_{corner}")
        inner_leg = _get_or_create_component(leg_comp, f"Leg_Inner_{corner}")
        wheel_comp = _get_or_create_component(leg_comp, f"Wheel_{corner}")

        if "leg_module" in modules:
            try:
                modules["leg_module"].build(leg_comp, corner=corner)
                _msg(ui, f"Built Leg_{corner} geometry (V7: + B-G431B-ESC1 leg lift)")
            except Exception as e:
                _msg(ui, f"leg_module build error ({corner}): {e}")

        if "wheel_assembly" in modules:
            try:
                modules["wheel_assembly"].build(wheel_comp, corner=corner)
                _msg(ui, f"Built Wheel_{corner} geometry (V7: + B-G431B-ESC1 driver)")
            except Exception as e:
                _msg(ui, f"wheel_assembly build error ({corner}): {e}")

    _msg(ui, "V8.5 Component hierarchy built successfully")
    return root


# ===========================================================================
# Joint creation
# ===========================================================================

def apply_joints(design: adsk.fusion.Design):
    """
    Create all joints according to JOINT_DEFS configuration.
    """
    ui = design.parentApplication.userInterface
    root = design.rootComponent

    for parent_name, child_name, jtype, offset in JOINT_DEFS:
        parent_occ = _find_occurrence(root, parent_name)
        child_occ = _find_occurrence(root, child_name)

        if parent_occ is None or child_occ is None:
            _msg(ui, f"SKIP joint {parent_name}↔{child_name} – occurrence not found")
            continue

        parent_point = adsk.core.Point3D.create(0, 0, 0)
        child_point = adsk.core.Point3D.create(
            offset.x, offset.y, offset.z
        )

        geo_one = adsk.fusion.JointGeometry.createByPoint(
            parent_occ, parent_point,
            adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )
        geo_two = adsk.fusion.JointGeometry.createByPoint(
            child_occ, child_point,
            adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )

        joint_input = root.joints.createInput(geo_one, geo_two)

        if jtype == "rigid":
            joint_input.setAsRigidJoint()

        elif jtype == "revolute":
            axis = adsk.core.Vector3D.create(1, 0, 0)
            joint_input.setAsRevoluteJoint(axis)

        elif jtype == "slider":
            slide_dir = adsk.core.Vector3D.create(0, 0, 1)
            joint_input.setAsSlideJoint(slide_dir, 0, 50)

        try:
            joint = root.joints.add(joint_input)
            joint.name = f"{parent_name}_to_{child_name}_{jtype}"
            _msg(ui, f"Joint: {parent_name} ↔ {child_name} ({jtype})")
        except Exception as e:
            _msg(ui, f"Joint error {parent_name}↔{child_name}: {e}")

    _msg(ui, "All joints applied")


# ===========================================================================
# Bill of Materials (BOM)
# ===========================================================================

def generate_bom(design: adsk.fusion.Design) -> str:
    """Generate BOM as JSON string."""
    ui = design.parentApplication.userInterface
    bom_items = []

    for comp_name, meta in BOM_METADATA.items():
        volume_mm3 = 0.0
        for occ in design.rootComponent.allOccurrences:
            if occ.component.name == comp_name:
                body = occ.component.bRepBodies.item(0)
                if body:
                    volume_mm3 = body.volume
                break

        volume_cm3 = volume_mm3
        mass_est_g = 0.0
        density_map = {
            "PETG-CF": 1.27, "PETG": 1.27, "TPU-95A": 1.12,
            "PCB": 1.80, "Assembly": 1.50, "Silicone": 1.20,
        }
        mat = meta.get("material", "PETG")
        density = density_map.get(mat, 1.27)
        mass_est_g = volume_cm3 * density

        bom_items.append({
            "part_name":     comp_name,
            "material":      mat,
            "quantity":      meta.get("qty", 1),
            "infill":        meta.get("infill", "25%"),
            "volume_cm3":    round(volume_cm3, 2),
            "mass_est_g":    round(mass_est_g, 2),
            "notes":         meta.get("notes", ""),
        })

    bom = {
        "project":    PROJECT_NAME,
        "version":    "7.0.0",
        "generated":  datetime.now().isoformat(),
        "total_parts": sum(i["quantity"] for i in bom_items),
        "v7_new_parts": {
            "bg431_esc_drivers": 6,
            "cooling_fans": 2,
            "buck_cc_modules": 2,
            "xdrive_mini": 4,
            "thermal_pads": 8,
        },
        "items":      bom_items,
    }

    bom_json = json.dumps(bom, indent=2, ensure_ascii=False)

    bom_dir = _ensure_folder(os.path.join(EXPORT_ROOT, "bom"))
    bom_path = os.path.join(bom_dir, f"{PROJECT_NAME}_BOM.json")
    with open(bom_path, "w", encoding="utf-8") as f:
        f.write(bom_json)

    _msg(ui, f"V8.5 BOM saved → {bom_path}")
    return bom_json


# ===========================================================================
# STL Export
# ===========================================================================

def export_stl(design: adsk.fusion.Design):
    """Export every body as STL with correct print orientation."""
    ui = design.parentApplication.userInterface
    stl_dir = _ensure_folder(os.path.join(EXPORT_ROOT, "stl"))

    refinement_map = {"low": 0, "medium": 1, "high": 2}
    ref_value = refinement_map.get(STL_REFINEMENT, 2)

    export_mgr = design.exportManager
    root = design.rootComponent
    exported_count = 0

    for occ in root.allOccurrences:
        comp = occ.component
        for body_idx in range(comp.bRepBodies.count):
            body = comp.bRepBodies.item(body_idx)
            body_name = comp.name.replace(" ", "_")

            orient = PRINT_ORIENTATION.get(comp.name, "Z")
            rot_matrix = _rotation_for_orientation(orient)

            original_transform = occ.transform2.copy()
            try:
                new_transform = original_transform.copy()
                new_transform.transformBy(rot_matrix)
                occ.transform2 = new_transform

                stl_path = os.path.join(stl_dir, f"{body_name}.stl")
                stl_opts = export_mgr.createSTLExportOptions(body, stl_path)
                stl_opts.refinement = ref_value
                stl_opts.isBinaryFormat = True

                if export_mgr.execute(stl_opts):
                    _msg(ui, f"STL → {body_name}.stl ({orient}-oriented)")
                    exported_count += 1
                else:
                    _msg(ui, f"STL export FAILED: {body_name}")

            finally:
                occ.transform2 = original_transform

    _msg(ui, f"STL export complete: {exported_count} files")


# ===========================================================================
# STEP Export
# ===========================================================================

def export_step(design: adsk.fusion.Design):
    """Export full assembly + per-component STEP."""
    ui = design.parentApplication.userInterface
    step_dir = _ensure_folder(os.path.join(EXPORT_ROOT, "step"))

    export_mgr = design.exportManager
    root = design.rootComponent

    # Full assembly STEP
    asm_path = os.path.join(step_dir, f"{PROJECT_NAME}_Assembly.step")
    step_opts = export_mgr.createSTEPExportOptions(asm_path, root)
    step_opts.version = STEP_VERSION

    if export_mgr.execute(step_opts):
        _msg(ui, f"Assembly STEP → {asm_path}")
    else:
        _msg(ui, "Assembly STEP export FAILED")

    # Per-component STEP
    exported = 0
    for occ in root.allOccurrences:
        comp = occ.component
        if comp.bRepBodies.count == 0:
            continue

        comp_name = comp.name.replace(" ", "_")
        comp_path = os.path.join(step_dir, f"{comp_name}.step")
        comp_opts = export_mgr.createSTEPExportOptions(comp_path, comp)
        comp_opts.version = STEP_VERSION

        if export_mgr.execute(comp_opts):
            _msg(ui, f"STEP → {comp_name}.step")
            exported += 1

    _msg(ui, f"STEP export complete: 1 assembly + {exported} components")


# ===========================================================================
# Drawing sheets
# ===========================================================================

def create_drawings(design: adsk.fusion.Design):
    """Create drawing sheets."""
    ui = design.parentApplication.userInterface
    draw_dir = _ensure_folder(os.path.join(EXPORT_ROOT, "drawings"))

    try:
        drawing_doc = app.documents.add(adsk.core.DocumentTypes.FusionDrawingDocumentType)
        drawing = drawing_doc.drawing

        sheet = drawing.sheets.item(0)
        sheet.name = "Assembly Overview"
        sheet.activate()

        base_pos = adsk.core.Point3D.create(10, 10)
        base_view_input = drawing.views.createBaseViewInput(
            design,
            adsk.fusion.DraftingViewScale.fromScale(0.5),
            base_pos,
            adsk.fusion.ViewOrientations.IsometricTopLeftViewOrientation,
            adsk.fusion.DrawingViewStyles.ShadedDrawingStyle,
        )
        base_view = sheet.views.add(base_view_input)
        _msg(ui, "Drawing: V8.5 Assembly overview placed")

        root = design.rootComponent
        sheet_idx = 1
        for occ in root.allOccurrences:
            comp = occ.component
            if comp.bRepBodies.count == 0:
                continue

            if sheet_idx >= drawing.sheets.count:
                drawing.sheets.add()
            detail_sheet = drawing.sheets.item(sheet_idx)
            detail_sheet.name = comp.name
            detail_sheet.activate()

            comp_pos = adsk.core.Point3D.create(10, 10)
            comp_view_input = drawing.views.createBaseViewInput(
                design,
                adsk.fusion.DraftingViewScale.fromScale(1.0),
                comp_pos,
                adsk.fusion.ViewOrientations.FrontViewOrientation,
                adsk.fusion.DrawingViewStyles.HiddenLineDrawingStyle,
            )
            comp_view = detail_sheet.views.add(comp_view_input)

            if comp.bRepBodies.count > 0:
                bbox = comp.bRepBodies.item(0).boundingBox
                _msg(ui, f"Drawing: {comp.name} – "
                          f"{bbox.minPoint.x:.1f}×{bbox.minPoint.y:.1f}×{bbox.minPoint.z:.1f} "
                          f"to {bbox.maxPoint.x:.1f}×{bbox.maxPoint.y:.1f}×{bbox.maxPoint.z:.1f}")

            sheet_idx += 1

        pdf_path = os.path.join(draw_dir, f"{PROJECT_NAME}_Drawings.pdf")
        try:
            drawing_doc.saveAs(pdf_path)
            _msg(ui, f"Drawings PDF → {pdf_path}")
        except Exception as e:
            _msg(ui, f"PDF export note: {e}")

    except Exception as e:
        _msg(ui, f"Drawing step skipped (non-critical): {e}")

    _msg(ui, "Drawing creation complete")


# ===========================================================================
# Main entry point
# ===========================================================================

app = None
_ui = None


def run(context: dict):
    """Entry point for Fusion 360 script execution."""
    global app, _ui
    app = adsk.core.Application.get()
    _ui = app.userInterface

    try:
        _msg(_ui, "========== Jihun Robot V8.5 – Auto-Assembly START ==========")

        product = app.activeProduct
        if not product or not isinstance(product, adsk.fusion.Design):
            _msg(_ui, "ERROR: No active Fusion design – open or create one first.")
            return

        design = product

        # Step 1: Import sub-modules
        _msg(_ui, "Step 1/7 – Importing modules …")
        modules = import_modules(app)

        # Step 2: Build component hierarchy
        _msg(_ui, "Step 2/7 – Building V8.5 component hierarchy …")
        build_hierarchy(design, modules)

        # Step 3: Apply joints
        _msg(_ui, "Step 3/7 – Applying joints …")
        apply_joints(design)

        # Step 4: Generate BOM
        _msg(_ui, "Step 4/7 – Generating V8.5 Bill of Materials …")
        generate_bom(design)

        # Step 5: Export STL
        _msg(_ui, "Step 5/7 – Exporting STL files …")
        export_stl(design)

        # Step 6: Export STEP
        _msg(_ui, "Step 6/7 – Exporting STEP files …")
        export_step(design)

        # Step 7: Create drawings
        _msg(_ui, "Step 7/7 – Creating drawing sheets …")
        try:
            create_drawings(design)
        except Exception as e:
            _msg(_ui, f"Drawing step skipped (non-critical): {e}")

        _msg(_ui, "========== Jihun Robot V8.5 – Auto-Assembly COMPLETE ✅ ==========")
        _ui.messageBox(
            "Jihun Robot V8.5 assembly complete!\n\n"
            "V8.5 New Features:\n"
            "  • B-G431B-ESC1 motor drivers ×6 (4 wheel + 2 leg lift)\n"
            "  • CC/CV Buck charging modules ×2 (USB-C PD→14.6V)\n"
            "  • 40mm cooling fans ×2 (Jetson SoC direct)\n"
            "  • MKS XDRIVE Mini CAN drivers ×4 (2 leg + 2 spare)\n"
            "  • Jetson Orin NX 16GB (8GB→16GB upgrade)\n"
            "  • Motor current limit 25A\n\n"
            "Generated:\n"
            "  • Component hierarchy with joints\n"
            "  • BOM (JSON)\n"
            "  • STL files (print-oriented)\n"
            "  • STEP files (AP214)\n"
            "  • Drawing sheets\n\n"
            f"Export root: {EXPORT_ROOT}",
            "Jihun Robot V8.5 – Done"
        )

    except Exception:
        _ui.messageBox(
            "Assembly script failed:\n\n" + traceback.format_exc(),
            "Jihun Robot V8.5 – Error"
        )


def stop(context: dict):
    """Cleanup when script is stopped."""
    global app, _ui
    if _ui:
        _msg(_ui, "Jihun Robot V8.5 script stopped.")
    app = None
    _ui = None
