#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 내부 트레이 모듈 / Internal Tray Module
=========================================================

Jetson, ESP32, 배터리, 전원 모듈을 수납하는 내부 트레이 설계
납땜 없이 조립 가능한 구조 — 인서트 너트 + 볼트 체결

V8.5 변경사항:
  - 납땜 없음 설계 규칙 검증 추가 (SolderFreeConfig 연동)
  - 케이블 통로 곡률 반경 검증 (PDF #33)
  - 방열 구멍 필수 검증 (PDF #32)
  - 안테나 신호 경로 검증 (PDF #34)
  - 버튼 스트로크 계산 검증 (PDF #35)
  - 최종 조립 나사 진입로 검증 (PDF #50)

버전: V8.5
라이선스: MIT
"""

import adsk.core
import adsk.fusion360
import traceback


def build(root_comp, config=None):
    """
    내부 트레이 빌드 / Build internal tray
    
    Args:
        root_comp: Fusion 360 루트 컴포넌트
        config: 하드웨어 설정 (선택적)
    
    Returns:
        생성된 컴포넌트
    """
    app = adsk.core.Application.get()
    ui = app.userInterface
    
    try:
        # 내부 트레이 컴포넌트 생성
        tray_occ = root_comp.occurrences.addNewComponent(
            adsk.core.Matrix3D.create()
        )
        tray_comp = tray_occ.component
        tray_comp.name = "Internal_Tray_V84"
        
        sketches = tray_comp.sketches
        features = tray_comp.features
        
        # 트레이 기본 치수 (body_main.py와 호환)
        tray_length = 460  # mm (본체 내부 길이)
        tray_width = 300   # mm (본체 내부 폭)
        tray_height = 15   # mm (트레이 높이)
        wall_thickness = 3  # mm
        
        # --- 상판 스케치 ---
        xy_plane = tray_comp.xYConstructionPlane
        top_sketch = sketches.add(xy_plane)
        
        # 상판 사각형
        lines = top_sketch.sketchCurves.sketchLines
        rect = lines.addCenterPointRectangle(
            adsk.core.Point3D.create(0, 0, 0),
            adsk.core.Point3D.create(tray_length/2, tray_width/2, 0)
        )
        
        # --- Jetson 마운트 홀 (2개) ---
        jetson_hole_positions = [
            adsk.core.Point3D.create(-80, -50, 0),
            adsk.core.Point3D.create(-80, 50, 0),
            adsk.core.Point3D.create(80, -50, 0),
            adsk.core.Point3D.create(80, 50, 0),
        ]
        for pos in jetson_hole_positions:
            circles = top_sketch.sketchCurves.sketchCircles
            circles.addByCenterRadius(pos, 1.5)  # M3 bolt hole
        
        # --- ESP32 마운트 홀 ---
        esp32_pos = adsk.core.Point3D.create(150, -80, 0)
        circles = top_sketch.sketchCurves.sketchCircles
        circles.addByCenterRadius(esp32_pos, 1.5)
        
        # --- MCP2515 CAN 마운트 홀 ---
        can_pos = adsk.core.Point3D.create(150, 80, 0)
        circles.addByCenterRadius(can_pos, 1.5)
        
        # --- 방열 구멍 (PDF #32 필수) ---
        # 10x6 그리드 방열 구멍
        vent_rows = 6
        vent_cols = 10
        vent_spacing_x = 30  # mm
        vent_spacing_y = 20  # mm
        vent_start_x = -120
        vent_start_y = -50
        
        for row in range(vent_rows):
            for col in range(vent_cols):
                x = vent_start_x + col * vent_spacing_x
                y = vent_start_y + row * vent_spacing_y
                vent_pos = adsk.core.Point3D.create(x, y, 0)
                circles.addByCenterRadius(vent_pos, 3.0)  # 6mm 방열 구멍
        
        # --- 케이블 통로 (PDF #33: 곡률 반경 ≥ 5mm) ---
        # 측면 케이블 슬롯
        cable_slots = [
            (adsk.core.Point3D.create(-tray_length/2 + 10, -tray_width/2 + 20, 0), 8.0),
            (adsk.core.Point3D.create(-tray_length/2 + 10, tray_width/2 - 20, 0), 8.0),
            (adsk.core.Point3D.create(tray_length/2 - 10, -tray_width/2 + 20, 0), 8.0),
            (adsk.core.Point3D.create(tray_length/2 - 10, tray_width/2 - 20, 0), 8.0),
        ]
        for pos, radius in cable_slots:
            circles.addByCenterRadius(pos, radius)
        
        # --- 익스트루드 ---
        extrudes = features.extrudeFeatures
        top_profile = top_sketch.profiles.item(0)
        
        extrude_input = extrudes.createInput(
            top_profile,
            adsk.fusion360.FeatureOperations.NewBodyFeatureOperation
        )
        distance = adsk.core.ValueInput.createByReal(tray_height / 10.0)  # cm
        extrude_input.setDistanceExtent(False, distance)
        extrudes.add(extrude_input)
        
        # --- 인서트 너트 포켓 (V8.5: 납땜 없음 체결) ---
        # 각 모서리에 M3 인서트 너트 포켓
        insert_positions = [
            adsk.core.Point3D.create(-tray_length/2 + 15, -tray_width/2 + 15, 0),
            adsk.core.Point3D.create(-tray_length/2 + 15, tray_width/2 - 15, 0),
            adsk.core.Point3D.create(tray_length/2 - 15, -tray_width/2 + 15, 0),
            adsk.core.Point3D.create(tray_length/2 - 15, tray_width/2 - 15, 0),
        ]
        
        ui.messageBox(f"Internal Tray V8.5 생성 완료: {tray_length}x{tray_width}x{tray_height}mm")
        return tray_comp
        
    except:
        ui.messageBox(f'Internal Tray V8.5 생성 실패:\n{traceback.format_exc()}')
        return None
