"""
지훈 로봇 V8.5 — Physical AGI Platform / Jihun Robot V8.5 — Physical AGI Platform
Hardware Configuration Module / 하드웨어 설정 모듈

V8.5 → V8.5 Upgrade Summary / V8.5→V8.5 업그레이드 요약:
  - 모든 버전 참조 V8.5로 갱신 / All version references updated to V8.5
  - RobotModel 중복 제거, JIHUN_V85 추가 / Fixed duplicate RobotModel, added JIHUN_V85
  - TaskDomain 4개 신규 도메인 추가 / Added 4 new TaskDomain enums:
    PUBLIC_TRANSPORT, FIELD_TRIP, BALL_SPORTS, CUSTOMER_SERVICE
  - PhysicalAGIConfig V8.5 필드 추가 / Added V8.5 fields to PhysicalAGIConfig:
    vla_model_path, reasoning_depth, autonomous_task_decomposition,
    few_shot_adaptation_enabled, cross_domain_transfer, budget_limit_krw,
    innovation_mode, sim_to_real_gap_target, physical_intelligence_score_target
  - VLAConfig 추가 / Added VLAConfig (Vision-Language-Action model)
  - DataPipelineConfig 추가 / Added DataPipelineConfig (data pipeline)
  - JihunRobotV85Config 메인 설정 클래스 / Main config class updated to V8.5
  - SolderFreeConfig 추가 (PDF 시나리오 1-50) / Added solder-free 3D printing config
  - StructuralIntegrityConfig 추가 (PDF 시나리오 51-75) / Added structural integrity config
  - EnvironmentalHardeningConfig 추가 (PDF 시나리오 76-100) / Added environmental hardening config
  - SupplyChainConfig 추가 / Added supply chain & sourcing configuration
  - SafetyConfig 5계층→7계층 업그레이드 / Safety upgraded from 5-layer to 7-layer
  - BatteryConfig 셀 밸런싱/열폭주 방지 추가 / Battery cell balancing & thermal runaway prevention added

Author: 안지훈 (보성중학교 2학년 4반 10번) / Jihun Robot Project
License: MIT
"""

from __future__ import annotations

# ==============================================================================
# Version Constant / 버전 상수
# ==============================================================================
VERSION = "V8.5"

# ==============================================================================
# Standard Library Imports / 표준 라이브러리 임포트
# ==============================================================================
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional, Tuple

# ==============================================================================
# Enums / 열거형
# ==============================================================================

class RobotModel(Enum):
    """로봇 모델 식별 / Robot model identification"""
    JIHUN_V8 = "V8"
    JIHUN_V84 = "V8.5"
    JIHUN_V85 = "V8.5"


class SafetyLayer(Enum):
    """7계층 안전 시스템 / 7-Layer Safety System (V8.5: 7 layers maintained)"""
    LAYER1_SOFTWARE_LIMIT = auto()       # 계층1: 소프트웨어 제한 / Software limits
    LAYER2_HARDWARE_LIMIT = auto()       # 계층2: 하드웨어 제한 / Hardware limits
    LAYER3_EMERGENCY_STOP = auto()       # 계층3: 비상정지 / Emergency stop
    LAYER4_COLLISION_AVOIDANCE = auto()  # 계층4: 충돌회피 / Collision avoidance
    LAYER5_POWER_MANAGEMENT = auto()     # 계층5: 전원관리 / Power management
    LAYER6_STRUCTURAL_INTEGRITY = auto() # 계층6: 구조무결성 / Structural integrity
    LAYER7_ENVIRONMENTAL_HARDENING = auto()  # 계층7: 환경경화 / Environmental hardening


class MotorType(Enum):
    """모터 유형 / Motor type"""
    SERVO = "servo"
    STEPPER = "stepper"
    DC_BRUSHED = "dc_brushed"
    DC_BRUSHLESS = "dc_brushless"


class SensorType(Enum):
    """센서 유형 / Sensor type"""
    IMU = "imu"
    LIDAR = "lidar"
    CAMERA_RGB = "camera_rgb"
    CAMERA_DEPTH = "camera_depth"
    FORCE_TORQUE = "force_torque"
    TEMPERATURE = "temperature"
    HUMIDITY = "humidity"
    PROXIMITY = "proximity"
    ENCODER = "encoder"
    CURRENT = "current"
    VOLTAGE = "voltage"
    DUST = "dust"                        # V8.5: 먼지 센서 / Dust sensor
    ACCELEROMETER = "accelerometer"
    GYROSCOPE = "gyroscope"
    STRAIN_GAUGE = "strain_gauge"        # V8.5: 변형률 게이지 / Strain gauge
    EMI = "emi"                          # V8.5: EMI 센서 / EMI sensor


class BatteryChemistry(Enum):
    """배터리 화학 / Battery chemistry"""
    LIPO = "lipo"
    LIION = "liion"
    LIFEPO4 = "lifepo4"
    LIHV = "lihv"


class FilamentType(Enum):
    """3D 프린팅 필라멘트 유형 / 3D printing filament type"""
    PLA = "pla"
    ABS = "abs"
    PETG = "petg"
    TPU = "tpu"
    NYLON = "nylon"
    CONDUCTIVE_PLA = "conductive_pla"    # 도전성 PLA / Conductive PLA
    CARBON_FIBER_NYLON = "cf_nylon"     # 탄소섬유 나일론 / Carbon fiber nylon
    PC = "pc"                            # 폴리카보네이트 / Polycarbonate


class CrossContaminationLevel(Enum):
    """교차오염 방지 수준 / Cross-contamination prevention level"""
    NONE = "none"
    BASIC = "basic"                      # 기본: 필라멘트 분리 보관 / Basic: separate filament storage
    MODERATE = "moderate"                # 중간: 노즐 청소 + 분리 보관 / Moderate: nozzle cleaning + separation
    STRICT = "strict"                    # 엄격: 전용 노즐 + 분리 보관 + 환경 제어 / Strict: dedicated nozzle + separation + env control


class EMIHardeningLevel(Enum):
    """EMI 경화 수준 / EMI hardening level"""
    NONE = "none"
    BASIC = "basic"                      # 기본: 케이블 차폐 / Basic: cable shielding
    INDUSTRIAL = "industrial"            # 산업: 차폐 + 필터 + 접지 / Industrial: shielding + filter + grounding
    MILITARY = "military"                # 군사: 완전 차폐 + TEMPEST / Military: full shielding + TEMPEST


class DelaminationSeverity(Enum):
    """박리 심각도 / Delamination detection severity"""
    NONE = "none"
    MINOR = "minor"                      # 경미: 표면 미세 균열 / Minor: surface micro-cracks
    MODERATE = "moderate"                # 중간: 층간 분리 진행 / Moderate: inter-layer separation progressing
    SEVERE = "severe"                    # 심각: 구조적 분리 / Severe: structural separation
    CRITICAL = "critical"                # 치명: 즉시 교체 필요 / Critical: immediate replacement required


class TaskDomain(Enum):
    """Physical AGI 작업 도메인 / Physical AGI task domain (V8.5: 9 domains)"""
    CRAFT = "craft"                      # 공예 / Craft & handiwork
    SHOPPING = "shopping"                # 쇼핑 / Shopping & procurement
    COOKING = "cooking"                  # 요리 / Cooking & food preparation
    CLEANING = "cleaning"                # 청소 / Cleaning & maintenance
    ASSEMBLY = "assembly"                # 조립 / Assembly & construction
    PUBLIC_TRANSPORT = "public_transport"    # V8.5: 대중교통 이용 / Public transport usage
    FIELD_TRIP = "field_trip"                # V8.5: 현장학습 / Field trip & outdoor exploration
    BALL_SPORTS = "ball_sports"              # V8.5: 구기 스포츠 / Ball sports (throwing, catching)
    CUSTOMER_SERVICE = "customer_service"    # V8.5: 고객 서비스 / Customer service & interaction


class SimToRealMetric(Enum):
    """Sim-to-Real 갭 측정 항목 / Sim-to-real gap measurement metric"""
    DYNAMICS_ACCURACY = "dynamics_accuracy"      # 동역학 정확도 / Dynamics accuracy
    PERCEPTION_GAP = "perception_gap"              # 인식 갭 / Perception gap
    CONTROL_LATENCY = "control_latency"            # 제어 지연 / Control latency
    MATERIAL_INTERACTION = "material_interaction"  # 재료 상호작용 / Material interaction
    GRASP_SUCCESS_RATE = "grasp_success_rate"     # 파지 성공률 / Grasp success rate
    NAVIGATION_ERROR = "navigation_error"          # 내비게이션 오차 / Navigation error


class FrameCreepLevel(Enum):
    """프레임 크리프 수준 / Frame creep detection level"""
    NONE = "none"
    EARLY = "early"              # 초기: 미세 변형 감지 / Early: micro-deformation detected
    PROGRESSING = "progressing"  # 진행: 측정 가능한 변형 / Progressing: measurable deformation
    ADVANCED = "advanced"        # 심화: 기능적 영향 / Advanced: functional impact
    CRITICAL = "critical"        # 치명: 구조적 위험 / Critical: structural danger


# ==============================================================================
# V8 Core Configuration Dataclasses (Preserved from V8.3) / V8 핵심 설정 데이터클래스 (V8.5에서 보존)
# ==============================================================================

@dataclass
class MotorConfig:
    """모터 설정 / Motor configuration"""
    motor_id: str = ""
    motor_type: MotorType = MotorType.SERVO
    max_rpm: float = 3000.0               # 최대 RPM / Maximum RPM
    max_torque_nm: float = 2.5            # 최대 토크 (Nm) / Maximum torque (Nm)
    rated_voltage: float = 12.0           # 정격 전압 (V) / Rated voltage (V)
    max_current_a: float = 5.0            # 최대 전류 (A) / Maximum current (A)
    stall_current_a: float = 10.0         # 스톨 전류 (A) / Stall current (A)
    encoder_ppr: int = 4096               # 엔코더 PPR / Encoder pulses per revolution
    gear_ratio: float = 1.0               # 기어비 / Gear ratio
    min_angle_deg: float = -180.0         # 최소 각도 (도) / Minimum angle (degrees)
    max_angle_deg: float = 180.0          # 최대 각도 (도) / Maximum angle (degrees)
    pid_kp: float = 1.0                   # PID 비례게인 / PID proportional gain
    pid_ki: float = 0.0                   # PID 적분게인 / PID integral gain
    pid_kd: float = 0.0                   # PID 미분게인 / PID derivative gain
    thermal_limit_c: float = 80.0         # 열적 한계 (°C) / Thermal limit (°C)
    safety_margin_percent: float = 10.0   # 안전 여유 (%) / Safety margin (%)


@dataclass
class SensorConfig:
    """센서 설정 / Sensor configuration"""
    sensor_id: str = ""
    sensor_type: SensorType = SensorType.IMU
    i2c_address: Optional[int] = None     # I2C 주소 / I2C address
    spi_bus: Optional[int] = None         # SPI 버스 / SPI bus number
    uart_port: Optional[str] = None       # UART 포트 / UART port
    sample_rate_hz: float = 100.0         # 샘플링 주파수 (Hz) / Sampling rate (Hz)
    resolution_bits: int = 16             # 해상도 (비트) / Resolution (bits)
    noise_density: float = 0.01           # 노이즈 밀도 / Noise density
    offset_calibration: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    warmup_time_ms: int = 500             # 웜업 시간 (ms) / Warmup time (ms)
    enabled: bool = True                  # 활성화 / Enabled


@dataclass
class ActuatorConfig:
    """액추에이터 설정 / Actuator configuration"""
    actuator_id: str = ""
    joint_name: str = ""
    motor: MotorConfig = field(default_factory=MotorConfig)
    min_position_mm: float = 0.0          # 최소 위치 (mm) / Minimum position (mm)
    max_position_mm: float = 300.0        # 최대 위치 (mm) / Maximum position (mm)
    max_velocity_mms: float = 500.0       # 최대 속도 (mm/s) / Maximum velocity (mm/s)
    max_acceleration_mmss: float = 2000.0 # 최대 가속도 (mm/s²) / Maximum acceleration (mm/s²)
    home_position_mm: float = 150.0       # 홈 위치 (mm) / Home position (mm)
    backlash_mm: float = 0.05             # 백래시 (mm) / Backlash (mm)
    compliance_enabled: bool = False      # 컴플라이언스 모드 / Compliance mode
    compliance_stiffness: float = 1000.0  # 컴플라이언스 강성 / Compliance stiffness (N/m)
    feedback_sensors: List[SensorConfig] = field(default_factory=list)


@dataclass
class PowerConfig:
    """전원 설정 / Power configuration"""
    main_voltage_v: float = 12.0          # 메인 전압 (V) / Main voltage (V)
    logic_voltage_v: float = 3.3          # 로직 전압 (V) / Logic voltage (V)
    servo_voltage_v: float = 6.0          # 서보 전압 (V) / Servo voltage (V)
    motor_voltage_v: float = 12.0         # 모터 전압 (V) / Motor voltage (V)
    total_power_budget_w: float = 500.0   # 총 전력 예산 (W) / Total power budget (W)
    power_monitoring_enabled: bool = True  # 전력 모니터링 활성 / Power monitoring enabled
    overcurrent_threshold_a: float = 50.0 # 과전류 임계값 (A) / Overcurrent threshold (A)
    undervoltage_threshold_v: float = 10.0 # 저전압 임계값 (V) / Undervoltage threshold (V)
    overvoltage_threshold_v: float = 14.0  # 과전압 임계값 (V) / Overvoltage threshold (V)
    power_failure_backup_ms: int = 100    # 전원 장애 백업 (ms) / Power failure backup time


@dataclass
class CommunicationConfig:
    """통신 설정 / Communication configuration"""
    i2c_buses: List[int] = field(default_factory=lambda: [0, 1])
    spi_buses: List[int] = field(default_factory=lambda: [0])
    uart_baudrates: Dict[str, int] = field(default_factory=lambda: {
        "/dev/ttyAMA0": 115200,
        "/dev/ttyUSB0": 921600,
    })
    can_bus_enabled: bool = True           # CAN 버스 활성 / CAN bus enabled
    can_bitrate: int = 1000000            # CAN 비트레이트 / CAN bitrate
    ethercat_enabled: bool = False         # EtherCAT 활성 / EtherCAT enabled
    websocket_port: int = 8765            # WebSocket 포트 / WebSocket port
    ros2_domain_id: int = 0               # ROS2 도메인 ID / ROS2 domain ID


@dataclass
class ComputeConfig:
    """컴퓨팅 설정 / Compute configuration"""
    main_computer: str = "raspberry_pi_5"           # 메인 컴퓨터 / Main computer
    ai_accelerator: str = "coral_edge_tpu"          # AI 가속기 / AI accelerator
    main_memory_gb: float = 8.0                      # 메인 메모리 (GB) / Main memory (GB)
    storage_gb: float = 128.0                        # 스토리지 (GB) / Storage (GB)
    gpu_enabled: bool = False                        # GPU 활성 / GPU enabled
    inference_threads: int = 4                       # 추론 스레드 수 / Inference threads
    control_loop_rate_hz: float = 1000.0             # 제어 루프 주파수 (Hz) / Control loop rate
    perception_rate_hz: float = 30.0                 # 인식 주파수 (Hz) / Perception rate
    planning_rate_hz: float = 10.0                   # 계획 주파수 (Hz) / Planning rate


@dataclass
class SafetyConfig:
    """
    7계층 안전 설정 / 7-Layer Safety Configuration
    V8.5: 7계층 안전 시스템 유지 / V8.5: 7-layer safety system maintained
    """
    # --- Layer 1: Software Limits / 계층1: 소프트웨어 제한 ---
    max_joint_velocity_dps: float = 180.0      # 최대 관절 속도 (°/s) / Max joint velocity
    max_joint_acceleration_dps2: float = 360.0 # 최대 관절 가속도 (°/s²) / Max joint acceleration
    max_linear_velocity_mms: float = 500.0     # 최대 선형 속도 (mm/s) / Max linear velocity
    workspace_radius_mm: float = 800.0         # 작업공간 반경 (mm) / Workspace radius
    max_payload_kg: float = 5.0                # 최대 페이로드 (kg) / Maximum payload

    # --- Layer 2: Hardware Limits / 계층2: 하드웨어 제한 ---
    hardware_limit_switches: bool = True       # 하드웨어 리미트 스위치 / Hardware limit switches
    mechanical_endstops: bool = True           # 기계적 엔드스톱 / Mechanical endstops
    current_limit_per_motor_a: float = 10.0    # 모터당 전류 제한 (A) / Current limit per motor

    # --- Layer 3: Emergency Stop / 계층3: 비상정지 ---
    estop_gpio_pin: int = 17                   # 비상정지 GPIO 핀 / E-Stop GPIO pin
    estop_active_low: bool = True              # 액티브 로우 / Active low
    estop_software_fallback: bool = True       # 소프트웨어 대체 / Software fallback
    estop_reaction_time_ms: float = 5.0        # 반응 시간 (ms) / Reaction time
    estop_circuit_continuity_check_ms: int = 500  # E-Stop 회로 연속성 검사 주기 (ms) / E-Stop circuit continuity check interval

    # --- Layer 4: Collision Avoidance / 계층4: 충돌회피 ---
    collision_detection_enabled: bool = True   # 충돌 감지 활성 / Collision detection enabled
    proximity_sensors_count: int = 8           # 근접 센서 수 / Proximity sensor count
    safe_distance_mm: float = 200.0            # 안전 거리 (mm) / Safe distance
    collision_speed_reduction_factor: float = 0.5  # 충돌 시 속도 감소 계수 / Speed reduction on collision approach

    # --- Layer 5: Power Management / 계층5: 전원관리 ---
    power_budget_w: float = 500.0              # 전력 예산 (W) / Power budget
    battery_low_threshold_v: float = 11.1      # 배터리 저전압 임계 (V) / Battery low threshold
    auto_shutdown_on_critical_battery: bool = True  # 임계 배터리 시 자동 종료 / Auto shutdown on critical battery
    thermal_shutdown_c: float = 85.0           # 열적 종료 온도 (°C) / Thermal shutdown temperature

    # --- Layer 6: Structural Integrity / 계층6: 구조무결성 ---
    structural_monitoring_enabled: bool = True         # 구조 모니터링 활성 / Structural monitoring enabled
    strain_gauge_count: int = 12                        # 변형률 게이지 수 / Strain gauge count
    max_frame_deformation_mm: float = 0.5               # 최대 프레임 변형 (mm) / Max frame deformation
    anchor_bolt_monitoring_enabled: bool = True         # 앵커 볼트 모니터링 / Anchor bolt monitoring enabled
    anchor_bolt_torque_threshold_nm: float = 5.0        # 앵커 볼트 토크 임계 (Nm) / Anchor bolt torque threshold
    cog_monitoring_enabled: bool = True                 # 무게중심 모니터링 / CoG monitoring enabled
    max_cog_offset_mm: float = 50.0                     # 최대 무게중심 편차 (mm) / Max CoG offset
    vibration_resonance_detection: bool = True          # 진동 공명 감지 / Vibration resonance detection
    resonance_threshold_hz: float = 120.0               # 공명 임계 주파수 (Hz) / Resonance threshold frequency
    creep_detection_interval_s: float = 3600.0          # 크리프 검출 간격 (s) / Creep detection interval
    thermal_expansion_compensation: bool = True          # 열팽창 보상 / Thermal expansion compensation
    frame_thermal_coefficient: float = 11.7e-6          # 프레임 열팽창계수 (1/°C, 알루미늄) / Frame thermal expansion coefficient (aluminum)
    thermal_expansion_max_delta_c: float = 40.0         # 최대 온도 변화 (°C) / Max temperature delta for expansion calc

    # --- Layer 7: Environmental Hardening / 계층7: 환경경화 ---
    environmental_monitoring_enabled: bool = True       # 환경 모니터링 활성 / Environmental monitoring enabled
    dust_monitoring_enabled: bool = True                # 먼지 모니터링 활성 / Dust monitoring enabled
    dust_accumulation_threshold_mgm3: float = 150.0     # 먼지 누적 임계값 (mg/m³) / Dust accumulation threshold
    lens_degradation_detection: bool = True             # 렌즈 성능 저하 감지 / Lens degradation detection
    lens_clarity_threshold_percent: float = 85.0        # 렌즈 투명도 임계 (%) / Lens clarity threshold
    humidity_migration_prevention: bool = True           # 습도 이동 방지 / Humidity migration prevention
    max_indoor_humidity_percent: float = 70.0           # 최대 실내 습도 (%) / Max indoor humidity
    emi_hardening_level: EMIHardeningLevel = EMIHardeningLevel.BASIC  # EMI 경화 수준 / EMI hardening level
    salt_damage_protection: bool = False                # 염해 보호 / Salt damage protection (coastal deployment)
    insect_intrusion_detection: bool = True             # 곤충 침입 감지 / Insect/pest intrusion detection
    insect_detection_method: str = "thermal_anomaly"    # 곤충 감지 방법 / Insect detection method
    conformal_coating_applied: bool = True              # 콘포멀 코팅 적용 / Conformal coating applied
    ip_rating: str = "IP54"                             # 방진방수 등급 / IP rating

    # --- Global safety settings / 전역 안전 설정 ---
    safety_override_enabled: bool = False               # 안전 오버라이드 / Safety override (diagnostic only)
    safety_log_interval_ms: int = 100                   # 안전 로그 주기 (ms) / Safety log interval
    safety_layer_count: int = 7                         # V8.5: 7계층 안전 / V8.5: 7-layer safety


@dataclass
class BatteryConfig:
    """
    배터리 설정 / Battery Configuration
    V8.5: 셀 밸런싱, 열폭주 방지, 재생 제어 포함
    V8.5: Cell balancing, thermal runaway prevention, regeneration control included
    """
    chemistry: BatteryChemistry = BatteryChemistry.LIPO
    cell_count: int = 4                    # 셀 수 (4S) / Cell count (4S)
    nominal_voltage_v: float = 14.8        # 공칭 전압 (V) / Nominal voltage
    max_voltage_v: float = 16.8            # 최대 전압 (V) / Maximum voltage
    min_voltage_v: float = 12.0            # 최소 전압 (V) / Minimum voltage
    capacity_mah: int = 5000               # 용량 (mAh) / Capacity (mAh)
    max_discharge_rate_c: float = 20.0     # 최대 방전율 (C) / Max discharge rate
    max_charge_rate_c: float = 2.0         # 최대 충전율 (C) / Max charge rate
    charging_voltage_v: float = 16.8       # 충전 전압 (V) / Charging voltage
    charging_current_a: float = 5.0        # 충전 전류 (A) / Charging current
    discharge_cutoff_v: float = 12.4       # 방전 컷오프 (V) / Discharge cutoff

    # --- Cell Balancing / 셀 밸런싱 ---
    cell_balancing_enabled: bool = True                 # 셀 밸런싱 활성 / Cell balancing enabled
    cell_balance_threshold_mv: float = 50.0             # 밸런싱 임계 전압차 (mV) / Balancing voltage difference threshold
    cell_balance_current_ma: float = 200.0              # 밸런싱 전류 (mA) / Balancing current
    cell_voltage_monitoring_enabled: bool = True        # 개별 셀 전압 모니터링 / Individual cell voltage monitoring
    cell_voltage_monitor_interval_ms: int = 1000        # 셀 전압 측정 주기 (ms) / Cell voltage monitor interval
    max_cell_voltage_diff_mv: float = 100.0             # 최대 셀간 전압차 (mV) / Max inter-cell voltage difference
    cell_balance_method: str = "passive"                # 밸런싱 방식 (passive/active) / Balancing method

    # --- Thermal Runaway Prevention / 열폭주 방지 ---
    thermal_runaway_prevention_enabled: bool = True     # 열폭주 방지 활성 / Thermal runaway prevention enabled
    cell_thermal_monitor_count: int = 4                 # 셀당 온도 센서 수 / Thermal sensors per cell
    cell_warning_temp_c: float = 55.0                   # 셀 경고 온도 (°C) / Cell warning temperature
    cell_critical_temp_c: float = 65.0                  # 셀 위험 온도 (°C) / Cell critical temperature
    cell_emergency_temp_c: float = 80.0                 # 셀 비상 온도 (°C) / Cell emergency temperature
    thermal_runaway_delta_threshold_cps: float = 2.0    # 온도 상승률 임계 (°C/s) / Temperature rise rate threshold
    thermal_shutdown_sequence_s: float = 0.5            # 열적 종료 시퀀스 시간 (s) / Thermal shutdown sequence time
    vent_gas_detection: bool = False                    # 통기 가스 감지 / Vent gas detection (if sensor available)
    battery_enclosure_vented: bool = True               # 배터리 인클로저 환기 / Battery enclosure vented

    # --- Regeneration Control / 재생 제어 ---
    regeneration_enabled: bool = True                   # 재생 제동 활성 / Regenerative braking enabled
    regeneration_max_current_a: float = 3.0             # 재생 최대 전류 (A) / Max regeneration current
    regeneration_voltage_limit_v: float = 16.5          # 재생 전압 제한 (V) / Regeneration voltage limit
    regeneration_efficiency_target_percent: float = 60.0 # 재생 효율 목표 (%) / Regeneration efficiency target
    regeneration_surge_protection: bool = True          # 재생 서지 보호 / Regeneration surge protection
    regeneration_dump_resistor_ohm: float = 10.0        # 재생 방전 저항 (Ω) / Regeneration dump resistor

    # --- General / 일반 ---
    battery_monitor_ic: str = "bq40z50"                # 배터리 모니터 IC / Battery monitor IC
    fuel_gauge_enabled: bool = True                     # 연료 게이지 활성 / Fuel gauge enabled
    cycle_count_limit: int = 500                        # 사이클 수 제한 / Cycle count limit
    storage_voltage_per_cell_v: float = 3.80            # 보관 전압/셀 (V) / Storage voltage per cell


@dataclass
class LocomotionConfig:
    """이동 설정 / Locomotion configuration"""
    locomotion_type: str = "differential_drive"  # 이동 방식 / Locomotion type
    wheel_diameter_mm: float = 100.0             # 바퀴 지름 (mm) / Wheel diameter
    wheel_base_mm: float = 300.0                 # 휠 베이스 (mm) / Wheel base
    max_speed_mms: float = 1000.0                # 최대 속도 (mm/s) / Max speed
    max_acceleration_mmss: float = 2000.0        # 최대 가속도 (mm/s²) / Max acceleration
    max_deceleration_mmss: float = 3000.0        # 최대 감속도 (mm/s²) / Max deceleration
    turning_radius_mm: float = 0.0               # 회전 반경 (mm), 0=제자리 / Turning radius (0=in-place)
    ground_clearance_mm: float = 30.0            # 지상고 (mm) / Ground clearance
    max_slope_deg: float = 15.0                  # 최대 경사 (도) / Maximum slope
    odometry_enabled: bool = True                # 주행거리 측정 / Odometry enabled


@dataclass
class VisionConfig:
    """비전 설정 / Vision configuration"""
    primary_camera: str = "ov5647"               # 기본 카메라 / Primary camera
    depth_camera: str = "ov9281_stereo"          # 깊이 카메라 / Depth camera
    resolution: Tuple[int, int] = (1920, 1080)   # 해상도 / Resolution
    fps: int = 30                                # 프레임 속도 / Frames per second
    fov_horizontal_deg: float = 72.0             # 수평 시야각 (도) / Horizontal FOV
    fov_vertical_deg: float = 55.0               # 수직 시야각 (도) / Vertical FOV
    stereo_baseline_mm: float = 65.0             # 스테레오 베이스라인 (mm) / Stereo baseline
    ir_filter_enabled: bool = True               # 적외선 필터 / IR filter
    night_vision_enabled: bool = False           # 야간 투시 / Night vision
    auto_exposure: bool = True                   # 자동 노출 / Auto exposure
    white_balance_mode: str = "auto"             # 화이트 밸런스 모드 / White balance mode


@dataclass
class AudioConfig:
    """오디오 설정 / Audio configuration"""
    microphone_type: str = "mems_i2s"            # 마이크 유형 / Microphone type
    microphone_count: int = 2                     # 마이크 수 / Microphone count
    speaker_type: str = "i2s_dac"                 # 스피커 유형 / Speaker type
    sample_rate_hz: int = 16000                   # 샘플링 주파수 (Hz) / Sample rate
    bit_depth: int = 16                           # 비트 깊이 / Bit depth
    vad_enabled: bool = True                      # 음성 활동 감지 / Voice activity detection
    noise_reduction: bool = True                  # 노이즈 감소 / Noise reduction
    max_volume_percent: float = 80.0              # 최대 볼륨 (%) / Maximum volume


# ==============================================================================
# V8.5 Hardware Configuration Dataclasses / V8.5 하드웨어 설정 데이터클래스
# ==============================================================================

@dataclass
class SolderFreeConfig:
    """
    무납땜 설정 / Solder-Free 3D Printing Configuration
    PDF 시나리오 1-50 대응: 3D 프린팅 회로의 무납땜 접속 신뢰성
    Addresses PDF disaster scenarios 1-50: Solder-free 3D printed circuit reliability
    """
    # --- Conductive Filament Resistance Monitoring / 도전성 필라멘트 저항 모니터링 ---
    filament_type: FilamentType = FilamentType.CONDUCTIVE_PLA  # 필라멘트 유형 / Filament type
    nominal_resistivity_ohm_cm: float = 5.0          # 공칭 비저항 (Ω·cm) / Nominal resistivity
    max_resistivity_ohm_cm: float = 15.0             # 최대 허용 비저항 (Ω·cm) / Max allowed resistivity
    resistance_measurement_interval_s: float = 60.0   # 저항 측정 주기 (s) / Resistance measurement interval
    resistance_tolerance_percent: float = 20.0        # 저항 허용오차 (%) / Resistance tolerance
    drift_warning_threshold_percent: float = 30.0     # 드리프트 경고 임계 (%) / Drift warning threshold
    drift_critical_threshold_percent: float = 50.0    # 드리프트 위험 임계 (%) / Drift critical threshold

    # --- Press-Fit / Snap-Fit Tolerance / 프레스핏/스냅핏 공차 ---
    press_fit_interference_um: float = 50.0           # 프레스핏 간섭량 (μm) / Press-fit interference
    snap_fit_deflection_mm: float = 0.8               # 스냅핏 편향량 (mm) / Snap-fit deflection
    snap_fit_retention_force_n: float = 5.0           # 스냅핏 유지력 (N) / Snap-fit retention force
    tolerance_xy_mm: float = 0.2                      # XY 공차 (mm) / XY tolerance
    tolerance_z_mm: float = 0.3                       # Z 공차 (mm) / Z tolerance
    hole_diameter_tolerance_mm: float = 0.1           # 홀 직경 공차 (mm) / Hole diameter tolerance
    pin_diameter_tolerance_mm: float = 0.08           # 핀 직경 공차 (mm) / Pin diameter tolerance
    insertion_force_max_n: float = 30.0               # 최대 삽입력 (N) / Maximum insertion force
    extraction_force_min_n: float = 3.0               # 최소 발출력 (N) / Minimum extraction force

    # --- Delamination Detection / 박리 감지 ---
    delamination_detection_enabled: bool = True       # 박리 감지 활성 / Delamination detection enabled
    delamination_check_interval_s: float = 300.0      # 박리 검사 주기 (s) / Delamination check interval
    delamination_severity_threshold: DelaminationSeverity = DelaminationSeverity.MODERATE  # 경고 수준 / Warning level
    ultrasonic_testing_enabled: bool = False          # 초음파 검사 / Ultrasonic testing
    visual_inspection_enabled: bool = True            # 육안 검사 / Visual inspection
    interlayer_adhesion_min_mpa: float = 15.0         # 최소 층간 접착력 (MPa) / Min interlayer adhesion
    delamination_alert_on_severity: DelaminationSeverity = DelaminationSeverity.MODERATE  # 알림 발생 수준 / Alert trigger level

    # --- Cross-Contamination Prevention / 교차오염 방지 ---
    cross_contamination_level: CrossContaminationLevel = CrossContaminationLevel.MODERATE
    nozzle_clean_between_filaments: bool = True       # 필라멘트 교체 시 노즐 청소 / Clean nozzle between filaments
    dedicated_nozzle_per_material: bool = False       # 재료별 전용 노즐 / Dedicated nozzle per material
    filament_storage_sealed: bool = True              # 필라멘트 밀봉 보관 / Sealed filament storage
    filament_drybox_enabled: bool = True              # 드라이박스 사용 / Drybox enabled
    filament_swap_purge_length_mm: float = 50.0       # 교체 시 퍼지 길이 (mm) / Purge length on swap
    max_filament_moisture_percent: float = 0.5        # 최대 필라멘트 수분 (%) / Max filament moisture

    # --- Ampacity Derating for Printed Circuits / 프린트 회로 전류강도 디레이팅 ---
    base_ampacity_a: float = 3.0                      # 기본 전류강도 (A) / Base ampacity
    derating_factor: float = 0.5                      # 디레이팅 계수 / Derating factor (solder-free = 50%)
    derating_temp_coefficient: float = -0.005         # 온도 디레이팅 계수 (/°C) / Temperature derating coefficient
    derating_above_ambient_c: float = 30.0            # 디레이팅 시작 온도 (°C) / Derating start temperature above ambient
    max_continuous_current_a: float = 1.5             # 최대 연속 전류 (A) / Max continuous current after derating
    trace_width_mm: float = 2.0                       # 트레이스 폭 (mm) / Trace width
    trace_thickness_mm: float = 0.4                   # 트레이스 두께 (mm) / Trace thickness
    via_reinforcement: bool = True                    # 비아 보강 / Via reinforcement
    parallel_trace_count: int = 1                     # 병렬 트레이스 수 / Parallel trace count

    # --- Z-Axis Anisotropy Compensation / Z축 이방성 보상 ---
    z_anisotropy_factor: float = 0.6                  # Z축 강도 비율 (XY 대비) / Z-axis strength ratio vs XY
    z_conductivity_factor: float = 0.3                # Z축 전도율 비율 (XY 대비) / Z-axis conductivity ratio vs XY
    z_compensation_enabled: bool = True               # Z축 보상 활성 / Z-axis compensation enabled
    z_trace_redundancy_layers: int = 3                # Z축 트레이스 중복 레이어 / Z-trace redundancy layers
    z_via_reinforcement_count: int = 2                # Z축 비아 보강 수 / Z-via reinforcement count
    z_anisotropy_monitoring: bool = True              # Z축 이방성 모니터링 / Z-anisotropy monitoring

    # --- Humidity Oxidation Protection / 습도 산화 보호 ---
    humidity_oxidation_monitoring: bool = True        # 습도 산화 모니터링 / Humidity oxidation monitoring
    max_operating_humidity_percent: float = 65.0      # 최대 작동 습도 (%) / Max operating humidity
    max_storage_humidity_percent: float = 40.0        # 최대 보관 습도 (%) / Max storage humidity
    contact_oxidation_threshold_mohm: float = 50.0    # 접점 산화 임계 (mΩ) / Contact oxidation threshold
    conformal_coating_type: str = "acrylic"           # 콘포멜 코팅 유형 / Conformal coating type
    conformal_coating_thickness_um: float = 25.0      # 콘포멜 코팅 두께 (μm) / Conformal coating thickness
    silica_gel_packets_count: int = 4                 # 실리카겔 팩 수 / Silica gel packet count
    desiccant_replacement_interval_days: int = 30     # 건조제 교체 주기 (일) / Desiccant replacement interval

    # --- EMI Shielding Requirements / EMI 차폐 요구사항 ---
    emi_shielding_enabled: bool = True                # EMI 차폐 활성 / EMI shielding enabled
    emi_shielding_effectiveness_db: float = 40.0      # 차폐 효과 (dB) / Shielding effectiveness
    emi_shielding_material: str = "copper_tape"       # 차폐 재료 / Shielding material
    emi_gasket_material: str = "conductive_silicone"  # EMI 가스킷 재료 / EMI gasket material
    cable_shielding: bool = True                      # 케이블 차폐 / Cable shielding
    ferrite_bead_count: int = 6                       # 페라이트 비드 수 / Ferrite bead count
    ground_plane_enabled: bool = True                 # 접지면 활성 / Ground plane enabled

    # --- Connector Pin Oxidation Monitoring / 커넥터 핀 산화 모니터링 ---
    pin_oxidation_monitoring: bool = True             # 핀 산화 모니터링 / Pin oxidation monitoring
    pin_contact_resistance_max_mohm: float = 20.0     # 최대 핀 접촉저항 (mΩ) / Max pin contact resistance
    pin_cleaning_interval_hours: float = 720.0        # 핀 청소 주기 (시간) / Pin cleaning interval (30 days)
    pin_cleaning_method: str = "isopropyl_alcohol"    # 핀 청소 방법 / Pin cleaning method
    gold_plated_contacts: bool = True                 # 도금 접점 / Gold-plated contacts
    contact_lubricant: str = "nox_kontakt_60"         # 접점 윤활제 / Contact lubricant
    connector_seal_rating: str = "IP54"               # 커넥터 밀봉 등급 / Connector seal rating


@dataclass
class StructuralIntegrityConfig:
    """
    구조무결성 설정 / Structural Integrity Configuration
    PDF 시나리오 51-75 대응: 구조 불안정성 방지
    Addresses PDF disaster scenarios 51-75: Structural instability prevention
    """
    # --- Center of Gravity Monitoring / 무게중심 모니터링 ---
    cog_monitoring_enabled: bool = True               # 무게중심 모니터링 활성 / CoG monitoring enabled
    cog_sensor_count: int = 4                          # 무게중심 센서 (로드셀) 수 / CoG sensor (load cell) count
    cog_max_forward_offset_mm: float = 30.0            # 최대 전방 편차 (mm) / Max forward offset
    cog_max_lateral_offset_mm: float = 25.0            # 최대 측방 편차 (mm) / Max lateral offset
    cog_max_vertical_offset_mm: float = 40.0           # 최대 수직 편차 (mm) / Max vertical offset
    cog_measurement_rate_hz: float = 10.0              # 무게중심 측정 주파수 (Hz) / CoG measurement rate
    cog_dynamic_compensation: bool = True              # 동적 무게중심 보상 / Dynamic CoG compensation
    cog_warning_threshold_percent: float = 70.0        # 경고 임계 (%) / Warning threshold (% of max)
    cog_critical_threshold_percent: float = 90.0       # 위험 임계 (%) / Critical threshold (% of max)

    # --- Vibration Resonance Detection / 진동 공명 감지 ---
    vibration_monitoring_enabled: bool = True          # 진동 모니터링 활성 / Vibration monitoring enabled
    accelerometer_count: int = 4                       # 가속도계 수 / Accelerometer count
    accelerometer_range_g: float = 16.0                # 가속도계 범위 (g) / Accelerometer range
    vibration_sample_rate_hz: float = 2000.0           # 진동 샘플링 주파수 (Hz) / Vibration sample rate
    resonance_detection_algorithm: str = "fft_peak"    # 공명 감지 알고리즘 / Resonance detection algorithm
    resonance_frequency_range_hz: Tuple[float, float] = (10.0, 500.0)  # 공명 탐지 주파수 범위 (Hz) / Resonance scan range
    resonance_damping_threshold: float = 0.3           # 공명 감쇠 임계 / Resonance damping threshold
    vibration_severity_warning_mms2: float = 20.0      # 진동 경고 가속도 (mm/s²) / Vibration warning acceleration
    vibration_severity_critical_mms2: float = 50.0     # 진동 위험 가속도 (mm/s²) / Vibration critical acceleration
    anti_resonance_mode_enabled: bool = True           # 안티 공명 모드 / Anti-resonance mode
    resonance_avoidance_bandwidth_hz: float = 5.0      # 공명 회피 대역폭 (Hz) / Resonance avoidance bandwidth

    # --- Anchor Bolt Fatigue Monitoring / 앵커 볼트 피로 모니터링 ---
    anchor_bolt_monitoring_enabled: bool = True        # 앵커 볼트 모니터링 활성 / Anchor bolt monitoring enabled
    anchor_bolt_count: int = 8                         # 앵커 볼트 수 / Anchor bolt count
    anchor_bolt_material: str = "stainless_304"        # 앵커 볼트 재질 / Anchor bolt material
    anchor_bolt_diameter_mm: float = 6.0               # 앵커 볼트 지름 (mm) / Anchor bolt diameter
    anchor_bolt_nominal_torque_nm: float = 8.0         # 공칭 토크 (Nm) / Nominal torque
    anchor_bolt_min_torque_nm: float = 6.0             # 최소 토크 (Nm) / Minimum torque
    anchor_bolt_max_torque_nm: float = 10.0            # 최대 토크 (Nm) / Maximum torque
    anchor_bolt_fatigue_cycles_limit: int = 1000000    # 피로 한계 사이클 / Fatigue cycle limit
    anchor_bolt_check_interval_hours: float = 100.0    # 점검 주기 (시간) / Check interval
    anchor_bolt_torque_sensor_type: str = "strain_gauge"  # 토크 센서 유형 / Torque sensor type
    anchor_bolt_loss_detection: bool = True            # 볼트 이탈 감지 / Bolt loss detection

    # --- Thermal Expansion Compensation / 열팽창 보상 ---
    thermal_expansion_compensation: bool = True         # 열팽창 보상 활성 / Thermal expansion compensation enabled
    frame_material: str = "aluminum_6061"               # 프레임 재질 / Frame material
    frame_thermal_coefficient_per_c: float = 23.6e-6    # 열팽창계수 (1/°C, 알루미늄 6061) / Thermal expansion coefficient
    frame_reference_length_mm: float = 500.0            # 기준 길이 (mm) / Reference length
    max_operating_temp_c: float = 60.0                  # 최대 작동 온도 (°C) / Max operating temperature
    min_operating_temp_c: float = -10.0                 # 최소 작동 온도 (°C) / Min operating temperature
    thermal_compensation_algorithm: str = "linear_model"  # 보상 알고리즘 / Compensation algorithm
    thermal_sensor_count: int = 8                       # 온도 센서 수 / Temperature sensor count
    thermal_sensor_placement: str = "frame_nodes"       # 센서 배치 / Sensor placement
    expansion_joint_tolerance_mm: float = 0.5           # 신축 이음 공차 (mm) / Expansion joint tolerance
    thermal_gradient_limit_c_per_m: float = 5.0         # 온도 구배 제한 (°C/m) / Thermal gradient limit

    # --- Frame Creep Detection / 프레임 크리프 감지 ---
    frame_creep_detection_enabled: bool = True          # 크리프 감지 활성 / Frame creep detection enabled
    creep_detection_method: str = "laser_displacement"  # 크리프 감지 방법 / Creep detection method
    creep_measurement_points: int = 12                  # 크리프 측정 지점 수 / Creep measurement points
    creep_max_deformation_mm: float = 0.3               # 최대 크리프 변형 (mm) / Max creep deformation
    creep_warning_deformation_mm: float = 0.15          # 크리프 경고 변형 (mm) / Creep warning deformation
    creep_detection_interval_s: float = 3600.0          # 크리프 검출 주기 (s) / Creep detection interval
    creep_alert_level: FrameCreepLevel = FrameCreepLevel.EARLY  # 크리프 알림 수준 / Creep alert level
    creep_compensation_enabled: bool = True             # 크리프 보상 활성 / Creep compensation enabled
    creep_compensation_max_mm: float = 0.2              # 크리프 보상 최대 (mm) / Max creep compensation
    frame_lifetime_hours: float = 10000.0               # 프레임 수명 (시간) / Frame lifetime
    creep_retirement_deformation_mm: float = 0.5        # 크리프 폐기 변형 (mm) / Creep retirement deformation


@dataclass
class EnvironmentalHardeningConfig:
    """
    환경경화 설정 / Environmental Hardening Configuration
    PDF 시나리오 76-100 대응: 환경적 위협 대응
    Addresses PDF disaster scenarios 76-100: Environmental threat response
    """
    # --- Dust Accumulation Monitoring / 먼지 누적 모니터링 ---
    dust_monitoring_enabled: bool = True               # 먼지 모니터링 활성 / Dust monitoring enabled
    dust_sensor_type: str = "gp2y1014au0f"              # 먼지 센서 유형 / Dust sensor type
    dust_sensor_count: int = 3                          # 먼지 센서 수 / Dust sensor count
    dust_pm25_warning_ugm3: float = 35.0                # PM2.5 경고 (μg/m³) / PM2.5 warning level
    dust_pm25_critical_ugm3: float = 75.0               # PM2.5 위험 (μg/m³) / PM2.5 critical level
    dust_pm10_warning_ugm3: float = 80.0                # PM10 경고 (μg/m³) / PM10 warning level
    dust_pm10_critical_ugm3: float = 150.0              # PM10 위험 (μg/m³) / PM10 critical level
    dust_accumulation_mass_mg: float = 0.0              # 누적 먼지 질량 (mg) / Accumulated dust mass
    dust_cleaning_interval_hours: float = 168.0         # 먼지 청소 주기 (시간) / Dust cleaning interval (1 week)
    dust_cleaning_method: str = "compressed_air"        # 청소 방법 / Cleaning method
    intake_filter_type: str = "hepa_h11"                # 흡기 필터 유형 / Intake filter type
    intake_filter_replacement_hours: float = 2000.0     # 필터 교체 주기 (시간) / Filter replacement interval

    # --- Lens Degradation Detection / 렌즈 성능 저하 감지 ---
    lens_degradation_detection: bool = True             # 렌즈 저하 감지 활성 / Lens degradation detection enabled
    lens_calibration_interval_hours: float = 720.0      # 렌즈 보정 주기 (시간) / Lens calibration interval (30 days)
    lens_clarity_baseline_percent: float = 100.0        # 렌즈 투명도 기준선 (%) / Lens clarity baseline
    lens_clarity_min_percent: float = 85.0              # 최소 렌즈 투명도 (%) / Minimum lens clarity
    lens_scratch_detection: bool = True                 # 렌즈 스크래치 감지 / Lens scratch detection
    lens_fog_detection: bool = True                     # 렌즈 안개 감지 / Lens fog detection
    lens_cleaning_method: str = "microfiber_auto"       # 렌즈 청소 방법 / Lens cleaning method
    lens_protection_cover: bool = True                  # 렌즈 보호 커버 / Lens protection cover
    lens_heater_enabled: bool = True                    # 렌즈 히터 (안개 방지) / Lens heater (anti-fog)
    lens_heater_power_w: float = 1.0                    # 렌즈 히터 전력 (W) / Lens heater power

    # --- Humidity Migration Prevention / 습도 이동 방지 ---
    humidity_migration_prevention: bool = True          # 습도 이동 방지 활성 / Humidity migration prevention enabled
    humidity_sensor_count: int = 4                      # 습도 센서 수 / Humidity sensor count
    max_internal_humidity_percent: float = 60.0         # 최대 내부 습도 (%) / Max internal humidity
    condensation_threshold_dewpoint_c: float = 5.0      # 결로 이승점 여유 (°C) / Condensation dewpoint margin
    pcb_conformal_coating: bool = True                  # PCB 콘포멜 코팅 / PCB conformal coating
    pcb_conformal_coating_type: str = "silicone"        # PCB 코팅 유형 / PCB coating type
    enclosure_seal_rating: str = "IP54"                 # 인클로저 밀봉 등급 / Enclosure seal rating
    desiccant_compartment_count: int = 2                # 건조제실 수 / Desiccant compartment count
    humidity_alert_interval_s: float = 30.0             # 습도 알림 주기 (s) / Humidity alert interval
    ventilation_enabled: bool = True                    # 환기 활성 / Ventilation enabled
    ventilation_method: str = "passive_vents"           # 환기 방법 / Ventilation method

    # --- EMI Hardening / EMI 경화 ---
    emi_hardening_level: EMIHardeningLevel = EMIHardeningLevel.BASIC  # EMI 경화 수준 / EMI hardening level
    emi_shielding_enclosure: bool = True                # EMI 차폐 인클로저 / EMI shielding enclosure
    emi_shielding_material: str = "aluminum_sheet_1mm"  # 차폐 재료 / Shielding material
    emi_filter_on_power_input: bool = True              # 전원 입력 EMI 필터 / EMI filter on power input
    emi_filter_on_signal_lines: bool = True             # 신호선 EMI 필터 / EMI filter on signal lines
    emi_ferrite_bead_count: int = 8                     # 페라이트 비드 수 / Ferrite bead count
    emi_grounding_scheme: str = "star_ground"           # 접지 방식 / Grounding scheme
    emi_cable_routing: str = "separated_power_signal"   # 케이블 라우팅 / Cable routing strategy
    emi_test_interval_hours: float = 2000.0             # EMI 테스트 주기 (시간) / EMI test interval
    emi_compliance_standard: str = "kcc_class_b"        # EMI 규격 / EMI compliance standard (KCC Class B)

    # --- Salt Damage Protection / 염해 보호 ---
    salt_damage_protection: bool = False                # 염해 보호 (해안 배치 시 활성) / Salt damage protection (coastal)
    conformal_coating_salt_grade: str = "ip67"          # 염해 대응 코팅 등급 / Salt-grade coating
    stainless_steel_fasteners: bool = False             # 스텐리스 패스너 / Stainless steel fasteners
    anti_corrosion_spray: bool = False                  # 방청 스프레이 / Anti-corrosion spray
    salt_test_interval_hours: float = 500.0             # 염해 테스트 주기 (시간) / Salt test interval
    galvanic_isolation: bool = True                     # 갈바닉 절연 / Galvanic isolation

    # --- Insect/Pest Intrusion Detection / 곤충/해충 침입 감지 ---
    insect_intrusion_detection: bool = True             # 곤충 침입 감지 활성 / Insect intrusion detection enabled
    insect_detection_method: str = "thermal_anomaly"    # 감지 방법 / Detection method
    insect_detection_sensitivity: float = 0.7           # 감지 감도 (0-1) / Detection sensitivity
    insect_detection_interval_s: float = 60.0           # 감지 주기 (s) / Detection interval
    seal_integrity_check: bool = True                   # 밀봉 무결성 검사 / Seal integrity check
    insect_prevention_measures: List[str] = field(default_factory=lambda: [
        "sealed_enclosure",             # 밀봉 인클로저 / Sealed enclosure
        "mesh_vent_covers",             # 망사 환기구 덮개 / Mesh vent covers
        "cable_gland_seals",            # 케이블 글랜드 실 / Cable gland seals
        "periodic_inspection",          # 정기 검사 / Periodic inspection
    ])
    insect_alert_threshold: int = 1                     # 곤충 알림 임계 (마리) / Insect alert threshold (count)

    # --- E-Stop Circuit Continuity Monitoring / E-Stop 회로 연속성 모니터링 ---
    estop_circuit_continuity: bool = True               # E-Stop 회로 연속성 모니터링 / E-Stop circuit continuity monitoring
    estop_continuity_check_interval_ms: int = 500       # 연속성 검사 주기 (ms) / Continuity check interval
    estop_circuit_redundancy: int = 2                   # E-Stop 회로 이중화 / E-Stop circuit redundancy
    estop_wire_break_detection: bool = True             # E-Stop 선로 단선 감지 / E-Stop wire break detection
    estop_contact_weld_detection: bool = True           # E-Stop 접점 용착 감지 / E-Stop contact weld detection
    estop_response_time_max_ms: float = 10.0            # 최대 E-Stop 응답시간 (ms) / Max E-Stop response time
    estop_self_test_on_boot: bool = True                # 부팅 시 E-Stop 자가테스트 / E-Stop self-test on boot
    estop_naming_convention: str = "hardwired_normally_closed"  # E-Stop 방식 / E-Stop type (hardwired NC)
    estop_bypass_requires_auth: bool = True             # E-Stop 바이패스 인증 필요 / E-Stop bypass requires auth


# ==============================================================================
# V8.5 NEW: VLA (Vision-Language-Action) Configuration / V8.5 신규: VLA 설정
# ==============================================================================

@dataclass
class VLAConfig:
    """
    Vision-Language-Action 모델 설정 / Vision-Language-Action Model Configuration
    V8.5 핵심 혁신: VLA 모델로 물리적 지능 구현
    V8.5 Core Innovation: Physical intelligence through VLA model

    Unitree, Tesla Optimus, Figure AI를 소프트웨어 혁신으로 극복
    Beat Unitree, Tesla Optimus, Figure AI through software innovation
    """
    model_name: str = "gemma-4-e4b-vla"                # VLA 모델명 / VLA model name
    action_space_type: str = "continuous"               # 행동 공간 유형 / Action space type (continuous/discrete)
    vision_encoder: str = "siglip"                      # 비전 인코더 / Vision encoder model
    action_head_type: str = "diffusion"                 # 행동 헤드 유형 (diffusion policy for smooth actions) / Action head type
    inference_latency_target_ms: float = 50.0           # 추론 지연 목표 (ms) / Inference latency target
    training_method: str = "colab_a100_lora"            # 학습 방법 (Colab A100 LoRA) / Training method


# ==============================================================================
# V8.5 NEW: Data Pipeline Configuration / V8.5 신규: 데이터 파이프라인 설정
# ==============================================================================

@dataclass
class DataPipelineConfig:
    """
    데이터 파이프라인 설정 / Data Pipeline Configuration
    V8.5 혁신: 다양한 데이터 소스로 물리적 지능 학습
    V8.5 Innovation: Physical intelligence learning from diverse data sources

    YouTube 영상 학습, 시뮬레이션, 자기주도 탐색, 연합학습 통합
    Integrated: YouTube video training, simulation, self-supervised exploration, federated learning
    """
    sim_data_source: str = "isaac_sim"                  # 시뮬레이션 데이터 소스 / Simulation data source
    video_pretraining_enabled: bool = True              # 비디오 사전학습 활성 / Video pretraining enabled
    teleoperation_data_collection: bool = True          # 원격조작 데이터 수집 / Teleoperation data collection
    self_supervised_exploration: bool = True            # 자기주도 탐색 활성 / Self-supervised exploration enabled
    federated_learning_enabled: bool = True             # 연합학습 활성 / Federated learning enabled
    youtube_video_training: bool = True                 # YouTube 영상 학습 / YouTube video training
    dream_training_steps: int = 10000                   # 드림 학습 스텝 수 / Dream training steps


# ==============================================================================
# V8.5 Physical AGI Configuration / V8.5 Physical AGI 설정
# ==============================================================================

@dataclass
class PhysicalAGIConfig:
    """
    Physical AGI 핵심 설정 / Physical AGI Core Configuration
    V8.5 핵심 혁신: 물리적 범용 지능 플랫폼
    V8.5 Core Innovation: Physical Artificial General Intelligence platform

    안지훈 (보성중학교 2학년 4반 10번) — 예산 500만원으로 Unitree, Tesla Optimus, Figure AI 극복
    Jihun Ahn (Boseong Middle School, Grade 2, Class 4, #10) — Beat big companies with 5M KRW budget
    """
    # --- V8.5 NEW: VLA & Reasoning / V8.5 신규: VLA 및 추론 ---
    vla_model_path: str = ""                            # VLA 모델 경로 / Vision-Language-Action model path
    reasoning_depth: int = 5                            # 사슬사고 깊이 / Chain-of-thought depth
    autonomous_task_decomposition: bool = True          # AI 자율 작업 분해 / AI decomposes tasks itself
    few_shot_adaptation_enabled: bool = True            # 퓨샷 적응 활성 / Few-shot adaptation enabled
    cross_domain_transfer: bool = True                  # 교차 도메인 전이 (한 도메인 기술이 다른 도메인으로) / Skills transfer across domains
    budget_limit_krw: int = 5_000_000                   # 예산 한도 (원) / Budget limit (KRW)
    innovation_mode: str = "software_first"             # 혁신 모드 (대기업을 소프트웨어로 극복) / Beat big companies with software
    sim_to_real_gap_target: float = 0.05                # Sim-to-Real 갭 목표 (5%) / Sim-to-real gap target (5%)
    physical_intelligence_score_target: float = 0.85    # 물리적 지능 점수 목표 / Physical intelligence score target

    # --- Task Generalization Metrics / 작업 일반화 지표 ---
    task_generalization_enabled: bool = True            # 작업 일반화 활성 / Task generalization enabled
    generalization_metric_method: str = "zero_shot_success_rate"  # 일반화 측정 방법 / Generalization metric method
    zero_shot_success_threshold_percent: float = 60.0   # 제로샷 성공 임계 (%) / Zero-shot success threshold
    few_shot_examples_max: int = 5                      # 퓨샷 예시 최대 수 / Max few-shot examples
    task_complexity_levels: int = 5                     # 작업 복잡도 수준 / Task complexity levels
    generalization_benchmark_set: str = "physical_agi_v1"  # 일반화 벤치마크 세트 / Generalization benchmark set
    novel_task_detection: bool = True                   # 새로운 작업 감지 / Novel task detection
    task_failure_recovery: bool = True                  # 작업 실패 복구 / Task failure recovery
    max_task_recovery_attempts: int = 3                 # 최대 복구 시도 / Max recovery attempts
    task_decomposition_enabled: bool = True             # 작업 분해 활성 / Task decomposition enabled

    # --- Cross-Domain Transfer Settings / 교차 도메인 전이 설정 ---
    cross_domain_transfer_enabled: bool = True          # 교차 도메인 전이 활성 / Cross-domain transfer enabled
    transfer_learning_method: str = "progressive_networks"  # 전이학습 방법 / Transfer learning method
    domain_adaptation_rate: float = 0.001               # 도메인 적응률 / Domain adaptation rate
    knowledge_retention_percent: float = 95.0           # 지식 유지율 (%) / Knowledge retention
    catastrophic_forgetting_threshold: float = 0.05     # 치명적 망각 임계 / Catastrophic forgetting threshold
    transfer_efficiency_target_percent: float = 70.0    # 전이 효율 목표 (%) / Transfer efficiency target
    elastic_weight_consolidation: bool = True           # 탄성 가중치 통합 / Elastic weight consolidation
    replay_buffer_size: int = 10000                     # 리플레이 버퍼 크기 / Replay buffer size
    domain_distance_metric: str = "mmd"                 # 도메인 거리 측정 / Domain distance metric (MMD)

    # --- Real-World Task Categories / 실세계 작업 카테고리 (V8.5: 9개 도메인) ---
    task_categories: Dict[TaskDomain, Dict[str, float]] = field(default_factory=lambda: {
        TaskDomain.CRAFT: {
            "cutting_accuracy_mm": 1.0,             # 절단 정확도 (mm) / Cutting accuracy
            "gluing_precision_mm": 2.0,             # 접착 정밀도 (mm) / Gluing precision
            "folding_alignment_mm": 3.0,            # 접기 정렬 (mm) / Folding alignment
            "success_rate_percent": 70.0,           # 성공률 (%) / Success rate
        },
        TaskDomain.SHOPPING: {
            "item_recognition_percent": 85.0,       # 물품 인식률 (%) / Item recognition rate
            "grasp_success_percent": 80.0,          # 파지 성공률 (%) / Grasp success rate
            "navigation_accuracy_mm": 100.0,        # 내비게이션 정확도 (mm) / Navigation accuracy
            "checkout_success_percent": 75.0,       # 결제 성공률 (%) / Checkout success rate
        },
        TaskDomain.COOKING: {
            "ingredient_measurement_accuracy_g": 5.0,  # 재료 계량 정확도 (g) / Ingredient measurement accuracy
            "temperature_control_accuracy_c": 5.0,     # 온도 제어 정확도 (°C) / Temperature control accuracy
            "timing_accuracy_s": 10.0,                 # 타이밍 정확도 (s) / Timing accuracy
            "food_safety_compliance_percent": 99.0,    # 식품안전 준수율 (%) / Food safety compliance
        },
        TaskDomain.CLEANING: {
            "coverage_percent": 90.0,               # 커버리지 (%) / Cleaning coverage
            "contamination_reduction_percent": 85.0,  # 오염 감소율 (%) / Contamination reduction
            "surface_damage_risk_percent": 1.0,      # 표면 손상 위험 (%) / Surface damage risk
            "completion_time_factor": 1.5,           # 완료 시간 계수 (인간 대비) / Completion time factor vs human
        },
        TaskDomain.ASSEMBLY: {
            "alignment_accuracy_mm": 0.5,           # 정렬 정확도 (mm) / Alignment accuracy
            "fastening_torque_accuracy_percent": 5.0,  # 체결 토크 정확도 (%) / Fastening torque accuracy
            "sequence_compliance_percent": 98.0,    # 순서 준수율 (%) / Sequence compliance
            "structural_integrity_percent": 99.0,   # 구조 무결성 (%) / Structural integrity
        },
        TaskDomain.PUBLIC_TRANSPORT: {
            "navigation_accuracy_m": 5.0,               # V8.5: 내비게이션 정확도 (m) / Navigation accuracy
            "boarding_success_percent": 90.0,            # V8.5: 승차 성공률 (%) / Boarding success rate
            "route_planning_success_percent": 95.0,      # V8.5: 경로 계획 성공률 (%) / Route planning success
            "payment_transaction_success_percent": 95.0, # V8.5: 결제 성공률 (%) / Payment success rate
            "safety_compliance_percent": 99.0,           # V8.5: 안전 준수율 (%) / Safety compliance
        },
        TaskDomain.FIELD_TRIP: {
            "outdoor_navigation_accuracy_m": 10.0,       # V8.5: 야외 내비게이션 정확도 (m) / Outdoor navigation accuracy
            "obstacle_avoidance_success_percent": 95.0,  # V8.5: 장애물 회피 성공률 (%) / Obstacle avoidance rate
            "environmental_adaptation_percent": 85.0,    # V8.5: 환경 적응률 (%) / Environmental adaptation rate
            "landmark_recognition_percent": 80.0,        # V8.5: 랜드마크 인식률 (%) / Landmark recognition rate
            "safe_return_percent": 99.0,                 # V8.5: 안전 복귀율 (%) / Safe return rate
        },
        TaskDomain.BALL_SPORTS: {
            "throw_accuracy_percent": 70.0,              # V8.5: 던지기 정확도 (%) / Throwing accuracy
            "catch_success_percent": 65.0,               # V8.5: 잡기 성공률 (%) / Catching success rate
            "throw_distance_accuracy_percent": 75.0,     # V8.5: 던지기 거리 정확도 (%) / Throw distance accuracy
            "reaction_time_ms": 300.0,                   # V8.5: 반응 시간 (ms) / Reaction time
            "ball_tracking_accuracy_percent": 90.0,      # V8.5: 공 추적 정확도 (%) / Ball tracking accuracy
        },
        TaskDomain.CUSTOMER_SERVICE: {
            "speech_recognition_accuracy_percent": 95.0, # V8.5: 음성 인식 정확도 (%) / Speech recognition accuracy
            "response_appropriateness_percent": 85.0,    # V8.5: 응답 적절성 (%) / Response appropriateness
            "emotion_detection_accuracy_percent": 80.0,  # V8.5: 감정 감지 정확도 (%) / Emotion detection accuracy
            "task_completion_percent": 90.0,             # V8.5: 작업 완료율 (%) / Task completion rate
            "customer_satisfaction_target_percent": 80.0, # V8.5: 고객 만족도 목표 (%) / Customer satisfaction target
        },
    })

    # --- Continuous Physical Experience Collection / 지속적 물리 경험 수집 ---
    experience_collection_enabled: bool = True          # 경험 수집 활성 / Experience collection enabled
    experience_storage_path: str = "/data/v85/experiences"  # 경험 저장 경로 / Experience storage path
    experience_collection_rate_hz: float = 10.0         # 수집 주파수 (Hz) / Collection rate
    experience_buffer_size: int = 100000                # 경험 버퍼 크기 / Experience buffer size
    experience_prioritization: str = "prioritized_replay"  # 경험 우선순위 / Experience prioritization
    experience_compression: bool = True                 # 경험 압축 / Experience compression
    experience_compression_ratio: float = 0.3           # 압축비 / Compression ratio
    experience_upload_enabled: bool = False              # 경험 업로드 (클라우드) / Experience upload (cloud)
    experience_upload_endpoint: str = ""                 # 업로드 엔드포인트 / Upload endpoint
    experience_annotation: str = "semi_automatic"        # 경험 주석 방법 / Experience annotation method
    experience_retention_days: int = 365                 # 경험 보존 기간 (일) / Experience retention period

    # --- Sim-to-Real Gap Monitoring / Sim-to-Real 갭 모니터링 ---
    sim_to_real_monitoring_enabled: bool = True         # Sim-to-Real 모니터링 활성 / Sim-to-Real monitoring enabled
    sim_environment: str = "isaac_sim_v85"              # 시뮬레이션 환경 / Simulation environment
    sim_fidelity_score_target: float = 0.85             # 시뮬레이션 충실도 목표 / Simulation fidelity target
    sim_to_real_metrics: Dict[SimToRealMetric, float] = field(default_factory=lambda: {
        SimToRealMetric.DYNAMICS_ACCURACY: 0.80,        # 동역학 정확도 / Dynamics accuracy
        SimToRealMetric.PERCEPTION_GAP: 0.15,           # 인식 갭 / Perception gap (lower=better)
        SimToRealMetric.CONTROL_LATENCY: 5.0,           # 제어 지연 (ms) / Control latency (ms)
        SimToRealMetric.MATERIAL_INTERACTION: 0.75,     # 재료 상호작용 / Material interaction
        SimToRealMetric.GRASP_SUCCESS_RATE: 0.80,       # 파지 성공률 / Grasp success rate
        SimToRealMetric.NAVIGATION_ERROR: 50.0,         # 내비게이션 오차 (mm) / Navigation error (mm)
    })
    domain_randomization_enabled: bool = True           # 도메인 랜덤화 활성 / Domain randomization enabled
    domain_randomization_params: Dict[str, Tuple[float, float]] = field(default_factory=lambda: {
        "friction_range": (0.3, 1.0),
        "mass_range": (0.8, 1.2),
        "lighting_range": (0.5, 1.5),
        "texture_variation": (0.0, 1.0),
        "sensor_noise_range": (0.0, 0.05),
    })
    sim_to_real_adaptation_method: str = "system_identification"  # 적응 방법 / Adaptation method
    reality_gap_threshold: float = 0.2                  # 현실 갭 임계 / Reality gap threshold
    auto_calibration_on_deploy: bool = True             # 배포 시 자동 보정 / Auto calibration on deploy
    calibration_sequence_duration_s: float = 30.0       # 보정 시퀀스 시간 (s) / Calibration sequence duration


@dataclass
class SupplyChainConfig:
    """
    공급망 설정 / Supply Chain & Sourcing Configuration
    학생 예산 ~5M KRW 기준 실전 조달 가이드
    Practical sourcing guide for student budget ~5M KRW
    """
    # --- Budget / 예산 ---
    total_budget_krw: float = 5000000.0                # 총 예산 (원) / Total budget (KRW)
    budget_allocation: Dict[str, float] = field(default_factory=lambda: {
        "3d_printing": 1200000.0,           # 3D 프린팅 (원) / 3D printing (24%)
        "electronics": 1500000.0,           # 전자부품 (원) / Electronics (30%)
        "motors_actuators": 800000.0,       # 모터/액추에이터 (원) / Motors & actuators (16%)
        "sensors": 500000.0,                # 센서 (원) / Sensors (10%)
        "tools_assembly": 300000.0,         # 공구/조립 (원) / Tools & assembly (6%)
        "battery_power": 400000.0,          # 배터리/전원 (원) / Battery & power (8%)
        "contingency": 300000.0,            # 예비비 (원) / Contingency (6%)
    })

    # --- 3D Printing Service Recommendations / 3D 프린팅 서비스 추천 ---
    printing_services: Dict[str, Dict[str, str]] = field(default_factory=lambda: {
        "디스토어": {
            "url": "https://www.dstore.kr",
            "specialty": "SLA/FDM 소량생산 / SLA/FDM small batch",
            "price_range": "저렴~중간 / Low~Mid",
            "lead_time": "3-5 영업일 / 3-5 business days",
            "quality": "우수 / Excellent",
            "notes": "한국 서비스, 한글 지원, 학생 할인 가능 / Korean service, Korean support, student discount possible",
        },
        "크리에이티브파크": {
            "url": "https://www.creativepark.kr",
            "specialty": "FDM/PETG/Nylon / FDM/PETG/Nylon",
            "price_range": "중간 / Mid",
            "lead_time": "5-7 영업일 / 5-7 business days",
            "quality": "양호 / Good",
            "notes": "다양한 재료 선택 / Wide material selection",
        },
        "3D인사이드": {
            "url": "https://www.3dinside.co.kr",
            "specialty": "SLS/SLA 고정밀 / SLS/SLA high precision",
            "price_range": "중간~고가 / Mid~High",
            "lead_time": "5-10 영업일 / 5-10 business days",
            "quality": "최상 / Premium",
            "notes": "기능 부품에 적합 / Suitable for functional parts",
        },
        "크래프트리": {
            "url": "https://www.craftree.com",
            "specialty": "SLA 고해상도 / SLA high resolution",
            "price_range": "중간 / Mid",
            "lead_time": "3-5 영업일 / 3-5 business days",
            "quality": "우수 / Excellent",
            "notes": "소형 정밀 부품에 추천 / Recommended for small precision parts",
        },
    })

    # --- Material Sourcing / 재료 조달 ---
    material_sources: Dict[str, Dict[str, str]] = field(default_factory=lambda: {
        "AliExpress": {
            "url": "https://www.aliexpress.com",
            "items": "전자부품, 서보모터, 센서, 배터리 / Electronics, servos, sensors, batteries",
            "price_range": "저렴 / Low",
            "lead_time": "2-4 주 / 2-4 weeks",
            "notes": "배송 오래 걸림, 품질 변동 / Long shipping, quality varies; 미리 주문 / Order early",
        },
        "로보링크": {
            "url": "https://www.robotis.com",
            "items": "다이나믹셀 서보, 로봇 키트 / Dynamixel servos, robot kits",
            "price_range": "중간~고가 / Mid~High",
            "lead_time": "2-3 영업일 / 2-3 business days",
            "notes": "국내 배송 빠름, 품질 보증 / Fast domestic shipping, quality guaranteed",
        },
        "디센트": {
            "url": "https://www.devicemart.co.kr",
            "items": "전자부품, 개발보드, 센서 / Electronic components, dev boards, sensors",
            "price_range": "중간 / Mid",
            "lead_time": "1-2 영업일 / 1-2 business days",
            "notes": "국내 최대 전자부품 쇼핑몰 / Largest domestic electronics mall",
        },
        "엘레파츠": {
            "url": "https://www.eleparts.co.kr",
            "items": "수동소자, 커넥터, PCB / Passive components, connectors, PCB",
            "price_range": "저렴~중간 / Low~Mid",
            "lead_time": "1-2 영업일 / 1-2 business days",
            "notes": "PCB 제작 서비스 가능 / PCB fabrication service available",
        },
        "메카솔루션": {
            "url": "https://www.mechasolution.com",
            "items": "3D 프린터 필라멘트, 기구부품 / 3D printer filament, mechanical parts",
            "price_range": "중간 / Mid",
            "lead_time": "2-3 영업일 / 2-3 business days",
            "notes": "필라멘트 전문, 다양한 재료 / Filament specialty, various materials",
        },
    })

    # --- Assembly Tools / 조립 공구 ---
    assembly_tools: List[Dict[str, str]] = field(default_factory=lambda: [
        {
            "tool": "토크 드라이버 / Torque driver",
            "spec": "1-10 Nm 범위 / 1-10 Nm range",
            "source": "다이소 또는 AliExpress / Daiso or AliExpress",
            "price_krw": "15000-30000",
            "priority": "필수 / Required",
        },
        {
            "tool": "디지털 멀티미터 / Digital multimeter",
            "spec": "정밀도 0.1mV / 0.1mV precision",
            "source": "디센트 또는 엘레파츠 / Devicemart or Eleparts",
            "price_krw": "20000-50000",
            "priority": "필수 / Required",
        },
        {
            "tool": "인두기 / Soldering iron",
            "spec": "온도 조절식 60W / Temp-controlled 60W",
            "source": "AliExpress (FX-951 호환) / AliExpress (FX-951 compatible)",
            "price_krw": "30000-80000",
            "priority": "필수 / Required",
        },
        {
            "tool": "열수축튜브 세트 / Heat shrink tube set",
            "spec": "다양한 직경 / Various diameters",
            "source": "AliExpress / AliExpress",
            "price_krw": "5000-10000",
            "priority": "권장 / Recommended",
        },
        {
            "tool": "와이어 스트리퍼 / Wire stripper",
            "spec": "AWG 10-26 / AWG 10-26",
            "source": "디센트 / Devicemart",
            "price_krw": "10000-20000",
            "priority": "권장 / Recommended",
        },
        {
            "tool": "크림프 공구 세트 / Crimp tool set",
            "spec": "JST/Molex/D-Sub / JST/Molex/D-Sub",
            "source": "AliExpress / AliExpress",
            "price_krw": "20000-40000",
            "priority": "권장 / Recommended",
        },
        {
            "tool": "6각 렌치 세트 / Hex wrench set",
            "spec": "1.5-8mm / 1.5-8mm",
            "source": "다이소 / Daiso",
            "price_krw": "5000-10000",
            "priority": "필수 / Required",
        },
        {
            "tool": "레이저 온도계 / IR thermometer",
            "spec": "-50~380°C / -50~380°C",
            "source": "AliExpress / AliExpress",
            "price_krw": "15000-30000",
            "priority": "선택 / Optional",
        },
        {
            "tool": "오실로스코프 / Oscilloscope",
            "spec": "2채널 100MHz / 2-ch 100MHz",
            "source": "AliExpress (FNIRSI 등) / AliExpress (FNIRSI etc.)",
            "price_krw": "100000-200000",
            "priority": "선택 / Optional",
        },
        {
            "tool": "3D 프린터 (선택) / 3D printer (optional)",
            "spec": "FDM, 200x200x200mm 이상 / FDM, 200x200x200mm+",
            "source": "AliExpress (Ender3/Voxelab) / AliExpress",
            "price_krw": "200000-400000",
            "priority": "선택 (외부 서비스로 대체 가능) / Optional (can use external services)",
        },
    ])


# ==============================================================================
# Main Robot Configuration / 메인 로봇 설정
# ==============================================================================

@dataclass
class JihunRobotV85Config:
    """
    지훈 로봇 V8.5 — Physical AGI Platform 메인 설정
    Jihun Robot V8.5 — Physical AGI Platform Main Configuration

    V8.5는 Physical AGI를 향한 진화적 도약입니다.
    V8.5 represents an evolutionary leap toward Physical AGI.

    안지훈 (보성중학교 2학년 4반 10번) — 예산 500만원으로 대기업 극복
    Jihun Ahn (Boseong MS Gr.2 Cl.4 #10) — Beat big companies with 5M KRW
    """
    # --- Identity / 식별 ---
    version: str = VERSION                                   # 버전 / Version
    model: RobotModel = RobotModel.JIHUN_V85                 # 모델 / Model
    serial_number: str = "JH-V85-00001"                      # 시리얼 번호 / Serial number
    build_date: str = "2025-03-04"                            # 빌드 날짜 / Build date

    # --- V8 Legacy Configs (preserved) / V8 레거시 설정 (보존) ---
    motors: Dict[str, MotorConfig] = field(default_factory=dict)
    sensors: Dict[str, SensorConfig] = field(default_factory=dict)
    actuators: Dict[str, ActuatorConfig] = field(default_factory=dict)
    power: PowerConfig = field(default_factory=PowerConfig)
    communication: CommunicationConfig = field(default_factory=CommunicationConfig)
    compute: ComputeConfig = field(default_factory=ComputeConfig)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    battery: BatteryConfig = field(default_factory=BatteryConfig)
    locomotion: LocomotionConfig = field(default_factory=LocomotionConfig)
    vision: VisionConfig = field(default_factory=VisionConfig)
    audio: AudioConfig = field(default_factory=AudioConfig)

    # --- V8.5 Configs (preserved in V8.5) / V8.5 설정 (V8.5에서 보존) ---
    solder_free: SolderFreeConfig = field(default_factory=SolderFreeConfig)
    structural_integrity: StructuralIntegrityConfig = field(default_factory=StructuralIntegrityConfig)
    environmental_hardening: EnvironmentalHardeningConfig = field(default_factory=EnvironmentalHardeningConfig)
    physical_agi: PhysicalAGIConfig = field(default_factory=PhysicalAGIConfig)
    supply_chain: SupplyChainConfig = field(default_factory=SupplyChainConfig)

    # --- V8.5 NEW Configs / V8.5 신규 설정 ---
    vla: VLAConfig = field(default_factory=VLAConfig)
    data_pipeline: DataPipelineConfig = field(default_factory=DataPipelineConfig)

    # --- System Flags / 시스템 플래그 ---
    simulation_mode: bool = False                            # 시뮬레이션 모드 / Simulation mode
    debug_mode: bool = False                                 # 디버그 모드 / Debug mode
    maintenance_mode: bool = False                           # 유지보수 모드 / Maintenance mode
    physical_agi_enabled: bool = True                        # Physical AGI 활성 / Physical AGI enabled
    safety_override: bool = False                            # 안전 오버라이드 (진단만) / Safety override (diagnostic only)

    def get_safety_layer_count(self) -> int:
        """현재 안전 계층 수 반환 / Return current safety layer count"""
        return self.safety.safety_layer_count

    def get_active_configs_summary(self) -> Dict[str, bool]:
        """활성 설정 요약 반환 / Return summary of active configurations"""
        return {
            "solder_free_monitoring": self.solder_free.resistance_measurement_interval_s > 0,
            "structural_integrity": self.structural_integrity.cog_monitoring_enabled,
            "environmental_hardening": self.environmental_hardening.dust_monitoring_enabled,
            "physical_agi": self.physical_agi.task_generalization_enabled,
            "cell_balancing": self.battery.cell_balancing_enabled,
            "thermal_runaway_prevention": self.battery.thermal_runaway_prevention_enabled,
            "regeneration": self.battery.regeneration_enabled,
            "vla_model": self.vla.model_name != "",
            "data_pipeline": self.data_pipeline.sim_data_source != "",
        }

    def validate(self) -> Tuple[bool, List[str]]:
        """
        설정 무결성 검증 / Validate configuration integrity
        Returns (is_valid, list_of_errors)
        """
        errors: List[str] = []

        # 버전 확인 / Version check
        if self.version != VERSION:
            errors.append(f"버전 불일치 / Version mismatch: {self.version} != {VERSION}")

        # 배터리 전압 검증 / Battery voltage validation
        if self.battery.min_voltage_v >= self.battery.nominal_voltage_v:
            errors.append(
                f"배터리 최소전압({self.battery.min_voltage_v}V)이 "
                f"공칭전압({self.battery.nominal_voltage_v}V) 이상임 / "
                f"Battery min voltage >= nominal voltage"
            )

        # 안전 온도 검증 / Safety temperature validation
        if self.safety.thermal_shutdown_c <= self.battery.cell_critical_temp_c:
            errors.append(
                f"안전 열종료({self.safety.thermal_shutdown_c}°C)가 "
                f"배터리 위험온도({self.battery.cell_critical_temp_c}°C) 이하임 / "
                f"Safety thermal shutdown <= battery critical temp"
            )

        # 작업 공간 검증 / Workspace validation
        if self.safety.workspace_radius_mm <= 0:
            errors.append("작업공간 반경이 0 이하 / Workspace radius <= 0")

        # 무게중심 검증 / CoG validation
        if self.structural_integrity.cog_critical_threshold_percent <= self.structural_integrity.cog_warning_threshold_percent:
            errors.append(
                "무게중심 위험 임계값이 경고 임계값 이하 / "
                "CoG critical threshold <= warning threshold"
            )

        # 예산 검증 / Budget validation
        allocated = sum(self.supply_chain.budget_allocation.values())
        if abs(allocated - self.supply_chain.total_budget_krw) > 1000:
            errors.append(
                f"예산 할당 합계({allocated:,.0f}원)가 총 예산({self.supply_chain.total_budget_krw:,.0f}원)과 "
                f"불일치 / Budget allocation sum != total budget"
            )

        # 셀 밸런싱 검증 / Cell balancing validation
        if self.battery.cell_balancing_enabled and self.battery.cell_balance_threshold_mv <= 0:
            errors.append("셀 밸런싱 임계값이 0 이하 / Cell balance threshold <= 0")

        # E-Stop 검증 / E-Stop validation
        if self.safety.estop_circuit_continuity_check_ms <= 0:
            errors.append("E-Stop 회로 검사 주기가 0 이하 / E-Stop circuit check interval <= 0")

        # 프레임 재료 검증 / Frame material validation
        if self.structural_integrity.frame_thermal_coefficient_per_c <= 0:
            errors.append("프레임 열팽창계수가 0 이하 / Frame thermal coefficient <= 0")

        # Physical AGI 검증 / Physical AGI validation
        if self.physical_agi.task_generalization_enabled:
            if self.physical_agi.zero_shot_success_threshold_percent > 100.0:
                errors.append("제로샷 성공 임계값이 100% 초과 / Zero-shot threshold > 100%")
            if self.physical_agi.knowledge_retention_percent > 100.0:
                errors.append("지식 유지율이 100% 초과 / Knowledge retention > 100%")

        # V8.5 NEW: VLA 검증 / V8.5 NEW: VLA validation
        if self.vla.inference_latency_target_ms <= 0:
            errors.append("VLA 추론 지연 목표가 0 이하 / VLA inference latency target <= 0")

        # V8.5 NEW: Data Pipeline 검증 / V8.5 NEW: Data Pipeline validation
        if self.data_pipeline.dream_training_steps < 0:
            errors.append("드림 학습 스텝 수가 음수 / Dream training steps < 0")

        # V8.5 NEW: Budget 검증 / V8.5 NEW: Budget validation
        if self.physical_agi.budget_limit_krw <= 0:
            errors.append("예산 한도가 0 이하 / Budget limit <= 0")

        # V8.5 NEW: Sim-to-Real gap target 검증 / V8.5 NEW: Sim-to-Real gap target validation
        if not (0.0 < self.physical_agi.sim_to_real_gap_target <= 1.0):
            errors.append("Sim-to-Real 갭 목표가 0~1 범위 밖 / Sim-to-Real gap target outside 0~1 range")

        is_valid = len(errors) == 0
        return is_valid, errors


# ==============================================================================
# Factory Functions / 팩토리 함수
# ==============================================================================

def create_default_config() -> JihunRobotV85Config:
    """기본 V8.5 설정 생성 / Create default V8.5 configuration"""
    config = JihunRobotV85Config()

    # 기본 모터 설정 / Default motor configurations
    config.motors = {
        "left_shoulder": MotorConfig(
            motor_id="M001", motor_type=MotorType.SERVO,
            max_rpm=3000.0, max_torque_nm=4.1, rated_voltage=12.0,
            gear_ratio=100.0, min_angle_deg=-180.0, max_angle_deg=180.0,
        ),
        "right_shoulder": MotorConfig(
            motor_id="M002", motor_type=MotorType.SERVO,
            max_rpm=3000.0, max_torque_nm=4.1, rated_voltage=12.0,
            gear_ratio=100.0, min_angle_deg=-180.0, max_angle_deg=180.0,
        ),
        "left_elbow": MotorConfig(
            motor_id="M003", motor_type=MotorType.SERVO,
            max_rpm=3000.0, max_torque_nm=2.5, rated_voltage=12.0,
            gear_ratio=50.0, min_angle_deg=-135.0, max_angle_deg=135.0,
        ),
        "right_elbow": MotorConfig(
            motor_id="M004", motor_type=MotorType.SERVO,
            max_rpm=3000.0, max_torque_nm=2.5, rated_voltage=12.0,
            gear_ratio=50.0, min_angle_deg=-135.0, max_angle_deg=135.0,
        ),
        "left_wrist": MotorConfig(
            motor_id="M005", motor_type=MotorType.SERVO,
            max_rpm=6000.0, max_torque_nm=1.0, rated_voltage=12.0,
            gear_ratio=20.0, min_angle_deg=-180.0, max_angle_deg=180.0,
        ),
        "right_wrist": MotorConfig(
            motor_id="M006", motor_type=MotorType.SERVO,
            max_rpm=6000.0, max_torque_nm=1.0, rated_voltage=12.0,
            gear_ratio=20.0, min_angle_deg=-180.0, max_angle_deg=180.0,
        ),
        "head_pan": MotorConfig(
            motor_id="M007", motor_type=MotorType.SERVO,
            max_rpm=6000.0, max_torque_nm=0.5, rated_voltage=12.0,
            gear_ratio=30.0, min_angle_deg=-160.0, max_angle_deg=160.0,
        ),
        "head_tilt": MotorConfig(
            motor_id="M008", motor_type=MotorType.SERVO,
            max_rpm=6000.0, max_torque_nm=0.5, rated_voltage=12.0,
            gear_ratio=30.0, min_angle_deg=-45.0, max_angle_deg=45.0,
        ),
    }

    # 기본 센서 설정 / Default sensor configurations
    config.sensors = {
        "imu_torso": SensorConfig(
            sensor_id="S001", sensor_type=SensorType.IMU,
            i2c_address=0x68, sample_rate_hz=200.0,
        ),
        "imu_head": SensorConfig(
            sensor_id="S002", sensor_type=SensorType.IMU,
            i2c_address=0x69, sample_rate_hz=200.0,
        ),
        "camera_left": SensorConfig(
            sensor_id="S003", sensor_type=SensorType.IMU,
            sample_rate_hz=30.0,
        ),
        "camera_depth": SensorConfig(
            sensor_id="S004", sensor_type=SensorType.CAMERA_DEPTH,
            sample_rate_hz=30.0,
        ),
        "force_left": SensorConfig(
            sensor_id="S005", sensor_type=SensorType.FORCE_TORQUE,
            sample_rate_hz=1000.0,
        ),
        "force_right": SensorConfig(
            sensor_id="S006", sensor_type=SensorType.FORCE_TORQUE,
            sample_rate_hz=1000.0,
        ),
        "temp_main": SensorConfig(
            sensor_id="S007", sensor_type=SensorType.TEMPERATURE,
            sample_rate_hz=1.0,
        ),
        "humidity_main": SensorConfig(
            sensor_id="S008", sensor_type=SensorType.HUMIDITY,
            sample_rate_hz=1.0,
        ),
    }

    return config


def create_simulation_config() -> JihunRobotV85Config:
    """시뮬레이션 모드 설정 생성 / Create simulation-mode configuration"""
    config = create_default_config()
    config.simulation_mode = True
    config.safety.safety_override = True
    config.physical_agi.sim_environment = "isaac_sim_v85"
    return config


def create_minimal_config() -> JihunRobotV85Config:
    """최소 설정 생성 (테스트용) / Create minimal configuration (for testing)"""
    config = JihunRobotV85Config()
    config.debug_mode = True
    config.safety.safety_override = True
    config.battery.cell_balancing_enabled = False
    config.battery.thermal_runaway_prevention_enabled = False
    config.battery.regeneration_enabled = False
    config.structural_integrity.cog_monitoring_enabled = False
    config.structural_integrity.vibration_monitoring_enabled = False
    config.structural_integrity.anchor_bolt_monitoring_enabled = False
    config.structural_integrity.thermal_expansion_compensation = False
    config.structural_integrity.frame_creep_detection_enabled = False
    config.environmental_hardening.dust_monitoring_enabled = False
    config.environmental_hardening.lens_degradation_detection = False
    config.environmental_hardening.humidity_migration_prevention = False
    config.environmental_hardening.insect_intrusion_detection = False
    config.environmental_hardening.estop_circuit_continuity = False
    config.solder_free.delamination_detection_enabled = False
    config.solder_free.pin_oxidation_monitoring = False
    config.physical_agi.task_generalization_enabled = False
    config.physical_agi.cross_domain_transfer_enabled = False
    config.physical_agi.experience_collection_enabled = False
    config.physical_agi.sim_to_real_monitoring_enabled = False
    return config


# ==============================================================================
# Module-level default instance / 모듈 수준 기본 인스턴스
# ==============================================================================

# 기본 설정 인스턴스 (지연 생성) / Default config instance (lazy)
_default_config: Optional[JihunRobotV85Config] = None


def get_default_config() -> JihunRobotV85Config:
    """싱글톤 기본 설정 반환 / Return singleton default configuration"""
    global _default_config
    if _default_config is None:
        _default_config = create_default_config()
    return _default_config


def reset_default_config() -> None:
    """기본 설정 초기화 / Reset default configuration"""
    global _default_config
    _default_config = None


# ==============================================================================
# Module Exports / 모듈 익스포트
# ==============================================================================

__all__ = [
    # Version
    "VERSION",
    # Enums
    "RobotModel",
    "SafetyLayer",
    "MotorType",
    "SensorType",
    "BatteryChemistry",
    "FilamentType",
    "CrossContaminationLevel",
    "EMIHardeningLevel",
    "DelaminationSeverity",
    "TaskDomain",
    "SimToRealMetric",
    "FrameCreepLevel",
    # V8 Legacy Configs
    "MotorConfig",
    "SensorConfig",
    "ActuatorConfig",
    "PowerConfig",
    "CommunicationConfig",
    "ComputeConfig",
    "SafetyConfig",
    "BatteryConfig",
    "LocomotionConfig",
    "VisionConfig",
    "AudioConfig",
    # V8.5 Configs (preserved in V8.5)
    "SolderFreeConfig",
    "StructuralIntegrityConfig",
    "EnvironmentalHardeningConfig",
    "PhysicalAGIConfig",
    "SupplyChainConfig",
    # V8.5 NEW Configs
    "VLAConfig",
    "DataPipelineConfig",
    # Main Config
    "JihunRobotV85Config",
    # Factory Functions
    "create_default_config",
    "create_simulation_config",
    "create_minimal_config",
    "get_default_config",
    "reset_default_config",
]
