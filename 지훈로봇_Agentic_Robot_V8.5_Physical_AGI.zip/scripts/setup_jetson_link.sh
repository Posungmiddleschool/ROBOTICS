#!/bin/bash
# ============================================================================
# 지훈 로봇 V8.5 — TODO 2: Jetson 간 이더넷 1Gbps 직결 통신 설정
# ============================================================================
# RJ45 크로스케이블 (Auto MDI-X) 직결
# Jetson #1: 192.168.1.1, Jetson #2: 192.168.1.2
#
# 검증: ping < 0.5ms, iperf3 > 900Mbps
#
# 작성일: 2026-05-19
# 버전: V8.5
# 라이선스: MIT
# ============================================================================

set -e

JIHUN_DIR="/opt/jihun"
ETH_IFACE="eth0"
IP_J1="192.168.1.1"
IP_J2="192.168.1.2"
SUBNET="24"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step()  { echo -e "${BLUE}[STEP]${NC} $1"; }

# ============================================================================
# 1. Jetson ID 확인
# ============================================================================

log_step "Jetson ID 확인"

if [ ! -f "${JIHUN_DIR}/jetson_id" ]; then
    log_error "Jetson ID 미설정 — setup_jetson.sh 먼저 실행"
    exit 1
fi

JETSON_ID=$(cat "${JIHUN_DIR}/jetson_id")

if [ "${JETSON_ID}" = "1" ]; then
    LOCAL_IP="${IP_J1}"
    REMOTE_IP="${IP_J2}"
    log_info "Jetson #1 (대뇌): ${LOCAL_IP} → ${REMOTE_IP}"
elif [ "${JETSON_ID}" = "2" ]; then
    LOCAL_IP="${IP_J2}"
    REMOTE_IP="${IP_J1}"
    log_info "Jetson #2 (소뇌): ${LOCAL_IP} → ${REMOTE_IP}"
else
    log_error "알 수 없는 Jetson ID: ${JETSON_ID}"
    exit 1
fi

# ============================================================================
# 2. 이더넷 인터페이스 확인
# ============================================================================

log_step "이더넷 인터페이스 확인"

if ! ip link show ${ETH_IFACE} &> /dev/null; then
    log_error "이더넷 인터페이스 ${ETH_IFACE} 없음"
    # 사용 가능한 이더넷 인터페이스 찾기
    log_info "사용 가능한 인터페이스:"
    ip -br link show | grep -E "eth|enp"
    exit 1
fi

log_info "이더넷 인터페이스: ${ETH_IFACE}"

# ============================================================================
# 3. 정적 IP 설정
# ============================================================================

log_step "정적 IP 설정: ${LOCAL_IP}/${SUBNET}"

# 인터페이스 활성화
sudo ip link set ${ETH_IFACE} up

# 기존 IP 제거
sudo ip addr flush dev ${ETH_IFACE}

# 정적 IP 설정
sudo ip addr add ${LOCAL_IP}/${SUBNET} dev ${ETH_IFACE}

log_info "정적 IP 설정 완료: ${LOCAL_IP}/${SUBNET}"

# ============================================================================
# 4. NetworkManager 프로파일 저장 (재부팅 시 유지)
# ============================================================================

log_step "NetworkManager 프로파일 저장"

CONN_NAME="jihun-jetson-link"

# 기존 연결 삭제
sudo nmcli connection delete "${CONN_NAME}" 2>/dev/null || true

# 새 연결 생성
sudo nmcli connection add \
    type ethernet \
    ifname ${ETH_IFACE} \
    con-name "${CONN_NAME}" \
    ipv4.method manual \
    ipv4.addresses "${LOCAL_IP}/${SUBNET}" \
    connection.autoconnect true 2>/dev/null || \
    log_warn "nmcli 설정 불가 — 수동 IP 설정으로 계속"

# ============================================================================
# 5. MTU 최적화 (Jumbo Frame)
# ============================================================================

log_step "MTU 최적화"

sudo ip link set ${ETH_IFACE} mtu 9000 2>/dev/null && \
    log_info "MTU 9000 (Jumbo Frame) 설정" || \
    log_warn "MTU 9000 설정 불가 — 표준 MTU 1500 사용"

# ============================================================================
# 6. ping 테스트
# ============================================================================

log_step "ping 테스트: ${REMOTE_IP}"

echo "상대방 Jetson이 부팅 중인지 확인..."
for i in $(seq 1 10); do
    if ping -c 1 -W 1 ${REMOTE_IP} &> /dev/null; then
        log_info "ping 성공! 상세 측정 중..."
        PING_RESULT=$(ping -c 10 -i 0.1 ${REMOTE_IP} 2>/dev/null | tail -1)
        log_info "ping 결과: ${PING_RESULT}"
        break
    else
        echo -n "."
    fi
done
echo ""

if ! ping -c 1 -W 2 ${REMOTE_IP} &> /dev/null; then
    log_warn "상대방 Jetson 응답 없음 — 이더넷 케이블 연결 확인"
    log_warn "상대방에서도 이 스크립트를 실행했는지 확인"
fi

# ============================================================================
# 7. iperf3 대역폭 테스트
# ============================================================================

log_step "iperf3 대역폭 테스트"

if command -v iperf3 &> /dev/null; then
    log_info "iperf3 설치됨"
    log_info "대역폭 테스트:"
    log_info "  서버측: iperf3 -s"
    log_info "  클라이언트측: iperf3 -c ${REMOTE_IP} -t 5"
else
    log_warn "iperf3 미설치 — 설치: sudo apt-get install iperf3"
fi

# ============================================================================
# 8. ROS2 DDS 설정
# ============================================================================

log_step "ROS2 DDS (Fast-RTPS) 설정"

mkdir -p "${JIHUN_DIR}"

# Fast-RTPS 프로파일
cat > "${JIHUN_DIR}/fast_rtps_profile.xml" << 'EOF'
<?xml version="1.0" encoding="UTF-8" ?>
<dds>
    <profiles xmlns="http://www.eprosima.com/XMLSchemas/fastRTPS_Profiles">
        <transport_descriptors>
            <transport_descriptor>
                <transport_id>udp_transport</transport_id>
                <type>UDPv4</type>
                <sendBufferSize>1048576</sendBufferSize>
                <receiveBufferSize>4194304</receiveBufferSize>
            </transport_descriptor>
        </transport_descriptors>
        <participant profile_name="jihun_participant" is_default_profile="true">
            <rtps>
                <useBuiltinTransports>false</useBuiltinTransports>
                <userTransports>
                    <transport_id>udp_transport</transport_id>
                </userTransports>
            </rtps>
        </participant>
    </profiles>
</dds>
EOF

# DDS 환경 변수
cat > "${JIHUN_DIR}/dds_env.sh" << EOF
export FASTRTPS_DEFAULT_PROFILES_FILE="${JIHUN_DIR}/fast_rtps_profile.xml"
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
export ROS_DOMAIN_ID=42
export ROS_AUTOMATIC_DISCOVERY_RANGE=SUBNET
EOF

chmod +x "${JIHUN_DIR}/dds_env.sh"
log_info "DDS 설정 완료: ${JIHUN_DIR}/dds_env.sh"

# ============================================================================
# 완료
# ============================================================================

log_info "========================================"
log_info "이더넷 직결 통신 설정 완료!"
log_info "  로컬 IP: ${LOCAL_IP}/${SUBNET}"
log_info "  원격 IP: ${REMOTE_IP}"
log_info "  인터페이스: ${ETH_IFACE}"
log_info "  DDS: ${JIHUN_DIR}/dds_env.sh"
log_info "========================================"
