#!/bin/bash
# ============================================================================
# 지훈 로봇 V8.5 — TODO 5: CAN 버스 MCP2515 초기화 스크립트
# ============================================================================
# SPI → MCP2515 → CAN 트랜시버 → 120Ω 종단 저항 → MKS XDRIVE
# CAN 2.0B 1Mbps 안정 통신
#
# 작성일: 2026-05-19
# 버전: V8.5
# 라이선스: MIT
# ============================================================================

set -e

JIHUN_DIR="/opt/jihun"
CAN_IFACE="can0"
CAN_BITRATE="1000000"    # 1Mbps

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step()  { echo -e "${BLUE}[STEP]${NC} $1"; }

# ============================================================================
# 1. SPI 장치 확인
# ============================================================================

log_step "SPI 장치 확인"

# MCP2515는 SPI1에 연결 (IMU ICM-42688-P와 공유)
if [ -c /dev/spidev1.0 ]; then
    log_info "SPI1.0 감지됨 (IMU용)"
else
    log_warn "SPI1.0 없음 — ICM-42688-P IMU와 공유"
fi

if [ -c /dev/spidev1.1 ]; then
    log_info "SPI1.1 감지됨 (MCP2515용)"
else
    log_warn "SPI1.1 없음 — MCP2515 연결 확인"
fi

# SPI 커널 모듈 로드
sudo modprobe spidev 2>/dev/null || true

# ============================================================================
# 2. MCP2515 Device Tree 오버레이 로드
# ============================================================================

log_step "MCP2515 Device Tree 오버레이"

# Jetson MCP2515 오버레이 로드 (있는 경우)
if [ -f /boot/dtb/tegra234-p3768-0000+p3768-0000.dtb ]; then
    log_info "Jetson Orin NX DTB 확인"
fi

# MCP2515 오버레이 수동 로드 시도
sudo dtoverlay mcp2515-can0 2>/dev/null && \
    log_info "MCP2515 오버레이 로드 성공" || \
    log_warn "MCP2515 오버레이 자동 로드 불가 — 수동 설정 필요"

# ============================================================================
# 3. CAN 인터페이스 설정
# ============================================================================

log_step "CAN 인터페이스 설정: ${CAN_IFACE} @ ${CAN_BITRATE}bps"

# 기존 인터페이스 다운
sudo ip link set ${CAN_IFACE} down 2>/dev/null || true

# CAN 비트레이트 및 재시작 설정
sudo ip link set ${CAN_IFACE} type can \
    bitrate ${CAN_BITRATE} \
    restart-ms 100 \
    berr-reporting on 2>/dev/null || \
    log_warn "CAN 설정 실패 — MCP2515 드라이버 확인 필요"

# CAN 인터페이스 업
sudo ip link set ${CAN_IFACE} up

# 상태 확인
sleep 1
if ip link show ${CAN_IFACE} | grep -q "UP"; then
    log_info "CAN 인터페이스 활성화 성공: ${CAN_IFACE}"
    ip -d link show ${CAN_IFACE}
else
    log_error "CAN 인터페이스 활성화 실패"
    exit 1
fi

# ============================================================================
# 4. CAN 종단 저항 확인
# ============================================================================

log_step "CAN 종단 저항 확인 (120Ω × 2)"

log_info "CAN 종단 저항은 하드웨어적으로 연결되어야 합니다"
log_info "  CAN-H ↔ CAN-L 간 저항 ≈ 60Ω (120Ω 병렬 2개 = 정상)"
log_info "  멀티미터로 측정 후 확인 필요"

# ============================================================================
# 5. 루프백 테스트
# ============================================================================

log_step "CAN 루프백 테스트"

# 루프백 모드 설정
sudo ip link set ${CAN_IFACE} down 2>/dev/null || true
sudo ip link set ${CAN_IFACE} type can \
    bitrate ${CAN_BITRATE} \
    loopback on 2>/dev/null || true
sudo ip link set ${CAN_IFACE} up

sleep 0.5

# 백그라운드에서 수신 대기
timeout 3 candump ${CAN_IFACE} -n 1 > /tmp/can_loopback_test.txt 2>&1 &
DUMP_PID=$!
sleep 0.5

# 테스트 프레임 송신
cansend ${CAN_IFACE} 123#DEADBEEF01020304 2>/dev/null && \
    log_info "테스트 프레임 송신 성공" || \
    log_warn "테스트 프레임 송신 실패"

sleep 1
kill ${DUMP_PID} 2>/dev/null || true

if [ -s /tmp/can_loopback_test.txt ]; then
    log_info "루프백 수신 확인:"
    cat /tmp/can_loopback_test.txt
else
    log_warn "루프백 수신 없음 — 배선/드라이버 점검 필요"
fi

# 루프백 모드 해제
sudo ip link set ${CAN_IFACE} down 2>/dev/null || true
sudo ip link set ${CAN_IFACE} type can \
    bitrate ${CAN_BITRATE} \
    loopback off \
    restart-ms 100 2>/dev/null || true
sudo ip link set ${CAN_IFACE} up

# ============================================================================
# 6. CAN 통계 확인
# ============================================================================

log_step "CAN 통계"

if [ -f /sys/class/net/${CAN_IFACE}/statistics ]; then
    for stat in /sys/class/net/${CAN_IFACE}/statistics/*; do
        echo "  $(basename ${stat}): $(cat ${stat})"
    done
else
    log_info "ip -d -s link show ${CAN_IFACE}:"
    ip -d -s link show ${CAN_IFACE} 2>/dev/null || true
fi

# ============================================================================
# 완료
# ============================================================================

log_info "========================================"
log_info "CAN 버스 초기화 완료!"
log_info "  인터페이스: ${CAN_IFACE}"
log_info "  비트레이트: ${CAN_BITRATE}bps"
log_info "  테스트: cansend ${CAN_IFACE} 123#DEADBEEF"
log_info "  모니터: candump ${CAN_IFACE}"
log_info "========================================"
