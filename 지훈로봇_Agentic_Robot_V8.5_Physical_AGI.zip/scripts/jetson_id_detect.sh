#!/bin/bash
# ============================================================================
# 지훈 로봇 V8.5 — Jetson ID 자동 감지 스크립트
# ============================================================================
# Jetson #1/#2 자동 감지:
#   1. /opt/jihun/jetson_id 파일
#   2. 호스트명 기반
#   3. MAC 주소 기반
#   4. 수동 선택
#
# 작성일: 2026-05-19
# 버전: V8.5
# 라이선스: MIT
# ============================================================================

set -e

JIHUN_DIR="/opt/jihun"
JIHUN_ID_FILE="${JIHUN_DIR}/jetson_id"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step()  { echo -e "${BLUE}[STEP]${NC} $1"; }

# ============================================================================
# 1. 기존 ID 파일 확인
# ============================================================================

if [ -f "${JIHUN_ID_FILE}" ]; then
    EXISTING_ID=$(cat "${JIHUN_ID_FILE}")
    log_info "기존 Jetson ID: #${EXISTING_ID}"
    echo "${EXISTING_ID}"
    exit 0
fi

# ============================================================================
# 2. 호스트명 기반 감지
# ============================================================================

log_step "호스트명 기반 감지"

HOSTNAME=$(hostname | tr '[:upper:]' '[:lower:]')
log_info "호스트명: ${HOSTNAME}"

if echo "${HOSTNAME}" | grep -qE "cerebrum|brain1|jetson1"; then
    JETSON_ID=1
    log_info "호스트명 기반 → Jetson #1 (대뇌)"
elif echo "${HOSTNAME}" | grep -qE "cerebellum|brain2|jetson2"; then
    JETSON_ID=2
    log_info "호스트명 기반 → Jetson #2 (소뇌)"
else
    JETSON_ID=0
    log_info "호스트명으로 감지 불가: ${HOSTNAME}"
fi

# ============================================================================
# 3. MAC 주소 기반 감지
# ============================================================================

if [ "${JETSON_ID}" = "0" ]; then
    log_step "MAC 주소 기반 감지"

    # 첫 번째 이더넷 MAC 주소
    MAC=$(ip link show | grep -A1 "eth0" | grep "link/ether" | awk '{print $2}' | head -1)

    if [ -n "${MAC}" ]; then
        LAST_OCTET=$((16#$(echo ${MAC} | cut -d: -f6)))
        if [ $((LAST_OCTET % 2)) -eq 0 ]; then
            JETSON_ID=1
        else
            JETSON_ID=2
        fi
        log_info "MAC 주소 기반 → Jetson #${JETSON_ID} (MAC: ${MAC}, 마지막 옥텟: ${LAST_OCTET})"
    else
        log_warn "MAC 주소 감지 불가"
    fi
fi

# ============================================================================
# 4. 수동 선택
# ============================================================================

if [ "${JETSON_ID}" = "0" ]; then
    log_warn "자동 감지 실패 — 수동 선택 필요"
    echo ""
    echo "  이 Jetson의 역할을 선택하세요:"
    echo "  1) 대뇌 (Cerebrum) — AI 추론 + 비전 + 플래닝"
    echo "  2) 소뇌 (Cerebellum) — 모터 제어 + STT/TTS + 반사"
    echo ""
    read -p "선택 [1/2]: " USER_CHOICE

    case "${USER_CHOICE}" in
        1) JETSON_ID=1 ;;
        2) JETSON_ID=2 ;;
        *) log_error "잘못된 선택"; exit 1 ;;
    esac
fi

# ============================================================================
# 5. ID 파일 저장
# ============================================================================

mkdir -p "${JIHUN_DIR}"
echo "${JETSON_ID}" | sudo tee "${JIHUN_ID_FILE}" > /dev/null

if [ "${JETSON_ID}" = "1" ]; then
    ROLE="대뇌 (Cerebrum)"
    DESC="Gemma4 + Vision + Planning"
else
    ROLE="소뇌 (Cerebellum)"
    DESC="Motor + STT/TTS + Reflex"
fi

log_info "========================================"
log_info "Jetson #${JETSON_ID} — ${ROLE}"
log_info "역할: ${DESC}"
log_info "ID 파일: ${JIHUN_ID_FILE}"
log_info "========================================"

echo "${JETSON_ID}"
