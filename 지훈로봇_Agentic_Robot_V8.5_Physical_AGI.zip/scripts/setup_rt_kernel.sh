#!/bin/bash
# ============================================================================
# 지훈 로봇 V8.5 — TODO 3: PREEMPT_RT 커널 패치 적용 스크립트
# ============================================================================
# JetPack 6 커널에 PREEMPT_RT 패치 적용
# cyclictest <50μs 지터 검증
#
# 작성일: 2026-05-19
# 버전: V8.5
# 라이선스: MIT
# ============================================================================

set -e

JIHUN_DIR="/opt/jihun"
KERNEL_SRC="/usr/src/kernel"
RT_IMAGE="/boot/Image.rt"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step()  { echo -e "${BLUE}[STEP]${NC} $1"; }

# ============================================================================
# 1. 현재 커널 확인
# ============================================================================

log_step "현재 커널 확인"

KERNEL_VERSION=$(uname -r)
log_info "커널 버전: ${KERNEL_VERSION}"

if grep -q "PREEMPT_RT" /proc/version; then
    log_info "이미 PREEMPT_RT 커널 실행 중!"
    exit 0
else
    log_warn "현재 커널은 PREEMPT_RT가 아님"
fi

# ============================================================================
# 2. RT 커널 이미지 확인
# ============================================================================

log_step "RT 커널 이미지 확인"

if [ -f "${RT_IMAGE}" ]; then
    log_info "RT 커널 이미지 존재: ${RT_IMAGE}"
    log_info "RT 커널로 부팅하려면:"
    log_info "  sudo cp ${RT_IMAGE} /boot/Image"
    log_info "  sudo reboot"
    exit 0
fi

# ============================================================================
# 3. 커널 소스 확인
# ============================================================================

log_step "커널 소스 확인"

if [ ! -d "${KERNEL_SRC}" ]; then
    log_error "커널 소스 디렉토리 없음: ${KERNEL_SRC}"
    log_info "설치: sudo apt-get install nvidia-l4t-kernel-headers"
    exit 1
fi

cd "${KERNEL_SRC}"
log_info "커널 소스: ${KERNEL_SRC}"

# ============================================================================
# 4. RT 패치 다운로드
# ============================================================================

log_step "RT 패치 다운로드"

# 커널 베이스 버전 추출
KERNEL_BASE=$(echo ${KERNEL_VERSION} | grep -oP '^\d+\.\d+' || echo "5.15")
log_info "커널 베이스 버전: ${KERNEL_BASE}"

RT_PATCH_BASE="https://cdn.kernel.org/pub/linux/kernel/projects/rt/${KERNEL_BASE}/"
log_info "RT 패치 경로: ${RT_PATCH_BASE}"
log_info "최신 RT 패치를 수동으로 다운로드 후 아래 단계 실행"

# ============================================================================
# 5. RT 커널 빌드 안내
# ============================================================================

log_step "RT 커널 빌드 절차"
echo ""
echo "  cd ${KERNEL_SRC}"
echo "  # RT 패치 다운로드"
echo "  wget <RT_PATCH_URL>/patch-<version>-rt<patch>.patch.xz"
echo "  xz -d patch-*.patch.xz"
echo ""
echo "  # 패치 적용"
echo "  patch -p1 < patch-*.patch"
echo ""
echo "  # 커널 설정"
echo "  make menuconfig"
echo "  # General setup → Preemption Model → Fully Preemptible Kernel (Real-Time)"
echo ""
echo "  # 빌드"
echo "  make -j\$(nproc) Image"
echo ""
echo "  # 설치"
echo "  sudo cp arch/arm64/boot/Image ${RT_IMAGE}"
echo "  sudo cp arch/arm64/boot/Image /boot/Image.rt"
echo ""

# ============================================================================
# 6. extlinux.conf 업데이트
# ============================================================================

log_step "부트 설정 업데이트"

EXTLINUX="/boot/extlinux/extlinux.conf"

if [ -f "${EXTLINUX}" ]; then
    log_info "기존 부트 설정: ${EXTLINUX}"

    # RT 커널 부트 옵션 추가
    if ! grep -q "Image.rt" "${EXTLINUX}"; then
        log_info "RT 커널 부트 옵션 추가 중..."
        sudo tee -a "${EXTLINUX}" > /dev/null << 'EOF'

LABEL rt
    MENU LABEL RT Kernel (PREEMPT_RT)
    LINUX /boot/Image.rt
    INITRD /boot/initrd
    APPEND ${cbootargs} isolcpus=3 nohz_full=3 rcu_nocbs=3 irqaffinity=0-2 quiet
EOF
        log_info "RT 부트 옵션 추가 완료"
    else
        log_info "RT 부트 옵션 이미 존재"
    fi
else
    log_warn "extlinux.conf 없음 — 수동 부트 설정 필요"
fi

# ============================================================================
# 7. RT 스케줄러 설정
# ============================================================================

log_step "RT 스케줄러 우선순위 설정"

# RT 스케줄링 제한 해제
sudo sysctl -w kernel.sched_rt_runtime_us=-1 2>/dev/null || log_warn "sysctl 설정 불가"

# RT 우선순위 저장
mkdir -p "${JIHUN_DIR}"
cat > "${JIHUN_DIR}/rt_priorities.json" << 'EOF'
{
    "motor_control": 90,
    "reflex_engine": 85,
    "sensory_fusion": 80,
    "can_bus_rx": 75,
    "uart_comm": 70,
    "stt_pipeline": 60,
    "tts_pipeline": 50,
    "vision_pipeline": 40,
    "ai_inference": 30,
    "logging": 10
}
EOF

# ============================================================================
# 8. enable_rt.sh 스크립트 설치
# ============================================================================

log_step "enable_rt.sh 설치"

mkdir -p "${JIHUN_DIR}/scripts"
cat > "${JIHUN_DIR}/scripts/enable_rt.sh" << 'RTSCRIPT'
#!/bin/bash
# 지훈 로봇 V8.5 — RT 커널 활성화
set -e

echo "[Jihun V8.5] RT 커널 활성화 중..."

if grep -q "PREEMPT_RT" /proc/version; then
    echo "[Jihun V8.5] 이미 RT 커널 실행 중"
else
    echo "[Jihun V8.5] RT 커널 필요 — 부트 설정 확인"
fi

# RT 스케줄링 제한 해제
sudo sysctl -w kernel.sched_rt_runtime_us=-1 2>/dev/null || true

# IRQ 어피니티
echo 7 > /proc/irq/default_smp_affinity 2>/dev/null || true

echo "[Jihun V8.5] RT 커널 활성화 완료"
RTSCRIPT

chmod +x "${JIHUN_DIR}/scripts/enable_rt.sh"
log_info "enable_rt.sh 설치 완료"

# ============================================================================
# 9. cyclictest 안내
# ============================================================================

log_step "cyclictest 검증"

if command -v cyclictest &> /dev/null; then
    log_info "cyclictest 설치됨 — RT 커널 부팅 후 실행:"
    log_info "  sudo cyclictest -m -Sp90 -i1000 -D10"
else
    log_warn "cyclictest 미설치"
    log_info "설치: sudo apt-get install rt-tests"
fi

# ============================================================================
# 완료
# ============================================================================

log_info "========================================"
log_info "RT 커널 설정 스크립트 완료!"
log_info "  RT 이미지: ${RT_IMAGE}"
log_info "  부트 설정: ${EXTLINUX}"
log_info "  RT 활성화: ${JIHUN_DIR}/scripts/enable_rt.sh"
log_info "========================================"
log_warn "RT 커널 빌드 후 재부팅 필요"
