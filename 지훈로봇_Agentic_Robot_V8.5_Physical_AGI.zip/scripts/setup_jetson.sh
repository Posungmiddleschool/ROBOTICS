#!/bin/bash
# ============================================================================
# 지훈 로봇 V8.5 — TODO 1: Jetson Orin NX 16GB 설정 스크립트
# ============================================================================
# JetPack 6.0 + ROS2 Jazzy 설치 검증
# Jetson ID 자동 감지 및 대뇌/소뇌 역할 설정
#
# 작성일: 2026-05-19
# 버전: V8.5
# 라이선스: MIT
# ============================================================================

set -e

JIHUN_DIR="/opt/jihun"
JIHUN_ID_FILE="${JIHUN_DIR}/jetson_id"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'  # No Color

log_info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step()  { echo -e "${BLUE}[STEP]${NC} $1"; }

# ============================================================================
# 1. Jetson 플랫폼 확인
# ============================================================================

log_step "Jetson 플랫폼 확인"

if [ ! -f /etc/nv_tegra_release ]; then
    log_error "Jetson 플랫폼이 아닙니다!"
    exit 1
fi

log_info "Jetson 플랫폼 확인됨"
cat /etc/nv_tegra_release

# ============================================================================
# 2. JetPack 버전 확인
# ============================================================================

log_step "JetPack 버전 확인"

# nvidia-smi 확인
if command -v nvidia-smi &> /dev/null; then
    log_info "nvidia-smi 정상"
    nvidia-smi | head -5
else
    log_error "nvidia-smi 실행 불가 — NVIDIA 드라이버 미설치"
    exit 1
fi

# jtop 확인
if command -v jtop &> /dev/null; then
    log_info "jtop 정상"
else
    log_warn "jtop 미설치 — 설치 중..."
    sudo -H pip3 install jetson-stats
fi

# JetPack 패키지 확인
if dpkg -l | grep -q nvidia-jetpack; then
    JP_VERSION=$(dpkg -l | grep nvidia-jetpack | awk '{print $3}')
    log_info "JetPack 버전: ${JP_VERSION}"
else
    log_warn "JetPack 패키지 확인 불가"
fi

# ============================================================================
# 3. 메모리 확인 (UMA 16GB)
# ============================================================================

log_step "UMA 메모리 확인"

TOTAL_MEM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
TOTAL_MEM_MB=$((TOTAL_MEM_KB / 1024))

if [ $TOTAL_MEM_MB -ge 15000 ]; then
    log_info "총 메모리: ${TOTAL_MEM_MB}MB (16GB UMA 확인)"
elif [ $TOTAL_MEM_MB -ge 7000 ]; then
    log_warn "총 메모리: ${TOTAL_MEM_MB}MB — 8GB 모델일 수 있음"
    log_warn "16GB Orin NX 업그레이드 권장"
else
    log_error "메모리 부족: ${TOTAL_MEM_MB}MB — 16GB 필요"
    exit 1
fi

# ============================================================================
# 4. Jetson ID 자동 감지
# ============================================================================

log_step "Jetson ID 자동 감지"

mkdir -p "${JIHUN_DIR}"

if [ -f "${JIHUN_ID_FILE}" ]; then
    JETSON_ID=$(cat "${JIHUN_ID_FILE}")
    log_info "기존 Jetson ID: #${JETSON_ID}"
else
    # 호스트명 기반 감지
    HOSTNAME=$(hostname | tr '[:upper:]' '[:lower:]')
    if echo "${HOSTNAME}" | grep -qE "cerebrum|brain1|jetson1"; then
        JETSON_ID=1
    elif echo "${HOSTNAME}" | grep -qE "cerebellum|brain2|jetson2"; then
        JETSON_ID=2
    else
        # MAC 주소 기반
        MAC=$(ip link show | grep link/ether | head -1 | awk '{print $2}')
        LAST_OCTET=$((16#$(echo $MAC | cut -d: -f6)))
        if [ $((LAST_OCTET % 2)) -eq 0 ]; then
            JETSON_ID=1
        else
            JETSON_ID=2
        fi
    fi

    echo "${JETSON_ID}" | sudo tee "${JIHUN_ID_FILE}" > /dev/null
    log_info "Jetson ID #${JETSON_ID} 감지 및 저장"
fi

# ============================================================================
# 5. 역할별 설정
# ============================================================================

if [ "${JETSON_ID}" = "1" ]; then
    log_step "Jetson #1 — 대뇌 (Cerebrum) 설정"

    # 전원 모드: 20W 퍼포먼스
    sudo nvpmodel -m 0 2>/dev/null || log_warn "nvpmodel 설정 불가"

    # 클럭 최대화
    sudo jetson_clocks 2>/dev/null || log_warn "jetson_clocks 실행 불가"

    # 환경 변수
    cat > "${JIHUN_DIR}/env" << EOF
export JIHUN_JETSON_ID="1"
export JIHUN_JETSON_ROLE="cerebrum"
export JIHUN_GEMMA_MODEL="google/gemma-4-E4B"
export JIHUN_GEMMA_QUANT="Q4_K_M"
EOF

    log_info "대뇌 설정 완료: Gemma4 + Vision + Planning"
    log_info "  VRAM: OS 3GB + Gemma4 4GB + Vision 1.1GB = 8.1GB / 16GB"

elif [ "${JETSON_ID}" = "2" ]; then
    log_step "Jetson #2 — 소뇌 (Cerebellum) 설정"

    # 전원 모드: 15W 밸런스
    sudo nvpmodel -m 1 2>/dev/null || log_warn "nvpmodel 설정 불가"

    # 환경 변수
    cat > "${JIHUN_DIR}/env" << EOF
export JIHUN_JETSON_ID="2"
export JIHUN_JETSON_ROLE="cerebellum"
export JIHUN_STT_MODEL="distil-whisper/distil-large-v3"
export JIHUN_TTS_MODEL="myshell-ai/MeloTTS-Korean"
export JIHUN_MOTOR_CONTROL_HZ="100"
export JIHUN_CAN_BUS="can0"
EOF

    log_info "소뇌 설정 완료: Motor + STT/TTS + Reflex"
    log_info "  VRAM: OS 4GB + Audio/AI 1.3GB = 5.3GB / 16GB"
fi

# ============================================================================
# 6. ROS2 환경 설정
# ============================================================================

log_step "ROS2 Jazzy 환경 설정"

if [ -f /opt/ros/jazzy/setup.bash ]; then
    log_info "ROS2 Jazzy 설치됨"

    cat > "${JIHUN_DIR}/ros2_env.sh" << EOF
export ROS_DOMAIN_ID=42
export ROS_AUTOMATIC_DISCOVERY_RANGE=SUBNET
source /opt/ros/jazzy/setup.bash
source ~/jihun_ws/install/setup.bash
EOF

    chmod +x "${JIHUN_DIR}/ros2_env.sh"
else
    log_warn "ROS2 Jazzy 미설치"
    log_info "설치: sudo apt-get install ros-jazzy-ros-base"
fi

# ============================================================================
# 7. NVMe SSD 확인 (Jetson #1)
# ============================================================================

if [ "${JETSON_ID}" = "1" ]; then
    log_step "NVMe SSD 확인"
    if lsblk | grep -q nvme; then
        log_info "NVMe SSD 감지됨"
        lsblk | grep nvme

        # 마운트 확인
        if ! mount | grep -q /mnt/nvme; then
            log_warn "NVMe 마운트 필요: sudo mount /dev/nvme0n1p1 /mnt/nvme"
        fi
    else
        log_warn "NVMe SSD 미감지 — 모델 가중치 저장소 필요"
    fi
fi

# ============================================================================
# 완료
# ============================================================================

log_info "========================================"
log_info "Jetson #${JETSON_ID} 설정 완료!"
log_info "  ID 파일: ${JIHUN_ID_FILE}"
log_info "  환경: ${JIHUN_DIR}/env"
log_info "  ROS2: ${JIHUN_DIR}/ros2_env.sh"
log_info "========================================"
