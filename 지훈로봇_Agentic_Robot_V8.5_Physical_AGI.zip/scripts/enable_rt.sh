#!/bin/bash
# ============================================================================
# 지훈 로봇 V8.5 — RT 커널 활성화 스크립트
# ============================================================================
# PREEMPT_RT 커널로 부팅 시 자동 실행
# 모터 제어 100Hz RT 우선순위 보장
#
# 작성일: 2026-05-19
# 버전: V8.5
# 라이선스: MIT
# ============================================================================

set -e

echo "[Jihun V8.5] RT 커널 활성화 중..."

# RT 커널 확인
if grep -q "PREEMPT_RT" /proc/version; then
    echo "[Jihun V8.5] ✓ PREEMPT_RT 커널 실행 중"
else
    echo "[Jihun V8.5] ⚠ PREEMPT_RT 커널이 아님 — RT 성능 보장 불가"
    echo "[Jihun V8.5] RT 커널 설치: setup_rt_kernel.sh 실행 후 재부팅"
fi

# RT 스케줄링 제한 해제
sudo sysctl -w kernel.sched_rt_runtime_us=-1 2>/dev/null || true
echo "[Jihun V8.5] ✓ RT 스케줄링 제한 해제"

# 스케줄러 파라미터 최적화
sudo sysctl -w kernel.sched_min_granularity_ns=1000000 2>/dev/null || true
sudo sysctl -w kernel.sched_wakeup_granularity_ns=500000 2>/dev/null || true
echo "[Jihun V8.5] ✓ 스케줄러 파라미터 최적화"

# CPU3를 RT 전용으로 준비 (온라인 상태 유지)
if [ -f /sys/devices/system/cpu/cpu3/online ]; then
    echo 1 > /sys/devices/system/cpu/cpu3/online 2>/dev/null || true
    echo "[Jihun V8.5] ✓ CPU3 온라인 (RT 전용 준비)"
fi

# IRQ 어피니티 — 네트워크/CAN 인터럽트를 CPU 0-2로 제한
echo 7 > /proc/irq/default_smp_affinity 2>/dev/null || true
echo "[Jihun V8.5] ✓ IRQ 어피니티: CPU 0-2"

# 실행 중인 Jihun 프로세스에 RT 우선순위 적용
JIHUN_DIR="/opt/jihun"
if [ -f "${JIHUN_DIR}/rt_priorities.json" ]; then
    echo "[Jihun V8.5] RT 우선순위 적용 중..."

    # 모터 제어 프로세스
    MOTOR_PID=$(pgrep -f "jihun.*motor_control" 2>/dev/null || true)
    if [ -n "$MOTOR_PID" ]; then
        sudo chrt -f -p 90 $MOTOR_PID 2>/dev/null || true
        echo "[Jihun V8.5] ✓ motor_control (PID $MOTOR_PID) → RT FIFO 90"
    fi

    # 반사 엔진
    REFLEX_PID=$(pgrep -f "jihun.*reflex" 2>/dev/null || true)
    if [ -n "$REFLEX_PID" ]; then
        sudo chrt -f -p 85 $REFLEX_PID 2>/dev/null || true
        echo "[Jihun V8.5] ✓ reflex_engine (PID $REFLEX_PID) → RT FIFO 85"
    fi

    # 감각 융합
    SENSORY_PID=$(pgrep -f "jihun.*sensory" 2>/dev/null || true)
    if [ -n "$SENSORY_PID" ]; then
        sudo chrt -f -p 80 $SENSORY_PID 2>/dev/null || true
        echo "[Jihun V8.5] ✓ sensory_fusion (PID $SENSORY_PID) → RT FIFO 80"
    fi
fi

echo "[Jihun V8.5] RT 커널 활성화 완료"
