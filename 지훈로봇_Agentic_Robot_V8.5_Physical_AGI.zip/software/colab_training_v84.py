#!/usr/bin/env python3
# ============================================================================
# 지훈 로봇 V8.5 — Google Colab AI 훈련 스크립트
# Jihun Robot V8.5 — Google Colab AI Training Script
# ============================================================================
#
# Google Colab에서 실행하는 방법:
# 1. Colab 노트북 새로 만들기
# 2. 런타임 → 런타임 유형 변경 → GPU (T4/A100)
# 3. 이 스크립트를 업로드하거나 셀에 복사
# 4. 순서대로 실행
#
# Features:
#   - PPO/SAC 강화학습 훈련 (로봇 이동 + 다리 제어 + 그립)
#   - Sim-to-Real 전이 학습
#   - World Model 사전 훈련
#   - 자기지도학습 (Self-supervised)
#   - 드림 시뮬레이터 (Dream Simulator)
#   - WandB 로깅 (선택)
#   - Google Drive 체크포인트 저장
#
# 작성일: 2026-05-21
# 버전: V8.5.5
# 라이선스: MIT
# ============================================================================

# ============================================================================
# CELL 1: 환경 설정 (Environment Setup)
# ============================================================================

import subprocess
import sys
import os

def install_dependencies():
    """Colab 환경에 필요한 패키지 설치"""
    packages = [
        "torch>=2.0.0",
        "numpy>=1.24.0",
        "matplotlib>=3.7.0",
        "wandb>=0.15.0",          # 실험 추적 (선택)
        "gymnasium>=0.29.0",      # RL 환경
        "pybullet>=3.2.5",        # 물리 시뮬레이션
        "h5py>=3.9.0",            # 데이터 저장
        "tqdm>=4.65.0",           # 진행바
        "opencv-python>=4.8.0",   # 비전 처리
        "scipy>=1.11.0",          # 과학 계산
    ]

    for pkg in packages:
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "-q", pkg],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            print(f"  ✓ {pkg}")
        except subprocess.CalledProcessError:
            print(f"  ✗ {pkg} (설치 실패, 계속 진행)")

    # GPU 확인
    import torch
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name(0)
        gpu_mem = torch.cuda.get_device_properties(0).total_mem / 1e9
        print(f"\n🎮 GPU: {gpu_name} ({gpu_mem:.1f} GB)")
    else:
        print("\n⚠️ GPU 없음 — CPU로 학습 (매우 느림)")

    print("✅ 환경 설정 완료")


def mount_google_drive():
    """Google Drive 마운트 (체크포인트 저장용)"""
    try:
        from google.colab import drive
        drive.mount('/content/drive')
        checkpoint_dir = '/content/drive/MyDrive/jihun_robot_v84/checkpoints'
        os.makedirs(checkpoint_dir, exist_ok=True)
        print(f"✅ Google Drive 마운트 완료 — 체크포인트: {checkpoint_dir}")
        return checkpoint_dir
    except ImportError:
        checkpoint_dir = '/content/jihun_robot_v84/checkpoints'
        os.makedirs(checkpoint_dir, exist_ok=True)
        print(f"📁 로컬 체크포인트 디렉토리: {checkpoint_dir}")
        return checkpoint_dir


# ============================================================================
# CELL 2: 로봇 물리 환경 (Robot Physics Environment)
# ============================================================================

import numpy as np
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum


# ---- 물리 상수 (telescoping_leg.py, mecanum_wheel.py와 일치) ----

# 다리 파라미터
LEG_MIN_HEIGHT_MM = 0.0
LEG_MAX_HEIGHT_MM = 1500.0
LEG_SPRING_FORCE_N = 15.0
LEG_MAX_SPEED_MMPS = 200.0

# 휠 파라미터
WHEEL_RADIUS_M = 0.04
WHEEL_MAX_FORWARD_MS = 1.0
WHEEL_MAX_LATERAL_MS = 0.5
WHEEL_MAX_ROTATION_RADS = math.pi

# 로봇 전체 파라미터
ROBOT_MASS_KG = 12.0     # 로봇 총 질량
GRAVITY_MS2 = 9.81


class RobotActionSpace:
    """로봇 행동 공간: 16차원 연속

    인덱스:
      0-3:   메카넘 휠 속도 (4휠, rad/s, [-max_rpm*2pi/60, max_rpm*2pi/60])
      4-5:   좌/우 다리 높이 (mm, [0, 1500])
      6-7:   좌/우 다리 피치 각도 (deg, [-45, 45])
      8-9:   핀 디텐트 체결/해제 (0 or 1)
      10-11: 그리퍼 좌/우 (0=열림, 1=닫힘)
      12-13: 그리퍼 회전 (rad, [-pi, pi])
      14:    카메라 팬 (deg, [-180, 180])
      15:    LED/표현 (0-1)
    """
    DIM = 16

    # 각 차원의 (최소, 최대) 범위
    BOUNDS = np.array([
        [-6000*2*math.pi/60, 6000*2*math.pi/60],  # 휠 FL
        [-6000*2*math.pi/60, 6000*2*math.pi/60],  # 휠 FR
        [-6000*2*math.pi/60, 6000*2*math.pi/60],  # 휠 RL
        [-6000*2*math.pi/60, 6000*2*math.pi/60],  # 휠 RR
        [0.0, 1500.0],      # 좌다리 높이
        [0.0, 1500.0],      # 우다리 높이
        [-45.0, 45.0],      # 좌다리 피치
        [-45.0, 45.0],      # 우다리 피치
        [0.0, 1.0],         # 좌 핀 디텐트
        [0.0, 1.0],         # 우 핀 디텐트
        [0.0, 1.0],         # 좌 그리퍼
        [0.0, 1.0],         # 우 그리퍼
        [-math.pi, math.pi],# 그리퍼 회전
        [-180.0, 180.0],    # 카메라 팬
        [0.0, 1.0],         # LED
    ])


class RobotObservationSpace:
    """로봇 관측 공간: 62차원

    인덱스:
      0-1:   좌/우 다리 현재 높이 (mm)
      2-3:   좌/우 다리 목표 높이 (mm)
      4-5:   좌/우 다리 피치 각도 (deg)
      6-9:   4휠 속도 (rad/s)
      10-11: 로봇 선속도 vx, vy (m/s)
      12:    로봇 각속도 omega (rad/s)
      13-14: 로봇 위치 x, y (m)
      15:    로봇 방향 theta (rad)
      16-19: 4휠 모터 전류 (A)
      20-21: 좌/우 다리 모터 전류 (A)
      22-23: 좌/우 다리 벨트 장력 (N)
      24-25: 좌/우 다리 핀 디텐트 상태 (0/1)
      26-27: 좌/우 스프링 건전성 (0-1)
      28:    배터리 전압 (V)
      29:    배터리 전류 (A)
      30:    온도 (°C)
      31:    IMU 가속도 x (m/s²)
      32:    IMU 가속도 y (m/s²)
      33:    IMU 가속도 z (m/s²)
      34:    IMU 자이로 x (rad/s)
      35:    IMU 자이로 y (rad/s)
      36:    IMU 자이로 z (rad/s)
      37-38: 그리퍼 좌/우 상태 (0-1)
      39:    그리퍼 힘 센서 (N)
      40-41: 발 패드 FSR 좌/우 (N)
      42-44: 대상 물체 위치 (x, y, z)
      45-47: 대상 위치 (x, y, z)
      48-50: 장애물 위치1 (x, y, z)
      51-53: 장애물 위치2 (x, y, z)
      54:    지형 타입 (0=평지, 1=경사, 2=계단, 3=거친면)
      55-56: 좌/우 다리 지면 접촉 (0/1)
      57:    안전 엔진 상태 (0=안전, 1=경고, 2=위험)
      58:    작업 진행도 (0-1)
      59-61: 추가 컨텍스트 (예약)
    """
    DIM = 62


class JihunRobotEnv:
    """
    지훈 로봇 V8.5 시뮬레이션 환경 (PyBullet 기반)

    Physical AGI 훈련을 위한 범용 로봇 환경.
    메카넘 휠 + 텔레스코핑 다리 + 핀 그리퍼 + 비전.

    작업 (Tasks):
      - Navigation: 목표 위치로 이동
      - Fetch: 물체 집어서 목표 위치에 놓기
      - Craft: 간단한 조립 작업
      - Traverse: 계단/경사 통과
    """

    def __init__(
        self,
        task: str = "navigation",
        use_pybullet: bool = True,
        render: bool = False,
        max_episode_steps: int = 1000,
        reward_scale: float = 1.0,
    ):
        self.task = task
        self.use_pybullet = use_pybullet
        self.render = render
        self.max_episode_steps = max_episode_steps
        self.reward_scale = reward_scale

        self.action_space = RobotActionSpace()
        self.observation_space = RobotObservationSpace()

        self._step_count = 0
        self._state = np.zeros(self.observation_space.DIM, dtype=np.float32)
        self._done = False
        self._total_reward = 0.0

        # PyBullet 초기화
        self._physics_client = None
        if self.use_pybullet:
            self._init_pybullet()

    def _init_pybullet(self):
        """PyBullet 물리 엔진 초기화"""
        try:
            import pybullet as p
            import pybullet_data

            if self.render:
                self._physics_client = p.connect(p.GUI)
            else:
                self._physics_client = p.connect(p.DIRECT)

            p.setAdditionalSearchPath(pybullet_data.getDataPath())
            p.setGravity(0, 0, -GRAVITY_MS2)
            p.setTimeStep(1.0 / 240.0)

            # 바닥 생성
            self._plane_id = p.loadURDF("plane.urdf")

            print("✅ PyBullet 물리 엔진 초기화 완료")
        except ImportError:
            print("⚠️ PyBullet 미설치 — 근사 환경 사용")
            self.use_pybullet = False

    def reset(self) -> np.ndarray:
        """환경 리셋"""
        self._step_count = 0
        self._done = False
        self._total_reward = 0.0

        # 초기 상태 설정
        self._state = np.zeros(self.observation_space.DIM, dtype=np.float32)
        self._state[0] = LEG_MIN_HEIGHT_MM     # 좌다리 높이
        self._state[1] = LEG_MIN_HEIGHT_MM     # 우다리 높이
        self._state[28] = 24.0                  # 배터리 전압
        self._state[30] = 25.0                  # 온도
        self._state[54] = 0.0                   # 지형: 평지
        self._state[57] = 0.0                   # 안전: 정상

        # 작업별 목표 설정
        if self.task == "navigation":
            # 랜덤 목표 위치 (2~5m 거리)
            angle = np.random.uniform(0, 2 * math.pi)
            dist = np.random.uniform(2.0, 5.0)
            self._state[45] = dist * math.cos(angle)  # 목표 x
            self._state[46] = dist * math.sin(angle)  # 목표 y
            self._state[47] = 0.0                      # 목표 z
        elif self.task == "fetch":
            # 물체 + 목표 위치
            self._state[42] = np.random.uniform(0.5, 2.0)
            self._state[43] = np.random.uniform(-1.0, 1.0)
            self._state[44] = 0.05
            self._state[45] = np.random.uniform(-2.0, -0.5)
            self._state[46] = np.random.uniform(-1.0, 1.0)
            self._state[47] = 0.05
        elif self.task == "traverse":
            # 계단/경사 환경
            self._state[54] = np.random.choice([1.0, 2.0, 3.0])

        return self._state.copy()

    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, dict]:
        """환경 스텝"""
        self._step_count += 1

        # 행동 클램핑
        action_clamped = np.zeros(self.action_space.DIM, dtype=np.float32)
        for i in range(self.action_space.DIM):
            lo, hi = self.action_space.BOUNDS[i]
            action_clamped[i] = np.clip(action[i], lo, hi)

        # ---- 물리 시뮬레이션 (근사) ----
        # 휠 이동 (메카넘 역학)
        wheel_speeds = action_clamped[0:4]
        r = WHEEL_RADIUS_M
        vx = r / 4 * (wheel_speeds[0] + wheel_speeds[1] + wheel_speeds[2] + wheel_speeds[3])
        vy = r / 4 * (-wheel_speeds[0] + wheel_speeds[1] + wheel_speeds[2] - wheel_speeds[3])
        omega = r / (4 * 0.225) * (-wheel_speeds[0] + wheel_speeds[1] - wheel_speeds[2] + wheel_speeds[3])

        # 속도 제한
        vx = np.clip(vx, -WHEEL_MAX_FORWARD_MS, WHEEL_MAX_FORWARD_MS)
        vy = np.clip(vy, -WHEEL_MAX_LATERAL_MS, WHEEL_MAX_LATERAL_MS)
        omega = np.clip(omega, -WHEEL_MAX_ROTATION_RADS, WHEEL_MAX_ROTATION_RADS)

        # 위치 업데이트 (dt=0.05s)
        dt = 0.05
        self._state[14] += vx * dt   # x
        self._state[15] += vy * dt   # y
        self._state[15] += omega * dt  # theta (인덱스 15=theta, 실제로는 16번째)

        # 다리 높이 업데이트
        left_target = action_clamped[4]
        right_target = action_clamped[5]
        self._state[0] = np.clip(left_target, LEG_MIN_HEIGHT_MM, LEG_MAX_HEIGHT_MM)
        self._state[1] = np.clip(right_target, LEG_MIN_HEIGHT_MM, LEG_MAX_HEIGHT_MM)

        # ---- 보상 계산 ----
        reward = self._compute_reward(action_clamped)

        # ---- 종료 조건 ----
        self._done = (
            self._step_count >= self.max_episode_steps or
            self._state[28] < 18.0 or  # 배터리 방전
            self._state[57] >= 2.0      # 안전 위험
        )

        # 작업 진행도 업데이트
        self._state[58] = min(1.0, self._step_count / self.max_episode_steps)

        self._total_reward += reward

        info = {
            "step": self._step_count,
            "task": self.task,
            "total_reward": self._total_reward,
            "battery_v": self._state[28],
            "safety": self._state[57],
        }

        return self._state.copy(), reward * self.reward_scale, self._done, info

    def _compute_reward(self, action: np.ndarray) -> float:
        """작업별 보상 계산"""
        reward = 0.0

        if self.task == "navigation":
            # 목표까지 거리 보상
            dx = self._state[45] - self._state[14]
            dy = self._state[46] - self._state[15]
            dist = math.sqrt(dx**2 + dy**2)
            reward += max(0, 1.0 - dist / 5.0)  # 거리 기반 보상
            if dist < 0.1:
                reward += 10.0  # 도달 보너스

        elif self.task == "fetch":
            # 물체 거리 + 목표 거리 보상
            obj_dist = math.sqrt(
                (self._state[42] - self._state[14])**2 +
                (self._state[43] - self._state[15])**2
            )
            reward += max(0, 1.0 - obj_dist / 3.0)
            if obj_dist < 0.15 and action[10] > 0.5:
                reward += 5.0  # 물체 잡기 보너스

        elif self.task == "traverse":
            # 이동 거리 + 안전 보상
            reward += 0.1  # 생존 보상
            if self._state[0] > 100 and self._state[1] > 100:
                reward += 0.5  # 다리 올림 보너스
            if self._state[57] < 1.0:
                reward += 0.3  # 안전 보너스

        # 공통 패널티
        # 에너지 소비 패널티
        motor_power = sum(abs(a) for a in action[0:6]) * 0.001
        reward -= motor_power

        # 급격한 행동 변화 패널티
        # (이전 행동과 비교, 생략 — 단일 스텝이므로)

        # 안전 위반 패널티
        if self._state[57] >= 1.0:
            reward -= 2.0

        # 다리 범위 위반 패널티
        if self._state[0] < 0 or self._state[0] > 1500:
            reward -= 1.0
        if self._state[1] < 0 or self._state[1] > 1500:
            reward -= 1.0

        return reward

    def close(self):
        """환경 정리"""
        if self._physics_client is not None:
            try:
                import pybullet as p
                p.disconnect(self._physics_client)
            except Exception:
                pass


# ============================================================================
# CELL 3: 강화학습 훈련 (RL Training)
# ============================================================================

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
from collections import deque
import time


def train_ppo(
    task: str = "navigation",
    total_timesteps: int = 500_000,
    rollout_steps: int = 2048,
    ppo_epochs: int = 10,
    lr: float = 3e-4,
    gamma: float = 0.99,
    lam: float = 0.95,
    clip_ratio: float = 0.2,
    entropy_coef: float = 0.01,
    batch_size: int = 64,
    save_interval: int = 50_000,
    checkpoint_dir: str = "/content/jihun_robot_v84/checkpoints",
    use_wandb: bool = False,
):
    """
    PPO 강화학습 훈련 메인 루프

    Args:
        task: 훈련 작업 ("navigation", "fetch", "traverse")
        total_timesteps: 총 훈련 스텝 수
        rollout_steps: 롤아웃당 스텝 수
        ppo_epochs: PPO 업데이트 에포크
        lr: 학습률
        gamma: 할인 인자
        lam: GAE lambda
        clip_ratio: PPO 클리핑 비율
        entropy_coef: 엔트로피 보너스
        batch_size: 미니배치 크기
        save_interval: 체크포인트 저장 간격
        checkpoint_dir: 체크포인트 저장 경로
        use_wandb: WandB 로깅 여부
    """
    os.makedirs(checkpoint_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🚀 PPO 훈련 시작 — 작업: {task}, 디바이스: {device}")

    # 환경 생성
    env = JihunRobotEnv(task=task, use_pybullet=False)

    # rl_policy.py에서 임포트 (Colab에서는 직접 정의)
    from rl_policy import PPOAgent, MLPActorCritic, RolloutBuffer

    # 에이전트 생성
    agent = PPOAgent(
        state_dim=RobotObservationSpace.DIM,
        action_dim=RobotActionSpace.DIM,
        lr=lr,
        gamma=gamma,
        lam=lam,
        clip_ratio=clip_ratio,
        epochs=ppo_epochs,
        entropy_coef=entropy_coef,
        device=device,
    )

    # WandB 초기화
    if use_wandb:
        try:
            import wandb
            wandb.init(
                project="jihun-robot-v84",
                name=f"ppo_{task}",
                config={
                    "task": task,
                    "total_timesteps": total_timesteps,
                    "lr": lr,
                    "gamma": gamma,
                    "lam": lam,
                    "clip_ratio": clip_ratio,
                },
            )
        except ImportError:
            use_wandb = False

    # 훈련 루프
    state = env.reset()
    episode_reward = 0.0
    episode_count = 0
    best_reward = -float('inf')
    timesteps = 0
    start_time = time.time()

    reward_history = deque(maxlen=100)

    while timesteps < total_timesteps:
        buffer = RolloutBuffer()

        # 롤아웃 수집
        for _ in range(rollout_steps):
            action, log_prob, value = agent.ac.get_action(state)
            next_state, reward, done, info = env.step(action)

            buffer.insert(
                state=state,
                action=action,
                reward=reward,
                value=value,
                log_prob=log_prob,
                done=done,
            )

            state = next_state
            episode_reward += reward
            timesteps += 1

            if done:
                episode_count += 1
                reward_history.append(episode_reward)

                if episode_reward > best_reward:
                    best_reward = episode_reward
                    agent.save_policy(
                        os.path.join(checkpoint_dir, f"ppo_{task}_best.pt")
                    )

                state = env.reset()
                episode_reward = 0.0

        # 부트스트랩 가치
        with torch.no_grad():
            state_t = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
            _, _, last_val = agent.ac(state_t)
            last_value = last_val.squeeze().item()

        # GAE 계산
        buffer.compute_returns_and_advantages(last_value, gamma, lam)

        # PPO 업데이트
        update_result = agent.update(buffer)

        # 로깅
        if episode_count % 10 == 0 and len(reward_history) > 0:
            avg_reward = np.mean(reward_history)
            elapsed = time.time() - start_time
            fps = timesteps / elapsed if elapsed > 0 else 0

            print(
                f"[{timesteps:,}/{total_timesteps:,}] "
                f"에피소드: {episode_count}, "
                f"평균 보상: {avg_reward:.2f}, "
                f"최고 보상: {best_reward:.2f}, "
                f"FPS: {fps:.0f}, "
                f"policy_loss: {update_result['policy_loss']:.4f}, "
                f"value_loss: {update_result['value_loss']:.4f}"
            )

            if use_wandb:
                wandb.log({
                    "timesteps": timesteps,
                    "avg_reward": avg_reward,
                    "best_reward": best_reward,
                    "policy_loss": update_result["policy_loss"],
                    "value_loss": update_result["value_loss"],
                    "entropy": update_result["entropy"],
                    "fps": fps,
                })

        # 정기 체크포인트
        if timesteps % save_interval == 0:
            ckpt_path = os.path.join(
                checkpoint_dir, f"ppo_{task}_{timesteps}.pt"
            )
            agent.save_policy(ckpt_path)
            print(f"💾 체크포인트 저장: {ckpt_path}")

    # 최종 저장
    final_path = os.path.join(checkpoint_dir, f"ppo_{task}_final.pt")
    agent.save_policy(final_path)
    print(f"\n✅ PPO 훈련 완료!")
    print(f"   총 에피소드: {episode_count}")
    print(f"   최고 보상: {best_reward:.2f}")
    print(f"   최종 체크포인트: {final_path}")

    env.close()

    if use_wandb:
        wandb.finish()

    return agent


# ============================================================================
# CELL 4: SAC 훈련 (Soft Actor-Critic)
# ============================================================================

def train_sac(
    task: str = "fetch",
    total_timesteps: int = 500_000,
    replay_capacity: int = 100_000,
    batch_size: int = 256,
    lr: float = 3e-4,
    tau: float = 0.005,
    gamma: float = 0.99,
    alpha: float = 0.2,
    auto_alpha: bool = True,
    learning_starts: int = 5_000,
    save_interval: int = 50_000,
    checkpoint_dir: str = "/content/jihun_robot_v84/checkpoints",
    use_wandb: bool = False,
):
    """
    SAC (Soft Actor-Critic) 훈련 — 그립/조작 작업에 특화

    SAC는 오프폴리시 알고리즘으로, 데이터 효율이 좋아
    실제 로봇 데이터와 결합하기 적합.
    """
    os.makedirs(checkpoint_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🚀 SAC 훈련 시작 — 작업: {task}, 디바이스: {device}")

    env = JihunRobotEnv(task=task, use_pybullet=False)

    from rl_policy import SACAgent, ReplayBuffer

    agent = SACAgent(
        state_dim=RobotObservationSpace.DIM,
        action_dim=RobotActionSpace.DIM,
        lr=lr,
        alpha=alpha,
        tau=tau,
        gamma=gamma,
        auto_alpha=auto_alpha,
        device=device,
    )

    replay_buffer = ReplayBuffer(
        capacity=replay_capacity,
        state_dim=RobotObservationSpace.DIM,
        action_dim=RobotActionSpace.DIM,
    )

    state = env.reset()
    episode_reward = 0.0
    episode_count = 0
    best_reward = -float('inf')
    timesteps = 0
    start_time = time.time()
    reward_history = deque(maxlen=100)

    while timesteps < total_timesteps:
        # 행동 선택 (랜덤 → 정책 전환)
        if timesteps < learning_starts:
            action = np.random.uniform(-1, 1, size=RobotActionSpace.DIM)
            # 스케일을 실제 행동 공간에 맞게
            for i in range(RobotActionSpace.DIM):
                lo, hi = RobotActionSpace.BOUNDS[i]
                action[i] = action[i] * (hi - lo) / 2 + (hi + lo) / 2
        else:
            # 정책에서 샘플링 ([-1,1] → 실제 범위로 스케일)
            action_raw = agent.select_action(state, evaluate=False)
            action = np.zeros(RobotActionSpace.DIM, dtype=np.float32)
            for i in range(RobotActionSpace.DIM):
                lo, hi = RobotActionSpace.BOUNDS[i]
                action[i] = (action_raw[i] + 1) / 2 * (hi - lo) + lo

        next_state, reward, done, info = env.step(action)

        replay_buffer.push(state, action, reward, next_state, done)

        state = next_state
        episode_reward += reward
        timesteps += 1

        # 학습
        if timesteps >= learning_starts:
            result = agent.update(replay_buffer, batch_size)

            if timesteps % 1000 == 0 and episode_count > 0 and len(reward_history) > 0:
                avg_reward = np.mean(reward_history)
                elapsed = time.time() - start_time
                fps = timesteps / elapsed if elapsed > 0 else 0

                print(
                    f"[{timesteps:,}/{total_timesteps:,}] "
                    f"에피소드: {episode_count}, "
                    f"평균 보상: {avg_reward:.2f}, "
                    f"critic_loss: {result['critic_loss']:.4f}, "
                    f"actor_loss: {result['actor_loss']:.4f}, "
                    f"alpha: {result['alpha']:.4f}"
                )

        if done:
            episode_count += 1
            reward_history.append(episode_reward)

            if episode_reward > best_reward:
                best_reward = episode_reward
                agent.save_policy(
                    os.path.join(checkpoint_dir, f"sac_{task}_best.pt")
                )

            state = env.reset()
            episode_reward = 0.0

        # 정기 체크포인트
        if timesteps % save_interval == 0:
            agent.save_policy(
                os.path.join(checkpoint_dir, f"sac_{task}_{timesteps}.pt")
            )

    agent.save_policy(
        os.path.join(checkpoint_dir, f"sac_{task}_final.pt")
    )
    print(f"\n✅ SAC 훈련 완료! 최고 보상: {best_reward:.2f}")

    env.close()
    return agent


# ============================================================================
# CELL 5: World Model 사전 훈련
# ============================================================================

class WorldModelNetwork(nn.Module):
    """세계 모델 네트워크 — 다음 상태 예측

    입력: (state, action) → 출력: (next_state, reward)
    잔차 학습: next_state = state + delta
    """

    def __init__(self, state_dim=62, action_dim=16, hidden_dim=512):
        super().__init__()
        input_dim = state_dim + action_dim

        self.delta_net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, state_dim),  # 상태 변화량
        )

        self.reward_net = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, 1),  # 보상 예측
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        delta = self.delta_net(x)
        reward = self.reward_net(x)
        return state + delta, reward


def train_world_model(
    data_path: Optional[str] = None,
    num_epochs: int = 100,
    batch_size: int = 256,
    lr: float = 1e-3,
    checkpoint_dir: str = "/content/jihun_robot_v84/checkpoints",
):
    """
    World Model 사전 훈련

    시뮬레이션에서 수집한 (s, a, r, s') 데이터로
    환경 역학을 학습 → 드림 시뮬레이터에 활용.
    """
    os.makedirs(checkpoint_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("🌍 World Model 훈련 시작")

    # 데이터 수집 (시뮬레이션에서 랜덤 정책으로)
    env = JihunRobotEnv(task="navigation", use_pybullet=False)
    print("  📊 시뮬레이션 데이터 수집 중...")

    states, actions, rewards, next_states = [], [], [], []
    state = env.reset()

    for _ in range(50_000):
        # 랜덤 행동
        action = np.zeros(RobotActionSpace.DIM, dtype=np.float32)
        for i in range(RobotActionSpace.DIM):
            lo, hi = RobotActionSpace.BOUNDS[i]
            action[i] = np.random.uniform(lo, hi)

        next_state, reward, done, _ = env.step(action)

        states.append(state.copy())
        actions.append(action.copy())
        rewards.append(reward)
        next_states.append(next_state.copy())

        if done:
            state = env.reset()
        else:
            state = next_state

    env.close()
    print(f"  📊 수집 완료: {len(states)} 전이")

    # 텐서 변환
    states_t = torch.tensor(np.array(states), dtype=torch.float32, device=device)
    actions_t = torch.tensor(np.array(actions), dtype=torch.float32, device=device)
    rewards_t = torch.tensor(np.array(rewards), dtype=torch.float32, device=device).unsqueeze(1)
    next_states_t = torch.tensor(np.array(next_states), dtype=torch.float32, device=device)

    # 모델 생성
    model = WorldModelNetwork().to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr)

    # 훈련
    dataset_size = len(states)
    for epoch in range(num_epochs):
        # 미니배치 학습
        indices = np.random.permutation(dataset_size)
        total_loss = 0.0
        num_batches = 0

        for start in range(0, dataset_size, batch_size):
            idx = indices[start:start + batch_size]
            s = states_t[idx]
            a = actions_t[idx]
            r = rewards_t[idx]
            ns = next_states_t[idx]

            pred_ns, pred_r = model(s, a)

            state_loss = nn.functional.mse_loss(pred_ns, ns)
            reward_loss = nn.functional.mse_loss(pred_r, r)
            loss = state_loss + 0.1 * reward_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            num_batches += 1

        avg_loss = total_loss / num_batches
        if (epoch + 1) % 10 == 0:
            print(f"  에포크 {epoch+1}/{num_epochs}: loss={avg_loss:.6f}")

    # 저장
    save_path = os.path.join(checkpoint_dir, "world_model_v84.pt")
    torch.save({
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "epoch": num_epochs,
        "loss": avg_loss,
    }, save_path)
    print(f"✅ World Model 훈련 완료 — 저장: {save_path}")

    return model


# ============================================================================
# CELL 6: 다중 작업 커리큘럼 훈련
# ============================================================================

def train_curriculum(
    total_timesteps: int = 1_000_000,
    checkpoint_dir: str = "/content/jihun_robot_v84/checkpoints",
):
    """
    다중 작업 커리큘럼 훈련

    단계별 난이도 증가:
      Phase 1: Navigation (이동 마스터) — 300K 스텝
      Phase 2: Fetch (물체 파지) — 300K 스텝
      Phase 3: Traverse (지형 극복) — 200K 스텝
      Phase 4: 통합 (모든 작업 혼합) — 200K 스텝
    """
    phases = [
        {"task": "navigation", "steps": 300_000, "name": "이동 마스터"},
        {"task": "fetch", "steps": 300_000, "name": "물체 파지"},
        {"task": "traverse", "steps": 200_000, "name": "지형 극복"},
        {"task": "navigation", "steps": 200_000, "name": "통합 복습"},
    ]

    print("=" * 60)
    print("🎓 지훈 로봇 V8.5 커리큘럼 훈련 시작")
    print("=" * 60)

    agent = None

    for i, phase in enumerate(phases):
        print(f"\n{'='*60}")
        print(f"📖 Phase {i+1}: {phase['name']} ({phase['task']})")
        print(f"   스텝 수: {phase['steps']:,}")
        print(f"{'='*60}")

        agent = train_ppo(
            task=phase["task"],
            total_timesteps=phase["steps"],
            checkpoint_dir=checkpoint_dir,
        )

    # 최종 통합 모델 저장
    if agent is not None:
        final_path = os.path.join(checkpoint_dir, "ppo_curriculum_final.pt")
        agent.save_policy(final_path)
        print(f"\n🏆 커리큘럼 훈련 완료! 최종 모델: {final_path}")

    return agent


# ============================================================================
# CELL 7: Sim-to-Real 전이 준비
# ============================================================================

def export_onnx_policy(
    checkpoint_path: str,
    output_path: str = "/content/jihun_robot_v84/policy.onnx",
):
    """
    훈련된 정책을 ONNX로 내보내기

    Jetson Orin Nano에서 추론하기 위해 ONNX 형식으로 변환.
    TensorRT로 최적화 가능.
    """
    device = torch.device("cpu")

    from rl_policy import MLPActorCritic

    # 체크포인트 로드
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    ac_state = checkpoint.get("ac_state_dict", checkpoint)

    # 모델 생성
    model = MLPActorCritic(
        state_dim=RobotObservationSpace.DIM,
        action_dim=RobotActionSpace.DIM,
    )
    model.load_state_dict(ac_state)
    model.eval()

    # ONNX 익스포트
    dummy_input = torch.randn(1, RobotObservationSpace.DIM)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    torch.onnx.export(
        model,
        dummy_input,
        output_path,
        input_names=["observation"],
        output_names=["action_mean", "action_log_std", "value"],
        dynamic_axes={"observation": {0: "batch_size"}},
        opset_version=17,
    )

    print(f"✅ ONNX 정책 내보내기 완료: {output_path}")
    print(f"   크기: {os.path.getsize(output_path) / 1024:.1f} KB")

    return output_path


# ============================================================================
# CELL 8: 메인 실행 (Main Execution)
# ============================================================================

def main():
    """
    Google Colab 메인 실행 함수

    사용법:
      1. 전체 커리큘럼 훈련:
         main()

      2. 개별 작업 훈련:
         train_ppo(task="navigation", total_timesteps=100_000)

      3. World Model 사전 훈련:
         train_world_model()

      4. ONNX 내보내기:
         export_onnx_policy("checkpoints/ppo_navigation_best.pt")
    """

    # 1. 환경 설정
    print("=" * 60)
    print("🤖 지훈 로봇 V8.5 — Colab AI 훈련")
    print("=" * 60)

    install_dependencies()
    checkpoint_dir = mount_google_drive()

    # 2. World Model 사전 훈련 (선택)
    print("\n[Step 1/3] World Model 사전 훈련")
    world_model = train_world_model(checkpoint_dir=checkpoint_dir)

    # 3. PPO 커리큘럼 훈련
    print("\n[Step 2/3] PPO 커리큘럼 훈련")
    agent = train_curriculum(
        total_timesteps=500_000,  # 빠른 테스트용, 실제는 1M+
        checkpoint_dir=checkpoint_dir,
    )

    # 4. ONNX 내보내기
    print("\n[Step 3/3] ONNX 정책 내보내기")
    best_ckpt = os.path.join(checkpoint_dir, "ppo_navigation_best.pt")
    if os.path.exists(best_ckpt):
        export_onnx_policy(
            best_ckpt,
            os.path.join(checkpoint_dir, "policy_v84.onnx"),
        )

    print("\n" + "=" * 60)
    print("🎉 모든 훈련 완료!")
    print(f"   체크포인트: {checkpoint_dir}")
    print("=" * 60)


# Colab에서 직접 실행 시
if __name__ == "__main__":
    # 빠른 테스트 (5분 이내)
    print("⚡ 빠른 테스트 모드 (10K 스텝)")

    install_dependencies()
    checkpoint_dir = mount_google_drive()

    # Navigation 작업만 빠르게 훈련
    agent = train_ppo(
        task="navigation",
        total_timesteps=10_000,
        rollout_steps=512,
        checkpoint_dir=checkpoint_dir,
    )

    print("\n✅ 빠른 테스트 완료!")
    print("   전체 훈련을 원하면 main()을 실행하세요.")
