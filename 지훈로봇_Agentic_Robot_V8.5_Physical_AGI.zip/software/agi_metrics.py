#!/usr/bin/env python3
"""
agi_metrics.py - Physical AGI Metrics System for Jihun Robot V8.5
===============================================================

Measures how close the robot is to Physical AGI across 9 core dimensions,
using harmonic mean for composite scoring (so weak dimensions drag the
overall score down — a robot that cannot manipulate objects is not AGI
no matter how well it walks).

9 Core Dimensions:
  1. Locomotion intelligence   — terrain traversal, stability, adaptation
  2. Manipulation intelligence  — grasp success, tool use, precision
  3. Perception intelligence    — object recognition, spatial understanding
  4. Learning speed             — sample efficiency, transfer learning
  5. Autonomy level             — self-directed goals, self-repair, self-improvement
  6. Safety awareness           — hazard detection, risk assessment
  7. Physical understanding     — causal reasoning about physics
  8. Creative problem solving   — novel solutions, tool invention
  9. Social interaction         — communication, collaboration

Key Design Principles:
  - Harmonic mean composite: H = n / sum(1/x_i), weak dims pull hard
  - Bayesian mastery tracking per dimension (Beta distribution prior)
  - Time-series progress with plateau / breakthrough detection
  - Sub-metric decomposition within each dimension
  - Thread-safe for real-time robot operation
  - Persistent state via SQLite

Hardware: Dual Jetson Orin NX 16GB
AI Model: Gemma 4 E4B Q4_K_M
Version: V8.5.4
License: MIT
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════

DB_PATH = "agi_metrics_v83.db"
HISTORY_LENGTH = 1000                # max snapshots kept in memory
SNAPSHOT_INTERVAL_SEC = 300.0        # auto-snapshot every 5 minutes
MIN_OBSERVATIONS_FOR_CONFIDENCE = 5
PLATEAU_WINDOW = 8                   # snapshots for plateau detection
BREAKTHROUGH_JUMP = 0.08             # min jump to count as breakthrough
EMERGENCE_MIN_COMBINED = 0.45        # both dims must exceed this for emergence
EMERGENCE_MIN_IMPROVEMENT = 0.10     # min improvement for emergence detection
DIMENSION_WEIGHT_EQUAL = 1.0 / 9.0  # equal weight per dimension (harmonic mean makes this moot)

# Sub-metric definitions per dimension
SUB_METRICS = {
    "locomotion": [
        "terrain_traversal_success",   # % of terrain types traversed successfully
        "stability_score",             # posture stability during movement
        "gait_adaptation",             # ability to adapt gait to conditions
        "obstacle_avoidance",          # dynamic obstacle avoidance success
        "energy_efficiency",           # movement energy per distance
    ],
    "manipulation": [
        "grasp_success_rate",          # % of objects grasped without drop
        "tool_use_proficiency",        # ability to use tools correctly
        "precision_control",           # fine motor control accuracy
        "force_calibration",           # applying appropriate force
        "bimanual_coordination",       # two-hand coordination
    ],
    "perception": [
        "object_recognition_accuracy", # correct object identification
        "spatial_mapping_quality",     # 3D spatial understanding
        "material_classification",     # identifying material properties
        "depth_estimation_accuracy",   # distance judgment
        "change_detection",            # noticing environmental changes
    ],
    "learning_speed": [
        "sample_efficiency",           # learning from few examples
        "transfer_learning",           # applying knowledge across domains
        "concept_acquisition_rate",    # speed of new concept learning
        "forgetting_rate_inv",         # 1 - forgetting rate (retention)
        "curriculum_progression",      # rate of advancing through curriculum
    ],
    "autonomy_level": [
        "self_directed_goals",         # generating own goals
        "self_diagnosis",              # detecting own errors/failures
        "self_repair_capability",      # recovering from failures
        "self_improvement_rate",       # actively seeking to improve
        "resource_management",         # managing own power/compute
    ],
    "safety_awareness": [
        "hazard_detection",            # detecting dangerous situations
        "risk_assessment",             # evaluating action risks
        "harm_avoidance",              # preventing harm to self/others
        "compliance_score",            # following safety rules
        "emergency_response",          # appropriate emergency reactions
    ],
    "physical_understanding": [
        "causal_reasoning",            # understanding cause and effect
        "physics_prediction",          # predicting physical outcomes
        "counterfactual_reasoning",    # "what if" physical reasoning
        "affordance_recognition",      # recognizing object uses
        "physical_analogy",            # applying physics knowledge analogically
    ],
    "creative_problem_solving": [
        "novel_solution_rate",         # finding non-obvious solutions
        "tool_invention",              # creating new tools/approaches
        "lateral_thinking",            # unconventional approaches
        "problem_decomposition",       # breaking complex problems down
        "resourcefulness",             # using available resources creatively
    ],
    "social_interaction": [
        "communication_clarity",       # clear expression of intent/state
        "collaboration_ability",       # working with others (robots/humans)
        "intent_recognition",          # understanding others' intents
        "feedback_integration",        # incorporating feedback
        "teaching_ability",            # conveying knowledge to others
    ],
}


# ═══════════════════════════════════════════════════════════════════════════
# AGI Dimension Enum
# ═══════════════════════════════════════════════════════════════════════════

class AGIDimension(Enum):
    """9 core dimensions of Physical AGI measurement."""
    LOCOMOTION = "locomotion"
    MANIPULATION = "manipulation"
    PERCEPTION = "perception"
    LEARNING_SPEED = "learning_speed"
    AUTONOMY = "autonomy_level"
    SAFETY = "safety_awareness"
    PHYSICAL_UNDERSTANDING = "physical_understanding"
    CREATIVE_SOLVING = "creative_problem_solving"
    SOCIAL = "social_interaction"

    @classmethod
    def all(cls) -> List["AGIDimension"]:
        return list(cls)

    @classmethod
    def names(cls) -> List[str]:
        return [d.value for d in cls]


# ═══════════════════════════════════════════════════════════════════════════
# AGI Level Categories
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class AGILevel:
    """Named AGI level category."""
    name: str
    min_score: float
    max_score: float
    description: str


AGI_LEVELS: List[AGILevel] = [
    AGILevel("Narrow Robot",     0.00, 0.15,
             "Single-task robotics, no generalization"),
    AGILevel("Emerging AGI",     0.15, 0.35,
             "Early multi-domain ability with major gaps"),
    AGILevel("Developing AGI",   0.35, 0.55,
             "Competent across most domains, some weak areas"),
    AGILevel("Advanced AGI",     0.55, 0.75,
             "Strong capability, minor weaknesses remaining"),
    AGILevel("Near Physical AGI", 0.75, 0.90,
             "Approaching human-level across all dimensions"),
    AGILevel("Physical AGI",     0.90, 1.00,
             "Human-equivalent or superhuman physical intelligence"),
]


def classify_agi_level(score: float) -> AGILevel:
    """Map a 0-1 harmonic-mean score to an AGILevel category."""
    for lvl in AGI_LEVELS:
        if lvl.min_score <= score < lvl.max_score:
            return lvl
    return AGI_LEVELS[-1]  # exact 1.0 → Physical AGI


# ═══════════════════════════════════════════════════════════════════════════
# Data Classes
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class SubMetricResult:
    """Result of a single sub-metric measurement within a dimension."""
    dimension: str
    sub_metric: str
    value: float           # 0.0 - 1.0
    weight: float = 1.0    # relative importance within dimension
    timestamp: float = field(default_factory=time.time)


@dataclass
class DimensionSnapshot:
    """Snapshot of all 9 dimensions at a point in time."""
    dimensions: Dict[str, float]   # dimension_name → mastery [0,1]
    overall_agi: float
    level_name: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class BreakthroughEvent:
    """Recorded when a dimension or overall score jumps significantly."""
    dimension: str        # "overall" or dimension name
    previous: float
    current: float
    jump: float
    timestamp: float = field(default_factory=time.time)


@dataclass
class EmergentCapability:
    """Detected when two dimensions combine to enable a new ability."""
    name: str
    dimensions: List[str]
    combined_score: float
    improvement: float
    description: str
    timestamp: float = field(default_factory=time.time)


# ═══════════════════════════════════════════════════════════════════════════
# DimensionMasteryTracker — Bayesian mastery per dimension
# ═══════════════════════════════════════════════════════════════════════════

class DimensionMasteryTracker:
    """
    Tracks mastery of a single AGI dimension using Bayesian updating
    with a Beta distribution prior.

    Each sub-metric observation updates the prior:
        success → α += weight * value
        failure → β += weight * (1 - value)

    Mastery = α / (α + β)   (posterior expected value)
    """

    def __init__(self, dimension_name: str, sub_metrics: List[str]):
        self.dimension_name = dimension_name
        self.sub_metric_names = sub_metrics
        # Beta prior parameters (weak prior: uniform)
        self._alpha: float = 1.0
        self._beta: float = 1.0
        # Per-sub-metric accumulation
        self._sub_alpha: Dict[str, float] = {sm: 1.0 for sm in sub_metrics}
        self._sub_beta: Dict[str, float] = {sm: 1.0 for sm in sub_metrics}
        # Recent observations for trend calculation
        self._recent_values: Deque[float] = deque(maxlen=100)
        self._observation_count: int = 0
        self._lock = threading.Lock()

    def update(self, sub_metric: str, value: float, weight: float = 1.0,
               success: Optional[bool] = None) -> None:
        """
        Update mastery with a new sub-metric observation.

        Args:
            sub_metric: name of the sub-metric
            value: observation value [0, 1]
            weight: importance weight for this observation
            success: if None, inferred from value >= 0.5
        """
        value = max(0.0, min(1.0, value))
        if success is None:
            success = value >= 0.5

        with self._lock:
            if success:
                self._alpha += weight * value
                self._sub_alpha[sub_metric] = self._sub_alpha.get(sub_metric, 1.0) + weight * value
            else:
                self._beta += weight * (1.0 - value)
                self._sub_beta[sub_metric] = self._sub_beta.get(sub_metric, 1.0) + weight * (1.0 - value)

            self._observation_count += 1
            self._recent_values.append(value)

    def get_mastery(self) -> float:
        """Return the overall mastery for this dimension (0-1)."""
        with self._lock:
            return self._alpha / (self._alpha + self._beta)

    def get_sub_mastery(self, sub_metric: str) -> float:
        """Return mastery for a specific sub-metric."""
        a = self._sub_alpha.get(sub_metric, 1.0)
        b = self._sub_beta.get(sub_metric, 1.0)
        return a / (a + b)

    def get_all_sub_mastery(self) -> Dict[str, float]:
        """Return mastery for all sub-metrics."""
        return {
            sm: self.get_sub_mastery(sm)
            for sm in self.sub_metric_names
        }

    def get_confidence(self) -> float:
        """
        Return confidence in the mastery estimate (0-1).
        More observations → higher confidence.
        """
        with self._lock:
            n = self._observation_count
        # Sigmoid-like scaling: reaches ~0.9 at 20 observations
        return min(1.0, n / (n + MIN_OBSERVATIONS_FOR_CONFIDENCE))

    def get_trend(self) -> str:
        """Return recent trend: 'improving', 'declining', or 'stable'."""
        with self._lock:
            if len(self._recent_values) < 5:
                return "stable"
            recent = list(self._recent_values)
            n = len(recent)
            first_half = np.mean(recent[:n // 2])
            second_half = np.mean(recent[n // 2:])
            diff = second_half - first_half
            if diff > 0.03:
                return "improving"
            elif diff < -0.03:
                return "declining"
            return "stable"

    @property
    def observation_count(self) -> int:
        with self._lock:
            return self._observation_count

    def get_state(self) -> Dict[str, Any]:
        """Serialize tracker state for persistence."""
        with self._lock:
            return {
                "dimension": self.dimension_name,
                "alpha": self._alpha,
                "beta": self._beta,
                "sub_alpha": dict(self._sub_alpha),
                "sub_beta": dict(self._sub_beta),
                "observation_count": self._observation_count,
                "recent_values": list(self._recent_values),
            }

    def load_state(self, state: Dict[str, Any]) -> None:
        """Restore tracker state from persistence."""
        with self._lock:
            self._alpha = state.get("alpha", 1.0)
            self._beta = state.get("beta", 1.0)
            self._sub_alpha = state.get("sub_alpha", {sm: 1.0 for sm in self.sub_metric_names})
            self._sub_beta = state.get("sub_beta", {sm: 1.0 for sm in self.sub_metric_names})
            self._observation_count = state.get("observation_count", 0)
            self._recent_values = deque(
                state.get("recent_values", []), maxlen=100
            )


# ═══════════════════════════════════════════════════════════════════════════
# AGIMetrics — Main class
# ═══════════════════════════════════════════════════════════════════════════

class AGIMetrics:
    """
    Physical AGI Metrics System — measures how close the robot is to
    Physical AGI across 9 dimensions using harmonic mean composition.

    Usage:
        metrics = AGIMetrics()
        metrics.initialize()
        metrics.record_sub_metric("locomotion", "terrain_traversal_success", 0.85)
        summary = metrics.get_summary()
        report = metrics.generate_report()
    """

    def __init__(self, db_path: str = DB_PATH):
        self._db_path = db_path
        self._initialized = False
        self._lock = threading.RLock()

        # Per-dimension mastery trackers
        self._trackers: Dict[str, DimensionMasteryTracker] = {}

        # Time-series history
        self._snapshots: Deque[DimensionSnapshot] = deque(maxlen=HISTORY_LENGTH)
        self._breakthroughs: List[BreakthroughEvent] = []
        self._emergent_capabilities: List[EmergentCapability] = []

        # Metacognition & goal tracking (fed from main.py)
        self._last_metacognition: Optional[Dict] = None
        self._last_goals: Optional[List[Dict]] = None
        self._metacognition_update_count: int = 0
        self._goal_update_count: int = 0

        # Subsystem connections for metric extraction
        self._subsystems: Dict[str, Any] = {}
        self._metric_extractors: Dict[str, Callable] = {}

        # Auto-snapshot timer
        self._last_snapshot_time: float = 0.0

        # Database connection (created in initialize())
        self._conn: Optional[sqlite3.Connection] = None

    # ── Initialization ──────────────────────────────────────────────────

    def initialize(self) -> bool:
        """
        Initialize the AGI metrics system.

        Creates per-dimension trackers, opens the database, and loads
        any previously persisted state.

        Returns:
            True if initialization succeeded.
        """
        logger.info("AGIMetrics: 초기화 시작 / Initializing...")

        # Create dimension trackers
        for dim in AGIDimension.all():
            sub_metrics = SUB_METRICS.get(dim.value, [])
            self._trackers[dim.value] = DimensionMasteryTracker(
                dimension_name=dim.value,
                sub_metrics=sub_metrics,
            )

        # Open database and load state
        try:
            self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
            self._ensure_db_schema()
            self._load_persisted_state()
        except Exception as e:
            logger.warning(f"AGIMetrics: DB 초기화 실패, 인메모리 동작 / "
                           f"DB init failed, running in-memory: {e}")
            self._conn = None

        self._last_snapshot_time = time.time()
        self._initialized = True

        logger.info("AGIMetrics: 초기화 완료 (9차원 조화평균) / "
                     "Initialized (9-dim harmonic mean)")
        return True

    def shutdown(self) -> None:
        """Persist state and close resources."""
        if self._conn:
            try:
                self._persist_state()
                self._conn.close()
            except Exception as e:
                logger.warning(f"AGIMetrics: 종료 중 오류 / Shutdown error: {e}")
        self._initialized = False
        logger.info("AGIMetrics: 종료 / Shutdown complete")

    # ── Database Schema ─────────────────────────────────────────────────

    def _ensure_db_schema(self) -> None:
        if not self._conn:
            return
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS agi_tracker_state (
                dimension TEXT PRIMARY KEY,
                state_json TEXT NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS agi_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dimensions_json TEXT NOT NULL,
                overall_agi REAL NOT NULL,
                level_name TEXT NOT NULL,
                timestamp REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS agi_breakthroughs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dimension TEXT NOT NULL,
                previous REAL NOT NULL,
                current REAL NOT NULL,
                jump REAL NOT NULL,
                timestamp REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_snap_ts ON agi_snapshots(timestamp);
        """)
        self._conn.commit()

    def _load_persisted_state(self) -> None:
        """Load tracker states and snapshots from the database."""
        if not self._conn:
            return
        # Load tracker states
        rows = self._conn.execute(
            "SELECT dimension, state_json FROM agi_tracker_state"
        ).fetchall()
        for dim_name, state_json in rows:
            if dim_name in self._trackers:
                try:
                    state = json.loads(state_json)
                    self._trackers[dim_name].load_state(state)
                except Exception as e:
                    logger.warning(f"AGIMetrics: 상태 로드 실패 {dim_name}: {e}")

        # Load recent snapshots
        rows = self._conn.execute(
            "SELECT dimensions_json, overall_agi, level_name, timestamp "
            "FROM agi_snapshots ORDER BY timestamp DESC LIMIT ?",
            (HISTORY_LENGTH,)
        ).fetchall()
        for dims_json, overall, level_name, ts in reversed(rows):
            try:
                dims = json.loads(dims_json)
                self._snapshots.append(DimensionSnapshot(
                    dimensions=dims, overall_agi=overall,
                    level_name=level_name, timestamp=ts,
                ))
            except Exception:
                pass

        logger.info(f"AGIMetrics: DB에서 {len(self._snapshots)}개 스냅샷 로드 / "
                     f"Loaded {len(self._snapshots)} snapshots from DB")

    def _persist_state(self) -> None:
        """Persist all tracker states to the database."""
        if not self._conn:
            return
        try:
            for dim_name, tracker in self._trackers.items():
                state_json = json.dumps(tracker.get_state())
                self._conn.execute(
                    "INSERT OR REPLACE INTO agi_tracker_state "
                    "(dimension, state_json, updated_at) VALUES (?, ?, ?)",
                    (dim_name, state_json, time.time()),
                )
            self._conn.commit()
        except Exception as e:
            logger.warning(f"AGIMetrics: 상태 저장 실패 / Persist failed: {e}")

    # ── Sub-Metric Recording ────────────────────────────────────────────

    def record_sub_metric(self, dimension: str, sub_metric: str,
                          value: float, weight: float = 1.0) -> None:
        """
        Record a single sub-metric observation.

        Args:
            dimension: one of AGIDimension.value strings
            sub_metric: name of the sub-metric within the dimension
            value: observation value [0, 1]
            weight: importance weight for this observation
        """
        if not self._initialized:
            return

        dim = dimension.lower()
        if dim not in self._trackers:
            logger.warning(f"AGIMetrics: 알 수 없는 차원 '{dim}' / Unknown dimension")
            return

        tracker = self._trackers[dim]
        old_mastery = tracker.get_mastery()
        tracker.update(sub_metric, value, weight)
        new_mastery = tracker.get_mastery()

        # Check for breakthrough in this dimension
        jump = new_mastery - old_mastery
        if jump >= BREAKTHROUGH_JUMP:
            bt = BreakthroughEvent(
                dimension=dim, previous=old_mastery,
                current=new_mastery, jump=jump,
            )
            self._breakthroughs.append(bt)
            logger.info(f"AGIMetrics: 돌파구! {dim} {old_mastery:.3f}→{new_mastery:.3f} "
                         f"(+{jump:.3f}) / Breakthrough!")

        # Auto-snapshot if interval elapsed
        self._maybe_auto_snapshot()

    def record_sub_metrics_batch(self, dimension: str,
                                  observations: Dict[str, float],
                                  weight: float = 1.0) -> None:
        """
        Record multiple sub-metric observations for a dimension at once.

        Args:
            dimension: dimension name
            observations: {sub_metric_name: value} dict
            weight: weight applied to all observations
        """
        for sub_metric, value in observations.items():
            self.record_sub_metric(dimension, sub_metric, value, weight)

    def record_task_result(self, dimension: str, task_name: str,
                           success: bool, score: float,
                           difficulty: float = 0.5) -> None:
        """
        Record a physical task result mapped to a dimension.

        Args:
            dimension: dimension name
            task_name: name of the task
            success: whether the task succeeded
            score: normalized score [0, 1]
            difficulty: task difficulty [0, 1]
        """
        # Weight by difficulty: harder tasks that succeed matter more
        weight = 0.5 + 0.5 * difficulty
        # Map to a generic sub-metric key
        self.record_sub_metric(dimension, f"task_{task_name}", score, weight)

    # ── Subsystem Connection ────────────────────────────────────────────

    def connect_subsystem(self, name: str, subsystem: Any,
                          metric_extractor: Optional[Callable] = None) -> None:
        """
        Connect a subsystem for periodic metric extraction.

        Args:
            name: subsystem identifier
            subsystem: the subsystem object
            metric_extractor: callable(subsystem) -> Dict[str, Dict[str, float]]
                Returns {dimension: {sub_metric: value}} mapping
        """
        with self._lock:
            self._subsystems[name] = subsystem
            if metric_extractor is not None:
                self._metric_extractors[name] = metric_extractor
        logger.info(f"AGIMetrics: 하위시스템 연결 '{name}' / Subsystem connected")

    def disconnect_subsystem(self, name: str) -> None:
        """Disconnect a subsystem."""
        with self._lock:
            self._subsystems.pop(name, None)
            self._metric_extractors.pop(name, None)

    def collect_subsystem_metrics(self) -> None:
        """Extract metrics from all connected subsystems."""
        with self._lock:
            extractors = dict(self._metric_extractors)
            subsystems = dict(self._subsystems)

        for name, extractor in extractors.items():
            try:
                result = extractor(subsystems[name])
                if isinstance(result, dict):
                    for dim_name, sub_observations in result.items():
                        if isinstance(sub_observations, dict):
                            self.record_sub_metrics_batch(dim_name, sub_observations)
            except Exception as e:
                logger.warning(f"AGIMetrics: {name} 메트릭 수집 실패 / "
                               f"Collection failed: {e}")

    # ── Metacognition & Goal Updates (from main.py) ─────────────────────

    def update_metacognition(self, assessment: Dict) -> None:
        """
        Receive metacognition assessment from the metacognition engine.

        Extracts relevant sub-metrics from the assessment dict and feeds
        them into the appropriate dimension trackers.
        """
        if not self._initialized:
            return

        self._last_metacognition = assessment
        self._metacognition_update_count += 1

        # Extract metrics from metacognition assessment
        uncertainty = assessment.get("overall_uncertainty", 0.5)
        self_knowledge = 1.0 - uncertainty  # low uncertainty → high self-knowledge

        # Feed into autonomy dimension
        self.record_sub_metric(
            "autonomy_level", "self_diagnosis",
            self_knowledge, weight=0.8,
        )

        # Metacognitive awareness maps to self-improvement
        improvement_rate = assessment.get("improvement_rate", 0.0)
        self.record_sub_metric(
            "autonomy_level", "self_improvement_rate",
            min(1.0, max(0.0, improvement_rate)), weight=0.6,
        )

        # Learning efficiency from metacognition
        learning_efficiency = assessment.get("learning_efficiency", 0.5)
        self.record_sub_metric(
            "learning_speed", "sample_efficiency",
            min(1.0, max(0.0, learning_efficiency)), weight=0.7,
        )

        # Physical understanding from uncertainty about physical predictions
        physical_confidence = assessment.get("physical_prediction_confidence", 0.5)
        self.record_sub_metric(
            "physical_understanding", "physics_prediction",
            physical_confidence, weight=0.5,
        )

    def update_goals(self, goals: List[Dict]) -> None:
        """
        Receive updated goals from the goal generator.

        Analyzes goal characteristics to inform autonomy and
        creative problem solving dimensions.
        """
        if not self._initialized:
            return

        self._last_goals = goals
        self._goal_update_count += 1

        if not goals:
            return

        # Self-directed goal ratio (goals generated by robot vs. external)
        self_directed = sum(1 for g in goals if g.get("source", "external") != "external")
        self_directed_ratio = self_directed / len(goals) if goals else 0.0
        self.record_sub_metric(
            "autonomy_level", "self_directed_goals",
            self_directed_ratio, weight=0.9,
        )

        # Goal novelty → creative problem solving
        novel_goals = sum(1 for g in goals if g.get("is_novel", False))
        novelty_ratio = novel_goals / len(goals) if goals else 0.0
        self.record_sub_metric(
            "creative_problem_solving", "novel_solution_rate",
            novelty_ratio, weight=0.6,
        )

        # Safety-aware goals
        safety_aware_goals = sum(
            1 for g in goals
            if g.get("safety_considered", False) or g.get("risk_assessed", False)
        )
        safety_ratio = safety_aware_goals / len(goals) if goals else 0.0
        self.record_sub_metric(
            "safety_awareness", "risk_assessment",
            safety_ratio, weight=0.5,
        )

    # ── Composite Scoring ───────────────────────────────────────────────

    @staticmethod
    def harmonic_mean(values: List[float]) -> float:
        """
        Compute the harmonic mean of a list of values.

        H = n / sum(1/x_i)

        The harmonic mean penalizes weak dimensions heavily — a robot
        that scores 0.01 in manipulation but 0.99 everywhere else gets
        H ≈ 0.089, not 0.88 (arithmetic mean).

        Args:
            values: list of non-negative floats

        Returns:
            harmonic mean, or 0.0 if the list is empty
        """
        if not values:
            return 0.0
        n = len(values)
        # Avoid division by zero: clamp each value to >= 0.01
        safe = [max(0.01, v) for v in values]
        return n / sum(1.0 / v for v in safe)

    def get_dimension_scores(self) -> Dict[str, float]:
        """Return current mastery score for each dimension."""
        return {dim: tracker.get_mastery() for dim, tracker in self._trackers.items()}

    def get_overall_agi(self) -> float:
        """
        Compute the overall Physical AGI score using harmonic mean
        of all 9 dimension masteries.
        """
        scores = self.get_dimension_scores()
        return self.harmonic_mean(list(scores.values()))

    def get_agi_level(self) -> AGILevel:
        """Return the current AGI level category."""
        return classify_agi_level(self.get_overall_agi())

    def get_weakest_dimension(self) -> Tuple[str, float]:
        """Return the name and score of the weakest dimension."""
        scores = self.get_dimension_scores()
        weakest = min(scores, key=scores.get)  # type: ignore
        return weakest, scores[weakest]

    def get_strongest_dimension(self) -> Tuple[str, float]:
        """Return the name and score of the strongest dimension."""
        scores = self.get_dimension_scores()
        strongest = max(scores, key=scores.get)  # type: ignore
        return strongest, scores[strongest]

    def get_dimension_confidences(self) -> Dict[str, float]:
        """Return confidence estimate for each dimension."""
        return {dim: t.get_confidence() for dim, t in self._trackers.items()}

    def get_dimension_trends(self) -> Dict[str, str]:
        """Return the current trend for each dimension."""
        return {dim: t.get_trend() for dim, t in self._trackers.items()}

    # ── Snapshot & Progress Tracking ────────────────────────────────────

    def _maybe_auto_snapshot(self) -> None:
        """Take a snapshot if enough time has elapsed since the last one."""
        now = time.time()
        if now - self._last_snapshot_time >= SNAPSHOT_INTERVAL_SEC:
            self.take_snapshot()
            self._last_snapshot_time = now

    def take_snapshot(self) -> DimensionSnapshot:
        """
        Record a snapshot of the current state of all dimensions.
        Also checks for overall breakthroughs and emergent capabilities.
        """
        scores = self.get_dimension_scores()
        overall = self.get_overall_agi()
        level = self.get_agi_level()

        snapshot = DimensionSnapshot(
            dimensions=scores,
            overall_agi=overall,
            level_name=level.name,
            timestamp=time.time(),
        )

        # Check for overall breakthrough
        if self._snapshots:
            prev_overall = self._snapshots[-1].overall_agi
            jump = overall - prev_overall
            if jump >= BREAKTHROUGH_JUMP:
                self._breakthroughs.append(BreakthroughEvent(
                    dimension="overall", previous=prev_overall,
                    current=overall, jump=jump,
                ))
                logger.info(f"AGIMetrics: 전체 돌파구! {prev_overall:.3f}→{overall:.3f} "
                             f"/ Overall breakthrough!")

        with self._lock:
            self._snapshots.append(snapshot)

        # Persist snapshot to database
        if self._conn:
            try:
                self._conn.execute(
                    "INSERT INTO agi_snapshots "
                    "(dimensions_json, overall_agi, level_name, timestamp) "
                    "VALUES (?, ?, ?, ?)",
                    (json.dumps(scores), overall, level.name, snapshot.timestamp),
                )
                self._conn.commit()
            except Exception:
                pass

        # Detect emergent capabilities
        self._detect_emergent_capabilities()

        # Persist tracker states periodically
        self._persist_state()

        return snapshot

    def get_progress_report(self) -> Dict[str, Any]:
        """
        Generate a comprehensive progress report including trends,
        plateaus, and breakthroughs.
        """
        with self._lock:
            snapshots = list(self._snapshots)

        if len(snapshots) < 2:
            return {
                "status": "insufficient_data",
                "message": "Need at least 2 snapshots for progress analysis",
                "snapshot_count": len(snapshots),
                "current_agi": self.get_overall_agi(),
                "current_level": self.get_agi_level().name,
            }

        current = snapshots[-1]
        initial = snapshots[0]

        # Time span
        time_span_h = (current.timestamp - initial.timestamp) / 3600.0

        # Overall improvement
        overall_improvement = current.overall_agi - initial.overall_agi

        # Per-dimension trends (linear regression)
        dim_trends: Dict[str, Dict[str, Any]] = {}
        for dim in AGIDimension.names():
            values = [s.dimensions.get(dim, 0.0) for s in snapshots]
            if len(values) >= 3:
                x = np.arange(len(values), dtype=float)
                y = np.array(values)
                # Simple linear regression
                n = len(x)
                sum_x = np.sum(x)
                sum_y = np.sum(y)
                sum_xy = np.sum(x * y)
                sum_x2 = np.sum(x * x)
                denom = n * sum_x2 - sum_x * sum_x
                if abs(denom) > 1e-10:
                    slope = (n * sum_xy - sum_x * sum_y) / denom
                else:
                    slope = 0.0
                # R-squared
                y_mean = np.mean(y)
                ss_tot = np.sum((y - y_mean) ** 2)
                ss_res = np.sum((y - (slope * x + (sum_y - slope * sum_x) / n)) ** 2)
                r_sq = 1.0 - ss_res / ss_tot if ss_tot > 1e-10 else 0.0

                dim_trends[dim] = {
                    "current": float(values[-1]),
                    "initial": float(values[0]),
                    "slope": float(slope),
                    "r_squared": float(r_sq),
                    "direction": (
                        "improving" if slope > 0.001 else
                        "declining" if slope < -0.001 else
                        "stable"
                    ),
                }

        # Plateau detection
        plateaus = self._detect_plateaus(snapshots)

        # Recent breakthroughs
        recent_breakthroughs = [
            {
                "dimension": bt.dimension,
                "previous": round(bt.previous, 4),
                "current": round(bt.current, 4),
                "jump": round(bt.jump, 4),
                "timestamp": bt.timestamp,
            }
            for bt in self._breakthroughs[-20:]
        ]

        return {
            "status": "ok",
            "snapshot_count": len(snapshots),
            "time_span_hours": round(time_span_h, 2),
            "current_agi": round(current.overall_agi, 4),
            "current_level": current.level_name,
            "initial_agi": round(initial.overall_agi, 4),
            "overall_improvement": round(overall_improvement, 4),
            "improvement_rate_per_hour": (
                round(overall_improvement / time_span_h, 4) if time_span_h > 0 else 0.0
            ),
            "dimension_trends": dim_trends,
            "plateaus": plateaus,
            "breakthroughs": recent_breakthroughs,
            "emergent_capabilities": [
                {
                    "name": ec.name,
                    "dimensions": ec.dimensions,
                    "combined_score": round(ec.combined_score, 4),
                    "improvement": round(ec.improvement, 4),
                }
                for ec in self._emergent_capabilities[-10:]
            ],
        }

    def _detect_plateaus(self, snapshots: List[DimensionSnapshot]) -> List[Dict]:
        """Detect plateau periods where improvement stalled."""
        plateaus = []
        if len(snapshots) < PLATEAU_WINDOW:
            return plateaus

        levels = [s.overall_agi for s in snapshots]
        for i in range(len(levels) - PLATEAU_WINDOW + 1):
            window = levels[i:i + PLATEAU_WINDOW]
            variation = max(window) - min(window)
            if variation < 0.02:
                plateaus.append({
                    "start_idx": i,
                    "end_idx": i + PLATEAU_WINDOW - 1,
                    "start_timestamp": snapshots[i].timestamp,
                    "end_timestamp": snapshots[i + PLATEAU_WINDOW - 1].timestamp,
                    "level": round(float(np.mean(window)), 4),
                    "variation": round(variation, 4),
                })

        return plateaus

    def _detect_emergent_capabilities(self) -> None:
        """
        Detect emergent capabilities arising from combinations of
        two dimensions both reaching sufficient mastery.
        """
        scores = self.get_dimension_scores()

        # Emergence rules: (dim1, dim2, capability_name, description)
        emergence_rules = [
            ("locomotion", "perception",
             "Spatial Navigation Mastery",
             "Combining movement and perception for complex navigation"),
            ("manipulation", "perception",
             "Precise Object Handling",
             "Fusing perception with manipulation for dexterous control"),
            ("learning_speed", "physical_understanding",
             "Rapid Physical Adaptation",
             "Learning speed combined with physics understanding enables fast adaptation"),
            ("autonomy_level", "safety_awareness",
             "Safe Self-Directed Operation",
             "Autonomous operation with reliable safety guardrails"),
            ("creative_problem_solving", "manipulation",
             "Tool Innovation",
             "Creative thinking applied to physical tool use and invention"),
            ("creative_problem_solving", "physical_understanding",
             "Novel Physics Exploitation",
             "Creative approaches leveraging deep physical understanding"),
            ("social_interaction", "learning_speed",
             "Social Learning",
             "Learning from and with other agents"),
            ("perception", "physical_understanding",
             "Physical World Modeling",
             "Perception grounded in causal physical understanding"),
            ("locomotion", "autonomy_level",
             "Self-Directed Exploration",
             "Autonomous movement for self-motivated exploration"),
            ("safety_awareness", "creative_problem_solving",
             "Safe Innovation",
             "Creative solutions that respect safety constraints"),
        ]

        with self._lock:
            if len(self._snapshots) < 2:
                return
            prev = self._snapshots[-2] if len(self._snapshots) >= 2 else None

        for dim1, dim2, cap_name, desc in emergence_rules:
            val1 = scores.get(dim1, 0.0)
            val2 = scores.get(dim2, 0.0)
            combined = (val1 + val2) / 2.0

            if combined < EMERGENCE_MIN_COMBINED:
                continue

            # Check if this capability was already detected
            already = any(
                ec.name == cap_name for ec in self._emergent_capabilities
            )
            if already:
                # Update the existing one
                for ec in self._emergent_capabilities:
                    if ec.name == cap_name:
                        improvement = combined - ec.combined_score
                        ec.combined_score = combined
                        ec.improvement = improvement
                continue

            # Calculate improvement from previous snapshot
            improvement = 0.0
            if prev:
                prev_val1 = prev.dimensions.get(dim1, 0.0)
                prev_val2 = prev.dimensions.get(dim2, 0.0)
                prev_combined = (prev_val1 + prev_val2) / 2.0
                improvement = combined - prev_combined

            if improvement >= EMERGENCE_MIN_IMPROVEMENT or combined >= 0.7:
                self._emergent_capabilities.append(EmergentCapability(
                    name=cap_name,
                    dimensions=[dim1, dim2],
                    combined_score=combined,
                    improvement=improvement,
                    description=desc,
                ))
                logger.info(f"AGIMetrics: 창발 능력 감지 '{cap_name}' "
                             f"({dim1}+{dim2}, combined={combined:.3f}) / "
                             f"Emergent capability detected")

    # ── Summary & Reporting ─────────────────────────────────────────────

    def get_summary(self) -> Dict[str, Any]:
        """
        Return a concise summary dict suitable for status reporting
        in the main robot system loop.

        This is the method called by main.py's get_status().
        """
        scores = self.get_dimension_scores()
        overall = self.get_overall_agi()
        level = self.get_agi_level()
        weakest_dim, weakest_val = self.get_weakest_dimension()
        strongest_dim, strongest_val = self.get_strongest_dimension()
        confidences = self.get_dimension_confidences()
        trends = self.get_dimension_trends()

        return {
            "overall_agi": round(overall, 4),
            "agi_level": level.name,
            "agi_level_description": level.description,
            "weakest_dimension": weakest_dim,
            "weakest_score": round(weakest_val, 4),
            "strongest_dimension": strongest_dim,
            "strongest_score": round(strongest_val, 4),
            "dimensions": {
                dim: {
                    "mastery": round(scores.get(dim, 0.0), 4),
                    "confidence": round(confidences.get(dim, 0.0), 4),
                    "trend": trends.get(dim, "stable"),
                    "sub_mastery": {
                        sm: round(self._trackers[dim].get_sub_mastery(sm), 4)
                        for sm in SUB_METRICS.get(dim, [])
                    } if dim in self._trackers else {},
                }
                for dim in AGIDimension.names()
            },
            "snapshot_count": len(self._snapshots),
            "breakthrough_count": len(self._breakthroughs),
            "emergent_capability_count": len(self._emergent_capabilities),
            "metacognition_updates": self._metacognition_update_count,
            "goal_updates": self._goal_update_count,
        }

    def generate_report(self) -> str:
        """
        Generate a detailed human-readable text report of the
        current AGI metrics state.
        """
        scores = self.get_dimension_scores()
        overall = self.get_overall_agi()
        level = self.get_agi_level()
        weakest_dim, weakest_val = self.get_weakest_dimension()
        strongest_dim, strongest_val = self.get_strongest_dimension()
        confidences = self.get_dimension_confidences()
        trends = self.get_dimension_trends()

        lines = [
            "=" * 65,
            "  PHYSICAL AGI METRICS REPORT / 물리적 AGI 메트릭 보고서",
            "  Jihun Robot V8.5",
            "=" * 65,
            "",
            f"  Overall AGI Score / 전체 AGI 점수:  {overall:.4f}",
            f"  Level / 수준:                      {level.name}",
            f"                                     {level.description}",
            f"  Strongest / 최강 차원:              {strongest_dim} ({strongest_val:.4f})",
            f"  Weakest / 최약 차원:                {weakest_dim} ({weakest_val:.4f})",
            "",
            "  ⚠  Harmonic Mean: weak dimensions pull score down hard.",
            "     조화평균: 약한 차원이 점수를 크게 끌어내립니다.",
            "",
            "-" * 65,
            "  DIMENSION BREAKDOWN / 차원별 상세",
            "-" * 65,
        ]

        for dim in AGIDimension.names():
            val = scores.get(dim, 0.0)
            conf = confidences.get(dim, 0.0)
            trend = trends.get(dim, "stable")
            trend_icon = {"improving": "↑", "declining": "↓", "stable": "→"}.get(trend, "?")

            bar_len = int(val * 30)
            bar = "█" * bar_len + "░" * (30 - bar_len)
            lines.append(
                f"  {dim:26s} |{bar}| {val:.3f}  conf:{conf:.2f} {trend_icon}"
            )

            # Sub-metrics detail
            if dim in self._trackers:
                sub_mastery = self._trackers[dim].get_all_sub_mastery()
                for sm_name, sm_val in sub_mastery.items():
                    sm_bar_len = int(sm_val * 20)
                    sm_bar = "▓" * sm_bar_len + "░" * (20 - sm_bar_len)
                    lines.append(
                        f"    {sm_name:30s} {sm_bar} {sm_val:.3f}"
                    )

        # Emergent capabilities
        if self._emergent_capabilities:
            lines.append("")
            lines.append("-" * 65)
            lines.append("  EMERGENT CAPABILITIES / 창발적 능력")
            lines.append("-" * 65)
            for ec in self._emergent_capabilities[-10:]:
                lines.append(f"  ★ {ec.name}")
                lines.append(f"    [{', '.join(ec.dimensions)}] "
                             f"combined={ec.combined_score:.3f} "
                             f"improvement={ec.improvement:.3f}")
                lines.append(f"    {ec.description}")

        # Recent breakthroughs
        if self._breakthroughs:
            lines.append("")
            lines.append("-" * 65)
            lines.append("  RECENT BREAKTHROUGHS / 최근 돌파구")
            lines.append("-" * 65)
            for bt in self._breakthroughs[-5:]:
                lines.append(
                    f"  ★ {bt.dimension}: {bt.previous:.3f} → {bt.current:.3f} "
                    f"(+{bt.jump:.3f})"
                )

        # Progress summary
        progress = self.get_progress_report()
        if progress.get("status") == "ok":
            lines.append("")
            lines.append("-" * 65)
            lines.append("  PROGRESS / 진행 상황")
            lines.append("-" * 65)
            lines.append(f"  Snapshots: {progress['snapshot_count']}")
            lines.append(f"  Time span: {progress['time_span_hours']:.1f} hours")
            lines.append(f"  Improvement: {progress['overall_improvement']:+.4f}")
            rate = progress.get("improvement_rate_per_hour", 0.0)
            lines.append(f"  Rate: {rate:+.6f} / hour")

            # Plateaus
            plateaus = progress.get("plateaus", [])
            if plateaus:
                lines.append(f"  Plateaus detected: {len(plateaus)}")

            # ETA estimate to next level
            current_level_obj = self.get_agi_level()
            next_level_idx = next(
                (i for i, lvl in enumerate(AGI_LEVELS)
                 if lvl.name == current_level_obj.name), -1
            )
            if next_level_idx < len(AGI_LEVELS) - 1 and rate > 0:
                next_level = AGI_LEVELS[next_level_idx + 1]
                remaining = next_level.min_score - overall
                eta_hours = remaining / rate if rate > 0 else float('inf')
                lines.append(f"  Next level: {next_level.name}")
                lines.append(f"  ETA: {eta_hours:.1f} hours" if eta_hours < 1e6
                             else "  ETA: >very long<")

        lines.append("=" * 65)
        return "\n".join(lines)

    def get_radar_chart_data(self) -> Dict[str, Any]:
        """
        Generate data suitable for a radar/spider chart visualization
        (ECharts, Plotly, matplotlib, etc.).
        """
        scores = self.get_dimension_scores()
        overall = self.get_overall_agi()
        level = self.get_agi_level()
        confidences = self.get_dimension_confidences()

        return {
            "dimensions": AGIDimension.names(),
            "values": [scores.get(d, 0.0) for d in AGIDimension.names()],
            "confidence": [confidences.get(d, 0.0) for d in AGIDimension.names()],
            "overall_agi": overall,
            "level": level.name,
            "indicators": [
                {"name": d, "max": 1.0} for d in AGIDimension.names()
            ],
            "time_series": [
                {
                    "timestamp": s.timestamp,
                    "overall_agi": s.overall_agi,
                    "level": s.level_name,
                }
                for s in list(self._snapshots)[-50:]
            ],
        }

    def get_dimension_balance_score(self) -> float:
        """
        Measure how balanced the 9 dimensions are.

        Returns 1.0 for perfectly balanced, lower for imbalanced.
        Calculated as 1 - std(dimension_scores).
        """
        scores = list(self.get_dimension_scores().values())
        return max(0.0, 1.0 - float(np.std(scores)))

    # ── Utility ─────────────────────────────────────────────────────────

    def force_snapshot(self) -> DimensionSnapshot:
        """Force a snapshot regardless of the auto-snapshot interval."""
        return self.take_snapshot()

    def get_snapshot_count(self) -> int:
        """Return the number of stored snapshots."""
        return len(self._snapshots)

    def get_observation_counts(self) -> Dict[str, int]:
        """Return the observation count for each dimension."""
        return {dim: t.observation_count for dim, t in self._trackers.items()}

    def reset_dimension(self, dimension: str) -> None:
        """Reset a single dimension tracker to its initial state."""
        if dimension in self._trackers:
            sub_metrics = SUB_METRICS.get(dimension, [])
            self._trackers[dimension] = DimensionMasteryTracker(
                dimension_name=dimension,
                sub_metrics=sub_metrics,
            )
            logger.info(f"AGIMetrics: 차원 '{dimension}' 리셋 / Dimension reset")

    def reset_all(self) -> None:
        """Reset all dimension trackers to initial state."""
        for dim in AGIDimension.all():
            self.reset_dimension(dim.value)
        self._snapshots.clear()
        self._breakthroughs.clear()
        self._emergent_capabilities.clear()
        logger.info("AGIMetrics: 전체 리셋 / All dimensions reset")


# ═══════════════════════════════════════════════════════════════════════════
# Module-level demo / Standalone test
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    # Create and initialize
    metrics = AGIMetrics(db_path=":memory:")
    metrics.initialize()

    # Simulate robot experience across dimensions
    np.random.seed(42)

    # Different dimensions have different baseline proficiencies
    baselines = {
        "locomotion": 0.65,
        "manipulation": 0.40,
        "perception": 0.55,
        "learning_speed": 0.45,
        "autonomy_level": 0.30,
        "safety_awareness": 0.70,
        "physical_understanding": 0.35,
        "creative_problem_solving": 0.20,
        "social_interaction": 0.25,
    }

    # Simulate 50 rounds of experience collection
    for round_idx in range(50):
        for dim_name, baseline in baselines.items():
            # Gradual improvement with noise
            improvement = 0.002 * round_idx
            for sub_metric in SUB_METRICS.get(dim_name, []):
                value = np.clip(
                    baseline + improvement + np.random.normal(0, 0.08),
                    0.0, 1.0,
                )
                metrics.record_sub_metric(dim_name, sub_metric, value)

        # Take a snapshot every 10 rounds
        if round_idx % 10 == 0:
            metrics.force_snapshot()

    # Feed metacognition and goal data
    metrics.update_metacognition({
        "overall_uncertainty": 0.3,
        "improvement_rate": 0.15,
        "learning_efficiency": 0.6,
        "physical_prediction_confidence": 0.45,
    })
    metrics.update_goals([
        {"description": "Explore kitchen environment", "source": "self",
         "is_novel": True, "safety_considered": True, "risk_assessed": True},
        {"description": "Grasp novel object", "source": "self",
         "is_novel": True, "safety_considered": False, "risk_assessed": True},
        {"description": "Navigate to charging station", "source": "external",
         "is_novel": False, "safety_considered": True, "risk_assessed": False},
    ])

    # Final snapshot
    metrics.force_snapshot()

    # Output reports
    print("\n" + metrics.generate_report())
    print()

    # Summary (as main.py would use it)
    summary = metrics.get_summary()
    print(f"Overall AGI: {summary['overall_agi']:.4f} ({summary['agi_level']})")
    print(f"Weakest: {summary['weakest_dimension']} ({summary['weakest_score']:.4f})")
    print(f"Strongest: {summary['strongest_dimension']} ({summary['strongest_score']:.4f})")
    print(f"Balance: {metrics.get_dimension_balance_score():.4f}")
    print(f"Breakthroughs: {summary['breakthrough_count']}")
    print(f"Emergent capabilities: {summary['emergent_capability_count']}")

    # Verify harmonic mean behavior
    print("\n--- Harmonic Mean Demonstration ---")
    print("If 8 dims = 0.90 but 1 dim = 0.01:")
    test_hm = AGIMetrics.harmonic_mean([0.9]*8 + [0.01])
    test_am = np.mean([0.9]*8 + [0.01])
    print(f"  Harmonic mean:  {test_hm:.4f}")
    print(f"  Arithmetic mean: {test_am:.4f}")
    print("  → Harmonic mean correctly penalizes the weak dimension!")

    metrics.shutdown()
    logger.info("agi_metrics.py demo complete")
