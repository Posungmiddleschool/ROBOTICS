#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — 파지 진화 시스템 (Grasp Evolution System)
=========================================================

파지 성공/실패 기록 → 자가 진화 → 접근 각도/힘 조정
EWC-LoRA 가중치 업데이트 (수면 학습 시)

아키텍처 / Architecture:
  - 파지 시도 기록: 접근 각도, 파지력, 물체 타입, 성공/실패
  - 패턴 분석: 물체 타입별 최적 파지 파라미터 추출
  - 개선 제안: 접근 각도, 파지력, 손목 회전 보정
  - EWC-LoRA 업데이트: 수면 학습 시 가중치 갱신

성능 목표 / Performance Targets:
  - 초기 파지 성공률: ~70%
  - 10회 반복 후: >85%
  - 50회 반복 후: >90%

학습 파라미터 / Learning Parameters:
  - EWC Fisher 정보 행렬: 치명적 망각 방지
  - LoRA rank: 16, alpha: 32
  - 학습률: 1e-4
  - 수면 학습 주기: 유휴 시 5분마다

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import math
import os
import sqlite3
import threading
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V8.5.GraspEvolution")

# ============================================================================
# 상수 정의 (Constants)
# ============================================================================

# 학습 파라미터 / Learning parameters
EWL_LORA_RANK: int = 16               # LoRA 랭크
EWL_LORA_ALPHA: int = 32              # LoRA 알파
EWC_LEARNING_RATE: float = 1e-4       # 학습률
EWC_GAMMA: float = 1000.0             # EWC 정규화 계수
SLEEP_LEARNING_INTERVAL_S: float = 300.0  # 5분마다 수면 학습

# 파지 파라미터 범위 / Grasp parameter ranges
APPROACH_ANGLE_MIN_DEG: float = -90.0
APPROACH_ANGLE_MAX_DEG: float = 90.0
GRIP_FORCE_MIN_N: float = 1.0
GRIP_FORCE_MAX_N: float = 10.0
WRIST_YAW_MIN_DEG: float = -90.0
WRIST_YAW_MAX_DEG: float = 90.0

# 성공률 목표 / Success rate targets
INITIAL_SUCCESS_RATE_PCT: float = 70.0
TARGET_SUCCESS_RATE_10_PCT: float = 85.0
TARGET_SUCCESS_RATE_50_PCT: float = 90.0

# 데이터베이스 / Database
DB_PATH: str = "/opt/jihun/data/grasp_evolution.db"
DB_DIR: str = "/opt/jihun/data"

# 물체 타입 분류 / Object type categories
OBJECT_CATEGORIES: Dict[str, List[str]] = {
    "cup": ["cup", "mug", "glass", "tumbler"],
    "bottle": ["bottle", "flask", "container"],
    "box": ["box", "cube", "package", "carton"],
    "sphere": ["ball", "orange", "apple", "sphere"],
    "flat": ["plate", "book", "tablet", "phone"],
}


# ============================================================================
# 열거형 (Enumerations)
# ============================================================================

class GraspOutcome(Enum):
    """파지 결과 / Grasp outcome"""
    SUCCESS = "success"           # 성공
    MISS = "miss"                 # 놓침
    SLIP = "slip"                 # 미끄러짐
    OVERFORCE = "overforce"       # 과도한 힘
    OBJECT_LOST = "object_lost"   # 물체 분실
    TIMEOUT = "timeout"           # 시간 초과


class EvolutionPhase(Enum):
    """진화 단계 / Evolution phase"""
    BOOTSTRAP = "bootstrap"    # 초기 (데이터 수집)
    ADAPTING = "adapting"       # 적응 (파라미터 조정)
    REFINING = "refining"       # 정제 (미세 조정)
    CREATIVE = "creative"       # 창조 (새 전략 탐색)


# ============================================================================
# 데이터 클래스 (Data Classes)
# ============================================================================

@dataclass
class GraspAttempt:
    """단일 파지 시도 기록 / Single grasp attempt record"""
    attempt_id: int = 0
    object_label: str = ""
    object_category: str = ""
    approach_angle_deg: float = 0.0
    grip_force_n: float = 5.0
    wrist_yaw_deg: float = 0.0
    finger_angle_deg: float = 90.0
    outcome: GraspOutcome = GraspOutcome.SUCCESS
    actual_force_n: float = 0.0
    position_error_mm: float = 0.0
    duration_ms: float = 0.0
    timestamp: float = field(default_factory=time.monotonic)

    @property
    def is_success(self) -> bool:
        return self.outcome == GraspOutcome.SUCCESS


@dataclass
class GraspParameters:
    """파지 파라미터 세트 / Grasp parameter set"""
    approach_angle_deg: float = 0.0
    grip_force_n: float = 5.0
    wrist_yaw_deg: float = 0.0
    finger_angle_deg: float = 90.0
    confidence: float = 0.0         # 파라미터 신뢰도
    sample_count: int = 0           # 기반 샘플 수


@dataclass
class EvolutionMetrics:
    """진화 지표 / Evolution metrics"""
    total_attempts: int = 0
    total_successes: int = 0
    success_rate_pct: float = 0.0
    recent_success_rate_pct: float = 0.0   # 최근 10회
    best_success_rate_pct: float = 0.0
    evolution_phase: EvolutionPhase = EvolutionPhase.BOOTSTRAP
    unique_objects: int = 0
    categories_learned: int = 0
    parameters_updated: int = 0
    sleep_learning_count: int = 0
    timestamp: float = field(default_factory=time.monotonic)


# ============================================================================
# GraspEvolution 클래스
# ============================================================================

class GraspEvolution:
    """
    파지 진화 시스템 / Grasp Evolution System.

    파지 시도를 기록하고 패턴을 분석하여 파지 파라미터를 자가 개선.
    EWC-LoRA로 수면 학습 시 가중치 업데이트.

    Features:
    - 파지 시도 기록 (SQLite 영속화)
    - 물체 카테고리별 최적 파라미터 분석
    - 접근 각도/파지력/손목 회전 개선 제안
    - EWC-LoRA 가중치 업데이트 (수면 학습)
    - 진화 단계 추적 (부트스트랩→적응→정제→창조)

    Usage:
        ge = GraspEvolution()
        ge.record_attempt(attempt)                   # 시도 기록
        patterns = ge.analyze_patterns()             # 패턴 분석
        suggestions = ge.suggest_improvements("cup") # 개선 제안
        ge.update_parameters("cup", new_params)      # 파라미터 업데이트
    """

    def __init__(
        self,
        db_path: str = DB_PATH,
        simulation_mode: bool = True,
    ):
        """
        파지 진화 시스템 초기화 / Initialize grasp evolution system.

        Args:
            db_path: SQLite 데이터베이스 경로
            simulation_mode: 시뮬레이션 모드
        """
        self._db_path = db_path
        self._simulation = simulation_mode
        self._lock = threading.Lock()

        # 시도 기록 (인메모리 버퍼) / Attempt records (in-memory buffer)
        self._attempts: List[GraspAttempt] = []
        self._max_buffer_size: int = 1000

        # 카테고리별 최적 파라미터 / Category-wise optimal parameters
        self._optimal_params: Dict[str, GraspParameters] = {}

        # 진화 지표 / Evolution metrics
        self._metrics = EvolutionMetrics()

        # EWC-LoRA 상태 / EWC-LoRA state
        self._fisher_matrix: Dict[str, float] = {}
        self._optimal_weights: Dict[str, float] = {}
        self._lora_weights: Dict[str, float] = {}
        self._sleep_learning_running: bool = False

        # 데이터베이스 초기화 / Initialize database
        self._init_database()

        logger.info("GraspEvolution 초기화 완료 / Init complete "
                     f"(db={db_path}, sim={simulation_mode})")

    # ── 데이터베이스 / Database ──

    def _init_database(self) -> None:
        """SQLite 데이터베이스 초기화 / Initialize SQLite database."""
        try:
            os.makedirs(DB_DIR, exist_ok=True)
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()

            # 파지 시도 테이블 / Grasp attempts table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS grasp_attempts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    object_label TEXT NOT NULL,
                    object_category TEXT DEFAULT '',
                    approach_angle_deg REAL DEFAULT 0,
                    grip_force_n REAL DEFAULT 5.0,
                    wrist_yaw_deg REAL DEFAULT 0,
                    finger_angle_deg REAL DEFAULT 90,
                    outcome TEXT NOT NULL,
                    actual_force_n REAL DEFAULT 0,
                    position_error_mm REAL DEFAULT 0,
                    duration_ms REAL DEFAULT 0,
                    timestamp REAL DEFAULT 0
                )
            """)

            # 최적 파라미터 테이블 / Optimal parameters table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS optimal_parameters (
                    category TEXT PRIMARY KEY,
                    approach_angle_deg REAL DEFAULT 0,
                    grip_force_n REAL DEFAULT 5.0,
                    wrist_yaw_deg REAL DEFAULT 0,
                    finger_angle_deg REAL DEFAULT 90,
                    confidence REAL DEFAULT 0,
                    sample_count INTEGER DEFAULT 0,
                    updated_at REAL DEFAULT 0
                )
            """)

            conn.commit()
            conn.close()
            logger.info("데이터베이스 초기화 완료 / DB init complete")

        except Exception as e:
            logger.warning(f"데이터베이스 초기화 실패: {e}")

    # ── 1단계: 시도 기록 / Step 1: Record Attempt ──

    def record_attempt(self, attempt: GraspAttempt) -> bool:
        """
        파지 시도 기록 / Record a grasp attempt.

        성공/실패 여부와 파지 파라미터를 기록.
        향후 패턴 분석에 사용.

        Args:
            attempt: GraspAttempt 파지 시도 데이터

        Returns:
            기록 성공 여부
        """
        with self._lock:
            # 물체 카테고리 분류 / Classify object category
            attempt.object_category = self._classify_object(attempt.object_label)
            attempt.attempt_id = len(self._attempts) + 1

            # 인메모리 버퍼에 추가 / Add to in-memory buffer
            self._attempts.append(attempt)
            if len(self._attempts) > self._max_buffer_size:
                self._attempts = self._attempts[-self._max_buffer_size:]

            # 데이터베이스에 영속화 / Persist to database
            self._persist_attempt(attempt)

            # 메트릭 업데이트 / Update metrics
            self._update_metrics(attempt)

        logger.info(f"파지 시도 기록: {attempt.object_label} "
                     f"→ {attempt.outcome.value} "
                     f"(각도={attempt.approach_angle_deg:.1f}°, "
                     f"힘={attempt.grip_force_n:.1f}N)")
        return True

    def _persist_attempt(self, attempt: GraspAttempt) -> None:
        """파지 시도를 DB에 저장 / Persist attempt to database."""
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO grasp_attempts
                (object_label, object_category, approach_angle_deg,
                 grip_force_n, wrist_yaw_deg, finger_angle_deg,
                 outcome, actual_force_n, position_error_mm,
                 duration_ms, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                attempt.object_label, attempt.object_category,
                attempt.approach_angle_deg, attempt.grip_force_n,
                attempt.wrist_yaw_deg, attempt.finger_angle_deg,
                attempt.outcome.value, attempt.actual_force_n,
                attempt.position_error_mm, attempt.duration_ms,
                attempt.timestamp,
            ))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"DB 저장 실패: {e}")

    def _classify_object(self, label: str) -> str:
        """물체 레이블 → 카테고리 분류 / Classify object label to category."""
        label_lower = label.lower()
        for category, keywords in OBJECT_CATEGORIES.items():
            if any(kw in label_lower for kw in keywords):
                return category
        return "unknown"

    def _update_metrics(self, attempt: GraspAttempt) -> None:
        """진화 메트릭 업데이트 / Update evolution metrics."""
        self._metrics.total_attempts += 1
        if attempt.is_success:
            self._metrics.total_successes += 1

        # 전체 성공률 / Overall success rate
        self._metrics.success_rate_pct = (
            self._metrics.total_successes / self._metrics.total_attempts * 100
            if self._metrics.total_attempts > 0 else 0.0
        )

        # 최근 10회 성공률 / Recent 10 attempts success rate
        recent = self._attempts[-10:]
        if recent:
            recent_successes = sum(1 for a in recent if a.is_success)
            self._metrics.recent_success_rate_pct = recent_successes / len(recent) * 100

        # 최고 성공률 / Best success rate
        self._metrics.best_success_rate_pct = max(
            self._metrics.best_success_rate_pct,
            self._metrics.recent_success_rate_pct,
        )

        # 진화 단계 판정 / Determine evolution phase
        if self._metrics.total_attempts < 10:
            self._metrics.evolution_phase = EvolutionPhase.BOOTSTRAP
        elif self._metrics.recent_success_rate_pct < 80:
            self._metrics.evolution_phase = EvolutionPhase.ADAPTING
        elif self._metrics.recent_success_rate_pct < 90:
            self._metrics.evolution_phase = EvolutionPhase.REFINING
        else:
            self._metrics.evolution_phase = EvolutionPhase.CREATIVE

        # 고유 물체 수 / Unique objects count
        self._metrics.unique_objects = len(set(
            a.object_label for a in self._attempts
        ))

        # 학습 카테고리 수 / Learned categories count
        self._metrics.categories_learned = len(set(
            a.object_category for a in self._attempts
            if a.is_success
        ))

    # ── 2단계: 패턴 분석 / Step 2: Pattern Analysis ──

    def analyze_patterns(self, category: Optional[str] = None
                         ) -> Dict[str, Any]:
        """
        파지 패턴 분석 / Analyze grasp patterns.

        카테고리별 성공/실패 패턴을 통계적으로 분석.

        Args:
            category: 특정 카테고리, None이면 전체

        Returns:
            분석 결과 딕셔너리
        """
        with self._lock:
            # 대상 시도 필터링 / Filter target attempts
            if category:
                attempts = [a for a in self._attempts
                            if a.object_category == category]
            else:
                attempts = list(self._attempts)

            if not attempts:
                return {"category": category or "all", "attempts": 0}

            # 기본 통계 / Basic statistics
            total = len(attempts)
            successes = [a for a in attempts if a.is_success]
            failures = [a for a in attempts if not a.is_success]
            success_rate = len(successes) / total * 100 if total > 0 else 0.0

            # 성공 시 파라미터 통계 / Success parameter statistics
            result = {
                "category": category or "all",
                "total_attempts": total,
                "successes": len(successes),
                "failures": len(failures),
                "success_rate_pct": round(success_rate, 1),
            }

            if successes:
                # 성공 시 평균 파라미터 / Average parameters on success
                avg_angle = sum(a.approach_angle_deg for a in successes) / len(successes)
                avg_force = sum(a.grip_force_n for a in successes) / len(successes)
                avg_wrist = sum(a.wrist_yaw_deg for a in successes) / len(successes)

                result["success_avg"] = {
                    "approach_angle_deg": round(avg_angle, 1),
                    "grip_force_n": round(avg_force, 1),
                    "wrist_yaw_deg": round(avg_wrist, 1),
                }

            if failures:
                # 실패 원인 분포 / Failure cause distribution
                failure_causes = Counter(a.outcome.value for a in failures)
                result["failure_causes"] = dict(failure_causes)

                # 실패 시 평균 파라미터 / Average parameters on failure
                avg_angle = sum(a.approach_angle_deg for a in failures) / len(failures)
                avg_force = sum(a.grip_force_n for a in failures) / len(failures)

                result["failure_avg"] = {
                    "approach_angle_deg": round(avg_angle, 1),
                    "grip_force_n": round(avg_force, 1),
                }

            # 물체별 성공률 / Per-object success rate
            object_stats = defaultdict(lambda: {"success": 0, "total": 0})
            for a in attempts:
                object_stats[a.object_label]["total"] += 1
                if a.is_success:
                    object_stats[a.object_label]["success"] += 1

            result["per_object"] = {
                obj: round(stats["success"] / stats["total"] * 100, 1)
                for obj, stats in object_stats.items()
                if stats["total"] >= 2
            }

            return result

    # ── 3단계: 개선 제안 / Step 3: Suggest Improvements ──

    def suggest_improvements(self, object_label: str) -> GraspParameters:
        """
        파지 개선 제안 / Suggest grasp improvements.

        과거 기록 분석으로 최적 파지 파라미터 제안.

        Args:
            object_label: 물체 레이블

        Returns:
            GraspParameters 제안 파라미터
        """
        category = self._classify_object(object_label)

        # 카테고리별 최적 파라미터 확인 / Check category optimal params
        if category in self._optimal_params:
            cached = self._optimal_params[category]
            if cached.confidence > 0.5 and cached.sample_count >= 5:
                logger.info(f"최적 파라미터 사용: {category} "
                             f"(신뢰도={cached.confidence:.2f})")
                return cached

        # 동일 물체 과거 성공 기록 분석 / Analyze past success for same object
        with self._lock:
            successes = [
                a for a in self._attempts
                if a.object_label == object_label and a.is_success
            ]
            all_attempts = [
                a for a in self._attempts
                if a.object_label == object_label
            ]

        if len(successes) >= 3:
            # 성공 기록의 가중 평균 (최근 기록 가중) / Weighted avg of successes
            weights = [1.0 + i * 0.1 for i in range(len(successes))]
            total_w = sum(weights)

            avg_angle = sum(a.approach_angle_deg * w
                            for a, w in zip(successes, weights)) / total_w
            avg_force = sum(a.grip_force_n * w
                            for a, w in zip(successes, weights)) / total_w
            avg_wrist = sum(a.wrist_yaw_deg * w
                            for a, w in zip(successes, weights)) / total_w

            confidence = len(successes) / max(len(all_attempts), 1)

            params = GraspParameters(
                approach_angle_deg=round(avg_angle, 1),
                grip_force_n=round(avg_force, 1),
                wrist_yaw_deg=round(avg_wrist, 1),
                confidence=confidence,
                sample_count=len(successes),
            )

            logger.info(f"개선 제안 ({object_label}): "
                         f"각도={avg_angle:.1f}°, 힘={avg_force:.1f}N, "
                         f"손목={avg_wrist:.1f}°, 신뢰도={confidence:.2f}")
            return params

        # 카테고리 기본값 / Category defaults
        defaults = {
            "cup": GraspParameters(approach_angle_deg=0.0, grip_force_n=3.0,
                                    wrist_yaw_deg=0.0, confidence=0.1),
            "bottle": GraspParameters(approach_angle_deg=0.0, grip_force_n=7.0,
                                       wrist_yaw_deg=0.0, confidence=0.1),
            "box": GraspParameters(approach_angle_deg=0.0, grip_force_n=5.0,
                                    wrist_yaw_deg=0.0, confidence=0.1),
            "sphere": GraspParameters(approach_angle_deg=15.0, grip_force_n=4.0,
                                       wrist_yaw_deg=0.0, confidence=0.1),
            "flat": GraspParameters(approach_angle_deg=30.0, grip_force_n=2.0,
                                     wrist_yaw_deg=0.0, confidence=0.1),
        }

        params = defaults.get(category, GraspParameters(confidence=0.0))
        logger.info(f"기본 파라미터 사용: {category}")
        return params

    # ── 4단계: 파라미터 업데이트 / Step 4: Update Parameters ──

    def update_parameters(self, category: str,
                          params: GraspParameters) -> bool:
        """
        카테고리 최적 파라미터 업데이트 / Update optimal parameters for category.

        EWC-LoRA 기반으로 기존 지식 보존하며 새 파라미터 반영.

        Args:
            category: 물체 카테고리
            params: 새 파라미터

        Returns:
            업데이트 성공 여부
        """
        with self._lock:
            # EWC 정규화: 기존 최적값에서 너무 멀어지지 않도록 제한
            # EWC regularization: prevent drift from previous optimum
            if category in self._optimal_params:
                old = self._optimal_params[category]
                # Fisher 정보 행렬 기반 제약 / Fisher information-based constraint
                fisher = self._fisher_matrix.get(category, 1.0)
                ewc_penalty = EWC_GAMMA * fisher

                # 새 파라미터 = (1-α)*기존 + α*새값, α는 신뢰도 비례
                alpha = min(params.confidence, 0.5)  # 최대 50% 업데이트
                blended = GraspParameters(
                    approach_angle_deg=old.approach_angle_deg * (1 - alpha)
                    + params.approach_angle_deg * alpha,
                    grip_force_n=old.grip_force_n * (1 - alpha)
                    + params.grip_force_n * alpha,
                    wrist_yaw_deg=old.wrist_yaw_deg * (1 - alpha)
                    + params.wrist_yaw_deg * alpha,
                    confidence=max(old.confidence, params.confidence),
                    sample_count=old.sample_count + params.sample_count,
                )
                self._optimal_params[category] = blended
            else:
                self._optimal_params[category] = params

            # Fisher 정보 행렬 업데이트 / Update Fisher information matrix
            self._update_fisher_matrix(category)

            # DB에 저장 / Save to DB
            self._persist_optimal_params(category)

            self._metrics.parameters_updated += 1

        logger.info(f"파라미터 업데이트: {category} "
                     f"→ 각도={self._optimal_params[category].approach_angle_deg:.1f}°, "
                     f"힘={self._optimal_params[category].grip_force_n:.1f}N")
        return True

    def _update_fisher_matrix(self, category: str) -> None:
        """Fisher 정보 행렬 업데이트 / Update Fisher information matrix."""
        # 카테고리의 파라미터 분산을 Fisher 정보로 근사
        # Approximate Fisher information from parameter variance
        attempts = [a for a in self._attempts
                    if a.object_category == category and a.is_success]
        if len(attempts) >= 2:
            angles = [a.approach_angle_deg for a in attempts]
            mean_angle = sum(angles) / len(angles)
            variance = sum((a - mean_angle) ** 2 for a in angles) / len(angles)
            self._fisher_matrix[category] = 1.0 / max(variance, 0.01)

    def _persist_optimal_params(self, category: str) -> None:
        """최적 파라미터를 DB에 저장 / Persist optimal parameters to DB."""
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            params = self._optimal_params[category]
            cursor.execute("""
                INSERT OR REPLACE INTO optimal_parameters
                (category, approach_angle_deg, grip_force_n,
                 wrist_yaw_deg, finger_angle_deg,
                 confidence, sample_count, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                category, params.approach_angle_deg, params.grip_force_n,
                params.wrist_yaw_deg, params.finger_angle_deg,
                params.confidence, params.sample_count, time.monotonic(),
            ))
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug(f"DB 저장 실패: {e}")

    # ── 수면 학습 / Sleep Learning ──

    def start_sleep_learning(self) -> None:
        """수면 학습 시작 / Start sleep learning."""
        if self._sleep_learning_running:
            return

        self._sleep_learning_running = True
        thread = threading.Thread(
            target=self._sleep_learning_loop, daemon=True,
            name="GraspSleepLearning"
        )
        thread.start()
        logger.info("수면 학습 시작 / Sleep learning started")

    def stop_sleep_learning(self) -> None:
        """수면 학습 중지 / Stop sleep learning."""
        self._sleep_learning_running = False
        logger.info("수면 학습 중지 / Sleep learning stopped")

    def _sleep_learning_loop(self) -> None:
        """수면 학습 루프 / Sleep learning loop (5분 주기)."""
        while self._sleep_learning_running:
            try:
                self._run_sleep_learning_session()
                self._metrics.sleep_learning_count += 1
            except Exception as e:
                logger.error(f"수면 학습 오류: {e}")

            time.sleep(SLEEP_LEARNING_INTERVAL_S)

    def _run_sleep_learning_session(self) -> None:
        """단일 수면 학습 세션 / Single sleep learning session."""
        logger.info("수면 학습 세션 시작 / Sleep learning session started")

        # 1. 경험 재생 (40%) / Experience replay (40%)
        categories = set(a.object_category for a in self._attempts)
        for category in categories:
            analysis = self.analyze_patterns(category)
            if "success_avg" in analysis:
                avg = analysis["success_avg"]
                new_params = GraspParameters(
                    approach_angle_deg=avg["approach_angle_deg"],
                    grip_force_n=avg["grip_force_n"],
                    wrist_yaw_deg=avg["wrist_yaw_deg"],
                    confidence=analysis["success_rate_pct"] / 100.0,
                    sample_count=analysis["total_attempts"],
                )
                self.update_parameters(category, new_params)

        # 2. 합성 데이터 생성 (30%) / Synthetic data generation (30%)
        # 기존 성공 파라미터 주변 탐색 / Explore around successful params
        for category, params in list(self._optimal_params.items()):
            exploration = GraspParameters(
                approach_angle_deg=params.approach_angle_deg
                + (hash(f"{category}{time.monotonic_ns()}") % 20 - 10),
                grip_force_n=max(GRIP_FORCE_MIN_N,
                                 min(GRIP_FORCE_MAX_N,
                                     params.grip_force_n + 0.5)),
                wrist_yaw_deg=params.wrist_yaw_deg,
                confidence=params.confidence * 0.8,
                sample_count=1,
            )
            # 신뢰도가 높으면 탐색 결과 반영 / Reflect exploration if confident
            if params.confidence > 0.7:
                self.update_parameters(category, exploration)

        # 3. EWC-LoRA 가중치 업데이트 / EWC-LoRA weight update
        self._update_lora_weights()

        logger.info("수면 학습 세션 완료 / Sleep learning session complete")

    def _update_lora_weights(self) -> None:
        """LoRA 가중치 업데이트 / Update LoRA weights."""
        # EWC 정규화 손실: L = L_task + λ/2 * Σ F_i * (θ - θ*_i)²
        for category in self._optimal_params:
            old_weight = self._lora_weights.get(category, 0.0)
            fisher = self._fisher_matrix.get(category, 1.0)

            # 새 가중치 = 기존 + 학습률 * 그래디언트 - EWC 패널티
            gradient = self._compute_gradient(category)
            ewc_penalty = (EWC_GAMMA * fisher *
                           (old_weight - self._optimal_weights.get(category, 0.0)))

            new_weight = old_weight + EWC_LEARNING_RATE * (gradient - ewc_penalty)
            self._lora_weights[category] = new_weight

    def _compute_gradient(self, category: str) -> float:
        """카테고리별 그래디언트 계산 / Compute gradient for category."""
        attempts = [a for a in self._attempts
                    if a.object_category == category]
        if not attempts:
            return 0.0

        # 최근 성공률 기반 그래디언트 / Gradient based on recent success rate
        recent = attempts[-20:]
        success_rate = sum(1 for a in recent if a.is_success) / len(recent)
        return (success_rate - 0.5) * 2.0  # -1.0 ~ 1.0 범위

    # ── 진화 보고서 / Evolution Report ──

    def get_evolution_metrics(self) -> EvolutionMetrics:
        """진화 지표 조회 / Get evolution metrics."""
        return self._metrics

    def get_evolution_report(self) -> Dict[str, Any]:
        """
        진화 보고서 생성 / Generate evolution report.

        Returns:
            진화 보고서 딕셔너리
        """
        metrics = self.get_evolution_metrics()
        return {
            "version": "V8.5",
            "total_attempts": metrics.total_attempts,
            "total_successes": metrics.total_successes,
            "success_rate_pct": round(metrics.success_rate_pct, 1),
            "recent_success_rate_pct": round(metrics.recent_success_rate_pct, 1),
            "best_success_rate_pct": round(metrics.best_success_rate_pct, 1),
            "evolution_phase": metrics.evolution_phase.value,
            "unique_objects": metrics.unique_objects,
            "categories_learned": metrics.categories_learned,
            "parameters_updated": metrics.parameters_updated,
            "sleep_learning_count": metrics.sleep_learning_count,
            "optimal_parameters": {
                cat: {
                    "angle": p.approach_angle_deg,
                    "force": p.grip_force_n,
                    "wrist": p.wrist_yaw_deg,
                    "confidence": round(p.confidence, 3),
                    "samples": p.sample_count,
                }
                for cat, p in self._optimal_params.items()
            },
        }
