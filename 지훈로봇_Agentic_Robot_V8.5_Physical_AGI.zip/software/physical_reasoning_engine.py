#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — 물리 추론 엔진 (Physical Reasoning Engine)
============================================================

로봇이 물리적 세계의 규칙을 이해하고 추론합니다.
이것이 바로 Physical AGI의 핵심 — 몸 달린 AI의 "물리적 지능"입니다.

혁신 포인트:
  - 대기업: 규칙 기반 하드코딩 → 예외 상황에 무력
  - 우리: AI가 물리적 상식을 추론 → 처음 보는 상황도 대처

물리적 지능이란:
  - 무거운 것을 들면 팔이 아프다 → 과부하 방지
  - 물이 있는 바닥은 미끄럽다 → 속도 조절
  - 유리는 깨지기 쉽다 → 힘 조절
  - 뜨거운 것은 조심해야 한다 → 온도 확인 후 접근
  - 무게중심이 흔들리면 넘어진다 → 균형 유지

작성자: 안지훈 (보성중학교 2학년 4반 10번)
버전: V8.5
"""

from __future__ import annotations

import json
import logging
import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("jihun.v85.physical_reasoning")
logger.setLevel(logging.DEBUG)


class PhysicalProperty(Enum):
    """물리적 속성 / Physical properties"""
    MASS = "mass"
    FRAGILITY = "fragility"
    FRICTION = "friction"
    HARDNESS = "hardness"
    TEMPERATURE = "temperature"
    ELASTICITY = "elasticity"
    CONDUCTIVITY = "conductivity"
    TRANSPARENCY = "transparency"


class PhysicalActionType(Enum):
    """물리적 행동 유형 / Physical action types"""
    GRASP = "grasp"
    LIFT = "lift"
    PUSH = "push"
    PULL = "pull"
    THROW = "throw"
    PLACE = "place"
    SLIDE = "slide"
    ROTATE = "rotate"
    HEAT = "heat"
    COOL = "cool"
    CUT = "cut"
    POUR = "pour"


@dataclass
class PhysicalObject:
    """물리적 객체 — 로봇이 상호작용하는 대상"""
    object_id: str = ""
    name: str = ""
    mass_kg: float = 0.1
    fragility: float = 0.5      # 0=단단, 1=매우 깨지기 쉬움
    friction: float = 0.5       # 표면 마찰계수
    hardness: float = 0.5       # 경도
    temperature_c: float = 20.0 # 온도
    elasticity: float = 0.0     # 탄성
    is_hot: bool = False
    is_sharp: bool = False
    is_wet: bool = False
    is_breakable: bool = False
    dimensions_m: Tuple[float, float, float] = (0.1, 0.1, 0.1)

    @classmethod
    def from_name(cls, name: str) -> "PhysicalObject":
        """이름으로부터 객체 속성 추론 (AI가 학습한 지식 기반)"""
        # 일반적인 객체의 물리적 속성 (경험에서 학습 가능)
        object_db = {
            "유리잔": cls(name="유리잔", mass_kg=0.2, fragility=0.8, friction=0.4, hardness=0.3, is_breakable=True),
            "계란": cls(name="계란", mass_kg=0.06, fragility=0.9, friction=0.3, hardness=0.1, is_breakable=True),
            "책": cls(name="책", mass_kg=0.3, fragility=0.2, friction=0.6, hardness=0.4),
            "스마트폰": cls(name="스마트폰", mass_kg=0.2, fragility=0.7, friction=0.3, hardness=0.5, is_breakable=True),
            "우유": cls(name="우유", mass_kg=1.0, fragility=0.1, friction=0.4, hardness=0.05, is_wet=True),
            "냄비": cls(name="냄비", mass_kg=0.8, fragility=0.05, friction=0.5, hardness=0.9, is_hot=True),
            "가위": cls(name="가위", mass_kg=0.1, fragility=0.05, friction=0.6, hardness=0.8, is_sharp=True),
            "야구공": cls(name="야구공", mass_kg=0.15, fragility=0.05, friction=0.7, hardness=0.4, elasticity=0.8),
            "빵": cls(name="빵", mass_kg=0.3, fragility=0.3, friction=0.5, hardness=0.1),
        }
        return object_db.get(name, cls(name=name))


@dataclass
class PhysicalPrediction:
    """물리적 예측 결과"""
    action: PhysicalActionType = PhysicalActionType.GRASP
    object_name: str = ""
    predicted_outcome: str = ""
    success_probability: float = 0.5
    risk_level: str = "safe"
    recommended_force_n: float = 5.0
    warnings: List[str] = field(default_factory=list)
    alternative_actions: List[str] = field(default_factory=list)


class PhysicalReasoningEngine:
    """
    물리 추론 엔진 — 로봇의 "물리적 상식"
    
    이 엔진은 하드코딩된 규칙이 아닌, 물리적 원리에 기반한 추론을 수행합니다.
    경험을 통해 지속적으로 학습하고 개선됩니다.
    
    대기업과의 차이:
    - 테슬라 Optimus: 각 동작을 규칙으로 정의
    - 유니트리 G1: 미리 정의된 궤적 추종
    - 지훈 로봇 V8.5: AI가 물리적 상황을 이해하고 스스로 판단
    """

    def __init__(self, gemma4_inference: Optional[Any] = None):
        self._gemma4 = gemma4_inference
        self._experience_db: Dict[str, deque] = {}
        self._lock = threading.Lock()
        
        # 물리적 상식 베이스 / Physical common sense base
        self._common_sense = self._init_physical_common_sense()
        
        logger.info("PhysicalReasoningEngine V8.5 초기화 완료")

    def _init_physical_common_sense(self) -> Dict[str, Any]:
        """
        물리적 상식 초기화 — 로봇이 태어날 때부터 알아야 할 기본 지식
        
        이것은 하드코딩된 규칙이 아닌, 물리적 법칙에 기반한 기본 상식입니다.
        마치 아기가 중력을 이해하는 것과 같습니다.
        """
        return {
            "gravity": {
                "acceleration_ms2": 9.81,
                "rule": "모든 물체는 아래로 떨어진다",
                "implication": "물체를 놓으면 바닥으로 떨어지므로 주의해서 놓아야 함",
            },
            "friction": {
                "dry_coefficient": 0.7,
                "wet_coefficient": 0.3,
                "ice_coefficient": 0.1,
                "rule": "마찰이 낮으면 미끄러진다",
                "implication": "물/얼음 위에서는 속도를 줄이고 조심해서 이동",
            },
            "fragility": {
                "glass_break_force_n": 15.0,
                "egg_break_force_n": 8.0,
                "ceramic_break_force_n": 20.0,
                "rule": "깨지기 쉬운 물체는 힘을 줄여서 잡아야 한다",
                "implication": "물체의 재질을 먼저 파악하고 적절한 힘으로 파지",
            },
            "heat": {
                "safe_touch_temp_c": 45.0,
                "warning_temp_c": 55.0,
                "danger_temp_c": 70.0,
                "rule": "뜨거운 것은 화상을 입힌다",
                "implication": "온도를 먼저 확인하고, 뜨거우면 보호 장구 사용",
            },
            "weight": {
                "max_safe_lift_kg": 5.0,
                "strain_threshold_kg": 3.0,
                "rule": "너무 무거운 것은 들 수 없다",
                "implication": "물체의 무게를 추정하고, 한계 초과 시 분할하거나 도움 요청",
            },
            "balance": {
                "max_com_offset_mm": 50.0,
                "stability_threshold": 0.5,
                "rule": "무게중심이 흔들리면 넘어진다",
                "implication": "무거운 물체를 들 때는 무게중심을 낮추고 천천히 이동",
            },
        }

    def reason_about_action(
        self,
        action: PhysicalActionType,
        obj: PhysicalObject,
        context: Optional[Dict] = None,
    ) -> PhysicalPrediction:
        """
        행동의 물리적 결과를 추론합니다.
        
        Args:
            action: 수행할 행동
            obj: 대상 객체
            context: 현재 상황 (센서 데이터 등)
            
        Returns:
            PhysicalPrediction: 예측 결과
        """
        context = context or {}
        prediction = PhysicalPrediction(
            action=action,
            object_name=obj.name,
        )

        # 행동별 물리적 추론
        if action == PhysicalActionType.GRASP:
            prediction = self._reason_grasp(obj, context)
        elif action == PhysicalActionType.LIFT:
            prediction = self._reason_lift(obj, context)
        elif action == PhysicalActionType.PUSH:
            prediction = self._reason_push(obj, context)
        elif action == PhysicalActionType.THROW:
            prediction = self._reason_throw(obj, context)
        elif action == PhysicalActionType.POUR:
            prediction = self._reason_pour(obj, context)

        # AI 추론으로 강화
        if self._gemma4:
            try:
                ai_prediction = self._ai_reason_about_action(action, obj, context)
                if ai_prediction:
                    # AI 예측과 물리적 추론을 융합
                    prediction.warnings.extend(ai_prediction.get("warnings", []))
                    if ai_prediction.get("alternative"):
                        prediction.alternative_actions.append(ai_prediction["alternative"])
            except Exception:
                pass

        # 경험 기반 보정
        prediction = self._apply_experience(prediction, obj, action)

        return prediction

    def _reason_grasp(self, obj: PhysicalObject, context: Dict) -> PhysicalPrediction:
        """파지 추론"""
        gravity = self._common_sense["gravity"]["acceleration_ms2"]
        friction = obj.friction
        
        # 필요 최소 파지력 계산
        min_force = (obj.mass_kg * gravity) / (2.0 * friction + 1e-6)
        
        # 파손 임계력 계산
        break_force = 10.0 + (1.0 - obj.fragility) * 30.0  # 단단할수록 높은 임계값
        
        # 권장 파지력: 최소력의 1.5배, 파손 임계의 70% 이하
        recommended = min(min_force * 1.5, break_force * 0.7)
        
        warnings = []
        if obj.is_hot:
            warnings.append("⚠ 뜨거운 물체 — 내열 장갑 필요 또는 온도 확인 후 파지")
        if obj.is_sharp:
            warnings.append("⚠ 날카로운 물체 — 주의해서 파지, 손(그리퍼) 보호")
        if obj.is_breakable:
            warnings.append(f"⚠ 깨지기 쉬운 물체 — 파지력 {recommended:.1f}N 이하 권장")
        if obj.is_wet:
            warnings.append("⚠ 젖은 물체 — 마찰 감소, 미끄러짐 주의")

        success_prob = 0.9
        if obj.fragility > 0.7 and recommended > break_force * 0.5:
            success_prob = 0.6  # 깨지기 쉬운데 힘이 많이 필요하면 위험

        return PhysicalPrediction(
            action=PhysicalActionType.GRASP,
            object_name=obj.name,
            predicted_outcome="safe_grasp" if success_prob > 0.7 else "risky_grasp",
            success_probability=success_prob,
            risk_level="safe" if success_prob > 0.8 else "caution" if success_prob > 0.5 else "dangerous",
            recommended_force_n=round(recommended, 1),
            warnings=warnings,
            alternative_actions=["부드러운 파지 모드 사용"] if obj.fragility > 0.5 else [],
        )

    def _reason_lift(self, obj: PhysicalObject, context: Dict) -> PhysicalPrediction:
        """들어올리기 추론"""
        max_lift = self._common_sense["weight"]["max_safe_lift_kg"]
        warnings = []

        if obj.mass_kg > max_lift:
            return PhysicalPrediction(
                action=PhysicalActionType.LIFT,
                object_name=obj.name,
                predicted_outcome="too_heavy",
                success_probability=0.1,
                risk_level="dangerous",
                recommended_force_n=0.0,
                warnings=[f"⚠ 무게 초과 ({obj.mass_kg}kg > {max_lift}kg) — 들 수 없음"],
                alternative_actions=["두 번에 나누어 옮기기", "도움 요청", "바닥에서 밀기"],
            )

        # 무게중심 이동 주의
        if obj.mass_kg > self._common_sense["weight"]["strain_threshold_kg"]:
            warnings.append("⚠ 무거운 물체 — 무게중심을 낮추고 천천히 들기")

        return PhysicalPrediction(
            action=PhysicalActionType.LIFT,
            object_name=obj.name,
            predicted_outcome="safe_lift",
            success_probability=0.85,
            risk_level="caution" if obj.mass_kg > 2.0 else "safe",
            recommended_force_n=obj.mass_kg * 9.81 * 1.2,
            warnings=warnings,
        )

    def _reason_push(self, obj: PhysicalObject, context: Dict) -> PhysicalPrediction:
        """밀기 추론"""
        friction = obj.friction
        push_force_needed = friction * obj.mass_kg * 9.81
        
        # 전도 위험 (높이/폭 비율)
        aspect_ratio = obj.dimensions_m[2] / max(obj.dimensions_m[0], obj.dimensions_m[1], 0.01)
        tip_risk = "high" if aspect_ratio > 2.0 else "medium" if aspect_ratio > 1.2 else "low"

        return PhysicalPrediction(
            action=PhysicalActionType.PUSH,
            object_name=obj.name,
            predicted_outcome="slide" if push_force_needed < 20 else "stuck",
            success_probability=0.75,
            risk_level="caution" if tip_risk != "low" else "safe",
            recommended_force_n=push_force_needed * 1.3,
            warnings=[f"⚠ 전도 위험: {tip_risk}"] if tip_risk != "low" else [],
        )

    def _reason_throw(self, obj: PhysicalObject, context: Dict) -> PhysicalPrediction:
        """던지기 추론"""
        if obj.fragility > 0.5:
            return PhysicalPrediction(
                action=PhysicalActionType.THROW,
                object_name=obj.name,
                predicted_outcome="object_damaged",
                success_probability=0.2,
                risk_level="dangerous",
                recommended_force_n=0.0,
                warnings=["⚠ 깨지기 쉬운 물체 — 던지면 파손"],
                alternative_actions=["부드럽게 전달하기"],
            )

        if obj.is_sharp:
            return PhysicalPrediction(
                action=PhysicalActionType.THROW,
                object_name=obj.name,
                predicted_outcome="dangerous_projectile",
                success_probability=0.0,
                risk_level="forbidden",
                recommended_force_n=0.0,
                warnings=["⚠ 날카로운 물체 — 던지기 금지!"],
                alternative_actions=["손으로 전달하기"],
            )

        return PhysicalPrediction(
            action=PhysicalActionType.THROW,
            object_name=obj.name,
            predicted_outcome="successful_throw",
            success_probability=0.7,
            risk_level="caution",
            recommended_force_n=obj.mass_kg * 15.0,  # 포물선 궤적을 위한 초기력
            warnings=["주변 인원 확인 필수"],
        )

    def _reason_pour(self, obj: PhysicalObject, context: Dict) -> PhysicalPrediction:
        """붓기 추론"""
        return PhysicalPrediction(
            action=PhysicalActionType.POUR,
            object_name=obj.name,
            predicted_outcome="controlled_pour",
            success_probability=0.65,
            risk_level="caution",
            recommended_force_n=2.0,
            warnings=[
                "붓는 속도를 천천히 유지",
                "넘치지 않도록 높이 조절",
                "액체 온도 확인 (뜨거우면 화상 위험)",
            ],
        )

    def _ai_reason_about_action(
        self, action: PhysicalActionType, obj: PhysicalObject, context: Dict
    ) -> Optional[Dict]:
        """AI를 사용한 물리 추론 (Gemma 4)"""
        if not self._gemma4:
            return None

        try:
            prompt = (
                f"로봇이 다음 행동을 수행하려 합니다:\n"
                f"행동: {action.value}\n"
                f"대상: {obj.name} (무게={obj.mass_kg}kg, 취약도={obj.fragility})\n"
                f"뜨거운가: {obj.is_hot}, 날카로운가: {obj.is_sharp}\n\n"
                f"이 행동의 위험 요소와 대안을 제시하세요."
            )
            result = self._gemma4.generate(prompt, max_tokens=256, temperature=0.3)
            if result and result.text:
                return {"warnings": [result.text[:200]], "alternative": None}
        except Exception:
            pass
        return None

    def _apply_experience(
        self, prediction: PhysicalPrediction, obj: PhysicalObject, action: PhysicalActionType
    ) -> PhysicalPrediction:
        """경험 기반 보정 — 이전에 성공/실패한 파지력 등을 반영"""
        key = f"{obj.name}_{action.value}"
        with self._lock:
            if key in self._experience_db and len(self._experience_db[key]) >= 3:
                experiences = list(self._experience_db[key])
                success_rate = sum(1 for e in experiences if e.get("success", False)) / len(experiences)
                # 경험 기반으로 성공 확률 보정
                prediction.success_probability = 0.5 * prediction.success_probability + 0.5 * success_rate
        return prediction

    def record_experience(
        self, obj_name: str, action: PhysicalActionType, force_n: float, success: bool
    ) -> None:
        """물리적 경험 기록 — 매 상호작용 후 호출"""
        key = f"{obj_name}_{action.value}"
        with self._lock:
            if key not in self._experience_db:
                self._experience_db[key] = deque(maxlen=100)
            self._experience_db[key].append({
                "force_n": force_n,
                "success": success,
                "timestamp": time.time(),
            })

    def evaluate_feasibility(self, task_description: str, context: Dict) -> Dict[str, Any]:
        """
        작업의 물리적 타당성 평가
        
        Returns:
            {"feasible": bool, "alternative": str, "recovery": str}
        """
        # 기본 타당성 평가
        feasible = True
        alternative = ""
        recovery = "중지하고 도움 요청"

        # 배터리 부족 확인
        battery = context.get("battery_level", 1.0)
        if battery < 0.15:
            feasible = False
            alternative = "충전 후 작업 수행"
            recovery = "충전 스테이션으로 이동"

        # 안전 상태 확인
        safety = context.get("safety_state", "safe")
        if safety in ("warning", "critical"):
            feasible = False
            alternative = "안전 상태 복구 후 작업 수행"
            recovery = "안전 엔진 진단 수행"

        return {
            "feasible": feasible,
            "alternative": alternative,
            "recovery": recovery,
        }

    def get_common_sense(self) -> Dict[str, Any]:
        """물리적 상식 반환"""
        return self._common_sense.copy()
