#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 절차 기억 스킬 라이브러리 / Procedural Memory Skill Library
==========================================================================

V8.5 → V8.5 업그레이드:
  - 스킬 조합 지원 (여러 스킬을 복합 스킬로 조합)
  - Affordance 태그 스킬 (스킬이 작동하는 객체를 앎)
  - 스킬 전이 지원 (유사 도메인으로 스킬 전이)
  - 스킬 분해 (복잡한 스킬을 하위 스킬로 분해)
  - 혁신 추적 (새로운 스킬 조합 추적)
  - 향상된 패턴 감지: 더 긴 시퀀스 (최대 10개 동작)
  - 스킬 의존성 그래프 (선행 스킬)
  - 스킬 버전 관리 + A/B 테스트 (새 버전 시도, 더 나은 것 유지)
  - 최대 스킬: 200 → 500
  - 스킬 효과성 예측 (실행 전 성공 예측)

30개 원시 동작 → 반복 시퀀스 자동 감지 → 복합 스킬 승격
최대 500개 스킬, 성공률 <60% 시 자동 비활성화

검증: "컵 가져와" 5회 반복 → 자동 복합 스킬 생성

버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

logger = logging.getLogger("jihun.v84.skill_library")
logger.setLevel(logging.INFO)


# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

DEFAULT_DB_PATH = Path(
    os.getenv("SKILL_DB_PATH", "/home/jihun/data/skills/skill_library.db")
)
MAX_SKILLS = 500                    # V8: 200 → 500 최대 스킬 수
SKILL_SUCCESS_THRESHOLD = 0.6      # 스킬 유지 최소 성공률 (60%)
PATTERN_MIN_REPEATS = 5            # 복합 승격 최소 반복 횟수
PATTERN_WINDOW_S = 30.0            # 패턴 감지 윈도우 (초)
MAX_PATTERN_SEQUENCE_LENGTH = 10    # V8: 5 → 10 최대 패턴 시퀀스 길이
AB_TEST_MIN_TRIALS = 10            # V8: A/B 테스트 최소 시행 횟수

# 30개 원시 동작 / 30 Primitive Actions
PRIMITIVE_ACTIONS: List[str] = [
    # 이동 (8개)
    "move_forward", "move_backward", "move_left", "move_right",
    "rotate_left", "rotate_right", "stop_movement", "follow_person",
    # 다리 (5개)
    "extend_legs", "retract_legs", "leg_pitch_forward",
    "leg_pitch_backward", "adjust_height",
    # 그리퍼 (4개)
    "open_gripper", "close_gripper", "rotate_wrist",
    "adjust_grasp_force",
    # 감각 (5개)
    "look_at", "scan_surroundings", "listen",
    "feel_surface", "weigh_object",
    # 소통 (4개)
    "speak", "play_sound", "express_emotion", "show_eyes",
    # 시스템 (4개)
    "go_home", "return_to_charger", "enter_sleep_mode", "emergency_stop",
]


class SkillStatus(Enum):
    """스킬 상태"""
    PRIMITIVE = "primitive"        # 원시 동작
    LEARNING = "learning"          # 학습 중
    EXPERIMENTAL = "experimental"  # 실험적 (성공률 낮음)
    STABLE = "stable"              # 안정적
    DEPRECATED = "deprecated"      # 사용 중단 (성공률 <60%)


class SkillType(Enum):
    """V8.5: 스킬 유형"""
    PRIMITIVE = "primitive"            # 원시 동작
    COMPOUND = "compound"              # 복합 스킬 (시퀀스 기반)
    COMPOSED = "composed"              # 조합 스킬 (기존 스킬 조합)
    TRANSFERRED = "transferred"        # 전이 스킬 (다른 도메인에서 전이)
    FEWSHOT = "fewshot"                # V8.5: 퓨샷 학습 스킬 (1~5 시연으로 습득)
    GENERALIZED = "generalized"        # V8.5: 일반화된 스킬 (원칙 추출)


# ──────────────────────────────────────────────────────────────────────────────
# 데이터 클래스 / Data Classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class Skill:
    """학습된 스킬 — V8: 조합/전이/Affordance/버전관리 추가"""
    skill_id: str = ""
    name: str = ""
    name_ko: str = ""
    description: str = ""
    version: int = 1
    status: SkillStatus = SkillStatus.PRIMITIVE
    skill_type: SkillType = SkillType.PRIMITIVE    # V8
    action_sequence: List[Dict[str, Any]] = field(default_factory=list)
    parameters: List[Dict[str, Any]] = field(default_factory=list)
    prerequisites: List[str] = field(default_factory=list)

    # 통계
    execution_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    success_rate: float = 1.0

    # 메타데이터
    created_at: float = field(default_factory=time.time)
    last_used_at: float = 0.0
    last_improved_at: float = 0.0
    importance: float = 0.5

    # 패턴 감지용
    source_pattern: str = ""       # 원래 패턴 키
    pattern_count: int = 0         # 패턴 감지 횟수

    # V8.5 신규 필드
    component_skills: List[str] = field(default_factory=list)    # 조합된 하위 스킬 ID
    affordance_tags: List[str] = field(default_factory=list)     # Affordance 태그
    dependency_graph: Dict[str, List[str]] = field(default_factory=dict)  # 의존성 그래프
    domain: str = "general"        # 스킬 도메인
    transfer_source: Optional[str] = None    # 전이 출처 스킬 ID
    ab_test_variant: Optional[str] = None    # A/B 테스트 변형 ("A" or "B")
    predicted_success_rate: float = 0.0      # 예측 성공률
    innovation_score: float = 0.0            # 혁신 점수

    def __post_init__(self):
        if not self.skill_id:
            self.skill_id = f"skill_{int(time.time() * 1000)}"

    def update_stats(self, success: bool) -> None:
        """실행 통계 업데이트"""
        self.execution_count += 1
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
        self.success_rate = (
            self.success_count / self.execution_count
            if self.execution_count > 0 else 0.0
        )
        self.last_used_at = time.time()

        # 상태 업데이트
        if self.execution_count >= 5:
            if self.success_rate >= 0.8:
                self.status = SkillStatus.STABLE
            elif self.success_rate >= SKILL_SUCCESS_THRESHOLD:
                self.status = SkillStatus.EXPERIMENTAL
            else:
                self.status = SkillStatus.DEPRECATED

    @property
    def is_compound(self) -> bool:
        """복합 스킬 여부 (원시 동작이 아닌)"""
        return self.status != SkillStatus.PRIMITIVE

    @property
    def is_composed(self) -> bool:
        """V8: 조합 스킬 여부"""
        return self.skill_type == SkillType.COMPOSED

    @property
    def is_transferred(self) -> bool:
        """V8: 전이 스킬 여부"""
        return self.skill_type == SkillType.TRANSFERRED


@dataclass
class ActionRecord:
    """동작 실행 기록 — 패턴 감지용"""
    action_name: str = ""
    timestamp: float = field(default_factory=time.time)
    arguments: Dict[str, Any] = field(default_factory=dict)
    success: bool = True
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ABTestResult:
    """V8: A/B 테스트 결과"""
    skill_id: str = ""
    variant_a_id: str = ""
    variant_b_id: str = ""
    variant_a_trials: int = 0
    variant_b_trials: int = 0
    variant_a_success_rate: float = 0.0
    variant_b_success_rate: float = 0.0
    winner: Optional[str] = None   # "A" or "B" or None
    concluded: bool = False


# ──────────────────────────────────────────────────────────────────────────────
# 스킬 라이브러리 / Skill Library
# ──────────────────────────────────────────────────────────────────────────────

class SkillLibrary:
    """
    절차 기억 스킬 라이브러리 V8

    V8.5 기능 + V8.5 업그레이드:
    - 30개 원시 동작에서 시작하여 500개까지 학습된 복합 스킬 성장
    - 스킬 조합: 기존 스킬을 조합하여 복잡한 스킬 생성
    - Affordance 태그: 스킬이 작동하는 객체를 알고 있음
    - 스킬 전이: 유사 도메인으로 스킬 전이
    - 스킬 분해: 복잡한 스킬을 하위 스킬로 분해
    - 혁신 추적: 새로운 스킬 조합의 혁신성 추적
    - 더 긴 패턴 감지: 최대 10개 동작 시퀀스
    - 스킬 의존성 그래프: 선행 스킬 관계
    - A/B 테스트: 새 버전 vs 기존 버전 성능 비교
    - 스킬 효과성 예측: 실행 전 성공률 예측

    검증: "컵 가져와" 5회 반복 → 자동 복합 스킬 생성
    """

    def __init__(self, db_path: Path = DEFAULT_DB_PATH) -> None:
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.RLock()

        # 스킬 저장소
        self._skills: Dict[str, Skill] = {}
        self._primitive_names: Set[str] = set()

        # 패턴 감지용 최근 동작 기록
        self._recent_actions: List[ActionRecord] = []

        # 스킬 실행 함수 레지스트리
        self._executors: Dict[str, Callable] = {}

        # V8: A/B 테스트 결과
        self._ab_tests: Dict[str, ABTestResult] = {}

        # V8: 혁신 추적
        self._innovation_log: List[Dict[str, Any]] = []

        logger.info(f"스킬 라이브러리 V8.5 초기화: DB={db_path}")

    async def initialize(self) -> None:
        """스킬 라이브러리 초기화 — 30개 원시 동작 등록"""
        self._conn = sqlite3.connect(
            str(self._db_path), check_same_thread=False,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._create_tables()

        # 기존 스킬 로드
        self._load_skills()

        # 원시 동작 등록
        for name in PRIMITIVE_ACTIONS:
            self._primitive_names.add(name)
            if name not in self._skills:
                skill = Skill(
                    skill_id=f"primitive_{name}",
                    name=name,
                    name_ko=name,
                    description=f"Primitive action: {name}",
                    status=SkillStatus.PRIMITIVE,
                    skill_type=SkillType.PRIMITIVE,
                    action_sequence=[{"action": name}],
                    importance=1.0,
                )
                self._skills[skill.skill_id] = skill

        self._save_skills()

        logger.info(
            f"스킬 라이브러리 V8.5 초기화 완료: "
            f"{len(self._skills)}개 스킬 "
            f"({len(self._primitive_names)}개 원시 동작, "
            f"최대 {MAX_SKILLS}개)"
        )

    def _create_tables(self) -> None:
        """테이블 생성 — V8: 추가 컬럼"""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS skills (
                skill_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                name_ko TEXT DEFAULT '',
                description TEXT DEFAULT '',
                version INTEGER DEFAULT 1,
                status TEXT NOT NULL,
                skill_type TEXT DEFAULT 'primitive',
                action_sequence TEXT DEFAULT '[]',
                parameters TEXT DEFAULT '[]',
                prerequisites TEXT DEFAULT '[]',
                execution_count INTEGER DEFAULT 0,
                success_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                success_rate REAL DEFAULT 1.0,
                created_at REAL NOT NULL,
                last_used_at REAL DEFAULT 0,
                last_improved_at REAL DEFAULT 0,
                importance REAL DEFAULT 0.5,
                source_pattern TEXT DEFAULT '',
                pattern_count INTEGER DEFAULT 0,
                component_skills TEXT DEFAULT '[]',
                affordance_tags TEXT DEFAULT '[]',
                dependency_graph TEXT DEFAULT '{}',
                domain TEXT DEFAULT 'general',
                transfer_source TEXT DEFAULT NULL,
                ab_test_variant TEXT DEFAULT NULL,
                predicted_success_rate REAL DEFAULT 0.0,
                innovation_score REAL DEFAULT 0.0
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS ab_tests (
                skill_name TEXT PRIMARY KEY,
                variant_a_id TEXT,
                variant_b_id TEXT,
                variant_a_trials INTEGER DEFAULT 0,
                variant_b_trials INTEGER DEFAULT 0,
                variant_a_success_rate REAL DEFAULT 0,
                variant_b_success_rate REAL DEFAULT 0,
                winner TEXT DEFAULT NULL,
                concluded INTEGER DEFAULT 0
            )
        """)
        self._conn.commit()

    def _load_skills(self) -> None:
        """DB에서 스킬 로드 — V8: 추가 컬럼"""
        try:
            cursor = self._conn.execute("SELECT * FROM skills")
            for row in cursor:
                skill = Skill(
                    skill_id=row[0],
                    name=row[1],
                    name_ko=row[2],
                    description=row[3],
                    version=row[4],
                    status=SkillStatus(row[5]),
                    skill_type=SkillType(row[6]) if len(row) > 6 and row[6] else SkillType.PRIMITIVE,
                    action_sequence=json.loads(row[7]) if row[7] else [],
                    parameters=json.loads(row[8]) if row[8] else [],
                    prerequisites=json.loads(row[9]) if row[9] else [],
                    execution_count=row[10],
                    success_count=row[11],
                    failure_count=row[12],
                    success_rate=row[13],
                    created_at=row[14],
                    last_used_at=row[15],
                    last_improved_at=row[16],
                    importance=row[17],
                    source_pattern=row[18],
                    pattern_count=row[19],
                    # V8.5 추가 필드
                    component_skills=json.loads(row[20]) if len(row) > 20 and row[20] else [],
                    affordance_tags=json.loads(row[21]) if len(row) > 21 and row[21] else [],
                    dependency_graph=json.loads(row[22]) if len(row) > 22 and row[22] else {},
                    domain=row[23] if len(row) > 23 else "general",
                    transfer_source=row[24] if len(row) > 24 else None,
                    ab_test_variant=row[25] if len(row) > 25 else None,
                    predicted_success_rate=row[26] if len(row) > 26 else 0.0,
                    innovation_score=row[27] if len(row) > 27 else 0.0,
                )
                self._skills[skill.skill_id] = skill
        except Exception as e:
            logger.error(f"스킬 로드 오류: {e}")

    def _save_skills(self) -> None:
        """스킬을 DB에 저장 — V8: 추가 컬럼"""
        try:
            for skill in self._skills.values():
                self._conn.execute(
                    """INSERT OR REPLACE INTO skills
                       (skill_id, name, name_ko, description, version,
                        status, skill_type, action_sequence, parameters, prerequisites,
                        execution_count, success_count, failure_count,
                        success_rate, created_at, last_used_at,
                        last_improved_at, importance, source_pattern,
                        pattern_count, component_skills, affordance_tags,
                        dependency_graph, domain, transfer_source,
                        ab_test_variant, predicted_success_rate, innovation_score)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                               ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        skill.skill_id, skill.name, skill.name_ko,
                        skill.description, skill.version,
                        skill.status.value, skill.skill_type.value,
                        json.dumps(skill.action_sequence, ensure_ascii=False),
                        json.dumps(skill.parameters, ensure_ascii=False),
                        json.dumps(skill.prerequisites, ensure_ascii=False),
                        skill.execution_count, skill.success_count,
                        skill.failure_count, skill.success_rate,
                        skill.created_at, skill.last_used_at,
                        skill.last_improved_at, skill.importance,
                        skill.source_pattern, skill.pattern_count,
                        json.dumps(skill.component_skills, ensure_ascii=False),
                        json.dumps(skill.affordance_tags, ensure_ascii=False),
                        json.dumps(skill.dependency_graph, ensure_ascii=False),
                        skill.domain, skill.transfer_source,
                        skill.ab_test_variant, skill.predicted_success_rate,
                        skill.innovation_score,
                    ),
                )
            self._conn.commit()
        except Exception as e:
            logger.error(f"스킬 저장 오류: {e}")

    # ──────────────────────────────────────────────────────────────────────
    # register_skill() — 스킬 등록
    # ──────────────────────────────────────────────────────────────────────

    def register_skill(
        self,
        name: str,
        action_sequence: List[Dict[str, Any]],
        name_ko: str = "",
        description: str = "",
        parameters: Optional[List[Dict[str, Any]]] = None,
        executor: Optional[Callable] = None,
        skill_type: SkillType = SkillType.COMPOUND,        # V8
        component_skills: Optional[List[str]] = None,       # V8
        affordance_tags: Optional[List[str]] = None,        # V8
        domain: str = "general",                             # V8
        dependency_graph: Optional[Dict[str, List[str]]] = None,  # V8
    ) -> Optional[str]:
        """
        새 스킬 등록 — V8: 조합/전이/Affordance 지원

        Args:
            name: 스킬 이름
            action_sequence: 동작 시퀀스
            name_ko: 한국어 이름
            description: 설명
            parameters: 매개변수 목록
            executor: 실행 함수
            skill_type: 스킬 유형 (V8)
            component_skills: 조합된 하위 스킬 ID (V8)
            affordance_tags: Affordance 태그 (V8)
            domain: 스킬 도메인 (V8)
            dependency_graph: 의존성 그래프 (V8)

        Returns:
            등록된 스킬 ID (실패 시 None)
        """
        with self._lock:
            # 최대 스킬 수 확인
            if len(self._skills) >= MAX_SKILLS:
                logger.warning(
                    f"스킬 최대 수 도달 ({MAX_SKILLS}) — 등록 불가"
                )
                return None

            # 중복 확인
            for existing in self._skills.values():
                if existing.name == name and existing.source_pattern == "":
                    logger.warning(f"이미 존재하는 스킬: {name}")
                    return existing.skill_id

            skill_id = f"skill_{int(time.time() * 1000)}"
            skill = Skill(
                skill_id=skill_id,
                name=name,
                name_ko=name_ko or name,
                description=description or f"Compound skill: {name}",
                version=1,
                status=SkillStatus.LEARNING,
                skill_type=skill_type,
                action_sequence=action_sequence,
                parameters=parameters or [],
                prerequisites=[
                    a.get("action", "") for a in action_sequence
                ],
                importance=0.5,
                component_skills=component_skills or [],      # V8
                affordance_tags=affordance_tags or [],        # V8
                domain=domain,                                 # V8
                dependency_graph=dependency_graph or {},       # V8
            )

            # V8: 조합 스킬인 경우 혁신 점수 계산
            if component_skills:
                skill.innovation_score = self._compute_innovation_score(
                    component_skills
                )

            self._skills[skill_id] = skill

            # 실행 함수 등록
            if executor:
                self._executors[skill_id] = executor

            # V8: 조합 스킬이면 혁신 로그에 기록
            if skill_type == SkillType.COMPOSED and component_skills:
                self._log_innovation(skill, "skill_composition")

            self._save_skills()
            logger.info(
                f"새 스킬 등록: {name} (ID: {skill_id}, "
                f"유형: {skill_type.value}, "
                f"시퀀스: {len(action_sequence)}개 동작)"
            )
            return skill_id

    # ──────────────────────────────────────────────────────────────────────
    # execute_skill() — 스킬 실행
    # ──────────────────────────────────────────────────────────────────────

    def execute_skill(
        self,
        skill_id: str,
        arguments: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        스킬 실행 — V8: 효과성 예측 + A/B 테스트 지원

        Args:
            skill_id: 실행할 스킬 ID
            arguments: 스킬 매개변수

        Returns:
            실행 결과
        """
        with self._lock:
            skill = self._skills.get(skill_id)
            if not skill:
                return {"success": False, "error": f"스킬 없음: {skill_id}"}

            if skill.status == SkillStatus.DEPRECATED:
                return {
                    "success": False,
                    "error": f"사용 중단된 스킬: {skill.name}",
                }

            # V8: 효과성 예측
            predicted_success = self._predict_skill_effectiveness(
                skill, arguments
            )

            # 실행 기록
            self._record_action(skill.name, arguments or {})

            # 실행 함수가 있으면 호출
            if skill_id in self._executors:
                try:
                    result = self._executors[skill_id](arguments or {})
                    success = result.get("success", True) if isinstance(result, dict) else True
                    skill.update_stats(success)
                    skill.predicted_success_rate = predicted_success
                    self._save_skills()

                    # V8: A/B 테스트 업데이트
                    self._update_ab_test(skill, success)

                    return result if isinstance(result, dict) else {"success": True, "result": result}
                except Exception as e:
                    skill.update_stats(False)
                    self._save_skills()
                    return {"success": False, "error": str(e)}

            # 실행 함수가 없으면 시퀀스 반환
            skill.update_stats(True)
            skill.predicted_success_rate = predicted_success
            self._save_skills()
            return {
                "success": True,
                "skill": skill.name,
                "sequence": skill.action_sequence,
                "predicted_success": predicted_success,
                "message": f"스킬 '{skill.name}' 실행 (시퀀스 반환)",
            }

    # ──────────────────────────────────────────────────────────────────────
    # V8: 스킬 조합 / Skill Composition
    # ──────────────────────────────────────────────────────────────────────

    def compose_skills(
        self,
        skill_ids: List[str],
        name: str = "",
        name_ko: str = "",
        description: str = "",
        affordance_tags: Optional[List[str]] = None,
    ) -> Optional[str]:
        """
        V8: 여러 스킬을 조합하여 새로운 복합 스킬 생성

        예: ["move_to_object", "grasp_object", "move_to_person", "release_object"]
         → "deliver_object" 스킬

        Args:
            skill_ids: 조합할 스킬 ID 목록
            name: 새 스킬 이름
            name_ko: 한국어 이름
            description: 설명
            affordance_tags: Affordance 태그

        Returns:
            새 조합 스킬 ID
        """
        with self._lock:
            # 모든 스킬이 존재하는지 확인
            component_skills = []
            combined_sequence = []
            combined_prerequisites = []
            combined_affordances = list(affordance_tags or [])

            for sid in skill_ids:
                skill = self._skills.get(sid)
                if not skill:
                    logger.error(f"조합할 스킬 없음: {sid}")
                    return None
                component_skills.append(sid)
                combined_sequence.extend(skill.action_sequence)
                combined_prerequisites.extend(skill.prerequisites)
                combined_affordances.extend(skill.affordance_tags)

            # 의존성 그래프 구성
            dep_graph = {}
            for i, sid in enumerate(skill_ids):
                dep_graph[sid] = skill_ids[:i] if i > 0 else []

            # 스킬 이름 자동 생성
            if not name:
                name_parts = []
                for sid in skill_ids[:4]:
                    s = self._skills.get(sid)
                    if s:
                        name_parts.append(s.name[:15])
                name = " + ".join(name_parts)

            # 중복 제거
            combined_prerequisites = list(dict.fromkeys(combined_prerequisites))
            combined_affordances = list(dict.fromkeys(combined_affordances))

            skill_id = self.register_skill(
                name=name,
                action_sequence=combined_sequence,
                name_ko=name_ko,
                description=description or f"Composed skill: {' + '.join([self._skills.get(sid, Skill()).name for sid in skill_ids])}",
                skill_type=SkillType.COMPOSED,
                component_skills=component_skills,
                affordance_tags=combined_affordances,
                dependency_graph=dep_graph,
            )

            if skill_id:
                logger.info(
                    f"스킬 조합: {name} ← "
                    f"{len(skill_ids)}개 스킬 조합"
                )

            return skill_id

    def _compute_innovation_score(self, component_skills: List[str]) -> float:
        """V8: 조합 스킬의 혁신 점수 계산"""
        # 이전에 조합된 적 없는 스킬 조합일수록 높은 점수
        existing_compositions = set()
        for skill in self._skills.values():
            if skill.skill_type == SkillType.COMPOSED:
                key = tuple(sorted(skill.component_skills))
                existing_compositions.add(key)

        new_key = tuple(sorted(component_skills))
        if new_key not in existing_compositions:
            # 완전히 새로운 조합 — 높은 혁신 점수
            # 도메인이 다른 스킬을 조합하면 더 높은 점수
            domains = set()
            for sid in component_skills:
                s = self._skills.get(sid)
                if s:
                    domains.add(s.domain)

            cross_domain_bonus = min(1.0, len(domains) * 0.3)
            return min(1.0, 0.7 + cross_domain_bonus)
        else:
            return 0.3  # 기존 조합

    def _log_innovation(self, skill: Skill, innovation_type: str) -> None:
        """V8: 혁신 로그 기록"""
        self._innovation_log.append({
            "skill_id": skill.skill_id,
            "skill_name": skill.name,
            "innovation_type": innovation_type,
            "innovation_score": skill.innovation_score,
            "timestamp": time.time(),
            "component_skills": skill.component_skills,
        })

    # ──────────────────────────────────────────────────────────────────────
    # V8: 스킬 전이 / Skill Transfer
    # ──────────────────────────────────────────────────────────────────────

    def transfer_skill(
        self,
        source_skill_id: str,
        target_domain: str,
        name: str = "",
        modifications: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """
        V8: 스킬 전이 — 유사 도메인으로 스킬 전이

        예: "grasp_cup" → "grasp_bottle" (유사한 동작, 다른 대상)

        Args:
            source_skill_id: 원본 스킬 ID
            target_domain: 대상 도메인
            name: 새 스킬 이름
            modifications: 수정 사항

        Returns:
            전이된 스킬 ID
        """
        with self._lock:
            source = self._skills.get(source_skill_id)
            if not source:
                logger.error(f"전이 원본 스킬 없음: {source_skill_id}")
                return None

            # 전이된 시퀀스 생성
            transferred_sequence = copy.deepcopy(source.action_sequence)
            if modifications:
                for mod_key, mod_value in modifications.items():
                    for action in transferred_sequence:
                        if mod_key in action:
                            action[mod_key] = mod_value

            # 전이된 스킬 이름
            if not name:
                name = f"{source.name}_to_{target_domain}"

            skill_id = self.register_skill(
                name=name,
                action_sequence=transferred_sequence,
                name_ko=source.name_ko,
                description=f"Transferred from {source.name} to {target_domain}",
                skill_type=SkillType.TRANSFERRED,
                affordance_tags=source.affordance_tags + [target_domain],
                domain=target_domain,
            )

            if skill_id:
                # 전이 출처 기록
                skill = self._skills.get(skill_id)
                if skill:
                    skill.transfer_source = source_skill_id
                    # 전이 스킬은 초기 성공률을 원본의 80%로 설정 (일반화 손실)
                    skill.predicted_success_rate = source.success_rate * 0.8
                    self._save_skills()

                self._log_innovation(skill, "skill_transfer")
                logger.info(
                    f"스킬 전이: {source.name} → {name} "
                    f"(도메인: {target_domain})"
                )

            return skill_id

    # ──────────────────────────────────────────────────────────────────────
    # V8: 스킬 분해 / Skill Decomposition
    # ──────────────────────────────────────────────────────────────────────

    def decompose_skill(
        self,
        skill_id: str,
    ) -> List[Dict[str, Any]]:
        """
        V8: 복잡한 스킬을 하위 스킬로 분해

        Args:
            skill_id: 분해할 스킬 ID

        Returns:
            분해된 하위 스킬 정보 리스트
        """
        with self._lock:
            skill = self._skills.get(skill_id)
            if not skill:
                return []

            # 조합 스킬인 경우 구성 스킬 반환
            if skill.component_skills:
                sub_skills = []
                for cid in skill.component_skills:
                    cs = self._skills.get(cid)
                    if cs:
                        sub_skills.append({
                            "skill_id": cs.skill_id,
                            "name": cs.name,
                            "type": cs.skill_type.value,
                            "success_rate": cs.success_rate,
                        })
                return sub_skills

            # 일반 복합 스킬인 경우 시퀀스를 그룹으로 분해
            if len(skill.action_sequence) <= 2:
                return [{
                    "skill_id": skill.skill_id,
                    "name": skill.name,
                    "type": "atomic",
                    "sequence": skill.action_sequence,
                }]

            # 시퀀스를 의미 단위로 분할
            groups = self._group_sequence(skill.action_sequence)
            result = []
            for i, group in enumerate(groups):
                result.append({
                    "skill_id": f"{skill_id}_sub{i}",
                    "name": f"{skill.name}_part{i+1}",
                    "type": "decomposed",
                    "sequence": group,
                })

            return result

    def _group_sequence(
        self, sequence: List[Dict[str, Any]],
    ) -> List[List[Dict[str, Any]]]:
        """시퀀스를 의미 단위로 그룹화"""
        if len(sequence) <= 3:
            return [sequence]

        groups = []
        current_group = []

        # 간단한 휴리스틱: 이동 동작과 조작 동작 분리
        move_actions = {"move_forward", "move_backward", "move_left", "move_right",
                       "rotate_left", "rotate_right", "follow_person", "go_home"}
        manip_actions = {"open_gripper", "close_gripper", "rotate_wrist",
                        "adjust_grasp_force"}

        for action in sequence:
            action_name = action.get("action", "")
            current_group.append(action)

            # 그룹 전환 지점 감지
            if (action_name in move_actions and current_group and
                    any(a.get("action", "") in manip_actions for a in current_group[:-1])):
                groups.append(current_group[:-1])
                current_group = [action]
            elif (action_name in manip_actions and current_group and
                    any(a.get("action", "") in move_actions for a in current_group[:-1])):
                groups.append(current_group[:-1])
                current_group = [action]

        if current_group:
            groups.append(current_group)

        return groups if groups else [sequence]

    # ──────────────────────────────────────────────────────────────────────
    # V8: 스킬 효과성 예측 / Skill Effectiveness Prediction
    # ──────────────────────────────────────────────────────────────────────

    def _predict_skill_effectiveness(
        self,
        skill: Skill,
        arguments: Optional[Dict[str, Any]] = None,
    ) -> float:
        """
        V8: 스킬 효과성 예측 — 실행 전 성공률 예측

        고려 요소:
        - 과거 성공률
        - 유사 상황에서의 성공률
        - 의존성 스킬 성공률
        - Affordance 일치도
        """
        # 기본: 과거 성공률
        if skill.execution_count == 0:
            # 새 스킬 — 예측 불가
            return 0.5

        base_rate = skill.success_rate

        # 의존성 스킬 성공률 반영
        dep_penalty = 0.0
        if skill.dependency_graph:
            for dep_id in skill.dependency_graph.keys():
                dep_skill = self._skills.get(dep_id)
                if dep_skill and dep_skill.execution_count > 0:
                    if dep_skill.success_rate < SKILL_SUCCESS_THRESHOLD:
                        dep_penalty += 0.1

        predicted = max(0.0, min(1.0, base_rate - dep_penalty))
        return predicted

    def predict_skill_success(
        self,
        skill_id: str,
        arguments: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        V8: 스킬 성공 예측 (공개 API)

        Args:
            skill_id: 예측할 스킬 ID
            arguments: 스킬 매개변수

        Returns:
            예측 결과
        """
        with self._lock:
            skill = self._skills.get(skill_id)
            if not skill:
                return {
                    "skill_id": skill_id,
                    "predicted_success": 0.0,
                    "confidence": 0.0,
                    "error": "스킬 없음",
                }

            predicted = self._predict_skill_effectiveness(skill, arguments)
            confidence = min(1.0, skill.execution_count / 20.0)

            return {
                "skill_id": skill_id,
                "skill_name": skill.name,
                "predicted_success": round(predicted, 3),
                "confidence": round(confidence, 3),
                "based_on_executions": skill.execution_count,
                "historical_success_rate": round(skill.success_rate, 3),
                "dependency_risks": self._assess_dependency_risks(skill),
            }

    def _assess_dependency_risks(self, skill: Skill) -> List[Dict[str, Any]]:
        """V8: 의존성 리스크 평가"""
        risks = []
        if not skill.dependency_graph:
            return risks

        for dep_id in skill.dependency_graph.keys():
            dep = self._skills.get(dep_id)
            if dep:
                risk_level = "low"
                if dep.success_rate < SKILL_SUCCESS_THRESHOLD:
                    risk_level = "high"
                elif dep.success_rate < 0.8:
                    risk_level = "medium"

                risks.append({
                    "skill_id": dep_id,
                    "skill_name": dep.name,
                    "success_rate": dep.success_rate,
                    "risk_level": risk_level,
                })

        return risks

    # ──────────────────────────────────────────────────────────────────────
    # V8: A/B 테스트 / A/B Testing
    # ──────────────────────────────────────────────────────────────────────

    def start_ab_test(
        self,
        skill_name: str,
        variant_a_id: str,
        variant_b_id: str,
    ) -> bool:
        """
        V8: A/B 테스트 시작 — 두 스킬 버전 성능 비교

        Args:
            skill_name: 테스트 스킬 이름
            variant_a_id: 변형 A (기존)
            variant_b_id: 변형 B (새 버전)

        Returns:
            테스트 시작 성공 여부
        """
        skill_a = self._skills.get(variant_a_id)
        skill_b = self._skills.get(variant_b_id)

        if not skill_a or not skill_b:
            logger.error("A/B 테스트: 스킬 ID 확인 필요")
            return False

        # A/B 변형 표시
        skill_a.ab_test_variant = "A"
        skill_b.ab_test_variant = "B"

        self._ab_tests[skill_name] = ABTestResult(
            skill_id=skill_name,
            variant_a_id=variant_a_id,
            variant_b_id=variant_b_id,
        )

        self._save_skills()
        logger.info(f"A/B 테스트 시작: {skill_name} (A:{variant_a_id}, B:{variant_b_id})")
        return True

    def _update_ab_test(self, skill: Skill, success: bool) -> None:
        """V8: A/B 테스트 결과 업데이트"""
        if not skill.ab_test_variant:
            return

        # 해당 A/B 테스트 찾기
        for name, test in self._ab_tests.items():
            if test.concluded:
                continue

            if skill.skill_id == test.variant_a_id:
                test.variant_a_trials += 1
                if success:
                    test.variant_a_success_rate = (
                        (test.variant_a_success_rate * (test.variant_a_trials - 1) + 1.0)
                        / test.variant_a_trials
                    )
                else:
                    test.variant_a_success_rate = (
                        test.variant_a_success_rate * (test.variant_a_trials - 1)
                        / test.variant_a_trials
                    )

            elif skill.skill_id == test.variant_b_id:
                test.variant_b_trials += 1
                if success:
                    test.variant_b_success_rate = (
                        (test.variant_b_success_rate * (test.variant_b_trials - 1) + 1.0)
                        / test.variant_b_trials
                    )
                else:
                    test.variant_b_success_rate = (
                        test.variant_b_success_rate * (test.variant_b_trials - 1)
                        / test.variant_b_trials
                    )

            # 충분한 시행 후 결론
            if (test.variant_a_trials >= AB_TEST_MIN_TRIALS and
                    test.variant_b_trials >= AB_TEST_MIN_TRIALS):
                self._conclude_ab_test(test)

    def _conclude_ab_test(self, test: ABTestResult) -> None:
        """V8: A/B 테스트 결론"""
        test.concluded = True

        if test.variant_a_success_rate >= test.variant_b_success_rate:
            test.winner = "A"
            # 변형 B 비활성화
            skill_b = self._skills.get(test.variant_b_id)
            if skill_b:
                skill_b.status = SkillStatus.DEPRECATED
                skill_b.ab_test_variant = None
        else:
            test.winner = "B"
            # 변형 A 비활성화
            skill_a = self._skills.get(test.variant_a_id)
            if skill_a:
                skill_a.status = SkillStatus.DEPRECATED
                skill_a.ab_test_variant = None

        # 승자 변형 정리
        winner_skill = self._skills.get(
            test.variant_a_id if test.winner == "A" else test.variant_b_id
        )
        if winner_skill:
            winner_skill.ab_test_variant = None

        self._save_skills()
        logger.info(
            f"A/B 테스트 결론: {test.skill_id} → 승자 {test.winner} "
            f"(A: {test.variant_a_success_rate:.2f}, "
            f"B: {test.variant_b_success_rate:.2f})"
        )

    # ──────────────────────────────────────────────────────────────────────
    # detect_pattern() — 반복 동작 시퀀스 자동 감지
    # ──────────────────────────────────────────────────────────────────────

    def detect_pattern(self) -> Optional[str]:
        """
        반복 동작 시퀀스 자동 감지 — V8: 최대 10개 동작 시퀀스

        최근 동작 기록에서 빈발하는 시퀀스를 탐지:
        1. 최근 동작 기록 분석
        2. 연속 동작 시퀀스 출현 빈도 계산
        3. PATTERN_MIN_REPEATS(5)회 이상 반복 시 승격 대상

        Returns:
            감지된 패턴 키 (없으면 None)
        """
        with self._lock:
            now = time.time()
            window_start = now - PATTERN_WINDOW_S * 6  # 3분 윈도우

            # 윈도우 내 동작 추출
            recent = [
                a for a in self._recent_actions
                if a.timestamp >= window_start
            ]

            if len(recent) < PATTERN_MIN_REPEATS:
                return None

            # V8: 길이 2~10의 시퀀스 빈도 분석 (V7: 2~5)
            sequence_counts: Dict[str, int] = {}
            sequence_examples: Dict[str, List[Dict]] = {}

            for seq_len in range(2, min(MAX_PATTERN_SEQUENCE_LENGTH + 1, len(recent) + 1)):
                for i in range(len(recent) - seq_len + 1):
                    seq = recent[i:i + seq_len]
                    seq_key = "→".join(a.action_name for a in seq)

                    sequence_counts[seq_key] = (
                        sequence_counts.get(seq_key, 0) + 1
                    )
                    if seq_key not in sequence_examples:
                        sequence_examples[seq_key] = [
                            {"action": a.action_name, "args": a.arguments}
                            for a in seq
                        ]

            # 빈발 시퀀스 필터링
            for seq_key, count in sequence_counts.items():
                if count >= PATTERN_MIN_REPEATS:
                    # 이미 승격된 패턴인지 확인
                    if not self._is_pattern_registered(seq_key):
                        logger.info(
                            f"반복 패턴 감지: '{seq_key}' "
                            f"({count}회 반복)"
                        )
                        self._promote_candidate(
                            seq_key, count,
                            sequence_examples.get(seq_key, []),
                        )
                        return seq_key

            return None

    def _is_pattern_registered(self, pattern_key: str) -> bool:
        """패턴이 이미 스킬로 등록되어 있는지 확인"""
        for skill in self._skills.values():
            if skill.source_pattern == pattern_key:
                return True
            # 동작 시퀀스 비교
            skill_key = "→".join(
                a.get("action", "") for a in skill.action_sequence
            )
            if skill_key == pattern_key:
                return True
        return False

    def _promote_candidate(
        self,
        pattern_key: str,
        count: int,
        example_sequence: List[Dict],
    ) -> None:
        """감지된 패턴을 승격 후보로 기록"""
        for skill in self._skills.values():
            if skill.source_pattern == pattern_key:
                skill.pattern_count = count
                self._save_skills()
                return

        # 아직 스킬이 없으면 승격 시도
        if count >= PATTERN_MIN_REPEATS:
            self.promote_to_compound(pattern_key, example_sequence)

    # ──────────────────────────────────────────────────────────────────────
    # promote_to_compound() — 복합 스킬 승격
    # ──────────────────────────────────────────────────────────────────────

    def promote_to_compound(
        self,
        pattern_key: str,
        action_sequence: List[Dict[str, Any]],
    ) -> Optional[str]:
        """
        감지된 패턴을 복합 스킬로 승격

        검증: "컵 가져와" 5회 반복 → 자동 복합 스킬 생성

        Args:
            pattern_key: 패턴 키 (동작→동작→...)
            action_sequence: 동작 시퀀스

        Returns:
            새 스킬 ID
        """
        with self._lock:
            # 스킬 이름 자동 생성
            action_names = [a.get("action", "?") for a in action_sequence]
            name = "_and_".join(action_names[:3])
            if len(action_names) > 3:
                name += f"_etc{len(action_names) - 3}"

            name_ko = " → ".join(action_names)

            # 매개변수 추출
            params = self._extract_parameters(action_sequence)

            # V8: Affordance 태그 추론
            affordance_tags = self._infer_affordance_tags(action_sequence)

            skill_id = self.register_skill(
                name=name,
                action_sequence=action_sequence,
                name_ko=name_ko,
                description=f"Auto-promoted compound skill: {pattern_key}",
                parameters=params,
                skill_type=SkillType.COMPOUND,
                affordance_tags=affordance_tags,
            )

            if skill_id:
                # 패턴 정보 저장
                skill = self._skills.get(skill_id)
                if skill:
                    skill.source_pattern = pattern_key
                    skill.pattern_count = PATTERN_MIN_REPEATS
                    skill.status = SkillStatus.EXPERIMENTAL
                    self._save_skills()

                logger.info(
                    f"복합 스킬 승격: '{name}' ← 패턴 '{pattern_key}'"
                )

            return skill_id

    def _infer_affordance_tags(
        self, sequence: List[Dict[str, Any]],
    ) -> List[str]:
        """V8: 동작 시퀀스에서 Affordance 태그 추론"""
        tags = []

        # 동작 이름에서 Affordance 추론
        for action in sequence:
            action_name = action.get("action", "")
            args = action.get("args", {})

            if "grasp" in action_name or "close_gripper" in action_name:
                tags.append("graspable")
            if "move" in action_name:
                tags.append("movable")
            if "push" in action_name:
                tags.append("pushable")
            if "lift" in action_name or "extend_legs" in action_name:
                tags.append("liftable")
            if "look" in action_name or "scan" in action_name:
                tags.append("observable")
            if "feel" in action_name:
                tags.append("tactile")

        # 대상 객체가 있으면 추가
        target = args.get("target", "")
        if target:
            tags.append(target)

        return list(dict.fromkeys(tags))  # 중복 제거

    def _extract_parameters(
        self, sequence: List[Dict],
    ) -> List[Dict[str, Any]]:
        """동작 시퀀스에서 매개변수 추출"""
        params = []
        seen = set()

        for action in sequence:
            args = action.get("args", {})
            for arg_name, arg_value in args.items():
                if arg_name not in seen:
                    param_type = "string"
                    if isinstance(arg_value, (int, float)):
                        param_type = "number"
                    elif isinstance(arg_value, bool):
                        param_type = "boolean"
                    params.append({
                        "name": arg_name,
                        "type": param_type,
                        "default": arg_value,
                    })
                    seen.add(arg_name)

        return params

    # ──────────────────────────────────────────────────────────────────────
    # 버전 관리 / Version Management
    # ──────────────────────────────────────────────────────────────────────

    def upgrade_skill(
        self,
        skill_id: str,
        new_sequence: List[Dict[str, Any]],
        reason: str = "",
        use_ab_test: bool = True,       # V8
    ) -> bool:
        """
        스킬 버전 업그레이드 — V8: A/B 테스트 지원

        기존 스킬의 성공률보다 새 시퀀스의 성공률이 높으면 업그레이드
        V8: use_ab_test=True면 A/B 테스트로 비교
        """
        with self._lock:
            skill = self._skills.get(skill_id)
            if not skill:
                return False

            if use_ab_test:
                # V8: 새 버전을 별도 스킬로 등록 후 A/B 테스트
                new_skill_id = self.register_skill(
                    name=f"{skill.name}_v{skill.version + 1}",
                    action_sequence=new_sequence,
                    name_ko=skill.name_ko,
                    description=f"Upgrade candidate for {skill.name}",
                    skill_type=skill.skill_type,
                    affordance_tags=skill.affordance_tags,
                )

                if new_skill_id:
                    new_skill = self._skills.get(new_skill_id)
                    if new_skill:
                        new_skill.version = skill.version + 1
                        new_skill.domain = skill.domain
                        self._save_skills()

                    # A/B 테스트 시작
                    self.start_ab_test(
                        skill_name=skill.name,
                        variant_a_id=skill_id,
                        variant_b_id=new_skill_id,
                    )

                    logger.info(
                        f"스킬 A/B 테스트 업그레이드: {skill.name} "
                        f"v{skill.version} vs v{skill.version + 1} ({reason})"
                    )
                    return True
            else:
                # 기존 방식: 즉시 업그레이드
                old_version = skill.version
                skill.version += 1
                skill.action_sequence = new_sequence
                skill.last_improved_at = time.time()
                skill.source_pattern = (
                    f"{skill.source_pattern}_v{skill.version}"
                )

                # 성공률 초기화 (새 버전은 다시 평가)
                skill.execution_count = 0
                skill.success_count = 0
                skill.failure_count = 0
                skill.success_rate = 0.0
                skill.status = SkillStatus.EXPERIMENTAL

                self._save_skills()
                logger.info(
                    f"스킬 업그레이드: {skill.name} "
                    f"v{old_version} → v{skill.version} ({reason})"
                )
                return True

        return False

    # ──────────────────────────────────────────────────────────────────────
    # 동작 기록 / Action Recording
    # ──────────────────────────────────────────────────────────────────────

    def _record_action(
        self,
        action_name: str,
        arguments: Dict[str, Any],
        success: bool = True,
    ) -> None:
        """동작 실행 기록 — 패턴 감지용"""
        record = ActionRecord(
            action_name=action_name,
            arguments=arguments,
            success=success,
        )
        self._recent_actions.append(record)

        # 오래된 기록 정리 (10분 이상)
        cutoff = time.time() - 600
        self._recent_actions = [
            a for a in self._recent_actions if a.timestamp >= cutoff
        ]

    # ──────────────────────────────────────────────────────────────────────
    # 검색 / Search
    # ──────────────────────────────────────────────────────────────────────

    def search_skills(
        self,
        query: str,
        include_affordances: bool = True,   # V8
    ) -> List[Dict[str, Any]]:
        """스킬 검색 — V8: Affordance 태그 검색 포함"""
        query_lower = query.lower()
        results = []

        for skill in self._skills.values():
            if skill.status == SkillStatus.DEPRECATED:
                continue

            score = 0.0
            if query_lower in skill.name.lower():
                score = 1.0
            elif query_lower in skill.description.lower():
                score = 0.8
            elif query_lower in skill.name_ko.lower():
                score = 0.9
            elif any(query_lower in p.get("name", "") for p in skill.parameters):
                score = 0.6
            # V8: Affordance 태그 검색
            elif include_affordances and any(
                query_lower in tag.lower() for tag in skill.affordance_tags
            ):
                score = 0.7
            # V8: 도메인 검색
            elif query_lower in skill.domain.lower():
                score = 0.5

            if score > 0:
                results.append({
                    "skill_id": skill.skill_id,
                    "name": skill.name,
                    "name_ko": skill.name_ko,
                    "description": skill.description,
                    "success_rate": skill.success_rate,
                    "version": skill.version,
                    "skill_type": skill.skill_type.value,       # V8
                    "is_compound": skill.is_compound,
                    "affordance_tags": skill.affordance_tags,   # V8
                    "domain": skill.domain,                      # V8
                    "relevance_score": score,
                })

        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        return results

    def find_skills_by_affordance(
        self,
        affordance: str,
    ) -> List[Dict[str, Any]]:
        """V8: Affordance 태그로 스킬 검색"""
        results = []
        affordance_lower = affordance.lower()

        for skill in self._skills.values():
            if skill.status == SkillStatus.DEPRECATED:
                continue
            if any(affordance_lower in tag.lower() for tag in skill.affordance_tags):
                results.append({
                    "skill_id": skill.skill_id,
                    "name": skill.name,
                    "success_rate": skill.success_rate,
                    "affordance_tags": skill.affordance_tags,
                })

        results.sort(key=lambda x: x["success_rate"], reverse=True)
        return results

    def get_all_skills(self) -> List[Skill]:
        """모든 스킬 반환"""
        return list(self._skills.values())

    def get_active_skills(self) -> List[Skill]:
        """활성 스킬만 반환 (원시+학습+실험+안정)"""
        return [
            s for s in self._skills.values()
            if s.status != SkillStatus.DEPRECATED
        ]

    def get_compound_skills(self) -> List[Skill]:
        """복합 스킬만 반환"""
        return [s for s in self._skills.values() if s.is_compound]

    def get_composed_skills(self) -> List[Skill]:
        """V8: 조합 스킬만 반환"""
        return [s for s in self._skills.values() if s.is_composed]

    def get_transferred_skills(self) -> List[Skill]:
        """V8: 전이 스킬만 반환"""
        return [s for s in self._skills.values() if s.is_transferred]

    def get_innovation_log(self) -> List[Dict[str, Any]]:
        """V8: 혁신 로그 반환"""
        return list(self._innovation_log)

    def get_skill_dependency_graph(self) -> Dict[str, List[str]]:
        """V8: 전체 스킬 의존성 그래프 반환"""
        graph = {}
        for skill in self._skills.values():
            deps = []
            # component_skills가 의존성
            for cid in skill.component_skills:
                cs = self._skills.get(cid)
                if cs:
                    deps.append(cs.name)
            # prerequisites도 의존성
            for prereq in skill.prerequisites:
                if prereq and prereq not in deps:
                    deps.append(prereq)
            if deps:
                graph[skill.name] = deps
        return graph

    def register_from_memory(self, memory_item: Any) -> None:
        """메모리 시스템에서 절차 기억으로 승격 (TODO 34 연동)"""
        # 메모리 아이템이 스킬 관련이면 처리
        pass

    def get_stats(self) -> Dict[str, Any]:
        """스킬 라이브러리 통계 — V8: 추가 정보"""
        total = len(self._skills)
        primitives = sum(
            1 for s in self._skills.values()
            if s.status == SkillStatus.PRIMITIVE
        )
        compound = sum(1 for s in self._skills.values() if s.is_compound)
        composed = sum(1 for s in self._skills.values() if s.is_composed)      # V8
        transferred = sum(1 for s in self._skills.values() if s.is_transferred) # V8
        deprecated = sum(
            1 for s in self._skills.values()
            if s.status == SkillStatus.DEPRECATED
        )
        avg_success = (
            sum(s.success_rate for s in self._skills.values()) / total
            if total > 0 else 0.0
        )
        avg_innovation = (
            sum(s.innovation_score for s in self._skills.values()
                if s.skill_type != SkillType.PRIMITIVE) /
            max(1, total - primitives)
        )
        active_ab_tests = sum(
            1 for t in self._ab_tests.values() if not t.concluded
        )

        return {
            "total_skills": total,
            "primitive_skills": primitives,
            "compound_skills": compound,
            "composed_skills": composed,           # V8
            "transferred_skills": transferred,     # V8
            "deprecated_skills": deprecated,
            "avg_success_rate": avg_success,
            "avg_innovation_score": round(avg_innovation, 3),  # V8
            "max_skills": MAX_SKILLS,
            "recent_actions_tracked": len(self._recent_actions),
            "active_ab_tests": active_ab_tests,    # V8
            "innovation_log_size": len(self._innovation_log),  # V8
        }

    def shutdown(self) -> None:
        """스킬 라이브러리 종료"""
        self._save_skills()
        if self._conn:
            self._conn.close()
            self._conn = None
        logger.info("스킬 라이브러리 V8.5 종료 완료")


# import needed for skill transfer deep copy
import copy



# ============================================================================
# V8.5 Physical AGI - 교차 도메인 스킬 전이 / Cross-Domain Skill Transfer
# ============================================================================


class CrossDomainSkillTransfer:
    """
    교차 도메인 스킬 전이 - 한 도메인의 스킬을 완전히 다른 도메인으로 전이
    Cross-Domain Skill Transfer - Transfer skills from one domain to another.

    예: "컵 잡기"(주방) → "볼트 잡기"(공작) → "촛불 잡기"(장식)
    단순한 매핑이 아닌, 스킬의 구조적 원리를 추출하여 재적용한다.

    NOT simple mapping — extracts structural principles and re-applies them.
    """

    def __init__(self, skill_library: Optional[SkillLibrary] = None):
        """
        교차 도메인 전이 초기화 / Initialize cross-domain transfer.

        Args:
            skill_library: 스킬 라이브러리 인스턴스 / Skill library instance
        """
        self._library = skill_library
        self._transfer_map: Dict[str, List[Dict[str, Any]]] = {}  # 전이 맵핑
        self._transfer_history: List[Dict[str, Any]] = []          # 전이 이력
        self._domain_similarity: Dict[Tuple[str, str], float] = {} # 도메인 유사도
        logger.info(
            "CrossDomainSkillTransfer 초기화 / Cross-domain skill transfer initialized"
        )

    def transfer(
        self,
        source_skill_id: str,
        target_domain: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """
        소스 스킬을 대상 도메인으로 전이 / Transfer source skill to target domain.

        전이 과정 / Transfer Process:
            1. 소스 스킬의 구조적 원리 추출 / Extract structural principles
            2. 대상 도메인의 제약 분석 / Analyze target domain constraints
            3. 원리를 대상 도메인에 적응 / Adapt principles to target domain
            4. 전이된 스킬 생성 / Generate transferred skill

        Args:
            source_skill_id: 소스 스킬 ID / Source skill ID
            target_domain: 대상 도메인 / Target domain
            context: 전이 맥락 정보 / Transfer context information

        Returns:
            전이된 스킬 ID / Transferred skill ID
        """
        if self._library is None:
            logger.error("스킬 라이브러리가 연결되지 않음 / Skill library not connected")
            return None

        context = context or {}
        source_skill = self._library._skills.get(source_skill_id)
        if not source_skill:
            logger.error(f"전이 원본 스킬 없음: {source_skill_id}")
            return None

        # 1. 구조적 원리 추론 / Infer structural principles
        principles = self._extract_principles(source_skill)

        # 2. 대상 도메인 제약 분석 / Analyze target domain constraints
        target_constraints = self._analyze_domain_constraints(target_domain, context)

        # 3. 원리 적응 / Adapt principles
        adapted_sequence = self._adapt_principles(
            principles, source_skill.action_sequence, target_constraints
        )

        # 4. 전이된 스킬 생성 / Generate transferred skill
        transferred_id = self._library.register_skill(
            name=f"{source_skill.name}_to_{target_domain}",
            action_sequence=adapted_sequence,
            name_ko=f"{source_skill.name_ko}→{target_domain}",
            description=f"Cross-domain transfer: {source_skill.name} ({source_skill.domain}) → {target_domain}",
            skill_type=SkillType.TRANSFERRED,
            affordance_tags=source_skill.affordance_tags + [f"domain:{target_domain}"],
            domain=target_domain,
        )

        if transferred_id:
            # 전이 정보 기록 / Record transfer info
            self._transfer_map.setdefault(source_skill.domain, []).append({
                "source_skill_id": source_skill_id,
                "target_domain": target_domain,
                "transferred_id": transferred_id,
                "principles": principles,
                "similarity": self._compute_domain_similarity(
                    source_skill.domain, target_domain
                ),
            })
            self._transfer_history.append({
                "source_id": source_skill_id,
                "source_domain": source_skill.domain,
                "target_domain": target_domain,
                "transferred_id": transferred_id,
                "timestamp": time.time(),
            })
            logger.info(
                f"교차 도메인 전이: {source_skill.name} ({source_skill.domain}) → {target_domain} / "
                f"Cross-domain transfer: {source_skill.name} ({source_skill.domain}) → {target_domain}"
            )

        return transferred_id

    def find_transferable_skills(
        self, target_domain: str, min_similarity: float = 0.3
    ) -> List[Dict[str, Any]]:
        """
        대상 도메인으로 전이 가능한 스킬 검색 / Find skills transferable to target domain.

        Args:
            target_domain: 대상 도메인 / Target domain
            min_similarity: 최소 유사도 / Minimum similarity threshold

        Returns:
            전이 가능한 스킬 목록 / List of transferable skills
        """
        if self._library is None:
            return []

        candidates = []
        for skill in self._library._skills.values():
            if skill.domain == target_domain:
                continue
            similarity = self._compute_domain_similarity(skill.domain, target_domain)
            if similarity >= min_similarity:
                candidates.append({
                    "skill_id": skill.skill_id,
                    "name": skill.name,
                    "source_domain": skill.domain,
                    "similarity": round(similarity, 3),
                    "success_rate": skill.success_rate,
                })

        # 유사도 내림차순 정렬 / Sort by similarity descending
        candidates.sort(key=lambda x: x["similarity"], reverse=True)
        return candidates[:20]

    # ─── 내부 메서드 / Internal Methods ───

    def _extract_principles(self, skill: Skill) -> List[Dict[str, Any]]:
        """스킬에서 구조적 원리 추출 / Extract structural principles from skill."""
        principles = []
        for i, action in enumerate(skill.action_sequence):
            principle = {
                "step": i,
                "action_type": action.get("action", ""),
                "role": self._classify_action_role(action),
                "essential": i < 2 or action.get("critical", False),
            }
            principles.append(principle)
        return principles

    def _classify_action_role(self, action: Dict[str, Any]) -> str:
        """액션의 역할 분류 / Classify action role."""
        name = action.get("action", "").lower()
        if any(w in name for w in ["move", "walk", "go", "approach"]):
            return "approach"
        elif any(w in name for w in ["grasp", "grab", "close", "grip"]):
            return "acquire"
        elif any(w in name for w in ["release", "open", "place"]):
            return "release"
        elif any(w in name for w in ["look", "scan", "observe"]):
            return "perceive"
        return "transform"

    def _analyze_domain_constraints(
        self, domain: str, context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """도메인 제약 분석 / Analyze domain constraints."""
        domain_profiles = {
            "kitchen": {"precision": 0.6, "force": 0.5, "speed": 0.4, "safety": 0.7},
            "workshop": {"precision": 0.8, "force": 0.8, "speed": 0.3, "safety": 0.9},
            "outdoor": {"precision": 0.4, "force": 0.7, "speed": 0.6, "safety": 0.8},
            "social": {"precision": 0.3, "force": 0.2, "speed": 0.5, "safety": 0.5},
            "shopping": {"precision": 0.5, "force": 0.3, "speed": 0.5, "safety": 0.6},
            "cleaning": {"precision": 0.4, "force": 0.6, "speed": 0.5, "safety": 0.5},
        }
        return domain_profiles.get(domain, {"precision": 0.5, "force": 0.5, "speed": 0.5, "safety": 0.5})

    def _adapt_principles(
        self,
        principles: List[Dict[str, Any]],
        original_sequence: List[Dict[str, Any]],
        target_constraints: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """원리를 대상 도메인에 적응 / Adapt principles to target domain."""
        adapted = []
        for i, principle in enumerate(principles):
            if principle["essential"] or i < len(original_sequence):
                # 원본 액션을 기반으로 파라미터 조정
                action = original_sequence[i] if i < len(original_sequence) else {"action": principle["action_type"]}
                adapted_action = dict(action)
                # 힘 조정 / Adjust force
                if "force" in adapted_action:
                    adapted_action["force"] = adapted_action["force"] * target_constraints.get("force", 0.5) * 2
                # 속도 조정 / Adjust speed
                if "speed" in adapted_action:
                    adapted_action["speed"] = adapted_action["speed"] * target_constraints.get("speed", 0.5) * 2
                adapted.append(adapted_action)
        return adapted

    def _compute_domain_similarity(self, domain_a: str, domain_b: str) -> float:
        """두 도메인 간 유사도 계산 / Compute similarity between two domains."""
        key = tuple(sorted([domain_a, domain_b]))
        if key in self._domain_similarity:
            return self._domain_similarity[key]

        # 도메인 특성 벡터 / Domain feature vectors
        features = {
            "kitchen": [0.6, 0.5, 0.4, 0.7, 0.8],
            "workshop": [0.8, 0.8, 0.3, 0.9, 0.3],
            "outdoor": [0.4, 0.7, 0.6, 0.8, 0.2],
            "social": [0.3, 0.2, 0.5, 0.5, 0.9],
            "shopping": [0.5, 0.3, 0.5, 0.6, 0.7],
            "cleaning": [0.4, 0.6, 0.5, 0.5, 0.3],
            "crafting": [0.9, 0.4, 0.3, 0.6, 0.2],
            "sports": [0.3, 0.7, 0.8, 0.7, 0.4],
        }

        vec_a = features.get(domain_a, [0.5, 0.5, 0.5, 0.5, 0.5])
        vec_b = features.get(domain_b, [0.5, 0.5, 0.5, 0.5, 0.5])

        # 코사인 유사도 / Cosine similarity
        dot = sum(a * b for a, b in zip(vec_a, vec_b))
        norm_a = sum(a ** 2 for a in vec_a) ** 0.5
        norm_b = sum(b ** 2 for b in vec_b) ** 0.5
        similarity = dot / (norm_a * norm_b) if norm_a > 0 and norm_b > 0 else 0.0

        self._domain_similarity[key] = similarity
        return similarity

    def get_transfer_history(self) -> List[Dict[str, Any]]:
        """전이 이력 반환 / Return transfer history."""
        return self._transfer_history.copy()


# ============================================================================
# V8.5 Physical AGI - 스킬 일반화기 / Skill Generalizer
# ============================================================================


class SkillGeneralizer:
    """
    스킬 일반화기 - 특정 스킬에서 일반 원리를 추출하여 새로운 상황에 적용
    Skill Generalizer - Extract general principles from specific skills.

    예: "빨간 컵 잡기" + "파란 컵 잡기" + "초록 컵 잡기"
         → 일반 원리: "컵 잡기" (색상 무관) → "원통형 물체 잡기" (형태 일반화)

    하드코딩된 일반화 규칙이 아닌, 경험 패턴에서 원리를 자동 추출한다.
    NOT hardcoded generalization rules — automatically extracts principles from experience patterns.
    """

    def __init__(self, skill_library: Optional[SkillLibrary] = None):
        """
        스킬 일반화기 초기화 / Initialize skill generalizer.

        Args:
            skill_library: 스킬 라이브러리 인스턴스 / Skill library instance
        """
        self._library = skill_library
        self._generalized_skills: Dict[str, Dict[str, Any]] = {}
        self._principle_db: Dict[str, List[str]] = {}  # 원리 데이터베이스
        self._generalization_history: List[Dict[str, Any]] = []
        logger.info(
            "SkillGeneralizer 초기화 / Skill generalizer initialized"
        )

    def generalize(
        self,
        skill_ids: List[str],
        generalization_name: str = "",
    ) -> Optional[str]:
        """
        여러 유사 스킬에서 공통 원리를 추출하여 일반화 스킬 생성
        Extract common principles from similar skills to create a generalized skill.

        Args:
            skill_ids: 일반화할 스킬 ID 목록 / Skill IDs to generalize
            generalization_name: 일반화 스킬 이름 / Generalized skill name

        Returns:
            일반화된 스킬 ID / Generalized skill ID
        """
        if self._library is None or len(skill_ids) < 2:
            logger.error(
                "일반화 불가: 라이브러리 없음 또는 스킬 부족 (%d개) / "
                "Cannot generalize: no library or insufficient skills (%d)",
                len(skill_ids),
                len(skill_ids),
            )
            return None

        # 소스 스킬들 수집 / Collect source skills
        source_skills = []
        for sid in skill_ids:
            skill = self._library._skills.get(sid)
            if skill:
                source_skills.append(skill)

        if len(source_skills) < 2:
            logger.error("유효한 소스 스킬 부족 / Insufficient valid source skills")
            return None

        # 1. 공통 시퀀스 패턴 추출 / Extract common sequence patterns
        common_pattern = self._extract_common_pattern(source_skills)

        # 2. 변이 가능한 파라미터 식별 / Identify variable parameters
        variable_params = self._identify_variable_params(source_skills)

        # 3. 일반 원리 추출 / Extract general principles
        principles = self._extract_general_principles(source_skills, variable_params)

        # 4. 일반화 스킬 생성 / Create generalized skill
        name = generalization_name or f"generalized_{source_skills[0].name}"

        generalized_id = self._library.register_skill(
            name=name,
            action_sequence=common_pattern,
            name_ko=f"일반화_{source_skills[0].name_ko}",
            description=f"Generalized from {len(source_skills)} skills: {', '.join(s.name for s in source_skills[:3])}",
            skill_type=SkillType.GENERALIZED,
            affordance_tags=list(set(
                tag for s in source_skills for tag in s.affordance_tags
            )),
            domain="general",
        )

        if generalized_id:
            # 원리 저장 / Store principles
            self._principle_db[name] = principles
            self._generalized_skills[generalized_id] = {
                "source_ids": skill_ids,
                "principles": principles,
                "variable_params": variable_params,
            }
            self._generalization_history.append({
                "generalized_id": generalized_id,
                "source_skills": [s.skill_id for s in source_skills],
                "principles": principles,
                "variable_params": variable_params,
                "timestamp": time.time(),
            })
            logger.info(
                f"스킬 일반화: {len(source_skills)}개 → '{name}' / "
                f"Skill generalized: {len(source_skills)} → '{name}'"
            )

        return generalized_id

    def auto_generalize_domain(self, domain: str) -> List[str]:
        """
        특정 도메인의 모든 스킬을 자동으로 일반화
        Automatically generalize all skills in a specific domain.

        Args:
            domain: 일반화할 도메인 / Domain to generalize

        Returns:
            생성된 일반화 스킬 ID 목록 / List of generalized skill IDs
        """
        if self._library is None:
            return []

        domain_skills = [
            s for s in self._library._skills.values()
            if s.domain == domain and s.skill_type != SkillType.GENERALIZED
        ]

        if len(domain_skills) < 2:
            logger.info(f"도메인 '{domain}'에 일반화할 스킬 부족 / Insufficient skills in '{domain}'")
            return []

        # 스킬 클러스터링 / Cluster similar skills
        clusters = self._cluster_skills(domain_skills)

        generalized_ids = []
        for cluster in clusters:
            if len(cluster) >= 2:
                ids = [s.skill_id for s in cluster]
                gid = self.generalize(ids)
                if gid:
                    generalized_ids.append(gid)

        logger.info(
            f"도메인 '{domain}' 자동 일반화: {len(generalized_ids)}개 생성 / "
            f"Auto-generalized domain '{domain}': {len(generalized_ids)} created"
        )
        return generalized_ids

    def get_principles(self, skill_name: str) -> List[str]:
        """스킬의 일반 원리 반환 / Return general principles for a skill."""
        return self._principle_db.get(skill_name, [])

    # ─── 내부 메서드 / Internal Methods ───

    def _extract_common_pattern(
        self, skills: List[Skill]
    ) -> List[Dict[str, Any]]:
        """공통 시퀀스 패턴 추출 / Extract common sequence pattern."""
        if not skills:
            return []

        # 가장 짧은 시퀀스를 기준으로 공통 패턴 추출
        min_len = min(len(s.action_sequence) for s in skills)
        common = []

        for i in range(min_len):
            # 모든 스킬의 i번째 액션 비교 / Compare i-th action across all skills
            actions_at_i = [s.action_sequence[i] for s in skills]
            common_action = self._find_common_action(actions_at_i)
            if common_action:
                common.append(common_action)

        return common

    def _find_common_action(
        self, actions: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """여러 액션에서 공통 요소 찾기 / Find common elements across actions."""
        if not actions:
            return None

        # 가장 빈번한 액션 타입 / Most frequent action type
        action_types = [a.get("action", "") for a in actions]
        from collections import Counter
        counter = Counter(action_types)
        most_common_type = counter.most_common(1)[0][0]

        # 파라미터 평균 / Average parameters
        avg_action = {"action": most_common_type}
        all_keys = set()
        for a in actions:
            all_keys.update(k for k in a.keys() if k != "action")

        for key in all_keys:
            values = [a.get(key, 0) for a in actions if isinstance(a.get(key), (int, float))]
            if values:
                avg_action[key] = sum(values) / len(values)

        return avg_action

    def _identify_variable_params(
        self, skills: List[Skill]
    ) -> List[str]:
        """변이 가능한 파라미터 식별 / Identify variable parameters across skills."""
        if len(skills) < 2:
            return []

        variable = []
        # 각 파라미터의 분산 확인 / Check variance of each parameter
        all_params: Dict[str, List[float]] = {}
        for skill in skills:
            for param in skill.parameters:
                for key, val in param.items():
                    if isinstance(val, (int, float)):
                        all_params.setdefault(key, []).append(float(val))

        for key, values in all_params.items():
            if len(values) >= 2:
                variance = np.var(values) if len(values) > 1 else 0
                mean = np.mean(values)
                if mean > 0 and (variance / mean) > 0.1:
                    variable.append(key)

        return variable

    def _extract_general_principles(
        self,
        skills: List[Skill],
        variable_params: List[str],
    ) -> List[str]:
        """일반 원리 추출 / Extract general principles."""
        principles = []

        # 1. 공통 전제조건 / Common preconditions
        all_preconds = [set(s.prerequisites) for s in skills]
        if all_preconds:
            common_preconds = set.intersection(*all_preconds) if all_preconds else set()
            if common_preconds:
                principles.append(f"공통 전제조건: {', '.join(list(common_preconds)[:5])}")

        # 2. 시퀀스 길이 원리 / Sequence length principle
        seq_lengths = [len(s.action_sequence) for s in skills]
        avg_len = sum(seq_lengths) / len(seq_lengths)
        principles.append(f"평균 시퀀스 길이: {avg_len:.1f}단계")

        # 3. 변이 파라미터 원리 / Variable parameter principles
        if variable_params:
            principles.append(f"조절 가능한 파라미터: {', '.join(variable_params)}")

        # 4. 도메인 독립 원리 / Domain-independent principles
        domains = set(s.domain for s in skills)
        if len(domains) > 1:
            principles.append(f"다중 도메인 적용: {', '.join(domains)}")

        return principles

    def _cluster_skills(
        self, skills: List[Skill], similarity_threshold: float = 0.5
    ) -> List[List[Skill]]:
        """유사 스킬 클러스터링 / Cluster similar skills."""
        if not skills:
            return []

        clusters: List[List[Skill]] = []
        assigned: Set[int] = set()

        for i, skill_a in enumerate(skills):
            if i in assigned:
                continue
            cluster = [skill_a]
            assigned.add(i)

            for j, skill_b in enumerate(skills):
                if j in assigned or i == j:
                    continue
                # 이름 유사도 / Name similarity
                similarity = self._compute_name_similarity(skill_a.name, skill_b.name)
                if similarity >= similarity_threshold:
                    cluster.append(skill_b)
                    assigned.add(j)

            clusters.append(cluster)

        return clusters

    def _compute_name_similarity(self, name_a: str, name_b: str) -> float:
        """이름 유사도 계산 / Compute name similarity."""
        words_a = set(name_a.lower().replace("_", " ").split())
        words_b = set(name_b.lower().replace("_", " ").split())
        if not words_a or not words_b:
            return 0.0
        intersection = words_a & words_b
        union = words_a | words_b
        return len(intersection) / len(union)

    def get_generalization_history(self) -> List[Dict[str, Any]]:
        """일반화 이력 반환 / Return generalization history."""
        return self._generalization_history.copy()


# ============================================================================
# V8.5 Physical AGI - 퓨샷 스킬 습득 / Few-Shot Skill Acquisition
# ============================================================================


class FewShotSkillAcquisition:
    """
    퓨샷 스킬 습득 - 1~5개의 시연만으로 새 스킬 학습
    Few-Shot Skill Acquisition - Learn new skills from just 1-5 demonstrations.

    핵심 원리 / Core Principle:
        인간은 한두 번의 시연으로 새로운 물리적 과업을 학습할 수 있다.
        로봇도 마찬가지여야 한다 — 하드코딩 없이 시연에서 직접 학습.

        Humans can learn new physical tasks from just 1-2 demonstrations.
        Robots should too — learn directly from demonstrations, NOT from hardcoding.

    학습 과정 / Learning Process:
        1. 시연 관찰 → 핵심 동작 식별 / Observe demo → identify key actions
        2. 동작 일반화 → 파라미터 범위 추론 / Generalize → infer parameter ranges
        3. 내재 모델 구축 → 과업 성공 조건 학습 / Build internal model → learn success conditions
        4. 시행 → 피드백 → 정제 / Attempt → feedback → refine
    """

    def __init__(self, skill_library: Optional[SkillLibrary] = None):
        """
        퓨샷 스킬 습득 초기화 / Initialize few-shot skill acquisition.

        Args:
            skill_library: 스킬 라이브러리 인스턴스 / Skill library instance
        """
        self._library = skill_library
        self._demonstrations: Dict[str, List[Dict[str, Any]]] = {}  # 과제별 시연
        self._learned_models: Dict[str, Dict[str, Any]] = {}        # 학습된 모델
        self._acquisition_history: List[Dict[str, Any]] = []
        logger.info(
            "FewShotSkillAcquisition 초기화 / Few-shot skill acquisition initialized"
        )

    def observe_demonstration(
        self,
        task_name: str,
        demonstration: Dict[str, Any],
    ) -> int:
        """
        시연 관찰 및 기록 / Observe and record a demonstration.

        Args:
            task_name: 과제 이름 / Task name
            demonstration: 시연 데이터 / Demonstration data
                - "actions": List[Dict] - 액션 시퀀스
                - "context": Dict - 맥락 정보
                - "outcome": Dict - 결과 정보

        Returns:
            현재까지 관찰된 시연 수 / Number of demonstrations observed so far
        """
        if task_name not in self._demonstrations:
            self._demonstrations[task_name] = []
        self._demonstrations[task_name].append(demonstration)
        count = len(self._demonstrations[task_name])
        logger.info(
            f"시연 관찰: '{task_name}' (%d번째) / "
            f"Demonstration observed: '%s' (#%d)",
            count, task_name, count,
        )
        return count

    def try_learn(
        self,
        task_name: str,
        min_demonstrations: int = 1,
    ) -> Optional[str]:
        """
        관찰된 시연으로부터 스킬 학습 시도 / Try to learn a skill from observed demonstrations.

        Args:
            task_name: 과제 이름 / Task name
            min_demonstrations: 최소 시연 수 (1~5) / Minimum demonstrations needed

        Returns:
            학습된 스킬 ID (실패 시 None) / Learned skill ID (or None)
        """
        if self._library is None:
            logger.error("스킬 라이브러리 연결 안됨 / Skill library not connected")
            return None

        demos = self._demonstrations.get(task_name, [])
        if len(demos) < min_demonstrations:
            logger.info(
                f"시연 부족: {len(demos)}/{min_demonstrations} / "
                f"Insufficient demonstrations: {len(demos)}/{min_demonstrations}"
            )
            return None

        # 1. 핵심 동작 식별 / Identify key actions
        key_actions = self._identify_key_actions(demos)

        # 2. 파라미터 범위 추론 / Infer parameter ranges
        param_ranges = self._infer_parameter_ranges(demos)

        # 3. 성공 조건 추출 / Extract success conditions
        success_conditions = self._extract_success_conditions(demos)

        # 4. 스킬 생성 / Generate skill
        action_sequence = key_actions
        parameters = [
            {"name": k, "min": v[0], "max": v[1], "default": (v[0] + v[1]) / 2}
            for k, v in param_ranges.items()
        ]

        skill_id = self._library.register_skill(
            name=f"fewshot_{task_name}",
            action_sequence=action_sequence,
            name_ko=f"퓨샷_{task_name}",
            description=f"Few-shot learned from {len(demos)} demonstrations",
            skill_type=SkillType.FEWSHOT,
            parameters=parameters,
        )

        if skill_id:
            self._learned_models[task_name] = {
                "skill_id": skill_id,
                "num_demonstrations": len(demos),
                "key_actions": key_actions,
                "param_ranges": param_ranges,
                "success_conditions": success_conditions,
                "confidence": self._compute_confidence(demos),
            }
            self._acquisition_history.append({
                "task_name": task_name,
                "skill_id": skill_id,
                "num_demonstrations": len(demos),
                "confidence": self._compute_confidence(demos),
                "timestamp": time.time(),
            })
            logger.info(
                f"퓨샷 스킬 학습: '{task_name}' from {len(demos)} demonstrations "
                f"(신뢰도: {self._compute_confidence(demos):.2f}) / "
                f"Few-shot learned: '{task_name}' from {len(demos)} demos "
                f"(confidence: {self._compute_confidence(demos):.2f})"
            )

        return skill_id

    def refine_skill(
        self,
        task_name: str,
        additional_demonstration: Dict[str, Any],
    ) -> Optional[str]:
        """
        추가 시연으로 기존 스킬 정제 / Refine existing skill with additional demonstration.

        Args:
            task_name: 과제 이름 / Task name
            additional_demonstration: 추가 시연 / Additional demonstration

        Returns:
            갱신된 스킬 ID / Updated skill ID
        """
        # 추가 시연 관찰 / Observe additional demo
        count = self.observe_demonstration(task_name, additional_demonstration)

        # 재학습 / Re-learn
        if count >= 1:
            return self.try_learn(task_name, min_demonstrations=1)
        return None

    def get_confidence(self, task_name: str) -> float:
        """과제에 대한 학습 신뢰도 반환 / Return learning confidence for a task."""
        model = self._learned_models.get(task_name)
        return model.get("confidence", 0.0) if model else 0.0

    # ─── 내부 메서드 / Internal Methods ───

    def _identify_key_actions(
        self, demonstrations: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """시연에서 핵심 동작 식별 / Identify key actions from demonstrations."""
        if not demonstrations:
            return []

        # 모든 시연의 액션 수집 / Collect actions from all demos
        all_sequences = [
            d.get("actions", []) for d in demonstrations
        ]

        if not all_sequences:
            return []

        # 가장 짧은 시퀀스 길이 / Shortest sequence length
        min_len = min(len(s) for s in all_sequences if s)

        # 각 위치에서 빈도수 기반 핵심 동작 추출 / Extract key actions by frequency
        key_actions = []
        for i in range(min_len):
            actions_at_i = [s[i] for s in all_sequences if i < len(s)]
            if actions_at_i:
                # 가장 빈번한 액션 선택 / Select most frequent action
                from collections import Counter
                action_types = Counter(
                    json.dumps(a, sort_keys=True) for a in actions_at_i
                )
                most_common = action_types.most_common(1)[0][0]
                key_actions.append(json.loads(most_common))

        return key_actions

    def _infer_parameter_ranges(
        self, demonstrations: List[Dict[str, Any]]
    ) -> Dict[str, Tuple[float, float]]:
        """시연에서 파라미터 범위 추론 / Infer parameter ranges from demonstrations."""
        ranges: Dict[str, Tuple[float, float]] = {}

        for demo in demonstrations:
            for action in demo.get("actions", []):
                for key, val in action.items():
                    if isinstance(val, (int, float)):
                        fval = float(val)
                        if key in ranges:
                            lo, hi = ranges[key]
                            ranges[key] = (min(lo, fval), max(hi, fval))
                        else:
                            ranges[key] = (fval, fval)

        # 범위에 여유 추가 / Add margin to ranges
        expanded = {}
        for key, (lo, hi) in ranges.items():
            margin = max(0.1, (hi - lo) * 0.2)
            expanded[key] = (lo - margin, hi + margin)

        return expanded

    def _extract_success_conditions(
        self, demonstrations: List[Dict[str, Any]]
    ) -> List[str]:
        """시연에서 성공 조건 추출 / Extract success conditions from demonstrations."""
        conditions = []
        for demo in demonstrations:
            outcome = demo.get("outcome", {})
            if outcome.get("success", True):
                conditions.extend(outcome.get("success_factors", []))
        return list(set(conditions))[:10]

    def _compute_confidence(self, demonstrations: List[Dict[str, Any]]) -> float:
        """학습 신뢰도 계산 / Compute learning confidence."""
        if not demonstrations:
            return 0.0

        # 시연 수에 따른 신뢰도 / Confidence based on demo count
        count_confidence = min(len(demonstrations) / 5.0, 1.0)

        # 시연 간 일관성 / Consistency between demonstrations
        sequences = [d.get("actions", []) for d in demonstrations]
        if len(sequences) < 2:
            return count_confidence * 0.5

        # 시퀀스 길이 일관성 / Sequence length consistency
        lengths = [len(s) for s in sequences]
        length_variance = np.var(lengths) if len(lengths) > 1 else 0
        length_consistency = max(0.0, 1.0 - length_variance / 10.0)

        return min(1.0, count_confidence * 0.6 + length_consistency * 0.4)

    def get_acquisition_history(self) -> List[Dict[str, Any]]:
        """습득 이력 반환 / Return acquisition history."""
        return self._acquisition_history.copy()

    def get_learned_tasks(self) -> List[str]:
        """학습된 과제 목록 반환 / Return list of learned tasks."""
        return list(self._learned_models.keys())


