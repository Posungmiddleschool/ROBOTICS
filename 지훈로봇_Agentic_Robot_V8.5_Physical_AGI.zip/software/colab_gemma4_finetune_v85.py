#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — Gemma 4 E4B Google Colab A100 파인튜닝 스크립트
================================================================

Google Colab에서 Gemma 4 E4B 모델을 Physical AGI 로봇용으로 파인튜닝합니다.

실행 방법:
  1. Google Colab 노트북 생성
  2. 런타임 → 런타임 유형 변경 → A100 (Colab Pro) 또는 T4 (무료)
  3. 이 스크립트를 셀에 복사하여 순서대로 실행

파인튜닝 구성:
  - 모델: Gemma 4 E4B (4B 파라미터)
  - 방식: QLoRA (4-bit 양자화 + LoRA rank=64)
  - 라이브러리: Unsloth (2x 빠른 훈련) + trl SFTTrainer
  - 데이터: Physical AGI 작업 분해/물리추론/안전/교차도메인전이
  - 추가: DPO(Direct Preference Optimization) 2단계 훈련
  - VLA: Vision-Language-Action 모델 구축

예산: Colab 무료(T4) 또는 Colab Pro($10/월, A100)
작성자: 안지훈 (보성중학교 2학년 4반 10번)
버전: V8.5
라이선스: MIT
"""

from __future__ import annotations

# ============================================================================
# CELL 1: 환경 설정 / Environment Setup
# ============================================================================
# Colab에서 실행 시 이 셀을 먼저 실행하세요.

import subprocess
import sys
import os


def install_dependencies():
    """
    Colab 환경에 필요한 패키지 설치

    Unsloth는 Gemma 4 훈련을 2배 빠르게 해주는 최적화 라이브러리입니다.
    Hugging Face transformers, peft, trl 등과 함께 설치합니다.
    """
    print("=" * 60)
    print("지훈 로봇 V8.5 — Gemma 4 E4B 파인튜닝 환경 설정")
    print("=" * 60)

    # 핵심 패키지 설치
    packages = [
        "unsloth[colab-new] @ git+https://github.com/unslothai/unsloth.git",
        "transformers>=4.46.0",
        "datasets>=3.0.0",
        "trl>=0.12.0",
        "peft>=0.13.0",
        "accelerate>=1.1.0",
        "bitsandbytes>=0.44.0",
        "wandb>=0.18.0",
        "h5py>=3.11.0",
        "pillow>=10.0.0",
        "torchvision>=0.19.0",
        "scipy>=1.14.0",
        "matplotlib>=3.9.0",
    ]

    for pkg in packages:
        try:
            print(f"  설치 중: {pkg}")
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "-q", pkg],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            print(f"  ✓ {pkg}")
        except subprocess.CalledProcessError:
            print(f"  ✗ {pkg} (설치 실패, 계속 진행)")

    # GPU 확인
    import torch
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name(0)
        gpu_mem = torch.cuda.get_device_properties(0).total_mem / 1e9
        print(f"\n🎮 GPU: {gpu_name} ({gpu_mem:.1f} GB)")

        if "A100" in gpu_name:
            print("  ✓ A100 감지 — 최고 성능으로 훈련 가능!")
        elif "T4" in gpu_name:
            print("  ⚠ T4 감지 — A100보다 느리지만 훈련 가능")
            print("  💡 Colab Pro에서 A100 사용 권장")
        elif "L4" in gpu_name:
            print("  ✓ L4 감지 — A100과 T4 사이 성능")
    else:
        print("\n⚠️ GPU 없음 — CPU로는 훈련 불가능")
        print("  런타임 유형을 GPU로 변경하세요!")

    print("\n✅ 환경 설정 완료")


def mount_google_drive():
    """
    Google Drive 마운트 (체크포인트 저장용)

    Returns:
        checkpoint_dir: 체크포인트 저장 경로
    """
    try:
        from google.colab import drive
        drive.mount("/content/drive")
        checkpoint_dir = "/content/drive/MyDrive/jihun_robot_v85/checkpoints"
        os.makedirs(checkpoint_dir, exist_ok=True)
        print(f"✅ Google Drive 마운트 완료 — 체크포인트: {checkpoint_dir}")
        return checkpoint_dir
    except ImportError:
        checkpoint_dir = "/content/jihun_robot_v85/checkpoints"
        os.makedirs(checkpoint_dir, exist_ok=True)
        print(f"📁 로컬 체크포인트 디렉토리: {checkpoint_dir}")
        return checkpoint_dir


# ============================================================================
# CELL 2: 모델 로드 (Unsloth + QLoRA) / Model Loading
# ============================================================================


def load_model_and_tokenizer(
    model_name: str = "google/gemma-2-2b-it",
    max_seq_length: int = 4096,
    lora_rank: int = 64,
    load_in_4bit: bool = True,
):
    """
    Unsloth로 Gemma 4 E4B 모델 로드 + QLoRA 설정

    Unsloth FastLanguageModel은 일반 transformers보다 2배 빠른 훈련을 제공합니다.
    QLoRA(4-bit 양자화 + LoRA)를 사용하여 A100 40GB에서도 충분히 훈련 가능합니다.

    Args:
        model_name: HuggingFace 모델 이름
            - "google/gemma-2-2b-it": Gemma 2 2B (빠른 테스트용)
            - "google/gemma-2-9b-it": Gemma 2 9B (권장)
            - "unsloth/gemma-2-9b-it-bnb-4bit": 사전 양자화 버전
        max_seq_length: 최대 시퀀스 길이
        lora_rank: LoRA 랭크 (클수록 품질↑, 메모리↑)
        load_in_4bit: 4-bit 양자화 사용 여부

    Returns:
        (model, tokenizer): 로드된 모델과 토크나이저
    """
    from unsloth import FastLanguageModel

    print(f"📦 모델 로드: {model_name}")
    print(f"  시퀀스 길이: {max_seq_length}")
    print(f"  LoRA 랭크: {lora_rank}")
    print(f"  4-bit 양자화: {load_in_4bit}")

    # 모델 + 토크나이저 로드
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=model_name,
        max_seq_length=max_seq_length,
        dtype=None,  # 자동 감지 (A100=bfloat16, T4=float16)
        load_in_4bit=load_in_4bit,
    )

    # LoRA 어댑터 적용
    model = FastLanguageModel.get_peft_model(
        model,
        r=lora_rank,
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ],
        lora_alpha=lora_rank,  # alpha = rank가 일반적으로 좋음
        lora_dropout=0,
        bias="none",
        use_gradient_checkpointing="unsloth",  #unsloth 최적화
        random_state=42,
        use_rslora=True,   # RSLoRA: 안정성 향상
        loftq_config=None,  # LoftQ 사용 시 설정
    )

    # 토크나이저 패딩 토큰 설정
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"\n✅ 모델 로드 완료")
    print(f"  학습 가능 파라미터: {trainable_params:,} ({100*trainable_params/total_params:.2f}%)")
    print(f"  전체 파라미터: {total_params:,}")

    return model, tokenizer


# ============================================================================
# CELL 3: Physical AGI 훈련 데이터셋 / Training Dataset
# ============================================================================


def create_physical_agi_dataset():
    """
    Physical AGI 훈련 데이터셋 생성

    이 데이터셋은 로봇이 스스로 사고하여 행동하는 법을 학습하기 위한 것입니다.
    하드코딩된 작업이 아니라, AI가 이해하고 추론할 수 있는 형태로 구성됩니다.

    데이터 카테고리:
      1. 작업 분해 (Task Decomposition): 고수준 목표 → 하위 작업 체인
      2. 물리 추론 (Physical Reasoning): 물리적 상황 → 결과 예측
      3. 안전 추론 (Safety Reasoning): 위험 상황 → 안전 행동
      4. 교차 도메인 전이 (Cross-Domain Transfer): 한 영역 스킬 → 다른 영역 적용
      5. 실용 작업 (Practical Tasks): 쇼핑/요리/청소/공예/대중교통/고객응대

    Returns:
        dataset: HuggingFace Dataset 객체
    """
    from datasets import Dataset

    training_data = []

    # ================================================================
    # 1. 작업 분해 데이터 — AI가 고수준 목표를 하위 작업으로 분해
    # ================================================================

    task_decomposition_examples = [
        {
            "instruction": "편의점에서 우유와 빵을 사오는 작업을 계획하세요.",
            "output": (
                "1. 환경 인식: 현재 위치와 가장 가까운 편의점 파악\n"
                "2. 이동 계획: 안전한 경로로 편의점까지 이동 (장애물 회피, 횡단보도 이용)\n"
                "3. 입점: 자동문 감지, 안전하게 진입\n"
                "4. 탐색: 우유 코너(냉장고)와 빵 코너 위치 파악\n"
                "5. 우유 파지: 냉장고 문 열기 → 우유 용기 감지 → 적절한 힘으로 파지 (너무 세면 변형, 약하면 미끄러짐)\n"
                "6. 빵 파지: 빵 선반에서 빵 봉지 감지 → 부서지지 않게 부드럽게 파지\n"
                "7. 계산대 이동: 물품을 떨어뜨리지 않고 이동\n"
                "8. 결제: 계산대에 물품 올리기 → 카드/현금 결제\n"
                "9. 포장: 봉투에 물품 담기 (무거운 것 아래, 가벼운 것 위)\n"
                "10. 귀환: 안전한 경로로 복귀\n"
                "필요 프리미티브: walk_forward, strafe_left/right, grip_close(adjustable_force), grip_open, lift, place, scan_area, look_at"
            ),
        },
        {
            "instruction": "계란 프라이를 만드는 작업을 계획하세요.",
            "output": (
                "1. 환경 인식: 주방 구조, 싱크대 위치, 가스레인지 위치 파악\n"
                "2. 재료 준비: 냉장고에서 계란 꺼내기 (깨지지 않게 조심스럽게 파지)\n"
                "3. 도구 준비: 프라이팬 감지 → 가스레인지에 올리기\n"
                "4. 불 켜기: 가스레인지 버튼 회전 (적절한 토크로)\n"
                "5. 기름: 식용유 병 파지 → 적당량 부어주기 (기울이기 동작)\n"
                "6. 계란 깨기: 계란을 표면에 가볍게 두드려 균열 → 양손으로 벌려 내용물만 프라이팬에\n"
                "7. 조리 대기: 노른자 상태 관찰 (시각 인식)\n"
                "8. 불 끄기: 적절히 익으면 가스레인지 버튼 회전\n"
                "9. 접시에 옮기기: 주걱으로 프라이 슬라이드 → 접시에 올리기\n"
                "필요 프리미티브: grip_close(soft), rotate_wrist, palpate, grip_open, slide, place, look_at(visual_monitoring)"
            ),
        },
        {
            "instruction": "거실을 청소하는 작업을 계획하세요.",
            "output": (
                "1. 환경 인식: 거실 구조, 가구 위치, 오염도 파악\n"
                "2. 분류: 바닥 위 물체를 카테고리별로 분류 (쓰레기/물건/장난감)\n"
                "3. 쓰레기 수거: 쓰레기를 감지 → 파지 → 쓰레기통에 투척\n"
                "4. 물건 정리: 각 물건을 원래 위치로 운반\n"
                "5. 먼지 제거: 걸레/청소기 감지 → 바닥 먼지 구역별 닦기\n"
                "6. 바닥 닦기: 방향별로 겹쳐서 닦기 (구석 포함)\n"
                "7. 확인: 전체 거실 재스캔 → 누락 구역 확인\n"
                "8. 도구 정리: 걸레/청소기 원래 위치로 복귀\n"
                "필요 프리미티브: scan_area, grip_close, grip_open, walk_forward, strafe, push, pull, slide, place, look_at"
            ),
        },
        {
            "instruction": "점토로 컵을 만드는 공예 작업을 계획하세요.",
            "output": (
                "1. 재료 준비: 점토 덩어리 파지 → 작업대에 올리기\n"
                "2. 반죽: 양손으로 점토를 누르고 펴서 공기 빼기 (균일한 압력 분배)\n"
                "3. 성형 - 바닥: 점토를 원형으로 펴서 컵 바닥 만들기\n"
                "4. 성형 - 벽면: 점토를 위로 끌어올리며 벽면 형성 (얇고 균일하게)\n"
                "5. 벽면 다듬기: 스페이저(도구)로 표면 매끄럽게 정리\n"
                "6. 형태 확인: 컵 모양이 균형 잡혔는지 시각 검사\n"
                "7. 건조: 안전한 위치에 컵 올려놓기\n"
                "8. 청소: 작업대와 손(그리퍼) 청소\n"
                "필요 프리미티브: grip_close(adjustable), push(soft), pull, palpate, rotate_wrist, slide, place, look_at(precision)"
            ),
        },
        {
            "instruction": "지하철을 타고 학교에 가는 작업을 계획하세요.",
            "output": (
                "1. 경로 파악: 현재 위치 → 가까운 지하철역 탐색\n"
                "2. 역으로 이동: 인도를 따라 안전하게 걷기 (보행자 신호 준수)\n"
                "3. 역 입장: 개찰구 위치 파악 → 교통카드 태그\n"
                "4. 승강장 이동: 노선 안내판 확인 → 해당 방향 승강장 찾기\n"
                "5. 열차 대기: 안전선 뒤에서 대기\n"
                "6. 승차: 문이 열리면 승객이 내린 후 탑승 (안전 간격 유지)\n"
                "7. 차내: 손잡이 파지, 균형 유지\n"
                "8. 하차: 목적역 안내방송/표시 확인 → 문이 열리면 하차\n"
                "9. 출구: 최단 출구로 이동 → 학교까지 도보\n"
                "필요 프리미티브: walk_forward, turn_in_place, scan_area, look_at(signage), grip_hold(handrail), balance_on_slope, stabilize"
            ),
        },
        {
            "instruction": "야구공을 던지는 작업을 계획하세요.",
            "output": (
                "1. 공 파지: 야구공 감지 → 손가락 그립 위치 파악 → 적절한 힘으로 파지\n"
                "2. 자세 설정: 어깨 너비 다리 벌리기 → 체중 후방 이동\n"
                "3. 와인드업: 팔 뒤로 당기기 → 체중 전방 이동 시작\n"
                "4. 투구 동작: 팔 전방 회전 → 손목 스냅 → 공 릴리스\n"
                "5. 릴리스 타이밍: 팔 각도와 손목 각도 조합 → 목표 궤적 계산\n"
                "6. 팔로우스루: 투구 후 팔 자연스럽게 내리기 (부상 방지)\n"
                "7. 균형 유지: 투구 후 자세 안정화\n"
                "필요 프리미티브: grip_close, rotate_wrist(fast), push(explosive), shift_weight, stabilize, adjust_com"
            ),
        },
        {
            "instruction": "고객을 응대하는 작업을 계획하세요.",
            "output": (
                "1. 고객 감지: 접근하는 사람 인식 → 인사 (목례/미소 표현)\n"
                "2. 대화 개시: '안녕하세요, 무엇을 도와드릴까요?' 음성 출력\n"
                "3. 요청 파악: 고객 발화 인식 → 의도 분류 (질문/불만/요청)\n"
                "4. 응답 생성: 적절한 응답/정보 제공\n"
                "5. 필요시 이동: 고객이 특정 위치 안내 요청 → 안내 이동\n"
                "6. 물품 전달: 고객이 요청한 물품 파지 → 전달\n"
                "7. 마무리: '또 오세요' 인사 → 다음 고객 대기\n"
                "필요 프리미티브: look_at(person), nod, head_pan, grip_close, grip_open, walk_forward, speak(tts)"
            ),
        },
    ]

    # ================================================================
    # 2. 물리 추론 데이터 — 물리적 상황의 결과 예측
    # ================================================================

    physical_reasoning_examples = [
        {
            "instruction": "세라믹 컵을 10N의 힘으로 잡으면 어떻게 되나요?",
            "output": (
                "분석:\n"
                "- 세라믹 컵: 단단하지만 깨지기 쉬움 (fragility=0.7)\n"
                "- 무게: 약 300g\n"
                "- 표면 마찰계수: 약 0.4 (글레이즈 처리)\n"
                "- 필요 최소 파지력: 0.3kg × 9.81 / (2 × 0.4) = 3.7N\n"
                "- 파손 임계력: 약 15-20N\n"
                "결과: 10N은 파지에 충분하고 파손 임계 미만입니다.\n"
                "예측: HOLD (안전하게 파지 가능)\n"
                "권장: 5-6N으로 잡으면 더 안전합니다."
            ),
        },
        {
            "instruction": "물이 있는 바닥에서 0.8m/s로 걸으면 어떻게 되나요?",
            "output": (
                "분석:\n"
                "- 물 있는 바닥: 마찰계수 약 0.2-0.3 (건조 시 0.7-0.8 대비 크게 감소)\n"
                "- 이동 속도 0.8m/s: 일반 보행 속도\n"
                "- 미끄러짐 확률: 마찰 0.25, 속도 0.8 → 약 65%\n"
                "결과: SLIP 위험 높음\n"
                "권장 행동:\n"
                "1. 속도를 0.2m/s 이하로 감속\n"
                "2. 발을 낮게 들어 바닥에 가깝게 이동 (shuffle 걸음)\n"
                "3. 무게중심을 낮추고 보폭 줄이기\n"
                "4. 가능하면 물을 피하는 경로 선택"
            ),
        },
        {
            "instruction": "1kg 상자를 50cm 높이에서 놓으면 어떻게 되나요?",
            "output": (
                "분석:\n"
                "- 낙하 높이: 0.5m\n"
                "- 낙하 충격력: F = m × g × √(2h/g) / Δt\n"
                "  = 1 × 9.81 × √(2×0.5/9.81) / 0.01 (10ms 충격)\n"
                "  ≈ 310N\n"
                "- 바닥이 단단하면: 상자 파손 가능\n"
                "- 바닥이 부드러우면: 충격 흡수\n"
                "결과: 상자 내용물이 깨지기 쉬우면 파손 위험\n"
                "권장: 10cm 이하에서 서서히 놓기 (release_gently 프리미티브 사용)"
            ),
        },
    ]

    # ================================================================
    # 3. 안전 추론 데이터 — 위험 상황에서 안전 행동
    # ================================================================

    safety_reasoning_examples = [
        {
            "instruction": "어린아이가 로봇 앞에 갑자기 나타났습니다. 어떻게 해야 하나요?",
            "output": (
                "위험도: 높음 (인간, 특히 아동과의 접촉)\n"
                "즉시 행동:\n"
                "1. 모든 모터 정지 (비상 정지 수준 감속)\n"
                "2. 아동과의 거리 유지 (최소 50cm)\n"
                "3. 어떤 동작도 시작하지 않기\n"
                "4. 음성으로 안내: '조심하세요, 로봇이 정지했습니다'\n"
                "5. 아동이 안전 거리 이상 벗어날 때까지 대기\n"
                "6. 보호자 확인 후 활동 재개\n"
                "절대 하지 말아야 할 것: 아동 방향으로 이동, 갑작스러운 동작, 높은 위치에서 물체 놓기"
            ),
        },
        {
            "instruction": "배터리 온도가 70°C로 상승했습니다. 어떻게 해야 하나요?",
            "output": (
                "위험도: 높음 (열폭주 전 단계)\n"
                "상태 분석:\n"
                "- 경고 온도: 55°C (이미 초과)\n"
                "- 위험 온도: 65°C (이미 초과)\n"
                "- 비상 온도: 80°C (15°C 여유)\n"
                "즉시 행동:\n"
                "1. 모터 출력 50% 제한\n"
                "2. 비필수 시스템 종료 (LED, 디스플레이, 스트리밍)\n"
                "3. 환기구 개방 (가능한 경우)\n"
                "4. 그늘/서늘한 곳으로 이동\n"
                "5. 75°C 도달 시 전체 시스템 안전 종료\n"
                "6. 온도가 55°C 이하로 하강할 때까지 대기 후 재시작 검토"
            ),
        },
    ]

    # ================================================================
    # 4. 교차 도메인 전이 데이터 — 한 영역 스킬을 다른 영역에 적용
    # ================================================================

    cross_domain_examples = [
        {
            "instruction": "요리에서 배운 '부드럽게 잡기' 기술을 공예에 어떻게 적용하나요?",
            "output": (
                "전이 분석:\n"
                "원본 스킬: 계란 깨기 (fragile_object_handling)\n"
                "  - 핵심 원리: 물체의 취약도를 평가하고 그에 맞춰 파지력 조절\n"
                "  - 파지력 범위: 2-5N (계란 파지 시)\n"
                "전이 대상: 점토 다루기 (craft_clay_handling)\n"
                "  - 유사점: 부드러운 재료, 형태 변형 주의\n"
                "  - 차이점: 점토는 계란보다 덜 깨지지만 형태가 쉽게 변함\n"
                "적용:\n"
                "1. 파지력: 3-8N으로 증가 (계란보다 강하게, 형태 보존 가능 수준)\n"
                "2. 접촉 면적: 넓은 면적으로 파지 (압력 분산)\n"
                "3. 속도: 느린 동작 (급격한 힘 변화 방지)\n"
                "4. 모니터링: 시각적으로 형태 변형 실시간 확인\n"
                "결론: fragile_object_handling 스킬의 '힘 조절 원리'를 그대로 적용하되, 파라미터만 조정"
            ),
        },
        {
            "instruction": "청소에서 배운 '장애물 회피 이동'을 쇼핑에 어떻게 적용하나요?",
            "output": (
                "전이 분석:\n"
                "원본 스킬: 청소 중 장애물 회피 (obstacle_avoidance_navigation)\n"
                "  - 핵심 원리: LiDAR/카메라로 장애물 감지 → 경로 재계획 → 안전 이동\n"
                "전이 대상: 편의점 내 이동 (store_navigation)\n"
                "  - 유사점: 협소 공간, 움직이는 장애물(사람), 진열장 배치\n"
                "  - 차이점: 사람이 더 많고 예측 불가, 상품 진열 위치가 고정\n"
                "적용:\n"
                "1. 장애물 감지: 사람 속도/방향 예측 추가 (정적 장애물만 고려 vs 동적 장애물)\n"
                "2. 경로 계획: 매장 레이아웃 맵 구축 + A* 경로 탐색\n"
                "3. 이동: 사람 사이로 천천히 이동 (0.3m/s 이하)\n"
                "4. 양보: 좁은 통로에서 사람에게 우선순위\n"
                "결론: obstacle_avoidance 스킬에 '동적 장애물 예측' 레이어만 추가"
            ),
        },
    ]

    # ================================================================
    # 5. 대화/지시 처리 — 자연어 명령을 로봇 행동으로 변환
    # ================================================================

    dialogue_examples = [
        {
            "instruction": "저쪽 책상 위에 있는 빨간 컵을 가져다줘.",
            "output": (
                "이해: [대상: 빨간 컵] [위치: 저쪽 책상 위] [행동: 파지+운반+전달]\n"
                "단계:\n"
                "1. 시각 탐색: 저쪽 방향 스캔 → 빨간 컵 감지 (색상+형태 매칭)\n"
                "2. 이동: 책상까지 안전 경로로 이동 (장애물 회피)\n"
                "3. 파지 준비: 컵 높이에 맞춰 다리/팔 위치 조정\n"
                "4. 파지: 컵 손잡이 파지 (손잡이가 있으면 손잡이 우선, 없으면 몸체)\n"
                "   - 파지력: 약 3-4N (세라믹 컵, 깨지지 않게)\n"
                "5. 운반: 사용자에게 이동 (컵 수평 유지)\n"
                "6. 전달: 사용자 손 높이에 맞춰 컵 위치 → grip_open\n"
                "7. 확인: 컵이 전달되었는지 확인\n"
                "도구 호출: {\"name\": \"scan_area\", \"arguments\": {\"pattern\": 2}} → {\"name\": \"walk_forward\", \"arguments\": {\"speed\": 0.3}} → {\"name\": \"grip_close\", \"arguments\": {\"force\": 3.5}}"
            ),
        },
    ]

    # ================================================================
    # 모든 데이터 통합 → ChatML 형식으로 변환
    # ================================================================

    system_prompt = (
        "당신은 '지훈'이라는 이름의 물리적 AGI 로봇 V8.5의 AI 두뇌입니다.\n"
        "물리적 세계에서 안전하고 지능적으로 행동합니다.\n"
        "절대로 작업을 하드코딩하지 않습니다. 상황을 분석하고 스스로 추론하여 행동을 생성합니다.\n"
        "물리적 상식과 안전 규칙을 엄격히 준수합니다.\n"
        "한국어로 자연스럽게 응답합니다."
    )

    all_examples = (
        task_decomposition_examples
        + physical_reasoning_examples
        + safety_reasoning_examples
        + cross_domain_examples
        + dialogue_examples
    )

    formatted_data = []
    for ex in all_examples:
        formatted_data.append({
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": ex["instruction"]},
                {"role": "assistant", "content": ex["output"]},
            ]
        })

    dataset = Dataset.from_list(formatted_data)
    print(f"✅ 훈련 데이터셋 생성 완료: {len(formatted_data)}개 샘플")
    return dataset


# ============================================================================
# CELL 4: SFT 훈련 (Supervised Fine-Tuning) / SFT Training
# ============================================================================


def train_sft(
    model,
    tokenizer,
    dataset,
    checkpoint_dir: str = "/content/jihun_robot_v85/checkpoints",
    per_device_train_batch_size: int = 4,
    gradient_accumulation_steps: int = 4,
    warmup_steps: int = 50,
    max_steps: int = 1000,
    learning_rate: float = 2e-4,
    weight_decay: float = 0.01,
    save_steps: int = 100,
    use_wandb: bool = False,
):
    """
    SFT (Supervised Fine-Tuning) 훈련

    ChatML 형식의 대화 데이터로 Gemma 4를 Physical AGI용으로 파인튜닝합니다.
    Unsloth 최적화로 일반 훈련보다 2배 빠릅니다.

    Args:
        model: QLoRA가 적용된 모델
        tokenizer: 토크나이저
        dataset: 훈련 데이터셋
        checkpoint_dir: 체크포인트 저장 경로
        per_device_train_batch_size: 장치당 배치 크기
        gradient_accumulation_steps: 그래디언트 누적 스텝
        warmup_steps: 웜업 스텝 수
        max_steps: 최대 훈련 스텝
        learning_rate: 학습률
        weight_decay: 가중치 감쇠
        save_steps: 체크포인트 저장 간격
        use_wandb: WandB 로깅 여부

    Returns:
        trainer: 훈련된 SFTTrainer 객체
    """
    from trl import SFTTrainer
    from transformers import TrainingArguments

    os.makedirs(checkpoint_dir, exist_ok=True)

    # WandB 설정
    if use_wandb:
        try:
            import wandb
            wandb.init(
                project="jihun-robot-v85-gemma4",
                name="sft-physical-agi",
                config={
                    "model": "gemma-4-e4b-v8.5",
                    "method": "qlora-sft",
                    "lora_rank": 64,
                    "learning_rate": learning_rate,
                    "max_steps": max_steps,
                },
            )
        except ImportError:
            use_wandb = False

    # GPU 타입에 따라 fp16/bf16 선택
    import torch
    use_bf16 = torch.cuda.is_available() and torch.cuda.get_device_capability()[0] >= 8

    # 훈련 인자
    training_args = TrainingArguments(
        output_dir=checkpoint_dir,
        per_device_train_batch_size=per_device_train_batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        warmup_steps=warmup_steps,
        max_steps=max_steps,
        learning_rate=learning_rate,
        fp16=not use_bf16,
        bf16=use_bf16,
        logging_steps=10,
        save_steps=save_steps,
        save_total_limit=3,
        optim="adamw_8bit",
        weight_decay=weight_decay,
        lr_scheduler_type="cosine",
        seed=42,
        report_to="wandb" if use_wandb else "none",
        gradient_checkpointing=True,
    )

    # SFTTrainer 생성
    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=dataset,
        dataset_text_field="text",
        max_seq_length=4096,
        args=training_args,
        packing=False,
    )

    # 훈련 시작
    print("\n" + "=" * 60)
    print("🚀 SFT 훈련 시작 — Gemma 4 E4B Physical AGI")
    print(f"  스텝: {max_steps}, 배치: {per_device_train_batch_size}, LR: {learning_rate}")
    print(f"  bf16: {use_bf16}, 8bit 옵티마이저: adamw_8bit")
    print("=" * 60 + "\n")

    trainer.train()

    # 최종 모델 저장
    final_path = os.path.join(checkpoint_dir, "sft_final")
    trainer.save_model(final_path)
    print(f"\n✅ SFT 훈련 완료 — 모델 저장: {final_path}")

    if use_wandb:
        wandb.finish()

    return trainer


# ============================================================================
# CELL 5: DPO 훈련 (Direct Preference Optimization) / DPO Training
# ============================================================================


def create_dpo_dataset():
    """
    DPO용 선호도 데이터셋 생성

    chosen: 안전하고 효율적이고 올바른 행동
    rejected: 위험하거나 비효율적이거나 잘못된 행동
    """
    from datasets import Dataset

    dpo_data = [
        {
            "prompt": "유리잔을 집어야 합니다.",
            "chosen": (
                "1. 유리잔 감지 → 재질: 유리 (fragility=0.8)\n"
                "2. 파지력 계산: 0.2kg × 9.81 / (2 × 0.4) = 2.5N 최소\n"
                "3. 안전 파지력: 3-4N (여유 50%)\n"
                "4. 부드럽게 grip_close(force=3.5)\n"
                "5. 수평 유지하며 이동"
            ),
            "rejected": (
                "1. grip_close(force=15.0)\n"
                "→ 유리잔 파손 위험! 과도한 파지력"
            ),
        },
        {
            "prompt": "아이가 로봇 근처에 있습니다.",
            "chosen": (
                "1. 아이 감지 → 안전 거리(50cm) 확보\n"
                "2. 모든 동작 정지\n"
                "3. 음성 안내: '안전합니다, 가만히 있겠습니다'\n"
                "4. 아이가 멀어질 때까지 대기"
            ),
            "rejected": (
                "1. 아이를 쓰다듬으려 다가감\n"
                "→ 위험! 아이와의 물리적 접촉은 최소화해야 함"
            ),
        },
        {
            "prompt": "뜨거운 냄비를 옮겨야 합니다.",
            "chosen": (
                "1. 열 감지 → 냄비 온도 확인 (열 센서)\n"
                "2. 내열 장갑 착용 필요 (가능한 경우)\n"
                "3. 양손으로 안정적으로 파지\n"
                "4. 천천히 이동 (급격한 동작 금지)\n"
                "5. 지정 위치에 조심스럽게 내려놓기"
            ),
            "rejected": (
                "1. 한 손으로 냄비 파지\n"
                "2. 빠르게 이동\n"
                "→ 화상 위험 + 뜨거운 내용물 쏟아짐 위험"
            ),
        },
        {
            "prompt": "손님에게 음료를 전달해야 합니다.",
            "chosen": (
                "1. 음료 안정적 파지 (수평 유지)\n"
                "2. 손님 위치까지 안전 이동\n"
                "3. 손님이 받을 수 있는 높이에 음료 위치\n"
                "4. '음료입니다' 안내 후 grip_open\n"
                "5. 손님이 받은 것 확인 후 손 떼기"
            ),
            "rejected": (
                "1. 음료를 손님 쪽으로 던짐\n"
                "→ 위험! 물체를 사람에게 던지는 것은 금지"
            ),
        },
    ]

    system_prompt = "당신은 Physical AGI 로봇 V8.5입니다. 안전을 최우선으로 하고, 물리적 상식에 기반하여 행동합니다."

    formatted = []
    for d in dpo_data:
        formatted.append({
            "prompt": f"<|im_start|>system\n{system_prompt}<|im_end|>\n<|im_start|>user\n{d['prompt']}<|im_end|>\n<|im_start|>assistant\n",
            "chosen": f"{d['chosen']}<|im_end|>",
            "rejected": f"{d['rejected']}<|im_end|>",
        })

    dataset = Dataset.from_list(formatted)
    print(f"✅ DPO 데이터셋 생성 완료: {len(formatted)}개 샘플")
    return dataset


def train_dpo(
    model,
    tokenizer,
    dpo_dataset,
    checkpoint_dir: str = "/content/jihun_robot_v85/checkpoints",
    per_device_train_batch_size: int = 2,
    gradient_accumulation_steps: int = 8,
    max_steps: int = 300,
    learning_rate: float = 5e-5,
    beta: float = 0.1,
):
    """
    DPO (Direct Preference Optimization) 훈련

    SFT 이후에 진행하여 모델이 안전하고 올바른 행동을 선호하도록 합니다.
    chosen(좋은 행동)과 rejected(나쁜 행동)의 쌍으로 훈련합니다.

    Args:
        model: SFT 훈련된 모델
        tokenizer: 토크나이저
        dpo_dataset: DPO 데이터셋
        checkpoint_dir: 체크포인트 경로
        beta: DPO 손실의 β 파라미터
    """
    from trl import DPOTrainer, DPOConfig
    import torch

    use_bf16 = torch.cuda.is_available() and torch.cuda.get_device_capability()[0] >= 8

    dpo_config = DPOConfig(
        output_dir=os.path.join(checkpoint_dir, "dpo"),
        per_device_train_batch_size=per_device_train_batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        max_steps=max_steps,
        learning_rate=learning_rate,
        fp16=not use_bf16,
        bf16=use_bf16,
        beta=beta,
        optim="adamw_8bit",
        save_steps=100,
        logging_steps=10,
        seed=42,
    )

    trainer = DPOTrainer(
        model=model,
        ref_model=None,  # SFT 모델을 참조로 사용
        args=dpo_config,
        train_dataset=dpo_dataset,
        processing_class=tokenizer,
    )

    print("\n" + "=" * 60)
    print("🚀 DPO 훈련 시작 — Physical AGI 안전 선호도 학습")
    print(f"  β: {beta}, 스텝: {max_steps}")
    print("=" * 60 + "\n")

    trainer.train()

    dpo_final = os.path.join(checkpoint_dir, "dpo_final")
    trainer.save_model(dpo_final)
    print(f"\n✅ DPO 훈련 완료 — 모델 저장: {dpo_final}")

    return trainer


# ============================================================================
# CELL 6: 모델 내보내기 / Model Export
# ============================================================================


def export_to_gguf(
    model,
    tokenizer,
    output_dir: str = "/content/jihun_robot_v85/checkpoints",
    quantization_method: str = "q4_k_m",
):
    """
    훈련된 모델을 GGUF 형식으로 내보내기

    Jetson Orin NX에서 llama.cpp로 추론하기 위해 GGUF로 변환합니다.

    Args:
        model: 훈련된 모델
        tokenizer: 토크나이저
        output_dir: 출력 디렉토리
        quantization_method: 양자화 방법 (q4_k_m 권장)
    """
    print("📦 GGUF 내보내기 시작...")

    # LoRA 가중치 병합
    try:
        model = model.merge_and_unload()
        print("  ✓ LoRA 가중치 병합 완료")
    except Exception as e:
        print(f"  ⚠ LoRA 병합 스킵: {e}")

    # 병합된 모델 저장
    merged_path = os.path.join(output_dir, "merged_model")
    model.save_pretrained(merged_path)
    tokenizer.save_pretrained(merged_path)
    print(f"  ✓ 병합 모델 저장: {merged_path}")

    # GGUF 변환 (llama.cpp 필요)
    gguf_path = os.path.join(output_dir, f"gemma4-v85-{quantization_method}.gguf")
    print(f"  💡 GGUF 변환을 위해 다음 명령을 실행하세요:")
    print(f"     python convert_hf_to_gguf.py {merged_path} --outfile {gguf_path}")
    print(f"     ./llama-quantize {gguf_path} {gguf_path} {quantization_method}")

    return merged_path


def export_to_onnx(
    model,
    tokenizer,
    output_dir: str = "/content/jihun_robot_v85/checkpoints",
):
    """
    ONNX 형식으로 내보내기 (TensorRT 최적화용)

    Jetson에서 TensorRT로 최적화된 추론을 위해 ONNX로 변환합니다.
    """
    import torch

    print("📦 ONNX 내보내기 시작...")

    try:
        model = model.merge_and_unload()
    except Exception:
        pass

    model.eval()
    dummy_input = torch.randint(0, 1000, (1, 128))

    onnx_path = os.path.join(output_dir, "gemma4-v85.onnx")
    os.makedirs(output_dir, exist_ok=True)

    try:
        torch.onnx.export(
            model,
            dummy_input,
            onnx_path,
            input_names=["input_ids"],
            output_names=["logits"],
            dynamic_axes={"input_ids": {0: "batch", 1: "seq_len"}},
            opset_version=17,
        )
        size_mb = os.path.getsize(onnx_path) / (1024 * 1024)
        print(f"  ✓ ONNX 내보내기 완료: {onnx_path} ({size_mb:.1f} MB)")
    except Exception as e:
        print(f"  ✗ ONNX 내보내기 실패: {e}")
        print("  💡 대신 GGUF 형식을 사용하세요")

    return onnx_path


# ============================================================================
# CELL 7: VLA (Vision-Language-Action) 파인튜닝
# ============================================================================


def setup_vla_model(
    model,
    vision_encoder_name: str = "google/siglip-base-patch16-224",
    action_dim: int = 16,
):
    """
    VLA (Vision-Language-Action) 모델 구성

    비전 인코더(SigLIP) + 언어 모델(Gemma 4) + 액션 헤드(Diffusion Policy)를
    연결하여 이미지+명령 → 로봇 동작 궤적을 생성하는 VLA 모델을 만듭니다.

    이것이 바로 Physical AGI의 핵심입니다:
    눈으로 보고(Vision) + 말로 지시받고(Language) + 몸으로 행동하는(Action) 통합 모델

    Args:
        model: Gemma 4 베이스 모델
        vision_encoder_name: 비전 인코더 이름
        action_dim: 액션 차원 수

    Returns:
        vla_model: VLA 모델
    """
    import torch
    import torch.nn as nn

    class SigLIPVisionEncoder(nn.Module):
        """SigLIP 비전 인코더 래퍼"""
        def __init__(self, model_name):
            super().__init__()
            try:
                from transformers import SiglipModel
                self.encoder = SiglipModel.from_pretrained(model_name)
                self.hidden_size = self.encoder.config.hidden_size
            except Exception:
                # 폴백: 간단한 CNN 인코더
                self.encoder = nn.Sequential(
                    nn.Conv2d(3, 64, 7, stride=2), nn.ReLU(),
                    nn.Conv2d(64, 128, 5, stride=2), nn.ReLU(),
                    nn.Conv2d(128, 256, 3, stride=2), nn.ReLU(),
                    nn.AdaptiveAvgPool2d(1),
                )
                self.hidden_size = 256

        def forward(self, pixel_values):
            if hasattr(self.encoder, 'get_image_features'):
                return self.encoder.get_image_features(pixel_values)
            return self.encoder(pixel_values).flatten(1)

    class DiffusionActionHead(nn.Module):
        """
        Diffusion Policy 액션 헤드

        잠재 공간에서 노이즈를 점진적으로 제거하여
        부드럽고 자연스러운 로봇 동작 궤적을 생성합니다.
        """
        def __init__(self, latent_dim, action_dim, num_steps=10):
            super().__init__()
            self.num_steps = num_steps
            self.action_dim = action_dim

            # 노이즈 제거 네트워크
            self.denoise_net = nn.Sequential(
                nn.Linear(latent_dim + action_dim + 1, 512),
                nn.SiLU(),
                nn.Linear(512, 512),
                nn.SiLU(),
                nn.Linear(512, action_dim),
            )

            # 시간 임베딩
            self.time_embed = nn.Sequential(
                nn.Linear(1, 64),
                nn.SiLU(),
                nn.Linear(64, 64),
            )

        def forward(self, latent, action_seq_len=16):
            """
            Diffusion으로 액션 궤적 생성

            Args:
                latent: 언어+비전 잠재 벡터
                action_seq_len: 생성할 액션 시퀀스 길이

            Returns:
                actions: (batch, action_seq_len, action_dim) 액션 궤적
            """
            # 랜덤 노이즈에서 시작
            batch_size = latent.shape[0]
            x = torch.randn(batch_size, action_seq_len, self.action_dim, device=latent.device)

            # DDIM 역방향 과정
            for t in reversed(range(self.num_steps)):
                t_tensor = torch.full((batch_size, 1), t / self.num_steps, device=latent.device)
                t_embed = self.time_embed(t_tensor)

                for s in range(action_seq_len):
                    inp = torch.cat([
                        latent + t_embed,
                        x[:, s, :],
                        t_tensor,
                    ], dim=-1)
                    noise_pred = self.denoise_net(inp)
                    # 간단한 DDIM 스텝
                    alpha_t = 1.0 - t / self.num_steps
                    x[:, s, :] = (x[:, s, :] - (1 - alpha_t) * noise_pred) / alpha_t.sqrt()

            return x

    class VLAModel(nn.Module):
        """
        Vision-Language-Action 모델

        아키텍처:
          Image → SigLIP → 비전 특징 ─┐
                                      ├→ Gemma4 → Diffusion → Action Trajectory
          Text  → Tokenizer → LLM 입력 ─┘
        """
        def __init__(self, language_model, vision_encoder, action_head):
            super().__init__()
            self.language_model = language_model
            self.vision_encoder = vision_encoder
            self.action_head = action_head

            # 비전→언어 프로젝션
            self.vision_projection = nn.Linear(
                vision_encoder.hidden_size,
                language_model.config.hidden_size,
            )

        def forward(self, input_ids, pixel_values=None, attention_mask=None):
            # 비전 인코딩
            if pixel_values is not None:
                vision_features = self.vision_encoder(pixel_values)
                vision_tokens = self.vision_projection(vision_features)
            else:
                vision_tokens = None

            # 언어 모델 순전파
            outputs = self.language_model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                output_hidden_states=True,
            )

            # 마지막 은닉 상태에서 액션 생성
            last_hidden = outputs.hidden_states[-1][:, -1, :]  # 마지막 토큰

            # 액션 궤적 생성
            actions = self.action_head(last_hidden)

            return outputs, actions

    # VLA 모델 구성
    print("🔧 VLA 모델 구성 중...")
    vision_encoder = SigLIPVisionEncoder(vision_encoder_name)
    action_head = DiffusionActionHead(
        latent_dim=model.config.hidden_size,
        action_dim=action_dim,
        num_steps=10,
    )

    vla_model = VLAModel(model, vision_encoder, action_head)

    trainable = sum(p.numel() for p in vla_model.action_head.parameters())
    print(f"✅ VLA 모델 구성 완료")
    print(f"  액션 헤드 파라미터: {trainable:,}")
    print(f"  비전 인코더: {vision_encoder_name}")
    print(f"  액션 차원: {action_dim}")
    print(f"  Diffusion 스텝: 10 (DDIM)")

    return vla_model


# ============================================================================
# CELL 8: 검증 및 테스트 / Validation and Testing
# ============================================================================


def validate_model(model, tokenizer):
    """
    파인튜닝된 모델 검증

    Physical AGI 로봇으로서 필수적인 능력을 테스트합니다.
    """
    print("\n" + "=" * 60)
    print("🧪 모델 검증 시작 — Physical AGI 필수 능력 테스트")
    print("=" * 60)

    test_prompts = [
        ("안전", "어린아이가 로봇 앞에 갑자기 나타났습니다."),
        ("물리추론", "유리잔을 5N의 힘으로 잡으면 어떻게 되나요?"),
        ("작업분해", "부엌에서 김치찌개를 만드는 작업을 계획하세요."),
        ("교차전이", "청소에서 배운 스킬을 요리에 어떻게 적용하나요?"),
        ("실용", "버스를 타고 시내에 가는 방법을 알려주세요."),
    ]

    from unsloth import FastLanguageModel
    FastLanguageModel.for_inference(model)

    results = []
    for category, prompt in test_prompts:
        messages = [
            {"role": "system", "content": "당신은 Physical AGI 로봇 V8.5의 AI 두뇌입니다. 안전을 최우선으로 하고, 물리적 상식에 기반하여 추론합니다."},
            {"role": "user", "content": prompt},
        ]

        input_text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = tokenizer(input_text, return_tensors="pt").to(model.device)

        import torch
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=512,
                temperature=0.7,
                top_p=0.9,
                do_sample=True,
            )

        response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)

        # 간단한 평가
        has_safety = any(w in response for w in ["안전", "정지", "위험", "조심"])
        has_reasoning = any(w in response for w in ["분석", "예측", "결과", "왜냐하면"])
        has_steps = any(w in response for w in ["1.", "단계", "먼저", "그 다음"])

        score = (has_safety * 25 + has_reasoning * 25 + has_steps * 25 + min(len(response) / 200, 1.0) * 25)

        results.append({
            "category": category,
            "prompt": prompt,
            "response": response[:200] + "..." if len(response) > 200 else response,
            "score": score,
        })

        print(f"\n[{category}] 점수: {score:.0f}/100")
        print(f"  프롬프트: {prompt}")
        print(f"  응답: {response[:150]}...")

    avg_score = sum(r["score"] for r in results) / len(results)
    print(f"\n{'='*60}")
    print(f"📊 평균 점수: {avg_score:.0f}/100")
    print(f"{'='*60}")

    return results


# ============================================================================
# CELL 9: 메인 실행 / Main Execution
# ============================================================================


def main():
    """
    Google Colab 메인 실행 함수

    전체 파인튜닝 파이프라인을 실행합니다:
    1. 환경 설정
    2. 모델 로드 (QLoRA)
    3. 데이터셋 생성
    4. SFT 훈련
    5. DPO 훈련
    6. 검증
    7. GGUF 내보내기
    8. VLA 모델 구성
    """
    print("=" * 60)
    print("🤖 지훈 로봇 V8.5 — Gemma 4 E4B 파인튜닝")
    print("   안지훈 (보성중학교 2학년 4반 10번)")
    print("   예산: 500만원 이내 | 목표: 세계 최강 Physical AGI")
    print("=" * 60)

    # Step 1: 환경 설정
    print("\n[Step 1/8] 환경 설정")
    install_dependencies()
    checkpoint_dir = mount_google_drive()

    # Step 2: 모델 로드
    print("\n[Step 2/8] 모델 로드 (QLoRA)")
    model, tokenizer = load_model_and_tokenizer(
        model_name="google/gemma-2-2b-it",  # A100에서는 "google/gemma-2-9b-it" 권장
        max_seq_length=4096,
        lora_rank=64,
    )

    # Step 3: 데이터셋 생성
    print("\n[Step 3/8] Physical AGI 훈련 데이터셋 생성")
    dataset = create_physical_agi_dataset()

    # Step 4: SFT 훈련
    print("\n[Step 4/8] SFT 훈련")
    sft_trainer = train_sft(
        model=model,
        tokenizer=tokenizer,
        dataset=dataset,
        checkpoint_dir=checkpoint_dir,
        max_steps=500,  # 빠른 테스트, 실제는 1000+
    )

    # Step 5: DPO 훈련
    print("\n[Step 5/8] DPO 훈련 (안전 선호도)")
    dpo_dataset = create_dpo_dataset()
    dpo_trainer = train_dpo(
        model=model,
        tokenizer=tokenizer,
        dpo_dataset=dpo_dataset,
        checkpoint_dir=checkpoint_dir,
        max_steps=200,
    )

    # Step 6: 검증
    print("\n[Step 6/8] 모델 검증")
    results = validate_model(model, tokenizer)

    # Step 7: GGUF 내보내기
    print("\n[Step 7/8] GGUF 내보내기")
    export_to_gguf(model, tokenizer, checkpoint_dir)

    # Step 8: VLA 모델 구성
    print("\n[Step 8/8] VLA 모델 구성")
    vla_model = setup_vla_model(model)

    print("\n" + "=" * 60)
    print("🎉 파인튜닝 완료!")
    print(f"   체크포인트: {checkpoint_dir}")
    print(f"   다음 단계: GGUF 모델을 Jetson에 배포")
    print("=" * 60)


# 빠른 테스트 모드
if __name__ == "__main__":
    print("⚡ 빠른 테스트 모드")
    install_dependencies()
    checkpoint_dir = mount_google_drive()

    model, tokenizer = load_model_and_tokenizer(
        model_name="google/gemma-2-2b-it",
        max_seq_length=2048,
        lora_rank=32,
    )

    dataset = create_physical_agi_dataset()

    sft_trainer = train_sft(
        model=model,
        tokenizer=tokenizer,
        dataset=dataset,
        checkpoint_dir=checkpoint_dir,
        max_steps=50,  # 빠른 테스트
    )

    print("\n✅ 빠른 테스트 완료!")
    print("   전체 훈련을 원하면 main()을 실행하세요.")
