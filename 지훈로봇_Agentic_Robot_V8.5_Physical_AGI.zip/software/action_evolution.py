#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
action_evolution.py - 진화적 액션 탐색 모듈 / Evolutionary Action Exploration Module
=====================================================================================

Jihun Robot V8.5 — Physical AGI 핵심 모듈
Core module for Jihun Robot V8.5 — Physical AGI

NO PRESET PRIMITIVES. The AI freely discovers and evolves new actions through
evolutionary optimization, novelty search, and multi-objective selection.

프리미티브가 없다. AI가 진화적 최적화, 새로움 탐색, 다목적 선택을 통해
자유롭게 새로운 액션을 발견하고 진화시킨다.

Architecture:
    ActionGenome ─── CMAESOptimizer ─── NSGAIISelector ─── ActionEvolver
         │                │                    │                 │
    (32-dim vector)  (CMA-ES 진화)     (다목적 선택)    (메인 진화 엔진)
         │                │                    │                 │
    ActionSpaceExplorer ────────────────────────── SQLite 영속화

Key Algorithms:
    1. CMA-ES (Covariance Matrix Adaptation Evolution Strategy)
       - 연속 파라미터 공간에서 효율적인 탐색/활용 균형
       - 공분산 행렬 적응으로 탐색 분포 형태 자동 조정
       - 누적 스텝 사이즈 적응으로 수렴 속도 제어

    2. NSGA-II (Non-dominated Sorting Genetic Algorithm II)
       - 다목적 최적화: 성공률, 에너지 효율, 안정성, 정밀도, 새로움
       - 파레토 프론트 기반 선택으로 트레이드오프 해결
       - 밀집 거리로 해의 다양성 보존

    3. BLX-alpha Crossover + Gaussian Mutation
       - 유연한 유전자 재조합으로 새로운 액션 생성
       - 가우시안 돌연변이로 국소 탐색

    4. Novelty Search
       - 기존 액션과 다른 행동을 보이는 액션 탐색
       - k-최근접 이웃 평균 거리로 새로움 측정

Dependencies: numpy, dataclasses, threading, logging, uuid, time, sqlite3

Author: Jihun Robot V8.5 Team
Created: 2025
Version: V8.5.4
License: MIT
"""

from __future__ import annotations

import json
import logging
import math
import os
import sqlite3
import threading
import time
import uuid
from copy import deepcopy
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Tuple,
    Set,
)

import numpy as np

# ============================================================================
# 로깅 설정 / Logging Configuration
# ============================================================================

logger = logging.getLogger("action_evolution")
logger.setLevel(logging.DEBUG)

_formatter = logging.Formatter(
    "[%(asctime)s] %(name)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

_stream_handler = logging.StreamHandler()
_stream_handler.setLevel(logging.INFO)
_stream_handler.setFormatter(_formatter)
logger.addHandler(_stream_handler)

try:
    _log_dir = os.path.dirname(os.path.abspath(__file__))
    _file_handler = logging.FileHandler(
        os.path.join(_log_dir, "action_evolution.log")
    )
    _file_handler.setLevel(logging.DEBUG)
    _file_handler.setFormatter(_formatter)
    logger.addHandler(_file_handler)
except Exception:
    pass


# ============================================================================
# 상수 정의 / Constants
# ============================================================================

# 데이터베이스 경로 / Database path
DEFAULT_DB_PATH: str = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "action_evolution.db"
)

# 유전체 차원 / Genome dimension
DEFAULT_GENOME_DIM: int = 32

# CMA-ES 파라미터 / CMA-ES parameters
DEFAULT_POPULATION_SIZE: int = 20
DEFAULT_SIGMA: float = 0.3

# 진화 파라미터 / Evolution parameters
BLX_ALPHA: float = 0.5           # BLX-alpha 교차 확장 계수 / Crossover expansion factor
DEFAULT_MUTATION_SIGMA: float = 0.1  # 기본 돌연변이 강도 / Default mutation strength
GENOME_CLIP_MIN: float = -3.0    # 유전체 값 하한 / Genome value lower bound
GENOME_CLIP_MAX: float = 3.0     # 유전체 값 상한 / Genome value upper bound

# 적합도 키 / Fitness keys
FITNESS_KEYS: List[str] = [
    "success_rate",       # 성공률 (0~1)
    "energy_efficiency",  # 에너지 효율 (0~1, 높을수록 적은 에너지 소비)
    "stability",          # 안정성 (0~1, 균형 유지 능력)
    "precision",          # 정밀도 (0~1, 목표 대비 정확도)
    "novelty",            # 새로움 (0~1, 기존 액션과의 차이)
]

# 새로움 탐색 k-최근접 이웃 / Novelty search k-nearest neighbors
DEFAULT_NOVELTY_K: int = 15

# 유전체 → 프리미티브 디코딩 슬롯 정의 / Genome-to-primitive decoding slot definitions
# 32차원 유전체를 물리적 의미를 가진 슬롯으로 해석
# 32-dim genome interpreted as physically meaningful slots
GENOME_SLOTS: Dict[str, Tuple[int, int]] = {
    # 슬롯 이름: (시작 인덱스, 끝 인덱스) — 파이썬 슬라이싱 [start:end]
    "locomotion_vector":  (0, 6),     # 이동 벡터 (속도, 방향, 가속도, 보폭, 회전, 높이조절)
    "manipulation_vector": (6, 12),   # 조작 벡터 (접근각, 파지력, 손목회전, 손가락각도, 슬라이드, 삽입깊이)
    "posture_vector":     (12, 18),   # 자세 벡터 (COM_x, COM_y, 기울기, 다리높이, 무게이동, 안정화)
    "head_vector":        (18, 22),   # 머리 벡터 (pan, tilt, 초점거리, 스캔패턴)
    "timing_vector":      (22, 26),   # 타이밍 벡터 (지속시간, 가감속램프, 대기시간, 반복횟수)
    "composite_vector":   (26, 32),   # 복합 액션 인코딩 (순서가중치, 병렬가중치, 전이매개변수, 예비)
}


# ============================================================================
# 열거형 / Enumerations
# ============================================================================

class ActionCategory(Enum):
    """
    액션 카테고리 / Action categories.

    LOCOMOTION   - 이동 관련 동작 / Movement-related actions
    MANIPULATION - 조작 관련 동작 / Object manipulation actions
    POSTURE      - 자세 관련 동작 / Body posture actions
    HEAD         - 머리/시선 관련 동작 / Head/gaze actions
    COMPOSITE    - 복합 동작 / Composite (multi-primitive) actions
    """

    LOCOMOTION = "locomotion"
    MANIPULATION = "manipulation"
    POSTURE = "posture"
    HEAD = "head"
    COMPOSITE = "composite"


class EvolutionPhase(Enum):
    """
    진화 단계 / Evolution phase.
    초기 탐색 → 적응 → 정제 → 창조적 탐색
    """

    EXPLORE = "explore"      # 초기 랜덤 탐색 / Initial random exploration
    ADAPT = "adapt"          # 적응 — 좋은 방향으로 수렴 / Adapting toward promising regions
    REFINE = "refine"        # 정제 — 미세 조정 / Refining best solutions
    CREATE = "create"        # 창조 — 새로운 영역 탐색 / Creative exploration of new regions


# ============================================================================
# 데이터 클래스 / Data Classes
# ============================================================================

@dataclass
class ActionGenome:
    """
    프리미티브 액션의 유전체 표현 / Genome representation of a primitive action.

    액션을 32차원 연속 벡터로 인코딩하여 진화 알고리즘이 최적화할 수 있게 한다.
    Encodes an action as a 32-dimensional continuous vector, enabling optimization
    by evolutionary algorithms.

    Attributes:
        genome_id: 고유 식별자 / Unique identifier
        genome: 32차원 연속 파라미터 벡터 / 32-dim continuous parameter vector
        category: 액션 카테고리 / Action category
        fitness_scores: 다목적 적합도 점수 / Multi-objective fitness scores
        generation: 세대 번호 / Generation number
        parent_ids: 부모 유전체 ID 목록 / Parent genome IDs
        evaluation_count: 평가 횟수 / Number of evaluations
        created_at: 생성 타임스탬프 / Creation timestamp
    """

    genome_id: str = ""
    genome: np.ndarray = field(default_factory=lambda: np.zeros(DEFAULT_GENOME_DIM))
    category: ActionCategory = ActionCategory.LOCOMOTION
    fitness_scores: Dict[str, float] = field(default_factory=lambda: {k: 0.0 for k in FITNESS_KEYS})
    generation: int = 0
    parent_ids: List[str] = field(default_factory=list)
    evaluation_count: int = 0
    created_at: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        """초기화 후 검증 / Post-init validation."""
        if not self.genome_id:
            self.genome_id = f"genome_{uuid.uuid4().hex[:12]}"
        if isinstance(self.genome, (list, tuple)):
            self.genome = np.array(self.genome, dtype=np.float64)
        if self.genome.shape[0] != DEFAULT_GENOME_DIM:
            raise ValueError(
                f"유전체 차원은 {DEFAULT_GENOME_DIM}이어야 합니다 / "
                f"Genome dimension must be {DEFAULT_GENOME_DIM}, got {self.genome.shape[0]}"
            )

    def get_dominant_fitness(self) -> float:
        """
        대표 적합도 점수 (가중 합) / Dominant fitness score (weighted sum).
        다목적 점수를 단일 스칼라로 환산하여 정렬 등에 사용.
        """
        weights = {
            "success_rate": 0.30,
            "energy_efficiency": 0.20,
            "stability": 0.20,
            "precision": 0.15,
            "novelty": 0.15,
        }
        return sum(
            self.fitness_scores.get(k, 0.0) * w
            for k, w in weights.items()
        )

    def get_slot(self, slot_name: str) -> np.ndarray:
        """
        유전체 슬롯 추출 / Extract genome slot by name.

        Args:
            slot_name: GENOME_SLOTS에 정의된 슬롯 이름

        Returns:
            해당 슬롯의 유전체 부분 벡터
        """
        if slot_name not in GENOME_SLOTS:
            raise KeyError(f"알 수 없는 슬롯: {slot_name} / Unknown slot: {slot_name}")
        start, end = GENOME_SLOTS[slot_name]
        return self.genome[start:end]

    def set_slot(self, slot_name: str, values: np.ndarray) -> None:
        """
        유전체 슬롯 설정 / Set genome slot values.

        Args:
            slot_name: GENOME_SLOTS에 정의된 슬롯 이름
            values: 설정할 값 배열 (슬롯 길이와 일치해야 함)
        """
        if slot_name not in GENOME_SLOTS:
            raise KeyError(f"알 수 없는 슬롯: {slot_name} / Unknown slot: {slot_name}")
        start, end = GENOME_SLOTS[slot_name]
        expected_len = end - start
        if len(values) != expected_len:
            raise ValueError(
                f"슬롯 '{slot_name}'은(는) 길이 {expected_len}이 필요, "
                f"입력 길이 {len(values)} / "
                f"Slot '{slot_name}' requires length {expected_len}, got {len(values)}"
            )
        self.genome[start:end] = values

    def clip_genome(self) -> None:
        """유전체 값을 허용 범위로 클리핑 / Clip genome values to allowed range."""
        self.genome = np.clip(self.genome, GENOME_CLIP_MIN, GENOME_CLIP_MAX)

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary."""
        return {
            "genome_id": self.genome_id,
            "genome": self.genome.tolist(),
            "category": self.category.value,
            "fitness_scores": self.fitness_scores,
            "generation": self.generation,
            "parent_ids": self.parent_ids,
            "evaluation_count": self.evaluation_count,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ActionGenome":
        """딕셔너리에서 생성 / Create from dictionary."""
        data["category"] = ActionCategory(data["category"])
        data["genome"] = np.array(data["genome"], dtype=np.float64)
        return cls(**data)

    def summary(self) -> str:
        """유전체 요약 문자열 / Genome summary string."""
        dom = self.get_dominant_fitness()
        top3 = sorted(
            self.fitness_scores.items(), key=lambda x: x[1], reverse=True
        )[:3]
        top3_str = ", ".join(f"{k}={v:.3f}" for k, v in top3)
        return (
            f"[{self.category.value}] {self.genome_id} "
            f"gen={self.generation} dom_fitness={dom:.3f} "
            f"({top3_str}) evals={self.evaluation_count}"
        )


# ============================================================================
# CMA-ES 최적화기 / CMA-ES Optimizer
# ============================================================================

class CMAESOptimizer:
    """
    CMA-ES (Covariance Matrix Adaptation Evolution Strategy) 최적화기.
    CMA-ES optimizer for continuous action parameter optimization.

    CMA-ES는 연속 파라미터 공간에서 강력한 진화 전략이다.
    공분산 행렬을 적응시켜 탐색 분포의 형태를 자동으로 조정하고,
    누적 스텝 사이즈 적응으로 탐색-활용 균형을 제어한다.

    핵심 수식 / Core equations:
        x_k ~ N(m, sigma^2 * C)     — 샘플링 / Sampling
        m_new = sum(w_i * x_i)      — 평균 업데이트 / Mean update
        p_sigma = (1-c_sigma)*p_sigma + sqrt(c_sigma*(2-c_sigma)) * C^(-1/2) * (m_new-m)/sigma
        p_c = (1-c_c)*p_c + sqrt(c_c*(2-c_c)) * (m_new-m)/sigma
        C_new = (1-c_1-c_mu)*C + c_1*p_c*p_c^T + c_mu*sum(w_i * y_i * y_i^T)
        sigma_new = sigma * exp((||p_sigma|| - E||N(0,I)||) / (2*d_sigma*E||N(0,I)||))

    Attributes:
        genome_dim: 유전체 차원 / Genome dimension
        population_size: 모집단 크기 / Population size
        sigma: 스텝 사이즈 / Step size
        mean: 분포 평균 벡터 / Distribution mean vector
        C: 공분산 행렬 / Covariance matrix
        p_sigma: 진화 경로 (스텝 사이즈) / Evolution path (step size)
        p_c: 진화 경로 (공분산) / Evolution path (covariance)
        generation_count: 세대 카운터 / Generation counter
    """

    def __init__(
        self,
        genome_dim: int = DEFAULT_GENOME_DIM,
        population_size: int = DEFAULT_POPULATION_SIZE,
        sigma: float = DEFAULT_SIGMA,
    ) -> None:
        """
        CMA-ES 최적화기 초기화 / Initialize CMA-ES optimizer.

        Args:
            genome_dim: 유전체 차원 / Genome dimension
            population_size: 모집단 큀기 / Population size
            sigma: 초기 스텝 사이즈 / Initial step size
        """
        self.genome_dim = genome_dim
        self.population_size = population_size
        self.sigma = sigma
        self.generation_count = 0

        # ── 분포 파라미터 초기화 / Initialize distribution parameters ──
        self.mean = np.zeros(genome_dim)
        self.C = np.eye(genome_dim)              # 공분산 행렬 / Covariance matrix
        self.p_sigma = np.zeros(genome_dim)       # 스텝 사이즈 진화 경로 / Step-size evolution path
        self.p_c = np.zeros(genome_dim)           # 공분산 진화 경로 / Covariance evolution path

        # ── 적응 파라미터 계산 / Compute adaptation parameters ──
        # 모집단 크기의 절반 (부모 선택 수) / Half population size (number of parents)
        self.mu = population_size // 2

        # 재조합 가중치 / Recombination weights
        # log-rank 가중치: 더 좋은 해에 더 큰 가중치
        self.weights = self._compute_weights(self.mu)

        # 유효 선택 질량 / Effective selection mass
        self.mu_eff = 1.0 / np.sum(self.weights ** 2)

        # 스텝 사이즈 제어 파라미터 / Step-size control parameters
        n = genome_dim
        self.c_sigma = (self.mu_eff + 2.0) / (n + self.mu_eff + 5.0)
        self.d_sigma = 1.0 + 2.0 * max(0.0, math.sqrt((self.mu_eff - 1.0) / (n + 1.0)) - 1.0) + self.c_sigma

        # 공분산 행렬 적응 파라미터 / Covariance matrix adaptation parameters
        self.c_c = (4.0 + self.mu_eff / n) / (n + 4.0 + 2.0 * self.mu_eff / n)
        self.c_1 = 2.0 / ((n + 1.3) ** 2 + self.mu_eff)
        self.c_mu = min(
            1.0 - self.c_1,
            2.0 * (self.mu_eff - 2.0 + 1.0 / self.mu_eff) / ((n + 2.0) ** 2 + self.mu_eff),
        )

        # N(0,I)의 기대 노름 / Expected norm of N(0,I)
        self.expected_norm = math.sqrt(n) * (
            1.0 - 1.0 / (4.0 * n) + 1.0 / (21.0 * n ** 2)
        )

        # ── B, D 분해 (C = B * D^2 * B^T) / Eigen decomposition ──
        self.B = np.eye(n)       # 고유 벡터 행렬 / Eigenvector matrix
        self.D = np.ones(n)      # 고유값 제곱근 / Square root of eigenvalues
        self._eigen_update_count = 0

        # ── 스레드 안전성 / Thread safety ──
        self._lock = threading.Lock()

        logger.info(
            "CMA-ES 초기화 완료 / CMA-ES initialized: "
            f"dim={genome_dim}, pop={population_size}, sigma={sigma:.3f}, "
            f"mu_eff={self.mu_eff:.1f}"
        )

    @staticmethod
    def _compute_weights(mu: int) -> np.ndarray:
        """
        재조합 가중치 계산 (log-rank 가중치) / Compute recombination weights (log-rank).

        Args:
            mu: 부모 선택 수 / Number of parents

        Returns:
            정규화된 가중치 벡터 / Normalized weight vector
        """
        raw = np.array([math.log(mu + 0.5) - math.log(i + 1) for i in range(mu)])
        raw = np.maximum(raw, 0.0)  # 음수 가중치 제거 / Remove negative weights
        total = np.sum(raw)
        if total > 0:
            raw /= total
        return raw

    def _update_eigen_decomposition(self) -> None:
        """
        공분산 행렬의 고유 분해 갱신 / Update eigen decomposition of covariance matrix.

        C = B * diag(D^2) * B^T
        C^(-1/2) = B * diag(D^(-1)) * B^T
        """
        self._eigen_update_count += 1
        try:
            # 대칭 행렬 보장 / Ensure symmetry
            self.C = (self.C + self.C.T) / 2.0

            eigenvalues, eigenvectors = np.linalg.eigh(self.C)

            # 수치 안정성: 음수 고유값 보정 / Numerical stability: fix negative eigenvalues
            eigenvalues = np.maximum(eigenvalues, 1e-20)

            self.D = np.sqrt(eigenvalues)
            self.B = eigenvectors
        except np.linalg.LinAlgError as e:
            logger.warning(
                "고유 분해 실패, 공분산 행렬 재설정 / "
                "Eigen decomposition failed, resetting covariance: %s",
                e,
            )
            self.C = np.eye(self.genome_dim)
            self.B = np.eye(self.genome_dim)
            self.D = np.ones(self.genome_dim)

    def initialize_population(
        self, seed_genomes: Optional[List[ActionGenome]] = None
    ) -> List[ActionGenome]:
        """
        초기 모집단 생성 / Initialize population.

        시드 유전체가 제공되면 그 주변에 샘플링하고,
        없으면 평균 0, 단위 공분산으로 랜덤 샘플링한다.

        If seed genomes are provided, sample around them;
        otherwise, sample from N(0, sigma^2 * I).

        Args:
            seed_genomes: 선택적 시드 유전체 목록 / Optional seed genomes

        Returns:
            초기 모집단 / Initial population
        """
        with self._lock:
            if seed_genomes and len(seed_genomes) > 0:
                # 시드 유전체의 평균을 초기 분포 중심으로 사용
                # Use mean of seed genomes as initial distribution center
                seed_arrays = np.array([sg.genome for sg in seed_genomes])
                self.mean = np.mean(seed_arrays, axis=0)

                # 시드 유전체의 공분산으로 초기 공분산 추정
                # Estimate initial covariance from seed genomes
                if len(seed_genomes) > 1:
                    seed_cov = np.cov(seed_arrays.T)
                    # 충분한 샘플이 있으면 시드 공분산 사용, 아니면 합동
                    if seed_cov.shape == (self.genome_dim, self.genome_dim):
                        self.C = 0.5 * seed_cov + 0.5 * np.eye(self.genome_dim)
                        self._update_eigen_decomposition()
            else:
                self.mean = np.zeros(self.genome_dim)
                self.C = np.eye(self.genome_dim)
                self.B = np.eye(self.genome_dim)
                self.D = np.ones(self.genome_dim)

            # 모집단 샘플링 / Sample population
            population = self._sample_population()

            logger.info(
                "초기 모집단 생성: %d개 유전체 / "
                "Initial population generated: %d genomes",
                len(population), len(population),
            )
            return population

    def _sample_population(self) -> List[ActionGenome]:
        """
        현재 분포에서 모집단 샘플링 / Sample population from current distribution.

        x_k = m + sigma * B * D * z_k,  z_k ~ N(0, I)
        """
        genomes = []
        for _ in range(self.population_size):
            # 표준 정규 샘플 / Standard normal sample
            z = np.random.randn(self.genome_dim)
            # 선형 변환으로 탐색 분포에서 샘플 / Sample from search distribution
            y = self.B @ (self.D * z)
            x = self.mean + self.sigma * y

            # 클리핑 / Clipping
            x = np.clip(x, GENOME_CLIP_MIN, GENOME_CLIP_MAX)

            # 카테고리 결정 (유전체 내용 기반 휴리스틱) / Determine category heuristically
            category = self._infer_category(x)

            genome = ActionGenome(
                genome=np.array(x, dtype=np.float64),
                category=category,
                generation=self.generation_count,
                fitness_scores={k: 0.0 for k in FITNESS_KEYS},
            )
            genomes.append(genome)

        return genomes

    @staticmethod
    def _infer_category(genome: np.ndarray) -> ActionCategory:
        """
        유전체 벡터로부터 액션 카테고리 추론 / Infer action category from genome vector.

        어느 슬롯의 활성도가 가장 높은지에 따라 카테고리를 결정한다.
        Determines category based on which slot has the highest activation.

        Args:
            genome: 유전체 벡터 / Genome vector

        Returns:
            추론된 액션 카테고리 / Inferred action category
        """
        slot_norms: Dict[str, float] = {}
        for slot_name, (start, end) in GENOME_SLOTS.items():
            slot_values = genome[start:end]
            slot_norms[slot_name] = float(np.linalg.norm(slot_values))

        # 가장 활성도가 높은 슬롯 기반 카테고리 매핑
        # Category mapping based on most active slot
        slot_to_category = {
            "locomotion_vector": ActionCategory.LOCOMOTION,
            "manipulation_vector": ActionCategory.MANIPULATION,
            "posture_vector": ActionCategory.POSTURE,
            "head_vector": ActionCategory.HEAD,
            "timing_vector": ActionCategory.COMPOSITE,
            "composite_vector": ActionCategory.COMPOSITE,
        }

        max_slot = max(slot_norms, key=slot_norms.get)  # type: ignore[arg-type]
        return slot_to_category[max_slot]

    def evaluate_population(
        self,
        genomes: List[ActionGenome],
        fitness_fn: Callable[[ActionGenome], Dict[str, float]],
    ) -> List[ActionGenome]:
        """
        모집단 평가 / Evaluate population using fitness function.

        Args:
            genomes: 평가할 유전체 목록 / Genomes to evaluate
            fitness_fn: 적합도 함수 (ActionGenome → Dict[str, float]) / Fitness function

        Returns:
            평가된 유전체 목록 / Evaluated genomes with updated fitness scores
        """
        evaluated = []
        for genome in genomes:
            try:
                scores = fitness_fn(genome)
                # 적합도 점수 업데이트 / Update fitness scores
                for key in FITNESS_KEYS:
                    if key in scores:
                        genome.fitness_scores[key] = float(
                            np.clip(scores[key], 0.0, 1.0)
                        )
                genome.evaluation_count += 1
            except Exception as e:
                logger.warning(
                    "유전체 %s 평가 실패 / Genome %s evaluation failed: %s",
                    genome.genome_id, genome.genome_id, e,
                )
                # 평가 실패 시 모든 적합도 0 / Zero fitness on evaluation failure
                for key in FITNESS_KEYS:
                    genome.fitness_scores[key] = 0.0
                genome.evaluation_count += 1
            evaluated.append(genome)

        return evaluated

    def evolve_generation(
        self, evaluated: List[ActionGenome]
    ) -> List[ActionGenome]:
        """
        CMA-ES 세대 진화 / CMA-ES generation evolution step.

        평가된 모집단을 기반으로 분포 파라미터를 갱신하고
        새로운 모집단을 샘플링한다.

        Updates distribution parameters based on evaluated population
        and samples a new population.

        Args:
            evaluated: 평가된 유전체 목록 / Evaluated genomes

        Returns:
            새 세대의 유전체 목록 / New generation genomes
        """
        with self._lock:
            self.generation_count += 1
            n = self.genome_dim

            # ── 1. 선택: 적합도 기준 정렬 (내림차순) / Selection: sort by fitness ──
            sorted_pop = sorted(
                evaluated, key=lambda g: g.get_dominant_fitness(), reverse=True
            )

            # 상위 mu개 선택 / Select top mu
            selected = sorted_pop[: self.mu]

            # ── 2. 평균 업데이트 / Mean update ──
            old_mean = self.mean.copy()
            selected_arrays = np.array([s.genome for s in selected])
            self.mean = np.sum(
                self.weights[:, np.newaxis] * selected_arrays, axis=0
            )

            # ── 3. 스텝 사이즈 진화 경로 업데이트 / Step-size evolution path update ──
            # C^(-1/2) = B * diag(D^(-1)) * B^T
            C_inv_sqrt = self.B @ np.diag(1.0 / self.D) @ self.B.T
            mean_diff = (self.mean - old_mean) / self.sigma

            self.p_sigma = (1.0 - self.c_sigma) * self.p_sigma + math.sqrt(
                self.c_sigma * (2.0 - self.c_sigma) * self.mu_eff
            ) * (C_inv_sqrt @ mean_diff)

            # ── 4. 스텝 사이즈 적응 / Step-size adaptation ──
            p_sigma_norm = np.linalg.norm(self.p_sigma)
            self.sigma = self.sigma * math.exp(
                (self.c_sigma / self.d_sigma)
                * (p_sigma_norm / self.expected_norm - 1.0)
            )

            # 스텝 사이즈 경계 / Step-size bounds
            self.sigma = np.clip(self.sigma, 1e-20, 1e2)

            # ── 5. 공분산 진화 경로 업데이트 / Covariance evolution path update ──
            # h_sigma: 스텝 사이즈가 너무 커진 경우 공분산 경로 업데이트 억제
            # h_sigma: suppress covariance path update if step size grew too large
            h_sigma = float(
                p_sigma_norm
                / math.sqrt(
                    1.0 - (1.0 - self.c_sigma) ** (2.0 * (self.generation_count + 1))
                )
                < (1.4 + 2.0 / (n + 1.0)) * self.expected_norm
            )

            self.p_c = (1.0 - self.c_c) * self.p_c + h_sigma * math.sqrt(
                self.c_c * (2.0 - self.c_c) * self.mu_eff
            ) * mean_diff

            # ── 6. 공분산 행렬 적응 / Covariance matrix adaptation ──
            # 랭크-1 업데이트 / Rank-1 update
            rank1_update = self.c_1 * np.outer(self.p_c, self.p_c)

            # 랭크-mu 업데이트 / Rank-mu update
            rank_mu_update = np.zeros((n, n))
            for i, sel in enumerate(selected):
                y_i = (sel.genome - old_mean) / self.sigma
                rank_mu_update += self.weights[i] * np.outer(y_i, y_i)
            rank_mu_update *= self.c_mu

            # (1-c_1-c_mu) 항에 h_sigma 적용 / Apply h_sigma to (1-c_1-c_mu) term
            delta_h = (1.0 - h_sigma) * self.c_c * (2.0 - self.c_c)
            self.C = (
                (1.0 - self.c_1 - self.c_mu + self.c_1 * delta_h) * self.C
                + rank1_update
                + rank_mu_update
            )

            # ── 7. 고유 분해 갱신 (주기적) / Update eigen decomposition (periodic) ──
            if self._eigen_update_count == 0 or self.generation_count % max(1, n // 10) == 0:
                self._update_eigen_decomposition()

            # ── 8. 새 모집단 샘플링 / Sample new population ──
            new_population = self._sample_population()

            # 부모 ID 기록 / Record parent IDs
            parent_ids = [s.genome_id for s in selected]
            for genome in new_population:
                genome.parent_ids = parent_ids
                genome.generation = self.generation_count

            logger.info(
                "CMA-ES 세대 %d 진화 완료: sigma=%.4f, "
                "최고 적합도=%.3f / "
                "CMA-ES generation %d evolved: sigma=%.4f, "
                "best_fitness=%.3f",
                self.generation_count, self.sigma,
                sorted_pop[0].get_dominant_fitness() if sorted_pop else 0.0,
                self.generation_count, self.sigma,
                sorted_pop[0].get_dominant_fitness() if sorted_pop else 0.0,
            )

            return new_population

    def get_state(self) -> Dict[str, Any]:
        """
        CMA-ES 내부 상태 반환 / Return CMA-ES internal state.

        영속화 및 상태 검사에 사용.
        Used for persistence and state inspection.
        """
        return {
            "generation_count": self.generation_count,
            "mean": self.mean.tolist(),
            "sigma": float(self.sigma),
            "C": self.C.tolist(),
            "p_sigma": self.p_sigma.tolist(),
            "p_c": self.p_c.tolist(),
            "genome_dim": self.genome_dim,
            "population_size": self.population_size,
        }

    def set_state(self, state: Dict[str, Any]) -> None:
        """
        CMA-ES 내부 상태 복원 / Restore CMA-ES internal state.

        Args:
            state: 이전에 get_state()로 얻은 상태 딕셔너리
        """
        with self._lock:
            self.generation_count = state["generation_count"]
            self.mean = np.array(state["mean"], dtype=np.float64)
            self.sigma = float(state["sigma"])
            self.C = np.array(state["C"], dtype=np.float64)
            self.p_sigma = np.array(state["p_sigma"], dtype=np.float64)
            self.p_c = np.array(state["p_c"], dtype=np.float64)
            self._update_eigen_decomposition()
            logger.info(
                "CMA-ES 상태 복원: 세대 %d, sigma=%.4f / "
                "CMA-ES state restored: generation %d, sigma=%.4f",
                self.generation_count, self.sigma,
                self.generation_count, self.sigma,
            )


# ============================================================================
# NSGA-II 선택기 / NSGA-II Selector
# ============================================================================

class NSGAIISelector:
    """
    NSGA-II (Non-dominated Sorting Genetic Algorithm II) 다목적 선택기.
    NSGA-II multi-objective selector.

    다목적 최적화에서 파레토 프론트 기반 선택으로
    성공률, 에너지 효율, 안정성, 정밀도, 새로움 간의
    트레이드오프를 관리한다.

    Manages tradeoffs between success_rate, energy_efficiency,
    stability, precision, and novelty through Pareto-front-based selection.

    핵심 알고리즘 / Core algorithm:
        1. 비지배 정렬: 파레토 프론트 분해 / Non-dominated sorting
        2. 밀집 거리 계산: 해의 다양성 보존 / Crowding distance
        3. 선택: 랭크 → 밀집 거리 순위 / Rank then crowding distance
    """

    def __init__(self, fitness_keys: Optional[List[str]] = None) -> None:
        """
        NSGA-II 선택기 초기화 / Initialize NSGA-II selector.

        Args:
            fitness_keys: 최적화할 적합도 키 목록 / Fitness keys to optimize
        """
        self.fitness_keys = fitness_keys or FITNESS_KEYS
        self._lock = threading.Lock()
        logger.info(
            "NSGA-II 선택기 초기화: %d개 목적 / "
            "NSGA-II selector initialized: %d objectives",
            len(self.fitness_keys), len(self.fitness_keys),
        )

    def non_dominated_sort(
        self, genomes: List[ActionGenome]
    ) -> List[List[ActionGenome]]:
        """
        비지배 정렬 / Non-dominated sorting.

        모든 유전체를 파레토 프론트로 분해한다.
        프론트 1이 최상위 파레토 프론트 (어떤 해에게도 지배되지 않음).

        Decomposes all genomes into Pareto fronts.
        Front 1 is the top-level Pareto front (not dominated by any solution).

        Args:
            genomes: 정렬할 유전체 목록 / Genomes to sort

        Returns:
            파레토 프론트 목록 (프론트 1, 2, 3, ...) / List of Pareto fronts
        """
        if not genomes:
            return []

        n = len(genomes)

        # 지배 관계 계산 / Compute domination relationships
        # domination_count[i]: i를 지배하는 해의 수 / Number of solutions dominating i
        # dominated_set[i]: i가 지배하는 해의 집합 / Set of solutions dominated by i
        domination_count = np.zeros(n, dtype=int)
        dominated_set: List[Set[int]] = [set() for _ in range(n)]

        for i in range(n):
            for j in range(i + 1, n):
                if self._dominates(genomes[i], genomes[j]):
                    # i가 j를 지배 / i dominates j
                    dominated_set[i].add(j)
                    domination_count[j] += 1
                elif self._dominates(genomes[j], genomes[i]):
                    # j가 i를 지배 / j dominates i
                    dominated_set[j].add(i)
                    domination_count[i] += 1

        # 프론트 분해 / Front decomposition
        fronts: List[List[ActionGenome]] = []
        remaining = set(range(n))

        while remaining:
            # 현재 프론트: 지배 횟수가 0인 해들 / Current front: solutions with 0 domination count
            current_front_indices = [
                i for i in remaining if domination_count[i] == 0
            ]

            if not current_front_indices:
                # 안전장치: 지배 횟수가 모두 > 0이면 남은 해 모두 추가
                # Safety: if all remaining have domination_count > 0, add all
                current_front_indices = list(remaining)

            current_front = [genomes[i] for i in current_front_indices]
            fronts.append(current_front)

            # 다음 프론트를 위해 지배 횟수 감소 / Reduce domination counts for next front
            for i in current_front_indices:
                for j in dominated_set[i]:
                    domination_count[j] -= 1

            remaining -= set(current_front_indices)

        return fronts

    def _dominates(self, a: ActionGenome, b: ActionGenome) -> bool:
        """
        a가 b를 지배하는지 판별 / Check if a dominates b.

        a가 b를 지배한다 = a의 모든 목적이 b보다 크거나 같고,
        적어도 하나의 목적은 엄격히 크다.

        a dominates b = a is >= b in all objectives
        and strictly > in at least one objective.

        모든 적합도는 최대화 (0~1, 높을수록 좋음).
        All fitnesses are maximized (0~1, higher is better).
        """
        a_at_least_as_good = True
        a_strictly_better = False

        for key in self.fitness_keys:
            a_val = a.fitness_scores.get(key, 0.0)
            b_val = b.fitness_scores.get(key, 0.0)

            if a_val < b_val:
                a_at_least_as_good = False
                break
            if a_val > b_val:
                a_strictly_better = True

        return a_at_least_as_good and a_strictly_better

    def crowding_distance(self, front: List[ActionGenome]) -> List[float]:
        """
        밀집 거리 계산 / Compute crowding distance for a front.

        각 해의 주변 빈 공간을 측정하여 해의 다양성을 보존한다.
        동일한 프론트 내에서 밀집 거리가 큰 해를 우선 선택하면
        해가 고르게 퍼지게 된다.

        Measures the empty space around each solution to preserve diversity.
        Selecting solutions with larger crowding distance within the same front
        leads to evenly spread solutions.

        Args:
            front: 파레토 프론트 / Pareto front

        Returns:
            각 해의 밀집 거리 / Crowding distance for each solution
        """
        n = len(front)
        if n <= 2:
            # 경계 해는 무한대 밀집 거리 / Boundary solutions get infinite distance
            return [float("inf")] * n

        distances = np.zeros(n)

        for key in self.fitness_keys:
            # 해당 목적 기준 정렬 / Sort by this objective
            values = np.array([g.fitness_scores.get(key, 0.0) for g in front])
            sorted_indices = np.argsort(values)

            # 목적 값 범위 / Objective value range
            value_range = values[sorted_indices[-1]] - values[sorted_indices[0]]
            if value_range < 1e-12:
                continue  # 모든 값이 동일 / All values identical

            # 경계 해: 무한대 거리 / Boundary solutions: infinite distance
            distances[sorted_indices[0]] = float("inf")
            distances[sorted_indices[-1]] = float("inf")

            # 내부 해: 인접 해와의 거리 합 / Interior solutions: sum of neighbor distances
            for i in range(1, n - 1):
                idx = sorted_indices[i]
                idx_prev = sorted_indices[i - 1]
                idx_next = sorted_indices[i + 1]
                distances[idx] += (values[idx_next] - values[idx_prev]) / value_range

        return distances.tolist()

    def select(
        self, genomes: List[ActionGenome], n_select: int
    ) -> List[ActionGenome]:
        """
        NSGA-II 선택 / NSGA-II selection.

        비지배 정렬 → 밀집 거리 기반 선택을 통해
        n_select개의 해를 선택한다.

        Selects n_select solutions through non-dominated sorting
        then crowding-distance-based selection.

        Args:
            genomes: 후보 유전체 목록 / Candidate genomes
            n_select: 선택할 해의 수 / Number of solutions to select

        Returns:
            선택된 유전체 목록 / Selected genomes
        """
        with self._lock:
            if n_select >= len(genomes):
                return list(genomes)

            fronts = self.non_dominated_sort(genomes)
            selected: List[ActionGenome] = []

            for front in fronts:
                if len(selected) + len(front) <= n_select:
                    # 전체 프론트 추가 / Add entire front
                    selected.extend(front)
                else:
                    # 부분적으로 프론트에서 선택 / Partially select from front
                    remaining_slots = n_select - len(selected)
                    distances = self.crowding_distance(front)

                    # 밀집 거리 내림차순 정렬 / Sort by crowding distance descending
                    front_with_dist = list(zip(front, distances))
                    front_with_dist.sort(key=lambda x: x[1], reverse=True)

                    for genome, _ in front_with_dist[:remaining_slots]:
                        selected.append(genome)
                    break

            logger.debug(
                "NSGA-II 선택: %d개 후보에서 %d개 선택 / "
                "NSGA-II selection: %d selected from %d candidates",
                len(genomes), len(selected),
                len(selected), len(genomes),
            )
            return selected


# ============================================================================
# 액션 진화 엔진 / Action Evolution Engine
# ============================================================================

class ActionEvolver:
    """
    진화적 액션 탐색 메인 엔진 / Main evolutionary action exploration engine.

    CMA-ES 최적화, NSGA-II 선택, BLX-alpha 교차, 가우시안 돌연변이를
    통합하여 로봇이 자유롭게 새로운 액션을 발견하고 진화시킨다.

    Integrates CMA-ES optimization, NSGA-II selection, BLX-alpha crossover,
    and Gaussian mutation for the robot to freely discover and evolve new actions.

    NO PRESET PRIMITIVES — 모든 액션은 진화를 통해 발견된다.
    NO PRESET PRIMITIVES — All actions are discovered through evolution.

    Usage:
        evolver = ActionEvolver(genome_dim=32)
        # 새 액션 발견 / Discover new actions
        new_actions = evolver.discover_new_actions(ActionCategory.MANIPULATION, n_actions=5)
        # 기존 액션 최적화 / Optimize existing action
        optimized = evolver.optimize_action(my_action, "success_rate")
        # 파레토 프론트 조회 / Get Pareto front
        front = evolver.get_pareto_front(ActionCategory.LOCOMOTION)
    """

    def __init__(
        self,
        genome_dim: int = DEFAULT_GENOME_DIM,
        db_path: str = DEFAULT_DB_PATH,
    ) -> None:
        """
        액션 진화 엔진 초기화 / Initialize action evolution engine.

        Args:
            genome_dim: 유전체 차원 / Genome dimension
            db_path: SQLite 데이터베이스 경로 / SQLite database path
        """
        self.genome_dim = genome_dim
        self._db_path = db_path

        # ── 진화 컴포넌트 / Evolution components ──
        self._cmaes = CMAESOptimizer(genome_dim=genome_dim)
        self._nsga2 = NSGAIISelector()

        # ── 유전체 아카이브 / Genome archive ──
        self._archive: Dict[str, ActionGenome] = {}
        self._category_index: Dict[ActionCategory, List[str]] = {
            cat: [] for cat in ActionCategory
        }

        # ── 진화 상태 / Evolution state ──
        self._phase = EvolutionPhase.EXPLORE
        self._total_generations = 0
        self._total_evaluations = 0

        # ── 스레드 안전성 / Thread safety ──
        self._lock = threading.RLock()

        # ── 데이터베이스 초기화 / Initialize database ──
        self._init_database()

        # ── DB에서 기존 아카이브 로드 / Load existing archive from DB ──
        self._load_archive()

        logger.info(
            "ActionEvolver 초기화 완료: dim=%d, 아카이브=%d개 / "
            "ActionEvolver initialized: dim=%d, archive=%d genomes",
            genome_dim, len(self._archive),
            genome_dim, len(self._archive),
        )

    # ── 데이터베이스 / Database ──

    def _init_database(self) -> None:
        """SQLite 데이터베이스 초기화 / Initialize SQLite database."""
        try:
            db_dir = os.path.dirname(self._db_path)
            if db_dir:
                os.makedirs(db_dir, exist_ok=True)

            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()

            # 유전체 아카이브 테이블 / Genome archive table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS action_genomes (
                    genome_id TEXT PRIMARY KEY,
                    genome_json TEXT NOT NULL,
                    category TEXT NOT NULL,
                    fitness_success_rate REAL DEFAULT 0,
                    fitness_energy_efficiency REAL DEFAULT 0,
                    fitness_stability REAL DEFAULT 0,
                    fitness_precision REAL DEFAULT 0,
                    fitness_novelty REAL DEFAULT 0,
                    generation INTEGER DEFAULT 0,
                    parent_ids_json TEXT DEFAULT '[]',
                    evaluation_count INTEGER DEFAULT 0,
                    created_at REAL DEFAULT 0
                )
            """)

            # 진화 상태 테이블 / Evolution state table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS evolution_state (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL
                )
            """)

            # CMA-ES 상태 테이블 / CMA-ES state table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS cmaes_state (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    state_json TEXT NOT NULL,
                    updated_at REAL DEFAULT 0
                )
            """)

            # 인덱스 / Indexes
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_genomes_category
                ON action_genomes(category)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_genomes_generation
                ON action_genomes(generation)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_genomes_novelty
                ON action_genomes(fitness_novelty DESC)
            """)

            conn.commit()
            conn.close()
            logger.info("데이터베이스 초기화 완료 / Database initialized")
        except Exception as e:
            logger.warning("데이터베이스 초기화 실패: %s / DB init failed: %s", e, e)

    def _persist_genome(self, genome: ActionGenome) -> None:
        """유전체를 DB에 저장 / Persist genome to database."""
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT OR REPLACE INTO action_genomes
                (genome_id, genome_json, category,
                 fitness_success_rate, fitness_energy_efficiency,
                 fitness_stability, fitness_precision, fitness_novelty,
                 generation, parent_ids_json, evaluation_count, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    genome.genome_id,
                    json.dumps(genome.genome.tolist()),
                    genome.category.value,
                    genome.fitness_scores.get("success_rate", 0.0),
                    genome.fitness_scores.get("energy_efficiency", 0.0),
                    genome.fitness_scores.get("stability", 0.0),
                    genome.fitness_scores.get("precision", 0.0),
                    genome.fitness_scores.get("novelty", 0.0),
                    genome.generation,
                    json.dumps(genome.parent_ids),
                    genome.evaluation_count,
                    genome.created_at,
                ),
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug("DB 저장 실패: %s / DB persist failed: %s", e, e)

    def _load_archive(self) -> None:
        """DB에서 아카이브 로드 / Load archive from database."""
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT genome_json FROM action_genomes")
            rows = cursor.fetchall()
            conn.close()

            for (genome_json,) in rows:
                try:
                    data = json.loads(genome_json)
                    # 간단한 복원 / Simple restore
                    genome = ActionGenome(
                        genome_id=data.get("genome_id", ""),
                        genome=np.array(data.get("genome", []), dtype=np.float64),
                        category=ActionCategory(data.get("category", "locomotion")),
                        fitness_scores=data.get("fitness_scores", {k: 0.0 for k in FITNESS_KEYS}),
                        generation=data.get("generation", 0),
                        parent_ids=data.get("parent_ids", []),
                        evaluation_count=data.get("evaluation_count", 0),
                        created_at=data.get("created_at", 0.0),
                    )
                    self._archive[genome.genome_id] = genome
                    self._category_index[genome.category].append(genome.genome_id)
                except Exception as e:
                    logger.debug("유전체 로드 실패: %s / Genome load failed: %s", e, e)

            if self._archive:
                logger.info(
                    "아카이브 %d개 로드 완료 / Loaded %d genomes from archive",
                    len(self._archive), len(self._archive),
                )
        except Exception as e:
            logger.debug("아카이브 로드 실패: %s / Archive load failed: %s", e, e)

    def _persist_cmaes_state(self) -> None:
        """CMA-ES 상태를 DB에 저장 / Persist CMA-ES state to database."""
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            state = self._cmaes.get_state()
            cursor.execute(
                """
                INSERT OR REPLACE INTO cmaes_state (id, state_json, updated_at)
                VALUES (1, ?, ?)
                """,
                (json.dumps(state), time.time()),
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug("CMA-ES 상태 저장 실패: %s / CMA-ES state persist failed: %s", e, e)

    # ── 핵심 진화 기능 / Core Evolution Functions ──

    def discover_new_actions(
        self,
        category: ActionCategory,
        n_actions: int,
        fitness_fn: Optional[Callable[[ActionGenome], Dict[str, float]]] = None,
        n_generations: int = 10,
    ) -> List[ActionGenome]:
        """
        완전히 새로운 액션 발견 / Discover entirely new actions.

        CMA-ES를 사용하여 지정된 카테고리에서 새로운 액션을 진화시킨다.
        기본 적합도 함수가 제공되지 않으면 아카이브 기반 새로움 점수와
        랜덤 탐험 점수를 사용한다.

        Uses CMA-ES to evolve new actions in the specified category.
        If no fitness function is provided, uses archive-based novelty
        and random exploration scores.

        Args:
            category: 탐색할 액션 카테고리 / Action category to explore
            n_actions: 발견할 액션 수 / Number of actions to discover
            fitness_fn: 선택적 적합도 함수 / Optional fitness function
            n_generations: 진화 세대 수 / Number of evolution generations

        Returns:
            발견된 새 액션 목록 / List of discovered new actions
        """
        with self._lock:
            logger.info(
                "새 액션 발견 시작: 카테고리=%s, 목표=%d개, 세대=%d / "
                "Discovering new actions: category=%s, target=%d, generations=%d",
                category.value, n_actions, n_generations,
                category.value, n_actions, n_generations,
            )

            # 카테고리 시드 유전체 수집 / Collect category seed genomes
            seed_ids = self._category_index.get(category, [])
            seed_genomes = [
                self._archive[sid]
                for sid in seed_ids
                if sid in self._archive
            ]

            # CMA-ES 초기화 / Initialize CMA-ES
            self._cmaes = CMAESOptimizer(
                genome_dim=self.genome_dim,
                population_size=DEFAULT_POPULATION_SIZE,
                sigma=DEFAULT_SIGMA,
            )
            population = self._cmaes.initialize_population(seed_genomes if seed_genomes else None)

            # 카테고리 강제 설정 / Force category assignment
            for genome in population:
                genome.category = category

            # 기본 적합도 함수 / Default fitness function
            if fitness_fn is None:
                fitness_fn = self._default_fitness_fn

            # 진화 루프 / Evolution loop
            for gen in range(n_generations):
                # 평가 / Evaluate
                evaluated = self._cmaes.evaluate_population(population, fitness_fn)

                # 아카이브에 추가 / Add to archive
                for genome in evaluated:
                    self._add_to_archive(genome)

                self._total_evaluations += len(evaluated)

                # 진화 / Evolve
                population = self._cmaes.evolve_generation(evaluated)

                # 카테고리 유지 / Maintain category
                for genome in population:
                    genome.category = category

                self._total_generations += 1

            # 최종 평가 / Final evaluation
            final_evaluated = self._cmaes.evaluate_population(population, fitness_fn)
            for genome in final_evaluated:
                self._add_to_archive(genome)

            # NSGA-II로 최종 선택 / Final NSGA-II selection
            all_category_genomes = [
                self._archive[sid]
                for sid in self._category_index.get(category, [])
                if sid in self._archive
            ]
            selected = self._nsga2.select(all_category_genomes, n_actions)

            # CMA-ES 상태 저장 / Save CMA-ES state
            self._persist_cmaes_state()

            # 진화 단계 갱신 / Update evolution phase
            self._update_phase()

            logger.info(
                "새 액션 발견 완료: %d개 / Discovered %d new actions",
                len(selected), len(selected),
            )
            return selected

    def optimize_action(
        self,
        action: ActionGenome,
        objective: str,
        fitness_fn: Optional[Callable[[ActionGenome], Dict[str, float]]] = None,
        n_generations: int = 15,
    ) -> ActionGenome:
        """
        특정 목적에 대해 액션 최적화 / Optimize action for a specific objective.

        주어진 액션을 시작점으로 CMA-ES를 사용하여 특정 목적
        (예: success_rate, energy_efficiency)을 최적화한다.

        Uses CMA-ES starting from the given action to optimize for
        a specific objective (e.g., success_rate, energy_efficiency).

        Args:
            action: 최적화할 액션 / Action to optimize
            objective: 최적화 목적 키 / Objective key to optimize
            fitness_fn: 선택적 적합도 함수 / Optional fitness function
            n_generations: 진화 세대 수 / Number of generations

        Returns:
            최적화된 액션 / Optimized action
        """
        with self._lock:
            if objective not in FITNESS_KEYS:
                raise ValueError(
                    f"알 수 없는 목적: {objective}. 가능한 목적: {FITNESS_KEYS} / "
                    f"Unknown objective: {objective}. Valid: {FITNESS_KEYS}"
                )

            logger.info(
                "액션 최적화 시작: %s → %s / "
                "Optimizing action: %s for %s",
                action.genome_id, objective,
                action.genome_id, objective,
            )

            # 액션을 시드로 CMA-ES 초기화 / Initialize CMA-ES with action as seed
            self._cmaes = CMAESOptimizer(
                genome_dim=self.genome_dim,
                population_size=DEFAULT_POPULATION_SIZE,
                sigma=DEFAULT_SIGMA * 0.5,  # 더 작은 초기 스텝 / Smaller initial step
            )
            population = self._cmaes.initialize_population([action])

            # 목적 특화 적합도 함수 / Objective-specific fitness function
            if fitness_fn is None:
                fitness_fn = self._default_fitness_fn

            def objective_biased_fitness(genome: ActionGenome) -> Dict[str, float]:
                """목적 가중 적합도 / Objective-biased fitness."""
                scores = fitness_fn(genome)
                # 목적 키에 추가 가중치 / Extra weight on target objective
                scores[objective] = min(1.0, scores.get(objective, 0.0) * 1.5)
                return scores

            # 진화 루프 / Evolution loop
            best = action
            for gen in range(n_generations):
                evaluated = self._cmaes.evaluate_population(
                    population, objective_biased_fitness
                )
                for genome in evaluated:
                    self._add_to_archive(genome)

                self._total_evaluations += len(evaluated)

                # 최고 해 추적 / Track best solution
                gen_best = max(evaluated, key=lambda g: g.fitness_scores.get(objective, 0.0))
                if gen_best.fitness_scores.get(objective, 0.0) > best.fitness_scores.get(objective, 0.0):
                    best = gen_best

                population = self._cmaes.evolve_generation(evaluated)
                for genome in population:
                    genome.category = action.category
                self._total_generations += 1

            # 최종 평가 / Final evaluation
            final_evaluated = self._cmaes.evaluate_population(population, objective_biased_fitness)
            for genome in final_evaluated:
                self._add_to_archive(genome)

            # 최종 최고 해 / Final best
            final_best = max(final_evaluated, key=lambda g: g.fitness_scores.get(objective, 0.0))
            if final_best.fitness_scores.get(objective, 0.0) > best.fitness_scores.get(objective, 0.0):
                best = final_best

            self._persist_cmaes_state()
            self._update_phase()

            logger.info(
                "액션 최적화 완료: %s → %s=%.3f / "
                "Action optimized: %s, %s=%.3f",
                action.genome_id, objective,
                best.fitness_scores.get(objective, 0.0),
                best.genome_id, objective,
                best.fitness_scores.get(objective, 0.0),
            )
            return best

    def crossover(
        self,
        parent_a: ActionGenome,
        parent_b: ActionGenome,
        alpha: float = BLX_ALPHA,
    ) -> ActionGenome:
        """
        BLX-alpha 교차 / BLX-alpha crossover.

        각 유전자에 대해 [min(a,b) - alpha*d, max(a,b) + alpha*d] 구간에서
        균일 샘플링한다. d = |a - b|.

        For each gene, samples uniformly from
        [min(a,b) - alpha*d, max(a,b) + alpha*d]
        where d = |a - b|.

        alpha = 0.5 (기본값)은 부모 범위를 50% 확장하여 탐색 다양성 확보.
        alpha = 0.5 (default) extends the parent range by 50% for diversity.

        Args:
            parent_a: 부모 A / Parent A
            parent_b: 부모 B / Parent B
            alpha: BLX 확장 계수 / BLX expansion factor

        Returns:
            자식 유전체 / Child genome
        """
        a_genes = parent_a.genome
        b_genes = parent_b.genome

        # 각 유전자에 대해 BLX-alpha 구간 계산 / Compute BLX-alpha interval per gene
        gene_min = np.minimum(a_genes, b_genes)
        gene_max = np.maximum(a_genes, b_genes)
        delta = gene_max - gene_min

        # 확장 구간 / Extended interval
        lower = gene_min - alpha * delta
        upper = gene_max + alpha * delta

        # 균일 샘플링 / Uniform sampling
        child_genome = np.random.uniform(lower, upper)
        child_genome = np.clip(child_genome, GENOME_CLIP_MIN, GENOME_CLIP_MAX)

        # 카테고리: 부모 중 더 높은 적합도의 카테고리 / Category from fitter parent
        if parent_a.get_dominant_fitness() >= parent_b.get_dominant_fitness():
            child_category = parent_a.category
        else:
            child_category = parent_b.category

        child = ActionGenome(
            genome=child_genome,
            category=child_category,
            fitness_scores={k: 0.0 for k in FITNESS_KEYS},
            generation=max(parent_a.generation, parent_b.generation) + 1,
            parent_ids=[parent_a.genome_id, parent_b.genome_id],
            evaluation_count=0,
        )

        logger.debug(
            "BLX-alpha 교차: %s + %s → %s / "
            "BLX-alpha crossover: %s + %s → %s",
            parent_a.genome_id, parent_b.genome_id, child.genome_id,
            parent_a.genome_id, parent_b.genome_id, child.genome_id,
        )
        return child

    def mutate(
        self, genome: ActionGenome, sigma: float = DEFAULT_MUTATION_SIGMA
    ) -> ActionGenome:
        """
        가우시안 돌연변이 / Gaussian mutation.

        각 유전자에 N(0, sigma^2) 노이즈를 추가한다.
        Adds N(0, sigma^2) noise to each gene.

        Args:
            genome: 돌연변이시킬 유전체 / Genome to mutate
            sigma: 돌연변이 강도 / Mutation strength

        Returns:
            돌연변이된 유전체 / Mutated genome
        """
        noise = np.random.randn(self.genome_dim) * sigma
        new_genes = genome.genome + noise
        new_genes = np.clip(new_genes, GENOME_CLIP_MIN, GENOME_CLIP_MAX)

        mutated = ActionGenome(
            genome=new_genes,
            category=genome.category,
            fitness_scores={k: 0.0 for k in FITNESS_KEYS},
            generation=genome.generation + 1,
            parent_ids=[genome.genome_id],
            evaluation_count=0,
        )

        logger.debug(
            "가우시안 돌연변이: %s → %s (sigma=%.3f) / "
            "Gaussian mutation: %s → %s (sigma=%.3f)",
            genome.genome_id, mutated.genome_id, sigma,
            genome.genome_id, mutated.genome_id, sigma,
        )
        return mutated

    def decode_to_primitive(self, genome: ActionGenome) -> Dict[str, Any]:
        """
        유전체를 실행 가능한 프리미티브 액션 파라미터로 디코딩 /
        Decode genome to executable primitive action parameters.

        32차원 연속 벡터를 물리적으로 의미 있는 파라미터로 변환한다.
        Converts the 32-dim continuous vector to physically meaningful parameters.

        Genome Slot Layout (32-dim):
            [0:6]   locomotion  — speed, direction, acceleration, stride, turn_rate, height_adj
            [6:12]  manipulation — approach_angle, grip_force, wrist_yaw, finger_angle, slide_dir, insert_depth
            [12:18] posture     — com_x, com_y, tilt, leg_height, weight_shift, stabilize_gain
            [18:22] head        — pan, tilt, focus_dist, scan_pattern
            [22:26] timing      — duration, ramp, wait, reps
            [26:32] composite   — seq_weights(3), parallel_weights(3)

        Args:
            genome: 디코딩할 유전체 / Genome to decode

        Returns:
            실행 가능한 프리미티브 액션 파라미터 딕셔너리 / Executable primitive action parameters dict
        """
        g = genome.genome

        # ── 이동 파라미터 / Locomotion parameters ──
        loco = g[0:6]
        locomotion = {
            "speed": float(np.clip(loco[0] * 0.3, 0.0, 2.0)),         # m/s (0~2)
            "direction": float(loco[1] * 30.0),                         # degrees (-90~90)
            "acceleration": float(np.clip(loco[2] * 0.5, -1.0, 1.0)),  # m/s^2
            "stride_length": float(np.clip(loco[3] * 0.1, 0.02, 0.5)), # meters
            "turn_rate": float(loco[4] * 30.0),                         # deg/s
            "height_adjustment": float(np.clip(loco[5] * 0.05, -0.15, 0.15)),  # meters
        }

        # ── 조작 파라미터 / Manipulation parameters ──
        manip = g[6:12]
        manipulation = {
            "approach_angle": float(np.clip(manip[0] * 30.0, -90.0, 90.0)),  # degrees
            "grip_force": float(np.clip(manip[1] * 2.0 + 3.0, 0.5, 15.0)),  # Newtons
            "wrist_yaw": float(np.clip(manip[2] * 45.0, -90.0, 90.0)),      # degrees
            "finger_angle": float(np.clip(manip[3] * 30.0 + 45.0, 0.0, 90.0)),  # degrees
            "slide_direction": float(manip[4] * 180.0),                       # degrees
            "insert_depth": float(np.clip(manip[5] * 0.03, 0.0, 0.1)),       # meters
        }

        # ── 자세 파라미터 / Posture parameters ──
        post = g[12:18]
        posture = {
            "com_x": float(np.clip(post[0] * 0.1, -0.3, 0.3)),        # meters offset
            "com_y": float(np.clip(post[1] * 0.1, -0.3, 0.3)),        # meters offset
            "body_tilt": float(np.clip(post[2] * 15.0, -30.0, 30.0)), # degrees
            "leg_height": float(np.clip(post[3] * 0.05 + 0.2, 0.05, 0.4)),  # meters
            "weight_shift": float(np.clip(post[4] * 0.3, -0.5, 0.5)), # ratio
            "stabilize_gain": float(np.clip(post[5] * 0.3 + 0.5, 0.1, 1.0)),  # Kp
        }

        # ── 머리 파라미터 / Head parameters ──
        head = g[18:22]
        head_params = {
            "pan": float(np.clip(head[0] * 45.0, -90.0, 90.0)),       # degrees
            "tilt": float(np.clip(head[1] * 30.0, -60.0, 60.0)),      # degrees
            "focus_distance": float(np.clip(head[2] * 0.5 + 1.0, 0.2, 3.0)),  # meters
            "scan_pattern": float(np.clip(head[3] + 1.5, 0.0, 3.0)),  # 0=horiz,1=vert,2=spiral,3=saccade
        }

        # ── 타이밍 파라미터 / Timing parameters ──
        timing = g[22:26]
        timing_params = {
            "duration_ms": int(np.clip(timing[0] * 300 + 500, 100, 3000)),  # ms
            "ramp_time_ms": int(np.clip(timing[1] * 100 + 200, 50, 1000)), # ms
            "wait_after_ms": int(np.clip(timing[2] * 200, 0, 1000)),        # ms
            "repetitions": int(np.clip(round(timing[3] + 1.5), 1, 5)),      # count
        }

        # ── 복합 액션 파라미터 / Composite action parameters ──
        comp = g[26:32]
        composite = {
            "sequence_weights": comp[0:3].tolist(),   # 순차 실행 가중치 / Sequential weights
            "parallel_weights": comp[3:6].tolist(),   # 병렬 실행 가중치 / Parallel weights
        }

        # ── 위험도 추정 / Risk estimation ──
        speed_risk = abs(locomotion["speed"]) / 2.0
        force_risk = abs(manipulation["grip_force"] - 3.0) / 12.0
        tilt_risk = abs(posture["body_tilt"]) / 30.0
        risk_level = float(np.clip(
            0.3 * speed_risk + 0.3 * force_risk + 0.2 * tilt_risk + 0.2 * 0.1,
            0.0, 1.0,
        ))

        # ── 에너지 비용 추정 / Energy cost estimation ──
        base_energy = 2.0  # 기본 대기 에너지 / Base idle energy (J)
        loco_energy = abs(locomotion["speed"]) * 15.0
        manip_energy = abs(manipulation["grip_force"]) * 1.5
        post_energy = abs(posture["body_tilt"]) * 0.3
        energy_cost = base_energy + loco_energy + manip_energy + post_energy

        result = {
            "genome_id": genome.genome_id,
            "category": genome.category.value,
            "generation": genome.generation,
            "locomotion": locomotion,
            "manipulation": manipulation,
            "posture": posture,
            "head": head_params,
            "timing": timing_params,
            "composite": composite,
            "risk_level": round(risk_level, 3),
            "estimated_energy_cost_j": round(energy_cost, 2),
            "estimated_duration_ms": timing_params["duration_ms"],
        }

        return result

    def encode_from_primitive(self, action_dict: Dict) -> ActionGenome:
        """
        프리미티브 액션 파라미터를 유전체로 인코딩 /
        Encode known action parameters to genome.

        decode_to_primitive의 역변환. 물리적 파라미터를 32차원 연속 벡터로 변환한다.
        Inverse of decode_to_primitive. Converts physical parameters to 32-dim continuous vector.

        Args:
            action_dict: 프리미티브 액션 파라미터 / Primitive action parameters

        Returns:
            인코딩된 유전체 / Encoded genome
        """
        genome = np.zeros(self.genome_dim)

        # ── 이동 파라미터 역변환 / Locomotion inverse ──
        loco = action_dict.get("locomotion", {})
        genome[0] = loco.get("speed", 0.5) / 0.3
        genome[1] = loco.get("direction", 0.0) / 30.0
        genome[2] = loco.get("acceleration", 0.0) / 0.5
        genome[3] = loco.get("stride_length", 0.15) / 0.1
        genome[4] = loco.get("turn_rate", 0.0) / 30.0
        genome[5] = loco.get("height_adjustment", 0.0) / 0.05

        # ── 조작 파라미터 역변환 / Manipulation inverse ──
        manip = action_dict.get("manipulation", {})
        genome[6] = manip.get("approach_angle", 0.0) / 30.0
        genome[7] = (manip.get("grip_force", 5.0) - 3.0) / 2.0
        genome[8] = manip.get("wrist_yaw", 0.0) / 45.0
        genome[9] = (manip.get("finger_angle", 45.0) - 45.0) / 30.0
        genome[10] = manip.get("slide_direction", 0.0) / 180.0
        genome[11] = manip.get("insert_depth", 0.0) / 0.03

        # ── 자세 파라미터 역변환 / Posture inverse ──
        post = action_dict.get("posture", {})
        genome[12] = post.get("com_x", 0.0) / 0.1
        genome[13] = post.get("com_y", 0.0) / 0.1
        genome[14] = post.get("body_tilt", 0.0) / 15.0
        genome[15] = (post.get("leg_height", 0.2) - 0.2) / 0.05
        genome[16] = post.get("weight_shift", 0.0) / 0.3
        genome[17] = (post.get("stabilize_gain", 0.5) - 0.5) / 0.3

        # ── 머리 파라미터 역변환 / Head inverse ──
        head = action_dict.get("head", {})
        genome[18] = head.get("pan", 0.0) / 45.0
        genome[19] = head.get("tilt", 0.0) / 30.0
        genome[20] = (head.get("focus_distance", 1.0) - 1.0) / 0.5
        genome[21] = head.get("scan_pattern", 1.5) - 1.5

        # ── 타이밍 파라미터 역변환 / Timing inverse ──
        timing = action_dict.get("timing", {})
        genome[22] = (timing.get("duration_ms", 500) - 500) / 300.0
        genome[23] = (timing.get("ramp_time_ms", 200) - 200) / 100.0
        genome[24] = timing.get("wait_after_ms", 0) / 200.0
        genome[25] = timing.get("repetitions", 1) - 1.5

        # ── 복합 액션 파라미터 역변환 / Composite inverse ──
        comp = action_dict.get("composite", {})
        seq_w = comp.get("sequence_weights", [0.0, 0.0, 0.0])
        par_w = comp.get("parallel_weights", [0.0, 0.0, 0.0])
        genome[26:29] = np.array(seq_w[:3])
        genome[29:32] = np.array(par_w[:3])

        # 클리핑 / Clipping
        genome = np.clip(genome, GENOME_CLIP_MIN, GENOME_CLIP_MAX)

        # 카테고리 설정 / Set category
        category_str = action_dict.get("category", "locomotion")
        try:
            category = ActionCategory(category_str)
        except ValueError:
            category = ActionCategory.LOCOMOTION

        encoded = ActionGenome(
            genome=genome,
            category=category,
            fitness_scores={k: 0.0 for k in FITNESS_KEYS},
            generation=0,
        )

        logger.debug(
            "프리미티브 → 유전체 인코딩: %s / "
            "Primitive → genome encoding: %s",
            encoded.genome_id, encoded.genome_id,
        )
        return encoded

    def get_pareto_front(
        self, category: ActionCategory
    ) -> List[ActionGenome]:
        """
        카테고리별 파레토 프론트 조회 / Get Pareto front for a category.

        지정된 카테고리에서 비지배 해(파레토 프론트)를 반환한다.

        Args:
            category: 조회할 카테고리 / Category to query

        Returns:
            파레토 프론트 유전체 목록 / Pareto front genomes
        """
        with self._lock:
            cat_ids = self._category_index.get(category, [])
            genomes = [
                self._archive[sid]
                for sid in cat_ids
                if sid in self._archive
            ]

            if not genomes:
                return []

            fronts = self._nsga2.non_dominated_sort(genomes)
            if fronts:
                pareto_front = fronts[0]
                logger.info(
                    "파레토 프론트: 카테고리=%s, %d개 비지배 해 / "
                    "Pareto front: category=%s, %d non-dominated solutions",
                    category.value, len(pareto_front),
                    category.value, len(pareto_front),
                )
                return pareto_front
            return []

    # ── 내부 유틸리티 / Internal Utilities ──

    def _add_to_archive(self, genome: ActionGenome) -> None:
        """아카이브에 유전체 추가 / Add genome to archive."""
        if genome.genome_id not in self._archive:
            self._category_index[genome.category].append(genome.genome_id)
        self._archive[genome.genome_id] = genome
        self._persist_genome(genome)

    def _default_fitness_fn(self, genome: ActionGenome) -> Dict[str, float]:
        """
        기본 적합도 함수 / Default fitness function.

        실제 로봇 평가가 불가능한 경우 사용하는 휴리스틱 적합도.
        아카이브 기반 새로움 점수와 유전체 특성 기반 휴리스틱을 결합.

        Heuristic fitness used when real robot evaluation is unavailable.
        Combines archive-based novelty with genome-property heuristics.
        """
        g = genome.genome

        # ── 성공률 추정: 안정적인 범위의 유전체가 높은 점수 / Success rate heuristic ──
        # 값이 극단적이지 않을수록 높은 성공률 추정
        extreme_ratio = float(np.mean(np.abs(g) > 2.5))
        success_rate = max(0.0, 1.0 - extreme_ratio * 2.0)

        # ── 에너지 효율: 작은 노름이 더 효율적 / Energy efficiency heuristic ──
        norm = float(np.linalg.norm(g))
        energy_efficiency = max(0.0, min(1.0, 1.0 - norm / (DEFAULT_GENOME_DIM * 0.5)))

        # ── 안정성: 자세 슬롯이 작을수록 안정 / Stability heuristic ──
        post_vals = g[12:18]
        stability = max(0.0, min(1.0, 1.0 - float(np.linalg.norm(post_vals)) / 3.0))

        # ── 정밀도: 조작 슬롯의 집중도 / Precision heuristic ──
        manip_vals = g[6:12]
        precision = max(0.0, min(1.0, float(np.mean(np.abs(manip_vals))) / 2.0))

        # ── 새로움: 아카이브와의 평균 거리 / Novelty from archive ──
        novelty = self._compute_novelty(genome, list(self._archive.values()), k=DEFAULT_NOVELTY_K)

        return {
            "success_rate": success_rate,
            "energy_efficiency": energy_efficiency,
            "stability": stability,
            "precision": precision,
            "novelty": novelty,
        }

    def _compute_novelty(
        self,
        candidate: ActionGenome,
        archive: List[ActionGenome],
        k: int = DEFAULT_NOVELTY_K,
    ) -> float:
        """
        새로움 점수 계산 / Compute novelty score.

        k-최근접 이웃과의 평균 유클리드 거리로 측정.
        Measured as average Euclidean distance to k-nearest neighbors.

        Args:
            candidate: 후보 유전체 / Candidate genome
            archive: 아카이브 유전체 목록 / Archive genomes
            k: 최근접 이웃 수 / Number of nearest neighbors

        Returns:
            새로움 점수 (0~1) / Novelty score (0~1)
        """
        if not archive:
            return 1.0  # 아카이브가 비어있으면 최대 새로움 / Max novelty for empty archive

        distances = []
        for arch_genome in archive:
            dist = float(np.linalg.norm(candidate.genome - arch_genome.genome))
            distances.append(dist)

        distances.sort()
        actual_k = min(k, len(distances))
        if actual_k == 0:
            return 1.0

        avg_dist = sum(distances[:actual_k]) / actual_k

        # 정규화: 최대 가능 거리는 sqrt(dim) * (max - min) / Normalize
        max_possible_dist = math.sqrt(self.genome_dim) * (GENOME_CLIP_MAX - GENOME_CLIP_MIN)
        novelty = min(1.0, avg_dist / max_possible_dist)

        return novelty

    def _update_phase(self) -> None:
        """진화 단계 갱신 / Update evolution phase."""
        archive_size = len(self._archive)
        if archive_size < 20:
            self._phase = EvolutionPhase.EXPLORE
        elif archive_size < 100:
            self._phase = EvolutionPhase.ADAPT
        elif archive_size < 500:
            self._phase = EvolutionPhase.REFINE
        else:
            self._phase = EvolutionPhase.CREATE

    def get_evolution_report(self) -> Dict[str, Any]:
        """
        진화 보고서 생성 / Generate evolution report.

        Returns:
            진화 상태 요약 / Evolution state summary
        """
        with self._lock:
            category_counts = {
                cat.value: len(ids) for cat, ids in self._category_index.items()
            }

            # 카테고리별 최고 적합도 / Best fitness per category
            best_per_category = {}
            for cat, ids in self._category_index.items():
                cat_genomes = [self._archive[sid] for sid in ids if sid in self._archive]
                if cat_genomes:
                    best = max(cat_genomes, key=lambda g: g.get_dominant_fitness())
                    best_per_category[cat.value] = {
                        "genome_id": best.genome_id,
                        "dominant_fitness": round(best.get_dominant_fitness(), 4),
                        "fitness_scores": {
                            k: round(v, 4) for k, v in best.fitness_scores.items()
                        },
                        "generation": best.generation,
                    }

            return {
                "version": "V8.5",
                "phase": self._phase.value,
                "total_generations": self._total_generations,
                "total_evaluations": self._total_evaluations,
                "archive_size": len(self._archive),
                "category_counts": category_counts,
                "best_per_category": best_per_category,
                "cmaes_sigma": round(self._cmaes.sigma, 6),
                "genome_dim": self.genome_dim,
            }


# ============================================================================
# 액션 공간 탐색기 / Action Space Explorer
# ============================================================================

class ActionSpaceExplorer:
    """
    자율적 액션 공간 탐색기 / Autonomous action space explorer.

    알려진 액션의 경계를 탐색하고, 액션 간 보간/외삽을 수행하며,
    새로움 탐색(novelty search)으로 미개척 영역을 발견한다.

    Explores boundaries of known actions, performs interpolation/extrapolation
    between actions, and discovers unexplored regions via novelty search.

    NO PRESET PRIMITIVES — 탐색을 통해 스스로 새로운 능력을 발견한다.
    NO PRESET PRIMITIVES — Discovers new capabilities through exploration.
    """

    def __init__(
        self,
        evolver: ActionEvolver,
        db_path: str = DEFAULT_DB_PATH,
    ) -> None:
        """
        액션 공간 탐색기 초기화 / Initialize action space explorer.

        Args:
            evolver: 연결된 액션 진화 엔진 / Connected action evolver
            db_path: SQLite 데이터베이스 경로 / SQLite database path
        """
        self._evolver = evolver
        self._db_path = db_path
        self._lock = threading.Lock()

        # ── 탐색 기록 / Exploration history ──
        self._exploration_log: List[Dict[str, Any]] = []

        # ── 새로움 아카이브 (novelty search용) / Novelty archive ──
        self._novelty_archive: List[ActionGenome] = []

        # ── 데이터베이스 초기화 / Initialize database ──
        self._init_exploration_db()

        logger.info("ActionSpaceExplorer 초기화 완료 / ActionSpaceExplorer initialized")

    def _init_exploration_db(self) -> None:
        """탐색 데이터베이스 초기화 / Initialize exploration database."""
        try:
            db_dir = os.path.dirname(self._db_path)
            if db_dir:
                os.makedirs(db_dir, exist_ok=True)

            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()

            # 탐색 기록 테이블 / Exploration log table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS exploration_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exploration_type TEXT NOT NULL,
                    genome_id TEXT NOT NULL,
                    novelty_score REAL DEFAULT 0,
                    boundary_score REAL DEFAULT 0,
                    details_json TEXT DEFAULT '{}',
                    timestamp REAL DEFAULT 0
                )
            """)

            # 새로움 아카이브 테이블 / Novelty archive table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS novelty_archive (
                    genome_id TEXT PRIMARY KEY,
                    genome_json TEXT NOT NULL,
                    novelty_score REAL DEFAULT 0,
                    added_at REAL DEFAULT 0
                )
            """)

            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_exploration_type
                ON exploration_log(exploration_type)
            """)

            conn.commit()
            conn.close()
            logger.info("탐색 데이터베이스 초기화 완료 / Exploration DB initialized")
        except Exception as e:
            logger.warning("탐색 DB 초기화 실패: %s / Exploration DB init failed: %s", e, e)

    def _log_exploration(
        self,
        exploration_type: str,
        genome: ActionGenome,
        novelty_score: float = 0.0,
        boundary_score: float = 0.0,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """탐색 기록 저장 / Log exploration result."""
        entry = {
            "exploration_type": exploration_type,
            "genome_id": genome.genome_id,
            "novelty_score": novelty_score,
            "boundary_score": boundary_score,
            "details": details or {},
            "timestamp": time.time(),
        }
        self._exploration_log.append(entry)

        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO exploration_log
                (exploration_type, genome_id, novelty_score, boundary_score, details_json, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    exploration_type,
                    genome.genome_id,
                    novelty_score,
                    boundary_score,
                    json.dumps(details or {}),
                    time.time(),
                ),
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug("탐색 기록 DB 저장 실패: %s / Exploration log DB save failed: %s", e, e)

    def _add_to_novelty_archive(self, genome: ActionGenome, novelty: float) -> None:
        """새로움 아카이브에 추가 / Add to novelty archive."""
        self._novelty_archive.append(genome)

        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT OR REPLACE INTO novelty_archive
                (genome_id, genome_json, novelty_score, added_at)
                VALUES (?, ?, ?, ?)
                """,
                (
                    genome.genome_id,
                    json.dumps(genome.to_dict()),
                    novelty,
                    time.time(),
                ),
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug("새로움 아카이브 DB 저장 실패: %s / Novelty archive DB save failed: %s", e, e)

    def explore_boundary_actions(
        self, known_actions: List[ActionGenome]
    ) -> List[ActionGenome]:
        """
        알려진 액션의 경계 탐색 / Explore actions at boundary of known capability.

        각 알려진 액션에서 가장 가까운 이웃 방향으로 외삽하여
        능력 경계에서의 새로운 액션을 발견한다.

        Extrapolates from each known action in the direction of its
        nearest neighbor to discover actions at the capability boundary.

        Args:
            known_actions: 알려진 액션 목록 / List of known actions

        Returns:
            경계 액션 목록 / Boundary actions discovered
        """
        with self._lock:
            if len(known_actions) < 2:
                # 1개 이하면 랜덤 방향 외삽 / Extrapolate in random direction if < 2
                boundary_actions = []
                for action in known_actions:
                    direction = np.random.randn(self._evolver.genome_dim)
                    direction = direction / (np.linalg.norm(direction) + 1e-10)
                    extrapolated = self.extrapolate_beyond(
                        [action], direction
                    )
                    boundary_actions.append(extrapolated)
                return boundary_actions

            boundary_actions: List[ActionGenome] = []

            for i, action in enumerate(known_actions):
                # 가장 가까운 이웃 찾기 / Find nearest neighbor
                min_dist = float("inf")
                nearest = known_actions[0] if i != 0 else known_actions[1]

                for j, other in enumerate(known_actions):
                    if i == j:
                        continue
                    dist = float(np.linalg.norm(action.genome - other.genome))
                    if dist < min_dist:
                        min_dist = dist
                        nearest = other

                # 이웃 방향으로 외삽 / Extrapolate toward neighbor direction
                direction = nearest.genome - action.genome
                norm = np.linalg.norm(direction)
                if norm > 1e-10:
                    direction = direction / norm
                else:
                    direction = np.random.randn(self._evolver.genome_dim)
                    direction = direction / (np.linalg.norm(direction) + 1e-10)

                # 경계 방향으로 1.5배 거리 외삽 / Extrapolate 1.5x distance toward boundary
                extrapolated_genome = action.genome + direction * min_dist * 1.5
                extrapolated_genome = np.clip(
                    extrapolated_genome, GENOME_CLIP_MIN, GENOME_CLIP_MAX
                )

                boundary_genome = ActionGenome(
                    genome=extrapolated_genome,
                    category=action.category,
                    fitness_scores={k: 0.0 for k in FITNESS_KEYS},
                    generation=action.generation + 1,
                    parent_ids=[action.genome_id],
                )

                # 새로움 측정 / Measure novelty
                novelty = self.measure_novelty(
                    boundary_genome,
                    self._novelty_archive if self._novelty_archive else known_actions,
                    k=DEFAULT_NOVELTY_K,
                )
                boundary_genome.fitness_scores["novelty"] = novelty

                # 경계 점수: 이웃과의 거리 (멀수록 경계적) / Boundary score
                boundary_score = min_dist

                boundary_actions.append(boundary_genome)
                self._add_to_novelty_archive(boundary_genome, novelty)
                self._log_exploration(
                    "boundary",
                    boundary_genome,
                    novelty_score=novelty,
                    boundary_score=boundary_score,
                    details={"source_id": action.genome_id, "distance_to_neighbor": min_dist},
                )

            logger.info(
                "경계 액션 %d개 탐색 완료 / Explored %d boundary actions",
                len(boundary_actions), len(boundary_actions),
            )
            return boundary_actions

    def interpolate_actions(
        self,
        a: ActionGenome,
        b: ActionGenome,
        n_steps: int = 5,
    ) -> List[ActionGenome]:
        """
        두 액션 간 보간 / Interpolate between two actions.

        a와 b 사이를 n_steps개의 등간격 점으로 보간하여
        중간 액션들을 생성한다.

        Creates n_steps evenly spaced intermediate actions between a and b.

        Args:
            a: 시작 액션 / Start action
            b: 끝 액션 / End action
            n_steps: 보간 단계 수 / Number of interpolation steps

        Returns:
            보간된 액션 목록 (a와 b 제외) / Interpolated actions (excluding a and b)
        """
        interpolated: List[ActionGenome] = []

        for i in range(1, n_steps + 1):
            t = i / (n_steps + 1)  # 0 < t < 1

            # 선형 보간 + 약간의 가우시안 노이즈로 다양성 확보
            # Linear interpolation + small Gaussian noise for diversity
            interp_genome = (1.0 - t) * a.genome + t * b.genome
            noise = np.random.randn(self._evolver.genome_dim) * 0.02
            interp_genome = interp_genome + noise
            interp_genome = np.clip(interp_genome, GENOME_CLIP_MIN, GENOME_CLIP_MAX)

            # 카테고리: t < 0.5면 a, t >= 0.5면 b / Category based on interpolation point
            category = a.category if t < 0.5 else b.category

            interp_action = ActionGenome(
                genome=interp_genome,
                category=category,
                fitness_scores={k: 0.0 for k in FITNESS_KEYS},
                generation=max(a.generation, b.generation) + 1,
                parent_ids=[a.genome_id, b.genome_id],
            )

            # 새로움 측정 / Measure novelty
            archive = self._novelty_archive or [a, b]
            novelty = self.measure_novelty(interp_action, archive, k=min(DEFAULT_NOVELTY_K, len(archive)))
            interp_action.fitness_scores["novelty"] = novelty

            interpolated.append(interp_action)
            self._add_to_novelty_archive(interp_action, novelty)
            self._log_exploration(
                "interpolation",
                interp_action,
                novelty_score=novelty,
                details={"parent_a": a.genome_id, "parent_b": b.genome_id, "t": round(t, 3)},
            )

        logger.info(
            "액션 보간: %s ↔ %s, %d단계 / "
            "Interpolated actions: %s ↔ %s, %d steps",
            a.genome_id, b.genome_id, n_steps,
            a.genome_id, b.genome_id, n_steps,
        )
        return interpolated

    def extrapolate_beyond(
        self,
        known: List[ActionGenome],
        direction: np.ndarray,
    ) -> ActionGenome:
        """
        알려진 액션을 넘어 외삽 / Extrapolate beyond known actions.

        알려진 액션들의 무게중심에서 주어진 방향으로 외삽하여
        완전히 새로운 영역의 액션을 생성한다.

        Extrapolates from the centroid of known actions in the given direction
        to create actions in completely unexplored regions.

        Args:
            known: 알려진 액션 목록 / Known actions
            direction: 외삽 방향 벡터 / Extrapolation direction vector

        Returns:
            외삽된 액션 / Extrapolated action
        """
        if not known:
            # 알려진 것이 없으면 원점에서 direction 방향으로 / Start from origin
            centroid = np.zeros(self._evolver.genome_dim)
        else:
            centroid = np.mean([a.genome for a in known], axis=0)

        # 방향 벡터 정규화 / Normalize direction vector
        direction = np.array(direction, dtype=np.float64)
        norm = np.linalg.norm(direction)
        if norm > 1e-10:
            direction = direction / norm
        else:
            direction = np.random.randn(self._evolver.genome_dim)
            direction = direction / (np.linalg.norm(direction) + 1e-10)

        # 알려진 액션들의 평균 분산으로 외삽 거리 결정 / Determine extrapolation distance
        if len(known) > 1:
            distances = [
                float(np.linalg.norm(a.genome - centroid))
                for a in known
            ]
            avg_dist = np.mean(distances) if distances else 1.0
            # 평균 거리의 1.0~2.0배 외삽 / Extrapolate 1.0~2.0x average distance
            extrapolation_factor = 1.0 + np.random.random()
        else:
            avg_dist = 1.0
            extrapolation_factor = 1.5

        extrapolated_genome = centroid + direction * avg_dist * extrapolation_factor
        extrapolated_genome = np.clip(extrapolated_genome, GENOME_CLIP_MIN, GENOME_CLIP_MAX)

        # 카테고리: 가장 가까운 알려진 액션의 카테고리 / Category from nearest known action
        if known:
            dists = [float(np.linalg.norm(extrapolated_genome - a.genome)) for a in known]
            nearest_idx = int(np.argmin(dists))
            category = known[nearest_idx].category
        else:
            category = ActionCategory.COMPOSITE

        extrapolated_action = ActionGenome(
            genome=extrapolated_genome,
            category=category,
            fitness_scores={k: 0.0 for k in FITNESS_KEYS},
            generation=max((a.generation for a in known), default=0) + 1,
            parent_ids=[a.genome_id for a in known[:5]],  # 최대 5개 부모 기록
        )

        # 새로움 측정 / Measure novelty
        archive = self._novelty_archive or known
        novelty = self.measure_novelty(extrapolated_action, archive, k=min(DEFAULT_NOVELTY_K, len(archive)))
        extrapolated_action.fitness_scores["novelty"] = novelty

        self._add_to_novelty_archive(extrapolated_action, novelty)
        self._log_exploration(
            "extrapolation",
            extrapolated_action,
            novelty_score=novelty,
            details={
                "n_known": len(known),
                "extrapolation_factor": round(extrapolation_factor, 3),
                "direction_norm": round(float(norm), 6),
            },
        )

        logger.info(
            "외삽 액션 생성: %s (새로움=%.3f) / "
            "Extrapolated action: %s (novelty=%.3f)",
            extrapolated_action.genome_id, novelty,
            extrapolated_action.genome_id, novelty,
        )
        return extrapolated_action

    def measure_novelty(
        self,
        candidate: ActionGenome,
        archive: List[ActionGenome],
        k: int = DEFAULT_NOVELTY_K,
    ) -> float:
        """
        새로움 점수 측정 / Measure novelty score.

        후보 액션과 아카이브 내 k-최근접 이웃 간의 평균 유클리드 거리로
        새로움을 측정한다. 거리가 클수록 더 새로운 액션이다.

        Measures novelty as the average Euclidean distance between the candidate
        and its k-nearest neighbors in the archive. Larger distance = more novel.

        This is the core metric for novelty search, enabling the system to
        discover actions that are genuinely different from what it already knows.

        Args:
            candidate: 평가할 후보 액션 / Candidate action to evaluate
            archive: 비교할 아카이브 액션 목록 / Archive actions for comparison
            k: 최근접 이웃 수 / Number of nearest neighbors

        Returns:
            새로움 점수 (0~1) / Novelty score (0~1)
        """
        if not archive:
            return 1.0

        # 유클리드 거리 계산 / Compute Euclidean distances
        distances: List[float] = []
        for arch in archive:
            # 자기 자신은 제외 / Exclude self
            if arch.genome_id == candidate.genome_id:
                continue
            dist = float(np.linalg.norm(candidate.genome - arch.genome))
            distances.append(dist)

        if not distances:
            return 1.0

        # 정렬 후 k-최근접 이웃 평균 거리 / Sort and average k-nearest distances
        distances.sort()
        actual_k = min(k, len(distances))
        avg_knn_dist = sum(distances[:actual_k]) / actual_k

        # 정규화 / Normalize
        max_possible = math.sqrt(self._evolver.genome_dim) * (GENOME_CLIP_MAX - GENOME_CLIP_MIN)
        novelty = min(1.0, avg_knn_dist / max_possible)

        return novelty

    def get_exploration_report(self) -> Dict[str, Any]:
        """
        탐색 보고서 생성 / Generate exploration report.

        Returns:
            탐색 상태 요약 / Exploration state summary
        """
        with self._lock:
            # 탐색 유형별 통계 / Statistics by exploration type
            type_counts: Dict[str, int] = {}
            type_novelty: Dict[str, List[float]] = {}
            for entry in self._exploration_log:
                etype = entry["exploration_type"]
                type_counts[etype] = type_counts.get(etype, 0) + 1
                if etype not in type_novelty:
                    type_novelty[etype] = []
                type_novelty[etype].append(entry.get("novelty_score", 0.0))

            avg_novelty_by_type = {}
            for etype, scores in type_novelty.items():
                avg_novelty_by_type[etype] = round(
                    sum(scores) / len(scores), 4
                ) if scores else 0.0

            return {
                "version": "V8.5",
                "total_explorations": len(self._exploration_log),
                "novelty_archive_size": len(self._novelty_archive),
                "exploration_type_counts": type_counts,
                "avg_novelty_by_type": avg_novelty_by_type,
            }


# ============================================================================
# 모듈 진입점 / Module Entry Point
# ============================================================================

def run_demonstration() -> None:
    """
    모듈 데모 실행 / Run module demonstration.

    진화적 액션 탐색 시스템의 핵심 기능을 시연한다.
    Demonstrates core features of the evolutionary action exploration system.
    """
    print("=" * 70)
    print("Jihun Robot V8.5 — 진화적 액션 탐색 데모 / Evolutionary Action Exploration Demo")
    print("=" * 70)
    print()

    # ── 1. ActionEvolver 초기화 / Initialize ActionEvolver ──
    print("[1] ActionEvolver 초기화 / Initializing ActionEvolver...")
    evolver = ActionEvolver(genome_dim=32)
    print(f"    아카이브 크기: {len(evolver._archive)} / Archive size: {len(evolver._archive)}")
    print()

    # ── 2. 새 액션 발견 / Discover new actions ──
    print("[2] 조작 카테고리 새 액션 발견 / Discovering new manipulation actions...")
    new_actions = evolver.discover_new_actions(
        ActionCategory.MANIPULATION,
        n_actions=5,
        n_generations=3,
    )
    for i, action in enumerate(new_actions):
        print(f"    [{i+1}] {action.summary()}")
    print()

    # ── 3. 유전체 디코딩 / Decode genome ──
    print("[3] 유전체 → 프리미티브 액션 디코딩 / Decoding genome to primitive action...")
    if new_actions:
        decoded = evolver.decode_to_primitive(new_actions[0])
        print(f"    genome_id: {decoded['genome_id']}")
        print(f"    category:  {decoded['category']}")
        print(f"    locomotion:  {decoded['locomotion']}")
        print(f"    manipulation: {decoded['manipulation']}")
        print(f"    posture:     {decoded['posture']}")
        print(f"    head:        {decoded['head']}")
        print(f"    timing:      {decoded['timing']}")
        print(f"    risk_level:  {decoded['risk_level']}")
        print(f"    energy_cost: {decoded['estimated_energy_cost_j']} J")
    print()

    # ── 4. 프리미티브 → 유전체 인코딩 / Encode primitive to genome ──
    print("[4] 프리미티브 액션 → 유전체 인코딩 / Encoding primitive action to genome...")
    test_action = {
        "category": "locomotion",
        "locomotion": {
            "speed": 0.8,
            "direction": 15.0,
            "acceleration": 0.3,
            "stride_length": 0.2,
            "turn_rate": 10.0,
            "height_adjustment": 0.0,
        },
        "manipulation": {
            "approach_angle": 0.0,
            "grip_force": 5.0,
            "wrist_yaw": 0.0,
            "finger_angle": 45.0,
            "slide_direction": 0.0,
            "insert_depth": 0.0,
        },
        "posture": {
            "com_x": 0.0, "com_y": 0.0,
            "body_tilt": 5.0, "leg_height": 0.25,
            "weight_shift": 0.0, "stabilize_gain": 0.7,
        },
        "head": {
            "pan": 0.0, "tilt": 0.0,
            "focus_distance": 1.5, "scan_pattern": 0.0,
        },
        "timing": {
            "duration_ms": 800, "ramp_time_ms": 300,
            "wait_after_ms": 100, "repetitions": 1,
        },
        "composite": {
            "sequence_weights": [0.5, 0.3, 0.2],
            "parallel_weights": [0.1, 0.0, -0.1],
        },
    }
    encoded = evolver.encode_from_primitive(test_action)
    print(f"    인코딩된 유전체: {encoded.genome_id}")
    print(f"    카테고리: {encoded.category.value}")
    print(f"    유전체 노름: {np.linalg.norm(encoded.genome):.3f}")
    # 왕복 확인 / Round-trip verification
    re_decoded = evolver.decode_to_primitive(encoded)
    print(f"    왕복 확인 speed: {re_decoded['locomotion']['speed']:.3f} (원본: 0.800)")
    print()

    # ── 5. 교차 및 돌연변이 / Crossover and mutation ──
    print("[5] 교차 및 돌연변이 / Crossover and mutation...")
    if len(new_actions) >= 2:
        child = evolver.crossover(new_actions[0], new_actions[1])
        print(f"    교차 자식: {child.genome_id}")
        print(f"    부모: {child.parent_ids}")

        mutated = evolver.mutate(child, sigma=0.15)
        print(f"    돌연변이: {mutated.genome_id}")
        print(f"    부모: {mutated.parent_ids}")
    print()

    # ── 6. NSGA-II 파레토 프론트 / NSGA-II Pareto front ──
    print("[6] 파레토 프론트 조회 / Querying Pareto front...")
    pareto = evolver.get_pareto_front(ActionCategory.MANIPULATION)
    print(f"    조작 파레토 프론트: {len(pareto)}개 비지배 해")
    for p in pareto[:3]:
        print(f"      {p.summary()}")
    print()

    # ── 7. ActionSpaceExplorer / 액션 공간 탐색기 ──
    print("[7] ActionSpaceExplorer — 액션 공간 탐색 / Action space exploration...")
    explorer = ActionSpaceExplorer(evolver)

    # 경계 탐색 / Boundary exploration
    boundary = explorer.explore_boundary_actions(new_actions[:3])
    print(f"    경계 액션 {len(boundary)}개 발견")
    for b in boundary:
        print(f"      {b.genome_id} novelty={b.fitness_scores.get('novelty', 0):.3f}")

    # 보간 / Interpolation
    if len(new_actions) >= 2:
        interp = explorer.interpolate_actions(new_actions[0], new_actions[1], n_steps=3)
        print(f"    보간 액션 {len(interp)}개 생성")
        for ia in interp:
            print(f"      {ia.genome_id} novelty={ia.fitness_scores.get('novelty', 0):.3f}")

    # 외삽 / Extrapolation
    direction = np.random.randn(32)
    extrapolated = explorer.extrapolate_beyond(new_actions, direction)
    print(f"    외삽 액션: {extrapolated.genome_id} novelty={extrapolated.fitness_scores.get('novelty', 0):.3f}")

    # 새로움 측정 / Novelty measurement
    novelty = explorer.measure_novelty(extrapolated, new_actions, k=min(3, len(new_actions)))
    print(f"    새로움 점수: {novelty:.3f}")
    print()

    # ── 8. 진화 보고서 / Evolution report ──
    print("[8] 진화 보고서 / Evolution report...")
    report = evolver.get_evolution_report()
    print(f"    버전:     {report['version']}")
    print(f"    단계:     {report['phase']}")
    print(f"    세대:     {report['total_generations']}")
    print(f"    평가:     {report['total_evaluations']}")
    print(f"    아카이브: {report['archive_size']}")
    print(f"    카테고리: {report['category_counts']}")
    print()

    # ── 9. 탐색 보고서 / Exploration report ──
    exp_report = explorer.get_exploration_report()
    print("[9] 탐색 보고서 / Exploration report...")
    print(f"    총 탐색:   {exp_report['total_explorations']}")
    print(f"    새로움 아카이브: {exp_report['novelty_archive_size']}")
    print(f"    탐색 유형: {exp_report['exploration_type_counts']}")
    print(f"    평균 새로움: {exp_report['avg_novelty_by_type']}")
    print()

    print("=" * 70)
    print("데모 완료 / Demo complete")
    print("=" * 70)


if __name__ == "__main__":
    run_demonstration()
