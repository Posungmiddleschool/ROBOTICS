#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — SimpleFOC Mini I2C 컨트롤러 (SimpleFOC Controller)
=================================================================

Jetson#2 → I2C 400kHz → SimpleFOC Mini ×6
  - 4x 휠 속도 제어 (2204 BLDC 1500KV, I2C 0x10-0x13)
  - 2x 다리 승강 위치 제어 (2806 BLDC 600KV, I2C 0x14, 0x15)

V8.5 변경사항 / V8.5 Changes from V8.5:
  - I2C 통신 오류 복구 (I2C communication error recovery)
  - 모터 엔코더 건전성 검사 (Motor encoder health check)
  - FOC 교정 검증 (FOC calibration verification)
  - 과온도 출력 제한 (Overtemperature derating)

제어 모드:
  - 속도 제어 (휠): 100Hz, 오버슈트 <5%
  - 위치 제어 (다리): 100Hz, 정상상태 오차 <1mm

⚠️ 중요 경고:
  SimpleFOC Mini는 DRV8313 드라이버 칩을 사용하며, 상당 최대 전류는
  2.5A/phase입니다. BOM에 명시된 10A는 과도한 수치입니다.

작성일: 2026-05-19
버전: V8.5.5-AGI
라이선스: MIT
"""

from __future__ import annotations

import logging
import struct
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V84.SimpleFOC")


# ============================================================================
# 상수 및 열거형
# ============================================================================

# ⚠️ CRITICAL WARNING: DRV8313 최대 전류
DRV8313_MAX_CURRENT_A = 2.5     # DRV8313 상당 최대 전류
DRV8313_PEAK_CURRENT_A = 3.5    # DRV8313 피크 (단시간)

# 추천 대안 드라이버 전류 스펙
ALTERNATIVE_DRIVERS = {
    "B-G431B-ESC1": {"continuous_a": 5.0, "peak_a": 7.0, "interface": "I2C/UART"},
    "ODrive_S1": {"continuous_a": 20.0, "peak_a": 40.0, "interface": "CAN/I2C/UART"},
}

I2C_BUS = 1
I2C_SPEED_KHZ = 400
CONTROL_LOOP_HZ = 100
CONTROL_LOOP_PERIOD_S = 1.0 / CONTROL_LOOP_HZ

# I2C 레지스터 맵 (SimpleFOC Mini 프로토콜)
REG_MODE = 0x01           # 제어 모드 레지스터
REG_TARGET = 0x02         # 목표값 (속도 또는 위치)
REG_VELOCITY = 0x03       # 현재 속도 피드백
REG_POSITION = 0x04       # 현재 위치 피드백
REG_ENCODER = 0x05        # 엔코더 원시값
REG_CURRENT = 0x06        # 상전류
REG_STATUS = 0x07         # 상태 레지스터
REG_ADDRESS = 0x08        # I2C 주소 변경
REG_PID_KP = 0x10         # PID Kp
REG_PID_KI = 0x11         # PID Ki
REG_PID_KD = 0x12         # PID Kd
REG_TEMPERATURE = 0x20    # V8.5: 온도 레지스터 (지원 시)
REG_FOC_CALIBRATION = 0x30  # V8.5: FOC 교정 상태

# V8.5: I2C 오류 복구 상수
I2C_MAX_RETRIES = 3                    # I2C 재시도 횟수
I2C_RECOVERY_DELAY_S = 0.01            # 재시도 간 대기 (초)
I2C_BUS_RESET_DELAY_S = 0.1            # 버스 리셋 대기 (초)
I2C_CONSECUTIVE_ERROR_LIMIT = 10        # 연속 오류 한계 (버스 리셋 기준)
I2C_ERROR_WINDOW_SIZE = 50             # 오류율 계산 윈도우

# V8.5: 엔코더 건전성 검사 상수
ENCODER_HEALTH_WINDOW = 100            # 엔코더 검사 윈도우 (샘플 수)
ENCODER_STUCK_THRESHOLD = 5            # 엔코더 정지 판정: 연속 동일값 한계
ENCODER_JUMP_THRESHOLD = 500           # 엔코더 급변 임계값 (PPR 기반)
ENCODER_MIN_VARIANCE = 0.1             # 최소 분산 (정지 판정)

# V8.5: FOC 교정 검증 상수
FOC_CALIBRATION_TIMEOUT_S = 5.0        # 교정 타임아웃 (초)
FOC_CALIBRATION_RETRIES = 2            # 교정 재시도 횟수

# V8.5: 과온도 제한 상수
TEMP_WARNING_C = 60.0                  # 온도 경고 (°C)
TEMP_DERATE_START_C = 55.0             # 출력 제한 시작 온도
TEMP_CRITICAL_C = 75.0                 # 위험 온도
TEMP_SHUTDOWN_C = 85.0                 # 셧다운 온도
TEMP_DERATE_MIN_FACTOR = 0.2           # 최소 제한 계수

# V8.5 AGI: FOC 구현 상수 / V8.5 AGI: FOC implementation constants
FOC_ELECTRICAL_ANGLE_OFFSET = 0.0      # 전기각 오프셋 (교정값)
FOC_POLE_PAIRS = 7                        # 폴 페어 수 (2204 BLDC 표준)
FOC_SIN_TABLE_SIZE = 256                  # 사인파 룩업 테이블 크기
FOC_CURRENT_LOOP_HZ = 1000               # 전류 제어 루프 주파수 (1kHz)

# V8.5 AGI: 토크 제어 상수 / V8.5 AGI: Torque control constants
TORQUE_KP = 0.5                         # 토크 제어 비례 게인
TORQUE_KI = 0.05                        # 토크 제어 적분 게인
TORQUE_KD = 0.01                        # 토크 제어 미분 게인
TORQUE_MAX_NM = 0.5                     # 최대 토크 (N·m)
TORQUE_CURRENT_LIMIT_A = DRV8313_MAX_CURRENT_A  # 토크 전류 제한

# V8.5 AGI: 궤적 생성 상수 / V8.5 AGI: Trajectory generation constants
TRAJ_DEFAULT_ACCEL_RAD_S2 = 10.0       # 기본 가속도 (rad/s²)
TRAJ_DEFAULT_DECEL_RAD_S2 = 10.0       # 기본 감속도 (rad/s²)
TRAJ_MAX_JERK_RAD_S3 = 100.0           # 최대 저크 (rad/s³)
TRAJ_S_CURVE_BLEND_FACTOR = 0.5        # S-커브 블렌딩 계수 (0=사다리꼴, 1=S-커브)


class ControlMode(IntEnum):
    """SimpleFOC 제어 모드"""
    VELOCITY = 0     # 속도 제어 (휠)
    POSITION = 1     # 위치 제어 (다리)
    TORQUE = 2       # 토크 제어 (V8.5 AGI: 활성화)


class DriverStatus(IntEnum):
    """드라이버 상태"""
    OK = 0
    OVERCURRENT = 1
    OVERTEMPERATURE = 2
    UNDERVOLTAGE = 3
    ENCODER_FAULT = 4
    STALL = 5


class MotorID(Enum):
    """모터 식별자"""
    WHEEL_FRONT_LEFT = "wheel_front_left"
    WHEEL_FRONT_RIGHT = "wheel_front_right"
    WHEEL_REAR_LEFT = "wheel_rear_left"
    WHEEL_REAR_RIGHT = "wheel_rear_right"
    LEG_LEFT_LIFT = "leg_left_lift"
    LEG_RIGHT_LIFT = "leg_right_lift"


# I2C 주소 매핑
MOTOR_I2C_ADDRESSES: Dict[MotorID, int] = {
    MotorID.WHEEL_FRONT_LEFT: 0x10,
    MotorID.WHEEL_FRONT_RIGHT: 0x11,
    MotorID.WHEEL_REAR_LEFT: 0x12,
    MotorID.WHEEL_REAR_RIGHT: 0x13,
    MotorID.LEG_LEFT_LIFT: 0x14,
    MotorID.LEG_RIGHT_LIFT: 0x15,
}


# ============================================================================
# V8.5 데이터 클래스
# ============================================================================

@dataclass
class I2CErrorStats:
    """V8.5: I2C 오류 통계"""
    total_errors: int = 0
    consecutive_errors: int = 0
    bus_resets: int = 0
    last_error_time: float = 0.0
    last_error_type: str = ""
    error_rate: float = 0.0  # 최근 윈도우 내 오류율


@dataclass
class EncoderHealth:
    """V8.5: 엔코더 건전성 상태"""
    motor_id: MotorID = MotorID.WHEEL_FRONT_LEFT
    is_healthy: bool = True
    stuck_detected: bool = False
    jump_detected: bool = False
    consecutive_same_count: int = 0
    last_jump_magnitude: int = 0
    variance: float = 0.0
    last_check_time: float = 0.0


@dataclass
class FOCCalibrationStatus:
    """V8.5: FOC 교정 상태"""
    motor_id: MotorID = MotorID.WHEEL_FRONT_LEFT
    is_calibrated: bool = False
    calibration_score: float = 0.0   # 0~1, 1=완벽
    last_calibration_time: float = 0.0
    calibration_attempts: int = 0
    needs_recalibration: bool = True


@dataclass
class ThermalDerating:
    """V8.5: 과온도 제한 상태"""
    motor_id: MotorID = MotorID.WHEEL_FRONT_LEFT
    current_temp_c: float = 25.0
    derate_factor: float = 1.0       # 1.0=정상, 0.0=셧다운
    is_shutdown: bool = False
    warning_active: bool = False


@dataclass
class MotorState:
    """개별 모터 상태"""
    motor_id: MotorID
    i2c_address: int
    mode: ControlMode = ControlMode.VELOCITY
    target: float = 0.0              # 목표값 (속도 rad/s 또는 위치 rad)
    current_velocity: float = 0.0    # 현재 속도 (rad/s)
    current_position: float = 0.0    # 현재 위치 (rad)
    encoder_raw: int = 0             # 엔코더 원시값
    phase_current_a: float = 0.0     # 상전류 (A)
    status: DriverStatus = DriverStatus.OK
    last_update_s: float = 0.0       # 마지막 업데이트 시간
    # V8.5 추가
    i2c_errors: I2CErrorStats = field(default_factory=I2CErrorStats)
    encoder_health: EncoderHealth = field(default_factory=EncoderHealth)
    foc_status: FOCCalibrationStatus = field(default_factory=FOCCalibrationStatus)
    thermal: ThermalDerating = field(default_factory=ThermalDerating)


@dataclass
class PIDGains:
    """PID 게인 설정"""
    kp: float = 2.0
    ki: float = 0.5
    kd: float = 0.1


# ============================================================================
# V8.5 AGI: FOC (Field-Oriented Control) 구현
# ============================================================================

class FOController:
    """
    V8.5 AGI: FOC (Field-Oriented Control) 구현 / FOC Implementation.

    BLDC 모터를 위한 벡터 제어 (Field-Oriented Control).
    3상 전류를 d-q 좌표계로 변환하여 독립 제어.

    FOC 파이프라인:
    1. 엔코더에서 기계각 θ_m 읽기
    2. 전기각 θ_e = θ_m × 폴페어수 + 오프셋
    3. Clarke 변환: (Ia, Ib, Ic) → (Iα, Iβ)
    4. Park 변환: (Iα, Iβ, θ_e) → (Id, Iq)
    5. PI 제어: Id→Vd (목표 Id=0), Iq→Vq (토크 제어)
    6. 역 Park 변환: (Vd, Vq, θ_e) → (Vα, Vβ)
    7. SVPWM: (Vα, Vβ) → (duty_a, duty_b, duty_c)

    이 구현은 I2C를 통해 SimpleFOC Mini에 명령을 전송하므로,
    호스트 측에서 고수준 FOC 계산을 수행하고 타겟 전류/각도를 전송.
    """

    def __init__(self, pole_pairs: int = FOC_POLE_PAIRS) -> None:
        self._pole_pairs = pole_pairs
        self._angle_offset = FOC_ELECTRICAL_ANGLE_OFFSET
        self._sin_table = self._build_sin_table(FOC_SIN_TABLE_SIZE)
        self._id_target: float = 0.0   # d축 목표 전류 (항상 0)
        self._iq_target: float = 0.0   # q축 목표 전류 (토크 제어)
        # PI 제어기 (d축, q축 각각)
        self._id_integral: float = 0.0
        self._iq_integral: float = 0.0
        self._prev_id_error: float = 0.0
        self._prev_iq_error: float = 0.0

    @staticmethod
    def _build_sin_table(size: int) -> List[float]:
        """사인파 룩업 테이블 생성 / Build sine lookup table."""
        return [math.sin(2.0 * math.pi * i / size) for i in range(size)]

    def _fast_sin(self, angle_rad: float) -> float:
        """룩업 테이블 기반 빠른 사인 계산 / Fast sine via lookup table."""
        idx = int((angle_rad / (2.0 * math.pi)) * len(self._sin_table)) % len(self._sin_table)
        return self._sin_table[idx]

    def _fast_cos(self, angle_rad: float) -> float:
        """룩업 테이블 기반 빠른 코사인 계산 / Fast cosine via lookup table."""
        return self._fast_sin(angle_rad + math.pi / 2.0)

    def mechanical_to_electrical(self, mech_angle_rad: float) -> float:
        """기계각 → 전기각 변환 / Mechanical to electrical angle."""
        return mech_angle_rad * self._pole_pairs + self._angle_offset

    def clarke_transform(self, ia: float, ib: float, ic: float) -> Tuple[float, float]:
        """
        Clarke 변환: 3상 → 2상 (α-β) / Clarke transform.

        Args:
            ia, ib, ic: 3상 전류 (A)

        Returns:
            (Iα, Iβ) 튜플
        """
        i_alpha = ia
        i_beta = (ia + 2.0 * ib) / math.sqrt(3.0)
        return (i_alpha, i_beta)

    def park_transform(
        self, i_alpha: float, i_beta: float, theta_e: float,
    ) -> Tuple[float, float]:
        """
        Park 변환: (α-β) → (d-q) / Park transform.

        Args:
            i_alpha, i_beta: α-β 전류
            theta_e: 전기각 (rad)

        Returns:
            (Id, Iq) 튜플
        """
        cos_theta = self._fast_cos(theta_e)
        sin_theta = self._fast_sin(theta_e)
        i_d = i_alpha * cos_theta + i_beta * sin_theta
        i_q = -i_alpha * sin_theta + i_beta * cos_theta
        return (i_d, i_q)

    def inverse_park_transform(
        self, v_d: float, v_q: float, theta_e: float,
    ) -> Tuple[float, float]:
        """
        역 Park 변환: (d-q) → (α-β) / Inverse Park transform.

        Args:
            v_d, v_q: d-q 전압
            theta_e: 전기각 (rad)

        Returns:
            (Vα, Vβ) 튜플
        """
        cos_theta = self._fast_cos(theta_e)
        sin_theta = self._fast_sin(theta_e)
        v_alpha = v_d * cos_theta - v_q * sin_theta
        v_beta = v_d * sin_theta + v_q * cos_theta
        return (v_alpha, v_beta)

    def svpwm(
        self, v_alpha: float, v_beta: float, v_bus: float,
    ) -> Tuple[float, float, float]:
        """
        SVPWM (Space Vector PWM): (Vα, Vβ) → 3상 듀티사이클.

        Args:
            v_alpha, v_beta: α-β 전압
            v_bus: DC 버스 전압 (V)

        Returns:
            (duty_a, duty_b, duty_c) 튜플 (0~1)
        """
        # 정규화 / Normalize
        v_alpha_n = v_alpha / (v_bus / math.sqrt(3.0)) if v_bus > 0 else 0.0
        v_beta_n = v_beta / (v_bus / math.sqrt(3.0)) if v_bus > 0 else 0.0

        # 섹터 결정 / Determine sector
        sector = self._get_sector(v_alpha_n, v_beta_n)

        # 단순화된 SVPWM (정현 PWM 근사) / Simplified SVPWM
        duty_a = 0.5 + v_alpha_n * 0.5
        duty_b = 0.5 + (-0.5 * v_alpha_n + math.sqrt(3.0) / 2.0 * v_beta_n) * 0.5
        duty_c = 0.5 + (-0.5 * v_alpha_n - math.sqrt(3.0) / 2.0 * v_beta_n) * 0.5

        # 클램핑 / Clamp
        duty_a = max(0.0, min(1.0, duty_a))
        duty_b = max(0.0, min(1.0, duty_b))
        duty_c = max(0.0, min(1.0, duty_c))

        return (duty_a, duty_b, duty_c)

    @staticmethod
    def _get_sector(v_alpha: float, v_beta: float) -> int:
        """SVPWM 섹터 결정 / Determine SVPWM sector (1-6)."""
        angle = math.atan2(v_beta, v_alpha)
        if angle < 0:
            angle += 2.0 * math.pi
        return int(angle / (math.pi / 3.0)) + 1

    def foc_current_control(
        self,
        i_d_measured: float,
        i_q_measured: float,
        i_q_target: float,
        dt: float,
    ) -> Tuple[float, float]:
        """
        FOC 전류 PI 제어 / FOC current PI control.

        d축: Id 목표 = 0 (최대 효율)
        q축: Iq 목표 = 토크 명령에 비례

        Args:
            i_d_measured: 측정 d축 전류
            i_q_measured: 측정 q축 전류
            i_q_target: 목표 q축 전류
            dt: 시간 간격

        Returns:
            (Vd, Vq) 제어 전압
        """
        # d축 PI 제어 (목표 Id = 0)
        id_error = 0.0 - i_d_measured
        self._id_integral += id_error * dt
        self._id_integral = max(-5.0, min(5.0, self._id_integral))
        v_d = 0.5 * id_error + 0.05 * self._id_integral

        # q축 PI 제어 (목표 Iq = 토크 명령)
        iq_error = i_q_target - i_q_measured
        self._iq_integral += iq_error * dt
        self._iq_integral = max(-5.0, min(5.0, self._iq_integral))
        iq_derivative = (iq_error - self._prev_iq_error) / max(dt, 0.001)
        self._prev_iq_error = iq_error
        v_q = 0.5 * iq_error + 0.05 * self._iq_integral + 0.01 * iq_derivative

        return (v_d, v_q)


# ============================================================================
# V8.5 AGI: 토크 제어기 (Torque Controller)
# ============================================================================

class TorqueController:
    """
    V8.5 AGI: 토크 제어기 / Torque Controller.

    BLDC 모터의 토크를 직접 제어.
    위치/속도 제어와 달리 출력 토크를 정밀하게 조절.

    토크 제어 파이프라인:
    1. 목표 토크 τ_d 입력
    2. τ_d → 목표 q축 전류 Iq = τ_d / Kt (토크상수)
    3. FOC 전류 제어 루프에서 Iq 추종
    4. 실제 토크 τ = Kt × Iq 피드백

    사용 시나리오:
    - 관절의 힘 제어 (악수, 물체 그립)
    - 무게 추적 (물체 들어올리기)
    - 충돌 감지 (안전 정지)
    """

    def __init__(self, torque_constant: float = 0.02) -> None:
        """
        토크 제어기 초기화 / Initialize torque controller.

        Args:
            torque_constant: 토크 상수 Kt (N·m/A)
        """
        self._kt = torque_constant
        self._target_torque_nm: Dict[MotorID, float] = {}
        self._measured_torque_nm: Dict[MotorID, float] = {}
        self._torque_integral: Dict[MotorID, float] = {}
        self._prev_torque_error: Dict[MotorID, float] = {}

    def set_target_torque(self, motor_id: MotorID, torque_nm: float) -> None:
        """
        목표 토크 설정 / Set target torque.

        Args:
            motor_id: 모터 식별자
            torque_nm: 목표 토크 (N·m), 음수 가능
        """
        torque_nm = max(-TORQUE_MAX_NM, min(TORQUE_MAX_NM, torque_nm))
        self._target_torque_nm[motor_id] = torque_nm
        if motor_id not in self._torque_integral:
            self._torque_integral[motor_id] = 0.0
            self._prev_torque_error[motor_id] = 0.0

    def compute_iq_target(self, motor_id: MotorID) -> float:
        """
        목표 토크 → 목표 q축 전류 변환 / Convert target torque to Iq target.

        τ = Kt × Iq  →  Iq = τ / Kt

        Returns:
            목표 q축 전류 (A)
        """
        torque = self._target_torque_nm.get(motor_id, 0.0)
        iq_target = torque / self._kt if self._kt > 0 else 0.0
        # 전류 제한 적용 / Apply current limit
        return max(-TORQUE_CURRENT_LIMIT_A, min(TORQUE_CURRENT_LIMIT_A, iq_target))

    def update(
        self,
        motor_id: MotorID,
        measured_current_a: float,
        dt: float,
    ) -> float:
        """
        토크 제어 업데이트 / Update torque control.

        측정 전류로부터 실제 토크를 추정하고
        오차에 따른 보정 전류를 계산.

        Args:
            motor_id: 모터 식별자
            measured_current_a: 측정 상전류 (A)
            dt: 시간 간격

        Returns:
            보정된 q축 목표 전류 (A)
        """
        # 실제 토크 추정 / Estimate actual torque
        measured_torque = measured_current_a * self._kt
        self._measured_torque_nm[motor_id] = measured_torque

        target_torque = self._target_torque_nm.get(motor_id, 0.0)
        error = target_torque - measured_torque

        # 토크 PID / Torque PID
        integral = self._torque_integral.get(motor_id, 0.0) + error * dt
        integral = max(-1.0, min(1.0, integral))
        self._torque_integral[motor_id] = integral

        prev_error = self._prev_torque_error.get(motor_id, 0.0)
        derivative = (error - prev_error) / max(dt, 0.001)
        self._prev_torque_error[motor_id] = error

        correction = (
            TORQUE_KP * error +
            TORQUE_KI * integral +
            TORQUE_KD * derivative
        )

        # 목표 전류에 보정 추가 / Add correction to target current
        iq_base = self.compute_iq_target(motor_id)
        iq_corrected = iq_base + correction / self._kt if self._kt > 0 else 0.0

        return max(-TORQUE_CURRENT_LIMIT_A, min(TORQUE_CURRENT_LIMIT_A, iq_corrected))

    def get_measured_torque(self, motor_id: MotorID) -> float:
        """측정 토크 조회 / Get measured torque."""
        return self._measured_torque_nm.get(motor_id, 0.0)


# ============================================================================
# V8.5 AGI: 궤적 생성기 (Trajectory Generator)
# ============================================================================

class TrajectoryGenerator:
    """
    V8.5 AGI: 궤적 생성기 / Trajectory Generator.

    부드러운 모터 이동을 위한 궤적 프로파일 생성.
    사다리꼴(Trapezoidal) 및 S-커브 프로파일 지원.

    사다리꼴 프로파일:
      가속 → 등속 → 감속
      빠른 응답, 저크가 큼

    S-커브 프로파일:
      저크 제한 가속 → 등속 → 저크 제한 감속
      부드러운 응답, 기계적 스트레스 감소
      요리, 조립 등 정밀 작업에 적합

    사용 예:
      traj = TrajectoryGenerator()
      traj.start(motor_id, start_pos, end_pos, max_vel, max_accel)
      while not traj.is_complete(motor_id):
          target = traj.update(motor_id, dt)
          controller.set_position(addr, target)
    """

    @dataclass
    class _TrajState:
        """궤적 내부 상태 / Internal trajectory state."""
        start_pos: float = 0.0
        end_pos: float = 0.0
        max_vel: float = 5.0          # rad/s
        max_accel: float = 10.0       # rad/s²
        max_jerk: float = 100.0       # rad/s³
        blend_factor: float = 0.5     # S-커브 블렌딩
        current_pos: float = 0.0
        current_vel: float = 0.0
        is_active: bool = False
        is_complete: bool = False
        phase: str = "idle"            # idle, accel, cruise, decel, done
        elapsed: float = 0.0
        direction: float = 1.0

    def __init__(self) -> None:
        self._states: Dict[MotorID, TrajectoryGenerator._TrajState] = {}

    def start(
        self,
        motor_id: MotorID,
        start_pos: float,
        end_pos: float,
        max_vel: float = 5.0,
        max_accel: float = TRAJ_DEFAULT_ACCEL_RAD_S2,
        s_curve: bool = True,
    ) -> None:
        """
        궤적 시작 / Start trajectory.

        Args:
            motor_id: 모터 식별자
            start_pos: 시작 위치 (rad)
            end_pos: 목표 위치 (rad)
            max_vel: 최대 속도 (rad/s)
            max_accel: 최대 가속도 (rad/s²)
            s_curve: True=S-커브, False=사다리꼴
        """
        distance = end_pos - start_pos
        direction = 1.0 if distance >= 0 else -1.0
        abs_distance = abs(distance)

        state = self._TrajState(
            start_pos=start_pos,
            end_pos=end_pos,
            max_vel=max_vel,
            max_accel=max_accel,
            max_jerk=TRAJ_MAX_JERK_RAD_S3,
            blend_factor=TRAJ_S_CURVE_BLEND_FACTOR if s_curve else 0.0,
            current_pos=start_pos,
            current_vel=0.0,
            is_active=True,
            is_complete=False,
            phase="accel",
            elapsed=0.0,
            direction=direction,
        )
        self._states[motor_id] = state

    def update(self, motor_id: MotorID, dt: float) -> float:
        """
        궤적 업데이트 / Update trajectory.

        현재 단계에 따라 위치/속도를 계산.

        Args:
            motor_id: 모터 식별자
            dt: 시간 간격 (초)

        Returns:
            현재 목표 위치 (rad)
        """
        if motor_id not in self._states:
            return 0.0

        state = self._states[motor_id]
        if not state.is_active or state.is_complete:
            return state.current_pos

        state.elapsed += dt
        distance = abs(state.end_pos - state.start_pos)

        # 사다리꼴/S-커브 궤적 계산 / Trapezoidal/S-curve trajectory
        # 가속 시간, 등속 시간, 감속 시간 계산
        t_accel = state.max_vel / state.max_accel
        d_accel = 0.5 * state.max_accel * t_accel ** 2

        # S-커브 블렌딩 적용 / Apply S-curve blending
        if state.blend_factor > 0:
            # S-커브: 가속/감속 구간을 코사인으로 블렌딩
            t_accel_adjusted = t_accel * (1.0 + state.blend_factor)
            d_accel = state.max_vel * t_accel_adjusted * 0.5

        if 2 * d_accel > distance:
            # 삼각 프로파일 (등속 구간 없음) / Triangular profile
            d_accel = distance / 2.0
            t_accel = math.sqrt(2.0 * d_accel / state.max_accel)
            t_cruise = 0.0
        else:
            d_cruise = distance - 2 * d_accel
            t_cruise = d_cruise / state.max_vel

        t_total = 2 * t_accel + t_cruise

        # 현재 시간 기준 위치 계산 / Calculate position based on elapsed time
        t = state.elapsed
        if t < t_accel:
            # 가속 구간 / Acceleration phase
            if state.blend_factor > 0 and t_accel > 0:
                # S-커브: 코사인 블렌딩 / S-curve: cosine blending
                progress = t / t_accel
                s = 0.5 * (1.0 - math.cos(math.pi * progress))
                pos = state.start_pos + state.direction * d_accel * s
            else:
                # 사다리꼴: 선형 가속 / Trapezoidal: linear acceleration
                pos = state.start_pos + state.direction * 0.5 * state.max_accel * t ** 2
            state.phase = "accel"
        elif t < t_accel + t_cruise:
            # 등속 구간 / Cruise phase
            t_in_cruise = t - t_accel
            pos = (state.start_pos +
                   state.direction * d_accel +
                   state.direction * state.max_vel * t_in_cruise)
            state.phase = "cruise"
        elif t < t_total:
            # 감속 구간 / Deceleration phase
            t_in_decel = t - t_accel - t_cruise
            if state.blend_factor > 0 and t_accel > 0:
                progress = t_in_decel / t_accel
                s = 0.5 * (1.0 + math.cos(math.pi * progress))
                pos = (state.end_pos - state.direction * d_accel * (1.0 - s))
            else:
                pos = (state.end_pos -
                       state.direction * 0.5 * state.max_accel * (t_total - t) ** 2)
            state.phase = "decel"
        else:
            # 완료 / Complete
            pos = state.end_pos
            state.is_complete = True
            state.is_active = False
            state.phase = "done"

        state.current_pos = pos
        return pos

    def is_complete(self, motor_id: MotorID) -> bool:
        """궤적 완료 여부 / Check if trajectory is complete."""
        if motor_id not in self._states:
            return True
        return self._states[motor_id].is_complete

    def get_phase(self, motor_id: MotorID) -> str:
        """현재 궤적 단계 조회 / Get current trajectory phase."""
        if motor_id not in self._states:
            return "idle"
        return self._states[motor_id].phase


# ============================================================================
# SimpleFOC 컨트롤러 V8.5
# ============================================================================

class SimpleFOCController:
    """
    SimpleFOC Mini I2C 통신 컨트롤러 V8.5 AGI

    6개의 SimpleFOC Mini 드라이버를 I2C 버스로 제어:
      - 4x 휠: 속도 제어 모드 (100Hz)
      - 2x 다리: 위치 제어 모드 (100Hz)

    V8.5 AGI 신규 기능:
      - FOC (Field-Oriented Control) 구현 (FOController)
      - 토크 제어 모드 (TorqueController)
      - 부드러운 궤적 생성 (TrajectoryGenerator)

    V8.5 기존 기능:
      - I2C 오류 복구: 재시도, 버스 리셋, 오류율 추적
      - 엔코더 건전성: 정지/급변/분산 검사
      - FOC 교정 검증: 전원 온 시 자동 교정 확인
      - 과온도 제한: 온도 기반 출력 제한

    ⚠️ DRV8313 전류 한계 (2.5A/phase) 주의
    """

    def __init__(
        self,
        i2c_bus: int = I2C_BUS,
        i2c_speed_khz: int = I2C_SPEED_KHZ,
    ) -> None:
        self._i2c_bus = i2c_bus
        self._i2c_speed_khz = i2c_speed_khz
        self._i2c_handle: Optional[object] = None
        self._motors: Dict[MotorID, MotorState] = {}
        self._lock = threading.Lock()
        self._running = False
        self._control_thread: Optional[threading.Thread] = None
        self._control_frequency_hz: float = CONTROL_LOOP_HZ

        # Instance-local copy of I2C addresses
        self._i2c_addresses: Dict[MotorID, int] = dict(MOTOR_I2C_ADDRESSES)

        # V8.5: I2C 오류 추적
        self._i2c_error_history: deque = deque(maxlen=I2C_ERROR_WINDOW_SIZE)

        # V8.5 AGI: FOC 제어기 / V8.5 AGI: FOC controller
        self._foc = FOController()

        # V8.5 AGI: 토크 제어기 / V8.5 AGI: Torque controller
        self._torque_ctrl = TorqueController()

        # V8.5 AGI: 궤적 생성기 / V8.5 AGI: Trajectory generator
        self._traj_gen = TrajectoryGenerator()

        # 모터 상태 초기화
        for motor_id, i2c_addr in self._i2c_addresses.items():
            mode = ControlMode.POSITION if "lift" in motor_id.value else ControlMode.VELOCITY
            state = MotorState(
                motor_id=motor_id,
                i2c_address=i2c_addr,
                mode=mode,
            )
            # V8.5: 모터별 상태 초기화
            state.encoder_health.motor_id = motor_id
            state.foc_status.motor_id = motor_id
            state.thermal.motor_id = motor_id
            self._motors[motor_id] = state

        logger.info(
            "SimpleFOC V8.5 컨트롤러 초기화 — I2C 버스 %d, %dkHz, 모터 %d개",
            i2c_bus, i2c_speed_khz, len(self._motors),
        )

        # ⚠️ 전류 경고 로그
        logger.warning(
            "⚠️ SimpleFOC Mini (DRV8313) 상당 최대 전류: %.1fA/phase — "
            "BOM의 10A는 오류. 대안: B-G431B-ESC1 (%.1fA) 또는 ODrive S1 (%.1fA)",
            DRV8313_MAX_CURRENT_A,
            ALTERNATIVE_DRIVERS["B-G431B-ESC1"]["continuous_a"],
            ALTERNATIVE_DRIVERS["ODrive_S1"]["continuous_a"],
        )

    # ========================================================================
    # 초기화 및 연결
    # ========================================================================

    def connect(self) -> bool:
        """
        I2C 버스 연결 및 모터 스캔

        V8.5: 연결 시 FOC 교정 상태 확인 추가.

        Returns:
            연결 성공 여부
        """
        try:
            import smbus2
            self._i2c_handle = smbus2.SMBus(self._i2c_bus)
        except ImportError:
            logger.error("smbus2 패키지 미설치 — pip install smbus2")
            return False
        except Exception as e:
            logger.error("I2C 버스 %d 열기 실패: %s", self._i2c_bus, e)
            return False

        # 모터 스캔
        found = 0
        for motor_id, state in self._motors.items():
            if self._ping(state.i2c_address):
                found += 1
                logger.info("모터 발견 — %s (0x%02X)", motor_id.value, state.i2c_address)
                # V8.5: FOC 교정 상태 확인
                self._check_foc_calibration(motor_id)
            else:
                logger.warning("모터 응답 없음 — %s (0x%02X)", motor_id.value, state.i2c_address)

        if found == 0:
            logger.error("모든 모터 응답 없음 — I2C 연결 확인 필요")
            return False

        logger.info("SimpleFOC V8.5 연결 완료 — %d/%d 모터 인식", found, len(self._motors))
        return True

    def disconnect(self) -> None:
        """I2C 버스 연결 해제"""
        if self._i2c_handle is not None:
            try:
                self._i2c_handle.close()
            except Exception:
                pass
            self._i2c_handle = None
        logger.info("SimpleFOC V8.5 연결 해제")

    def _ping(self, address: int) -> bool:
        """I2C 장치 핑 (상태 레지스터 읽기)"""
        return self._i2c_read_byte_with_retry(address, REG_STATUS) is not None

    # ========================================================================
    # V8.5: I2C 통신 오류 복구
    # ========================================================================

    def _i2c_read_byte_with_retry(self, address: int, register: int) -> Optional[int]:
        """
        V8.5: 재시도가 포함된 I2C 1바이트 읽기 / I2C read with retry.

        오류 발생 시:
        1. 최대 I2C_MAX_RETRIES 회 재시도
        2. 연속 오류 누적 시 I2C 버스 리셋
        """
        for attempt in range(I2C_MAX_RETRIES):
            try:
                if self._i2c_handle is None:
                    return None
                result = self._i2c_handle.read_byte_data(address, register)
                # 성공 시 오류 통계 업데이트
                self._record_i2c_success(address)
                return result
            except Exception as e:
                self._record_i2c_error(address, str(e))
                if attempt < I2C_MAX_RETRIES - 1:
                    time.sleep(I2C_RECOVERY_DELAY_S * (attempt + 1))

        # 모든 재시도 실패 → 버스 리셋 시도
        self._attempt_i2c_bus_reset(address)
        return None

    def _i2c_read_float_with_retry(self, address: int, register: int) -> Optional[float]:
        """
        V8.5: 재시도가 포함된 I2C float 읽기 / I2C float read with retry.
        """
        for attempt in range(I2C_MAX_RETRIES):
            try:
                if self._i2c_handle is None:
                    return None
                data = self._i2c_handle.read_i2c_block_data(address, register, 4)
                result = struct.unpack("<f", bytes(data))[0]
                # NaN/Inf 체크 (통신 오류 시 발생 가능)
                if not math.isfinite(result):
                    raise ValueError(f"Non-finite float: {result}")
                self._record_i2c_success(address)
                return result
            except Exception as e:
                self._record_i2c_error(address, str(e))
                if attempt < I2C_MAX_RETRIES - 1:
                    time.sleep(I2C_RECOVERY_DELAY_S * (attempt + 1))

        return None

    def _i2c_write_with_retry(self, address: int, register: int, data: list) -> bool:
        """
        V8.5: 재시도가 포함된 I2C 쓰기 / I2C write with retry.
        """
        import math as _math  # ensure available

        for attempt in range(I2C_MAX_RETRIES):
            try:
                if self._i2c_handle is None:
                    return False
                self._i2c_handle.write_i2c_block_data(address, register, data)
                self._record_i2c_success(address)
                return True
            except Exception as e:
                self._record_i2c_error(address, str(e))
                if attempt < I2C_MAX_RETRIES - 1:
                    time.sleep(I2C_RECOVERY_DELAY_S * (attempt + 1))

        self._attempt_i2c_bus_reset(address)
        return False

    def _record_i2c_error(self, address: int, error_type: str) -> None:
        """I2C 오류 기록 / Record I2C error."""
        motor_id = self._address_to_motor_id(address)
        if motor_id is None:
            return

        state = self._motors[motor_id]
        state.i2c_errors.total_errors += 1
        state.i2c_errors.consecutive_errors += 1
        state.i2c_errors.last_error_time = time.monotonic()
        state.i2c_errors.last_error_type = error_type

        # 오류율 계산
        self._i2c_error_history.append(False)
        total = len(self._i2c_error_history)
        errors = sum(1 for x in self._i2c_error_history if not x)
        state.i2c_errors.error_rate = errors / total if total > 0 else 0.0

        if state.i2c_errors.consecutive_errors >= I2C_CONSECUTIVE_ERROR_LIMIT:
            logger.error(
                "I2C 연속 오류 한계 초과 — %s: %d회 연속 실패",
                motor_id.value, state.i2c_errors.consecutive_errors,
            )

    def _record_i2c_success(self, address: int) -> None:
        """I2C 성공 기록 / Record I2C success."""
        motor_id = self._address_to_motor_id(address)
        if motor_id is None:
            return

        state = self._motors[motor_id]
        state.i2c_errors.consecutive_errors = 0

        self._i2c_error_history.append(True)

    def _attempt_i2c_bus_reset(self, trigger_address: int) -> None:
        """
        I2C 버스 리셋 시도 / Attempt I2C bus reset.

        연속 오류가 한계를 초과하면 버스를 재초기화.
        """
        motor_id = self._address_to_motor_id(trigger_address)
        if motor_id is None:
            return

        state = self._motors[motor_id]
        logger.warning(
            "I2C 버스 리셋 시도 — 트리거: %s (0x%02X)",
            motor_id.value, trigger_address,
        )

        try:
            # 기존 핸들 닫기
            if self._i2c_handle is not None:
                try:
                    self._i2c_handle.close()
                except Exception:
                    pass

            time.sleep(I2C_BUS_RESET_DELAY_S)

            # 버스 재열기
            import smbus2
            self._i2c_handle = smbus2.SMBus(self._i2c_bus)
            state.i2c_errors.bus_resets += 1
            state.i2c_errors.consecutive_errors = 0
            logger.info("I2C 버스 리셋 성공")
        except Exception as e:
            logger.error("I2C 버스 리셋 실패: %s", e)

    # ========================================================================
    # V8.5: 엔코더 건전성 검사
    # ========================================================================

    def _check_encoder_health(self, motor_id: MotorID) -> EncoderHealth:
        """
        V8.5: 엔코더 건전성 검사 / Motor encoder health check.

        검사 항목:
        1. 정지 감지: 엔코더 값이 연속적으로 변하지 않음
        2. 급변 감지: 엔코더 값이 비정상적으로 큰 폭으로 변화
        3. 분산 검사: 윈도우 내 분산이 너무 낮으면 비정상

        Returns:
            EncoderHealth 건전성 상태
        """
        state = self._motors[motor_id]
        health = state.encoder_health
        current_encoder = state.encoder_raw

        # 1. 정지 감지 (연속 동일값)
        if health.consecutive_same_count >= ENCODER_STUCK_THRESHOLD:
            # 모터가 구동 중인데 엔코더가 변하지 않음 → 고장
            if abs(state.target) > 0.01:
                health.stuck_detected = True
                health.is_healthy = False
                logger.error(
                    "엔코더 정지 감지 — %s: %d회 연속 동일값 (target=%.2f)",
                    motor_id.value, health.consecutive_same_count, state.target,
                )
            else:
                health.stuck_detected = False

        # 2. 급변 감지
        if hasattr(self, '_prev_encoder'):
            prev = self._prev_encoder.get(motor_id, current_encoder)
            jump = abs(current_encoder - prev)
            if jump > ENCODER_JUMP_THRESHOLD:
                health.jump_detected = True
                health.last_jump_magnitude = jump
                health.is_healthy = False
                logger.warning(
                    "엔코더 급변 감지 — %s: Δ=%d (임계: %d)",
                    motor_id.value, jump, ENCODER_JUMP_THRESHOLD,
                )
            else:
                health.jump_detected = False

        if not hasattr(self, '_prev_encoder'):
            self._prev_encoder: Dict[MotorID, int] = {}
        self._prev_encoder[motor_id] = current_encoder

        health.last_check_time = time.monotonic()
        return health

    # ========================================================================
    # V8.5: FOC 교정 검증
    # ========================================================================

    def _check_foc_calibration(self, motor_id: MotorID) -> FOCCalibrationStatus:
        """
        V8.5: FOC 교정 상태 확인 / FOC calibration verification.

        SimpleFOC Mini의 FOC 교정이 완료되었는지 확인.
        교정 미완료 시 자동 교정 명령 전송.

        Returns:
            FOCCalibrationStatus 교정 상태
        """
        state = self._motors[motor_id]
        foc = state.foc_status
        addr = state.i2c_address

        # 교정 상태 레지스터 읽기
        cal_byte = self._i2c_read_byte_with_retry(addr, REG_FOC_CALIBRATION)

        if cal_byte is not None:
            # 0x01 = 교정 완료, 0x00 = 미교정
            foc.is_calibrated = bool(cal_byte & 0x01)
            foc.calibration_score = (cal_byte & 0xFE) / 254.0  # 상위 7비트 = 점수
        else:
            # 레지스터 읽기 실패 → 교정 필요로 간주
            foc.needs_recalibration = True

        if not foc.is_calibrated:
            logger.info(
                "FOC 교정 필요 — %s: 자동 교정 시작", motor_id.value,
            )
            self._run_foc_calibration(motor_id)

        foc.last_calibration_time = time.monotonic()
        return foc

    def _run_foc_calibration(self, motor_id: MotorID) -> bool:
        """
        V8.5: FOC 교정 실행 / Run FOC calibration.

        교정 명령 전송 후 완료 대기.
        """
        state = self._motors[motor_id]
        foc = state.foc_status
        addr = state.i2c_address

        for attempt in range(FOC_CALIBRATION_RETRIES + 1):
            foc.calibration_attempts += 1

            # 교정 명령 전송 (레지스터 0x30에 0x01 쓰기)
            try:
                if self._i2c_handle is not None:
                    self._i2c_handle.write_byte_data(addr, REG_FOC_CALIBRATION, 0x01)
            except Exception as e:
                logger.error("FOC 교정 명령 전송 실패 — %s: %s", motor_id.value, e)
                continue

            # 교정 완료 대기
            start = time.monotonic()
            while time.monotonic() - start < FOC_CALIBRATION_TIMEOUT_S:
                cal_byte = self._i2c_read_byte_with_retry(addr, REG_FOC_CALIBRATION)
                if cal_byte is not None and (cal_byte & 0x01):
                    foc.is_calibrated = True
                    foc.needs_recalibration = False
                    logger.info(
                        "FOC 교정 완료 — %s (시도 %d, %.1f초)",
                        motor_id.value, attempt + 1, time.monotonic() - start,
                    )
                    return True
                time.sleep(0.1)

            logger.warning(
                "FOC 교정 타임아웃 — %s (시도 %d/%d)",
                motor_id.value, attempt + 1, FOC_CALIBRATION_RETRIES + 1,
            )

        foc.needs_recalibration = True
        logger.error("FOC 교정 실패 — %s: 최대 재시도 초과", motor_id.value)
        return False

    # ========================================================================
    # V8.5: 과온도 출력 제한 (Overtemperature Derating)
    # ========================================================================

    def _update_thermal_derating(self, motor_id: MotorID) -> ThermalDerating:
        """
        V8.5: 과온도 제한 업데이트 / Update thermal derating.

        온도에 따라 모터 출력을 선형적으로 제한.
        TEMP_DERATE_START_C 이상에서 제한 시작,
        TEMP_SHUTDOWN_C 이상에서 셧다운.

        Returns:
            ThermalDerating 제한 상태
        """
        state = self._motors[motor_id]
        thermal = state.thermal
        addr = state.i2c_address

        # 온도 읽기 시도 (지원하지 않으면 추정)
        temp_raw = self._i2c_read_float_with_retry(addr, REG_TEMPERATURE)
        if temp_raw is not None and -20.0 <= temp_raw <= 150.0:
            thermal.current_temp_c = temp_raw
        else:
            # 온도 센서 미지원 → 전류 기반 간접 추정
            # 대략: I²R 발열 모델
            current = state.phase_current_a
            ambient = 25.0
            heating = current ** 2 * 5.0  # 간소화된 발열 모델
            thermal.current_temp_c = min(ambient + heating, 120.0)

        temp = thermal.current_temp_c

        # 제한 계수 계산 / Calculate derating factor
        if temp >= TEMP_SHUTDOWN_C:
            derate = 0.0
            thermal.is_shutdown = True
            logger.critical(
                "모터 과열 셧다운 — %s: %.1f°C (임계: %.1f°C)",
                motor_id.value, temp, TEMP_SHUTDOWN_C,
            )
        elif temp >= TEMP_CRITICAL_C:
            derate = TEMP_DERATE_MIN_FACTOR
            logger.warning(
                "모터 과열 위험 — %s: %.1f°C", motor_id.value, temp,
            )
        elif temp >= TEMP_DERATE_START_C:
            # 선형 제한
            derate = 1.0 - (1.0 - TEMP_DERATE_MIN_FACTOR) * (
                (temp - TEMP_DERATE_START_C) / (TEMP_CRITICAL_C - TEMP_DERATE_START_C)
            )
            thermal.warning_active = True
            logger.info(
                "모터 과열 제한 — %s: %.1f°C, 계수=%.2f",
                motor_id.value, temp, derate,
            )
        else:
            derate = 1.0
            thermal.is_shutdown = False
            thermal.warning_active = temp >= TEMP_WARNING_C

        thermal.derate_factor = derate
        return thermal

    def set_torque(self, address: int, torque_nm: float) -> None:
        """
        V8.5 AGI: 토크 제어 명령 전송 / Send torque control command.

        목표 토크를 설정하고 FOC를 통해 q축 전류를 계산.

        Args:
            address: I2C 주소
            torque_nm: 목표 토크 (N·m)
        """
        motor_id = self._address_to_motor_id(address)
        if motor_id is None:
            return

        # 과열 셧다운 확인
        if self._motors[motor_id].thermal.is_shutdown:
            logger.warning("과열 쉴다운 — %s: 토크 명령 거부", motor_id.value)
            return

        # 토크 제어 모드로 전환
        with self._lock:
            self._i2c_write_byte(address, REG_MODE, int(ControlMode.TORQUE))
            self._motors[motor_id].mode = ControlMode.TORQUE

        # 목표 토크 설정
        self._torque_ctrl.set_target_torque(motor_id, torque_nm)

        # FOC를 통해 q축 전류 계산
        iq_target = self._torque_ctrl.compute_iq_target(motor_id)

        # I2C로 목표 전류 전송
        with self._lock:
            self._i2c_write_float(address, REG_TARGET, iq_target)
        self._update_motor_state(address, target=iq_target)

        logger.info("토크 제어 명령 — %s: %.3fN·m → Iq=%.2fA", motor_id.value, torque_nm, iq_target)

    def start_trajectory(
        self,
        address: int,
        start_pos: float,
        end_pos: float,
        max_vel: float = 5.0,
        max_accel: float = TRAJ_DEFAULT_ACCEL_RAD_S2,
        s_curve: bool = True,
    ) -> None:
        """
        V8.5 AGI: 궤적 생성 시작 / Start trajectory generation.

        사다리꼴 또는 S-커브 궤적 프로파일로 부드러운 이동.

        Args:
            address: I2C 주소
            start_pos: 시작 위치 (rad)
            end_pos: 목표 위치 (rad)
            max_vel: 최대 속도 (rad/s)
            max_accel: 최대 가속도 (rad/s²)
            s_curve: True=S-커브, False=사다리꼴
        """
        motor_id = self._address_to_motor_id(address)
        if motor_id is None:
            return

        self._traj_gen.start(motor_id, start_pos, end_pos, max_vel, max_accel, s_curve)
        logger.info(
            "궤적 시작 — %s: %.2f→%.2frad, 최대속도=%.1frad/s, S-커브=%s",
            motor_id.value, start_pos, end_pos, max_vel, s_curve,
        )

    def get_foc_controller(self) -> FOController:
        """V8.5 AGI: FOC 제어기 조회 / Get FOC controller."""
        return self._foc

    def get_torque_controller(self) -> TorqueController:
        """V8.5 AGI: 토크 제어기 조회 / Get torque controller."""
        return self._torque_ctrl

    def get_trajectory_generator(self) -> TrajectoryGenerator:
        """V8.5 AGI: 궤적 생성기 조회 / Get trajectory generator."""
        return self._traj_gen

    # ========================================================================
    # 제어 명령
    # ========================================================================

    def set_velocity(self, address: int, velocity: float) -> None:
        """
        속도 제어 명령 전송

        V8.5: 과온도 제한 적용.

        Args:
            address: I2C 주소 (0x10-0x15)
            velocity: 목표 속도 (rad/s)
        """
        motor_id = self._address_to_motor_id(address)
        if motor_id is not None:
            # V8.5: 과온도 제한 확인
            state = self._motors[motor_id]
            if state.thermal.is_shutdown:
                logger.warning("과열 셧다운 — %s: 속도 명령 거부", motor_id.value)
                velocity = 0.0
            else:
                velocity *= state.thermal.derate_factor

            if "wheel" in motor_id.value:
                max_vel = 628.0
            else:
                max_vel = 100.0
        else:
            max_vel = 100.0

        velocity = max(-max_vel, min(max_vel, velocity))

        with self._lock:
            self._i2c_write_float(address, REG_TARGET, velocity)
        self._update_motor_state(address, target=velocity)

    def set_position(self, address: int, position: float) -> None:
        """
        위치 제어 명령 전송

        V8.5: 과온도 제한 적용.

        Args:
            address: I2C 주소 (0x14, 0x15)
            position: 목표 위치 (rad)
        """
        motor_id = self._address_to_motor_id(address)
        if motor_id is not None:
            state = self._motors[motor_id]
            if state.thermal.is_shutdown:
                logger.warning("과열 셧다운 — %s: 위치 명령 거부", motor_id.value)
                return

        position = max(-10.0, min(10.0, position))

        with self._lock:
            self._i2c_write_float(address, REG_TARGET, position)
        self._update_motor_state(address, target=position)

    def read_encoder(self, address: int) -> int:
        """
        엔코더 값 읽기

        V8.5: 건전성 검사 포함.

        Args:
            address: I2C 주소

        Returns:
            엔코더 원시값 (PPR 기반)
        """
        try:
            if self._i2c_handle is None:
                raise IOError("I2C 미연결")

            data = self._i2c_handle.read_i2c_block_data(address, REG_ENCODER, 2)
            encoder_val = struct.unpack(">H", bytes(data))[0]

            self._update_motor_state(address, encoder_raw=encoder_val)

            # V8.5: 엔코더 건전성 검사
            motor_id = self._address_to_motor_id(address)
            if motor_id is not None:
                self._check_encoder_health(motor_id)

            return encoder_val

        except Exception as e:
            logger.error("엔코더 읽기 실패 (0x%02X): %s", address, e)
            return -1

    def set_address(self, old_address: int, new_address: int) -> bool:
        """I2C 주소 변경"""
        if not 0x08 <= new_address <= 0x77:
            logger.error("유효하지 않은 I2C 주소: 0x%02X (범위: 0x08-0x77)", new_address)
            return False

        try:
            self._i2c_write_byte(old_address, REG_ADDRESS, new_address)
            motor_id = self._address_to_motor_id(old_address)
            if motor_id is not None:
                self._motors[motor_id].i2c_address = new_address
                self._i2c_addresses[motor_id] = new_address
            logger.info("I2C 주소 변경: 0x%02X → 0x%02X", old_address, new_address)
            return True
        except Exception as e:
            logger.error("I2C 주소 변경 실패: %s", e)
            return False

    def set_control_mode(self, address: int, mode: ControlMode) -> None:
        """제어 모드 변경"""
        with self._lock:
            self._i2c_write_byte(address, REG_MODE, int(mode))
            motor_id = self._address_to_motor_id(address)
            if motor_id is not None:
                self._motors[motor_id].mode = mode
        logger.info("제어 모드 변경 (0x%02X): %s", address, mode.name)

    def set_pid_gains(
        self, address: int, kp: float, ki: float, kd: float
    ) -> None:
        """PID 게인 설정"""
        with self._lock:
            self._i2c_write_float(address, REG_PID_KP, kp)
            self._i2c_write_float(address, REG_PID_KI, ki)
            self._i2c_write_float(address, REG_PID_KD, kd)
        logger.info("PID 게인 설정 (0x%02X): Kp=%.2f, Ki=%.2f, Kd=%.2f", address, kp, ki, kd)

    # ========================================================================
    # 상태 조회
    # ========================================================================

    def get_motor_state(self, motor_id: MotorID) -> Optional[MotorState]:
        """특정 모터 상태 조회"""
        with self._lock:
            return self._motors.get(motor_id)

    def get_all_states(self) -> Dict[MotorID, MotorState]:
        """모든 모터 상태 조회"""
        with self._lock:
            return dict(self._motors)

    def read_all_feedback(self) -> None:
        """
        모든 모터 피드백 갱신 (100Hz 루프용)

        V8.5: I2C 재시도, 엔코더 건전성, 열 관리 통합.
        """
        with self._lock:
            for motor_id, state in self._motors.items():
                try:
                    addr = state.i2c_address

                    # 속도 피드백 읽기 (V8.5: 재시도 포함)
                    vel = self._i2c_read_float_with_retry(addr, REG_VELOCITY)
                    if vel is not None:
                        state.current_velocity = vel

                    # 위치 피드백 읽기
                    pos = self._i2c_read_float_with_retry(addr, REG_POSITION)
                    if pos is not None:
                        state.current_position = pos

                    # 상전류 읽기 (과전류 감시)
                    current = self._i2c_read_float_with_retry(addr, REG_CURRENT)
                    if current is not None:
                        state.phase_current_a = current
                        if current > DRV8313_MAX_CURRENT_A:
                            logger.warning(
                                "⚠️ 과전류 감지 — %s (0x%02X): %.2fA "
                                "(DRV8313 한계: %.1fA)",
                                motor_id.value, addr, current,
                                DRV8313_MAX_CURRENT_A,
                            )

                    # 상태 레지스터 읽기
                    status_byte = self._i2c_read_byte_with_retry(addr, REG_STATUS)
                    if status_byte is not None:
                        state.status = DriverStatus(status_byte)

                    # V8.5: 엔코더 건전성 검사
                    self._check_encoder_health(motor_id)

                    # V8.5: 과온도 제한 업데이트
                    self._update_thermal_derating(motor_id)

                    state.last_update_s = time.monotonic()

                except Exception as e:
                    logger.error("피드백 읽기 실패 — %s: %s", motor_id.value, e)
                    # V8.5: 오류 기록
                    self._record_i2c_error(state.i2c_address, str(e))

    # ========================================================================
    # 제어 루프 (백그라운드 스레드)
    # ========================================================================

    def start_control_loop(self, frequency_hz: Optional[float] = None) -> None:
        """
        백그라운드 피드백 읽기 루프 시작

        V8.5: 시작 시 FOC 교정 확인.
        """
        if self._running:
            logger.warning("제어 루프 이미 실행 중")
            return

        if frequency_hz is not None:
            self._control_frequency_hz = frequency_hz

        # V8.5: 시작 시 FOC 교정 확인
        for motor_id in self._motors:
            self._check_foc_calibration(motor_id)

        self._running = True
        self._control_thread = threading.Thread(
            target=self._control_loop,
            daemon=True,
            name="simplefoc-control-v84",
        )
        self._control_thread.start()
        logger.info(
            "SimpleFOC V8.5 제어 루프 시작: %.1fHz",
            self._control_frequency_hz,
        )

    def stop_control_loop(self) -> None:
        """백그라운드 제어 루프 중지"""
        self._running = False
        if self._control_thread is not None:
            self._control_thread.join(timeout=2.0)
            self._control_thread = None
        logger.info("SimpleFOC V8.5 제어 루프 중지")

    def _control_loop(self) -> None:
        """백그라운드 피드백 루프"""
        period = 1.0 / self._control_frequency_hz
        while self._running:
            start = time.monotonic()
            self.read_all_feedback()
            elapsed = time.monotonic() - start
            sleep_time = period - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)

    # ========================================================================
    # I2C 저수준 통신 (기존 + V8.5 재시도 래퍼)
    # ========================================================================

    def _i2c_write_float(self, address: int, register: int, value: float) -> None:
        """I2C 4바이트 float 쓰기 (V8.5: 재시도 포함)"""
        if self._i2c_handle is None:
            raise IOError("I2C 미연결")
        data = list(struct.pack("<f", value))
        self._i2c_write_with_retry(address, register, data)

    def _i2c_read_float(self, address: int, register: int) -> Optional[float]:
        """I2C 4바이트 float 읽기 (V8.5: 재시도 래퍼 사용)"""
        return self._i2c_read_float_with_retry(address, register)

    def _i2c_write_byte(self, address: int, register: int, value: int) -> None:
        """I2C 1바이트 쓰기"""
        if self._i2c_handle is None:
            raise IOError("I2C 미연결")
        try:
            self._i2c_handle.write_byte_data(address, register, value)
        except Exception as e:
            self._record_i2c_error(address, str(e))
            raise

    def _i2c_read_byte(self, address: int, register: int) -> Optional[int]:
        """I2C 1바이트 읽기 (V8.5: 재시도 래퍼 사용)"""
        return self._i2c_read_byte_with_retry(address, register)

    # ========================================================================
    # 내부 유틸리티
    # ========================================================================

    def _address_to_motor_id(self, address: int) -> Optional[MotorID]:
        """I2C 주소 → 모터 ID 역조회"""
        for motor_id, addr in self._i2c_addresses.items():
            if addr == address:
                return motor_id
        return None

    def _update_motor_state(
        self,
        address: int,
        target: Optional[float] = None,
        encoder_raw: Optional[int] = None,
    ) -> None:
        """모터 상태 내부 업데이트"""
        motor_id = self._address_to_motor_id(address)
        if motor_id is None:
            return
        with self._lock:
            state = self._motors[motor_id]
            if target is not None:
                state.target = target
            if encoder_raw is not None:
                state.encoder_raw = encoder_raw
            state.last_update_s = time.monotonic()

    # ========================================================================
    # V8.5: 진단 확장
    # ========================================================================

    def get_i2c_diagnostics(self) -> Dict[str, Dict]:
        """V8.5: I2C 통신 진단 정보 / Get I2C communication diagnostics."""
        result = {}
        with self._lock:
            for motor_id, state in self._motors.items():
                result[motor_id.value] = {
                    "total_errors": state.i2c_errors.total_errors,
                    "consecutive_errors": state.i2c_errors.consecutive_errors,
                    "bus_resets": state.i2c_errors.bus_resets,
                    "error_rate": round(state.i2c_errors.error_rate, 4),
                    "last_error": state.i2c_errors.last_error_type,
                }
        return result

    def get_encoder_diagnostics(self) -> Dict[str, Dict]:
        """V8.5: 엔코더 건전성 진단 정보 / Get encoder health diagnostics."""
        result = {}
        with self._lock:
            for motor_id, state in self._motors.items():
                h = state.encoder_health
                result[motor_id.value] = {
                    "is_healthy": h.is_healthy,
                    "stuck_detected": h.stuck_detected,
                    "jump_detected": h.jump_detected,
                    "consecutive_same": h.consecutive_same_count,
                }
        return result

    def get_thermal_diagnostics(self) -> Dict[str, Dict]:
        """V8.5: 열 관리 진단 정보 / Get thermal management diagnostics."""
        result = {}
        with self._lock:
            for motor_id, state in self._motors.items():
                t = state.thermal
                result[motor_id.value] = {
                    "temperature_c": round(t.current_temp_c, 1),
                    "derate_factor": round(t.derate_factor, 3),
                    "is_shutdown": t.is_shutdown,
                    "warning_active": t.warning_active,
                }
        return result

    def get_foc_diagnostics(self) -> Dict[str, Dict]:
        """V8.5: FOC 교정 진단 정보 / Get FOC calibration diagnostics."""
        result = {}
        with self._lock:
            for motor_id, state in self._motors.items():
                f = state.foc_status
                result[motor_id.value] = {
                    "is_calibrated": f.is_calibrated,
                    "calibration_score": round(f.calibration_score, 3),
                    "attempts": f.calibration_attempts,
                    "needs_recalibration": f.needs_recalibration,
                }
        return result
