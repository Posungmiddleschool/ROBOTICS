#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — 로드셀 시스템 (Load Cell System)
==================================================

HX711 ×4 + 5kg 로드셀 → 무게 중심 계산 → 과적재 경고
UART 통신 10Hz, 교정계수 ≈2280

아키텍처 / Architecture:
  - HX711 ×4: 5kg 로드셀 (전방좌/우, 후방좌/우)
  - UART-to-SPI 브릿지: Jetson#2 UART #2 경유 (BOM 사양)
  - 무게 중심 (CG) 계산: 4점 지지 방식
  - 과적재 경고: 12kg 경고, 15kg 최대 적재

물리 파라미터 / Physical Parameters:
  - 로드셀 용량: 5kg × 4 = 20kg 총 용량
  - 교정계수: ≈2280 (1kg 표준추 기준)
  - 측정 오차: <5%
  - CG 편차: <30%
  - 플랫폼 크기: 200mm × 150mm

안전 / Safety:
  - 최대 적재: 15kg
  - 과적재 경고: 12kg
  - IMU 경고: 기울기 >15° → 속도 30%

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import struct
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V8.5.LoadCell")

# ============================================================================
# 상수 정의 (Constants)
# ============================================================================

# HX711 파라미터 / HX711 parameters
HX711_MODEL: str = "HX711"
HX711_COUNT: int = 4
HX711_UART_PORT: str = "/dev/ttyUSB1"   # UART #2 (BOM 사양)
HX711_BAUDRATE: int = 9600
HX711_SAMPLE_RATE_HZ: int = 10          # 10Hz 샘플링
HX711_DEFAULT_CALIBRATION: float = 2280.0  # 교정계수 (1kg 기준)

# 로드셀 파라미터 / Load cell parameters
LOAD_CELL_CAPACITY_KG: float = 5.0      # 단일 로드셀 용량
LOAD_CELL_TOTAL_CAPACITY_KG: float = 20.0  # 4개 합산

# 무게 제한 / Weight limits
MAX_PAYLOAD_KG: float = 15.0            # 최대 적재 / Max payload
OVERLOAD_WARNING_KG: float = 12.0       # 과적재 경고 / Overload warning
OVERLOAD_CRITICAL_KG: float = 15.0      # 과적재 위험 / Overload critical

# 측정 정확도 / Measurement accuracy
WEIGHT_ERROR_TOLERANCE_PCT: float = 5.0  # 무게 오차 허용 (%)
CG_DEVIATION_TOLERANCE_PCT: float = 30.0 # CG 편차 허용 (%)

# 플랫폼 치수 / Platform dimensions (mm)
PLATFORM_WIDTH_MM: float = 200.0        # 폭 (좌→우)
PLATFORM_DEPTH_MM: float = 150.0        # 깊이 (전→후)

# 로드셀 위치 (플랫폼 기준) / Load cell positions relative to platform center
LOAD_CELL_POSITIONS: Dict[str, Tuple[float, float]] = {
    "fl": (+PLATFORM_DEPTH_MM / 4, +PLATFORM_WIDTH_MM / 4),   # 전방 좌
    "fr": (+PLATFORM_DEPTH_MM / 4, -PLATFORM_WIDTH_MM / 4),   # 전방 우
    "rl": (-PLATFORM_DEPTH_MM / 4, +PLATFORM_WIDTH_MM / 4),   # 후방 좌
    "rr": (-PLATFORM_DEPTH_MM / 4, -PLATFORM_WIDTH_MM / 4),   # 후방 우
}

# 필터링 / Filtering
MOVING_AVERAGE_WINDOW: int = 5          # 이동평균 윈도우 크기
OUTLIER_REJECTION_SIGMA: float = 3.0    # 이상치 제거 시그마


# ============================================================================
# 열거형 (Enumerations)
# ============================================================================

class LoadCellState(Enum):
    """로드셀 상태 / Load cell state"""
    UNCALIBRATED = "uncalibrated"   # 미교정
    CALIBRATING = "calibrating"     # 교정 중
    READY = "ready"                 # 측정 준비
    MEASURING = "measuring"         # 측정 중
    OVERLOAD_WARNING = "overload_warning"  # 과적재 경고
    OVERLOAD_CRITICAL = "overload_critical"  # 과적재 위험
    FAULT = "fault"                 # 오류


class WeightAlertLevel(Enum):
    """무게 경고 수준 / Weight alert level"""
    NORMAL = "normal"           # 정상
    WARNING = "warning"         # 과적재 경고 (>12kg)
    CRITICAL = "critical"       # 과적재 위험 (>15kg)
    DANGEROUS = "dangerous"     # 위험 (>20kg)


# ============================================================================
# 데이터 클래스 (Data Classes)
# ============================================================================

@dataclass
class LoadCellReading:
    """단일 로드셀 판독값 / Single load cell reading"""
    channel: str = ""
    raw_value: int = 0               # HX711 원시값 (24비트)
    weight_kg: float = 0.0           # 변환된 무게 (kg)
    is_valid: bool = True
    timestamp: float = field(default_factory=time.monotonic)


@dataclass
class WeightData:
    """무게 측정 데이터 / Weight measurement data"""
    total_weight_kg: float = 0.0      # 총 무게
    per_cell_kg: Dict[str, float] = field(default_factory=lambda: {
        "fl": 0.0, "fr": 0.0, "rl": 0.0, "rr": 0.0
    })
    cg_x_mm: float = 0.0             # 무게 중심 X (mm)
    cg_y_mm: float = 0.0             # 무게 중심 Y (mm)
    cg_deviation_pct: float = 0.0    # CG 편차 (%)
    alert_level: WeightAlertLevel = WeightAlertLevel.NORMAL
    is_overload: bool = False
    timestamp: float = field(default_factory=time.monotonic)


@dataclass
class CalibrationData:
    """교정 데이터 / Calibration data"""
    zero_offsets: Dict[str, int] = field(default_factory=lambda: {
        "fl": 0, "fr": 0, "rl": 0, "rr": 0
    })
    scale_factors: Dict[str, float] = field(default_factory=lambda: {
        "fl": HX711_DEFAULT_CALIBRATION,
        "fr": HX711_DEFAULT_CALIBRATION,
        "rl": HX711_DEFAULT_CALIBRATION,
        "rr": HX711_DEFAULT_CALIBRATION,
    })
    calibration_weight_kg: float = 1.0  # 기준 무게 (1kg)
    is_calibrated: bool = False
    calibration_time: float = 0.0


# ============================================================================
# LoadCellSystem 클래스
# ============================================================================

class LoadCellSystem:
    """
    화물 플랫폼 로드셀 시스템 / Cargo Platform Load Cell System.

    HX711 ×4 + 5kg 로드셀로 무게 및 무게 중심 측정.
    UART-to-SPI 브릿지 경유 Jetson#2 통신.

    Features:
    - 4채널 HX711 로드셀 10Hz 측정
    - 무게 중심 (CG) 실시간 계산
    - 과적재 경고 (12kg 경고, 15kg 위험)
    - 1kg 표준추 자동 교정
    - 이동평균 필터링 + 이상치 제거

    Usage:
        lcs = LoadCellSystem()
        lcs.start()
        weight = lcs.read_weight()            # 총 무게 (kg)
        cg = lcs.get_center_of_gravity()      # 무게 중심
        lcs.calibrate(1.0)                    # 1kg 표준추 교정
        lcs.check_overload()                  # 과적재 확인
        lcs.stop()
    """

    def __init__(
        self,
        uart_port: str = HX711_UART_PORT,
        baudrate: int = HX711_BAUDRATE,
        simulation_mode: bool = True,
    ):
        """
        로드셀 시스템 초기화 / Initialize load cell system.

        Args:
            uart_port: HX711 UART-to-SPI 브릿지 포트
            baudrate: UART 통신 속도
            simulation_mode: 시뮬레이션 모드
        """
        self._uart_port = uart_port
        self._baudrate = baudrate
        self._simulation = simulation_mode
        self._serial = None
        self._lock = threading.Lock()
        self._running = False

        # 로드셀 판독값 / Load cell readings
        self._readings: Dict[str, LoadCellReading] = {
            name: LoadCellReading(channel=name) for name in LOAD_CELL_POSITIONS
        }

        # 이동평균 버퍼 / Moving average buffers
        self._weight_buffers: Dict[str, deque] = {
            name: deque(maxlen=MOVING_AVERAGE_WINDOW)
            for name in LOAD_CELL_POSITIONS
        }

        # 교정 데이터 / Calibration data
        self._calibration = CalibrationData()

        # 최근 무게 데이터 / Latest weight data
        self._latest_weight = WeightData()

        # 과적재 콜백 / Overload callbacks
        self._warning_callback: Optional[Callable] = None
        self._critical_callback: Optional[Callable] = None

        # UART 수신 스레드 / UART receive thread
        self._rx_thread: Optional[threading.Thread] = None

        # 통계 / Statistics
        self._sample_count: int = 0
        self._overload_events: int = 0

        logger.info("LoadCellSystem 초기화 완료 / Init complete "
                     f"(simulation={simulation_mode})")

    # ── 시작/중지 / Start/Stop ──

    def start(self) -> bool:
        """로드셀 측정 시작 / Start load cell measurement."""
        if self._running:
            return True

        if not self._simulation:
            try:
                import serial
                self._serial = serial.Serial(
                    port=self._uart_port,
                    baudrate=self._baudrate,
                    timeout=0.5,
                )
            except Exception as e:
                logger.warning(f"UART 연결 실패: {e}")
                self._simulation = True

        self._running = True
        self._rx_thread = threading.Thread(
            target=self._measurement_loop, daemon=True,
            name="LoadCell_Measurement"
        )
        self._rx_thread.start()

        logger.info("LoadCellSystem 측정 시작 / Measurement started")
        return True

    def stop(self) -> None:
        """로드셀 측정 중지 / Stop load cell measurement."""
        self._running = False
        if self._rx_thread and self._rx_thread.is_alive():
            self._rx_thread.join(timeout=1.0)
        if self._serial and self._serial.is_open:
            self._serial.close()
        logger.info("LoadCellSystem 측정 중지 / Measurement stopped")

    # ── 측정 루프 / Measurement Loop ──

    def _measurement_loop(self) -> None:
        """10Hz 로드셀 측정 루프 / 10Hz load cell measurement loop."""
        dt = 1.0 / HX711_SAMPLE_RATE_HZ

        while self._running:
            if self._simulation:
                self._simulate_measurement()
            else:
                self._read_hx711_uart()

            # 무게 중심 계산 / Calculate center of gravity
            self._calculate_weight_and_cg()

            # 과적재 확인 / Check overload
            self._check_overload_internal()

            self._sample_count += 1
            time.sleep(dt)

    def _simulate_measurement(self) -> None:
        """시뮬레이션 측정값 생성 / Generate simulated measurements."""
        # 이전 측정값 기반 약간의 변동 / Slight variation based on previous
        for name in LOAD_CELL_POSITIONS:
            prev = self._readings[name].weight_kg
            noise = (hash(f"{name}{time.monotonic_ns()}") % 100 - 50) / 10000.0
            weight = max(0.0, prev + noise)
            self._readings[name].weight_kg = weight
            self._readings[name].raw_value = int(
                weight * self._calibration.scale_factors[name]
                + self._calibration.zero_offsets[name]
            )
            self._readings[name].timestamp = time.monotonic()

    def _read_hx711_uart(self) -> None:
        """UART를 통해 HX711 원시값 읽기 / Read HX711 raw via UART."""
        try:
            if not self._serial or not self._serial.is_open:
                return

            # 채널별 순차 읽기 / Sequential channel read
            for name, ch_id in [("fl", 0), ("fr", 1), ("rl", 2), ("rr", 3)]:
                # 채널 선택 명령 / Channel select command
                self._serial.write(bytes([0xAA, ch_id, 0x55]))
                resp = self._serial.read(4)

                if len(resp) == 4:
                    raw = (resp[1] << 16) | (resp[2] << 8) | resp[3]
                    if raw & 0x800000:
                        raw -= 0x1000000

                    self._readings[name].raw_value = raw
                    self._readings[name].is_valid = True
                    self._readings[name].timestamp = time.monotonic()
                else:
                    self._readings[name].is_valid = False

        except Exception as e:
            logger.debug(f"HX711 UART 읽기 오류: {e}")

    # ── 무게 및 CG 계산 / Weight and CG Calculation ──

    def _calculate_weight_and_cg(self) -> None:
        """무게 및 무게 중심 계산 / Calculate weight and center of gravity."""
        total_weight = 0.0
        weighted_x = 0.0
        weighted_y = 0.0
        per_cell = {}

        for name in LOAD_CELL_POSITIONS:
            # 교정 적용 / Apply calibration
            raw = self._readings[name].raw_value
            offset = self._calibration.zero_offsets.get(name, 0)
            scale = self._calibration.scale_factors.get(name, HX711_DEFAULT_CALIBRATION)

            if scale != 0:
                weight_kg = (raw - offset) / scale
            else:
                weight_kg = 0.0

            # 음수 무게 방지 / Prevent negative weight
            weight_kg = max(0.0, weight_kg)

            # 이동평균 버퍼 추가 / Add to moving average buffer
            self._weight_buffers[name].append(weight_kg)

            # 이상치 제거 + 이동평균 / Outlier rejection + moving average
            filtered = self._filter_weight(name)
            per_cell[name] = filtered

            # CG 계산을 위한 가중합 / Weighted sum for CG calculation
            pos = LOAD_CELL_POSITIONS[name]
            total_weight += filtered
            weighted_x += filtered * pos[0]
            weighted_y += filtered * pos[1]

            self._readings[name].weight_kg = filtered

        # 무게 중심 계산 / Calculate center of gravity
        if total_weight > 0.01:
            cg_x = weighted_x / total_weight
            cg_y = weighted_y / total_weight
        else:
            cg_x = 0.0
            cg_y = 0.0

        # CG 편차 (%): 플랫폼 중심에서 벗어난 정도
        max_offset = math.sqrt(
            (PLATFORM_WIDTH_MM / 2) ** 2 + (PLATFORM_DEPTH_MM / 2) ** 2
        )
        cg_deviation = (math.sqrt(cg_x ** 2 + cg_y ** 2) / max_offset * 100
                        if max_offset > 0 else 0.0)

        # 경고 수준 판정 / Determine alert level
        if total_weight >= MAX_PAYLOAD_KG:
            alert = WeightAlertLevel.CRITICAL
        elif total_weight >= OVERLOAD_WARNING_KG:
            alert = WeightAlertLevel.WARNING
        else:
            alert = WeightAlertLevel.NORMAL

        self._latest_weight = WeightData(
            total_weight_kg=round(total_weight, 3),
            per_cell_kg={k: round(v, 3) for k, v in per_cell.items()},
            cg_x_mm=round(cg_x, 1),
            cg_y_mm=round(cg_y, 1),
            cg_deviation_pct=round(cg_deviation, 1),
            alert_level=alert,
            is_overload=total_weight >= OVERLOAD_WARNING_KG,
            timestamp=time.monotonic(),
        )

    def _filter_weight(self, name: str) -> float:
        """
        이동평균 + 이상치 제거 필터 / Moving average + outlier rejection filter.

        Args:
            name: 채널명

        Returns:
            필터링된 무게 (kg)
        """
        buffer = self._weight_buffers[name]
        if not buffer:
            return 0.0

        values = list(buffer)

        # 이상치 제거 (3σ) / Outlier rejection (3σ)
        if len(values) >= 3:
            mean = sum(values) / len(values)
            std = math.sqrt(sum((v - mean) ** 2 for v in values) / len(values))
            if std > 0:
                filtered = [v for v in values
                            if abs(v - mean) < OUTLIER_REJECTION_SIGMA * std]
                if filtered:
                    return sum(filtered) / len(filtered)

        # 이동평균 / Moving average
        return sum(values) / len(values)

    # ── 공개 메서드 / Public Methods ──

    def read_weight(self) -> float:
        """
        총 무게 측정 / Read total weight.

        Returns:
            총 무게 (kg)
        """
        with self._lock:
            return self._latest_weight.total_weight_kg

    def calibrate(self, known_weight_kg: float = 1.0) -> bool:
        """
        로드셀 교정 / Calibrate load cells.

        1kg 표준추를 올려놓고 영점 및 계수 보정.

        Args:
            known_weight_kg: 기준 무게 (kg), 기본 1kg

        Returns:
            교정 성공 여부
        """
        logger.info(f"로드셀 교정 시작: 기준무게={known_weight_kg}kg")

        # 1단계: 영점 조절 (무부하 상태) / Step 1: Tare (no load)
        logger.info("1단계: 영점 조절 — 무부하 상태에서 측정")
        zero_raw = {}
        for name in LOAD_CELL_POSITIONS:
            readings = []
            for _ in range(10):
                raw = self._readings[name].raw_value
                readings.append(raw)
                time.sleep(0.01)
            zero_raw[name] = int(sum(readings) / len(readings))

        self._calibration.zero_offsets = zero_raw

        # 2단계: 기준 무게 측정 / Step 2: Measure with known weight
        logger.info(f"2단계: 기준 무게 {known_weight_kg}kg 측정 — 추를 올려주세요")
        # 실제 구현에서는 사용자 입력 대기
        # 여기서는 시뮬레이션으로 진행
        time.sleep(0.5)

        loaded_raw = {}
        for name in LOAD_CELL_POSITIONS:
            readings = []
            for _ in range(10):
                raw = self._readings[name].raw_value
                readings.append(raw)
                time.sleep(0.01)
            loaded_raw[name] = int(sum(readings) / len(readings))

        # 3단계: 교정계수 계산 / Step 3: Calculate calibration factors
        for name in LOAD_CELL_POSITIONS:
            diff = loaded_raw[name] - zero_raw[name]
            if abs(diff) > 0:
                self._calibration.scale_factors[name] = \
                    abs(diff) / known_weight_kg
            else:
                self._calibration.scale_factors[name] = HX711_DEFAULT_CALIBRATION

        self._calibration.calibration_weight_kg = known_weight_kg
        self._calibration.is_calibrated = True
        self._calibration.calibration_time = time.monotonic()

        logger.info("로드셀 교정 완료 / Calibration complete")
        for name in LOAD_CELL_POSITIONS:
            logger.info(f"  {name}: offset={zero_raw[name]}, "
                         f"scale={self._calibration.scale_factors[name]:.1f}")

        return True

    def get_center_of_gravity(self) -> Tuple[float, float, float]:
        """
        무게 중심 조회 / Get center of gravity.

        Returns:
            (cg_x_mm, cg_y_mm, cg_deviation_pct) 튜플
        """
        with self._lock:
            return (
                self._latest_weight.cg_x_mm,
                self._latest_weight.cg_y_mm,
                self._latest_weight.cg_deviation_pct,
            )

    def check_overload(self) -> WeightAlertLevel:
        """
        과적재 상태 확인 / Check overload status.

        Returns:
            WeightAlertLevel 경고 수준
        """
        with self._lock:
            return self._latest_weight.alert_level

    def get_weight_data(self) -> WeightData:
        """
        전체 무게 데이터 조회 / Get complete weight data.

        Returns:
            WeightData 전체 측정 데이터
        """
        with self._lock:
            return self._latest_weight

    # ── 과적재 콜백 / Overload Callbacks ──

    def set_warning_callback(self, callback: Callable) -> None:
        """과적재 경고 콜백 설정 / Set overload warning callback."""
        self._warning_callback = callback

    def set_critical_callback(self, callback: Callable) -> None:
        """과적재 위험 콜백 설정 / Set overload critical callback."""
        self._critical_callback = callback

    def _check_overload_internal(self) -> None:
        """내부 과적재 확인 및 콜백 호출 / Internal overload check and callback."""
        weight = self._latest_weight.total_weight_kg
        alert = self._latest_weight.alert_level

        if alert == WeightAlertLevel.CRITICAL:
            self._overload_events += 1
            logger.warning(f"과적재 위험! {weight:.1f}kg / OVERLOAD CRITICAL!")
            if self._critical_callback:
                try:
                    self._critical_callback(weight)
                except Exception:
                    pass
        elif alert == WeightAlertLevel.WARNING:
            logger.warning(f"과적재 경고: {weight:.1f}kg / Overload warning")
            if self._warning_callback:
                try:
                    self._warning_callback(weight)
                except Exception:
                    pass

    # ── 진단 / Diagnostics ──

    def get_diagnostics(self) -> Dict[str, Any]:
        """로드셀 진단 정보 / Get load cell diagnostics."""
        with self._lock:
            return {
                "total_weight_kg": self._latest_weight.total_weight_kg,
                "per_cell_kg": dict(self._latest_weight.per_cell_kg),
                "cg_x_mm": self._latest_weight.cg_x_mm,
                "cg_y_mm": self._latest_weight.cg_y_mm,
                "cg_deviation_pct": self._latest_weight.cg_deviation_pct,
                "alert_level": self._latest_weight.alert_level.value,
                "is_calibrated": self._calibration.is_calibrated,
                "calibration_factors": dict(self._calibration.scale_factors),
                "sample_count": self._sample_count,
                "overload_events": self._overload_events,
            }

    def tare(self) -> bool:
        """
        영점 조절 (현재 무게를 0으로) / Tare (zero current weight).

        Returns:
            영점 조절 성공 여부
        """
        logger.info("영점 조절 실행 / Tare")
        for name in LOAD_CELL_POSITIONS:
            self._calibration.zero_offsets[name] = self._readings[name].raw_value
        return True
