#!/usr/bin/env python3
"""
crossmodal_encoder.py — V8.5 Cross-Modal Alignment Encoder (CLIP-style)
지훈 로봇 물리적 AGI — V8.5 크로스모달 정렬 인코더 (CLIP 스타일)

A physical AGI must understand the correspondence between what it sees,
what it feels, and what forces it experiences. CLIP-style contrastive
learning aligns visual, tactile, and force embeddings into a shared
latent space where cross-modal retrieval becomes possible.

물리적 AGI는 보는 것, 느끼는 것, 경험하는 힘 사이의 대응 관계를
이해해야 합니다. CLIP 스타일 대조 학습은 시각, 촉각, 힘 임베딩을
공유 잠재 공간에 정렬하여 크로스모달 검색을 가능하게 합니다.

Components / 구성요소:
  1. VisualEncoder     — 시각 특징 인코더 (FC+Conv, 512-dim)
  2. TactileEncoder    — 촉각 특징 인코더 (FC, 512-dim)
  3. ForceEncoder      — 힘 특징 인코더 (FC, 512-dim)
  4. CrossModalAlignment — 크로스모달 정렬 (InfoNCE 손실)

Alignment Algorithm / 정렬 알고리즘:
  - InfoNCE loss: 대조 학습으로 모달리티 간 정렬
  - Temperature scaling: 소프트맥스 온도 조절
  - Symmetric loss: 양방향 정렬

InfoNCE Loss:
  L = -log(exp(sim(v_i, t_i)/τ) / Σ_j exp(sim(v_i, t_j)/τ))

Hardware: Dual Jetson Orin NX 16GB
AI Model: Gemma 4 E4B Q4_K_M
Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np

# ─── PyTorch 선택적 임포트 / Optional PyTorch Import ─────────────────────────

TORCH_AVAILABLE = False
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.utils.data import DataLoader, Dataset
    TORCH_AVAILABLE = True
except ImportError:
    torch = None
    nn = None
    F = None
    DataLoader = None
    Dataset = None

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.crossmodal_encoder")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 상수 / Constants ────────────────────────────────────────────────────────

EMBED_DIM = 512           # 공유 임베딩 차원 / Shared embedding dimension
VISUAL_INPUT_DIM = 256    # 시각 입력 차원 / Visual input dimension (from vision backbone)
TACTILE_INPUT_DIM = 64    # 촉각 입력 차원 (16 센서 × 4 채널)
FORCE_INPUT_DIM = 12      # 힘 입력 차원 (6축 FT × 2)
HIDDEN_DIM = 256          # 은닉층 차원 / Hidden dimension
DEFAULT_TEMPERATURE = 0.07  # InfoNCE 온도 / InfoNCE temperature
EPS = 1e-8


# ─── 데이터 클래스 / Data Classes ────────────────────────────────────────────


@dataclass
class MultimodalObservation:
    """
    다중 모달 관측 / Multi-modal observation.

    로봇의 시각, 촉각, 힘 센서 데이터를 하나로 묶습니다.

    Attributes:
        visual: 시각 특징 벡터 (256-dim)
        tactile: 촉각 데이터 벡터 (64-dim)
        force: 힘/토크 벡터 (12-dim)
        timestamp: 관측 시각
        metadata: 추가 메타데이터
    """
    visual: np.ndarray = field(default_factory=lambda: np.zeros(VISUAL_INPUT_DIM))
    tactile: np.ndarray = field(default_factory=lambda: np.zeros(TACTILE_INPUT_DIM))
    force: np.ndarray = field(default_factory=lambda: np.zeros(FORCE_INPUT_DIM))
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AlignmentRecord:
    """
    정렬 기록 / Alignment record.

    크로스모달 정렬 학습의 결과를 기록합니다.
    """
    record_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    visual_tactile_loss: float = 0.0
    visual_force_loss: float = 0.0
    tactile_force_loss: float = 0.0
    total_loss: float = 0.0
    temperature: float = DEFAULT_TEMPERATURE
    batch_size: int = 0
    epoch: int = 0
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ─── PyTorch 인코더 / PyTorch Encoders ───────────────────────────────────────

if TORCH_AVAILABLE:

    class VisualEncoder(nn.Module):
        """
        시각 특징 인코더 / Visual feature encoder.

        FC + Conv 레이어를 사용하여 시각 특징을 512차원 임베딩으로
        인코딩합니다. 입력은 비전 백본에서 추출된 특징 벡터입니다.

        Architecture:
          Input (256) → Conv1d → FC(256) → ReLU → FC(512) → L2 Normalize

        Args:
            input_dim: 입력 차원 (비전 백본 출력)
            embed_dim: 출력 임베딩 차원
            hidden_dim: 은닉층 차원
        """

        def __init__(
            self,
            input_dim: int = VISUAL_INPUT_DIM,
            embed_dim: int = EMBED_DIM,
            hidden_dim: int = HIDDEN_DIM,
        ) -> None:
            super().__init__()
            self.input_dim = input_dim
            self.embed_dim = embed_dim

            # 1D 합성곱: 지역적 특징 추출 / 1D Conv: local feature extraction
            self.conv = nn.Sequential(
                nn.Conv1d(1, 32, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.Conv1d(32, 64, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.AdaptiveAvgPool1d(input_dim),
            )

            # 완전연결 레이어 / Fully connected layers
            self.fc = nn.Sequential(
                nn.Linear(input_dim * 64, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_dim, embed_dim),
            )

            # 가중치 초기화 / Weight initialization
            self._init_weights()

            logger.debug(
                "VisualEncoder 생성: input=%d, embed=%d", input_dim, embed_dim
            )

        def _init_weights(self) -> None:
            """가중치 초기화 / Initialize weights."""
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    nn.init.xavier_uniform_(module.weight)
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)
                elif isinstance(module, nn.Conv1d):
                    nn.init.kaiming_normal_(module.weight, mode="fan_out")

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            """
            순전파 / Forward pass.

            Args:
                x: 시각 특징 [batch, input_dim]

            Returns:
                L2 정규화된 임베딩 [batch, embed_dim]
            """
            # Conv1d 입력을 위해 채널 차원 추가 / Add channel dim for Conv1d
            h = x.unsqueeze(1)  # [batch, 1, input_dim]
            h = self.conv(h)     # [batch, 64, input_dim]
            h = h.reshape(h.size(0), -1)  # [batch, 64 * input_dim]
            h = self.fc(h)       # [batch, embed_dim]

            # L2 정규화 / L2 normalize
            h = F.normalize(h, p=2, dim=-1)
            return h

    class TactileEncoder(nn.Module):
        """
        촉각 특징 인코더 / Tactile feature encoder.

        FC 레이어를 사용하여 촉각 센서 데이터를 512차원 임베딩으로
        인코딩합니다. 16개 센서 × 4채널 = 64차원 입력을 처리합니다.

        Architecture:
          Input (64) → FC(128) → ReLU → FC(256) → ReLU → FC(512) → L2 Normalize

        Args:
            input_dim: 입력 차원 (촉각 센서 데이터)
            embed_dim: 출력 임베딩 차원
            hidden_dim: 은닉층 차원
        """

        def __init__(
            self,
            input_dim: int = TACTILE_INPUT_DIM,
            embed_dim: int = EMBED_DIM,
            hidden_dim: int = HIDDEN_DIM,
        ) -> None:
            super().__init__()
            self.input_dim = input_dim
            self.embed_dim = embed_dim

            self.fc = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, embed_dim),
            )

            self._init_weights()

            logger.debug(
                "TactileEncoder 생성: input=%d, embed=%d", input_dim, embed_dim
            )

        def _init_weights(self) -> None:
            """가중치 초기화 / Initialize weights."""
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    nn.init.xavier_uniform_(module.weight)
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            """
            순전파 / Forward pass.

            Args:
                x: 촉각 데이터 [batch, input_dim]

            Returns:
                L2 정규화된 임베딩 [batch, embed_dim]
            """
            h = self.fc(x)
            h = F.normalize(h, p=2, dim=-1)
            return h

    class ForceEncoder(nn.Module):
        """
        힘 특징 인코더 / Force feature encoder.

        FC 레이어를 사용하여 힘/토크 센서 데이터를 512차원 임베딩으로
        인코딩합니다. 6축 FT 센서 × 2개 = 12차원 입력을 처리합니다.

        Architecture:
          Input (12) → FC(64) → ReLU → FC(128) → ReLU → FC(256) → ReLU → FC(512) → L2 Normalize

        Args:
            input_dim: 입력 차원 (힘/토크 데이터)
            embed_dim: 출력 임베딩 차원
            hidden_dim: 은닉층 차원
        """

        def __init__(
            self,
            input_dim: int = FORCE_INPUT_DIM,
            embed_dim: int = EMBED_DIM,
            hidden_dim: int = HIDDEN_DIM,
        ) -> None:
            super().__init__()
            self.input_dim = input_dim
            self.embed_dim = embed_dim

            self.fc = nn.Sequential(
                nn.Linear(input_dim, 64),
                nn.ReLU(),
                nn.Linear(64, 128),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(128, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, embed_dim),
            )

            self._init_weights()

            logger.debug(
                "ForceEncoder 생성: input=%d, embed=%d", input_dim, embed_dim
            )

        def _init_weights(self) -> None:
            """가중치 초기화 / Initialize weights."""
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    nn.init.xavier_uniform_(module.weight)
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            """
            순전파 / Forward pass.

            Args:
                x: 힘/토크 데이터 [batch, input_dim]

            Returns:
                L2 정규화된 임베딩 [batch, embed_dim]
            """
            h = self.fc(x)
            h = F.normalize(h, p=2, dim=-1)
            return h


# ─── Numpy 폴백 인코더 / Numpy Fallback Encoders ────────────────────────────


class NumpyEncoderBase:
    """
    Numpy 기반 인코더 기반 클래스 / Numpy-based encoder base class.

    torch를 사용할 수 없는 환경에서의 인코더 구현입니다.
    """

    def __init__(
        self,
        input_dim: int,
        embed_dim: int = EMBED_DIM,
        hidden_dim: int = HIDDEN_DIM,
    ) -> None:
        self.input_dim = input_dim
        self.embed_dim = embed_dim
        self.hidden_dim = hidden_dim

        # 간소화된 가중치 초기화 / Simplified weight initialization
        scale = 0.02
        self.w1 = np.random.randn(input_dim, hidden_dim).astype(np.float32) * scale
        self.b1 = np.zeros(hidden_dim, dtype=np.float32)
        self.w2 = np.random.randn(hidden_dim, embed_dim).astype(np.float32) * scale
        self.b2 = np.zeros(embed_dim, dtype=np.float32)

    def forward(self, x: np.ndarray) -> np.ndarray:
        """순전파 / Forward pass."""
        x = np.asarray(x, dtype=np.float32)
        if x.ndim == 1:
            x = x.reshape(1, -1)

        h = x @ self.w1 + self.b1
        h = np.maximum(h, 0)  # ReLU
        h = h @ self.w2 + self.b2

        # L2 정규화 / L2 normalize
        norms = np.linalg.norm(h, axis=1, keepdims=True)
        norms = np.maximum(norms, EPS)
        h = h / norms
        return h


class NumpyVisualEncoder(NumpyEncoderBase):
    """Numpy 시각 인코더 / Numpy visual encoder."""

    def __init__(self, input_dim: int = VISUAL_INPUT_DIM, embed_dim: int = EMBED_DIM) -> None:
        super().__init__(input_dim, embed_dim)


class NumpyTactileEncoder(NumpyEncoderBase):
    """Numpy 촉각 인코더 / Numpy tactile encoder."""

    def __init__(self, input_dim: int = TACTILE_INPUT_DIM, embed_dim: int = EMBED_DIM) -> None:
        super().__init__(input_dim, embed_dim)


class NumpyForceEncoder(NumpyEncoderBase):
    """Numpy 힘 인코더 / Numpy force encoder."""

    def __init__(self, input_dim: int = FORCE_INPUT_DIM, embed_dim: int = EMBED_DIM) -> None:
        super().__init__(input_dim, embed_dim)


# ─── 크로스모달 정렬 / Cross-Modal Alignment ────────────────────────────────


class CrossModalAlignment:
    """
    크로스모달 정렬 시스템 / Cross-modal alignment system.

    CLIP 스타일 대조 학습을 사용하여 시각, 촉각, 힘 임베딩을
    공유 잠재 공간에 정렬합니다. InfoNCE 손실로 양방향 정렬을 수행합니다.

    정렬 후에는 한 모달리티의 임베딩으로 다른 모달리티의 경험을
    검색할 수 있습니다 (예: 시각으로 촉각 경험 검색).

    InfoNCE Loss:
      L_{v→t} = -log(exp(sim(v_i, t_i)/τ) / Σ_j exp(sim(v_i, t_j)/τ))
      L_{t→v} = -log(exp(sim(t_i, v_i)/τ) / Σ_j exp(sim(t_i, v_j)/τ))
      L = (L_{v→t} + L_{t→v}) / 2

    Usage:
        alignment = CrossModalAlignment()
        # 학습
        loss = alignment.align_modality_pairs(visual_data, tactile_data, force_data)
        # 검색
        tactile_results = alignment.retrieve_crossmodal(query_visual, "tactile")
    """

    def __init__(
        self,
        embed_dim: int = EMBED_DIM,
        temperature: float = DEFAULT_TEMPERATURE,
        device: Optional[str] = None,
    ) -> None:
        self._embed_dim = embed_dim
        self._temperature = temperature
        self._use_torch = TORCH_AVAILABLE

        if self._use_torch:
            if device is None:
                self._device = torch.device(
                    "cuda" if torch.cuda.is_available() else "cpu"
                )
            else:
                self._device = torch.device(device)

            # 인코더 생성 / Create encoders
            self._visual_encoder = VisualEncoder(embed_dim=embed_dim).to(self._device)
            self._tactile_encoder = TactileEncoder(embed_dim=embed_dim).to(self._device)
            self._force_encoder = ForceEncoder(embed_dim=embed_dim).to(self._device)

            # 옵티마이저 / Optimizer
            self._optimizer = torch.optim.Adam(
                list(self._visual_encoder.parameters()) +
                list(self._tactile_encoder.parameters()) +
                list(self._force_encoder.parameters()),
                lr=1e-3,
            )

            # 학습 가능한 온도 파라미터 / Learnable temperature parameter
            self._log_temp = nn.Parameter(
                torch.tensor(math.log(temperature), dtype=torch.float32)
            )
        else:
            self._device = None
            self._visual_encoder = NumpyVisualEncoder(embed_dim=embed_dim)
            self._tactile_encoder = NumpyTactileEncoder(embed_dim=embed_dim)
            self._force_encoder = NumpyForceEncoder(embed_dim=embed_dim)
            self._optimizer = None
            self._log_temp = None

        # 임베딩 저장소 (검색용) / Embedding store (for retrieval)
        self._stored_embeddings: Dict[str, List[np.ndarray]] = {
            "visual": [],
            "tactile": [],
            "force": [],
        }
        self._stored_metadata: List[Dict[str, Any]] = []

        self._training_step = 0
        self._lock = threading.Lock()

        logger.info(
            "CrossModalAlignment 초기화: embed=%d, temp=%.3f, torch=%s, device=%s",
            embed_dim, temperature, self._use_torch, self._device,
        )

    @property
    def temperature(self) -> float:
        """현재 온도 값 / Current temperature value."""
        if self._use_torch and self._log_temp is not None:
            return float(self._log_temp.exp().item())
        return self._temperature

    def contrastive_loss(
        self,
        embedding_a: Any,
        embedding_b: Any,
        temperature: Optional[float] = None,
    ) -> Any:
        """
        InfoNCE 대조 손실 계산 / Compute InfoNCE contrastive loss.

        두 모달리티의 임베딩 쌍에 대해 대조 손실을 계산합니다.
        대응하는 쌍은 가깝게, 비대응 쌍은 멀게 만듭니다.

        Args:
            embedding_a: 첫 번째 모달리티 임베딩 [batch, embed_dim]
            embedding_b: 두 번째 모달리티 임베딩 [batch, embed_dim]
            temperature: 온도 파라미터 (None=학습 가능)

        Returns:
            손실 값 (torch.Tensor 또는 float)
        """
        if self._use_torch and TORCH_AVAILABLE:
            return self._contrastive_loss_torch(embedding_a, embedding_b, temperature)
        return self._contrastive_loss_numpy(embedding_a, embedding_b, temperature)

    def _contrastive_loss_torch(
        self,
        emb_a: torch.Tensor,
        emb_b: torch.Tensor,
        temperature: Optional[float] = None,
    ) -> torch.Tensor:
        """
        PyTorch InfoNCE 손실 / PyTorch InfoNCE loss.
        """
        # 임베딩은 이미 L2 정규화됨 / Embeddings already L2-normalized
        # 코사인 유사도 = 내적 / Cosine similarity = dot product
        logits = emb_a @ emb_b.T  # [batch, batch]

        if temperature is not None:
            temp = temperature
        else:
            temp = self._log_temp.exp()

        logits = logits / temp

        # 라벨: 대각선이 정답 / Labels: diagonal is correct
        batch_size = logits.shape[0]
        labels = torch.arange(batch_size, device=logits.device)

        # 양방향 손실 / Symmetric loss
        loss_a_to_b = F.cross_entropy(logits, labels)
        loss_b_to_a = F.cross_entropy(logits.T, labels)

        return (loss_a_to_b + loss_b_to_a) / 2.0

    def _contrastive_loss_numpy(
        self,
        emb_a: np.ndarray,
        emb_b: np.ndarray,
        temperature: Optional[float] = None,
    ) -> float:
        """
        Numpy InfoNCE 손실 / Numpy InfoNCE loss.
        """
        temp = temperature or self._temperature

        # 코사인 유사도 / Cosine similarity
        sim_matrix = emb_a @ emb_b.T / temp

        batch_size = sim_matrix.shape[0]

        # 소프트맥스 / Softmax
        def _softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
            x_max = np.max(x, axis=axis, keepdims=True)
            exp_x = np.exp(x - x_max)
            return exp_x / np.sum(exp_x, axis=axis, keepdims=True)

        # a → b 손실 / a → b loss
        probs_a_to_b = _softmax(sim_matrix, axis=1)
        loss_a_to_b = -np.mean(np.log(probs_a_to_b[np.arange(batch_size), np.arange(batch_size)] + EPS))

        # b → a 손실 / b → a loss
        probs_b_to_a = _softmax(sim_matrix.T, axis=1)
        loss_b_to_a = -np.mean(np.log(probs_b_to_a[np.arange(batch_size), np.arange(batch_size)] + EPS))

        return float((loss_a_to_b + loss_b_to_a) / 2.0)

    def encode_visual(self, visual_data: Any) -> Any:
        """
        시각 데이터 인코딩 / Encode visual data.

        Args:
            visual_data: 시각 특징 [batch, visual_dim]

        Returns:
            임베딩 [batch, embed_dim]
        """
        if self._use_torch and TORCH_AVAILABLE:
            with torch.no_grad():
                x = torch.tensor(visual_data, dtype=torch.float32, device=self._device)
                return self._visual_encoder(x).cpu().numpy()
        return self._visual_encoder.forward(np.asarray(visual_data, dtype=np.float32))

    def encode_tactile(self, tactile_data: Any) -> Any:
        """
        촉각 데이터 인코딩 / Encode tactile data.

        Args:
            tactile_data: 촉각 데이터 [batch, tactile_dim]

        Returns:
            임베딩 [batch, embed_dim]
        """
        if self._use_torch and TORCH_AVAILABLE:
            with torch.no_grad():
                x = torch.tensor(tactile_data, dtype=torch.float32, device=self._device)
                return self._tactile_encoder(x).cpu().numpy()
        return self._tactile_encoder.forward(np.asarray(tactile_data, dtype=np.float32))

    def encode_force(self, force_data: Any) -> Any:
        """
        힘 데이터 인코딩 / Encode force data.

        Args:
            force_data: 힘/토크 데이터 [batch, force_dim]

        Returns:
            임베딩 [batch, embed_dim]
        """
        if self._use_torch and TORCH_AVAILABLE:
            with torch.no_grad():
                x = torch.tensor(force_data, dtype=torch.float32, device=self._device)
                return self._force_encoder(x).cpu().numpy()
        return self._force_encoder.forward(np.asarray(force_data, dtype=np.float32))

    def align_modality_pairs(
        self,
        visual_data: Any,
        tactile_data: Any,
        force_data: Any,
    ) -> Dict[str, float]:
        """
        모달리티 쌍 정렬 학습 / Align modality pairs.

        시각-촉각, 시각-힘, 촉각-힘 쌍에 대해 InfoNCE 손실로
        공유 잠재 공간에 정렬합니다.

        Args:
            visual_data: 시각 데이터 [batch, visual_dim]
            tactile_data: 촉각 데이터 [batch, tactile_dim]
            force_data: 힘 데이터 [batch, force_dim]

        Returns:
            Dict: 손실 메트릭
        """
        if self._use_torch and TORCH_AVAILABLE:
            return self._align_torch(visual_data, tactile_data, force_data)
        return self._align_numpy(visual_data, tactile_data, force_data)

    def _align_torch(
        self,
        visual_data: Any,
        tactile_data: Any,
        force_data: Any,
    ) -> Dict[str, float]:
        """PyTorch 기반 정렬 / PyTorch-based alignment."""
        v = torch.tensor(visual_data, dtype=torch.float32, device=self._device)
        t = torch.tensor(tactile_data, dtype=torch.float32, device=self._device)
        f = torch.tensor(force_data, dtype=torch.float32, device=self._device)

        # 인코딩 / Encode
        v_emb = self._visual_encoder(v)
        t_emb = self._tactile_encoder(t)
        f_emb = self._force_encoder(f)

        # 대조 손실 / Contrastive losses
        loss_vt = self._contrastive_loss_torch(v_emb, t_emb)
        loss_vf = self._contrastive_loss_torch(v_emb, f_emb)
        loss_tf = self._contrastive_loss_torch(t_emb, f_emb)

        # 총 손실 / Total loss
        total_loss = loss_vt + loss_vf + loss_tf

        # 역전파 / Backward
        self._optimizer.zero_grad()
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(
            list(self._visual_encoder.parameters()) +
            list(self._tactile_encoder.parameters()) +
            list(self._force_encoder.parameters()),
            1.0,
        )
        self._optimizer.step()

        self._training_step += 1

        result = {
            "visual_tactile_loss": float(loss_vt.item()),
            "visual_force_loss": float(loss_vf.item()),
            "tactile_force_loss": float(loss_tf.item()),
            "total_loss": float(total_loss.item()),
            "temperature": self.temperature,
            "step": self._training_step,
        }

        logger.debug(
            "크로스모달 정렬: VT=%.4f, VF=%.4f, TF=%.4f, 총=%.4f",
            result["visual_tactile_loss"], result["visual_force_loss"],
            result["tactile_force_loss"], result["total_loss"],
        )

        return result

    def _align_numpy(
        self,
        visual_data: Any,
        tactile_data: Any,
        force_data: Any,
    ) -> Dict[str, float]:
        """Numpy 기반 정렬 (추론 전용, 학습 없음) / Numpy-based alignment (inference only)."""
        v = np.asarray(visual_data, dtype=np.float32)
        t = np.asarray(tactile_data, dtype=np.float32)
        f = np.asarray(force_data, dtype=np.float32)

        v_emb = self._visual_encoder.forward(v)
        t_emb = self._tactile_encoder.forward(t)
        f_emb = self._force_encoder.forward(f)

        loss_vt = self._contrastive_loss_numpy(v_emb, t_emb)
        loss_vf = self._contrastive_loss_numpy(v_emb, f_emb)
        loss_tf = self._contrastive_loss_numpy(t_emb, f_emb)

        return {
            "visual_tactile_loss": loss_vt,
            "visual_force_loss": loss_vf,
            "tactile_force_loss": loss_tf,
            "total_loss": loss_vt + loss_vf + loss_tf,
            "temperature": self._temperature,
            "step": self._training_step,
        }

    def store_embeddings(
        self,
        visual_emb: np.ndarray,
        tactile_emb: np.ndarray,
        force_emb: np.ndarray,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        임베딩 저장 (검색용) / Store embeddings (for retrieval).

        Args:
            visual_emb: 시각 임베딩
            tactile_emb: 촉각 임베딩
            force_emb: 힘 임베딩
            metadata: 메타데이터
        """
        with self._lock:
            self._stored_embeddings["visual"].append(
                np.asarray(visual_emb, dtype=np.float32).flatten()
            )
            self._stored_embeddings["tactile"].append(
                np.asarray(tactile_emb, dtype=np.float32).flatten()
            )
            self._stored_embeddings["force"].append(
                np.asarray(force_emb, dtype=np.float32).flatten()
            )
            self._stored_metadata.append(metadata or {})

    def retrieve_crossmodal(
        self,
        query_embedding: np.ndarray,
        target_modality: str = "tactile",
        k: int = 5,
    ) -> List[Tuple[int, float, Dict[str, Any]]]:
        """
        크로스모달 검색 / Cross-modal retrieval.

        한 모달리티의 임베딩으로 다른 모달리티의 저장된 경험을 검색합니다.
        정렬된 공간에서는 코사인 유사도가 높은 항목이 대응하는 경험입니다.

        Args:
            query_embedding: 쿼리 임베딩 (임의 모달리티)
            target_modality: 검색할 타겟 모달리티 ("tactile", "force", "visual")
            k: 반환할 결과 수

        Returns:
            List of (index, similarity, metadata) tuples
        """
        if target_modality not in self._stored_embeddings:
            return []

        target_embs = self._stored_embeddings[target_modality]
        if not target_embs:
            return []

        query = np.asarray(query_embedding, dtype=np.float32).flatten()
        query_norm = np.linalg.norm(query)
        if query_norm > EPS:
            query = query / query_norm

        similarities = []
        for idx, target_emb in enumerate(target_embs):
            target_norm = np.linalg.norm(target_emb)
            if target_norm > EPS:
                target_emb = target_emb / target_norm
            sim = float(np.dot(query, target_emb))
            similarities.append((idx, sim, self._stored_metadata[idx]))

        # 유사도순 정렬 / Sort by similarity
        similarities.sort(key=lambda x: x[1], reverse=True)

        logger.debug(
            "크로스모달 검색: 쿼리→%s, %d개 결과 (최고=%.3f)",
            target_modality, min(k, len(similarities)),
            similarities[0][1] if similarities else 0.0,
        )

        return similarities[:k]

    def get_alignment_quality(self) -> Dict[str, float]:
        """
        정렬 품질 평가 / Evaluate alignment quality.

        저장된 임베딩의 크로스모달 정렬 품질을 평가합니다.
        같은 인덱스의 서로 다른 모달리티 임베딩 간의 평균 유사도를 측정합니다.

        Returns:
            Dict: 모달리티 쌍별 평균 유사도
        """
        n = min(
            len(self._stored_embeddings["visual"]),
            len(self._stored_embeddings["tactile"]),
            len(self._stored_embeddings["force"]),
        )

        if n == 0:
            return {"visual_tactile": 0.0, "visual_force": 0.0, "tactile_force": 0.0}

        v_embs = np.array(self._stored_embeddings["visual"][:n])
        t_embs = np.array(self._stored_embeddings["tactile"][:n])
        f_embs = np.array(self._stored_embeddings["force"][:n])

        # L2 정규화 / L2 normalize
        for embs in [v_embs, t_embs, f_embs]:
            norms = np.linalg.norm(embs, axis=1, keepdims=True)
            norms = np.maximum(norms, EPS)
            embs /= norms

        # 대각 유사도 (같은 인덱스 = 대응 쌍) / Diagonal similarity
        vt_sim = float(np.mean(np.sum(v_embs * t_embs, axis=1)))
        vf_sim = float(np.mean(np.sum(v_embs * f_embs, axis=1)))
        tf_sim = float(np.mean(np.sum(t_embs * f_embs, axis=1)))

        return {
            "visual_tactile": vt_sim,
            "visual_force": vf_sim,
            "tactile_force": tf_sim,
        }

    def save(self, path: Union[str, Path]) -> bool:
        """
        모델 저장 / Save model.

        Args:
            path: 저장 경로

        Returns:
            bool: 저장 성공 여부
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        try:
            if self._use_torch and TORCH_AVAILABLE:
                torch.save({
                    "visual_encoder": self._visual_encoder.state_dict(),
                    "tactile_encoder": self._tactile_encoder.state_dict(),
                    "force_encoder": self._force_encoder.state_dict(),
                    "optimizer": self._optimizer.state_dict(),
                    "log_temp": self._log_temp,
                    "training_step": self._training_step,
                }, path / "crossmodal_model.pt")
            else:
                np.savez_compressed(
                    path / "crossmodal_model.npz",
                    visual_w1=self._visual_encoder.w1,
                    visual_w2=self._visual_encoder.w2,
                    tactile_w1=self._tactile_encoder.w1,
                    tactile_w2=self._tactile_encoder.w2,
                    force_w1=self._force_encoder.w1,
                    force_w2=self._force_encoder.w2,
                    training_step=np.array([self._training_step]),
                )

            logger.info("크로스모달 모델 저장: %s", path)
            return True
        except Exception as e:
            logger.error("모델 저장 실패: %s", e)
            return False

    def load(self, path: Union[str, Path]) -> bool:
        """
        모델 로드 / Load model.

        Args:
            path: 로드 경로

        Returns:
            bool: 로드 성공 여부
        """
        path = Path(path)

        try:
            if self._use_torch and TORCH_AVAILABLE:
                checkpoint = torch.load(
                    path / "crossmodal_model.pt",
                    map_location=self._device,
                    weights_only=False,
                )
                self._visual_encoder.load_state_dict(checkpoint["visual_encoder"])
                self._tactile_encoder.load_state_dict(checkpoint["tactile_encoder"])
                self._force_encoder.load_state_dict(checkpoint["force_encoder"])
                self._optimizer.load_state_dict(checkpoint["optimizer"])
                self._log_temp = checkpoint["log_temp"]
                self._training_step = checkpoint.get("training_step", 0)
            else:
                data = np.load(str(path / "crossmodal_model.npz"))
                self._visual_encoder.w1 = data["visual_w1"]
                self._visual_encoder.w2 = data["visual_w2"]
                self._tactile_encoder.w1 = data["tactile_w1"]
                self._tactile_encoder.w2 = data["tactile_w2"]
                self._force_encoder.w1 = data["force_w1"]
                self._force_encoder.w2 = data["force_w2"]
                self._training_step = int(data.get("training_step", [0])[0])

            logger.info("크로스모달 모델 로드: %s", path)
            return True
        except Exception as e:
            logger.error("모델 로드 실패: %s", e)
            return False

    def get_stats(self) -> Dict[str, Any]:
        """정렬 시스템 통계 / Return alignment statistics."""
        return {
            "embed_dim": self._embed_dim,
            "temperature": self.temperature,
            "training_step": self._training_step,
            "use_torch": self._use_torch,
            "stored_embeddings": {
                k: len(v) for k, v in self._stored_embeddings.items()
            },
            "alignment_quality": self.get_alignment_quality(),
        }


# ============================================================================
# Cross-Modal Predictive Coding + BindCraft — Physical AGI 다감각 혁신
# ============================================================================
# 기존: CLIP 스타일 정적 정렬 → 한계: 시간적 정렬, 미세 정렬 없음
# 혁신 1: 교차 모달 예측 코딩 — 한 모달리티에서 다른 모달리티 예측
# 혁신 2: BindCraft — 언어+시각+촉각+힘 통합 바인딩
# 혁신 3: 활성 교차 모달 탐색 — 정렬을 개선할 경험 적극 탐색
# ============================================================================

if TORCH_AVAILABLE:

    class CrossModalPredictiveCoder(nn.Module):
        """교차 모달 예측 코딩 — 한 감각으로 다른 감각 예측
        
        "이 물체의 시각만 보고 촉각을 예측할 수 있는가?"
        이 예측이 가능하면 세계 모델이 물리적 현실을 이해한 것.
        """
        
        def __init__(self, visual_dim=512, tactile_dim=512, force_dim=512,
                     hidden_dim=256, prediction_dim=128):
            super().__init__()
            
            # Cross-modal predictors
            self.visual_to_tactile = nn.Sequential(
                nn.Linear(visual_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, prediction_dim),
            )
            
            self.tactile_to_visual = nn.Sequential(
                nn.Linear(tactile_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, prediction_dim),
            )
            
            self.visual_to_force = nn.Sequential(
                nn.Linear(visual_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, prediction_dim),
            )
            
            self.force_to_visual = nn.Sequential(
                nn.Linear(force_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, prediction_dim),
            )
            
            self.tactile_to_force = nn.Sequential(
                nn.Linear(tactile_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, prediction_dim),
            )
            
            self.force_to_tactile = nn.Sequential(
                nn.Linear(force_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, prediction_dim),
            )
            
            # Target projections (to same prediction space)
            self.tactile_target_proj = nn.Linear(tactile_dim, prediction_dim)
            self.visual_target_proj = nn.Linear(visual_dim, prediction_dim)
            self.force_target_proj = nn.Linear(force_dim, prediction_dim)
        
        def forward(self, visual_emb=None, tactile_emb=None, force_emb=None):
            """교차 모달 예측 손실 계산
            
            Returns:
                dict: 각 예측 방향별 손실, 총 손실
            """
            losses = {}
            
            if visual_emb is not None and tactile_emb is not None:
                # Visual → Tactile
                pred_tactile = self.visual_to_tactile(visual_emb)
                target_tactile = self.tactile_target_proj(tactile_emb)
                losses['v2t'] = F.mse_loss(pred_tactile, target_tactile.detach())
                
                # Tactile → Visual
                pred_visual = self.tactile_to_visual(tactile_emb)
                target_visual = self.visual_target_proj(visual_emb)
                losses['t2v'] = F.mse_loss(pred_visual, target_visual.detach())
            
            if visual_emb is not None and force_emb is not None:
                # Visual → Force
                pred_force = self.visual_to_force(visual_emb)
                target_force = self.force_target_proj(force_emb)
                losses['v2f'] = F.mse_loss(pred_force, target_force.detach())
                
                # Force → Visual
                pred_visual = self.force_to_visual(force_emb)
                target_visual = self.visual_target_proj(visual_emb)
                losses['f2v'] = F.mse_loss(pred_visual, target_visual.detach())
            
            if tactile_emb is not None and force_emb is not None:
                # Tactile → Force
                pred_force = self.tactile_to_force(tactile_emb)
                target_force = self.force_target_proj(force_emb)
                losses['t2f'] = F.mse_loss(pred_force, target_force.detach())
                
                # Force → Tactile
                pred_tactile = self.force_to_tactile(force_emb)
                target_tactile = self.tactile_target_proj(tactile_emb)
                losses['f2t'] = F.mse_loss(pred_tactile, target_tactile.detach())
            
            total_loss = sum(losses.values()) / max(len(losses), 1)
            losses['total'] = total_loss
            
            return losses
        
        def predict_tactile_from_visual(self, visual_emb):
            """시각만으로 촉각 예측 (제로샷 물리적 추론)"""
            return self.visual_to_tactile(visual_emb)
        
        def predict_force_from_visual(self, visual_emb):
            """시각만으로 힘 예측"""
            return self.visual_to_force(visual_emb)


    class BindCraftAlignment(nn.Module):
        """BindCraft: 언어+시각+촉각+힘 통합 바인딩 공간
        
        모든 모달리티를 하나의 공간에 정렬하여:
        "빨간 컵" (언어) = [시각 임베딩] = [촉각 임베딩] = [힘 임베딩]
        """
        
        def __init__(self, language_dim=768, visual_dim=512, tactile_dim=512,
                     force_dim=512, shared_dim=256, temperature=0.07):
            super().__init__()
            self.shared_dim = shared_dim
            self.temperature = nn.Parameter(torch.tensor(temperature).log())
            
            # Modality projection heads to shared space
            self.language_proj = nn.Sequential(
                nn.Linear(language_dim, shared_dim * 2),
                nn.GELU(),
                nn.Linear(shared_dim * 2, shared_dim),
            )
            
            self.visual_proj = nn.Sequential(
                nn.Linear(visual_dim, shared_dim * 2),
                nn.GELU(),
                nn.Linear(shared_dim * 2, shared_dim),
            )
            
            self.tactile_proj = nn.Sequential(
                nn.Linear(tactile_dim, shared_dim * 2),
                nn.GELU(),
                nn.Linear(shared_dim * 2, shared_dim),
            )
            
            self.force_proj = nn.Sequential(
                nn.Linear(force_dim, shared_dim * 2),
                nn.GELU(),
                nn.Linear(shared_dim * 2, shared_dim),
            )
        
        def project(self, language_emb=None, visual_emb=None,
                    tactile_emb=None, force_emb=None):
            """모든 모달리티를 공유 공간으로 투영"""
            projections = {}
            if language_emb is not None:
                projections['language'] = F.normalize(self.language_proj(language_emb), dim=-1)
            if visual_emb is not None:
                projections['visual'] = F.normalize(self.visual_proj(visual_emb), dim=-1)
            if tactile_emb is not None:
                projections['tactile'] = F.normalize(self.tactile_proj(tactile_emb), dim=-1)
            if force_emb is not None:
                projections['force'] = F.normalize(self.force_proj(force_emb), dim=-1)
            return projections
        
        def contrastive_loss(self, projections):
            """다중 모달 대조 손실 (InfoNCE 확장)"""
            modalities = list(projections.keys())
            if len(modalities) < 2:
                return torch.tensor(0.0)
            
            total_loss = torch.tensor(0.0, device=next(self.parameters()).device)
            n_pairs = 0
            
            for i in range(len(modalities)):
                for j in range(i + 1, len(modalities)):
                    emb_i = projections[modalities[i]]
                    emb_j = projections[modalities[j]]
                    
                    # Symmetric InfoNCE
                    sim_matrix = torch.matmul(emb_i, emb_j.T) * self.temperature.exp()
                    labels = torch.arange(sim_matrix.shape[0], device=sim_matrix.device)
                    
                    loss_ij = F.cross_entropy(sim_matrix, labels)
                    loss_ji = F.cross_entropy(sim_matrix.T, labels)
                    
                    total_loss = total_loss + (loss_ij + loss_ji) / 2
                    n_pairs += 1
            
            return total_loss / max(n_pairs, 1)
        
        def zero_shot_physical_reasoning(self, visual_emb, query_text_emb=None):
            """제로샷 물리적 추론: 시각만으로 물리적 속성 예측"""
            visual_shared = F.normalize(self.visual_proj(visual_emb), dim=-1)
            
            result = {
                'visual_shared': visual_shared,
            }
            
            if query_text_emb is not None:
                text_shared = F.normalize(self.language_proj(query_text_emb), dim=-1)
                similarity = torch.matmul(visual_shared, text_shared.T)
                result['text_similarity'] = similarity
                result['matched'] = similarity.argmax(dim=-1)
            
            return result


# ─── 모듈 진입점 / Module Entry Point ───────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("=" * 60)
    print("크로스모달 인코더 테스트 / Cross-Modal Encoder Test")
    print("=" * 60)
    print(f"PyTorch 사용 가능: {TORCH_AVAILABLE}")

    # 정렬 시스템 생성 / Create alignment system
    alignment = CrossModalAlignment(embed_dim=EMBED_DIM, temperature=0.07)

    # 가상 데이터 생성 / Generate dummy data
    rng = np.random.RandomState(42)
    batch_size = 16

    visual_data = rng.randn(batch_size, VISUAL_INPUT_DIM).astype(np.float32)
    tactile_data = rng.randn(batch_size, TACTILE_INPUT_DIM).astype(np.float32)
    force_data = rng.randn(batch_size, FORCE_INPUT_DIM).astype(np.float32)

    # 인코딩 테스트 / Encoding test
    v_emb = alignment.encode_visual(visual_data)
    t_emb = alignment.encode_tactile(tactile_data)
    f_emb = alignment.encode_force(force_data)

    print(f"\n시각 임베딩: shape={v_emb.shape}, norm={np.linalg.norm(v_emb[0]):.3f}")
    print(f"촉각 임베딩: shape={t_emb.shape}, norm={np.linalg.norm(t_emb[0]):.3f}")
    print(f"힘 임베딩: shape={f_emb.shape}, norm={np.linalg.norm(f_emb[0]):.3f}")

    # 정렬 학습 테스트 / Alignment training test
    if TORCH_AVAILABLE:
        print("\n정렬 학습 / Alignment Training:")
        for epoch in range(5):
            result = alignment.align_modality_pairs(visual_data, tactile_data, force_data)
            if epoch % 2 == 0:
                print(f"  에포크 {epoch}: 총 손실={result['total_loss']:.4f}, "
                      f"온도={result['temperature']:.4f}")

    # 임베딩 저장 및 검색 테스트 / Store and retrieve test
    print("\n크로스모달 검색 테스트 / Cross-Modal Retrieval Test:")
    for i in range(10):
        alignment.store_embeddings(v_emb[i], t_emb[i], f_emb[i], {"idx": i})

    # 시각 → 촉각 검색 / Visual → Tactile retrieval
    results = alignment.retrieve_crossmodal(v_emb[0], target_modality="tactile", k=3)
    print(f"  시각→촉각 검색 결과:")
    for idx, sim, meta in results:
        print(f"    인덱스={idx}, 유사도={sim:.3f}, 메타={meta}")

    # 정렬 품질 / Alignment quality
    quality = alignment.get_alignment_quality()
    print(f"\n정렬 품질: {quality}")
    print(f"통계: {alignment.get_stats()}")
    print("\n모든 테스트 완료 / All tests completed.")
