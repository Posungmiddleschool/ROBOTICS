#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — 7계층 안전 엔진 / Seven-Layer Safety Engine
============================================================

V7의 5계층 → V8.5의 7계층으로 업그레이드
Upgrade from V7's 5 layers to V8.5's 7 layers

100개 하드웨어 재난 시나리오(PDF) 대응
Addresses ALL 100 hardware disaster scenarios from the PDF

Layer 1 — 하드웨어 E-Stop (Hardware Emergency Stop)
Layer 2 — 전류 제한 (Current Limiting)
Layer 3 — 워치독 (Watchdog Timer)
Layer 4 — 충돌 예측 (Collision Prediction)
Layer 5 — AI 안전 검증 (AI Safety Verification)
Layer 6 — 구조적 무결성 (Structural Integrity)       [NEW in V8.5]
Layer 7 — 환경 경화 (Environmental Hardening)        [NEW in V8.5]

작성자: 지훈 로봇 안전팀
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import time
import threading
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Sequence,
    Tuple,
)

# ─────────────────────────────────────────────────────────────
# 상수 정의 / Constants
# ─────────────────────────────────────────────────────────────

VERSION = "V8.5"

# 전류 제한 / Current limits (PDF #1-6,7,21,25)
MAX_TOTAL_CURRENT_A = 25.0           # 총 모터 전류 상한 / Total motor current limit
INRUSH_CURRENT_SPIKE_A = 40.0       # 돌입 전류 스파이크 임계값 / Inrush current spike threshold
VOLTAGE_SAG_MIN_V = 18.0            # 전압 강하 최소 / Minimum voltage before sag alert
VOLTAGE_SURGE_MAX_V = 30.0          # 전압 서지 최대 / Maximum voltage before surge alert
REGENERATION_CURRENT_A = 15.0       # 회생 제동 전류 한계 / Regenerative braking current limit

# 워치독 / Watchdog (Layer 3)
WATCHDOG_TIMEOUT_MS = 100           # 100ms 내 응답 필수 / Must respond within 100ms

# 충돌 예측 / Collision prediction (Layer 4)
COLLISION_PREDICTION_WINDOW_S = 0.5  # 0.5초 후 충돌 예측 / Predict collision 0.5s ahead
COLLISION_DISTANCE_M = 0.3          # 최소 안전 거리 / Minimum safe distance in meters

# 구조적 무결성 / Structural Integrity (Layer 6)
COG_TILT_THRESHOLD_DEG = 15.0       # 질량중심 기울기 임계값 / CoG tilt threshold
RESONANCE_FREQ_RANGE_HZ = (20.0, 200.0)   # 공진 주파수 감지 범위 / Resonance detection range
VIBRATION_ANOMALY_G = 2.5           # 진동 이상 가속도 / Vibration anomaly threshold in G
THERMAL_EXPANSION_COEFF = 12e-6     # 열팽창 계수(강) / Thermal expansion coefficient (steel)
CREEP_RATE_THRESHOLD_MM_H = 0.01    # 크리프 속도 임계값 / Creep rate threshold mm/hr
BASE_PLATE_DEFORM_MM = 0.5          # 베이스 플레이트 변형 한계 / Base plate deformation limit mm
IMPACT_ABSORBER_WEAR_PCT = 80.0     # 충격 흡수 장치 마모율 / Impact absorber wear percentage
BOLT_LOOSENESS_VIBRATION_G = 1.8    # 볼트 풀림 진동 임계값 / Bolt looseness vibration threshold

# 환경 경화 / Environmental Hardening (Layer 7)
DUST_TEMP_RISE_RATE_C_MIN = 2.0     # 미세먼지 간접감지 온도상승률 / Dust indirect detection temp rise rate
OPTICAL_QUALITY_DEGRADATION_PCT = 30.0  # 렌즈 백화 품질 저하율 / Lens haziness quality degradation %
HUMIDITY_CONDENSATION_PCT = 85.0    # 결로 위험 습도 / Condensation risk humidity %
EMI_NOISE_SPIKE_FACTOR = 3.0        # EMI 노이즈 급증 배수 / EMI noise spike factor
SALT_CONTACT_RESISTANCE_CHANGE_PCT = 20.0  # 염해 접촉저항 변화율 / Saline contact resistance change %
PEST_TEMPERATURE_ANOMALY_C = 5.0    # 해충 온도 이상치 / Pest temperature anomaly °C
ESTOP_CIRCUIT_RESISTANCE_OHM = 10.0 # E-Stop 회로 저항 한계 / E-Stop circuit resistance limit Ω
POWER_CABLE_VDROP_V = 2.0           # 전원 케이블 전압 강하 / Power cable voltage drop limit V
CONNECTOR_PIN_RESISTANCE_OHM = 5.0  # 커넥터 핀 저항 한계 / Connector pin resistance limit Ω
LEAKAGE_CURRENT_MA = 30.0           # 누전 차단기 오작동 임계값 / Leakage current malfunction threshold mA


# ─────────────────────────────────────────────────────────────
# 열거형 / Enumerations
# ─────────────────────────────────────────────────────────────

class SafetyLayer(Enum):
    """7계층 안전 레이어 식별 / Seven-layer safety layer identification"""
    LAYER1_HARDWARE_ESTOP = 1        # 하드웨어 E-Stop
    LAYER2_CURRENT_LIMIT = 2         # 전류 제한
    LAYER3_WATCHDOG = 3              # 워치독
    LAYER4_COLLISION_PREDICTION = 4  # 충돌 예측
    LAYER5_AI_SAFETY = 5             # AI 안전 검증
    LAYER6_STRUCTURAL = 6            # 구조적 무결성 (NEW V8.5)
    LAYER7_ENVIRONMENTAL = 7         # 환경 경화 (NEW V8.5)


class SafetyStatus(Enum):
    """안전 상태 / Safety status"""
    NOMINAL = auto()       # 정상 / Normal
    WARNING = auto()       # 경고 / Warning
    CRITICAL = auto()      # 위험 / Critical
    EMERGENCY = auto()     # 비상 / Emergency


class EmergencyType(Enum):
    """비상 정지 유형 / Emergency stop type"""
    HARDWARE_ESTOP = auto()          # 하드웨어 비상정지
    OVERCURRENT = auto()             # 과전류
    WATCHDOG_TIMEOUT = auto()        # 워치독 시간초과
    COLLISION_IMMINENT = auto()      # 충돌 임박
    AI_COMMAND_REJECTED = auto()     # AI 명령 거부
    STRUCTURAL_FAILURE = auto()      # 구조적 파손 (NEW V8.5)
    ENVIRONMENTAL_HAZARD = auto()    # 환경적 위험 (NEW V8.5)


# ─────────────────────────────────────────────────────────────
# 데이터 클래스 / Data Classes
# ─────────────────────────────────────────────────────────────

@dataclass
class MotorCurrents:
    """모터 전류 판독값 / Motor current readings"""
    currents: List[float] = field(default_factory=list)  # 각 모터 전류(A) / Per-motor current (A)
    total: float = 0.0                                   # 총 전류 / Total current
    timestamp: float = 0.0                               # 판독 시각 / Reading timestamp


@dataclass
class PowerReading:
    """전원 상태 판독값 / Power status readings (PDF #1-6,7,21,25)"""
    bus_voltage_v: float = 24.0        # 버스 전압 / Bus voltage
    battery_voltage_v: float = 24.0    # 배터리 전압 / Battery voltage
    regeneration_current_a: float = 0.0  # 회생 전류 / Regeneration current
    inrush_detected: bool = False      # 돌입 전류 감지 / Inrush current detected
    timestamp: float = 0.0


@dataclass
class CollisionData:
    """충돌 예측 센서 데이터 / Collision prediction sensor data"""
    distances_m: List[float] = field(default_factory=list)  # 거리 센서 값(m) / Distance sensor values
    velocities_m_s: List[float] = field(default_factory=list)  # 속도(m/s) / Velocities
    time_to_collision_s: float = float('inf')  # 충돌까지 시간 / Time to collision
    nearest_distance_m: float = float('inf')   # 최근 거리 / Nearest distance
    timestamp: float = 0.0


@dataclass
class AICommand:
    """AI 명령 평가 / AI command for evaluation"""
    command_text: str = ""           # 명령 텍스트 / Command text
    risk_score: float = 0.0         # 위험 점수 0~1 / Risk score 0-1
    category: str = ""              # 명령 카테고리 / Command category
    parameters: Dict[str, Any] = field(default_factory=dict)  # 매개변수 / Parameters
    timestamp: float = 0.0


@dataclass
class StructuralReading:
    """
    구조적 무결성 센서 데이터 / Structural integrity sensor data (NEW in V8.5)
    PDF #51-75 대응
    """
    # 질량 중심 (CoG) / Center of Gravity (PDF #51-55)
    cog_tilt_deg: float = 0.0             # CoG 기울기(도) / CoG tilt in degrees
    cog_offset_x_mm: float = 0.0          # CoG X 오프셋 / CoG X offset
    cog_offset_y_mm: float = 0.0          # CoG Y 오프셋 / CoG Y offset
    tipover_risk_score: float = 0.0       # 전도 위험 점수 / Tip-over risk score 0-1

    # 진동 / Vibration (PDF #56-60)
    vibration_frequency_hz: float = 0.0   # 진동 주파수 / Vibration frequency
    vibration_amplitude_g: float = 0.0    # 진동 진폭(G) / Vibration amplitude in G
    resonance_detected: bool = False      # 공진 감지 / Resonance detected
    vibration_pattern: List[float] = field(default_factory=list)  # 진동 패턴 / Vibration pattern

    # 볼트/나사 풀림 / Bolt & screw looseness (PDF #61-63)
    bolt_looseness_detected: bool = False # 볼트 풀림 감지 / Bolt looseness detected
    bolt_vibration_g: float = 0.0        # 볼트 풀림 진동값 / Bolt looseness vibration
    anchor_bolt_status: str = "nominal"  # 앵커 볼트 상태 / Anchor bolt status

    # 열팽창 / Thermal expansion (PDF #64-66)
    frame_temperature_c: float = 25.0    # 프레임 온도 / Frame temperature °C
    thermal_expansion_mm: float = 0.0    # 열팽창량(mm) / Thermal expansion amount
    thermal_warp_detected: bool = False  # 열 뒤틀림 감지 / Thermal warp detected

    # 크리프 / Creep (PDF #67-69)
    creep_rate_mm_h: float = 0.0         # 크리프 속도 / Creep rate mm/hr
    creep_detected: bool = False         # 크리프 감지 / Creep detected
    creep_location: str = ""             # 크리프 발생 위치 / Creep location

    # 베이스 플레이트 / Base plate (PDF #70-72)
    base_plate_deformation_mm: float = 0.0  # 베이스 플레이트 변형 / Base plate deformation
    base_plate_warp_detected: bool = False  # 베이스 플레이트 뒤틀림 / Base plate warp detected

    # 충격 흡수 / Impact absorber (PDF #73-75)
    impact_absorber_wear_pct: float = 0.0   # 충격 흡수 장치 마모율 / Impact absorber wear %
    impact_absorber_leaking: bool = False    # 충격 흡수 장치 누유 / Impact absorber leaking

    # 메타 / Meta
    timestamp: float = 0.0


@dataclass
class EnvironmentalReading:
    """
    환경 경화 센서 데이터 / Environmental hardening sensor data (NEW in V8.5)
    PDF #76-100 대응
    """
    # 미세먼지 / Fine dust (PDF #76-78) — 온도 상승률로 간접 감지
    dust_temp_rise_rate_c_min: float = 0.0  # 온도상승률(°C/min) / Temp rise rate
    dust_accumulation_suspected: bool = False  # 미세먼지 축적 의심 / Dust accumulation suspected
    estimated_dust_level: str = "normal"    # 추정 먼지 수준 / Estimated dust level

    # 광학 센서 렌즈 / Optical sensor lens (PDF #79-81)
    optical_quality_pct: float = 100.0      # 이미지 품질(%) / Image quality percentage
    lens_haziness_detected: bool = False    # 렌즈 백화 감지 / Lens haziness detected
    image_sharpness_score: float = 1.0      # 이미지 선명도 점수 / Image sharpness score

    # 습도 / Humidity (PDF #82-83)
    humidity_pct: float = 50.0             # 상대습도(%) / Relative humidity
    condensation_risk: bool = False        # 결로 위험 / Condensation risk
    dew_point_c: float = 10.0             # 이슬점(°C) / Dew point

    # EMI 간섭 / EMI interference (PDF #84)
    emi_noise_level: float = 1.0           # EMI 노이즈 수준 / EMI noise level (baseline=1.0)
    emi_spike_detected: bool = False       # EMI 스파이크 감지 / EMI spike detected
    sensor_noise_baseline: float = 1.0     # 센서 노이즈 기준 / Sensor noise baseline

    # 염해 / Saline corrosion (PDF #86-88)
    contact_resistance_change_pct: float = 0.0  # 접촉 저항 변화율 / Contact resistance change %
    saline_corrosion_detected: bool = False     # 염해 부식 감지 / Saline corrosion detected
    exposed_metal_resistance_ohm: float = 0.1  # 노출 금속 저항 / Exposed metal resistance

    # 해충 / Pest intrusion (PDF #89-91)
    temperature_anomaly_c: float = 0.0     # 온도 이상치 / Temperature anomaly °C
    ir_anomaly_detected: bool = False      # 적외선 이상 감지 / IR anomaly detected
    pest_intrusion_suspected: bool = False # 해충 침입 의심 / Pest intrusion suspected

    # E-Stop 회로 / E-Stop circuit (PDF #85 — 핵심!)
    estop_circuit_resistance_ohm: float = 0.5  # E-Stop 회로 저항 / E-Stop circuit resistance
    estop_circuit_continuous: bool = True      # E-Stop 회로 연속성 / E-Stop circuit continuity
    estop_wire_break_detected: bool = False    # 회로 단선 감지 / Wire break detected

    # 전원 케이블 / Power cable (PDF #24)
    power_cable_vdrop_v: float = 0.0      # 케이블 전압 강하 / Cable voltage drop
    power_cable_disconnected: bool = False # 케이블 이탈 감지 / Cable disconnected
    cable_connection_secure: bool = True   # 케이블 연결 안전 / Cable connection secure

    # 커넥터 핀 / Connector pin (PDF #15)
    connector_pin_resistance_ohm: float = 0.1  # 핀 저항 / Pin resistance
    connector_oxidation_detected: bool = False # 핀 산화 감지 / Pin oxidation detected
    contact_quality_score: float = 1.0         # 접촉 품질 점수 / Contact quality score

    # 누전 차단기 / Leakage circuit breaker (PDF #23)
    leakage_current_ma: float = 0.0       # 누전 전류 / Leakage current
    breaker_malfunction: bool = False     # 차단기 오작동 / Breaker malfunction
    breaker_trip_count: int = 0           # 차단기 트립 횟수 / Breaker trip count

    # 메타 / Meta
    ambient_temperature_c: float = 25.0   # 주변 온도 / Ambient temperature
    timestamp: float = 0.0


@dataclass
class SafetyReport:
    """전체 안전 검사 보고서 / Comprehensive safety check report"""
    version: str = VERSION
    timestamp: float = 0.0
    overall_status: SafetyStatus = SafetyStatus.NOMINAL
    layer_statuses: Dict[str, SafetyStatus] = field(default_factory=dict)
    layer_messages: Dict[str, str] = field(default_factory=dict)
    active_emergencies: List[EmergencyType] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────
# 예외 클래스 / Exception Classes
# ─────────────────────────────────────────────────────────────

class SafetyViolationError(Exception):
    """안전 위반 예외 / Safety violation exception"""
    def __init__(self, layer: SafetyLayer, message: str, emergency_type: Optional[EmergencyType] = None):
        self.layer = layer
        self.message = message
        self.emergency_type = emergency_type
        super().__init__(f"[{layer.name}] {message}")


class EmergencyStopError(SafetyViolationError):
    """비상 정지 예외 / Emergency stop exception"""
    pass


# ─────────────────────────────────────────────────────────────
# 메인 안전 엔진 / Main Safety Engine
# ─────────────────────────────────────────────────────────────

class SevenLayerSafetyEngine:
    """
    지훈 로봇 V8.5 7계층 안전 엔진
    Jihun Robot V8.5 Seven-Layer Safety Engine

    V7의 5계층에서 V8.5의 7계층으로 업그레이드
    Upgraded from V7's 5 layers to V8.5's 7 layers

    모든 레이어는 독립적으로 테스트 가능 (test_layer1 ~ test_layer7)
    All layers are independently testable (test_layer1 through test_layer7)

    스레드 안전: RLock 사용
    Thread-safe: Uses RLock
    """

    def __init__(self):
        # 버전 / Version
        self._version = VERSION

        # 스레드 안전 락 / Thread-safe lock (재진입 가능 / Reentrant)
        self._lock = threading.RLock()

        # 로거 / Logger
        self._logger = logging.getLogger(f"SafetyEngine.{self._version}")
        self._logger.setLevel(logging.DEBUG)

        # ── 레이어 1: 하드웨어 E-Stop 상태 / Layer 1: Hardware E-Stop state ──
        self._estop_active: bool = False              # E-Stop 활성 상태 / E-Stop active state
        self._estop_circuit_ok: bool = True           # E-Stop 회로 정상 / E-Stop circuit OK
        self._estop_last_trigger_time: float = 0.0    # 마지막 트리거 시각 / Last trigger time

        # ── 레이어 2: 전류 모니터링 / Layer 2: Current monitoring ──
        self._motor_currents: MotorCurrents = MotorCurrents()
        self._power_reading: PowerReading = PowerReading()
        self._current_violation_count: int = 0        # 전류 위반 횟수 / Current violation count

        # ── 레이어 3: 워치독 / Layer 3: Watchdog ──
        self._watchdog_last_heartbeat: float = time.time()
        self._watchdog_timeout_ms: int = WATCHDOG_TIMEOUT_MS
        self._watchdog_monitor_thread: Optional[threading.Thread] = None
        self._watchdog_running: bool = False
        self._watchdog_missed_beats: int = 0          # 놓친 하트비트 / Missed heartbeats

        # ── 레이어 4: 충돌 예측 / Layer 4: Collision prediction ──
        self._collision_data: CollisionData = CollisionData()
        self._collision_prediction_enabled: bool = True

        # ── 레이어 5: AI 안전 검증 / Layer 5: AI safety verification ──
        self._ai_command: Optional[AICommand] = None
        self._ai_risk_threshold: float = 0.7          # 위험 점수 임계값 / Risk score threshold
        self._ai_rejected_commands: List[AICommand] = []

        # ── 레이어 6: 구조적 무결성 (NEW V8.5) / Layer 6: Structural Integrity ──
        self._structural_reading: StructuralReading = StructuralReading()
        self._structural_history: List[StructuralReading] = []  # 이력 / History
        self._structural_max_history: int = 1000

        # ── 레이어 7: 환경 경화 (NEW V8.5) / Layer 7: Environmental Hardening ──
        self._environmental_reading: EnvironmentalReading = EnvironmentalReading()
        self._environmental_history: List[EnvironmentalReading] = []  # 이력 / History
        self._environmental_max_history: int = 1000

        # ── 비상 콜백 시스템 / Emergency callbacks system ──
        self._emergency_callbacks: Dict[EmergencyType, List[Callable]] = {
            etype: [] for etype in EmergencyType
        }

        # ── 연결된 하위 시스템 / Connected subsystems ──
        self._subsystems: Dict[str, Any] = {}

        # ── 엔진 상태 / Engine state ──
        self._initialized: bool = False
        self._shutdown_flag: bool = False

        self._logger.info(
            "지훈 로봇 %s 7계층 안전 엔진 초기화 완료 / "
            "Jihun Robot %s Seven-Layer Safety Engine initialized",
            self._version, self._version
        )

    # ─────────────────────────────────────────────────────────
    # 속성 / Properties
    # ─────────────────────────────────────────────────────────

    @property
    def version(self) -> str:
        """엔진 버전 / Engine version"""
        return self._version

    @property
    def estop_active(self) -> bool:
        """E-Stop 활성 여부 / Whether E-Stop is active"""
        with self._lock:
            return self._estop_active

    @property
    def overall_status(self) -> SafetyStatus:
        """전체 안전 상태 / Overall safety status (가장 심각한 상태 반환 / Returns most severe status)"""
        with self._lock:
            report = self.check_safety()
            return report.overall_status

    # ─────────────────────────────────────────────────────────
    # 비상 콜백 시스템 / Emergency Callback System
    # ─────────────────────────────────────────────────────────

    def register_emergency_callback(
        self, emergency_type: EmergencyType, callback: Callable[[EmergencyType, Dict[str, Any]], None]
    ) -> None:
        """
        비상 상황 콜백 등록 / Register emergency callback
        비상 상황 발생 시 등록된 콜백이 호출됨
        Registered callbacks are invoked when an emergency occurs
        """
        with self._lock:
            self._emergency_callbacks[emergency_type].append(callback)
            self._logger.debug(
                "콜백 등록: %s / Callback registered: %s",
                emergency_type.name, callback.__name__
            )

    def unregister_emergency_callback(
        self, emergency_type: EmergencyType, callback: Callable
    ) -> None:
        """비상 콜백 제거 / Remove emergency callback"""
        with self._lock:
            if callback in self._emergency_callbacks[emergency_type]:
                self._emergency_callbacks[emergency_type].remove(callback)

    def _fire_emergency(self, emergency_type: EmergencyType, context: Dict[str, Any]) -> None:
        """
        비상 콜백 실행 / Fire emergency callbacks
        등록된 모든 콜백에 비상 상황을 알림
        Notifies all registered callbacks of the emergency
        """
        callbacks = self._emergency_callbacks.get(emergency_type, [])
        for cb in callbacks:
            try:
                cb(emergency_type, context)
            except Exception as e:
                self._logger.error(
                    "비상 콜백 오류 / Emergency callback error: %s — %s",
                    cb.__name__, e
                )

    # ─────────────────────────────────────────────────────────
    # 하위 시스템 연결 / Subsystem Connect Methods
    # ─────────────────────────────────────────────────────────

    def connect_gpio_controller(self, controller: Any) -> None:
        """
        GPIO 컨트롤러 연결 (레이어 1) / Connect GPIO controller (Layer 1)
        E-Stop 버튼의 GPIO 인터럽트를 처리
        Handles GPIO interrupts from the E-Stop button
        """
        with self._lock:
            self._subsystems["gpio_controller"] = controller
            self._logger.info("GPIO 컨트롤러 연결됨 / GPIO controller connected")

    def connect_motor_driver(self, driver: Any) -> None:
        """
        모터 드라이버 연결 (레이어 2) / Connect motor driver (Layer 2)
        전류 제한 및 모터 전원 차단 제어
        Controls current limiting and motor power cutoff
        """
        with self._lock:
            self._subsystems["motor_driver"] = driver
            self._logger.info("모터 드라이버 연결됨 / Motor driver connected")

    def connect_power_monitor(self, monitor: Any) -> None:
        """
        전원 모니터 연결 (레이어 2) / Connect power monitor (Layer 2)
        전압 강하, 서지, 회생 전류 모니터링 (PDF #1-6,7,21,25)
        Monitors voltage sag, surge, regeneration current
        """
        with self._lock:
            self._subsystems["power_monitor"] = monitor
            self._logger.info("전원 모니터 연결됨 / Power monitor connected")

    def connect_distance_sensor(self, sensor: Any) -> None:
        """
        거리 센서 연결 (레이어 4) / Connect distance sensor (Layer 4)
        ToF/LiDAR 센서로 충돌 예측
        ToF/LiDAR sensor for collision prediction
        """
        with self._lock:
            self._subsystems["distance_sensor"] = sensor
            self._logger.info("거리 센서 연결됨 / Distance sensor connected")

    def connect_ai_verifier(self, verifier: Any) -> None:
        """
        AI 검증기 연결 (레이어 5) / Connect AI verifier (Layer 5)
        Gemma 4 기반 명령 위험도 평가
        Gemma 4-based command risk assessment
        """
        with self._lock:
            self._subsystems["ai_verifier"] = verifier
            self._logger.info("AI 검증기 연결됨 / AI verifier connected")

    def connect_structural_monitor(self, monitor: Any) -> None:
        """
        구조 모니터 연결 (레이어 6, NEW V8.5) / Connect structural monitor (Layer 6)
        CoG, 진동, 볼트, 열팽창, 크리프, 베이스플레이트, 충격흡수 모니터링
        Monitors CoG, vibration, bolts, thermal expansion, creep, base plate, impact absorber
        """
        with self._lock:
            self._subsystems["structural_monitor"] = monitor
            self._logger.info("구조 모니터 연결됨 / Structural monitor connected")

    def connect_environmental_monitor(self, monitor: Any) -> None:
        """
        환경 모니터 연결 (레이어 7, NEW V8.5) / Connect environmental monitor (Layer 7)
        미세먼지, 렌즈백화, 습도, EMI, 염해, 해충, E-Stop회로, 케이블, 커넥터, 누전차단기
        Monitors dust, lens haziness, humidity, EMI, saline, pests, E-Stop circuit, cable, connector, breaker
        """
        with self._lock:
            self._subsystems["environmental_monitor"] = monitor
            self._logger.info("환경 모니터 연결됨 / Environmental monitor connected")

    # ─────────────────────────────────────────────────────────
    # 레이어 1: 하드웨어 E-Stop / Layer 1: Hardware E-Stop
    # GPIO 인터럽트 → 즉시 모터 전원 차단
    # PDF #85: E-Stop circuit continuity monitoring
    # ─────────────────────────────────────────────────────────

    def trigger_estop(self, reason: str = "Manual trigger") -> None:
        """
        하드웨어 비상 정지 트리거 / Trigger hardware emergency stop
        GPIO 인터럽트 수신 시 즉시 모터 전원을 차단합니다
        Immediately cuts motor power upon GPIO interrupt
        """
        with self._lock:
            self._estop_active = True
            self._estop_last_trigger_time = time.time()
            self._logger.critical(
                "⚠️ 하드웨어 E-Stop 트리거됨 / Hardware E-Stop TRIGGERED: %s", reason
            )

            # 모터 전원 차단 시도 / Attempt to cut motor power
            motor_driver = self._subsystems.get("motor_driver")
            if motor_driver and hasattr(motor_driver, "emergency_cutoff"):
                try:
                    motor_driver.emergency_cutoff()
                    self._logger.info("모터 전원 차단 완료 / Motor power cutoff complete")
                except Exception as e:
                    self._logger.error(
                        "모터 전원 차단 실패 / Motor power cutoff FAILED: %s", e
                    )

            # 비상 콜백 실행 / Fire emergency callbacks
            self._fire_emergency(
                EmergencyType.HARDWARE_ESTOP,
                {"reason": reason, "timestamp": self._estop_last_trigger_time}
            )

    def release_estop(self) -> bool:
        """
        비상 정지 해제 / Release emergency stop
        E-Stop 회로 정상 시에만 해제 가능
        Can only release if E-Stop circuit is healthy
        """
        with self._lock:
            if not self._estop_circuit_ok:
                self._logger.warning(
                    "E-Stop 회로 불량으로 해제 불가 / "
                    "Cannot release: E-Stop circuit not OK"
                )
                return False
            self._estop_active = False
            self._logger.info("비상 정지 해제됨 / Emergency stop released")
            return True

    def update_estop_circuit(self, circuit_ok: bool, resistance_ohm: float = 0.5) -> None:
        """
        E-Stop 회로 상태 업데이트 / Update E-Stop circuit status
        PDF #85: 회로 단선 연속 감지
        Continuous monitoring for circuit wire break
        """
        with self._lock:
            self._estop_circuit_ok = circuit_ok
            if not circuit_ok or resistance_ohm > ESTOP_CIRCUIT_RESISTANCE_OHM:
                self._logger.critical(
                    "🚨 E-Stop 회로 이상 감지 / E-Stop circuit ANOMALY: "
                    "ok=%s, R=%.2fΩ (한계=%.1fΩ)",
                    circuit_ok, resistance_ohm, ESTOP_CIRCUIT_RESISTANCE_OHM
                )
                # 회로 이상 시 자동 E-Stop 트리거 / Auto-trigger E-Stop on circuit fault
                self.trigger_estop(
                    f"E-Stop 회로 단선/이상 / Circuit fault: R={resistance_ohm:.2f}Ω"
                )

    def test_layer1(self) -> Tuple[bool, str]:
        """
        레이어 1 독립 테스트 / Layer 1 independent test
        하드웨어 E-Stop 기능 검증
        Verifies hardware E-Stop functionality
        """
        with self._lock:
            # E-Stop 트리거 테스트 / Test E-Stop trigger
            old_state = self._estop_active
            self.trigger_estop("Layer 1 테스트 / Layer 1 test")
            trigger_ok = self._estop_active

            # E-Stop 해제 테스트 / Test E-Stop release
            release_ok = self.release_estop()

            # 원래 상태 복원 / Restore original state
            self._estop_active = old_state

            if trigger_ok and release_ok:
                msg = "레이어 1 통과: 하드웨어 E-Stop 정상 / Layer 1 PASS: Hardware E-Stop OK"
                self._logger.info(msg)
                return True, msg
            else:
                msg = f"레이어 1 실패: 트리거={trigger_ok}, 해제={release_ok} / Layer 1 FAIL"
                self._logger.error(msg)
                return False, msg

    # ─────────────────────────────────────────────────────────
    # 레이어 2: 전류 제한 / Layer 2: Current Limiting
    # 총 모터 전류 25A 소프트웨어 제한
    # PDF #1-6,7,21,25: voltage sag, surge, inrush current, BMS errors, regeneration
    # ─────────────────────────────────────────────────────────

    def update_motor_currents(self, currents: List[float], timestamp: Optional[float] = None) -> SafetyStatus:
        """
        모터 전류 업데이트 / Update motor current readings
        총 전류가 25A를 초과하면 자동으로 전류를 제한합니다
        If total current exceeds 25A, automatically limits current
        """
        with self._lock:
            now = timestamp or time.time()
            total = sum(currents)
            self._motor_currents = MotorCurrents(
                currents=list(currents),
                total=total,
                timestamp=now
            )

            status = SafetyStatus.NOMINAL
            messages: List[str] = []

            # 총 전류 검사 / Total current check
            if total > MAX_TOTAL_CURRENT_A:
                status = SafetyStatus.EMERGENCY
                messages.append(
                    f"총 전류 과부하: {total:.1f}A > {MAX_TOTAL_CURRENT_A}A / "
                    f"Total current overload"
                )
                self._current_violation_count += 1
                self._fire_emergency(
                    EmergencyType.OVERCURRENT,
                    {"total_current": total, "limit": MAX_TOTAL_CURRENT_A,
                     "violation_count": self._current_violation_count}
                )

                # 모터 드라이버에 전류 제한 요청 / Request current limit from motor driver
                motor_driver = self._subsystems.get("motor_driver")
                if motor_driver and hasattr(motor_driver, "limit_current"):
                    try:
                        motor_driver.limit_current(MAX_TOTAL_CURRENT_A)
                    except Exception as e:
                        self._logger.error("전류 제한 요청 실패 / Current limit request failed: %s", e)

            elif total > MAX_TOTAL_CURRENT_A * 0.8:
                status = SafetyStatus.WARNING
                messages.append(
                    f"전류 경고: {total:.1f}A (한계의 80%%) / Current warning"
                )

            # 개별 모터 전류 검사 / Individual motor current check
            for i, current in enumerate(currents):
                if current > MAX_TOTAL_CURRENT_A / max(len(currents), 1) * 1.5:
                    messages.append(
                        f"모터 {i} 과전류: {current:.1f}A / Motor {i} overcurrent"
                    )
                    if status == SafetyStatus.NOMINAL:
                        status = SafetyStatus.WARNING

            if messages:
                self._logger.warning(" / ".join(messages))

            return status

    def update_power_reading(self, reading: PowerReading) -> SafetyStatus:
        """
        전원 상태 업데이트 / Update power reading
        PDF #1-6: 전압 강하, 서지 감지
        PDF #7: 돌입 전류, PDF #21: BMS 오류, PDF #25: 회생 전류
        """
        with self._lock:
            self._power_reading = reading
            status = SafetyStatus.NOMINAL

            # 전압 강하 검사 / Voltage sag check (PDF #1-3)
            if reading.bus_voltage_v < VOLTAGE_SAG_MIN_V:
                self._logger.critical(
                    "⚡ 전압 강하 감지: %.1fV < %.1fV / Voltage SAG detected",
                    reading.bus_voltage_v, VOLTAGE_SAG_MIN_V
                )
                status = SafetyStatus.EMERGENCY
                self._fire_emergency(
                    EmergencyType.OVERCURRENT,
                    {"type": "voltage_sag", "voltage": reading.bus_voltage_v}
                )

            # 전압 서지 검사 / Voltage surge check (PDF #4-6)
            elif reading.bus_voltage_v > VOLTAGE_SURGE_MAX_V:
                self._logger.critical(
                    "⚡ 전압 서지 감지: %.1fV > %.1fV / Voltage SURGE detected",
                    reading.bus_voltage_v, VOLTAGE_SURGE_MAX_V
                )
                status = SafetyStatus.EMERGENCY
                self._fire_emergency(
                    EmergencyType.OVERCURRENT,
                    {"type": "voltage_surge", "voltage": reading.bus_voltage_v}
                )

            # 돌입 전류 검사 / Inrush current check (PDF #7)
            if reading.inrush_detected:
                self._logger.warning(
                    "⚡ 돌입 전류 스파이크 감지 / Inrush current SPIKE detected"
                )
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING

            # 회생 전류 검사 / Regeneration current check (PDF #25)
            if reading.regeneration_current_a > REGENERATION_CURRENT_A:
                self._logger.warning(
                    "⚡ 회생 전류 과다: %.1fA > %.1fA / Excessive regeneration current",
                    reading.regeneration_current_a, REGENERATION_CURRENT_A
                )
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING

            return status

    def test_layer2(self) -> Tuple[bool, str]:
        """
        레이어 2 독립 테스트 / Layer 2 independent test
        전류 제한 기능 검증
        Verifies current limiting functionality
        """
        # 정상 전류 테스트 / Normal current test
        status_ok = self.update_motor_currents([5.0, 5.0, 5.0, 5.0])  # 20A total

        # 과전류 테스트 / Overcurrent test
        status_over = self.update_motor_currents([8.0, 8.0, 8.0, 8.0])  # 32A total

        # 전원 이상 테스트 / Power anomaly test
        power_sag = PowerReading(bus_voltage_v=15.0, timestamp=time.time())
        status_sag = self.update_power_reading(power_sag)

        power_surge = PowerReading(bus_voltage_v=32.0, timestamp=time.time())
        status_surge = self.update_power_reading(power_surge)

        # 정상 복구 / Restore normal
        self.update_motor_currents([5.0, 5.0, 5.0, 5.0])
        self.update_power_reading(PowerReading(timestamp=time.time()))

        ok = (
            status_ok != SafetyStatus.EMERGENCY
            and status_over == SafetyStatus.EMERGENCY
        )
        msg = (
            "레이어 2 통과: 전류 제한 정상 / Layer 2 PASS: Current limiting OK"
            if ok else
            "레이어 2 실패: 전류 제한 이상 / Layer 2 FAIL: Current limiting error"
        )
        self._logger.info(msg)
        return ok, msg

    # ─────────────────────────────────────────────────────────
    # 레이어 3: 워치독 / Layer 3: Watchdog Timer
    # 100ms 내 응답 없으면 자동 정지
    # ─────────────────────────────────────────────────────────

    def heartbeat(self) -> None:
        """
        워치독 하트비트 / Watchdog heartbeat
        메인 제어 루프에서 주기적으로 호출해야 함
        Must be called periodically from the main control loop
        """
        with self._lock:
            self._watchdog_last_heartbeat = time.time()
            self._watchdog_missed_beats = 0

    def start_watchdog(self) -> None:
        """
        워치독 모니터링 시작 / Start watchdog monitoring
        별도 스레드에서 하트비트를 감시
        Monitors heartbeat in a separate thread
        """
        with self._lock:
            if self._watchdog_running:
                return
            self._watchdog_running = True
            self._watchdog_monitor_thread = threading.Thread(
                target=self._watchdog_loop,
                name="SafetyEngine-Watchdog",
                daemon=True,
            )
            self._watchdog_monitor_thread.start()
            self._logger.info("워치독 시작됨 / Watchdog started (timeout=%dms)", self._watchdog_timeout_ms)

    def stop_watchdog(self) -> None:
        """워치독 모니터링 중지 / Stop watchdog monitoring"""
        with self._lock:
            self._watchdog_running = False
        if self._watchdog_monitor_thread and self._watchdog_monitor_thread.is_alive():
            self._watchdog_monitor_thread.join(timeout=1.0)
        self._logger.info("워치독 중지됨 / Watchdog stopped")

    def _watchdog_loop(self) -> None:
        """
        워치독 감시 루프 / Watchdog monitoring loop
        하트비트 간격이 100ms를 초과하면 자동 정지
        Auto-stop if heartbeat interval exceeds 100ms
        """
        check_interval = self._watchdog_timeout_ms / 1000.0 / 4.0  # 4x 빈도로 확인 / Check at 4x frequency

        while self._watchdog_running:
            time.sleep(check_interval)
            with self._lock:
                elapsed_ms = (time.time() - self._watchdog_last_heartbeat) * 1000.0
                if elapsed_ms > self._watchdog_timeout_ms:
                    self._watchdog_missed_beats += 1
                    self._logger.critical(
                        "🐕 워치독 시간초과: %.1fms > %dms (놓친 횟수: %d) / "
                        "Watchdog TIMEOUT",
                        elapsed_ms, self._watchdog_timeout_ms, self._watchdog_missed_beats
                    )
                    # 자동 정지 / Auto-stop
                    self.trigger_estop(
                        f"워치독 시간초과 / Watchdog timeout: {elapsed_ms:.1f}ms"
                    )
                    self._fire_emergency(
                        EmergencyType.WATCHDOG_TIMEOUT,
                        {"elapsed_ms": elapsed_ms, "timeout_ms": self._watchdog_timeout_ms}
                    )

    def test_layer3(self) -> Tuple[bool, str]:
        """
        레이어 3 독립 테스트 / Layer 3 independent test
        워치독 타이머 기능 검증
        Verifies watchdog timer functionality
        """
        # 하트비트 갱신 테스트 / Test heartbeat update
        old_time = self._watchdog_last_heartbeat
        self.heartbeat()
        heartbeat_ok = self._watchdog_last_heartbeat > old_time

        # 타임아웃 감지 테스트 (시뮬레이션) / Test timeout detection (simulation)
        with self._lock:
            self._watchdog_last_heartbeat = time.time() - 0.2  # 200ms 전으로 설정 / Set 200ms ago
        elapsed_ok = (time.time() - self._watchdog_last_heartbeat) * 1000 > self._watchdog_timeout_ms

        # 복구 / Restore
        self.heartbeat()

        ok = heartbeat_ok and elapsed_ok
        msg = (
            "레이어 3 통과: 워치독 정상 / Layer 3 PASS: Watchdog OK"
            if ok else
            "레이어 3 실패: 워치독 이상 / Layer 3 FAIL: Watchdog error"
        )
        self._logger.info(msg)
        return ok, msg

    # ─────────────────────────────────────────────────────────
    # 레이어 4: 충돌 예측 / Layer 4: Collision Prediction
    # ToF/LiDAR → 0.5초 후 충돌 예측
    # ─────────────────────────────────────────────────────────

    def update_collision_data(self, data: CollisionData) -> SafetyStatus:
        """
        충돌 예측 데이터 업데이트 / Update collision prediction data
        ToF/LiDAR 데이터를 기반으로 0.5초 후 충돌을 예측합니다
        Predicts collision 0.5s ahead based on ToF/LiDAR data
        """
        with self._lock:
            self._collision_data = data
            status = SafetyStatus.NOMINAL

            # 최근 거리 검사 / Check nearest distance
            if data.nearest_distance_m < COLLISION_DISTANCE_M:
                status = SafetyStatus.EMERGENCY
                self._logger.critical(
                    "💥 충돌 임박: %.2fm < %.2fm / Collision IMMINENT",
                    data.nearest_distance_m, COLLISION_DISTANCE_M
                )
                self._fire_emergency(
                    EmergencyType.COLLISION_IMMINENT,
                    {"distance_m": data.nearest_distance_m,
                     "time_to_collision_s": data.time_to_collision_s}
                )

            # 충돌 예측 시간 검사 / Check predicted time to collision
            elif data.time_to_collision_s < COLLISION_PREDICTION_WINDOW_S:
                status = SafetyStatus.CRITICAL
                self._logger.warning(
                    "⚠️ 충돌 예측: %.2fs 후 / Collision predicted in %.2fs",
                    data.time_to_collision_s, data.time_to_collision_s
                )
                self._fire_emergency(
                    EmergencyType.COLLISION_IMMINENT,
                    {"distance_m": data.nearest_distance_m,
                     "time_to_collision_s": data.time_to_collision_s}
                )

            elif data.time_to_collision_s < COLLISION_PREDICTION_WINDOW_S * 2:
                status = SafetyStatus.WARNING
                self._logger.info(
                    "충돌 주의: %.2fs 후 / Collision caution: %.2fs ahead",
                    data.time_to_collision_s, data.time_to_collision_s
                )

            return status

    def predict_collision(
        self, distances: List[float], velocities: List[float]
    ) -> CollisionData:
        """
        거리/속도 데이터로 충돌 예측 / Predict collision from distance/velocity
        단순 운동학 모델: t = d / v
        Simple kinematic model: t = d / v
        """
        if not distances or not velocities:
            return CollisionData(
                distances_m=distances,
                velocities_m_s=velocities,
                timestamp=time.time()
            )

        min_ttc = float('inf')
        nearest = float('inf')

        for d, v in zip(distances, velocities):
            if d < nearest:
                nearest = d
            if v > 0:  # 접근 중 / Approaching
                ttc = d / v
                if ttc < min_ttc:
                    min_ttc = ttc

        data = CollisionData(
            distances_m=distances,
            velocities_m_s=velocities,
            time_to_collision_s=min_ttc,
            nearest_distance_m=nearest,
            timestamp=time.time()
        )
        return data

    def test_layer4(self) -> Tuple[bool, str]:
        """
        레이어 4 독립 테스트 / Layer 4 independent test
        충돌 예측 기능 검증
        Verifies collision prediction functionality
        """
        # 안전 상태 테스트 / Safe state test
        safe_data = CollisionData(
            distances_m=[2.0, 3.0, 5.0],
            velocities_m_s=[0.1, 0.0, 0.0],
            time_to_collision_s=20.0,
            nearest_distance_m=2.0,
            timestamp=time.time()
        )
        status_safe = self.update_collision_data(safe_data)

        # 충돌 임박 테스트 / Collision imminent test
        danger_data = CollisionData(
            distances_m=[0.1, 3.0, 5.0],
            velocities_m_s=[1.0, 0.0, 0.0],
            time_to_collision_s=0.1,
            nearest_distance_m=0.1,
            timestamp=time.time()
        )
        status_danger = self.update_collision_data(danger_data)

        # 예측 테스트 / Prediction test
        predicted = self.predict_collision([1.0, 2.0], [0.5, 2.0])
        prediction_ok = predicted.time_to_collision_s > 0

        # 복구 / Restore
        self.update_collision_data(safe_data)

        ok = (
            status_safe != SafetyStatus.EMERGENCY
            and status_danger == SafetyStatus.EMERGENCY
            and prediction_ok
        )
        msg = (
            "레이어 4 통과: 충돌 예측 정상 / Layer 4 PASS: Collision prediction OK"
            if ok else
            "레이어 4 실패: 충돌 예측 이상 / Layer 4 FAIL: Collision prediction error"
        )
        self._logger.info(msg)
        return ok, msg

    # ─────────────────────────────────────────────────────────
    # 레이어 5: AI 안전 검증 / Layer 5: AI Safety Verification
    # Gemma 4 명령이 위험한지 사전 평가
    # ─────────────────────────────────────────────────────────

    def evaluate_ai_command(self, command: AICommand) -> Tuple[bool, SafetyStatus]:
        """
        AI 명령 안전성 평가 / Evaluate AI command safety
        Gemma 4 기반으로 명령의 위험도를 사전 평가합니다
        Pre-evaluates command risk using Gemma 4

        Returns:
            (approved, status): 승인 여부와 안전 상태
            (approved, status): Approval flag and safety status
        """
        with self._lock:
            self._ai_command = command
            status = SafetyStatus.NOMINAL

            # 위험 점수 검사 / Risk score check
            if command.risk_score >= self._ai_risk_threshold:
                status = SafetyStatus.EMERGENCY
                self._logger.critical(
                    "🤖 AI 명령 거부: 위험점수=%.2f ≥ 임계값=%.2f / "
                    "AI command REJECTED: risk_score=%.2f ≥ threshold=%.2f — %s",
                    command.risk_score, self._ai_risk_threshold,
                    command.risk_score, self._ai_risk_threshold,
                    command.command_text
                )
                self._ai_rejected_commands.append(command)
                self._fire_emergency(
                    EmergencyType.AI_COMMAND_REJECTED,
                    {"command": command.command_text,
                     "risk_score": command.risk_score,
                     "category": command.category}
                )
                return False, status

            elif command.risk_score >= self._ai_risk_threshold * 0.7:
                status = SafetyStatus.WARNING
                self._logger.warning(
                    "🤖 AI 명령 주의: 위험점수=%.2f / "
                    "AI command CAUTION: risk_score=%.2f — %s",
                    command.risk_score, command.risk_score,
                    command.command_text
                )

            # 위험 카테고리 검사 / Dangerous category check
            dangerous_categories = {"aggressive", "destructive", "override_safety"}
            if command.category in dangerous_categories:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                self._logger.warning(
                    "🤖 위험 카테고리: %s / Dangerous category: %s",
                    command.category, command.category
                )

            # 위험 매개변수 검사 / Dangerous parameter check
            speed = command.parameters.get("speed", 0)
            force = command.parameters.get("force", 0)
            if speed > 0 and force > 0 and speed * force > 100:
                status = SafetyStatus.CRITICAL
                self._logger.warning(
                    "🤖 고위험 매개변수: speed=%.1f, force=%.1f / "
                    "High-risk parameters",
                    speed, force
                )

            approved = status not in (SafetyStatus.EMERGENCY, SafetyStatus.CRITICAL)
            return approved, status

    def set_ai_risk_threshold(self, threshold: float) -> None:
        """
        AI 위험 임계값 설정 / Set AI risk threshold
        0.0(모두 승인) ~ 1.0(모두 거부)
        0.0 (approve all) ~ 1.0 (reject all)
        """
        with self._lock:
            self._ai_risk_threshold = max(0.0, min(1.0, threshold))
            self._logger.info(
                "AI 위험 임계값 변경: %.2f / AI risk threshold changed to %.2f",
                self._ai_risk_threshold, self._ai_risk_threshold
            )

    def test_layer5(self) -> Tuple[bool, str]:
        """
        레이어 5 독립 테스트 / Layer 5 independent test
        AI 안전 검증 기능 검증
        Verifies AI safety verification functionality
        """
        # 안전한 명령 테스트 / Safe command test
        safe_cmd = AICommand(
            command_text="move_forward",
            risk_score=0.1,
            category="navigation",
            timestamp=time.time()
        )
        approved_safe, status_safe = self.evaluate_ai_command(safe_cmd)

        # 위험한 명령 테스트 / Dangerous command test
        danger_cmd = AICommand(
            command_text="emergency_override",
            risk_score=0.9,
            category="override_safety",
            timestamp=time.time()
        )
        approved_danger, status_danger = self.evaluate_ai_command(danger_cmd)

        ok = approved_safe and not approved_danger
        msg = (
            "레이어 5 통과: AI 안전 검증 정상 / Layer 5 PASS: AI safety verification OK"
            if ok else
            "레이어 5 실패: AI 안전 검증 이상 / Layer 5 FAIL: AI safety verification error"
        )
        self._logger.info(msg)
        return ok, msg

    # ─────────────────────────────────────────────────────────
    # 레이어 6: 구조적 무결성 / Layer 6: Structural Integrity (NEW V8.5)
    # PDF #51-75 대응
    # ─────────────────────────────────────────────────────────

    def update_structural_reading(self, reading: StructuralReading) -> SafetyStatus:
        """
        구조적 무결성 데이터 업데이트 / Update structural integrity data
        질량중심, 진동, 볼트풀림, 열팽창, 크리프, 베이스플레이트, 충격흡수 모니터링
        Monitors CoG, vibration, bolt looseness, thermal expansion, creep, base plate, impact absorber
        """
        with self._lock:
            self._structural_reading = reading

            # 이력 기록 / Record history
            self._structural_history.append(reading)
            if len(self._structural_history) > self._structural_max_history:
                self._structural_history = self._structural_history[-self._structural_max_history:]

            status = SafetyStatus.NOMINAL
            messages: List[str] = []

            # ── 질량 중심(CoG) 검사 / Center of Gravity check (PDF #51-55) ──
            if reading.cog_tilt_deg > COG_TILT_THRESHOLD_DEG:
                status = SafetyStatus.EMERGENCY
                messages.append(
                    f"전도 위험: CoG 기울기 {reading.cog_tilt_deg:.1f}° > "
                    f"{COG_TILT_THRESHOLD_DEG:.1f}° / Tip-over risk"
                )
                self._fire_emergency(
                    EmergencyType.STRUCTURAL_FAILURE,
                    {"type": "cog_tilt", "tilt_deg": reading.cog_tilt_deg,
                     "tipover_risk": reading.tipover_risk_score}
                )
            elif reading.cog_tilt_deg > COG_TILT_THRESHOLD_DEG * 0.7:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"CoG 기울기 주의: {reading.cog_tilt_deg:.1f}° / CoG tilt caution"
                )

            # ── 진동 공진 검사 / Vibration resonance check (PDF #56-60) ──
            if reading.resonance_detected:
                freq_lo, freq_hi = RESONANCE_FREQ_RANGE_HZ
                if freq_lo <= reading.vibration_frequency_hz <= freq_hi:
                    if status != SafetyStatus.EMERGENCY:
                        status = SafetyStatus.CRITICAL
                    messages.append(
                        f"공진 감지: {reading.vibration_frequency_hz:.1f}Hz, "
                        f"{reading.vibration_amplitude_g:.2f}G / Resonance detected"
                    )

            # 진동 이상 가속도 / Vibration anomaly amplitude
            if reading.vibration_amplitude_g > VIBRATION_ANOMALY_G:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"진동 이상: {reading.vibration_amplitude_g:.2f}G > "
                    f"{VIBRATION_ANOMALY_G}G / Vibration anomaly"
                )

            # ── 볼트/나사 풀림 검사 / Bolt looseness check (PDF #61-63) ──
            if reading.bolt_looseness_detected:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"볼트 풀림 감지: 진동={reading.bolt_vibration_g:.2f}G / "
                    f"Bolt looseness detected"
                )
                if reading.bolt_vibration_g > BOLT_LOOSENESS_VIBRATION_G:
                    if status != SafetyStatus.EMERGENCY:
                        status = SafetyStatus.CRITICAL
                    messages.append("심각한 볼트 풀림 / Severe bolt looseness")

            # 앵커 볼트 상태 / Anchor bolt status
            if reading.anchor_bolt_status in ("loose", "critical"):
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"앵커 볼트 상태: {reading.anchor_bolt_status} / "
                    f"Anchor bolt: {reading.anchor_bolt_status}"
                )

            # ── 열팽창 검사 / Thermal expansion check (PDF #64-66) ──
            if reading.thermal_warp_detected:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"열 뒤틀림 감지: 온도={reading.frame_temperature_c:.1f}°C, "
                    f"팽창={reading.thermal_expansion_mm:.3f}mm / Thermal warp detected"
                )

            # ── 크리프 검사 / Creep check (PDF #67-69) ──
            if reading.creep_detected or reading.creep_rate_mm_h > CREEP_RATE_THRESHOLD_MM_H:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"크리프 감지: {reading.creep_rate_mm_h:.4f}mm/h / "
                    f"Creep detected at {reading.creep_location or 'unknown'}"
                )
                if reading.creep_rate_mm_h > CREEP_RATE_THRESHOLD_MM_H * 3:
                    if status != SafetyStatus.EMERGENCY:
                        status = SafetyStatus.CRITICAL
                    messages.append("심각한 크리프 속도 / Severe creep rate")

            # ── 베이스 플레이트 변형 검사 / Base plate deformation check (PDF #70-72) ──
            if reading.base_plate_deformation_mm > BASE_PLATE_DEFORM_MM:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"베이스 플레이트 변형: {reading.base_plate_deformation_mm:.2f}mm > "
                    f"{BASE_PLATE_DEFORM_MM}mm / Base plate deformation"
                )
                if reading.base_plate_warp_detected:
                    if status != SafetyStatus.EMERGENCY:
                        status = SafetyStatus.CRITICAL

            # ── 충격 흡수 장치 검사 / Impact absorber check (PDF #73-75) ──
            if reading.impact_absorber_wear_pct > IMPACT_ABSORBER_WEAR_PCT:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"충격 흡수 장치 마모: {reading.impact_absorber_wear_pct:.1f}%% > "
                    f"{IMPACT_ABSORBER_WEAR_PCT}%% / Impact absorber wear"
                )
            if reading.impact_absorber_leaking:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append("충격 흡수 장치 누유 / Impact absorber leaking")

            # 로깅 / Logging
            if messages:
                log_level = {
                    SafetyStatus.WARNING: self._logger.warning,
                    SafetyStatus.CRITICAL: self._logger.critical,
                    SafetyStatus.EMERGENCY: self._logger.critical,
                }.get(status, self._logger.info)
                log_level("레이어 6 / Layer 6: %s", " | ".join(messages))

            return status

    def check_cog_stability(self) -> Tuple[bool, float]:
        """
        질량 중심 안정성 검사 / Check center of gravity stability
        전도 위험을 평가합니다
        Evaluates tip-over risk

        Returns:
            (stable, tipover_risk): 안정 여부와 전도 위험 점수
            (stable, tipover_risk): Stability flag and tip-over risk score
        """
        with self._lock:
            reading = self._structural_reading
            is_stable = reading.cog_tilt_deg < COG_TILT_THRESHOLD_DEG
            return is_stable, reading.tipover_risk_score

    def detect_resonance(self) -> Tuple[bool, float]:
        """
        진동 공진 감지 / Detect vibration resonance
        공진 주파수 대역에서의 진동을 감지합니다
        Detects vibration in resonance frequency bands

        Returns:
            (resonance, frequency): 공진 여부와 주파수
            (resonance, frequency): Resonance flag and frequency
        """
        with self._lock:
            reading = self._structural_reading
            freq_lo, freq_hi = RESONANCE_FREQ_RANGE_HZ
            in_range = freq_lo <= reading.vibration_frequency_hz <= freq_hi
            return (reading.resonance_detected and in_range), reading.vibration_frequency_hz

    def test_layer6(self) -> Tuple[bool, str]:
        """
        레이어 6 독립 테스트 / Layer 6 independent test
        구조적 무결성 기능 검증 (NEW V8.5)
        Verifies structural integrity functionality
        """
        # 정상 구조 상태 테스트 / Normal structural state test
        nominal_reading = StructuralReading(
            cog_tilt_deg=5.0,
            vibration_amplitude_g=0.5,
            vibration_frequency_hz=10.0,
            resonance_detected=False,
            bolt_looseness_detected=False,
            anchor_bolt_status="nominal",
            frame_temperature_c=25.0,
            thermal_expansion_mm=0.01,
            thermal_warp_detected=False,
            creep_rate_mm_h=0.001,
            creep_detected=False,
            base_plate_deformation_mm=0.1,
            base_plate_warp_detected=False,
            impact_absorber_wear_pct=50.0,
            impact_absorber_leaking=False,
            timestamp=time.time()
        )
        status_nominal = self.update_structural_reading(nominal_reading)

        # 전도 위험 테스트 / Tip-over risk test
        danger_reading = StructuralReading(
            cog_tilt_deg=20.0,          # 한계 초과 / Over threshold
            tipover_risk_score=0.9,
            vibration_amplitude_g=3.0,   # 이상 진동 / Anomalous vibration
            vibration_frequency_hz=50.0, # 공진 주파수 대역 / Resonance frequency range
            resonance_detected=True,
            bolt_looseness_detected=True,
            bolt_vibration_g=2.0,        # 볼트 풀림 진동 / Bolt looseness vibration
            anchor_bolt_status="loose",
            thermal_warp_detected=True,
            creep_rate_mm_h=0.05,        # 크리프 한계 초과 / Over creep threshold
            creep_detected=True,
            base_plate_deformation_mm=1.0,  # 변형 한계 초과 / Over deformation threshold
            base_plate_warp_detected=True,
            impact_absorber_wear_pct=90.0,
            impact_absorber_leaking=True,
            timestamp=time.time()
        )
        status_danger = self.update_structural_reading(danger_reading)

        # CoG 안정성 테스트 / CoG stability test
        stable, risk = self.check_cog_stability()

        # 공진 감지 테스트 / Resonance detection test
        resonance, freq = self.detect_resonance()

        # 복구 / Restore
        self.update_structural_reading(nominal_reading)

        ok = (
            status_nominal != SafetyStatus.EMERGENCY
            and status_danger in (SafetyStatus.CRITICAL, SafetyStatus.EMERGENCY)
        )
        msg = (
            "레이어 6 통과: 구조적 무결성 정상 / Layer 6 PASS: Structural integrity OK"
            if ok else
            "레이어 6 실패: 구조적 무결성 이상 / Layer 6 FAIL: Structural integrity error"
        )
        self._logger.info(msg)
        return ok, msg

    # ─────────────────────────────────────────────────────────
    # 레이어 7: 환경 경화 / Layer 7: Environmental Hardening (NEW V8.5)
    # PDF #76-100 대응
    # ─────────────────────────────────────────────────────────

    def update_environmental_reading(self, reading: EnvironmentalReading) -> SafetyStatus:
        """
        환경 경화 데이터 업데이트 / Update environmental hardening data
        미세먼지, 렌즈백화, 습도, EMI, 염해, 해충, E-Stop회로, 케이블, 커넥터, 누전차단기
        Monitors dust, lens haziness, humidity, EMI, saline, pests, E-Stop circuit, cable, connector, breaker
        """
        with self._lock:
            self._environmental_reading = reading

            # 이력 기록 / Record history
            self._environmental_history.append(reading)
            if len(self._environmental_history) > self._environmental_max_history:
                self._environmental_history = self._environmental_history[-self._environmental_max_history:]

            status = SafetyStatus.NOMINAL
            messages: List[str] = []

            # ── 미세먼지 간접 감지 / Fine dust indirect detection (PDF #76-78) ──
            # 온도 상승률로 간접 감지 — 냉각 불량 시 미세먼지 축적 의심
            # Indirect detection via temp rise rate — dust accumulation suspected when cooling is impaired
            if reading.dust_temp_rise_rate_c_min > DUST_TEMP_RISE_RATE_C_MIN:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"미세먼지 의심: 온도상승률 {reading.dust_temp_rise_rate_c_min:.1f}°C/min > "
                    f"{DUST_TEMP_RISE_RATE_C_MIN}°C/min / Dust suspected"
                )

            # ── 광학 센서 렌즈 백화 / Optical sensor lens haziness (PDF #79-81) ──
            if reading.optical_quality_pct < (100.0 - OPTICAL_QUALITY_DEGRADATION_PCT):
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"렌즈 백화: 품질 {reading.optical_quality_pct:.1f}%% / "
                    f"Lens haziness detected"
                )
                if reading.optical_quality_pct < 30.0:
                    if status != SafetyStatus.EMERGENCY:
                        status = SafetyStatus.CRITICAL
                    messages.append("심각한 렌즈 열화 / Severe lens degradation")

            # ── 습도 / Humidity (PDF #82-83) ──
            if reading.humidity_pct > HUMIDITY_CONDENSATION_PCT:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"결로 위험: 습도 {reading.humidity_pct:.1f}%% > "
                    f"{HUMIDITY_CONDENSATION_PCT}%% / Condensation risk"
                )
                if reading.condensation_risk:
                    if status != SafetyStatus.EMERGENCY:
                        status = SafetyStatus.CRITICAL

            # ── EMI 간섭 / EMI interference (PDF #84) ──
            if reading.emi_spike_detected:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"EMI 스파이크: 노이즈 {reading.emi_noise_level:.1f}x 기준 / "
                    f"EMI spike detected"
                )
                if reading.emi_noise_level > EMI_NOISE_SPIKE_FACTOR * reading.sensor_noise_baseline:
                    if status != SafetyStatus.EMERGENCY:
                        status = SafetyStatus.CRITICAL
                    messages.append("심각한 EMI 간섭 / Severe EMI interference")

            # ── 염해 / Saline corrosion (PDF #86-88) ──
            if reading.contact_resistance_change_pct > SALT_CONTACT_RESISTANCE_CHANGE_PCT:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"염해 의심: 접촉저항 변화 {reading.contact_resistance_change_pct:.1f}%% / "
                    f"Saline corrosion suspected"
                )
            if reading.saline_corrosion_detected:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append("염해 부식 감지 / Saline corrosion detected")

            # ── 해충 침입 / Pest intrusion (PDF #89-91) ──
            if reading.pest_intrusion_suspected:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"해충 침입 의심: 온도이상 {reading.temperature_anomaly_c:.1f}°C / "
                    f"Pest intrusion suspected"
                )
            if reading.ir_anomaly_detected and reading.temperature_anomaly_c > PEST_TEMPERATURE_ANOMALY_C:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    "적외선+온도 이상: 해충 침입 가능성 높음 / "
                    "IR+temp anomaly: High pest intrusion probability"
                )

            # ── E-Stop 회로 단선 연속 감지 / E-Stop circuit continuity (PDF #85 — 핵심!) ──
            if not reading.estop_circuit_continuous or reading.estop_wire_break_detected:
                status = SafetyStatus.EMERGENCY  # 최우선 비상 / Top priority emergency
                messages.append(
                    "🚨 E-Stop 회로 단선 감지 / E-Stop circuit WIRE BREAK detected: "
                    f"연속성={reading.estop_circuit_continuous}, "
                    f"R={reading.estop_circuit_resistance_ohm:.2f}Ω"
                )
                self._fire_emergency(
                    EmergencyType.ENVIRONMENTAL_HAZARD,
                    {"type": "estop_circuit_break",
                     "circuit_continuous": reading.estop_circuit_continuous,
                     "resistance_ohm": reading.estop_circuit_resistance_ohm}
                )
                # E-Stop 회로 이상은 자동 트리거 / Auto-trigger on circuit fault
                self.trigger_estop("E-Stop 회로 단선 / E-Stop circuit wire break")

            elif reading.estop_circuit_resistance_ohm > ESTOP_CIRCUIT_RESISTANCE_OHM:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"E-Stop 회로 저항 증가: {reading.estop_circuit_resistance_ohm:.2f}Ω > "
                    f"{ESTOP_CIRCUIT_RESISTANCE_OHM}Ω / E-Stop circuit resistance elevated"
                )

            # ── 전원 케이블 이탈 / Power cable disconnection (PDF #24) ──
            if reading.power_cable_disconnected or not reading.cable_connection_secure:
                if status != SafetyStatus.EMERGENCY:
                    status = SafetyStatus.CRITICAL
                messages.append(
                    f"전원 케이블 이탈 감지 / Power cable DISCONNECT detected: "
                    f"연결안전={reading.cable_connection_secure}, "
                    f"전압강하={reading.power_cable_vdrop_v:.2f}V"
                )
                self._fire_emergency(
                    EmergencyType.ENVIRONMENTAL_HAZARD,
                    {"type": "power_cable_disconnected",
                     "vdrop_v": reading.power_cable_vdrop_v}
                )

            elif reading.power_cable_vdrop_v > POWER_CABLE_VDROP_V:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"전원 케이블 전압 강하: {reading.power_cable_vdrop_v:.2f}V > "
                    f"{POWER_CABLE_VDROP_V}V / Power cable voltage drop"
                )

            # ── 커넥터 핀 산화 / Connector pin oxidation (PDF #15) ──
            if reading.connector_oxidation_detected:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"커넥터 핀 산화 감지: R={reading.connector_pin_resistance_ohm:.2f}Ω / "
                    f"Connector pin oxidation detected"
                )

            if reading.connector_pin_resistance_ohm > CONNECTOR_PIN_RESISTANCE_OHM:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"커넥터 핀 저항 증가: {reading.connector_pin_resistance_ohm:.2f}Ω > "
                    f"{CONNECTOR_PIN_RESISTANCE_OHM}Ω / Connector pin resistance elevated"
                )

            # ── 누전 차단기 오작동 / Leakage circuit breaker malfunction (PDF #23) ──
            if reading.breaker_malfunction:
                if status != SafetyStatus.EMERGENCY:
                    status = SafetyStatus.CRITICAL
                messages.append(
                    f"누전 차단기 오작동 감지 / Leakage breaker MALFUNCTION: "
                    f"누전전류={reading.leakage_current_ma:.1f}mA, "
                    f"트립횟수={reading.breaker_trip_count}"
                )
                self._fire_emergency(
                    EmergencyType.ENVIRONMENTAL_HAZARD,
                    {"type": "breaker_malfunction",
                     "leakage_current_ma": reading.leakage_current_ma,
                     "trip_count": reading.breaker_trip_count}
                )

            elif reading.leakage_current_ma > LEAKAGE_CURRENT_MA:
                if status == SafetyStatus.NOMINAL:
                    status = SafetyStatus.WARNING
                messages.append(
                    f"누전 전류 과다: {reading.leakage_current_ma:.1f}mA > "
                    f"{LEAKAGE_CURRENT_MA}mA / Excessive leakage current"
                )

            # 로깅 / Logging
            if messages:
                log_level = {
                    SafetyStatus.WARNING: self._logger.warning,
                    SafetyStatus.CRITICAL: self._logger.critical,
                    SafetyStatus.EMERGENCY: self._logger.critical,
                }.get(status, self._logger.info)
                log_level("레이어 7 / Layer 7: %s", " | ".join(messages))

            return status

    def check_estop_circuit_continuity(self) -> Tuple[bool, float]:
        """
        E-Stop 회로 연속성 검사 / Check E-Stop circuit continuity
        PDF #85 핵심 기능
        PDF #85 core functionality

        Returns:
            (continuous, resistance): 회로 연속성과 저항값
            (continuous, resistance): Circuit continuity and resistance value
        """
        with self._lock:
            reading = self._environmental_reading
            continuous = (
                reading.estop_circuit_continuous
                and not reading.estop_wire_break_detected
                and reading.estop_circuit_resistance_ohm <= ESTOP_CIRCUIT_RESISTANCE_OHM
            )
            return continuous, reading.estop_circuit_resistance_ohm

    def check_environmental_health(self) -> Dict[str, Any]:
        """
        환경 건전성 종합 검사 / Comprehensive environmental health check
        모든 환경 센서의 상태를 요약합니다
        Summarizes the status of all environmental sensors

        Returns:
            환경 건전성 보고서 딕셔너리 / Environmental health report dict
        """
        with self._lock:
            r = self._environmental_reading
            return {
                "dust_suspected": r.dust_accumulation_suspected,
                "lens_quality_pct": r.optical_quality_pct,
                "lens_haziness": r.lens_haziness_detected,
                "humidity_pct": r.humidity_pct,
                "condensation_risk": r.condensation_risk,
                "emi_spike": r.emi_spike_detected,
                "emi_noise_level": r.emi_noise_level,
                "saline_corrosion": r.saline_corrosion_detected,
                "pest_intrusion": r.pest_intrusion_suspected,
                "estop_circuit_ok": r.estop_circuit_continuous and not r.estop_wire_break_detected,
                "estop_resistance_ohm": r.estop_circuit_resistance_ohm,
                "power_cable_ok": r.cable_connection_secure and not r.power_cable_disconnected,
                "connector_oxidation": r.connector_oxidation_detected,
                "breaker_ok": not r.breaker_malfunction,
                "leakage_current_ma": r.leakage_current_ma,
                "timestamp": r.timestamp,
            }

    def test_layer7(self) -> Tuple[bool, str]:
        """
        레이어 7 독립 테스트 / Layer 7 independent test
        환경 경화 기능 검증 (NEW V8.5)
        Verifies environmental hardening functionality
        """
        # 정상 환경 상태 테스트 / Normal environmental state test
        nominal_reading = EnvironmentalReading(
            dust_temp_rise_rate_c_min=0.5,
            optical_quality_pct=95.0,
            humidity_pct=45.0,
            condensation_risk=False,
            emi_noise_level=1.0,
            emi_spike_detected=False,
            contact_resistance_change_pct=2.0,
            saline_corrosion_detected=False,
            temperature_anomaly_c=0.5,
            ir_anomaly_detected=False,
            pest_intrusion_suspected=False,
            estop_circuit_continuous=True,
            estop_circuit_resistance_ohm=0.5,
            estop_wire_break_detected=False,
            power_cable_disconnected=False,
            cable_connection_secure=True,
            power_cable_vdrop_v=0.3,
            connector_pin_resistance_ohm=0.1,
            connector_oxidation_detected=False,
            breaker_malfunction=False,
            leakage_current_ma=2.0,
            breaker_trip_count=0,
            timestamp=time.time()
        )
        status_nominal = self.update_environmental_reading(nominal_reading)

        # E-Stop 회로 단선 테스트 (PDF #85 핵심) / E-Stop circuit break test
        estop_break_reading = EnvironmentalReading(
            estop_circuit_continuous=False,
            estop_wire_break_detected=True,
            estop_circuit_resistance_ohm=50.0,
            timestamp=time.time()
        )
        status_estop = self.update_environmental_reading(estop_break_reading)

        # 전원 케이블 이탈 테스트 (PDF #24) / Power cable disconnect test
        cable_disconnect_reading = EnvironmentalReading(
            power_cable_disconnected=True,
            cable_connection_secure=False,
            power_cable_vdrop_v=5.0,
            timestamp=time.time()
        )
        status_cable = self.update_environmental_reading(cable_disconnect_reading)

        # 누전 차단기 오작동 테스트 (PDF #23) / Breaker malfunction test
        breaker_reading = EnvironmentalReading(
            breaker_malfunction=True,
            leakage_current_ma=50.0,
            breaker_trip_count=5,
            timestamp=time.time()
        )
        status_breaker = self.update_environmental_reading(breaker_reading)

        # 종합 위험 환경 테스트 / Comprehensive hazardous environment test
        danger_reading = EnvironmentalReading(
            dust_temp_rise_rate_c_min=5.0,
            dust_accumulation_suspected=True,
            optical_quality_pct=50.0,
            lens_haziness_detected=True,
            humidity_pct=95.0,
            condensation_risk=True,
            emi_noise_level=5.0,
            emi_spike_detected=True,
            contact_resistance_change_pct=30.0,
            saline_corrosion_detected=True,
            temperature_anomaly_c=8.0,
            ir_anomaly_detected=True,
            pest_intrusion_suspected=True,
            connector_pin_resistance_ohm=8.0,
            connector_oxidation_detected=True,
            leakage_current_ma=50.0,
            timestamp=time.time()
        )
        status_danger = self.update_environmental_reading(danger_reading)

        # E-Stop 회로 연속성 검사 / E-Stop circuit continuity check
        continuous, resistance = self.check_estop_circuit_continuity()

        # 복구 / Restore
        self.update_environmental_reading(nominal_reading)

        ok = (
            status_nominal != SafetyStatus.EMERGENCY
            and status_estop == SafetyStatus.EMERGENCY
            and status_cable in (SafetyStatus.CRITICAL, SafetyStatus.EMERGENCY)
            and status_breaker in (SafetyStatus.CRITICAL, SafetyStatus.EMERGENCY)
        )
        msg = (
            "레이어 7 통과: 환경 경화 정상 / Layer 7 PASS: Environmental hardening OK"
            if ok else
            "레이어 7 실패: 환경 경화 이상 / Layer 7 FAIL: Environmental hardening error"
        )
        self._logger.info(msg)
        return ok, msg

    # ─────────────────────────────────────────────────────────
    # 통합 안전 검사 / Comprehensive Safety Check
    # ─────────────────────────────────────────────────────────

    def check_safety(self) -> SafetyReport:
        """
        전체 7계층 안전 검사 / Comprehensive 7-layer safety check
        모든 레이어를 순차적으로 검사하고 종합 보고서를 생성합니다
        Checks all layers sequentially and generates a comprehensive report

        Returns:
            SafetyReport: 7계층 전체 안전 검사 보고서 / Full 7-layer safety check report
        """
        with self._lock:
            report = SafetyReport(
                version=self._version,
                timestamp=time.time(),
            )

            # ── 레이어 1: 하드웨어 E-Stop ──
            if self._estop_active:
                report.layer_statuses["layer1_hardware_estop"] = SafetyStatus.EMERGENCY
                report.layer_messages["layer1_hardware_estop"] = (
                    "E-Stop 활성 상태 / E-Stop is ACTIVE"
                )
                report.active_emergencies.append(EmergencyType.HARDWARE_ESTOP)
            elif not self._estop_circuit_ok:
                report.layer_statuses["layer1_hardware_estop"] = SafetyStatus.CRITICAL
                report.layer_messages["layer1_hardware_estop"] = (
                    "E-Stop 회로 불량 / E-Stop circuit FAULTY"
                )
            else:
                report.layer_statuses["layer1_hardware_estop"] = SafetyStatus.NOMINAL
                report.layer_messages["layer1_hardware_estop"] = (
                    "E-Stop 정상 / E-Stop OK"
                )

            # ── 레이어 2: 전류 제한 ──
            if self._motor_currents.total > MAX_TOTAL_CURRENT_A:
                report.layer_statuses["layer2_current_limit"] = SafetyStatus.EMERGENCY
                report.layer_messages["layer2_current_limit"] = (
                    f"과전류: {self._motor_currents.total:.1f}A / "
                    f"Overcurrent: {self._motor_currents.total:.1f}A"
                )
                report.active_emergencies.append(EmergencyType.OVERCURRENT)
            elif self._motor_currents.total > MAX_TOTAL_CURRENT_A * 0.8:
                report.layer_statuses["layer2_current_limit"] = SafetyStatus.WARNING
                report.layer_messages["layer2_current_limit"] = (
                    f"전류 경고: {self._motor_currents.total:.1f}A / "
                    f"Current warning: {self._motor_currents.total:.1f}A"
                )
            else:
                report.layer_statuses["layer2_current_limit"] = SafetyStatus.NOMINAL
                report.layer_messages["layer2_current_limit"] = (
                    f"전류 정상: {self._motor_currents.total:.1f}A / "
                    f"Current OK: {self._motor_currents.total:.1f}A"
                )

            # 전원 상태 추가 / Add power status
            if self._power_reading.bus_voltage_v < VOLTAGE_SAG_MIN_V:
                report.layer_statuses["layer2_power"] = SafetyStatus.EMERGENCY
                report.layer_messages["layer2_power"] = (
                    f"전압 강하: {self._power_reading.bus_voltage_v:.1f}V / Voltage sag"
                )
            elif self._power_reading.bus_voltage_v > VOLTAGE_SURGE_MAX_V:
                report.layer_statuses["layer2_power"] = SafetyStatus.EMERGENCY
                report.layer_messages["layer2_power"] = (
                    f"전압 서지: {self._power_reading.bus_voltage_v:.1f}V / Voltage surge"
                )
            else:
                report.layer_statuses["layer2_power"] = SafetyStatus.NOMINAL
                report.layer_messages["layer2_power"] = "전원 정상 / Power OK"

            # ── 레이어 3: 워치독 ──
            elapsed_ms = (time.time() - self._watchdog_last_heartbeat) * 1000.0
            if elapsed_ms > self._watchdog_timeout_ms:
                report.layer_statuses["layer3_watchdog"] = SafetyStatus.EMERGENCY
                report.layer_messages["layer3_watchdog"] = (
                    f"워치독 시간초과: {elapsed_ms:.1f}ms / "
                    f"Watchdog timeout: {elapsed_ms:.1f}ms"
                )
                report.active_emergencies.append(EmergencyType.WATCHDOG_TIMEOUT)
            elif elapsed_ms > self._watchdog_timeout_ms * 0.7:
                report.layer_statuses["layer3_watchdog"] = SafetyStatus.WARNING
                report.layer_messages["layer3_watchdog"] = (
                    f"워치독 주의: {elapsed_ms:.1f}ms / "
                    f"Watchdog caution: {elapsed_ms:.1f}ms"
                )
            else:
                report.layer_statuses["layer3_watchdog"] = SafetyStatus.NOMINAL
                report.layer_messages["layer3_watchdog"] = (
                    f"워치독 정상: {elapsed_ms:.1f}ms / "
                    f"Watchdog OK: {elapsed_ms:.1f}ms"
                )

            # ── 레이어 4: 충돌 예측 ──
            cd = self._collision_data
            if cd.nearest_distance_m < COLLISION_DISTANCE_M:
                report.layer_statuses["layer4_collision"] = SafetyStatus.EMERGENCY
                report.layer_messages["layer4_collision"] = (
                    f"충돌 임박: {cd.nearest_distance_m:.2f}m / "
                    f"Collision imminent: {cd.nearest_distance_m:.2f}m"
                )
                report.active_emergencies.append(EmergencyType.COLLISION_IMMINENT)
            elif cd.time_to_collision_s < COLLISION_PREDICTION_WINDOW_S:
                report.layer_statuses["layer4_collision"] = SafetyStatus.CRITICAL
                report.layer_messages["layer4_collision"] = (
                    f"충돌 예측: {cd.time_to_collision_s:.2f}s / "
                    f"Collision predicted: {cd.time_to_collision_s:.2f}s"
                )
            elif cd.time_to_collision_s < COLLISION_PREDICTION_WINDOW_S * 2:
                report.layer_statuses["layer4_collision"] = SafetyStatus.WARNING
                report.layer_messages["layer4_collision"] = (
                    f"충돌 주의: {cd.time_to_collision_s:.2f}s / "
                    f"Collision caution: {cd.time_to_collision_s:.2f}s"
                )
            else:
                report.layer_statuses["layer4_collision"] = SafetyStatus.NOMINAL
                report.layer_messages["layer4_collision"] = "충돌 예측 정상 / Collision prediction OK"

            # ── 레이어 5: AI 안전 검증 ──
            if self._ai_command and self._ai_command.risk_score >= self._ai_risk_threshold:
                report.layer_statuses["layer5_ai_safety"] = SafetyStatus.EMERGENCY
                report.layer_messages["layer5_ai_safety"] = (
                    f"AI 명령 거부: 위험점수={self._ai_command.risk_score:.2f} / "
                    f"AI command rejected: risk={self._ai_command.risk_score:.2f}"
                )
                report.active_emergencies.append(EmergencyType.AI_COMMAND_REJECTED)
            elif self._ai_command and self._ai_command.risk_score >= self._ai_risk_threshold * 0.7:
                report.layer_statuses["layer5_ai_safety"] = SafetyStatus.WARNING
                report.layer_messages["layer5_ai_safety"] = (
                    f"AI 명령 주의: 위험점수={self._ai_command.risk_score:.2f} / "
                    f"AI command caution: risk={self._ai_command.risk_score:.2f}"
                )
            else:
                report.layer_statuses["layer5_ai_safety"] = SafetyStatus.NOMINAL
                report.layer_messages["layer5_ai_safety"] = "AI 안전 검증 정상 / AI safety verification OK"

            # ── 레이어 6: 구조적 무결성 (NEW V8.5) ──
            sr = self._structural_reading
            layer6_status = SafetyStatus.NOMINAL
            layer6_msgs: List[str] = []

            if sr.cog_tilt_deg > COG_TILT_THRESHOLD_DEG:
                layer6_status = SafetyStatus.EMERGENCY
                layer6_msgs.append(f"전도 위험: {sr.cog_tilt_deg:.1f}° / Tip-over risk")
                report.active_emergencies.append(EmergencyType.STRUCTURAL_FAILURE)
            elif sr.cog_tilt_deg > COG_TILT_THRESHOLD_DEG * 0.7:
                layer6_status = SafetyStatus.WARNING
                layer6_msgs.append(f"CoG 기울기 주의 / CoG tilt caution")

            if sr.resonance_detected:
                freq_lo, freq_hi = RESONANCE_FREQ_RANGE_HZ
                if freq_lo <= sr.vibration_frequency_hz <= freq_hi:
                    layer6_status = max(layer6_status, SafetyStatus.CRITICAL)
                    layer6_msgs.append(f"공진 감지: {sr.vibration_frequency_hz:.1f}Hz / Resonance")

            if sr.bolt_looseness_detected:
                layer6_status = max(layer6_status, SafetyStatus.WARNING)
                layer6_msgs.append("볼트 풀림 / Bolt looseness")

            if sr.thermal_warp_detected:
                layer6_status = max(layer6_status, SafetyStatus.WARNING)
                layer6_msgs.append("열 뒤틀림 / Thermal warp")

            if sr.creep_detected or sr.creep_rate_mm_h > CREEP_RATE_THRESHOLD_MM_H:
                layer6_status = max(layer6_status, SafetyStatus.WARNING)
                layer6_msgs.append("크리프 감지 / Creep detected")

            if sr.base_plate_deformation_mm > BASE_PLATE_DEFORM_MM:
                layer6_status = max(layer6_status, SafetyStatus.WARNING)
                layer6_msgs.append("베이스 변형 / Base plate deformation")

            if sr.impact_absorber_wear_pct > IMPACT_ABSORBER_WEAR_PCT:
                layer6_status = max(layer6_status, SafetyStatus.WARNING)
                layer6_msgs.append("충격 흡수 마모 / Impact absorber wear")

            report.layer_statuses["layer6_structural"] = layer6_status
            report.layer_messages["layer6_structural"] = (
                " | ".join(layer6_msgs) if layer6_msgs else "구조 무결성 정상 / Structural integrity OK"
            )

            # ── 레이어 7: 환경 경화 (NEW V8.5) ──
            er = self._environmental_reading
            layer7_status = SafetyStatus.NOMINAL
            layer7_msgs: List[str] = []

            # E-Stop 회로 (PDF #85 — 최우선) / E-Stop circuit (top priority)
            if not er.estop_circuit_continuous or er.estop_wire_break_detected:
                layer7_status = SafetyStatus.EMERGENCY
                layer7_msgs.append("E-Stop 회로 단선 / E-Stop circuit wire break")
                report.active_emergencies.append(EmergencyType.ENVIRONMENTAL_HAZARD)

            # 전원 케이블 (PDF #24) / Power cable
            if er.power_cable_disconnected or not er.cable_connection_secure:
                layer7_status = max(layer7_status, SafetyStatus.CRITICAL)
                layer7_msgs.append("전원 케이블 이탈 / Power cable disconnected")

            # 누전 차단기 (PDF #23) / Leakage breaker
            if er.breaker_malfunction:
                layer7_status = max(layer7_status, SafetyStatus.CRITICAL)
                layer7_msgs.append("누전 차단기 오작동 / Breaker malfunction")

            # 미세먼지 / Dust
            if er.dust_temp_rise_rate_c_min > DUST_TEMP_RISE_RATE_C_MIN:
                layer7_status = max(layer7_status, SafetyStatus.WARNING)
                layer7_msgs.append("미세먼지 의심 / Dust suspected")

            # 렌즈 백화 / Lens haziness
            if er.optical_quality_pct < (100.0 - OPTICAL_QUALITY_DEGRADATION_PCT):
                layer7_status = max(layer7_status, SafetyStatus.WARNING)
                layer7_msgs.append("렌즈 백화 / Lens haziness")

            # 습도 / Humidity
            if er.humidity_pct > HUMIDITY_CONDENSATION_PCT:
                layer7_status = max(layer7_status, SafetyStatus.WARNING)
                layer7_msgs.append("결로 위험 / Condensation risk")

            # EMI / EMI interference
            if er.emi_spike_detected:
                layer7_status = max(layer7_status, SafetyStatus.WARNING)
                layer7_msgs.append("EMI 스파이크 / EMI spike")

            # 염해 / Saline
            if er.saline_corrosion_detected:
                layer7_status = max(layer7_status, SafetyStatus.WARNING)
                layer7_msgs.append("염해 부식 / Saline corrosion")

            # 해충 / Pests
            if er.pest_intrusion_suspected:
                layer7_status = max(layer7_status, SafetyStatus.WARNING)
                layer7_msgs.append("해충 침입 의심 / Pest intrusion")

            # 커넥터 산화 / Connector oxidation
            if er.connector_oxidation_detected:
                layer7_status = max(layer7_status, SafetyStatus.WARNING)
                layer7_msgs.append("커넥터 산화 / Connector oxidation")

            report.layer_statuses["layer7_environmental"] = layer7_status
            report.layer_messages["layer7_environmental"] = (
                " | ".join(layer7_msgs) if layer7_msgs else "환경 경화 정상 / Environmental hardening OK"
            )

            # ── 종합 상태 결정 / Determine overall status ──
            # 가장 심각한 상태를 전체 상태로 설정 / Set most severe status as overall
            severity_order = [
                SafetyStatus.NOMINAL, SafetyStatus.WARNING,
                SafetyStatus.CRITICAL, SafetyStatus.EMERGENCY
            ]
            worst = SafetyStatus.NOMINAL
            for layer_status in report.layer_statuses.values():
                if severity_order.index(layer_status) > severity_order.index(worst):
                    worst = layer_status
            report.overall_status = worst

            # ── 권장 사항 / Recommendations ──
            if report.overall_status == SafetyStatus.EMERGENCY:
                report.recommendations.append(
                    "🚨 즉시 로봇 정지 / IMMEDIATE robot stop required"
                )
            if SafetyLayer.LAYER1_HARDWARE_ESTOP in [
                SafetyLayer(k.split("_")[0].upper()) if k.startswith("LAYER") else SafetyLayer.LAYER1_HARDWARE_ESTOP
                for k in report.layer_statuses
                if report.layer_statuses[k] == SafetyStatus.EMERGENCY
            ]:
                report.recommendations.append(
                    "E-Stop 원인 확인 후 수동 해제 / Check E-Stop cause before manual release"
                )
            if self._current_violation_count > 3:
                report.recommendations.append(
                    "전류 위반 반복 — 모터 드라이버 점검 필요 / "
                    "Repeated current violations — motor driver inspection needed"
                )
            if not self._environmental_reading.estop_circuit_continuous:
                report.recommendations.append(
                    "E-Stop 회로 수리 필요 (PDF #85) / E-Stop circuit repair required"
                )
            if self._structural_reading.cog_tilt_deg > COG_TILT_THRESHOLD_DEG * 0.5:
                report.recommendations.append(
                    "하중 재분배 권장 / Load redistribution recommended"
                )

            return report

    # ─────────────────────────────────────────────────────────
    # 전체 레이어 테스트 / Full Layer Tests
    # ─────────────────────────────────────────────────────────

    def test_all_layers(self) -> Dict[str, Tuple[bool, str]]:
        """
        모든 7계층 독립 테스트 / Test all 7 layers independently
        각 레이어를 개별적으로 테스트합니다
        Tests each layer independently

        Returns:
            레이어별 테스트 결과 / Per-layer test results
        """
        results: Dict[str, Tuple[bool, str]] = {}

        self._logger.info("=" * 60)
        self._logger.info(
            "지훈 로봇 %s — 7계층 안전 엔진 전체 테스트 시작 / "
            "Jihun Robot %s — Seven-Layer Safety Engine Full Test START",
            self._version, self._version
        )
        self._logger.info("=" * 60)

        results["layer1_hardware_estop"] = self.test_layer1()
        results["layer2_current_limit"] = self.test_layer2()
        results["layer3_watchdog"] = self.test_layer3()
        results["layer4_collision_prediction"] = self.test_layer4()
        results["layer5_ai_safety"] = self.test_layer5()
        results["layer6_structural_integrity"] = self.test_layer6()
        results["layer7_environmental_hardening"] = self.test_layer7()

        # 결과 요약 / Results summary
        passed = sum(1 for ok, _ in results.values() if ok)
        total = len(results)
        self._logger.info("=" * 60)
        self._logger.info(
            "테스트 결과 / Test Results: %d/%d 통과 / PASSED", passed, total
        )
        for name, (ok, msg) in results.items():
            status_icon = "✅" if ok else "❌"
            self._logger.info("  %s %s: %s", status_icon, name, msg)
        self._logger.info("=" * 60)

        return results

    # ─────────────────────────────────────────────────────────
    # 수명 주기 / Lifecycle
    # ─────────────────────────────────────────────────────────

    def initialize(self) -> None:
        """
        안전 엔진 초기화 / Initialize safety engine
        모든 레이어의 초기 상태를 설정하고 워치독을 시작합니다
        Sets initial state for all layers and starts watchdog
        """
        with self._lock:
            if self._initialized:
                self._logger.warning("이미 초기화됨 / Already initialized")
                return

            # 초기 하트비트 / Initial heartbeat
            self._watchdog_last_heartbeat = time.time()

            # 워치독 시작 / Start watchdog
            self.start_watchdog()

            self._initialized = True
            self._logger.info(
                "지훈 로봇 %s 7계층 안전 엔진 초기화 완료 / "
                "Jihun Robot %s Seven-Layer Safety Engine initialized",
                self._version, self._version
            )

    def shutdown(self) -> None:
        """
        안전 엔진 종료 / Shutdown safety engine
        워치독을 중지하고 모든 리소스를 정리합니다
        Stops watchdog and cleans up all resources
        """
        with self._lock:
            if self._shutdown_flag:
                return

            self._shutdown_flag = True

            # 워치독 중지 / Stop watchdog
            self.stop_watchdog()

            self._logger.info(
                "지훈 로봇 %s 7계층 안전 엔진 종료 / "
                "Jihun Robot %s Seven-Layer Safety Engine shutdown",
                self._version, self._version
            )

    # ─────────────────────────────────────────────────────────
    # 유틸리티 / Utilities
    # ─────────────────────────────────────────────────────────

    def get_layer_status(self, layer: SafetyLayer) -> SafetyStatus:
        """
        특정 레이어 상태 조회 / Get specific layer status
        """
        report = self.check_safety()
        layer_name_map = {
            SafetyLayer.LAYER1_HARDWARE_ESTOP: "layer1_hardware_estop",
            SafetyLayer.LAYER2_CURRENT_LIMIT: "layer2_current_limit",
            SafetyLayer.LAYER3_WATCHDOG: "layer3_watchdog",
            SafetyLayer.LAYER4_COLLISION_PREDICTION: "layer4_collision",
            SafetyLayer.LAYER5_AI_SAFETY: "layer5_ai_safety",
            SafetyLayer.LAYER6_STRUCTURAL: "layer6_structural",
            SafetyLayer.LAYER7_ENVIRONMENTAL: "layer7_environmental",
        }
        key = layer_name_map.get(layer)
        if key and key in report.layer_statuses:
            return report.layer_statuses[key]
        return SafetyStatus.NOMINAL

    def get_diagnostics(self) -> Dict[str, Any]:
        """
        진단 정보 반환 / Return diagnostic information
        모든 레이어의 상세 상태를 포함합니다
        Includes detailed status of all layers
        """
        with self._lock:
            report = self.check_safety()
            return {
                "version": self._version,
                "initialized": self._initialized,
                "shutdown": self._shutdown_flag,
                "estop_active": self._estop_active,
                "estop_circuit_ok": self._estop_circuit_ok,
                "motor_current_total_a": self._motor_currents.total,
                "current_violation_count": self._current_violation_count,
                "bus_voltage_v": self._power_reading.bus_voltage_v,
                "watchdog_last_heartbeat": self._watchdog_last_heartbeat,
                "watchdog_missed_beats": self._watchdog_missed_beats,
                "collision_nearest_m": self._collision_data.nearest_distance_m,
                "collision_ttc_s": self._collision_data.time_to_collision_s,
                "ai_risk_threshold": self._ai_risk_threshold,
                "ai_rejected_count": len(self._ai_rejected_commands),
                "cog_tilt_deg": self._structural_reading.cog_tilt_deg,
                "resonance_detected": self._structural_reading.resonance_detected,
                "bolt_looseness": self._structural_reading.bolt_looseness_detected,
                "creep_detected": self._structural_reading.creep_detected,
                "estop_circuit_continuous": self._environmental_reading.estop_circuit_continuous,
                "humidity_pct": self._environmental_reading.humidity_pct,
                "emi_spike": self._environmental_reading.emi_spike_detected,
                "breaker_ok": not self._environmental_reading.breaker_malfunction,
                "overall_status": report.overall_status.name,
                "layer_statuses": {k: v.name for k, v in report.layer_statuses.items()},
                "active_emergencies": [e.name for e in report.active_emergencies],
                "recommendations": report.recommendations,
                "timestamp": time.time(),
            }

    def __repr__(self) -> str:
        return (
            f"SevenLayerSafetyEngine(version={self._version}, "
            f"estop_active={self._estop_active}, "
            f"initialized={self._initialized})"
        )


# ─────────────────────────────────────────────────────────────
# 모듈 실행 테스트 / Module Execution Test
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # 로깅 설정 / Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S"
    )

    print("=" * 70)
    print(f"지훈 로봇 {VERSION} — 7계층 안전 엔진 / Seven-Layer Safety Engine")
    print(f"Jihun Robot {VERSION} — Seven-Layer Safety Engine")
    print("=" * 70)
    print()

    # 엔진 인스턴스 생성 / Create engine instance
    engine = SevenLayerSafetyEngine()

    # 초기화 / Initialize
    engine.initialize()
    print(f"엔진 버전 / Engine version: {engine.version}")
    print(f"E-Stop 활성 / E-Stop active: {engine.estop_active}")
    print()

    # 전체 7계층 테스트 / Full 7-layer test
    results = engine.test_all_layers()

    # 진단 정보 / Diagnostics
    print()
    print("── 진단 정보 / Diagnostics ──")
    diag = engine.get_diagnostics()
    for key, value in diag.items():
        if isinstance(value, dict):
            print(f"  {key}:")
            for k, v in value.items():
                print(f"    {k}: {v}")
        elif isinstance(value, list):
            print(f"  {key}: {value}")
        else:
            print(f"  {key}: {value}")

    # 종합 안전 검사 / Comprehensive safety check
    print()
    print("── 종합 안전 검사 / Comprehensive Safety Check ──")
    report = engine.check_safety()
    print(f"  전체 상태 / Overall: {report.overall_status.name}")
    for layer, status in report.layer_statuses.items():
        msg = report.layer_messages.get(layer, "")
        print(f"  {layer}: {status.name} — {msg}")
    if report.active_emergencies:
        print(f"  활성 비상 / Active emergencies: {[e.name for e in report.active_emergencies]}")
    if report.recommendations:
        print("  권장 사항 / Recommendations:")
        for rec in report.recommendations:
            print(f"    - {rec}")

    # 종료 / Shutdown
    engine.shutdown()
    print()
    print("안전 엔진 종료 완료 / Safety engine shutdown complete")
