#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TODO 3: PREEMPT_RT 커널 패치 및 실시간 스케줄링
=================================================================

JetPack 6 커널에 PREEMPT_RT 패치 적용
100Hz 모터 제어 루프가 Linux 스케줄링 지터에 밀리지 않기 위함

검증 기준:
  - cyclictest -m -Sp90 -i1000 -D10 결과 <50μs 지터

산출물:
  - /boot/Image.rt
  - /opt/jihun/scripts/enable_rt.sh

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import os
import platform
import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from hardware.config import JihunRobotV7Config

logger = logging.getLogger("jihun.v84.rt_kernel")

# ============================================================================
# 상수
# ============================================================================

CONFIG_DIR = Path("/opt/jihun")
SCRIPTS_DIR = CONFIG_DIR / "scripts"
KERNEL_DIR = Path("/usr/src/kernel")
BOOT_RT_IMAGE = Path("/boot/Image.rt")

# cyclictest 기준
CYCLICTEST_MAX_LATENCY_US = 50   # 최대 허용 지터 (μs)
CYCLICTEST_DURATION_S = 10       # 테스트 지속 시간
CYCLICTEST_PRIORITY = 90         # RT 우선순위
CYCLICTEST_INTERVAL_US = 1000    # 측정 간격 (μs)

# RT 스케줄러 우선순위 매핑
RT_PRIORITY_MAP = {
    "motor_control": 90,       # 최고 — 100Hz 모터 제어
    "reflex_engine": 85,       # 반사 엔진
    "sensory_fusion": 80,     # 감각 융합
    "can_bus_rx": 75,         # CAN 수신
    "uart_comm": 70,          # UART 통신
    "stt_pipeline": 60,      # STT 파이프라인
    "tts_pipeline": 50,      # TTS 파이프라인
    "vision_pipeline": 40,   # 비전 (비실시간)
    "ai_inference": 30,      # AI 추론 (비실시간)
    "logging": 10,           # 로깅 (최저)
}

# enable_rt.sh 스크립트 내용
ENABLE_RT_SCRIPT = """#!/bin/bash
# 지훈 로봇 V8.5 — RT 커널 활성화 스크립트
# PREEMPT_RT 커널로 부팅 시 자동 실행

set -e

echo "[Jihun V7] RT 커널 활성화 중..."

# RT 커널 이미지 확인
if [ ! -f /boot/Image.rt ]; then
    echo "[Jihun V7] 오류: /boot/Image.rt 없음 — RT 커널 미설치"
    exit 1
fi

# 현재 커널이 RT인지 확인
if grep -q "PREEMPT_RT" /proc/version; then
    echo "[Jihun V7] 이미 RT 커널 실행 중"
else
    echo "[Jihun V7] RT 커널로 부팅 필요"
    echo "[Jihun V7] sudo cp /boot/Image.rt /boot/Image 후 재부팅"
fi

# RT 스케줄러 우선순위 설정
for svc in motor_control reflex_engine sensory_fusion can_bus_rx; do
    pid=$(pgrep -f "jihun.*${svc}" 2>/dev/null || true)
    if [ -n "$pid" ]; then
        prio=$(python3 -c "
import json
with open('/opt/jihun/rt_priorities.json') as f:
    d = json.load(f)
print(d.get('${svc}', 50))
")
        chrt -f -p $prio $pid 2>/dev/null || true
        echo "[Jihun V7] ${svc} (PID: $pid) → RT 우선순위 $prio"
    fi
done

# CPU 격리 설정 (CPU 3을 RT 전용으로)
if [ -f /sys/devices/system/cpu/cpu3/online ]; then
    echo 0 > /sys/devices/system/cpu/cpu3/online 2>/dev/null || true
    echo 1 > /sys/devices/system/cpu/cpu3/online 2>/dev/null || true
    echo "[Jihun V7] CPU3 온라인 확인"
fi

# IRQ 어피니티 — 네트워크/CAN 인터럽트를 CPU 0-2로 제한
echo 7 > /proc/irq/default_smp_affinity 2>/dev/null || true

echo "[Jihun V7] RT 커널 활성화 완료"
"""


@dataclass
class RTKernelInfo:
    """RT 커널 정보"""
    kernel_version: str = ""
    is_rt_kernel: bool = False
    preempt_level: str = ""       # PREEMPT, PREEMPT_RT, PREEMPT_VOLUNTARY 등
    rt_patch_version: str = ""
    available_cpus: int = 0


@dataclass
class CyclicTestResult:
    """cyclictest 결과"""
    min_latency_us: float = -1.0
    avg_latency_us: float = -1.0
    max_latency_us: float = -1.0
    act_latency_us: float = -1.0   # 최악값 (99.99%)
    passed: bool = False
    raw_output: str = ""


class RTKernel:
    """
    TODO 3: PREEMPT_RT 커널 패치 및 실시간 스케줄링

    기능:
      - RT 커널 가용성 확인
      - PREEMPT_RT 패치 적용
      - cyclictest 지터 검증 (<50μs)
      - RT 스케줄러 우선순위 설정
      - 부트 컨피그 생성 (/boot/Image.rt)
    """

    def __init__(self, config: Optional[JihunRobotV7Config] = None):
        self.config = config or JihunRobotV7Config()
        self._kernel_info: Optional[RTKernelInfo] = None

    # ========================================================================
    # 공용 메서드
    # ========================================================================

    def setup(self) -> bool:
        """전체 RT 커널 설정"""
        logger.info("=== PREEMPT_RT 커널 설정 시작 ===")

        # 1. 현재 커널 확인
        info = self._get_kernel_info()
        self._kernel_info = info

        if info.is_rt_kernel:
            logger.info("  이미 PREEMPT_RT 커널 실행 중")
        else:
            # 2. RT 패치 적용
            if not self.apply_rt_patch():
                logger.error("RT 패치 적용 실패")
                return False

        # 3. cyclictest 검증
        test = self.run_cyclictest()
        if not test.passed:
            logger.warning(f"  ⚠ cyclictest 미통과: 최대 {test.max_latency_us:.1f}μs > {CYCLICTEST_MAX_LATENCY_US}μs")
            logger.warning("  커널 설정 조정 후 재테스트 필요")
        else:
            logger.info(f"  ✓ cyclictest 통과: 최대 {test.max_latency_us:.1f}μs < {CYCLICTEST_MAX_LATENCY_US}μs")

        # 4. RT 스케줄러 설정
        self.enable_rt_scheduler()

        # 5. 부트 설정 생성
        self.generate_boot_config()

        logger.info("=== PREEMPT_RT 커널 설정 완료 ===")
        return True

    def verify(self) -> bool:
        """RT 커널 상태 검증"""
        info = self._get_kernel_info()
        if not info.is_rt_kernel:
            return False
        test = self.run_cyclictest()
        return test.passed

    # ========================================================================
    # TODO 3-1: RT 커널 가용성 확인
    # ========================================================================

    def check_rt_available(self) -> RTKernelInfo:
        """
        PREEMPT_RT 패치 가용성 확인

        확인 항목:
          - /proc/version에 PREEMPT_RT 포함 여부
          - 커널 설정 CONFIG_PREEMPT_RT=y
          - /boot/Image.rt 존재 여부
        """
        return self._get_kernel_info()

    def _get_kernel_info(self) -> RTKernelInfo:
        """커널 정보 수집"""
        info = RTKernelInfo()

        # /proc/version 확인
        try:
            version_text = Path("/proc/version").read_text().strip()
            info.kernel_version = version_text

            if "PREEMPT_RT" in version_text:
                info.is_rt_kernel = True
                info.preempt_level = "PREEMPT_RT"
            elif "PREEMPT" in version_text:
                info.preempt_level = "PREEMPT"
            else:
                info.preempt_level = "NONE"
        except IOError:
            pass

        # /boot/Image.rt 확인
        if BOOT_RT_IMAGE.exists():
            info.rt_patch_version = "installed"

        # CPU 수 확인
        info.available_cpus = os.cpu_count() or 4

        return info

    # ========================================================================
    # TODO 3-2: PREEMPT_RT 패치 적용
    # ========================================================================

    def apply_rt_patch(self) -> bool:
        """
        JetPack 6 커널에 PREEMPT_RT 패치 적용

        과정:
          1. 현재 커널 소스 확인
          2. 대응하는 RT 패치 다운로드
          3. 패치 적용
          4. 커널 설정 (CONFIG_PREEMPT_RT=y)
          5. 커널 빌드
          6. /boot/Image.rt 로 설치
        """
        logger.info("PREEMPT_RT 패치 적용 중...")

        # 이미 RT 커널인 경우 스킵
        info = self._get_kernel_info()
        if info.is_rt_kernel:
            logger.info("  이미 RT 커널 — 패치 불필요")
            return True

        # 1. 커널 소스 디렉토리 확인
        if not KERNEL_DIR.exists():
            logger.error(f"  ✗ 커널 소스 없음: {KERNEL_DIR}")
            logger.info("  설치: sudo apt-get install nvidia-l4t-kernel-headers")
            return False

        # 2. 현재 커널 버전 확인
        kernel_version = self._get_current_kernel_version()
        if not kernel_version:
            logger.error("  ✗ 커널 버전 감지 실패")
            return False
        logger.info(f"  현재 커널: {kernel_version}")

        # 3. RT 패치 다운로드 (커널 버전에 맞는 패치)
        rt_patch_url = self._get_rt_patch_url(kernel_version)
        if rt_patch_url:
            logger.info(f"  RT 패치 URL: {rt_patch_url}")
        else:
            logger.warning("  ⚠ 자동 패치 URL 감지 불가 — 수동 다운로드 필요")
            logger.info("  https://cdn.kernel.org/pub/linux/kernel/projects/rt/")

        # 4. 패치 적용 및 빌드 안내
        logger.info("  RT 커널 빌드 절차:")
        logger.info("    cd /usr/src/kernel")
        logger.info(f"    wget {rt_patch_url or '<RT_PATCH_URL>'}")
        logger.info("    xz -d patch-*.patch.xz")
        logger.info("    patch -p1 < patch-*.patch")
        logger.info("    make menuconfig  # General setup → Preemption Model → Fully Preemptible")
        logger.info("    make -j$(nproc) Image")
        logger.info("    sudo cp arch/arm64/boot/Image /boot/Image.rt")

        # 5. enable_rt.sh 스크립트 설치
        self._install_enable_rt_script()

        return True

    def _get_current_kernel_version(self) -> str:
        """현재 커널 버전 조회"""
        try:
            result = subprocess.run(
                ["uname", "-r"], capture_output=True, text=True, timeout=5
            )
            return result.stdout.strip()
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return ""

    def _get_rt_patch_url(self, kernel_version: str) -> Optional[str]:
        """커널 버전에 맞는 RT 패치 URL 생성"""
        # 예: 5.15.148-tegra → 5.15.x RT 패치
        match = re.match(r"(\d+\.\d+)", kernel_version)
        if match:
            base_version = match.group(1)
            return (
                f"https://cdn.kernel.org/pub/linux/kernel/projects/rt/"
                f"{base_version}/"
            )
        return None

    def _install_enable_rt_script(self) -> bool:
        """enable_rt.sh 스크립트 설치"""
        try:
            SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)
            script_path = SCRIPTS_DIR / "enable_rt.sh"
            script_path.write_text(ENABLE_RT_SCRIPT)
            os.chmod(script_path, 0o755)
            logger.info(f"  ✓ enable_rt.sh 설치: {script_path}")
            return True
        except IOError as e:
            logger.error(f"  ✗ 스크립트 설치 실패: {e}")
            return False

    # ========================================================================
    # TODO 3-3: cyclictest 지터 검증
    # ========================================================================

    def run_cyclictest(self) -> CyclicTestResult:
        """
        cyclictest 실행 — <50μs 지터 검증

        명령: cyclictest -m -Sp90 -i1000 -D10
          -m: 메모리 잠금
          -S: SMI 비활성화 (가능한 경우)
          -p90: RT 우선순위 90
          -i1000: 1000μs 간격
          -D10: 10초간 실행
        """
        result = CyclicTestResult()

        # cyclictest 설치 확인
        if not self._check_cyclictest():
            logger.warning("  cyclictest 미설치 — 설치 권장: sudo apt-get install rt-tests")
            return result

        logger.info("cyclictest 실행 중...")
        try:
            cmd = [
                "sudo", "cyclictest",
                "-m",               # 메모리 잠금
                "-S",               # SMI 비활성화
                f"-p{CYCLICTEST_PRIORITY}",
                f"-i{CYCLICTEST_INTERVAL_US}",
                f"-D{CYCLICTEST_DURATION_S}",
                "-h", "400",        # 히스토그램
            ]
            proc = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=CYCLICTEST_DURATION_S + 30,
            )

            result.raw_output = proc.stdout

            if proc.returncode == 0:
                # 결과 파싱
                # 예: "Min: 00005 Act: 00008 Avg: 00012 Max: 00045"
                for line in proc.stdout.splitlines():
                    if "Min:" in line and "Max:" in line:
                        parts = line.split()
                        for i, p in enumerate(parts):
                            if p == "Min:":
                                result.min_latency_us = int(parts[i + 1])
                            elif p == "Act:":
                                result.act_latency_us = int(parts[i + 1])
                            elif p == "Avg:":
                                result.avg_latency_us = int(parts[i + 1])
                            elif p == "Max:":
                                result.max_latency_us = int(parts[i + 1])

                result.passed = result.max_latency_us < CYCLICTEST_MAX_LATENCY_US

                if result.passed:
                    logger.info(
                        f"  ✓ cyclictest 통과: "
                        f"Min={result.min_latency_us}μs "
                        f"Avg={result.avg_latency_us}μs "
                        f"Max={result.max_latency_us}μs "
                        f"< {CYCLICTEST_MAX_LATENCY_US}μs"
                    )
                else:
                    logger.warning(
                        f"  ⚠ cyclictest 초과: "
                        f"Max={result.max_latency_us}μs > {CYCLICTEST_MAX_LATENCY_US}μs"
                    )
            else:
                logger.error(f"  cyclictest 실행 오류: {proc.stderr}")

        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.error(f"  cyclictest 실행 불가: {e}")

        return result

    @staticmethod
    def _check_cyclictest() -> bool:
        """cyclictest 설치 확인"""
        try:
            result = subprocess.run(
                ["which", "cyclictest"],
                capture_output=True, text=True, timeout=5,
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    # ========================================================================
    # TODO 3-4: RT 스케줄러 우선순위 설정
    # ========================================================================

    def enable_rt_scheduler(self) -> bool:
        """
        RT 스케줄러 우선순위 설정

        우선순위 매핑:
          90: 모터 제어 (최고)
          85: 반사 엔진
          80: 감각 융합
          75: CAN 수신
          70: UART 통신
          60: STT
          50: TTS
          40: 비전
          30: AI 추론
          10: 로깅
        """
        logger.info("RT 스케줄러 우선순위 설정 중...")

        # 우선순위 설정 파일 저장
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            prio_path = CONFIG_DIR / "rt_priorities.json"
            prio_path.write_text(json.dumps(RT_PRIORITY_MAP, indent=2))
            logger.info(f"  ✓ RT 우선순위 매핑 저장: {prio_path}")
        except IOError as e:
            logger.warning(f"  ⚠ 우선순위 파일 저장 실패: {e}")

        # 커널 파라미터 설정
        rt_sysctl = {
            "kernel.sched_rt_runtime_us": "-1",      # RT 스케줄링 제한 해제
            "kernel.sched_min_granularity_ns": "1000000",  # 최소 그래뉴러리티 1ms
            "kernel.sched_wakeup_granularity_ns": "500000",  # 웨이크업 그래뉴러리티 0.5ms
        }

        for key, value in rt_sysctl.items():
            try:
                subprocess.run(
                    ["sudo", "sysctl", "-w", f"{key}={value}"],
                    capture_output=True, text=True, timeout=5,
                )
                logger.info(f"  ✓ sysctl {key}={value}")
            except (FileNotFoundError, subprocess.TimeoutExpired):
                logger.warning(f"  ⚠ sysctl 설정 불가: {key}")

        # 실행 중인 프로세스에 RT 스케줄러 적용
        self._apply_rt_to_running_processes()

        logger.info("  ✓ RT 스케줄러 설정 완료")
        return True

    def _apply_rt_to_running_processes(self) -> None:
        """실행 중인 프로세스에 RT 우선순위 적용"""
        for service, priority in RT_PRIORITY_MAP.items():
            try:
                # 프로세스 찾기
                result = subprocess.run(
                    ["pgrep", "-f", f"jihun.*{service}"],
                    capture_output=True, text=True, timeout=5,
                )
                if result.returncode == 0 and result.stdout.strip():
                    pid = result.stdout.strip().split("\n")[0]
                    # chrt로 RT FIFO 스케줄러 적용
                    subprocess.run(
                        ["sudo", "chrt", "-f", "-p", str(priority), pid],
                        capture_output=True, text=True, timeout=5,
                    )
                    logger.info(f"  ✓ {service} (PID {pid}) → RT FIFO {priority}")
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

    # ========================================================================
    # TODO 3-5: 부트 컨피그 생성
    # ========================================================================

    def generate_boot_config(self) -> bool:
        """
        /boot/Image.rt 부트 컨피그 생성

        extlinux.conf에 RT 커널 부트 옵션 추가:
          - isolcpus=3         — CPU 3을 RT 전용으로 격리
          - nohz_full=3        — 틱리스 모드
          - rcu_nocbs=3        — RCU 콜백 오프로드
          - irqaffinity=0-2    — IRQ를 CPU 0-2로 제한
        """
        logger.info("부트 컨피그 생성 중...")

        boot_config_content = """# 지훈 로봇 V8.5 — RT 커널 부트 설정
# /boot/extlinux.conf에 추가할 내용

TIMEOUT 30
DEFAULT primary

MENU TITLE Jihun Robot V8.5 Boot Options

LABEL primary
    MENU LABEL Primary Kernel (Standard)
    LINUX /boot/Image
    INITRD /boot/initrd
    APPEND ${cbootargs} quiet

LABEL rt
    MENU LABEL RT Kernel (PREEMPT_RT)
    LINUX /boot/Image.rt
    INITRD /boot/initrd
    APPEND ${cbootargs} isolcpus=3 nohz_full=3 rcu_nocbs=3 irqaffinity=0-2 quiet
"""

        # 부트 컨피그 저장
        config_path = CONFIG_DIR / "boot_extlinux.conf.example"
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            config_path.write_text(boot_config_content)
            logger.info(f"  ✓ 부트 컨피그 예시: {config_path}")
        except IOError as e:
            logger.warning(f"  ⚠ 부트 컨피그 저장 실패: {e}")

        # 실제 extlinux.conf 업데이트 안내
        extlinux_path = Path("/boot/extlinux/extlinux.conf")
        if extlinux_path.exists():
            logger.info(f"  기존 부트 컨피그: {extlinux_path}")
            logger.info("  RT 커널 부트 옵션 추가 후 재부팅 필요")
        else:
            logger.info("  부트 컨피그 수동 설정 필요")

        # enable_rt.sh 설치
        self._install_enable_rt_script()

        logger.info("  ✓ 부트 컨피그 생성 완료")
        return True

    # ========================================================================
    # 유틸리티
    # ========================================================================

    def get_rt_status(self) -> Dict:
        """현재 RT 커널 상태 반환"""
        info = self._get_kernel_info()
        return {
            "kernel_version": info.kernel_version[:80] if info.kernel_version else "",
            "is_rt_kernel": info.is_rt_kernel,
            "preempt_level": info.preempt_level,
            "rt_image_installed": BOOT_RT_IMAGE.exists(),
            "available_cpus": info.available_cpus,
            "priorities": RT_PRIORITY_MAP,
        }
