#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 눈 디스플레이 시스템 (Eye Display System)
=========================================================

GC9A01 240×240 원형 TFT ×2 (좌/우 눈) SPI 제어
표정 렌더링, 애니메이션, 깜빡임, 커스텀 비트맵 지원

TODO 49: eye_display.py

하드웨어:
  - GC9A01 1.09" Circular TFT ×2
  - SPI 20MHz, RGB565 포맷
  - Jetson #2 SPI 버스 (CS0=좌안, GPIO CS=우안)
  - 10fps 업데이트, 감정 명령 → 200ms 이내 표정 변경

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import struct
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

# 하드웨어 의존성 (실제 환경에서 활성화)
try:
    import spidev
    SPI_AVAILABLE = True
except ImportError:
    SPI_AVAILABLE = False

try:
    import RPi.GPIO as GPIO
    GPIO_AVAILABLE = True
except ImportError:
    GPIO_AVAILABLE = False

logger = logging.getLogger(__name__)


# ============================================================================
# 열거형 및 상수
# ============================================================================

class Expression(Enum):
    """표정 종류 — 감정 명령과 매핑"""
    HAPPY = "happy"
    SAD = "sad"
    SURPRISED = "surprised"
    ANGRY = "angry"
    NEUTRAL = "neutral"
    SLEEPY = "sleepy"
    LOVE = "love"
    THINKING = "thinking"
    CUSTOM = "custom"


class EyeSide(Enum):
    """눈 좌/우 구분"""
    LEFT = "left"
    RIGHT = "right"


# GC9A01 명령어 정의
GC9A01_CMD_NOP = 0x00
GC9A01_CMD_SWRESET = 0x01
GC9A01_CMD_SLPIN = 0x10
GC9A01_CMD_SLPOUT = 0x11
GC9A01_CMD_PTLON = 0x12
GC9A01_CMD_NORON = 0x13
GC9A01_CMD_INVOFF = 0x20
GC9A01_CMD_INVON = 0x21
GC9A01_CMD_DISPOFF = 0x28
GC9A01_CMD_DISPON = 0x29
GC9A01_CMD_CASET = 0x2A
GC9A01_CMD_RASET = 0x2B
GC9A01_CMD_RAMWR = 0x2C
GC9A01_CMD_MADCTL = 0x36
GC9A01_CMD_COLMOD = 0x3A

# 화면 해상도
DISPLAY_WIDTH = 240
DISPLAY_HEIGHT = 240
DISPLAY_PIXELS = DISPLAY_WIDTH * DISPLAY_HEIGHT

# 색상 정의 (RGB565)
COLOR_BLACK = 0x0000
COLOR_WHITE = 0xFFFF
COLOR_RED = 0xF800
COLOR_GREEN = 0x07E0
COLOR_BLUE = 0x001F
COLOR_YELLOW = 0xFFE0
COLOR_CYAN = 0x07FF
COLOR_MAGENTA = 0xF81F
COLOR_ORANGE = 0xFD20
COLOR_PINK = 0xFE19

# 타이밍
SPI_SPEED_MHZ = 20
TARGET_FPS = 10
FRAME_INTERVAL_MS = 100  # 1000ms / 10fps
EXPRESSION_CHANGE_TIMEOUT_MS = 200


# ============================================================================
# 데이터 클래스
# ============================================================================

@dataclass
class EyeFrame:
    """단일 눈 프레임 — RGB565 픽셀 버퍼"""
    pixels: np.ndarray  # shape: (240, 240), dtype: uint16 (RGB565)
    timestamp: float = 0.0

    def __post_init__(self):
        if self.timestamp == 0.0:
            self.timestamp = time.time()


@dataclass
class BlinkState:
    """깜빡임 상태 관리"""
    is_blinking: bool = False
    blink_start: float = 0.0
    blink_duration_ms: float = 150.0    # 깜빡임 지속 시간
    blink_interval_ms: float = 3000.0   # 깜빡임 간격
    last_blink: float = 0.0
    blink_phase: float = 0.0            # 0.0~1.0 (0=열림, 0.5=닫힘, 1.0=열림)


@dataclass
class AnimationState:
    """애니메이션 상태 관리"""
    is_animating: bool = False
    animation_name: str = ""
    frame_index: int = 0
    frame_count: int = 0
    frame_duration_ms: float = 100.0
    last_frame_time: float = 0.0
    loop: bool = True


# ============================================================================
# 표정 생성기 (Expression Generator)
# ============================================================================

class ExpressionGenerator:
    """표정 픽셀 데이터 생성 — 각 표정을 RGB565 배열로 렌더링"""

    # 눈 기본 형태 원 반경
    EYE_RADIUS = 80       # 눈동자 외곽 반경
    IRIS_RADIUS = 50      # 홍채 반경
    PUPIL_RADIUS = 25     # 동공 반경
    CENTER_X = 120        # 화면 중앙 X
    CENTER_Y = 120        # 화면 중앙 Y

    @staticmethod
    def _rgb565(r: int, g: int, b: int) -> int:
        """RGB 888 → RGB565 변환"""
        return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)

    @staticmethod
    def _create_canvas(bg_color: int = COLOR_BLACK) -> np.ndarray:
        """빈 캔버스 생성 — 원형 디스플레이 바탕"""
        canvas = np.full((DISPLAY_HEIGHT, DISPLAY_WIDTH), bg_color, dtype=np.uint16)
        # 원형 마스크 적용 (디스플레이가 원형이므로 바깥은 검정)
        cy, cx = DISPLAY_HEIGHT // 2, DISPLAY_WIDTH // 2
        radius = min(cy, cx)
        y_coords, x_coords = np.ogrid[:DISPLAY_HEIGHT, :DISPLAY_WIDTH]
        mask = (x_coords - cx) ** 2 + (y_coords - cy) ** 2 > radius ** 2
        canvas[mask] = COLOR_BLACK
        return canvas

    @staticmethod
    def _draw_circle(
        canvas: np.ndarray, cx: int, cy: int, r: int, color: int, fill: bool = True
    ) -> np.ndarray:
        """원 그리기 (Bresenham 알고리즘 기반)"""
        y_coords, x_coords = np.ogrid[:DISPLAY_HEIGHT, :DISPLAY_WIDTH]
        if fill:
            mask = (x_coords - cx) ** 2 + (y_coords - cy) ** 2 <= r ** 2
        else:
            dist = (x_coords - cx) ** 2 + (y_coords - cy) ** 2
            mask = (dist <= r ** 2) & (dist >= (r - 2) ** 2)
        canvas[mask] = color
        return canvas

    @staticmethod
    def _draw_ellipse(
        canvas: np.ndarray, cx: int, cy: int,
        rx: int, ry: int, color: int
    ) -> np.ndarray:
        """타원 그리기"""
        y_coords, x_coords = np.ogrid[:DISPLAY_HEIGHT, :DISPLAY_WIDTH]
        mask = ((x_coords - cx) ** 2 / max(rx ** 2, 1) +
                (y_coords - cy) ** 2 / max(ry ** 2, 1)) <= 1.0
        canvas[mask] = color
        return canvas

    @classmethod
    def generate(cls, expression: Expression, side: EyeSide) -> EyeFrame:
        """표정에 따른 프레임 생성"""
        method = {
            Expression.HAPPY: cls._gen_happy,
            Expression.SAD: cls._gen_sad,
            Expression.SURPRISED: cls._gen_surprised,
            Expression.ANGRY: cls._gen_angry,
            Expression.NEUTRAL: cls._gen_neutral,
            Expression.SLEEPY: cls._gen_sleepy,
            Expression.LOVE: cls._gen_love,
            Expression.THINKING: cls._gen_thinking,
            Expression.CUSTOM: cls._gen_neutral,  # 커스텀은 draw_custom 사용
        }.get(expression, cls._gen_neutral)
        return method(side)

    # --- 개별 표정 생성 메서드 ---

    @classmethod
    def _gen_neutral(cls, side: EyeSide) -> EyeFrame:
        """중립 표정 — 기본 눈 모양"""
        canvas = cls._create_canvas(COLOR_WHITE)
        cx = cls.CENTER_X + (5 if side == EyeSide.RIGHT else -5)  # 약간 응시
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.IRIS_RADIUS, COLOR_BLUE)
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.PUPIL_RADIUS, COLOR_BLACK)
        # 하이라이트
        cls._draw_circle(canvas, cx + 12, cls.CENTER_Y - 12, 6, COLOR_WHITE)
        return EyeFrame(pixels=canvas)

    @classmethod
    def _gen_happy(cls, side: EyeSide) -> EyeFrame:
        """행복 표정 — 웃는 눈 (아래쪽 호)"""
        canvas = cls._create_canvas(COLOR_WHITE)
        cx = cls.CENTER_X + (5 if side == EyeSide.RIGHT else -5)
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.IRIS_RADIUS, COLOR_BLUE)
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.PUPIL_RADIUS, COLOR_BLACK)
        cls._draw_circle(canvas, cx + 12, cls.CENTER_Y - 12, 6, COLOR_WHITE)
        # 아래쪽 눈꺼풀 (반달 모양 웃음)
        cls._draw_ellipse(canvas, cx, cls.CENTER_Y + 40, 70, 30, COLOR_WHITE)
        return EyeFrame(pixels=canvas)

    @classmethod
    def _gen_sad(cls, side: EyeSide) -> EyeFrame:
        """슬픔 표정 — 위로 향한 눈꺼풀, 아래 내려다보기"""
        canvas = cls._create_canvas(COLOR_WHITE)
        cx = cls.CENTER_X + (5 if side == EyeSide.RIGHT else -5)
        # 동공 아래로 내려감
        cy = cls.CENTER_Y + 10
        cls._draw_circle(canvas, cx, cy, cls.IRIS_RADIUS, COLOR_BLUE)
        cls._draw_circle(canvas, cx, cy, cls.PUPIL_RADIUS, COLOR_BLACK)
        cls._draw_circle(canvas, cx + 10, cy - 10, 5, COLOR_WHITE)
        # 위 눈꺼풀 내려옴
        cls._draw_ellipse(canvas, cx, cls.CENTER_Y - 50, 80, 35, COLOR_WHITE)
        return EyeFrame(pixels=canvas)

    @classmethod
    def _gen_surprised(cls, side: EyeSide) -> EyeFrame:
        """놀람 표정 — 큰 동공, 넓은 눈"""
        canvas = cls._create_canvas(COLOR_WHITE)
        cx = cls.CENTER_X
        # 홍채 작게, 동공 크게
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.IRIS_RADIUS + 5, COLOR_BLUE)
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.PUPIL_RADIUS + 10, COLOR_BLACK)
        cls._draw_circle(canvas, cx + 14, cls.CENTER_Y - 14, 8, COLOR_WHITE)
        return EyeFrame(pixels=canvas)

    @classmethod
    def _gen_angry(cls, side: EyeSide) -> EyeFrame:
        """화남 표정 — 위 눈꺼풀 내려옴, 찌푸림"""
        canvas = cls._create_canvas(COLOR_WHITE)
        cx = cls.CENTER_X + (5 if side == EyeSide.RIGHT else -5)
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.IRIS_RADIUS, COLOR_RED)
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.PUPIL_RADIUS, COLOR_BLACK)
        cls._draw_circle(canvas, cx + 10, cls.CENTER_Y - 10, 5, COLOR_WHITE)
        # 찌푸린 눈썹 — 비대칭 타원
        offset = 15 if side == EyeSide.LEFT else -15
        cls._draw_ellipse(
            canvas, cls.CENTER_X + offset, cls.CENTER_Y - 60, 75, 20, COLOR_WHITE
        )
        return EyeFrame(pixels=canvas)

    @classmethod
    def _gen_sleepy(cls, side: EyeSide) -> EyeFrame:
        """졸림 표정 — 눈 반쯤 감기"""
        canvas = cls._create_canvas(COLOR_WHITE)
        cx = cls.CENTER_X
        # 동공 아래로 처짐
        cy = cls.CENTER_Y + 5
        cls._draw_circle(canvas, cx, cy, cls.IRIS_RADIUS - 5, COLOR_BLUE)
        cls._draw_circle(canvas, cx, cy, cls.PUPIL_RADIUS - 3, COLOR_BLACK)
        # 위 눈꺼풀 많이 내려옴
        cls._draw_ellipse(canvas, cx, cls.CENTER_Y - 25, 80, 45, COLOR_WHITE)
        # 아래 눈꺼풀도 올라옴
        cls._draw_ellipse(canvas, cx, cls.CENTER_Y + 30, 70, 25, COLOR_WHITE)
        return EyeFrame(pixels=canvas)

    @classmethod
    def _gen_love(cls, side: EyeSide) -> EyeFrame:
        """사랑 표정 — 하트 모양 동공"""
        canvas = cls._create_canvas(COLOR_WHITE)
        cx = cls.CENTER_X + (5 if side == EyeSide.RIGHT else -5)
        cls._draw_circle(canvas, cx, cls.CENTER_Y, cls.IRIS_RADIUS, COLOR_PINK)
        # 하트 모양 (두 개의 원 + 아래 삼각형 근사)
        cls._draw_circle(canvas, cx - 12, cls.CENTER_Y - 8, 15, COLOR_RED)
        cls._draw_circle(canvas, cx + 12, cls.CENTER_Y - 8, 15, COLOR_RED)
        # 아래 뾰족한 부분 (삼각형 근사)
        y_coords, x_coords = np.ogrid[:DISPLAY_HEIGHT, :DISPLAY_WIDTH]
        heart_mask = (
            (y_coords > cls.CENTER_Y - 5) &
            (y_coords < cls.CENTER_Y + 25) &
            (np.abs(x_coords - cx) < (cls.CENTER_Y + 25 - y_coords) * 0.6)
        )
        canvas[heart_mask] = COLOR_RED
        # 하이라이트
        cls._draw_circle(canvas, cx + 10, cls.CENTER_Y - 18, 4, COLOR_WHITE)
        return EyeFrame(pixels=canvas)

    @classmethod
    def _gen_thinking(cls, side: EyeSide) -> EyeFrame:
        """생각 표정 — 위를 올려다봄"""
        canvas = cls._create_canvas(COLOR_WHITE)
        # 동공 위로 올림
        cx = cls.CENTER_X + (5 if side == EyeSide.RIGHT else -5)
        cy = cls.CENTER_Y - 15
        cls._draw_circle(canvas, cx, cy, cls.IRIS_RADIUS, COLOR_BLUE)
        cls._draw_circle(canvas, cx, cy, cls.PUPIL_RADIUS, COLOR_BLACK)
        cls._draw_circle(canvas, cx + 10, cy - 10, 5, COLOR_WHITE)
        return EyeFrame(pixels=canvas)


# ============================================================================
# GC9A01 SPI 드라이버
# ============================================================================

class GC9A01Driver:
    """GC9A01 SPI 디스플레이 저수준 드라이버"""

    def __init__(
        self,
        spi_bus: int = 0,
        spi_device: int = 0,
        dc_pin: int = 25,
        rst_pin: int = 27,
        cs_pin: Optional[int] = None,
        spi_speed_mhz: int = SPI_SPEED_MHZ,
    ):
        self.spi_bus = spi_bus
        self.spi_device = spi_device
        self.dc_pin = dc_pin
        self.rst_pin = rst_pin
        self.cs_pin = cs_pin  # None이면 HW CS 사용
        self.spi_speed_mhz = spi_speed_mhz
        self._spi = None
        self._initialized = False
        self._lock = threading.Lock()

    def initialize(self) -> bool:
        """SPI 및 GPIO 초기화, GC9A01 리셋 시퀀스"""
        try:
            if SPI_AVAILABLE:
                self._spi = spidev.SpiDev(self.spi_bus, self.spi_device)
                self._spi.max_speed_hz = self.spi_speed_mhz * 1_000_000
                self._spi.mode = 0
            else:
                logger.warning("spidev 미사용 — 시뮬레이션 모드")

            if GPIO_AVAILABLE:
                GPIO.setmode(GPIO.BCM)
                GPIO.setup(self.dc_pin, GPIO.OUT)
                GPIO.setup(self.rst_pin, GPIO.OUT)
                if self.cs_pin is not None:
                    GPIO.setup(self.cs_pin, GPIO.OUT)
                    GPIO.output(self.cs_pin, GPIO.HIGH)

            self._hardware_reset()
            self._init_sequence()
            self._initialized = True
            logger.info("GC9A01 초기화 완료 (bus=%d, dev=%d)", self.spi_bus, self.spi_device)
            return True
        except Exception as e:
            logger.error("GC9A01 초기화 실패: %s", e)
            return False

    def _hardware_reset(self) -> None:
        """하드웨어 리셋 시퀀스"""
        if not GPIO_AVAILABLE:
            return
        GPIO.output(self.rst_pin, GPIO.HIGH)
        time.sleep(0.01)
        GPIO.output(self.rst_pin, GPIO.LOW)
        time.sleep(0.01)
        GPIO.output(self.rst_pin, GPIO.HIGH)
        time.sleep(0.12)

    def _init_sequence(self) -> None:
        """GC9A01 초기화 명령 시퀀스"""
        # IC 제조사 권장 초기화
        self._write_command(GC9A01_CMD_SWRESET)
        time.sleep(0.12)
        self._write_command(GC9A01_CMD_SLPOUT)
        time.sleep(0.02)

        # GC9A01 특화 레지스터 설정
        self._write_command(0xEF)       # 내부 레지스터 해제
        self._write_data_bytes(b'\x03\x80\x02')
        self._write_command(0xCF)
        self._write_data_bytes(b'\x00\xC1\x30')
        self._write_command(0xED)
        self._write_data_bytes(b'\x64\x03\x12\x81')
        self._write_command(0xE8)
        self._write_data_bytes(b'\x85\x00\x78')
        self._write_command(0xCB)
        self._write_data_bytes(b'\x39\x2C\x00\x34\x02')
        self._write_command(0xF7)
        self._write_data_bytes(b'\x20')
        self._write_command(0xEA)
        self._write_data_bytes(b'\x00\x00')

        # 전원 설정
        self._write_command(0xC0)   # Power Control 1
        self._write_data_bytes(b'\x23')
        self._write_command(0xC1)   # Power Control 2
        self._write_data_bytes(b'\x10')
        self._write_command(0xC5)   # VCOM Control
        self._write_data_bytes(b'\x3E\x28')
        self._write_command(0xC7)   # VCOM Offset
        self._write_data_bytes(b'\x86')

        # 메모리 액세스 (가로 모드)
        self._write_command(GC9A01_CMD_MADCTL)
        self._write_data_bytes(b'\x00')  # RGB 순서

        # 픽셀 포맷 — RGB565
        self._write_command(GC9A01_CMD_COLMOD)
        self._write_data_bytes(b'\x05')  # 16bit/pixel

        # 프레임 레이트
        self._write_command(0xB1)
        self._write_data_bytes(b'\x00\x18')  # 18 = ~26fps

        # 디스플레이 ON
        self._write_command(GC9A01_CMD_NORON)
        time.sleep(0.01)
        self._write_command(GC9A01_CMD_DISPON)
        time.sleep(0.1)

    def _write_command(self, cmd: int) -> None:
        """명령어 전송 (DC=LOW)"""
        if GPIO_AVAILABLE:
            GPIO.output(self.dc_pin, GPIO.LOW)
        if self._spi:
            self._spi.writebytes([cmd])

    def _write_data_bytes(self, data: bytes) -> None:
        """데이터 전송 (DC=HIGH)"""
        if GPIO_AVAILABLE:
            GPIO.output(self.dc_pin, GPIO.HIGH)
        if self._spi:
            self._spi.writebytes(list(data))

    def _write_data_word(self, data: int) -> None:
        """16비트 데이터 전송"""
        if GPIO_AVAILABLE:
            GPIO.output(self.dc_pin, GPIO.HIGH)
        if self._spi:
            self._spi.writebytes([(data >> 8) & 0xFF, data & 0xFF])

    def set_window(self, x0: int, y0: int, x1: int, y1: int) -> None:
        """디스플레이 쓰기 윈도우 설정"""
        self._write_command(GC9A01_CMD_CASET)
        self._write_data_bytes(bytes([
            (x0 >> 8) & 0xFF, x0 & 0xFF,
            (x1 >> 8) & 0xFF, x1 & 0xFF,
        ]))
        self._write_command(GC9A01_CMD_RASET)
        self._write_data_bytes(bytes([
            (y0 >> 8) & 0xFF, y0 & 0xFF,
            (y1 >> 8) & 0xFF, y1 & 0xFF,
        ]))

    def write_frame(self, pixels: np.ndarray) -> None:
        """전체 프레임 전송 (RGB565 240×240)"""
        with self._lock:
            self.set_window(0, 0, DISPLAY_WIDTH - 1, DISPLAY_HEIGHT - 1)
            self._write_command(GC9A01_CMD_RAMWR)
            if GPIO_AVAILABLE:
                GPIO.output(self.dc_pin, GPIO.HIGH)
            if self._spi:
                # RGB565 uint16 → bytes (빅엔디안)
                frame_bytes = pixels.astype(np.uint16).tobytes()
                # 최대 4096바이트 청크 전송
                chunk_size = 4096
                for i in range(0, len(frame_bytes), chunk_size):
                    self._spi.writebytes(list(frame_bytes[i:i + chunk_size]))

    def cleanup(self) -> None:
        """리소스 정리"""
        if self._spi:
            self._spi.close()
            self._spi = None
        self._initialized = False


# ============================================================================
# 메인 클래스: EyeDisplaySystem
# ============================================================================

class EyeDisplaySystem:
    """
    지훈 로봇 V8.5 — 눈 디스플레이 시스템

    GC9A01 240×240 원형 TFT ×2 (좌/우 눈) 제어
    - 표정 렌더링 (9종 + 커스텀)
    - 20MHz SPI, RGB565, 10fps 업데이트
    - 감정 명령 → 200ms 이내 표정 변경
    - 프레임 버퍼 관리로 부드러운 애니메이션
    - 커스텀 비트맵 표정 지원
    """

    def __init__(
        self,
        left_spi_bus: int = 0,
        left_spi_device: int = 0,
        right_spi_bus: int = 0,
        right_spi_device: int = 1,
        dc_pin: int = 25,
        rst_pin: int = 27,
        right_cs_pin: int = 8,  # 우안은 GPIO CS 사용
    ):
        # 좌안 드라이버 (HW CS)
        self._left_driver = GC9A01Driver(
            spi_bus=left_spi_bus,
            spi_device=left_spi_device,
            dc_pin=dc_pin,
            rst_pin=rst_pin,
            spi_speed_mhz=SPI_SPEED_MHZ,
        )
        # 우안 드라이버 (GPIO CS)
        self._right_driver = GC9A01Driver(
            spi_bus=right_spi_bus,
            spi_device=right_spi_device,
            dc_pin=dc_pin,
            rst_pin=rst_pin,
            cs_pin=right_cs_pin,
            spi_speed_mhz=SPI_SPEED_MHZ,
        )

        # 현재 상태
        self._current_expression = Expression.NEUTRAL
        self._left_frame: Optional[EyeFrame] = None
        self._right_frame: Optional[EyeFrame] = None

        # 커스텀 프레임 버퍼 (사용자 정의 비트맵)
        self._custom_frames: Dict[str, Tuple[EyeFrame, EyeFrame]] = {}

        # 애니메이션 상태
        self._animation_state = AnimationState()
        self._animation_frames: Dict[str, List[Tuple[EyeFrame, EyeFrame]]] = {}

        # 깜빡임 상태
        self._blink_state = BlinkState()

        # 렌더링 스레드
        self._running = False
        self._render_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        # 성능 측정
        self._last_expression_change_time: float = 0.0
        self._expression_change_latency_ms: float = 0.0

        logger.info("EyeDisplaySystem 인스턴스 생성")

    # --- 초기화 및 종료 ---

    def initialize(self) -> bool:
        """디스플레이 시스템 초기화"""
        logger.info("눈 디스플레이 초기화 시작...")
        left_ok = self._left_driver.initialize()
        right_ok = self._right_driver.initialize()

        if not left_ok:
            logger.error("좌안 GC9A01 초기화 실패")
        if not right_ok:
            logger.error("우안 GC9A01 초기화 실패")

        # 기본 표정 표시
        self.set_expression(Expression.NEUTRAL)
        self._start_render_loop()
        logger.info("눈 디스플레이 초기화 완료 (좌:%s, 우:%s)", left_ok, right_ok)
        return left_ok and right_ok

    def shutdown(self) -> None:
        """디스플레이 시스템 종료"""
        logger.info("눈 디스플레이 종료...")
        self._running = False
        if self._render_thread and self._render_thread.is_alive():
            self._render_thread.join(timeout=1.0)
        self._left_driver.cleanup()
        self._right_driver.cleanup()
        logger.info("눈 디스플레이 종료 완료")

    # --- 표정 제어 ---

    def set_expression(self, expression: Expression) -> float:
        """
        표정 설정 — 감정 명령 수신

        Args:
            expression: 표정 종류

        Returns:
            표정 변경 소요 시간 (ms)
        """
        start_time = time.time()
        with self._lock:
            self._current_expression = expression
            self._animation_state.is_animating = False

            # 좌/우 프레임 생성
            self._left_frame = ExpressionGenerator.generate(expression, EyeSide.LEFT)
            self._right_frame = ExpressionGenerator.generate(expression, EyeSide.RIGHT)

        elapsed_ms = (time.time() - start_time) * 1000
        self._expression_change_latency_ms = elapsed_ms
        self._last_expression_change_time = time.time()

        logger.debug("표정 변경: %s (%.1fms)", expression.value, elapsed_ms)
        return elapsed_ms

    def draw_custom(
        self,
        left_pixels: Optional[np.ndarray] = None,
        right_pixels: Optional[np.ndarray] = None,
        name: str = "custom",
    ) -> None:
        """
        커스텀 비트맵 표정 그리기

        Args:
            left_pixels: 좌안 RGB565 픽셀 배열 (240×240, uint16), None이면 우안만 변경
            right_pixels: 우안 RGB565 픽셀 배열, None이면 좌안만 변경
            name: 커스텀 표정 이름 (저장용)
        """
        with self._lock:
            self._current_expression = Expression.CUSTOM
            self._animation_state.is_animating = False

            if left_pixels is not None:
                self._left_frame = EyeFrame(pixels=left_pixels)
            if right_pixels is not None:
                self._right_frame = EyeFrame(pixels=right_pixels)

            # 커스텀 프레임 저장
            self._custom_frames[name] = (
                self._left_frame or EyeFrame(pixels=np.zeros((240, 240), dtype=np.uint16)),
                self._right_frame or EyeFrame(pixels=np.zeros((240, 240), dtype=np.uint16)),
            )
        logger.info("커스텀 표정 '%s' 등록", name)

    def animate(
        self,
        animation_name: str,
        frame_duration_ms: float = 100.0,
        loop: bool = True,
    ) -> bool:
        """
        애니메이션 재생

        Args:
            animation_name: 등록된 애니메이션 이름
            frame_duration_ms: 프레임 지속 시간 (ms)
            loop: 반복 재생 여부

        Returns:
            애니메이션 시작 성공 여부
        """
        if animation_name not in self._animation_frames:
            logger.warning("알 수 없는 애니메이션: %s", animation_name)
            return False

        with self._lock:
            self._animation_state = AnimationState(
                is_animating=True,
                animation_name=animation_name,
                frame_index=0,
                frame_count=len(self._animation_frames[animation_name]),
                frame_duration_ms=frame_duration_ms,
                last_frame_time=time.time(),
                loop=loop,
            )
        logger.info("애니메이션 시작: %s (%d프레임, %.0fms)", animation_name,
                     self._animation_state.frame_count, frame_duration_ms)
        return True

    def blink(self, duration_ms: float = 150.0) -> None:
        """
        수동 깜빡임 트리거

        Args:
            duration_ms: 깜빡임 지속 시간 (ms)
        """
        with self._lock:
            self._blink_state.is_blinking = True
            self._blink_state.blink_start = time.time()
            self._blink_state.blink_duration_ms = duration_ms
            self._blink_state.blink_phase = 0.0
        logger.debug("깜빡임 트리거 (%.0fms)", duration_ms)

    def register_animation(
        self,
        name: str,
        frames: List[Tuple[np.ndarray, np.ndarray]],
    ) -> None:
        """
        커스텀 애니메이션 등록

        Args:
            name: 애니메이션 이름
            frames: 프레임 리스트 [(좌안픽셀, 우안픽셀), ...]
        """
        animation_frames = []
        for left_px, right_px in frames:
            animation_frames.append((
                EyeFrame(pixels=left_px),
                EyeFrame(pixels=right_px),
            ))
        self._animation_frames[name] = animation_frames
        logger.info("애니메이션 '%s' 등록 (%d프레임)", name, len(frames))

    # --- 내부 렌더링 루프 ---

    def _start_render_loop(self) -> None:
        """렌더링 루프 시작 (별도 스레드)"""
        self._running = True
        self._render_thread = threading.Thread(
            target=self._render_loop, daemon=True, name="EyeDisplay-Render"
        )
        self._render_thread.start()

    def _render_loop(self) -> None:
        """10fps 렌더링 루프"""
        while self._running:
            frame_start = time.time()

            # 깜빡임 처리
            self._process_blink()

            # 애니메이션 프레임 갱신
            self._process_animation()

            # 프레임 전송
            with self._lock:
                left_frame = self._left_frame
                right_frame = self._right_frame
                blink_phase = self._blink_state.blink_phase

            if left_frame is not None and right_frame is not None:
                # 깜빡임 위아래 눈꺼풀 효과 적용
                left_display = self._apply_blink_effect(left_frame.pixels, blink_phase)
                right_display = self._apply_blink_effect(right_frame.pixels, blink_phase)

                self._left_driver.write_frame(left_display)
                self._right_driver.write_frame(right_display)

            # 프레임 레이트 제어
            elapsed = (time.time() - frame_start) * 1000
            sleep_ms = max(0, FRAME_INTERVAL_MS - elapsed)
            time.sleep(sleep_ms / 1000.0)

    def _process_blink(self) -> None:
        """자동 깜빡임 처리"""
        now = time.time()
        with self._lock:
            bs = self._blink_state
            if bs.is_blinking:
                elapsed_ms = (now - bs.blink_start) * 1000
                total_ms = bs.blink_duration_ms
                if elapsed_ms >= total_ms:
                    # 깜빡임 종료
                    bs.is_blinking = False
                    bs.blink_phase = 0.0
                    bs.last_blink = now
                else:
                    # 깜빡임 진행 (0→1→0 삼각파)
                    progress = elapsed_ms / total_ms
                    bs.blink_phase = 1.0 - abs(2.0 * progress - 1.0)
            else:
                bs.blink_phase = 0.0
                # 자동 깜빡임 간격 확인
                if (now - bs.last_blink) * 1000 > bs.blink_interval_ms:
                    self.blink()

    def _process_animation(self) -> None:
        """애니메이션 프레임 갱신"""
        with self._lock:
            anim = self._animation_state
            if not anim.is_animating:
                return

            now = time.time()
            elapsed_ms = (now - anim.last_frame_time) * 1000
            if elapsed_ms < anim.frame_duration_ms:
                return

            # 다음 프레임으로 이동
            anim.frame_index += 1
            anim.last_frame_time = now

            if anim.frame_index >= anim.frame_count:
                if anim.loop:
                    anim.frame_index = 0
                else:
                    anim.is_animating = False
                    return

            # 프레임 데이터 적용
            frames = self._animation_frames.get(anim.animation_name, [])
            if anim.frame_index < len(frames):
                self._left_frame, self._right_frame = frames[anim.frame_index]

    @staticmethod
    def _apply_blink_effect(pixels: np.ndarray, blink_phase: float) -> np.ndarray:
        """
        깜빡임 효과 적용 — 위아래 눈꺼풀이 닫혔다 열림

        Args:
            pixels: 원본 프레임
            blink_phase: 0.0=완전 열림, 1.0=완전 닫힘
        """
        if blink_phase <= 0.01:
            return pixels

        result = pixels.copy()
        # 닫히는 높이 계산 (최대 화면의 60%)
        close_height = int(blink_phase * DISPLAY_HEIGHT * 0.6)

        if close_height > 0:
            # 위에서부터 눈꺼풀 내려옴 (검정)
            result[:close_height, :] = COLOR_BLACK
            # 아래에서부터 눈꺼풀 올라옴
            result[DISPLAY_HEIGHT - close_height:, :] = COLOR_BLACK

        return result

    # --- 상태 조회 ---

    def get_current_expression(self) -> Expression:
        """현재 표정 반환"""
        return self._current_expression

    def get_expression_latency_ms(self) -> float:
        """마지막 표정 변경 소요 시간 (ms)"""
        return self._expression_change_latency_ms

    def is_animating(self) -> bool:
        """애니메이션 재생 중 여부"""
        return self._animation_state.is_animating

    def is_blinking(self) -> bool:
        """깜빡임 중 여부"""
        return self._blink_state.is_blinking

    def get_status(self) -> Dict:
        """시스템 상태 반환"""
        return {
            "expression": self._current_expression.value,
            "is_animating": self._animation_state.is_animating,
            "animation_name": self._animation_state.animation_name,
            "is_blinking": self._blink_state.is_blinking,
            "expression_latency_ms": self._expression_change_latency_ms,
            "custom_expressions": list(self._custom_frames.keys()),
            "animations": list(self._animation_frames.keys()),
        }


# ============================================================================
# 메인 진입점 (단독 테스트용)
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    eye_system = EyeDisplaySystem()
    if eye_system.initialize():
        print("=== 눈 디스플레이 시스템 테스트 ===")

        # 각 표정 순차 표시
        for expr in Expression:
            if expr == Expression.CUSTOM:
                continue
            latency = eye_system.set_expression(expr)
            print(f"표정: {expr.value:12s} | 변경 소요: {latency:.1f}ms")
            assert latency < EXPRESSION_CHANGE_TIMEOUT_MS, \
                f"표정 변경 시간 초과: {latency:.1f}ms > {EXPRESSION_CHANGE_TIMEOUT_MS}ms"
            time.sleep(1.5)

        # 깜빡임 테스트
        print("\n깜빡임 테스트...")
        eye_system.blink(duration_ms=200)
        time.sleep(1.0)

        # 커스텀 표정 테스트
        print("커스텀 표정 테스트...")
        custom_pixels = np.full((240, 240), COLOR_CYAN, dtype=np.uint16)
        eye_system.draw_custom(left_pixels=custom_pixels, right_pixels=custom_pixels, name="test")
        time.sleep(2.0)

        print(f"\n상태: {eye_system.get_status()}")
        eye_system.shutdown()
        print("테스트 완료")
    else:
        print("초기화 실패 — SPI/GPIO 확인 필요")
