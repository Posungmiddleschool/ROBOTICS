#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — USB-C PD 충전 시스템
======================================

USB-C PD 트리거 20V → CC/CV Buck 14.6V/3A → BMS 충전
듀얼 충전 포트 지원 (2× CC/CV 모듈)

TODO 51: charging_system.py

CRITICAL: 20V 직결은 LiFePO4 4S (14.6V max) 충전 불가 — 반드시 강압 필요
모듈: XL4015 CC/CV 또는 IP2366 전용 LiFePO4 충전 IC

V8.5 추가 기능:
  - CC/CV Buck 컨버터 실시간 모니터링 강화 (20V 직결 방지)
  - 충전 중 과전압 보호 (PDF #3, #10)
  - 충전 온도 모니터링 (과온/저온 시 충전 금지)
  - 충전 세션 NVMe 로깅

하드웨어:
  - USB-C PD Trigger ×2 (20V/65W)
  - CC/CV Buck Module ×2 (20V→14.6V/3A)
  - LiFePO4 4S 3000mAh ×2팩 (병렬)
  - INA219 전압/전류 센서 (I2C)

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, IntEnum
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# INA219 센서 (실제 환경)
try:
    from ina219 import INA219
    INA219_AVAILABLE = True
except ImportError:
    INA219_AVAILABLE = False

# I2C (Jetson/ESP32)
try:
    import smbus2
    I2C_AVAILABLE = True
except ImportError:
    I2C_AVAILABLE = False

logger = logging.getLogger("jihun.v84.charging_system")


# ============================================================================
# 열거형 및 상수
# ============================================================================

class ChargeState(Enum):
    """충전 상태"""
    IDLE = "idle"                     # 대기 (충전기 미연결)
    CC_CHARGING = "cc_charging"       # 정전류 충전 (14.6V, 3A)
    CV_CHARGING = "cv_charging"       # 정전압 충전 (14.6V, 전류 감소)
    FULLY_CHARGED = "fully_charged"   # 충전 완료
    ERROR = "error"                   # 오류
    PORT_DISABLED = "port_disabled"   # 포트 비활성화
    # V8.5 추가
    TEMP_SUSPENDED = "temp_suspended"  # 온도 이유로 충전 일시정지


class ChargePort(IntEnum):
    """충전 포트 번호"""
    PORT_1 = 1
    PORT_2 = 2


class ChargeErrorCode(Enum):
    """충전 오류 코드"""
    NONE = "none"
    OVERVOLTAGE = "overvoltage"         # 과전압 (>15.0V)
    UNDERVOLTAGE = "undervoltage"       # 저전압 (<10.0V)
    OVERCURRENT = "overcurrent"         # 과전류 (>4.0A)
    TEMPERATURE_HIGH = "temp_high"      # 온도 과다 (>60°C)
    TEMPERATURE_LOW = "temp_low"        # 온도 과소 (<0°C) — V8.5
    PD_TRIGGER_FAIL = "pd_trigger_fail" # PD 트리거 실패
    BUCK_FAIL = "buck_fail"             # CC/CV 모듈 이상
    BMS_FAULT = "bms_fault"            # BMS 보호 동작
    TIMEOUT = "timeout"                 # 충전 시간 초과
    DIRECT_20V_DETECTED = "direct_20v"  # V8.5: 20V 직결 감지 (치명적!)
    BUCK_OUTPUT_OVERVOLTAGE = "buck_ov" # V8.5: Buck 출력 과전압 (PDF #3, #10)


# LiFePO4 4S 전압 한계
LIFEPO4_4S_NOMINAL_V = 12.8      # 공칭 전압
LIFEPO4_4S_MAX_CHARGE_V = 14.6   # 최대 충전 전압
LIFEPO4_4S_MIN_DISCHARGE_V = 10.0  # 최대 방전 전압
LIFEPO4_4S_CELL_FULL_V = 3.65    # 셀당 충전 완료 전압
LIFEPO4_4S_CELL_EMPTY_V = 2.5    # 셀당 방전 종료 전압

# CC/CV 충전 파라미터
CC_MODE_CURRENT_A = 3.0          # 정전류 충전 전류
CC_MODE_VOLTAGE_V = 14.6         # 정전류 모드 목표 전압
CV_MODE_VOLTAGE_V = 14.6         # 정전압 모드 전압
CV_CUTOFF_CURRENT_A = 0.3        # 정전압 → 충전 완료 기준 전류 (100mA/cell)

# 안전 임계값
MAX_CHARGE_VOLTAGE_V = 15.0      # 과전압 보호 (BMS 14.6V 보다 여유)
MIN_CHARGE_VOLTAGE_V = 10.0      # 저전압 보호
MAX_CHARGE_CURRENT_A = 4.0       # 과전류 보호
MAX_CHARGE_TEMP_C = 60.0         # 온도 보호 (상한)
MAX_CHARGE_TIME_HOURS = 5.0      # 최대 충전 시간

# V8.5: 충전 온도 범위 (LiFePO4 안전 충전 온도)
MIN_CHARGE_TEMP_C = 0.0          # 충전 불가 온도 (하한) — 0°C 이하 충전 금지
CHARGE_TEMP_RESUME_C = 5.0       # 충전 재개 온도 (히스테리시스)
CHARGE_TEMP_SUSPEND_HIGH_C = 55.0  # 고온 충전 일시정지 (60°C 전 여유)
CHARGE_TEMP_RESUME_HIGH_C = 50.0   # 고온 충전 재개 온도

# V8.5: CC/CV Buck 컨버터 모니터링 (20V 직결 방지)
BUCK_EXPECTED_OUTPUT_V = 14.6    # 정상 Buck 출력 전압
BUCK_TOLERANCE_PCT = 3.0         # 허용 오차 (%)
BUCK_CRITICAL_OUTPUT_V = 18.0    # 이 이상이면 20V 직결 의심 (위험!)
BUCK_INPUT_PD_V = 20.0           # PD 트리거 입력 전압
BUCK_MONITOR_INTERVAL_MS = 500   # Buck 모니터링 주기 (기존 1000ms → 500ms)

# V8.5: 과전압 보호 강화 (PDF #3, #10)
OVERVOLTAGE_WARNING_V = 14.8     # 과전압 경고 (14.6V + 여유)
OVERVOLTAGE_CRITICAL_V = 15.5    # 과전압 위험 (즉시 차단)
OVERVOLTAGE_CATASTROPHIC_V = 16.0  # 과전압 치명적 (비상 차단)

# PD 트리거
PD_TRIGGER_VOLTAGE_V = 20        # USB-C PD 요청 전압
PD_TRIGGER_MAX_POWER_W = 65      # 최대 전력

# 이중 포트
NUM_CHARGE_PORTS = 2

# 모니터링
MONITOR_INTERVAL_MS = 1000       # 충전 모니터링 주기 (1초)
VOLTAGE_TOLERANCE_PCT = 2.0      # 전압 허용 오차 (%)

# V8.5: NVMe 로깅 경로
NVME_LOG_BASE_PATH = "/mnt/nvme/charge_logs"
NVME_LOG_MAX_SIZE_MB = 100       # 로그 최대 크기 (MB)
NVME_LOG_ROTATION_COUNT = 10     # 로그 로테이션 수


# ============================================================================
# 데이터 클래스
# ============================================================================

@dataclass
class ChargePortStatus:
    """개별 충전 포트 상태"""
    port: ChargePort = ChargePort.PORT_1
    state: ChargeState = ChargeState.IDLE
    voltage_v: float = 0.0
    current_a: float = 0.0
    power_w: float = 0.0
    temperature_c: float = 25.0
    error_code: ChargeErrorCode = ChargeErrorCode.NONE
    charge_start_time: float = 0.0
    total_charge_mah: float = 0.0
    pd_connected: bool = False
    buck_output_v: float = 0.0
    # V8.5 추가
    buck_input_v: float = 0.0        # Buck 입력 전압 (PD 20V)
    overvoltage_count: int = 0       # 과전압 발생 횟수
    temp_suspend_count: int = 0      # 온도 정지 횟수
    last_overvoltage_v: float = 0.0  # 마지막 과전압 기록


@dataclass
class BatteryStatus:
    """배터리 팩 상태"""
    voltage_v: float = 12.8
    current_a: float = 0.0
    soc_percent: float = 50.0     # State of Charge (%)
    soh_percent: float = 100.0    # State of Health (%)
    temperature_c: float = 25.0
    cell_voltages: List[float] = field(default_factory=lambda: [3.2] * 4)
    is_balancing: bool = False


# ============================================================================
# V8.5: 충전 세션 NVMe 로거
# ============================================================================

class ChargeSessionLogger:
    """
    충전 세션 NVMe 로깅 — 영구 기록

    충전 이벤트, 전압/전류 이력, 오류 기록을 NVMe에 저장
    → 사후 분석 및 보증 클레임 증빙
    """

    def __init__(self, log_base_path: str = NVME_LOG_BASE_PATH,
                 max_size_mb: float = NVME_LOG_MAX_SIZE_MB,
                 rotation_count: int = NVME_LOG_ROTATION_COUNT):
        self._log_base_path = Path(log_base_path)
        self._max_size_bytes = max_size_mb * 1024 * 1024
        self._rotation_count = rotation_count
        self._current_session: Optional[Dict] = None
        self._session_events: List[Dict] = []
        self._lock = threading.Lock()

        # 로그 디렉토리 생성
        try:
            self._log_base_path.mkdir(parents=True, exist_ok=True)
            logger.info("NVMe 충전 로그 경로: %s", self._log_base_path)
        except Exception as e:
            logger.warning("NVMe 로그 디렉토리 생성 실패: %s — 로깅 비활성화", e)

    def start_session(self, port: ChargePort, battery_soc: float,
                      battery_voltage: float) -> None:
        """
        충전 세션 시작 기록

        Args:
            port: 충전 포트
            battery_soc: 배터리 SOC (%)
            battery_voltage: 배터리 전압 (V)
        """
        with self._lock:
            self._current_session = {
                "session_id": f"charge_{datetime.now().strftime('%Y%m%d_%H%M%S')}_p{port.value}",
                "port": port.value,
                "start_time": datetime.now().isoformat(),
                "start_timestamp": time.time(),
                "start_soc": battery_soc,
                "start_voltage_v": battery_voltage,
                "events": [],
            }
            self._session_events = []

        logger.info("충전 세션 기록 시작: %s", self._current_session["session_id"])

    def log_event(self, event_type: str, data: Dict) -> None:
        """
        충전 이벤트 기록

        Args:
            event_type: 이벤트 유형
            data: 이벤트 데이터
        """
        with self._lock:
            event = {
                "timestamp": time.time(),
                "datetime": datetime.now().isoformat(),
                "event_type": event_type,
                "data": data,
            }
            self._session_events.append(event)

            # 중요 이벤트는 즉시 플러시
            if event_type in ("overvoltage", "error", "emergency_stop", "direct_20v_detected"):
                self._flush_to_disk()

    def end_session(self, end_soc: float, end_voltage: float,
                    total_mah: float, reason: str) -> None:
        """
        충전 세션 종료 기록

        Args:
            end_soc: 종료 시 SOC (%)
            end_voltage: 종료 시 전압 (V)
            total_mah: 총 충전량 (mAh)
            reason: 종료 사유
        """
        with self._lock:
            if self._current_session is None:
                return

            self._current_session["end_time"] = datetime.now().isoformat()
            self._current_session["end_timestamp"] = time.time()
            self._current_session["end_soc"] = end_soc
            self._current_session["end_voltage_v"] = end_voltage
            self._current_session["total_charge_mah"] = total_mah
            self._current_session["reason"] = reason
            self._current_session["duration_s"] = (
                self._current_session["end_timestamp"]
                - self._current_session["start_timestamp"]
            )
            self._current_session["events"] = self._session_events

            self._flush_to_disk()

            session_id = self._current_session["session_id"]
            self._current_session = None
            self._session_events = []

        logger.info("충전 세션 기록 종료: %s (사유: %s)", session_id, reason)

    def _flush_to_disk(self) -> None:
        """세션 데이터를 NVMe에 플러시"""
        if self._current_session is None:
            return

        try:
            # NVMe 사용 가능한지 확인
            if not self._log_base_path.exists():
                return

            filename = f"{self._current_session['session_id']}.json"
            filepath = self._log_base_path / filename

            # 기존 파일에 추가 (세션 진행 중)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(self._current_session, f, indent=2, ensure_ascii=False)

            # 로그 로테이션
            self._rotate_logs()

        except Exception as e:
            logger.error("NVMe 로그 쓰기 실패: %s", e)

    def _rotate_logs(self) -> None:
        """오래된 로그 파일 로테이션"""
        try:
            log_files = sorted(self._log_base_path.glob("charge_*.json"))
            while len(log_files) > self._rotation_count:
                oldest = log_files.pop(0)
                oldest.unlink()
                logger.debug("오래된 로그 삭제: %s", oldest.name)
        except Exception as e:
            logger.error("로그 로테이션 실패: %s", e)


# ============================================================================
# V8.5: CC/CV Buck 컨버터 모니터 (20V 직결 방지 강화)
# ============================================================================

class BuckConverterMonitor:
    """
    CC/CV Buck 컨버터 실시간 모니터링 — 20V 직결 방지

    CRITICAL: USB-C PD 20V가 Buck 컨버터 없이 직접 연결되면
    LiFePO4 4S (최대 14.6V)가 손상됨!

    모니터링 항목:
    - Buck 출력 전압이 정상 범위 (14.6V ± 3%) 인지 확인
    - 18V 이상 감지 시 20V 직결로 판단 → 즉시 차단
    - Buck 입력 전압 (PD 20V) 확인
    """

    def __init__(self, port: ChargePort,
                 expected_output_v: float = BUCK_EXPECTED_OUTPUT_V,
                 tolerance_pct: float = BUCK_TOLERANCE_PCT,
                 critical_output_v: float = BUCK_CRITICAL_OUTPUT_V):
        self._port = port
        self._expected_output_v = expected_output_v
        self._tolerance_pct = tolerance_pct
        self._critical_output_v = critical_output_v
        self._last_output_v: float = 0.0
        self._last_input_v: float = 0.0
        self._direct_20v_detected: bool = False
        self._monitoring_history: List[Dict] = []

    def check(self, buck_output_v: float, buck_input_v: float = 0.0) -> Dict:
        """
        Buck 컨버터 출력 검증

        Args:
            buck_output_v: Buck 출력 전압 (V)
            buck_input_v: Buck 입력 전압 (V)

        Returns:
            검증 결과 딕셔너리
        """
        self._last_output_v = buck_output_v
        self._last_input_v = buck_input_v

        result = {
            "port": self._port.value,
            "output_v": buck_output_v,
            "input_v": buck_input_v,
            "expected_v": self._expected_output_v,
            "is_safe": True,
            "direct_20v": False,
            "buck_fail": False,
            "error": "",
        }

        # 1. 20V 직결 감지 (치명적!)
        if buck_output_v >= self._critical_output_v:
            result["is_safe"] = False
            result["direct_20v"] = True
            result["error"] = (
                f"CRITICAL: 20V 직결 감지! 출력 {buck_output_v:.1f}V ≥ "
                f"{self._critical_output_v}V — LiFePO4 4S 최대 {LIFEPO4_4S_MAX_CHARGE_V}V! "
                f"즉시 분리 필요!"
            )
            self._direct_20v_detected = True
            logger.critical(
                "포트 %d: 20V 직결 감지! 출력 %.1fV — 즉시 충전 차단!",
                self._port.value, buck_output_v
            )

        # 2. Buck 컨버터 고장 감지 (출력이 너무 높거나 낮음)
        elif buck_output_v > 0.5:  # 연결됨
            tolerance = self._expected_output_v * self._tolerance_pct / 100.0
            if buck_output_v > self._expected_output_v + tolerance:
                if buck_output_v < self._critical_output_v:
                    result["buck_fail"] = True
                    result["error"] = (
                        f"Buck 출력 과전압: {buck_output_v:.2f}V "
                        f"(예상 {self._expected_output_v}V ± {tolerance:.1f}V)"
                    )
                    logger.error(
                        "포트 %d: Buck 출력 이상! %.2fV (예상 %.1fV±%.1fV)",
                        self._port.value, buck_output_v,
                        self._expected_output_v, tolerance
                    )
            elif buck_output_v < self._expected_output_v - tolerance:
                result["buck_fail"] = True
                result["error"] = (
                    f"Buck 출력 저전압: {buck_output_v:.2f}V "
                    f"(예상 {self._expected_output_v}V ± {tolerance:.1f}V)"
                )
                logger.warning(
                    "포트 %d: Buck 출력 저전압 %.2fV (예상 %.1fV)",
                    self._port.value, buck_output_v, self._expected_output_v
                )

        # 이력 기록
        self._monitoring_history.append({
            "timestamp": time.time(),
            "output_v": buck_output_v,
            "input_v": buck_input_v,
            "is_safe": result["is_safe"],
        })
        if len(self._monitoring_history) > 100:
            self._monitoring_history = self._monitoring_history[-100:]

        return result

    @property
    def is_direct_20v(self) -> bool:
        return self._direct_20v_detected

    def reset_alarm(self) -> None:
        """20V 직결 알람 리셋 (물리적 수리 후)"""
        self._direct_20v_detected = False
        logger.info("포트 %d: 20V 직결 알람 리셋", self._port.value)


# ============================================================================
# V8.5: 충전 온도 모니터
# ============================================================================

class ChargingTemperatureMonitor:
    """
    충전 온도 모니터 — LiFePO4 안전 충전 온도 범위 감시

    LiFePO4 충전 온도 규격:
    - 충전 가능: 0°C ~ 60°C
    - 권장 충전: 10°C ~ 45°C
    - 0°C 이하 충전 금지 (리튬 도금 위험)
    - 60°C 이상 충전 금지 (열폭주 위험)
    """

    def __init__(self, min_temp_c: float = MIN_CHARGE_TEMP_C,
                 max_temp_c: float = MAX_CHARGE_TEMP_C,
                 suspend_high_c: float = CHARGE_TEMP_SUSPEND_HIGH_C,
                 resume_high_c: float = CHARGE_TEMP_RESUME_HIGH_C,
                 resume_low_c: float = CHARGE_TEMP_RESUME_C):
        self._min_temp = min_temp_c
        self._max_temp = max_temp_c
        self._suspend_high = suspend_high_c
        self._resume_high = resume_high_c
        self._resume_low = resume_low_c
        self._suspended: bool = False
        self._suspend_reason: Optional[str] = None

    def check(self, battery_temp_c: float) -> Dict:
        """
        충전 온도 적합성 검사

        Args:
            battery_temp_c: 배터리 온도 (°C)

        Returns:
            온도 검사 결과
        """
        result = {
            "can_charge": True,
            "suspended": False,
            "reason": "",
            "battery_temp_c": battery_temp_c,
            "safe_range": f"{self._min_temp}~{self._max_temp}°C",
        }

        # 저온 검사 (0°C 이하 → 충전 금지)
        if battery_temp_c < self._min_temp:
            result["can_charge"] = False
            result["suspended"] = True
            result["reason"] = (
                f"배터리 온도 과低: {battery_temp_c:.1f}°C < {self._min_temp}°C "
                f"— 리튬 도금 위험으로 충전 금지"
            )
            self._suspended = True
            self._suspend_reason = "low_temp"
            logger.error(
                "충전 온도 과低! %.1f°C < %.1f°C — 충전 금지",
                battery_temp_c, self._min_temp
            )

        # 고온 검사 (55°C → 일시정지, 60°C → 금지)
        elif battery_temp_c >= self._max_temp:
            result["can_charge"] = False
            result["suspended"] = True
            result["reason"] = (
                f"배터리 온도 과高: {battery_temp_c:.1f}°C ≥ {self._max_temp}°C "
                f"— 열폭주 위험으로 충전 금지"
            )
            self._suspended = True
            self._suspend_reason = "high_temp"
            logger.critical(
                "충전 온도 과高! %.1f°C ≥ %.1f°C — 충전 금지",
                battery_temp_c, self._max_temp
            )

        elif battery_temp_c >= self._suspend_high:
            result["can_charge"] = False
            result["suspended"] = True
            result["reason"] = (
                f"배터리 온도 경고: {battery_temp_c:.1f}°C ≥ {self._suspend_high}°C "
                f"— 충전 일시정지"
            )
            self._suspended = True
            self._suspend_reason = "high_temp_warning"
            logger.warning(
                "충전 온도 경고! %.1f°C ≥ %.1f°C — 충전 일시정지",
                battery_temp_c, self._suspend_high
            )

        else:
            # 정상 범위 복귀 확인
            if self._suspended:
                if self._suspend_reason == "low_temp" and battery_temp_c >= self._resume_low:
                    logger.info("충전 온도 정상 복귀 (저온): %.1f°C", battery_temp_c)
                    self._suspended = False
                    self._suspend_reason = None
                elif self._suspend_reason in ("high_temp", "high_temp_warning") and \
                     battery_temp_c <= self._resume_high:
                    logger.info("충전 온도 정상 복귀 (고온): %.1f°C", battery_temp_c)
                    self._suspended = False
                    self._suspend_reason = None

        result["suspended"] = self._suspended
        result["can_charge"] = not self._suspended

        return result

    @property
    def is_suspended(self) -> bool:
        return self._suspended


# ============================================================================
# CC/CV Buck 모듈 제어
# ============================================================================

class CCVBuckController:
    """
    XL4015 CC/CV Buck 모듈 제어

    20V 입력 → 14.6V/3A 출력
    - 출력 전압은 멀티턴 가변저항으로 설정 (하드웨어)
    - 소프트웨어는 INA219로 출력 전압/전류 모니터링
    - 비상 시 릴레이로 입력 차단
    """

    def __init__(
        self,
        port: ChargePort,
        ina219_address: int = 0x40,
        relay_pin: Optional[int] = None,
    ):
        self._port = port
        self._ina219_address = ina219_address
        self._relay_pin = relay_pin
        self._ina219: Optional[object] = None
        self._enabled = False

    def initialize(self) -> bool:
        """INA219 센서 및 릴레이 초기화"""
        try:
            if INA219_AVAILABLE:
                self._ina219 = INA219(
                    shunt_ohms=0.1,
                    max_expected_amps=5.0,
                    address=self._ina219_address,
                )
                self._ina219.configure()
            logger.info("CC/CV Buck 포트 %d 초기화 완료", self._port)
            return True
        except Exception as e:
            logger.error("CC/CV Buck 포트 %d 초기화 실패: %s", self._port, e)
            return False

    def enable(self) -> None:
        """충전 포트 활성화 (릴레이 ON)"""
        self._enabled = True
        logger.info("충전 포트 %d 활성화", self._port)

    def disable(self) -> None:
        """충전 포트 비활성화 (릴레이 OFF)"""
        self._enabled = False
        logger.info("충전 포트 %d 비활성화", self._port)

    def read_voltage(self) -> float:
        """출력 전압 읽기 (V)"""
        if self._ina219:
            try:
                return self._ina219.voltage()
            except Exception:
                return 0.0
        return 0.0  # 시뮬레이션

    def read_current(self) -> float:
        """출력 전류 읽기 (A)"""
        if self._ina219:
            try:
                return self._ina219.current() / 1000.0  # mA → A
            except Exception:
                return 0.0
        return 0.0

    def read_power(self) -> float:
        """출력 전력 읽기 (W)"""
        return self.read_voltage() * self.read_current()

    def is_enabled(self) -> bool:
        return self._enabled


# ============================================================================
# 메인 클래스: ChargingSystem — V8.5
# ============================================================================

class ChargingSystem:
    """
    지훈 로봇 V8.5 — USB-C PD 충전 시스템

    CRITICAL: 20V 직결 절대 금지 — 반드시 CC/CV Buck 강압 모듈 필요!

    충전 흐름:
      65W PD 어댑터 → USB-C PD 트리거(20V) → CC/CV Buck(14.6V/3A) → BMS → 배터리

    기능:
      - 듀얼 충전 포트 (2× CC/CV 모듈)
      - 정전류(CC) → 정전압(CV) 자동 전환
      - INA219 실시간 전압/전류 모니터링
      - 과전압/과전류/과온 보호
      - 충전 상태 리포팅

    V8.5 추가:
      - CC/CV Buck 컨버터 실시간 모니터링 (20V 직결 방지)
      - 과전압 보호 강화 (PDF #3, #10) — 다단계 과전압 임계값
      - 충전 온도 모니터링 (과온/저온 시 충전 금지)
      - 충전 세션 NVMe 로깅
    """

    def __init__(
        self,
        port1_ina_address: int = 0x40,
        port2_ina_address: int = 0x41,
        port1_relay_pin: Optional[int] = None,
        port2_relay_pin: Optional[int] = None,
    ):
        # CC/CV Buck 컨트롤러 ×2
        self._buck_controllers: Dict[ChargePort, CCVBuckController] = {
            ChargePort.PORT_1: CCVBuckController(
                ChargePort.PORT_1, port1_ina_address, port1_relay_pin
            ),
            ChargePort.PORT_2: CCVBuckController(
                ChargePort.PORT_2, port2_ina_address, port2_relay_pin
            ),
        }

        # V8.5: Buck 컨버터 모니터 ×2
        self._buck_monitors: Dict[ChargePort, BuckConverterMonitor] = {
            ChargePort.PORT_1: BuckConverterMonitor(ChargePort.PORT_1),
            ChargePort.PORT_2: BuckConverterMonitor(ChargePort.PORT_2),
        }

        # V8.5: 충전 온도 모니터
        self._temp_monitor = ChargingTemperatureMonitor()

        # V8.5: NVMe 세션 로거
        self._session_logger = ChargeSessionLogger()

        # 포트 상태
        self._port_status: Dict[ChargePort, ChargePortStatus] = {
            ChargePort.PORT_1: ChargePortStatus(port=ChargePort.PORT_1),
            ChargePort.PORT_2: ChargePortStatus(port=ChargePort.PORT_2),
        }

        # 배터리 상태
        self._battery_status = BatteryStatus()

        # 모니터링 스레드
        self._running = False
        self._monitor_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        # 충전 이력
        self._charge_history: List[Dict] = []

        # V8.5: 과전압 보호 카운터 (PDF #3, #10)
        self._overvoltage_counters: Dict[ChargePort, int] = {
            ChargePort.PORT_1: 0,
            ChargePort.PORT_2: 0,
        }

        logger.info("ChargingSystem V8.5 인스턴스 생성 (듀얼 포트)")

    # --- 초기화 및 종료 ---

    def initialize(self) -> bool:
        """충전 시스템 초기화"""
        logger.info("충전 시스템 V8.5 초기화...")
        success = True
        for port, controller in self._buck_controllers.items():
            if not controller.initialize():
                logger.error("포트 %d 초기화 실패", port)
                success = False
        self._start_monitoring()
        logger.info("충전 시스템 V8.5 초기화 %s", "완료" if success else "부분 실패")
        return success

    def shutdown(self) -> None:
        """충전 시스템 종료"""
        logger.info("충전 시스템 V8.5 종료...")
        self._running = False
        # 모든 포트 충전 정지
        for port in ChargePort:
            self.stop_charging(port)
        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=2.0)
        logger.info("충전 시스템 V8.5 종료 완료")

    # --- 충전 제어 ---

    def start_charging(self, port: ChargePort = ChargePort.PORT_1) -> bool:
        """
        충전 시작 — V8.5: 온도 및 Buck 검증 추가

        Args:
            port: 충전 포트 번호

        Returns:
            충전 시작 성공 여부
        """
        with self._lock:
            status = self._port_status[port]
            if status.state in (ChargeState.CC_CHARGING, ChargeState.CV_CHARGING):
                logger.warning("포트 %d 이미 충전 중", port)
                return True

            # 사전 검증: 배터리 전압 확인
            battery_v = self._battery_status.voltage_v
            if battery_v >= LIFEPO4_4S_MAX_CHARGE_V:
                logger.info("배터리 이미 충전됨 (%.2fV)", battery_v)
                status.state = ChargeState.FULLY_CHARGED
                return False

            if battery_v < MIN_CHARGE_VOLTAGE_V:
                logger.error("배터리 전압 너무 낮음 (%.2fV) — BMS 확인 필요", battery_v)
                status.state = ChargeState.ERROR
                status.error_code = ChargeErrorCode.UNDERVOLTAGE
                return False

            # V8.5: 충전 온도 검증
            temp_result = self._temp_monitor.check(self._battery_status.temperature_c)
            if not temp_result["can_charge"]:
                logger.error("충전 온도 부적합: %s", temp_result["reason"])
                status.state = ChargeState.TEMP_SUSPENDED
                status.temp_suspend_count += 1
                return False

            # V8.5: Buck 컨버터 사전 검증
            controller = self._buck_controllers[port]
            buck_output = controller.read_voltage()
            if buck_output > 0.5:  # 이미 출력이 있음
                buck_result = self._buck_monitors[port].check(buck_output)
                if buck_result["direct_20v"]:
                    logger.critical("포트 %d: 20V 직결 감지! 충전 시작 거부", port)
                    status.state = ChargeState.ERROR
                    status.error_code = ChargeErrorCode.DIRECT_20V_DETECTED
                    return False

            # CC/CV Buck 활성화
            controller.enable()

            # 충전 시작 기록
            status.state = ChargeState.CC_CHARGING
            status.charge_start_time = time.time()
            status.total_charge_mah = 0.0
            status.error_code = ChargeErrorCode.NONE
            status.overvoltage_count = 0

        # V8.5: 세션 로깅 시작
        self._session_logger.start_session(
            port, self._battery_status.soc_percent, battery_v
        )

        logger.info("포트 %d 충전 시작 (배터리 %.2fV, 온도 %.1f°C)",
                    port, battery_v, self._battery_status.temperature_c)
        return True

    def stop_charging(self, port: ChargePort = ChargePort.PORT_1) -> None:
        """
        충전 정지

        Args:
            port: 충전 포트 번호
        """
        with self._lock:
            controller = self._buck_controllers[port]
            controller.disable()

            status = self._port_status[port]
            if status.state not in (ChargeState.IDLE, ChargeState.ERROR):
                # 충전 이력 기록
                self._log_charge_event(port, "stopped")

            status.state = ChargeState.IDLE
            status.pd_connected = False

        # V8.5: 세션 로깅 종료
        self._session_logger.end_session(
            end_soc=self._battery_status.soc_percent,
            end_voltage=self._battery_status.voltage_v,
            total_mah=status.total_charge_mah,
            reason="manual_stop"
        )

        logger.info("포트 %d 충전 정지", port)

    def monitor_charge(self, port: ChargePort = ChargePort.PORT_1) -> ChargePortStatus:
        """
        충전 상태 모니터링

        Args:
            port: 충전 포트 번호

        Returns:
            포트 상태
        """
        with self._lock:
            return self._port_status[port]

    def verify_voltage(self, port: ChargePort = ChargePort.PORT_1) -> Dict:
        """
        충전 전압 검증 — CC/CV 모듈 출력이 14.6V인지 확인

        CRITICAL: 20V가 그대로 출력되면 LiFePO4 손상!

        V8.5: BuckConverterMonitor 통합

        Args:
            port: 충전 포트 번호

        Returns:
            검증 결과 딕셔너리
        """
        controller = self._buck_controllers[port]
        output_v = controller.read_voltage()

        # V8.5: Buck 모니터로 종합 검증
        buck_result = self._buck_monitors[port].check(output_v)

        result = {
            "port": port,
            "buck_output_v": output_v,
            "expected_v": CC_MODE_VOLTAGE_V,
            "tolerance_pct": VOLTAGE_TOLERANCE_PCT,
            "is_safe": buck_result["is_safe"],
            "error": buck_result["error"],
            "direct_20v": buck_result["direct_20v"],
            "buck_fail": buck_result["buck_fail"],
        }

        # 20V 직결 감지 시 즉시 비상 차단
        if buck_result["direct_20v"]:
            controller.disable()
            self._port_status[port].state = ChargeState.ERROR
            self._port_status[port].error_code = ChargeErrorCode.DIRECT_20V_DETECTED
            logger.critical("포트 %d 20V 직결! 충전 비활성화", port)

            # V8.5: 세션 로깅
            self._session_logger.log_event("direct_20v_detected", {
                "port": port.value,
                "voltage_v": output_v,
            })

        # 기존 검증 로직 유지
        elif output_v > MAX_CHARGE_VOLTAGE_V and not buck_result["direct_20v"]:
            result["is_safe"] = False
            result["error"] = (
                f"CRITICAL: CC/CV 출력 과전압 {output_v:.2f}V > {MAX_CHARGE_VOLTAGE_V}V! "
                f"LiFePO4 4S 최대 {LIFEPO4_4S_MAX_CHARGE_V}V — 즉시 분리 필요"
            )
            controller.disable()
            self._port_status[port].state = ChargeState.ERROR
            self._port_status[port].error_code = ChargeErrorCode.OVERVOLTAGE
            logger.critical("포트 %d 과전압 감지! %.2fV — 충전 비활성화", port, output_v)

        elif output_v < 0.1:
            result["error"] = "CC/CV 모듈 응답 없음 — PD 어댑터 연결 확인"
            if self._port_status[port].state != ChargeState.IDLE:
                self._port_status[port].pd_connected = False

        return result

    # --- 내부 모니터링 루프 ---

    def _start_monitoring(self) -> None:
        """충전 모니터링 스레드 시작"""
        self._running = True
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop, daemon=True, name="ChargingMonitor-V84"
        )
        self._monitor_thread.start()

    def _monitor_loop(self) -> None:
        """1초 주기 모니터링 루프 — V8.5: Buck/온도/과전압 검증 추가"""
        while self._running:
            for port in ChargePort:
                self._update_port_status(port)
                self._check_safety_v84(port)
                self._update_charge_state(port)
            time.sleep(MONITOR_INTERVAL_MS / 1000.0)

    def _update_port_status(self, port: ChargePort) -> None:
        """포트 상태 업데이트 (INA219 읽기)"""
        controller = self._buck_controllers[port]
        with self._lock:
            status = self._port_status[port]
            status.voltage_v = controller.read_voltage()
            status.current_a = controller.read_current()
            status.power_w = controller.read_power()
            status.buck_output_v = status.voltage_v
            status.pd_connected = status.voltage_v > 5.0  # PD 연결 시 전압 존재

            # 충전량 누적
            if status.state in (ChargeState.CC_CHARGING, ChargeState.CV_CHARGING):
                status.total_charge_mah += status.current_a * (MONITOR_INTERVAL_MS / 3600000.0) * 1000.0

    def _check_safety_v84(self, port: ChargePort) -> None:
        """V8.5: 통합 안전 검사 — 과전압/과전류/과온/Buck/충전온도"""

        with self._lock:
            status = self._port_status[port]
            controller = self._buck_controllers[port]

            # V8.5: Buck 컨버터 모니터링 (20V 직결 감지)
            if status.state in (ChargeState.CC_CHARGING, ChargeState.CV_CHARGING):
                buck_result = self._buck_monitors[port].check(
                    status.buck_output_v, status.buck_input_v if hasattr(status, 'buck_input_v') else 0.0
                )

                if buck_result["direct_20v"]:
                    logger.critical("포트 %d: 20V 직결 감지! 즉시 차단", port)
                    status.state = ChargeState.ERROR
                    status.error_code = ChargeErrorCode.DIRECT_20V_DETECTED
                    controller.disable()
                    self._log_charge_event(port, "direct_20v_emergency_stop")
                    self._session_logger.log_event("direct_20v_detected", {
                        "port": port.value, "voltage_v": status.buck_output_v
                    })
                    return

                if buck_result["buck_fail"]:
                    status.error_code = ChargeErrorCode.BUCK_FAIL
                    self._session_logger.log_event("buck_fail", {
                        "port": port.value, "output_v": status.buck_output_v
                    })

            # V8.5: 다단계 과전압 보호 (PDF #3, #10)
            if status.buck_output_v > OVERVOLTAGE_CATASTROPHIC_V:
                logger.critical(
                    "포트 %d 치명적 과전압! %.2fV > %.1fV — PDF #3, #10",
                    port, status.buck_output_v, OVERVOLTAGE_CATASTROPHIC_V
                )
                status.state = ChargeState.ERROR
                status.error_code = ChargeErrorCode.BUCK_OUTPUT_OVERVOLTAGE
                controller.disable()
                self._overvoltage_counters[port] += 1
                self._session_logger.log_event("catastrophic_overvoltage", {
                    "port": port.value, "voltage_v": status.buck_output_v
                })
                return

            elif status.buck_output_v > OVERVOLTAGE_CRITICAL_V:
                logger.critical(
                    "포트 %d 위험 과전압! %.2fV > %.1fV — 즉시 차단 (PDF #3, #10)",
                    port, status.buck_output_v, OVERVOLTAGE_CRITICAL_V
                )
                status.state = ChargeState.ERROR
                status.error_code = ChargeErrorCode.OVERVOLTAGE
                controller.disable()
                self._overvoltage_counters[port] += 1
                status.overvoltage_count += 1
                status.last_overvoltage_v = status.buck_output_v
                self._session_logger.log_event("critical_overvoltage", {
                    "port": port.value, "voltage_v": status.buck_output_v
                })
                return

            elif status.buck_output_v > OVERVOLTAGE_WARNING_V:
                logger.warning(
                    "포트 %d 과전압 경고! %.2fV > %.1fV (PDF #3, #10)",
                    port, status.buck_output_v, OVERVOLTAGE_WARNING_V
                )
                status.last_overvoltage_v = status.buck_output_v
                self._session_logger.log_event("overvoltage_warning", {
                    "port": port.value, "voltage_v": status.buck_output_v
                })

            # 기존 과전압 검사
            if status.buck_output_v > MAX_CHARGE_VOLTAGE_V:
                logger.critical("포트 %d 과전압! %.2fV > %.1fV",
                                port, status.buck_output_v, MAX_CHARGE_VOLTAGE_V)
                status.state = ChargeState.ERROR
                status.error_code = ChargeErrorCode.OVERVOLTAGE
                controller.disable()
                self._log_charge_event(port, "overvoltage_emergency_stop")
                return

            # 과전류 검사
            if status.current_a > MAX_CHARGE_CURRENT_A:
                logger.error("포트 %d 과전류! %.2fA > %.1fA",
                             port, status.current_a, MAX_CHARGE_CURRENT_A)
                status.state = ChargeState.ERROR
                status.error_code = ChargeErrorCode.OVERCURRENT
                controller.disable()
                return

            # 과온 검사 (컨트롤러 온도)
            if status.temperature_c > MAX_CHARGE_TEMP_C:
                logger.error("포트 %d 과온! %.1f°C > %.1f°C",
                             port, status.temperature_c, MAX_CHARGE_TEMP_C)
                status.state = ChargeState.ERROR
                status.error_code = ChargeErrorCode.TEMPERATURE_HIGH
                controller.disable()
                return

            # V8.5: 충전 온도 모니터링 (배터리 온도)
            if status.state in (ChargeState.CC_CHARGING, ChargeState.CV_CHARGING):
                temp_result = self._temp_monitor.check(self._battery_status.temperature_c)
                if temp_result["suspended"]:
                    logger.warning("포트 %d 충전 온도 정지: %s", port, temp_result["reason"])
                    status.state = ChargeState.TEMP_SUSPENDED
                    status.temp_suspend_count += 1
                    # 팬은 계속 돌림 (냉각)
                    self._session_logger.log_event("temp_suspended", {
                        "port": port.value,
                        "battery_temp_c": self._battery_status.temperature_c,
                        "reason": temp_result["reason"],
                    })

            # 충전 시간 초과
            if status.charge_start_time > 0:
                elapsed_hours = (time.time() - status.charge_start_time) / 3600.0
                if elapsed_hours > MAX_CHARGE_TIME_HOURS:
                    logger.warning("포트 %d 충전 시간 초과 (%.1fh)", port, elapsed_hours)
                    status.state = ChargeState.ERROR
                    status.error_code = ChargeErrorCode.TIMEOUT
                    controller.disable()

    def _update_charge_state(self, port: ChargePort) -> None:
        """CC/CV 충전 상태 자동 전환 — V8.5: 온도 정지 복귀 추가"""
        with self._lock:
            status = self._port_status[port]

            # V8.5: 온도 정지에서 복귀 확인
            if status.state == ChargeState.TEMP_SUSPENDED:
                temp_result = self._temp_monitor.check(self._battery_status.temperature_c)
                if temp_result["can_charge"]:
                    logger.info("포트 %d 충전 온도 복귀 — 충전 재개", port)
                    status.state = ChargeState.CC_CHARGING
                    self._buck_controllers[port].enable()
                    self._session_logger.log_event("temp_resumed", {
                        "port": port.value,
                        "battery_temp_c": self._battery_status.temperature_c,
                    })
                return

            if status.state == ChargeState.CC_CHARGING:
                # 정전류 → 정전압 전환: 전압이 14.6V 도달 시
                if status.buck_output_v >= CC_MODE_VOLTAGE_V * 0.98:
                    status.state = ChargeState.CV_CHARGING
                    logger.info("포트 %d CC→CV 전환 (전압 %.2fV)", port, status.buck_output_v)
                    self._session_logger.log_event("cc_to_cv_transition", {
                        "port": port.value, "voltage_v": status.buck_output_v
                    })

            elif status.state == ChargeState.CV_CHARGING:
                # 정전압 → 충전 완료: 전류가 차단 기준 이하 시
                if status.current_a < CV_CUTOFF_CURRENT_A:
                    status.state = ChargeState.FULLY_CHARGED
                    self._buck_controllers[port].disable()
                    logger.info("포트 %d 충전 완료 (전류 %.3fA < %.1fA)",
                                port, status.current_a, CV_CUTOFF_CURRENT_A)
                    self._log_charge_event(port, "fully_charged")

                    # V8.5: 세션 로깅 종료
                    self._session_logger.end_session(
                        end_soc=self._battery_status.soc_percent,
                        end_voltage=self._battery_status.voltage_v,
                        total_mah=status.total_charge_mah,
                        reason="fully_charged"
                    )

    def _log_charge_event(self, port: ChargePort, event: str) -> None:
        """충전 이벤트 기록"""
        status = self._port_status[port]
        event_data = {
            "timestamp": time.time(),
            "port": port,
            "event": event,
            "voltage_v": status.voltage_v,
            "current_a": status.current_a,
            "total_charge_mah": status.total_charge_mah,
        }
        self._charge_history.append(event_data)

        # V8.5: 세션 로그에도 기록
        self._session_logger.log_event(event, event_data)

    # --- 배터리 상태 ---

    def update_battery_status(self, battery: BatteryStatus) -> None:
        """배터리 상태 업데이트 (외부 BMS 모니터에서 호출)"""
        with self._lock:
            self._battery_status = battery

    def get_battery_status(self) -> BatteryStatus:
        """배터리 상태 반환"""
        with self._lock:
            return self._battery_status

    def estimate_soc(self, voltage: float) -> float:
        """
        전압 기반 SOC 추정 (LiFePO4 개략)

        LiFePO4는 방전 곡선이 평택하여 전압 기반 SOC는 근사치

        Args:
            voltage: 배터리 팩 전압 (V)

        Returns:
            추정 SOC (%)
        """
        cell_v = voltage / 4.0  # 4S
        if cell_v >= 3.65:
            return 100.0
        elif cell_v >= 3.30:
            # 3.30~3.65V: 대략 50~100% (평탄 구간)
            return 50.0 + (cell_v - 3.30) / (3.65 - 3.30) * 50.0
        elif cell_v >= 2.80:
            # 2.80~3.30V: 대략 10~50%
            return 10.0 + (cell_v - 2.80) / (3.30 - 2.80) * 40.0
        elif cell_v >= 2.50:
            return (cell_v - 2.50) / (2.80 - 2.50) * 10.0
        else:
            return 0.0

    # --- 상태 조회 ---

    def get_port_status(self, port: ChargePort = ChargePort.PORT_1) -> ChargePortStatus:
        """포트 상태 반환"""
        with self._lock:
            return self._port_status[port]

    def get_all_status(self) -> Dict:
        """전체 충전 시스템 상태 반환 — V8.5 확장"""
        with self._lock:
            return {
                "ports": {
                    p.value: {
                        "state": s.state.value,
                        "voltage_v": s.voltage_v,
                        "current_a": s.current_a,
                        "power_w": s.power_w,
                        "charge_mah": s.total_charge_mah,
                        "pd_connected": s.pd_connected,
                        "error": s.error_code.value,
                        # V8.5 추가
                        "buck_output_v": s.buck_output_v,
                        "overvoltage_count": s.overvoltage_count,
                        "temp_suspend_count": s.temp_suspend_count,
                        "last_overvoltage_v": s.last_overvoltage_v,
                    }
                    for p, s in self._port_status.items()
                },
                "battery": {
                    "voltage_v": self._battery_status.voltage_v,
                    "soc_percent": self._battery_status.soc_percent,
                    "temperature_c": self._battery_status.temperature_c,
                },
                # V8.5 추가
                "overvoltage_counters": {p.value: c for p, c in self._overvoltage_counters.items()},
                "temp_monitor_suspended": self._temp_monitor.is_suspended,
                "buck_monitor_alarms": {
                    p.value: self._buck_monitors[p].is_direct_20v for p in ChargePort
                },
                "history_count": len(self._charge_history),
            }


# ============================================================================
# 메인 진입점 (단독 테스트용)
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    charging = ChargingSystem()
    if charging.initialize():
        print("=== USB-C PD 충전 시스템 V8.5 테스트 ===")

        # 전압 검증 테스트
        print("\n--- 전압 검증 ---")
        for port in ChargePort:
            result = charging.verify_voltage(port)
            print(f"포트 {port}: {result}")

        # 충전 시작 테스트
        print("\n--- 충전 시작 ---")
        success = charging.start_charging(ChargePort.PORT_1)
        print(f"포트 1 충전 시작: {'성공' if success else '실패'}")

        # 듀얼 포트 충전
        charging.start_charging(ChargePort.PORT_2)
        print("포트 2 충전 시작")

        # 상태 모니터링 (5초)
        print("\n--- 상태 모니터링 ---")
        for i in range(5):
            status = charging.get_all_status()
            print(f"[{i+1}s] {status}")
            time.sleep(1.0)

        # 충전 정지
        charging.stop_charging(ChargePort.PORT_1)
        charging.stop_charging(ChargePort.PORT_2)

        # SOC 추정 테스트
        print("\n--- SOC 추정 ---")
        for v in [10.0, 11.2, 12.8, 13.2, 14.6]:
            soc = charging.estimate_soc(v)
            print(f"전압 {v:.1f}V → SOC {soc:.0f}%")

        print(f"\n최종 상태: {charging.get_all_status()}")
        charging.shutdown()
        print("V8.5 테스트 완료")
    else:
        print("초기화 실패 — INA219/I2C 확인 필요")
