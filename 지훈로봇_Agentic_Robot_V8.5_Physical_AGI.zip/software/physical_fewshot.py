#!/usr/bin/env python3
"""
physical_fewshot.py — V8.5 Few-Shot Physical Adaptation from Similar Experiences
지훈 로봇 물리적 AGI — V8.5 유사 경험 기반 퓨샷 물리적 적응

A physical AGI must adapt instantly to new situations by recalling similar
past experiences. Unlike training from scratch, few-shot adaptation leverages
k-nearest-neighbor retrieval and weighted action interpolation to produce
competent behavior immediately — then refines through practice.

물리적 AGI는 유사한 과거 경험을 회상하여 새로운 상황에 즉시 적응해야 합니다.
처음부터 학습하는 것과 달리, 퓨샷 적응은 k-최근접이웃 검색과 가중 행동
보간을 통해 즉시 유능한 행동을 생성하고, 이후 연습을 통해 개선합니다.

Components / 구성요소:
  1. ExperienceRetriever  — 유사 경험 검색 (numpy 기반 FAISS-like 인덱스)
  2. FewShotAdapter       — k-NN 기반 행동 적응
  3. PhysicalAnalogyEngine — 물리적 상황 간의 유추 추론

Key Algorithms / 핵심 알고리즘:
  - L2 거리 기반 k-NN 검색 / L2 distance-based k-NN search
  - 유사도 가중 행동 보간 / Similarity-weighted action interpolation
  - 물리적 유추 추론 / Physical analogy reasoning

State Embedding / 상태 임베딩:
  - PhysicalState 벡터의 마지막 62차원 사용
  - L2 정규화 후 코사인 유사도 계산

Hardware: Dual Jetson Orin NX 16GB
AI Model: Gemma 4 E4B Q4_K_M
Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.physical_fewshot")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 상수 / Constants ────────────────────────────────────────────────────────

STATE_DIM = 62          # PhysicalState 벡터 차원
ACTION_DIM = 16         # 행동 파라미터 차원
DEFAULT_K = 5           # 기본 k-NN k값
SIMILARITY_THRESHOLD = 0.3  # 유사도 임계값 (이하면 유사하지 않음)
INDEX_SHARD_SIZE = 10000    # 인덱스 샤드 크기
EPS = 1e-8


# ─── 데이터 클래스 / Data Classes ────────────────────────────────────────────


@dataclass
class PhysicalExperience:
    """
    물리적 경험 레코드 / Physical experience record.

    로봇의 물리적 경험을 저장합니다. 상태, 행동, 결과, 메타데이터를
    포함하며 퓨샷 적응을 위한 검색 대상이 됩니다.

    Attributes:
        experience_id: 경험 식별자
        state: 상태 벡터 (62차원)
        action: 행동 벡터 (16차원)
        reward: 보상 값
        success: 성공 여부
        category: 스킬 카테고리
        terrain_type: 지형 유형
        object_type: 객체 유형
        difficulty: 난이도 (1~10)
        metadata: 추가 메타데이터
        timestamp: 기록 시각
    """
    experience_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    state: np.ndarray = field(default_factory=lambda: np.zeros(STATE_DIM))
    action: np.ndarray = field(default_factory=lambda: np.zeros(ACTION_DIM))
    reward: float = 0.0
    success: bool = False
    category: str = ""
    terrain_type: str = "flat"
    object_type: str = ""
    difficulty: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def state_embedding(self) -> np.ndarray:
        """
        상태 임베딩 추출 / Extract state embedding.

        PhysicalState 벡터의 마지막 62차원을 사용합니다.
        L2 정규화 후 코사인 유사도 계산에 사용합니다.

        Returns:
            np.ndarray: 정규화된 상태 임베딩 (62차원)
        """
        emb = self.state.astype(np.float64).flatten()[:STATE_DIM]
        norm = np.linalg.norm(emb)
        if norm > EPS:
            emb = emb / norm
        return emb


@dataclass
class RetrievalResult:
    """
    검색 결과 / Retrieval result.

    k-NN 검색의 결과를 나타냅니다.

    Attributes:
        experience: 검색된 경험
        distance: 쿼리와의 L2 거리
        similarity: 코사인 유사도
    """
    experience: PhysicalExperience = field(default_factory=PhysicalExperience)
    distance: float = float("inf")
    similarity: float = 0.0


@dataclass
class AdaptedAction:
    """
    적응된 행동 / Adapted action.

    퓨샷 적응의 결과를 나타냅니다.

    Attributes:
        action: 적응된 행동 벡터
        confidence: 신뢰도 (0~1)
        source_count: 기여한 경험 수
        source_categories: 기여한 카테고리 목록
        adaptation_method: 적응 방법
    """
    action: np.ndarray = field(default_factory=lambda: np.zeros(ACTION_DIM))
    confidence: float = 0.0
    source_count: int = 0
    source_categories: List[str] = field(default_factory=list)
    adaptation_method: str = ""


@dataclass
class AnalogyResult:
    """
    유추 결과 / Analogy result.

    물리적 유추 추론의 결과를 나타냅니다.

    Attributes:
        source_situation: 소스 상황 설명
        target_situation: 타겟 상황 설명
        analogy_description: 유추 설명 (한국어+영어)
        suggested_adjustments: 제안된 조정 사항
        confidence: 유추 신뢰도
    """
    source_situation: str = ""
    target_situation: str = ""
    analogy_description: str = ""
    korean_description: str = ""
    suggested_adjustments: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0


# ─── 경험 검색기 / Experience Retriever ─────────────────────────────────────


class ExperienceRetriever:
    """
    유사 경험 검색기 / Similar experience retriever.

    numpy 기반 FAISS-like 인덱스를 사용하여 유사한 과거 경험을
    빠르게 검색합니다. L2 거리와 코사인 유사도를 모두 지원합니다.

    인덱스 구조 / Index structure:
    - 샤드 기반 분할로 대규모 데이터 처리
    - L2 정규화된 임베딩으로 코사인 유사도 지원
    - 카테고리별 필터링 지원

    Usage:
        retriever = ExperienceRetriever()
        retriever.index_experience(exp1)
        retriever.index_experience(exp2)
        results = retriever.retrieve_similar(query_state, k=5)
    """

    def __init__(
        self,
        dimension: int = STATE_DIM,
        metric: str = "cosine",
    ) -> None:
        self._dimension = dimension
        self._metric = metric

        # 인덱스 저장소 / Index storage
        self._embeddings: List[np.ndarray] = []
        self._experiences: List[PhysicalExperience] = []
        self._embeddings_matrix: Optional[np.ndarray] = None
        self._dirty = True  # 매트릭스 재구성 필요 / Matrix needs rebuild

        # 카테고리 인덱스 / Category index
        self._category_index: Dict[str, List[int]] = defaultdict(list)

        self._lock = threading.Lock()
        self._total_indexed = 0

        logger.info(
            "ExperienceRetriever 초기화: dim=%d, metric=%s",
            dimension, metric,
        )

    def index_experience(self, experience: PhysicalExperience) -> None:
        """
        경험을 인덱스에 추가 / Add experience to index.

        Args:
            experience: 인덱싱할 물리적 경험
        """
        embedding = experience.state_embedding()

        with self._lock:
            idx = len(self._embeddings)
            self._embeddings.append(embedding)
            self._experiences.append(experience)
            self._dirty = True
            self._total_indexed += 1

            # 카테고리 인덱스 업데이트 / Update category index
            if experience.category:
                self._category_index[experience.category].append(idx)

        logger.debug(
            "경험 인덱싱: %s (카테고리=%s, 총=%d)",
            experience.experience_id[:8], experience.category,
            self._total_indexed,
        )

    def index_batch(self, experiences: List[PhysicalExperience]) -> int:
        """
        경험 배치 인덱싱 / Batch index experiences.

        Args:
            experiences: 인덱싱할 경험 목록

        Returns:
            int: 인덱싱된 경험 수
        """
        for exp in experiences:
            self.index_experience(exp)
        return len(experiences)

    def _rebuild_matrix(self) -> None:
        """임베딩 매트릭스 재구성 / Rebuild embedding matrix."""
        if not self._embeddings:
            self._embeddings_matrix = None
            return

        self._embeddings_matrix = np.vstack(self._embeddings).astype(np.float32)
        self._dirty = False

    def retrieve_similar(
        self,
        query_state: np.ndarray,
        k: int = DEFAULT_K,
        category_filter: Optional[str] = None,
        min_similarity: float = SIMILARITY_THRESHOLD,
    ) -> List[RetrievalResult]:
        """
        유사한 경험 검색 / Retrieve similar experiences.

        k-NN 검색으로 쿼리 상태와 가장 유사한 k개 경험을 반환합니다.

        Args:
            query_state: 쿼리 상태 벡터 (62차원)
            k: 반환할 경험 수
            category_filter: 카테고리 필터 (선택)
            min_similarity: 최소 유사도 임계값

        Returns:
            List[RetrievalResult]: 검색 결과 (유사도순 정렬)
        """
        with self._lock:
            if not self._embeddings:
                return []

            if self._dirty:
                self._rebuild_matrix()

            if self._embeddings_matrix is None:
                return []

        # 쿼리 임베딩 정규화 / Normalize query embedding
        query_emb = query_state.astype(np.float64).flatten()[:self._dimension]
        query_norm = np.linalg.norm(query_emb)
        if query_norm > EPS:
            query_emb = query_emb / query_norm

        # 검색 대상 결정 / Determine search target
        with self._lock:
            if category_filter and category_filter in self._category_index:
                indices = self._category_index[category_filter]
                if not indices:
                    return []
                search_matrix = self._embeddings_matrix[indices]
            else:
                indices = list(range(len(self._experiences)))
                search_matrix = self._embeddings_matrix

        # 거리 계산 / Compute distances
        if self._metric == "cosine":
            # 코사인 유사도 / Cosine similarity
            similarities = search_matrix @ query_emb
            # 상위 k개 인덱스 / Top-k indices
            n_results = min(k, len(similarities))
            top_indices = np.argpartition(-similarities, n_results)[:n_results]
            top_indices = top_indices[np.argsort(-similarities[top_indices])]
        else:
            # L2 거리 / L2 distance
            distances = np.linalg.norm(search_matrix - query_emb, axis=1)
            n_results = min(k, len(distances))
            top_indices = np.argpartition(distances, n_results)[:n_results]
            top_indices = top_indices[np.argsort(distances[top_indices])]

        # 결과 구성 / Build results
        results: List[RetrievalResult] = []
        with self._lock:
            for local_idx in top_indices:
                global_idx = indices[local_idx]

                if self._metric == "cosine":
                    sim = float(similarities[local_idx])
                    dist = float(2.0 * (1.0 - sim))  # 코사인 → L2 근사
                else:
                    dist = float(distances[local_idx])
                    sim = float(1.0 / (1.0 + dist))

                # 최소 유사도 필터 / Minimum similarity filter
                if sim < min_similarity:
                    continue

                results.append(RetrievalResult(
                    experience=self._experiences[global_idx],
                    distance=dist,
                    similarity=sim,
                ))

        logger.debug(
            "유사 경험 검색: %d/%d 결과 (최고 유사도=%.3f)",
            len(results), k,
            results[0].similarity if results else 0.0,
        )

        return results

    def get_stats(self) -> Dict[str, Any]:
        """검색기 통계 / Return retriever statistics."""
        with self._lock:
            return {
                "total_indexed": self._total_indexed,
                "categories": dict(
                    (k, len(v)) for k, v in self._category_index.items()
                ),
                "dimension": self._dimension,
                "metric": self._metric,
            }


# ─── 퓨샷 적응기 / Few-Shot Adapter ─────────────────────────────────────────


class FewShotAdapter:
    """
    k-NN 기반 퓨샷 행동 적응기 / k-NN based few-shot action adapter.

    유사한 과거 경험의 성공적인 행동 파라미터를 가중 평균하여
    새로운 상황에 즉시 적응된 행동을 생성합니다.
    신뢰도는 유사도 점수와 성공 경험 비율로 계산됩니다.

    Adaptation Formula / 적응 수식:
      adapted_action = Σ_k (w_k * action_k) / Σ_k w_k
      where w_k = similarity_k * success_k

    Confidence / 신뢰도:
      confidence = (Σ_k w_k) / (k * max_similarity)

    Usage:
        adapter = FewShotAdapter(retriever)
        adapted = adapter.adapt_action(action, similar_experiences)
        print(f"적응된 행동: {adapted.action}, 신뢰도: {adapted.confidence}")
    """

    def __init__(
        self,
        retriever: Optional[ExperienceRetriever] = None,
        default_k: int = DEFAULT_K,
        similarity_weight: float = 0.7,
        success_weight: float = 0.3,
    ) -> None:
        self._retriever = retriever or ExperienceRetriever()
        self._default_k = default_k
        self._similarity_weight = similarity_weight
        self._success_weight = success_weight

        self._adaptation_count = 0
        self._lock = threading.Lock()

        logger.info(
            "FewShotAdapter 초기화: k=%d, 유사도가중치=%.2f, 성공가중치=%.2f",
            default_k, similarity_weight, success_weight,
        )

    def adapt_action(
        self,
        action: np.ndarray,
        similar_experiences: List[RetrievalResult],
    ) -> AdaptedAction:
        """
        유사 경험으로 행동 적응 / Adapt action from similar experiences.

        k-최근접이웃의 성공적인 행동 파라미터를 유사도 가중 평균합니다.
        실패한 경험은 반대 방향으로 약간의 조정을 제공합니다.

        Args:
            action: 원래 행동 벡터 (16차원)
            similar_experiences: 유사한 경험 검색 결과

        Returns:
            AdaptedAction: 적응된 행동과 신뢰도
        """
        if not similar_experiences:
            return AdaptedAction(
                action=action.copy(),
                confidence=0.0,
                adaptation_method="no_data",
            )

        action = np.asarray(action, dtype=np.float64).flatten()[:ACTION_DIM]
        if len(action) < ACTION_DIM:
            action = np.concatenate([action, np.zeros(ACTION_DIM - len(action))])

        # 성공/실패 경험 분리 / Separate success/failure experiences
        success_results = [r for r in similar_experiences if r.experience.success]
        failure_results = [r for r in similar_experiences if not r.experience.success]

        weighted_sum = np.zeros(ACTION_DIM, dtype=np.float64)
        total_weight = 0.0
        source_categories: List[str] = []

        # 성공 경험 가중 합 / Weighted sum of successful experiences
        for result in success_results:
            sim = result.similarity
            exp = result.experience
            exp_action = np.asarray(exp.action, dtype=np.float64).flatten()[:ACTION_DIM]
            if len(exp_action) < ACTION_DIM:
                exp_action = np.concatenate([exp_action, np.zeros(ACTION_DIM - len(exp_action))])

            weight = self._similarity_weight * sim + self._success_weight * 1.0
            weighted_sum += weight * exp_action
            total_weight += weight

            if exp.category and exp.category not in source_categories:
                source_categories.append(exp.category)

        # 실패 경험: 반대 방향 약한 조정 / Failed experiences: weak opposite adjustment
        for result in failure_results:
            sim = result.similarity
            exp = result.experience
            exp_action = np.asarray(exp.action, dtype=np.float64).flatten()[:ACTION_DIM]
            if len(exp_action) < ACTION_DIM:
                exp_action = np.concatenate([exp_action, np.zeros(ACTION_DIM - len(exp_action))])

            # 실패 행동에서 약간 벗어나도록 / Nudge away from failed action
            weight = self._similarity_weight * sim * 0.1  # 약한 가중치
            diff = action - exp_action  # 원래 행동과 실패 행동의 차이
            weighted_sum += weight * diff  # 차이 방향으로 약간 이동
            total_weight += weight

        # 정규화 / Normalize
        if total_weight > 0.0:
            adapted = weighted_sum / total_weight
        else:
            adapted = action.copy()

        # 신뢰도 계산 / Compute confidence
        if similar_experiences:
            max_sim = max(r.similarity for r in similar_experiences)
            success_ratio = len(success_results) / max(len(similar_experiences), 1)
            confidence = max_sim * success_ratio
        else:
            confidence = 0.0

        confidence = float(np.clip(confidence, 0.0, 1.0))

        with self._lock:
            self._adaptation_count += 1

        result = AdaptedAction(
            action=adapted.astype(np.float32),
            confidence=confidence,
            source_count=len(similar_experiences),
            source_categories=source_categories,
            adaptation_method="weighted_knn",
        )

        logger.debug(
            "행동 적응: 신뢰도=%.3f, 소스=%d (성공=%d, 실패=%d)",
            confidence, len(similar_experiences),
            len(success_results), len(failure_results),
        )

        return result

    def adapt_from_state(
        self,
        state: np.ndarray,
        action: np.ndarray,
        k: int = 0,
        category_filter: Optional[str] = None,
    ) -> AdaptedAction:
        """
        상태에서 직접 적응 / Adapt directly from state.

        검색과 적응을 한 번에 수행합니다.

        Args:
            state: 현재 상태 벡터
            action: 원래 행동 벡터
            k: 검색할 이웃 수 (0=기본값)
            category_filter: 카테고리 필터

        Returns:
            AdaptedAction: 적응된 행동
        """
        k = k or self._default_k
        similar = self._retriever.retrieve_similar(
            state, k=k, category_filter=category_filter
        )
        return self.adapt_action(action, similar)

    def get_stats(self) -> Dict[str, Any]:
        """적응기 통계 / Return adapter statistics."""
        return {
            "adaptation_count": self._adaptation_count,
            "default_k": self._default_k,
            "retriever_stats": self._retriever.get_stats(),
        }


# ─── 물리적 유추 엔진 / Physical Analogy Engine ─────────────────────────────


class PhysicalAnalogyEngine:
    """
    물리적 유추 추론 엔진 / Physical analogy reasoning engine.

    현재 물리적 상황과 과거 경험 간의 유추를 찾아냅니다.
    유추는 표면적 특징이 아닌 구조적 유사성에 기반합니다.

    Example analogies / 유추 예시:
    - "이 경사면은 이전 자갈길과 비슷하지만 더 가파름 → 속도 낮춤"
    - "이 물체는 컵과 비슷하지만 더 무거움 → 파지력 증가"
    - "이 지형은 계단과 비슷하지만 불규칙함 → 보폭 줄임"

    Analogy Structure / 유추 구조:
      source → target: "X는 Y와 비슷하지만 Z가 다름 → W 조정"

    Usage:
        engine = PhysicalAnalogyEngine(retriever)
        analogy = engine.find_analogy(current_situation, experience_database)
        print(analogy.korean_description)
    """

    def __init__(
        self,
        retriever: Optional[ExperienceRetriever] = None,
    ) -> None:
        self._retriever = retriever or ExperienceRetriever()
        self._analogy_templates = self._init_templates()
        self._analogy_history: List[AnalogyResult] = []
        self._lock = threading.Lock()

        logger.info("PhysicalAnalogyEngine 초기화")

    def _init_templates(self) -> Dict[str, Dict[str, Any]]:
        """
        유추 템플릿 초기화 / Initialize analogy templates.

        물리적 속성 변화에 따른 조정 규칙을 정의합니다.
        """
        return {
            "steeper_slope": {
                "korean": "{source}은(는) {target}과 비슷하지만 더 가파름 → 속도 낮춤, 보폭 줄임",
                "english": "{source} is like {target} but steeper → reduce speed, shorten stride",
                "adjustments": {
                    "speed_multiplier": 0.6,
                    "stride_multiplier": 0.7,
                    "stability_bonus": 0.1,
                },
            },
            "heavier_object": {
                "korean": "{source}은(는) {target}과 비슷하지만 더 무거움 → 파지력 증가, 속도 낮춤",
                "english": "{source} is like {target} but heavier → increase grip force, reduce speed",
                "adjustments": {
                    "grip_force_multiplier": 1.5,
                    "speed_multiplier": 0.7,
                    "caution_bonus": 0.2,
                },
            },
            "more_slippery": {
                "korean": "{source}은(는) {target}과 비슷하지만 더 미끄러움 → 마찰력 확보, 저속",
                "english": "{source} is like {target} but more slippery → secure friction, slow down",
                "adjustments": {
                    "speed_multiplier": 0.5,
                    "grip_multiplier": 1.3,
                    "friction_awareness": 0.3,
                },
            },
            "more_fragile": {
                "korean": "{source}은(는) {target}과 비슷하지만 더 깨지기 쉬움 → 부드러운 파지",
                "english": "{source} is like {target} but more fragile → gentle grip",
                "adjustments": {
                    "grip_force_multiplier": 0.5,
                    "speed_multiplier": 0.6,
                    "precision_bonus": 0.3,
                },
            },
            "rougher_terrain": {
                "korean": "{source}은(는) {target}과 비슷하지만 더 거침 → 안정성 강화",
                "english": "{source} is like {target} but rougher → enhance stability",
                "adjustments": {
                    "stability_bonus": 0.2,
                    "speed_multiplier": 0.7,
                    "stride_multiplier": 0.8,
                },
            },
            "higher_obstacle": {
                "korean": "{source}은(는) {target}과 비슷하지만 장애물이 더 높음 → 다리 높이 증가",
                "english": "{source} is like {target} but obstacles are higher → increase leg height",
                "adjustments": {
                    "leg_height_multiplier": 1.3,
                    "speed_multiplier": 0.6,
                    "caution_bonus": 0.2,
                },
            },
        }

    def find_analogy(
        self,
        current_situation: Dict[str, Any],
        experience_database: Optional[Any] = None,
        k: int = DEFAULT_K,
    ) -> AnalogyResult:
        """
        물리적 유추 찾기 / Find physical analogy.

        현재 상황과 가장 유사한 과거 경험을 찾고,
        속성 차이를 기반으로 유추를 생성합니다.

        Args:
            current_situation: 현재 물리적 상황
                - state: 상태 벡터 (62차원)
                - terrain_type: 지형 유형
                - object_type: 객체 유형
                - difficulty: 난이도
                - slope_angle: 경사 각도
                - friction: 마찰 계수
                - object_mass: 객체 질량
            experience_database: 경험 데이터베이스 (선택)
            k: 검색할 이웃 수

        Returns:
            AnalogyResult: 유추 결과
        """
        # 유사 경험 검색 / Retrieve similar experiences
        query_state = np.asarray(
            current_situation.get("state", np.zeros(STATE_DIM)),
            dtype=np.float32,
        )

        similar = self._retriever.retrieve_similar(query_state, k=k)

        if not similar:
            return AnalogyResult(
                target_situation="unknown",
                analogy_description="No similar experiences found",
                korean_description="유사한 경험을 찾을 수 없음",
                confidence=0.0,
            )

        # 가장 유사한 경험 / Most similar experience
        best_match = similar[0]
        best_exp = best_match.experience

        # 속성 차이 분석 / Analyze attribute differences
        analogy_type, source_desc, target_desc, adjustments = (
            self._analyze_attribute_diff(
                current_situation, best_exp, best_match.similarity
            )
        )

        # 유추 템플릿 적용 / Apply analogy template
        template = self._analogy_templates.get(analogy_type, {})

        korean_desc = template.get("korean", "{source}은(는) {target}과 유사")
        english_desc = template.get("english", "{source} is similar to {target}")

        korean_desc = korean_desc.replace("{source}", target_desc).replace(
            "{target}", source_desc
        )
        english_desc = english_desc.replace("{source}", target_desc).replace(
            "{target}", source_desc
        )

        # 템플릿 조정 + 분석 조정 병합 / Merge template and analysis adjustments
        final_adjustments = {**template.get("adjustments", {}), **adjustments}

        # 신뢰도 / Confidence
        confidence = best_match.similarity * (1.0 if best_exp.success else 0.5)

        result = AnalogyResult(
            source_situation=source_desc,
            target_situation=target_desc,
            analogy_description=english_desc,
            korean_description=korean_desc,
            suggested_adjustments=final_adjustments,
            confidence=float(np.clip(confidence, 0.0, 1.0)),
        )

        with self._lock:
            self._analogy_history.append(result)

        logger.info(
            "유추 발견: %s (신뢰도=%.3f)",
            korean_desc[:50], confidence,
        )

        return result

    def _analyze_attribute_diff(
        self,
        current: Dict[str, Any],
        past: PhysicalExperience,
        similarity: float,
    ) -> Tuple[str, str, str, Dict[str, Any]]:
        """
        속성 차이 분석 / Analyze attribute differences.

        현재 상황과 과거 경험 간의 물리적 속성 차이를 분석하여
        적절한 유추 유형을 결정합니다.

        Args:
            current: 현재 상황
            past: 과거 경험
            similarity: 유사도

        Returns:
            (analogy_type, source_desc, target_desc, adjustments)
        """
        adjustments: Dict[str, Any] = {}
        analogy_type = "rougher_terrain"  # 기본값 / Default

        # 소스/타겟 설명 / Source/target descriptions
        source_desc = past.terrain_type or past.object_type or "이전 상황"
        target_desc = current.get("terrain_type", "") or current.get("object_type", "") or "현재 상황"

        # 경사 차이 / Slope difference
        current_slope = current.get("slope_angle", 0.0)
        if current_slope > 10.0:
            analogy_type = "steeper_slope"
            adjustments["speed_multiplier"] = max(0.3, 1.0 - current_slope / 50.0)

        # 마찰 차이 / Friction difference
        current_friction = current.get("friction", 0.5)
        if current_friction < 0.3:
            analogy_type = "more_slippery"
            adjustments["speed_multiplier"] = max(0.3, current_friction)

        # 질량 차이 / Mass difference
        current_mass = current.get("object_mass", 0.0)
        if current_mass > 2.0:
            analogy_type = "heavier_object"
            adjustments["grip_force_multiplier"] = min(3.0, 1.0 + current_mass * 0.3)

        # 파편성 / Fragility
        current_fragility = current.get("fragility", 0.0)
        if current_fragility > 0.5:
            analogy_type = "more_fragile"
            adjustments["grip_force_multiplier"] = max(0.2, 1.0 - current_fragility * 0.5)

        # 난이도 차이 / Difficulty difference
        current_difficulty = current.get("difficulty", 1)
        if current_difficulty > past.difficulty + 2:
            adjustments["caution_bonus"] = 0.3

        return analogy_type, source_desc, target_desc, adjustments

    def get_analogy_history(self, n: int = 10) -> List[AnalogyResult]:
        """유추 이력 반환 / Return analogy history."""
        with self._lock:
            return self._analogy_history[-n:]

    def get_stats(self) -> Dict[str, Any]:
        """유추 엔진 통계 / Return analogy engine statistics."""
        with self._lock:
            return {
                "total_analogies": len(self._analogy_history),
                "retriever_stats": self._retriever.get_stats(),
                "templates": list(self._analogy_templates.keys()),
            }


# ─── 모듈 진입점 / Module Entry Point ───────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("=" * 60)
    print("퓨샷 물리적 적응 테스트 / Few-Shot Physical Adaptation Test")
    print("=" * 60)

    # 검색기 테스트 / Retriever test
    retriever = ExperienceRetriever(dimension=STATE_DIM, metric="cosine")

    # 가상 경험 인덱싱 / Index dummy experiences
    rng = np.random.RandomState(42)
    categories = ["locomotion", "gripping", "manipulation"]
    terrains = ["flat", "slope", "gravel", "carpet"]

    for i in range(200):
        exp = PhysicalExperience(
            state=rng.randn(STATE_DIM).astype(np.float32),
            action=rng.randn(ACTION_DIM).astype(np.float32) * 0.5,
            reward=rng.uniform(-1.0, 1.0),
            success=rng.random() > 0.3,
            category=categories[i % len(categories)],
            terrain_type=terrains[i % len(terrains)],
            difficulty=int(rng.randint(1, 10)),
        )
        retriever.index_experience(exp)

    print(f"인덱싱된 경험: {retriever.get_stats()}")

    # 유사 경험 검색 / Retrieve similar experiences
    query = rng.randn(STATE_DIM).astype(np.float32)
    results = retriever.retrieve_similar(query, k=5)
    print(f"\n검색 결과: {len(results)}개")
    for r in results:
        print(f"  유사도={r.similarity:.3f}, 거리={r.distance:.3f}, "
              f"성공={r.experience.success}, 카테고리={r.experience.category}")

    # 퓨샷 적응 테스트 / Few-shot adapter test
    adapter = FewShotAdapter(retriever)
    original_action = rng.randn(ACTION_DIM).astype(np.float32) * 0.5
    adapted = adapter.adapt_action(original_action, results)
    print(f"\n원래 행동 평균: {np.mean(original_action):.3f}")
    print(f"적응된 행동 평균: {np.mean(adapted.action):.3f}")
    print(f"신뢰도: {adapted.confidence:.3f}")
    print(f"소스 카테고리: {adapted.source_categories}")

    # 상태에서 직접 적응 / Direct adaptation from state
    adapted2 = adapter.adapt_from_state(query, original_action, k=5)
    print(f"직접 적응 신뢰도: {adapted2.confidence:.3f}")

    # 유추 엔진 테스트 / Analogy engine test
    print("\n유추 엔진 테스트 / Analogy Engine Test")
    analogy_engine = PhysicalAnalogyEngine(retriever)

    current_situation = {
        "state": rng.randn(STATE_DIM).astype(np.float32),
        "terrain_type": "가파른 경사면",
        "slope_angle": 25.0,
        "friction": 0.3,
        "difficulty": 7,
    }

    analogy = analogy_engine.find_analogy(current_situation)
    print(f"  한국어: {analogy.korean_description}")
    print(f"  영어: {analogy.analogy_description}")
    print(f"  신뢰도: {analogy.confidence:.3f}")
    print(f"  조정: {analogy.suggested_adjustments}")
    print(f"\n모든 테스트 완료 / All tests completed.")
