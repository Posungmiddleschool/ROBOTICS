#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 6계층 메모리 시스템 / Six-Layer Memory System
=============================================================

V8.5 → V8.5 업그레이드: 4계층 → 6계층

Layer 1 — 작업 기억 (Working Memory): deque (최근 50 상호작용, 휘발성)
Layer 2 — 일화 기억 (Episodic Memory): SQLite (대화/행동/관찰, 90일 보존)
Layer 3 — 의미 기억 (Semantic Memory): LanceDB (임베딩 벡터, 의미 검색)
Layer 4 — 절차 기억 (Procedural Memory): 스킬 라이브러리
Layer 5 — 세계지식 (World Knowledge): V8.5 신규 — 세계 데이터에서 학습한 사실
Layer 6 — 혁신기억 (Innovation Memory): V8.5 신규 — 새로운 해결책/발견

V8.5 추가 기능:
  - 교차 모달 연관 (시각↔촉각↔청각)
  - 연속 통합 (시간 기반 → 이벤트 기반 연속 통합)
  - 지식 그래프 통합
  - 인과 추론 통합
  - 메모리 기반 시뮬레이션
  - 인과 추론 기반 향상된 회상
  - 하위 호환성 유지 (connect_* 메서드)

검증: "어제 뭐 했어?" → 일화 기억 + 세계지식 → 정확 회상

버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("jihun.v84.memory_system")
logger.setLevel(logging.INFO)


# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

WORKING_MEMORY_CAPACITY = 50           # 작업 기억 최대 항목 수
EPISODIC_RETENTION_DAYS = 90           # 일화 기억 보존 일수
CONSOLIDATION_INTERVAL_S = 600.0       # V8: 3600→600 통합 주기 (10분, 더 자주)
FORGET_THRESHOLD_DAYS = 90             # 망각 임계값 (일)
WORLD_KNOWLEDGE_MAX_ITEMS = 50000      # 세계지식 최대 항목 수
INNOVATION_MEMORY_MAX_ITEMS = 5000     # 혁신기억 최대 항목 수
CROSS_MODAL_ASSOCIATION_DECAY = 0.95   # 교차 모달 연관 감쇄율

DEFAULT_DATA_DIR = Path(
    os.getenv("JIHUN_DATA_DIR", "/home/jihun/data")
)


class MemoryLayerType(Enum):
    """메모리 계층 유형 — V8: 6계층"""
    WORKING = "working"           # Layer 1 — 작업 기억 — deque
    EPISODIC = "episodic"         # Layer 2 — 일화 기억 — SQLite
    SEMANTIC = "semantic"         # Layer 3 — 의미 기억 — LanceDB
    PROCEDURAL = "procedural"     # Layer 4 — 절차 기억 — Skills
    WORLD_KNOWLEDGE = "world_knowledge"   # Layer 5 — 세계지식 — V8.5 신규
    INNOVATION = "innovation"             # Layer 6 — 혁신기억 — V8.5 신규


class MemoryPriority(Enum):
    """메모리 저장 우선순위 — 높을수록 중요"""
    LOW = 0       # 일반 대화
    MEDIUM = 1    # 작업 관련 정보
    HIGH = 2      # 소유자 관련 정보
    CRITICAL = 3  # 안전/생존 관련
    INNOVATIVE = 4  # V8: 혁신적 발견


class CrossModalType(Enum):
    """V8: 교차 모달 연관 유형"""
    VISUAL_TACTILE = "visual_tactile"     # 시각↔촉각
    VISUAL_AUDITORY = "visual_auditory"   # 시각↔청각
    TACTILE_AUDITORY = "tactile_auditory" # 촉각↔청각
    CONCEPT_SENSOR = "concept_sensor"     # 개념↔센서


# ──────────────────────────────────────────────────────────────────────────────
# 데이터 클래스 / Data Classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class MemoryItem:
    """메모리 항목 — 모든 계층의 기본 단위"""
    item_id: str = ""
    content: str = ""                              # 텍스트 내용
    layer: MemoryLayerType = MemoryLayerType.WORKING
    priority: MemoryPriority = MemoryPriority.MEDIUM
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    embedding: Optional[List[float]] = None        # 의미 기억용 임베딩
    # V8.5 신규 필드
    causal_context: Optional[Dict[str, Any]] = None   # 인과 맥락
    emotional_context: Optional[Dict[str, Any]] = None # 감성 맥락
    modal_associations: List[Dict[str, Any]] = field(default_factory=list)  # 교차 모달 연관
    novelty_score: float = 0.0                     # V8: 참신함 점수
    world_knowledge_links: List[str] = field(default_factory=list)  # 세계지식 링크

    def __post_init__(self):
        if not self.item_id:
            self.item_id = f"mem_{int(self.timestamp * 1000)}"

    @property
    def age_hours(self) -> float:
        """현재까지의 경과 시간 (시간)"""
        return (time.time() - self.timestamp) / 3600.0

    @property
    def age_days(self) -> float:
        """현재까지의 경과 시간 (일)"""
        return self.age_hours / 24.0


@dataclass
class RecallResult:
    """회상 결과"""
    items: List[MemoryItem] = field(default_factory=list)
    total_count: int = 0
    query: str = ""
    layer: Optional[MemoryLayerType] = None
    elapsed_ms: float = 0.0
    # V8.5 신규
    causal_chain_used: bool = False          # 인과 추론 사용 여부
    world_knowledge_enriched: bool = False   # 세계지식 보강 여부

    @property
    def best_match(self) -> Optional[MemoryItem]:
        """가장 관련성 높은 항목 반환"""
        return self.items[0] if self.items else None


@dataclass
class CrossModalAssociation:
    """V8: 교차 모달 연관 — 시각↔촉각↔청각 매핑"""
    association_id: str = ""
    source_modality: str = ""      # "visual", "tactile", "auditory", "concept"
    target_modality: str = ""
    source_content: str = ""
    target_content: str = ""
    strength: float = 1.0          # 연관 강도 (0~1)
    association_type: CrossModalType = CrossModalType.CONCEPT_SENSOR
    timestamp: float = field(default_factory=time.time)

    def __post_init__(self):
        if not self.association_id:
            self.association_id = f"cma_{int(self.timestamp * 1000)}"

    def decay(self) -> None:
        """연관 강도 감쇄"""
        self.strength *= CROSS_MODAL_ASSOCIATION_DECAY


@dataclass
class WorldKnowledgeEntry:
    """V8: Layer 5 세계지식 항목"""
    entry_id: str = ""
    fact: str = ""
    source: str = ""               # 출처 (예: "wikipedia", "news", "observation")
    confidence: float = 0.8        # 신뢰도 (0~1)
    timestamp: float = field(default_factory=time.time)
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    causal_links: List[str] = field(default_factory=list)  # 인과 관련 항목 ID

    def __post_init__(self):
        if not self.entry_id:
            self.entry_id = f"wk_{int(self.timestamp * 1000)}"


@dataclass
class InnovationEntry:
    """V8: Layer 6 혁신기억 항목"""
    entry_id: str = ""
    innovation_type: str = ""      # "novel_solution", "discovery", "creative_combination"
    description: str = ""
    originality_score: float = 0.0 # 독창성 점수 (0~1)
    utility_score: float = 0.0     # 유용성 점수 (0~1)
    timestamp: float = field(default_factory=time.time)
    source_skills: List[str] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    validation_count: int = 0      # 검증 횟수
    validated: bool = False

    def __post_init__(self):
        if not self.entry_id:
            self.entry_id = f"innov_{int(self.timestamp * 1000)}"


# ──────────────────────────────────────────────────────────────────────────────
# 6계층 메모리 시스템 / Six-Layer Memory System
# ──────────────────────────────────────────────────────────────────────────────

class SixLayerMemory:
    """
    6계층 메모리 시스템 / Six-Layer Memory System (V8)

    V7의 4계층 + V8의 2계층 추가:
    - Layer 1 (작업 기억): 최근 상호작용 유지 (빠른 접근, 휘발성)
    - Layer 2 (일화 기억): 경험/대화/행동을 시간순 저장 (90일 보존)
    - Layer 3 (의미 기억): 중요 정보를 벡터로 저장 (의미 검색)
    - Layer 4 (절차 기억): 학습된 스킬 저장 (skill_library와 연동)
    - Layer 5 (세계지식): V8.5 — 세계 데이터에서 학습한 사실 (지식 그래프 연동)
    - Layer 6 (혁신기억): V8.5 — 새로운 해결책/발견 (창발적 지능)

    V8.5 추가 기능:
    - 교차 모달 연관 (시각↔촉각↔청각)
    - 연속 통합 (이벤트 기반)
    - 지식 그래프 / 인과 추론 통합
    - 메모리 기반 시뮬레이션
    - 하위 호환성 (FourLayerMemory → SixLayerMemory)

    검증 시나리오:
    - "어제 뭐 했어?" → Layer 2 일화 기억 + Layer 5 세계지식 → 정확 회상
    - "내가 좋아하는 음료가 뭐야?" → Layer 3 의미 기억 → 정확 회상
    - "어떻게 컵을 잡아?" → Layer 4 절차 기억 → 스킬 반환
    - "세계에서 가장 높은 건물은?" → Layer 5 세계지식 → 최신 정보
    - "새로운 방법이 없을까?" → Layer 6 혁신기억 → 창의적 해결책
    """

    def __init__(
        self,
        data_dir: Path = DEFAULT_DATA_DIR,
        working_capacity: int = WORKING_MEMORY_CAPACITY,
    ) -> None:
        self._data_dir = data_dir
        self._working_capacity = working_capacity
        self._lock = threading.RLock()

        # Layer 1 — 작업 기억: 최근 50개 상호작용 (deque, 휘발성)
        self._working_memory: deque[MemoryItem] = deque(
            maxlen=working_capacity
        )

        # Layer 2 — 일화 기억 (지연 초기화)
        self._episodic: Optional[Any] = None  # EpisodicMemory

        # Layer 3 — 의미 기억 (지연 초기화)
        self._semantic: Optional[Any] = None  # SemanticMemory

        # Layer 4 — 절차 기억 (지연 초기화)
        self._procedural: Optional[Any] = None  # SkillLibrary

        # Layer 5 — 세계지식 (V8.5 신규)
        self._world_knowledge: List[WorldKnowledgeEntry] = []

        # Layer 6 — 혁신기억 (V8.5 신규)
        self._innovation_memory: List[InnovationEntry] = []

        # V8: 교차 모달 연관
        self._cross_modal_associations: List[CrossModalAssociation] = []

        # V8: 외부 시스템 참조 (지연 연결)
        self._knowledge_graph: Optional[Any] = None
        self._causal_reasoning: Optional[Any] = None

        # 통합 주기 타이머 — V8: 연속 통합
        self._last_consolidation: float = 0.0
        self._consolidation_count: int = 0
        self._continuous_consolidation_enabled: bool = True

        logger.info(
            f"6계층 메모리 초기화: 작업기억={working_capacity}항목, "
            f"데이터경로={data_dir}"
        )

    def initialize(self) -> None:
        """6계층 메모리 시스템 초기화"""
        logger.info("6계층 메모리 시스템 초기화 완료")

    # ──────────────────────────────────────────────────────────────────────
    # 하위 메모리 시스템 연결 / Connect Sub-Memory Systems
    # ──────────────────────────────────────────────────────────────────────

    def connect_episodic(self, episodic_memory: Any) -> None:
        """Layer 2 일화 기억 연결"""
        self._episodic = episodic_memory
        logger.info("Layer 2 일화 기억 연결 완료")

    def connect_semantic(self, semantic_memory: Any) -> None:
        """Layer 3 의미 기억 연결"""
        self._semantic = semantic_memory
        logger.info("Layer 3 의미 기억 연결 완료")

    def connect_procedural(self, skill_library: Any) -> None:
        """Layer 4 절차 기억 연결"""
        self._procedural = skill_library
        logger.info("Layer 4 절차 기억 연결 완료")

    def connect_knowledge_graph(self, knowledge_graph: Any) -> None:
        """V8: 지식 그래프 연결"""
        self._knowledge_graph = knowledge_graph
        logger.info("지식 그래프 연결 완료")

    def connect_causal_reasoning(self, causal_reasoning: Any) -> None:
        """V8: 인과 추론 연결"""
        self._causal_reasoning = causal_reasoning
        logger.info("인과 추론 연결 완료")

    # ──────────────────────────────────────────────────────────────────────
    # store() — 메모리 저장 / Store Memory
    # ──────────────────────────────────────────────────────────────────────

    def store(
        self,
        content: str,
        priority: MemoryPriority = MemoryPriority.MEDIUM,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        target_layers: Optional[List[MemoryLayerType]] = None,
        causal_context: Optional[Dict[str, Any]] = None,        # V8
        emotional_context: Optional[Dict[str, Any]] = None,     # V8
        novelty_score: float = 0.0,                             # V8
    ) -> str:
        """
        메모리 저장 — 적절한 계층에 자동 분배 (V8: 6계층)

        Args:
            content: 저장할 텍스트 내용
            priority: 저장 우선순위
            tags: 검색용 태그
            metadata: 추가 메타데이터
            target_layers: 특정 계층에만 저장 (None=자동)
            causal_context: 인과 맥락 (V8)
            emotional_context: 감성 맥락 (V8)
            novelty_score: 참신함 점수 (V8)

        Returns:
            저장된 메모리 항목 ID
        """
        with self._lock:
            item = MemoryItem(
                content=content,
                priority=priority,
                tags=tags or [],
                metadata=metadata or {},
                causal_context=causal_context,
                emotional_context=emotional_context,
                novelty_score=novelty_score,
            )

            # 자동 계층 결정
            if target_layers is None:
                target_layers = self._determine_layers(item)

            # 각 계층에 저장
            item_id = item.item_id

            # Layer 1 — 작업 기억 (항상 저장)
            if MemoryLayerType.WORKING in target_layers:
                self._store_working(item)

            # Layer 2 — 일화 기억
            if MemoryLayerType.EPISODIC in target_layers and self._episodic:
                self._store_episodic(item)

            # Layer 3 — 의미 기억 (높은 우선순위만)
            if MemoryLayerType.SEMANTIC in target_layers and self._semantic:
                self._store_semantic(item)

            # Layer 4 — 절차 기억 (스킬 관련만)
            if MemoryLayerType.PROCEDURAL in target_layers and self._procedural:
                self._store_procedural(item)

            # Layer 5 — 세계지식 (V8.5 신규)
            if MemoryLayerType.WORLD_KNOWLEDGE in target_layers:
                self._store_world_knowledge(item)

            # Layer 6 — 혁신기억 (V8.5 신규 — 높은 참신함 점수만)
            if MemoryLayerType.INNOVATION in target_layers:
                self._store_innovation(item)

            logger.debug(
                f"메모리 저장: '{content[:30]}...' → "
                f"계층 {[l.value for l in target_layers]}"
            )

            # V8: 연속 통합 (이벤트 기반)
            if self._continuous_consolidation_enabled:
                self._maybe_consolidate()

            return item_id

    def _determine_layers(self, item: MemoryItem) -> List[MemoryLayerType]:
        """메모리 항목을 저장할 계층 자동 결정 — V8: 6계층"""
        layers = [MemoryLayerType.WORKING]  # 작업 기억은 항상 포함

        # 모든 항목은 일화 기억에도 저장
        layers.append(MemoryLayerType.EPISODIC)

        # 높은 우선순위 → 의미 기억에도 저장
        if item.priority.value >= MemoryPriority.HIGH.value:
            layers.append(MemoryLayerType.SEMANTIC)

        # 스킬 관련 태그 → 절차 기억에도 저장
        skill_tags = {"skill", "action", "procedure", "compound"}
        if skill_tags & set(item.tags):
            layers.append(MemoryLayerType.PROCEDURAL)

        # V8: 세계지식 태그 → Layer 5
        world_tags = {"fact", "world", "knowledge", "observation", "data"}
        if world_tags & set(item.tags):
            layers.append(MemoryLayerType.WORLD_KNOWLEDGE)

        # V8: 높은 참신함 → Layer 6 혁신기억
        if item.novelty_score >= 0.7 or item.priority == MemoryPriority.INNOVATIVE:
            layers.append(MemoryLayerType.INNOVATION)

        return layers

    def _store_working(self, item: MemoryItem) -> None:
        """Layer 1 — 작업 기억에 저장"""
        working_item = MemoryItem(
            item_id=item.item_id,
            content=item.content,
            layer=MemoryLayerType.WORKING,
            priority=item.priority,
            timestamp=item.timestamp,
            metadata=item.metadata,
            tags=item.tags,
            causal_context=item.causal_context,
            emotional_context=item.emotional_context,
            novelty_score=item.novelty_score,
        )
        self._working_memory.append(working_item)

    def _store_episodic(self, item: MemoryItem) -> None:
        """Layer 2 — 일화 기억에 저장"""
        try:
            self._episodic.store_episode(
                content=item.content,
                episode_type="memory_store",
                tags=item.tags,
                metadata={
                    **item.metadata,
                    "priority": item.priority.value,
                    "source_layer": "six_layer_memory",
                    "causal_context": item.causal_context,
                    "emotional_context": item.emotional_context,
                    "novelty_score": item.novelty_score,
                },
            )
        except Exception as e:
            logger.error(f"일화 기억 저장 오류: {e}")

    def _store_semantic(self, item: MemoryItem) -> None:
        """Layer 3 — 의미 기억에 저장"""
        try:
            self._semantic.store_fact(
                fact=item.content,
                tags=item.tags,
                metadata=item.metadata,
            )
        except Exception as e:
            logger.error(f"의미 기억 저장 오류: {e}")

    def _store_procedural(self, item: MemoryItem) -> None:
        """Layer 4 — 절차 기억에 저장"""
        try:
            # 절차 기억은 skill_library를 통해 관리
            if hasattr(self._procedural, "register_from_memory"):
                self._procedural.register_from_memory(item)
        except Exception as e:
            logger.error(f"절차 기억 저장 오류: {e}")

    def _store_world_knowledge(self, item: MemoryItem) -> None:
        """Layer 5 — 세계지식에 저장 (V8.5 신규)"""
        if len(self._world_knowledge) >= WORLD_KNOWLEDGE_MAX_ITEMS:
            # 오래된 항목 제거 (LRU)
            self._world_knowledge.sort(key=lambda x: x.timestamp, reverse=True)
            self._world_knowledge = self._world_knowledge[
                :WORLD_KNOWLEDGE_MAX_ITEMS - 1000
            ]

        entry = WorldKnowledgeEntry(
            fact=item.content,
            source=item.metadata.get("source", "unknown"),
            confidence=item.metadata.get("confidence", 0.8),
            tags=item.tags,
            metadata=item.metadata,
            embedding=item.embedding,
        )
        self._world_knowledge.append(entry)

        # V8: 지식 그래프에도 반영
        if self._knowledge_graph:
            try:
                self._knowledge_graph.add_fact(
                    fact=item.content,
                    source=entry.source,
                    confidence=entry.confidence,
                    tags=item.tags,
                )
            except Exception as e:
                logger.debug(f"지식 그래프 반영 오류: {e}")

    def _store_innovation(self, item: MemoryItem) -> None:
        """Layer 6 — 혁신기억에 저장 (V8.5 신규)"""
        if len(self._innovation_memory) >= INNOVATION_MEMORY_MAX_ITEMS:
            # 검증되지 않은 오래된 항목 제거
            self._innovation_memory = [
                e for e in self._innovation_memory
                if e.validated or e.age_days < 30
            ][:INNOVATION_MEMORY_MAX_ITEMS - 500]

        entry = InnovationEntry(
            innovation_type=item.metadata.get("innovation_type", "novel_solution"),
            description=item.content,
            originality_score=item.novelty_score,
            utility_score=item.metadata.get("utility_score", 0.5),
            source_skills=item.metadata.get("source_skills", []),
            context=item.metadata,
        )
        self._innovation_memory.append(entry)

    # ──────────────────────────────────────────────────────────────────────
    # recall() — 메모리 회상 / Recall Memory
    # ──────────────────────────────────────────────────────────────────────

    def recall(
        self,
        query: str,
        target_layers: Optional[List[MemoryLayerType]] = None,
        max_results: int = 5,
        time_range: Optional[Tuple[float, float]] = None,
        use_causal_reasoning: bool = True,    # V8
        enrich_with_world_knowledge: bool = True,  # V8
    ) -> RecallResult:
        """
        메모리 회상 — 쿼리에 맞는 메모리를 검색 (V8: 인과 추론 + 세계지식 보강)

        Args:
            query: 검색 쿼리
            target_layers: 검색할 계층 (None=모든 계층)
            max_results: 최대 결과 수
            time_range: (시작시간, 종료시간) 필터
            use_causal_reasoning: 인과 추론 사용 (V8)
            enrich_with_world_knowledge: 세계지식 보강 (V8)

        Returns:
            RecallResult — 검색 결과
        """
        start_time = time.time()

        if target_layers is None:
            target_layers = list(MemoryLayerType)

        all_items: List[MemoryItem] = []

        # Layer 1 — 작업 기억에서 검색
        if MemoryLayerType.WORKING in target_layers:
            all_items.extend(self._recall_working(query, time_range))

        # Layer 2 — 일화 기억에서 검색
        if MemoryLayerType.EPISODIC in target_layers and self._episodic:
            all_items.extend(self._recall_episodic(query, time_range))

        # Layer 3 — 의미 기억에서 검색
        if MemoryLayerType.SEMANTIC in target_layers and self._semantic:
            all_items.extend(self._recall_semantic(query))

        # Layer 4 — 절차 기억에서 검색
        if MemoryLayerType.PROCEDURAL in target_layers and self._procedural:
            all_items.extend(self._recall_procedural(query))

        # Layer 5 — 세계지식에서 검색 (V8)
        if MemoryLayerType.WORLD_KNOWLEDGE in target_layers:
            all_items.extend(self._recall_world_knowledge(query))

        # Layer 6 — 혁신기억에서 검색 (V8)
        if MemoryLayerType.INNOVATION in target_layers:
            all_items.extend(self._recall_innovation(query))

        # V8: 인과 추론으로 컨텍스트 보강
        causal_chain_used = False
        if use_causal_reasoning and self._causal_reasoning:
            try:
                causal_items = self._enrich_with_causal_reasoning(query)
                if causal_items:
                    all_items.extend(causal_items)
                    causal_chain_used = True
            except Exception:
                pass

        # V8: 세계지식으로 보강
        world_knowledge_enriched = False
        if enrich_with_world_knowledge:
            try:
                wk_items = self._enrich_with_world_knowledge(query)
                if wk_items:
                    all_items.extend(wk_items)
                    world_knowledge_enriched = True
            except Exception:
                pass

        # 타임스탬프순 정렬 (최신순)
        all_items.sort(key=lambda x: x.timestamp, reverse=True)

        # 중복 제거
        seen_ids = set()
        unique_items = []
        for item in all_items:
            if item.item_id not in seen_ids:
                seen_ids.add(item.item_id)
                unique_items.append(item)

        # 결과 제한
        result_items = unique_items[:max_results]

        elapsed_ms = (time.time() - start_time) * 1000

        return RecallResult(
            items=result_items,
            total_count=len(unique_items),
            query=query,
            elapsed_ms=elapsed_ms,
            causal_chain_used=causal_chain_used,
            world_knowledge_enriched=world_knowledge_enriched,
        )

    def _recall_working(
        self,
        query: str,
        time_range: Optional[Tuple[float, float]] = None,
    ) -> List[MemoryItem]:
        """Layer 1 — 작업 기억에서 키워드 검색"""
        results = []
        query_lower = query.lower()

        for item in self._working_memory:
            # 키워드 매칭
            if query_lower in item.content.lower():
                if time_range:
                    if time_range[0] <= item.timestamp <= time_range[1]:
                        results.append(item)
                else:
                    results.append(item)
            # 태그 매칭
            elif any(query_lower in tag.lower() for tag in item.tags):
                results.append(item)

        return results

    def _recall_episodic(
        self,
        query: str,
        time_range: Optional[Tuple[float, float]] = None,
    ) -> List[MemoryItem]:
        """Layer 2 — 일화 기억에서 검색"""
        try:
            episodes = self._episodic.search_episodes(
                query=query,
                limit=10,
            )
            results = []
            for ep in episodes:
                item = MemoryItem(
                    item_id=ep.get("episode_id", ""),
                    content=ep.get("content", ""),
                    layer=MemoryLayerType.EPISODIC,
                    timestamp=ep.get("timestamp", 0),
                    metadata=ep.get("metadata", {}),
                    tags=ep.get("tags", []),
                )
                if time_range:
                    if time_range[0] <= item.timestamp <= time_range[1]:
                        results.append(item)
                else:
                    results.append(item)
            return results
        except Exception as e:
            logger.error(f"일화 기억 회상 오류: {e}")
            return []

    def _recall_semantic(self, query: str) -> List[MemoryItem]:
        """Layer 3 — 의미 기억에서 벡터 검색"""
        try:
            similar = self._semantic.search_similar(
                query=query,
                top_k=5,
            )
            results = []
            for fact in similar:
                item = MemoryItem(
                    item_id=fact.get("fact_id", ""),
                    content=fact.get("content", ""),
                    layer=MemoryLayerType.SEMANTIC,
                    timestamp=fact.get("timestamp", 0),
                    metadata=fact.get("metadata", {}),
                    similarity=fact.get("similarity", 0.0),
                )
                results.append(item)
            return results
        except Exception as e:
            logger.error(f"의미 기억 회상 오류: {e}")
            return []

    def _recall_procedural(self, query: str) -> List[MemoryItem]:
        """Layer 4 — 절차 기억에서 스킬 검색"""
        try:
            skills = self._procedural.search_skills(query)
            results = []
            for skill in skills:
                item = MemoryItem(
                    item_id=skill.get("skill_id", ""),
                    content=skill.get("description", ""),
                    layer=MemoryLayerType.PROCEDURAL,
                    metadata=skill,
                    tags=["skill", "procedural"],
                )
                results.append(item)
            return results
        except Exception as e:
            logger.error(f"절차 기억 회상 오류: {e}")
            return []

    def _recall_world_knowledge(self, query: str) -> List[MemoryItem]:
        """Layer 5 — 세계지식에서 검색 (V8.5 신규)"""
        results = []
        query_lower = query.lower()

        for entry in self._world_knowledge:
            # 키워드 매칭
            if query_lower in entry.fact.lower():
                item = MemoryItem(
                    item_id=entry.entry_id,
                    content=entry.fact,
                    layer=MemoryLayerType.WORLD_KNOWLEDGE,
                    timestamp=entry.timestamp,
                    metadata={
                        "source": entry.source,
                        "confidence": entry.confidence,
                        **entry.metadata,
                    },
                    tags=entry.tags,
                )
                results.append(item)

            # 태그 매칭
            elif any(query_lower in tag.lower() for tag in entry.tags):
                item = MemoryItem(
                    item_id=entry.entry_id,
                    content=entry.fact,
                    layer=MemoryLayerType.WORLD_KNOWLEDGE,
                    timestamp=entry.timestamp,
                    metadata={
                        "source": entry.source,
                        "confidence": entry.confidence,
                    },
                    tags=entry.tags,
                )
                results.append(item)

        # 신뢰도순 정렬
        results.sort(
            key=lambda x: x.metadata.get("confidence", 0.0),
            reverse=True,
        )
        return results[:10]

    def _recall_innovation(self, query: str) -> List[MemoryItem]:
        """Layer 6 — 혁신기억에서 검색 (V8.5 신규)"""
        results = []
        query_lower = query.lower()

        for entry in self._innovation_memory:
            if query_lower in entry.description.lower():
                item = MemoryItem(
                    item_id=entry.entry_id,
                    content=entry.description,
                    layer=MemoryLayerType.INNOVATION,
                    timestamp=entry.timestamp,
                    metadata={
                        "innovation_type": entry.innovation_type,
                        "originality_score": entry.originality_score,
                        "utility_score": entry.utility_score,
                        "validated": entry.validated,
                    },
                    tags=["innovation", entry.innovation_type],
                )
                results.append(item)

        # 독창성순 정렬
        results.sort(
            key=lambda x: x.metadata.get("originality_score", 0.0),
            reverse=True,
        )
        return results[:5]

    # ──────────────────────────────────────────────────────────────────────
    # V8: 인과 추론/세계지식 보강 / Enrichment Methods
    # ──────────────────────────────────────────────────────────────────────

    def _enrich_with_causal_reasoning(self, query: str) -> List[MemoryItem]:
        """V8: 인과 추론으로 회상 보강"""
        if not self._causal_reasoning:
            return []

        try:
            related = self._causal_reasoning.find_related(query)
            results = []
            for r in related:
                item = MemoryItem(
                    item_id=f"causal_{r.get('id', '')}",
                    content=r.get("description", ""),
                    layer=MemoryLayerType.WORKING,
                    metadata={"source": "causal_reasoning"},
                    tags=["causal", "enrichment"],
                )
                results.append(item)
            return results[:3]
        except Exception:
            return []

    def _enrich_with_world_knowledge(self, query: str) -> List[MemoryItem]:
        """V8: 세계지식으로 회상 보강"""
        results = []
        query_lower = query.lower()

        # 간단한 키워드 매칭으로 보강 (의미 검색은 Layer 5에서 처리)
        for entry in self._world_knowledge:
            if entry.confidence > 0.9 and any(
                word in entry.fact.lower() for word in query_lower.split()
            ):
                item = MemoryItem(
                    item_id=f"wk_enrich_{entry.entry_id}",
                    content=entry.fact,
                    layer=MemoryLayerType.WORLD_KNOWLEDGE,
                    metadata={
                        "source": entry.source,
                        "confidence": entry.confidence,
                        "enrichment": True,
                    },
                )
                results.append(item)

        return results[:2]

    # ──────────────────────────────────────────────────────────────────────
    # V8: 교차 모달 연관 / Cross-Modal Associations
    # ──────────────────────────────────────────────────────────────────────

    def add_cross_modal_association(
        self,
        source_modality: str,
        target_modality: str,
        source_content: str,
        target_content: str,
        association_type: CrossModalType = CrossModalType.CONCEPT_SENSOR,
        strength: float = 1.0,
    ) -> str:
        """
        V8: 교차 모달 연관 추가

        예: 시각적 "빨간 컵" ↔ 촉각적 "차가운 표면"
        """
        association = CrossModalAssociation(
            source_modality=source_modality,
            target_modality=target_modality,
            source_content=source_content,
            target_content=target_content,
            association_type=association_type,
            strength=strength,
        )
        self._cross_modal_associations.append(association)
        return association.association_id

    def get_cross_modal_associations(
        self,
        content: str,
        modality: Optional[str] = None,
        min_strength: float = 0.3,
    ) -> List[CrossModalAssociation]:
        """
        V8: 교차 모달 연관 조회

        주어진 내용과 관련된 교차 모달 연관 반환
        """
        results = []
        content_lower = content.lower()

        for assoc in self._cross_modal_associations:
            if assoc.strength < min_strength:
                continue

            if content_lower in assoc.source_content.lower() or \
               content_lower in assoc.target_content.lower():
                if modality is None or (
                    assoc.source_modality == modality or
                    assoc.target_modality == modality
                ):
                    results.append(assoc)

        return results

    # ──────────────────────────────────────────────────────────────────────
    # search() — 의미 기억 벡터 검색 / Semantic Search
    # ──────────────────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: int = 5,
        min_similarity: float = 0.5,
    ) -> List[MemoryItem]:
        """
        의미 기억 벡터 검색 — LanceDB를 통한 유사도 검색

        Args:
            query: 검색 쿼리
            top_k: 반환할 최대 결과 수
            min_similarity: 최소 유사도 임계값

        Returns:
            유사도순 정렬된 메모리 항목 리스트
        """
        if not self._semantic:
            logger.warning("의미 기억이 연결되지 않음 — 작업 기억에서만 검색")
            return self._recall_working(query)

        try:
            results = self._semantic.search_similar(
                query=query, top_k=top_k,
            )
            items = []
            for fact in results:
                sim = fact.get("similarity", 0.0)
                if sim >= min_similarity:
                    items.append(MemoryItem(
                        item_id=fact.get("fact_id", ""),
                        content=fact.get("content", ""),
                        layer=MemoryLayerType.SEMANTIC,
                        timestamp=fact.get("timestamp", 0),
                        metadata=fact.get("metadata", {}),
                        similarity=sim,
                    ))
            return items
        except Exception as e:
            logger.error(f"의미 검색 오류: {e}")
            return []

    # ──────────────────────────────────────────────────────────────────────
    # forget() — 메모리 삭제 / Forget Memory
    # ──────────────────────────────────────────────────────────────────────

    def forget(
        self,
        item_id: str,
        target_layers: Optional[List[MemoryLayerType]] = None,
    ) -> bool:
        """
        메모리 삭제 — 지정된 계층에서 항목 제거 (V8: 6계층 지원)

        Args:
            item_id: 삭제할 메모리 항목 ID
            target_layers: 삭제할 계층 (None=모든 계층)

        Returns:
            삭제 성공 여부
        """
        with self._lock:
            if target_layers is None:
                target_layers = list(MemoryLayerType)

            deleted = False

            # Layer 1 — 작업 기억에서 삭제
            if MemoryLayerType.WORKING in target_layers:
                new_deque = deque(maxlen=self._working_capacity)
                for item in self._working_memory:
                    if item.item_id != item_id:
                        new_deque.append(item)
                    else:
                        deleted = True
                self._working_memory = new_deque

            # Layer 2 — 일화 기억에서 삭제
            if MemoryLayerType.EPISODIC in target_layers and self._episodic:
                try:
                    self._episodic.delete_episode(item_id)
                    deleted = True
                except Exception as e:
                    logger.error(f"일화 기억 삭제 오류: {e}")

            # Layer 3 — 의미 기억에서 삭제
            if MemoryLayerType.SEMANTIC in target_layers and self._semantic:
                try:
                    self._semantic.delete_fact(item_id)
                    deleted = True
                except Exception as e:
                    logger.error(f"의미 기억 삭제 오류: {e}")

            # Layer 5 — 세계지식에서 삭제 (V8)
            if MemoryLayerType.WORLD_KNOWLEDGE in target_layers:
                before = len(self._world_knowledge)
                self._world_knowledge = [
                    e for e in self._world_knowledge if e.entry_id != item_id
                ]
                if len(self._world_knowledge) < before:
                    deleted = True

            # Layer 6 — 혁신기억에서 삭제 (V8)
            if MemoryLayerType.INNOVATION in target_layers:
                before = len(self._innovation_memory)
                self._innovation_memory = [
                    e for e in self._innovation_memory if e.entry_id != item_id
                ]
                if len(self._innovation_memory) < before:
                    deleted = True

            if deleted:
                logger.info(f"메모리 삭제 완료: {item_id}")
            else:
                logger.warning(f"메모리 삭제 실패 — 항목 없음: {item_id}")

            return deleted

    # ──────────────────────────────────────────────────────────────────────
    # consolidate() — 메모리 통합 / Memory Consolidation
    # ──────────────────────────────────────────────────────────────────────

    def consolidate(self) -> Dict[str, Any]:
        """
        메모리 통합 — 작업 기억 → 일화/의미/세계지식/혁신기억으로 승격

        V8: 연속 통합 (시간 기반 + 이벤트 기반)
        1. 작업 기억에서 중요 항목을 일화 기억에 확실히 저장
        2. 높은 우선순위 항목을 의미 기억에 승격
        3. 오래된 일화 기억 압축 (7일+)
        4. 만료된 메모리 정리
        5. V8: 세계지식 신뢰도 재평가
        6. V8: 혁신기억 검증
        7. V8: 교차 모달 연관 감쇄

        Returns:
            통합 결과 통계
        """
        with self._lock:
            start_time = time.time()
            stats = {
                "promoted_to_episodic": 0,
                "promoted_to_semantic": 0,
                "promoted_to_world_knowledge": 0,     # V8
                "promoted_to_innovation": 0,          # V8
                "episodes_compressed": 0,
                "expired_removed": 0,
                "world_knowledge_reassessed": 0,      # V8
                "innovations_validated": 0,           # V8
                "cross_modal_decayed": 0,             # V8
                "working_memory_size": len(self._working_memory),
            }

            # 1. 작업 기억 → 일화 기억 승격 (확인용)
            for item in self._working_memory:
                if item.priority.value >= MemoryPriority.HIGH.value:
                    if self._semantic:
                        self._store_semantic(item)
                        stats["promoted_to_semantic"] += 1

                # V8: 세계지식 승격
                if item.novelty_score > 0.5 and any(
                    t in item.tags for t in {"fact", "world", "observation"}
                ):
                    self._store_world_knowledge(item)
                    stats["promoted_to_world_knowledge"] += 1

                # V8: 혁신기억 승격
                if item.novelty_score >= 0.7:
                    self._store_innovation(item)
                    stats["promoted_to_innovation"] += 1

            # 2. 일화 기억 압축 (7일 이상)
            if self._episodic:
                try:
                    compressed = self._episodic.compress_old()
                    stats["episodes_compressed"] = compressed
                except Exception as e:
                    logger.error(f"일화 기억 압축 오류: {e}")

            # 3. 만료된 일화 기억 정리 (90일 이상)
            if self._episodic:
                try:
                    expired = self._episodic.cleanup_expired(
                        retention_days=FORGET_THRESHOLD_DAYS,
                    )
                    stats["expired_removed"] = expired
                except Exception as e:
                    logger.error(f"만료 메모리 정리 오류: {e}")

            # V8: 4. 세계지식 신뢰도 재평가
            reassessed = self._reassess_world_knowledge()
            stats["world_knowledge_reassessed"] = reassessed

            # V8: 5. 혁신기억 검증
            validated = self._validate_innovations()
            stats["innovations_validated"] = validated

            # V8: 6. 교차 모달 연관 감쇄
            decayed = self._decay_cross_modal_associations()
            stats["cross_modal_decayed"] = decayed

            self._consolidation_count += 1
            self._last_consolidation = time.time()

            elapsed_ms = (time.time() - start_time) * 1000
            stats["elapsed_ms"] = elapsed_ms

            logger.info(
                f"메모리 통합 완료: 의미승격={stats['promoted_to_semantic']}, "
                f"세계지식승격={stats['promoted_to_world_knowledge']}, "
                f"혁신승격={stats['promoted_to_innovation']}, "
                f"압축={stats['episodes_compressed']}, "
                f"만료정리={stats['expired_removed']}"
            )

            return stats

    def _maybe_consolidate(self) -> None:
        """V8: 연속 통합 — 마지막 통합 후 충분한 시간이 지났으면 실행"""
        elapsed = time.time() - self._last_consolidation
        if elapsed >= CONSOLIDATION_INTERVAL_S:
            try:
                self.consolidate()
            except Exception as e:
                logger.error(f"연속 통합 오류: {e}")

    def _reassess_world_knowledge(self) -> int:
        """V8: 세계지식 신뢰도 재평가 — 오래된 정보 신뢰도 감소"""
        reassessed = 0
        now = time.time()

        for entry in self._world_knowledge:
            age_days = (now - entry.timestamp) / 86400
            if age_days > 30:
                # 30일 이상 된 정보는 신뢰도 점진적 감소
                decay = max(0.3, 1.0 - (age_days - 30) * 0.01)
                new_confidence = entry.confidence * decay
                if new_confidence != entry.confidence:
                    entry.confidence = new_confidence
                    reassessed += 1

        # 신뢰도 너무 낮은 항목 제거
        before = len(self._world_knowledge)
        self._world_knowledge = [
            e for e in self._world_knowledge if e.confidence >= 0.2
        ]
        reassessed += before - len(self._world_knowledge)

        return reassessed

    def _validate_innovations(self) -> int:
        """V8: 혁신기억 검증 — 재사용/재확인된 혁신은 검증 표시"""
        validated = 0

        for entry in self._innovation_memory:
            if not entry.validated:
                # 작업 기억에서 동일한 해결책이 다시 나타났는지 확인
                for item in self._working_memory:
                    if item.content and entry.description[:20] in item.content:
                        entry.validation_count += 1
                        if entry.validation_count >= 2:
                            entry.validated = True
                            validated += 1
                        break

        return validated

    def _decay_cross_modal_associations(self) -> int:
        """V8: 교차 모달 연관 감쇄 — 사용되지 않은 연관 약화"""
        decayed = 0

        for assoc in self._cross_modal_associations:
            old_strength = assoc.strength
            assoc.decay()
            if assoc.strength != old_strength:
                decayed += 1

        # 너무 약해진 연관 제거
        before = len(self._cross_modal_associations)
        self._cross_modal_associations = [
            a for a in self._cross_modal_associations
            if a.strength >= 0.1
        ]
        decayed += before - len(self._cross_modal_associations)

        return decayed

    # ──────────────────────────────────────────────────────────────────────
    # V8: 메모리 기반 시뮬레이션 / Memory-Based Simulation
    # ──────────────────────────────────────────────────────────────────────

    def simulate_outcome(
        self,
        action: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        V8: 메모리 기반 시뮬레이션 — 과거 경험으로 행동 결과 예측

        Args:
            action: 시뮬레이션할 행동
            context: 현재 컨텍스트

        Returns:
            예측 결과 (성공 확률, 과거 사례, 위험 요소)
        """
        # 관련 기억 검색
        related = self.recall(
            query=action,
            target_layers=[
                MemoryLayerType.EPISODIC,
                MemoryLayerType.PROCEDURAL,
                MemoryLayerType.WORLD_KNOWLEDGE,
            ],
            max_results=10,
        )

        # 성공/실패 통계
        success_count = 0
        failure_count = 0
        risks = []

        for item in related.items:
            outcome = item.metadata.get("outcome", "")
            if outcome == "success":
                success_count += 1
            elif outcome == "failure":
                failure_count += 1
                # 위험 요소 수집
                risk = item.metadata.get("error", "")
                if risk:
                    risks.append(risk)

        total = success_count + failure_count
        success_probability = success_count / total if total > 0 else 0.5

        return {
            "action": action,
            "success_probability": success_probability,
            "based_on_experiences": total,
            "risks_identified": risks[:3],
            "confidence": min(1.0, total / 5.0),  # 경험 많을수록 신뢰
        }

    # ──────────────────────────────────────────────────────────────────────
    # 유틸리티 / Utility Methods
    # ──────────────────────────────────────────────────────────────────────

    def get_context(
        self,
        current_query: str,
        max_items: int = 10,
    ) -> List[MemoryItem]:
        """
        현재 쿼리에 대한 컨텍스트 구성 — 모든 6계층에서 관련 정보 수집

        AI 모델 입력용 컨텍스트 생성에 사용
        """
        context_items = []

        # 작업 기억에서 최근 항목
        recent = list(self._working_memory)[-5:]
        context_items.extend(recent)

        # 일화/의미/세계지식에서 관련 항목
        recall_result = self.recall(
            query=current_query,
            max_results=max_items - len(context_items),
            use_causal_reasoning=True,
            enrich_with_world_knowledge=True,
        )
        context_items.extend(recall_result.items)

        # 중복 제거
        seen_ids = set()
        unique_items = []
        for item in context_items:
            if item.item_id not in seen_ids:
                seen_ids.add(item.item_id)
                unique_items.append(item)

        return unique_items[:max_items]

    def get_stats(self) -> Dict[str, Any]:
        """메모리 시스템 통계 반환 — V8: 6계층 정보 포함"""
        stats = {
            "working_memory_size": len(self._working_memory),
            "working_memory_capacity": self._working_capacity,
            "world_knowledge_size": len(self._world_knowledge),        # V8
            "innovation_memory_size": len(self._innovation_memory),    # V8
            "cross_modal_associations": len(self._cross_modal_associations),  # V8
            "layers_connected": {
                "episodic": self._episodic is not None,
                "semantic": self._semantic is not None,
                "procedural": self._procedural is not None,
                "knowledge_graph": self._knowledge_graph is not None,      # V8
                "causal_reasoning": self._causal_reasoning is not None,    # V8
            },
            "consolidation_count": self._consolidation_count,
            "last_consolidation": self._last_consolidation,
            "continuous_consolidation": self._continuous_consolidation_enabled,  # V8
        }

        if self._episodic and hasattr(self._episodic, "get_stats"):
            stats["episodic_stats"] = self._episodic.get_stats()

        if self._semantic and hasattr(self._semantic, "get_stats"):
            stats["semantic_stats"] = self._semantic.get_stats()

        if self._procedural and hasattr(self._procedural, "get_stats"):
            stats["procedural_stats"] = self._procedural.get_stats()

        return stats

    def clear_working_memory(self) -> None:
        """작업 기억 전체 삭제 (Layer 1만)"""
        with self._lock:
            self._working_memory.clear()
            logger.info("작업 기억 전체 삭제 완료")

    # ── V8: 하위 호환성 별칭 / Backward Compatibility Aliases ────────────

    # FourLayerMemory 호환 — V8.5 코드가 동작하도록
    FourLayerMemory = None  # 클래스 레벨에서는 동적 설정

    def shutdown(self) -> None:
        """메모리 시스템 종료"""
        # 최종 통합
        try:
            self.consolidate()
        except Exception:
            pass
        logger.info("6계층 메모리 시스템 종료 완료")


# 하위 호환: FourLayerMemory 별칭
FourLayerMemory = SixLayerMemory
