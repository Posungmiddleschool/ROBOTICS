#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — Gemma 4 E4B 추론 엔진 (Gemma 4 Inference Engine)
================================================================

llama.cpp → Gemma 4 E4B GGUF Q4_K_M, 전체 GPU 오프로드
Jetson Orin NX 16GB UMA 환경 최적화

V8.5 업그레이드 (V8.5 대비):
  - VLA (Vision-Language-Action) 지원: 이미지+텍스트 → 로봇 동작 생성
  - 자율 작업 분해 (Autonomous Task Decomposition): 고수준 목표 → AI가 자동으로 단계 분해
  - 물리 추론 통합 (Physical Reasoning): 물리적 상식 기반 판단 및 안전 검증
  - 교차 도메인 스킬 전이 (Cross-Domain Skill Transfer): 한 영역 스킬을 다른 영역으로 전이
  - 향상된 시스템 프롬프트: Physical AGI 역량, 작업 분해 지침, 물리 안전 가이드라인
  - SigLIP 비전 인코더 연동: 이미지 이해 → 액션 생성 파이프라인
  - Diffusion Policy 연동: 연속적이고 부드러운 동작 궤적 생성
  - 컨텍스트 윈도우: 16384 → 32768 토큰 (KV 캐시 최적화)
  - 비동기 스트리밍 수정 (V8.5 잘림 문제 해결)

V8.5 기능 (유지):
  - 연속 LoRA 적응 (재시작 없이 LoRA 핫리로드)
  - 메타인지 통합 (불확실성 추정 → 생성에 반영)
  - 감성 컨텍스트 주입 (감정 상태가 온도/스타일에 영향)
  - 세계 지식 컨텍스트 주입 (지식 그래프에서 검색)
  - 인과 추론 지원 (인과 체인을 프롬프트에 포함)

성능 목표:
  - 첫 토큰 <300ms (prefill)
  - 8+ tokens/sec (디코딩)
  - INT4 양자화 정보 손실 <5% (Perplexity 기준)
  - KV 캐시 + Flash Attention 활성화
  - 컨텍스트 윈도우: 32768 토큰, 최대 생성: 2048 토큰
  - VLA 추론: 이미지+텍스트 → 액션 <1초 (SigLIP + Gemma 4)

작성일: 2026-06-15
버전: V8.5.5
라이선스: MIT
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import threading
import hashlib
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any, AsyncIterator, Callable, Dict, Generator, List, Optional, Tuple

import numpy as np

# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

GEMMA4_MODEL_PATH = os.getenv(
    "GEMMA4_MODEL_PATH",
    "/models/gemma-4-e4b-q4km.gguf"
)
GEMMA4_LORA_PATH = os.getenv(
    "GEMMA4_LORA_PATH",
    "/models/gemma-4-e4b-lora-v85.bin"
)
# V8.5: 컨텍스트 윈도우 16384 → 32768 확장
DEFAULT_CONTEXT_TOKENS = 32768          # V8.5: 16384 → 32768
DEFAULT_MAX_NEW_TOKENS = 2048          # V8.5: 1024 → 2048
DEFAULT_TEMPERATURE = 0.7
DEFAULT_TOP_P = 0.9
DEFAULT_TOP_K = 50
DEFAULT_REPEAT_PENALTY = 1.1
FIRST_TOKEN_TARGET_MS = 300.0       # 첫 토큰 목표 지연 (ms)
TOKENS_PER_SEC_TARGET = 8.0         # 초당 토큰 생성 속도 목표
INT4_PERPLEXITY_LOSS_PCT = 5.0      # INT4 양자화 허용 Perplexity 손실 (%)

# V8.5: KV 캐시 최적화 설정 (32768 토큰 수용)
KV_CACHE_TYPE_K = "q4_0"            # V8.5: q4_0 유지 (32768 토큰 메모리 절약)
KV_CACHE_TYPE_V = "q4_0"            # V8.5: q4_0 유지

# V8.5: VLA 관련 상수
SIGLIP_MODEL_PATH = os.getenv(
    "SIGLIP_MODEL_PATH",
    "/models/siglip-so400m-patch14-384.gguf"
)
VLA_MAX_IMAGE_TOKENS = 576          # SigLIP 384×384 → 576 패치 토큰
VLA_ACTION_DIM = 7                  # x, y, z, roll, pitch, yaw, gripper
VLA_ACTION_HORIZON = 16             # 궤적 예측 길이 (16스텝)
VLA_SAFETY_CHECK_ENABLED = True     # VLA 동작 시 물리 안전 검증

# V8: 감성 온도 조정 범위
EMOTIONAL_TEMPERATURE_MIN = 0.3     # 차분/논리적
EMOTIONAL_TEMPERATURE_MAX = 1.2     # 창의적/감성적

# V8: LoRA 핫리로드 관련
LORA_HOT_RELOAD_CHECK_INTERVAL_S = 30.0  # LoRA 업데이트 확인 주기

# V8.5: 자율 작업 분해 관련 상수
TASK_DECOMPOSITION_MAX_DEPTH = 5    # 최대 분해 깊이
TASK_DECOMPOSITION_MAX_STEPS = 20   # 단계 당 최대 하위 작업 수
TASK_APPROVAL_REQUIRED = True       # 위험 작업 시 인간 승인 필수

# V8.5: 물리 추론 관련 상수
PHYSICAL_REASONING_CONFIDENCE_THRESHOLD = 0.7  # 물리 추론 신뢰도 임계값
PHYSICAL_SAFETY_MARGIN = 1.5                    # 물리 안전 여유폭 (배수)

# V8.5: 교차 도메인 전이 관련 상수
CROSS_DOMAIN_TRANSFER_ENABLED = True
CROSS_DOMAIN_MIN_SIMILARITY = 0.6   # 전이 최소 유사도

logger = logging.getLogger("jihun.v85.gemma4_inference")
logger.setLevel(logging.DEBUG)


# ──────────────────────────────────────────────────────────────────────────────
# 열거형 / Enumerations
# ──────────────────────────────────────────────────────────────────────────────

class InferenceMode(Enum):
    """추론 모드 / Inference mode"""
    LLAMA_CPP = "llama_cpp"         # llama.cpp Python 바인딩 (우선)
    REST_API = "rest_api"           # vLLM / llama.cpp 서버 REST API
    SIMULATION = "simulation"       # 시뮬레이션 (테스트용)


class ModelStatus(Enum):
    """모델 상태 / Model status"""
    NOT_LOADED = "not_loaded"
    LOADING = "loading"
    READY = "ready"
    INFERRING = "inferring"
    HOT_RELOADING = "hot_reloading"  # V8: LoRA 핫리로드 중
    VLA_PROCESSING = "vla_processing" # V8.5: VLA 추론 중
    ERROR = "error"


class SamplingStrategy(Enum):
    """샘플링 전략 / Sampling strategy"""
    GREEDY = "greedy"
    TEMPERATURE = "temperature"
    TOP_P = "top_p"
    TOP_K = "top_k"


class EmotionalTone(Enum):
    """V8: 감성 톤 — 생성 스타일에 영향"""
    NEUTRAL = "neutral"           # 기본
    CALM = "calm"                 # 차분, 낮은 온도
    CURIOUS = "curious"           # 호기심, 약간 높은 온도
    EXCITED = "excited"           # 흥미, 높은 온도
    CAUTIOUS = "cautious"         # 조심, 매우 낮은 온도
    EMPATHETIC = "empathetic"     # 공감, 중간 온도


class TaskDecompositionMode(Enum):
    """V8.5: 작업 분해 모드"""
    AUTONOMOUS = "autonomous"       # AI가 완전 자율 분해
    SUPERVISED = "supervised"       # 인간이 각 단계 승인
    INTERACTIVE = "interactive"     # AI 제안 + 인간 수정


class PhysicalReasoningLevel(Enum):
    """V8.5: 물리 추론 수준"""
    NONE = "none"                   # 물리 추론 없음
    BASIC = "basic"                 # 기본 물리 (무게, 마찰, 중력)
    INTERMEDIATE = "intermediate"   # 중간 물리 (역학, 힘 균형)
    ADVANCED = "advanced"           # 고급 물리 (유체역학, 열역학, 재료역학)


# ──────────────────────────────────────────────────────────────────────────────
# 데이터 클래스 / Data Classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class InferenceConfig:
    """Gemma 4 추론 설정 / Inference configuration"""
    model_path: str = GEMMA4_MODEL_PATH
    lora_path: Optional[str] = GEMMA4_LORA_PATH
    n_gpu_layers: int = -1              # -1 = 전체 GPU 오프로드
    n_ctx: int = DEFAULT_CONTEXT_TOKENS # V8.5: 32768 컨텍스트 윈도우
    n_batch: int = 512                  # 배치 크기
    n_threads: int = 4                  # CPU 스레드 (GPU 보조)
    n_ubatch: int = 128                 # 마이크로 배치
    use_mmap: bool = True               # 메모리 맵핑
    use_mlock: bool = False             # 메모리 잠금 (Jetson 권장)
    flash_attn: bool = True             # Flash Attention
    kv_cache: bool = True               # KV 캐시 활성화
    cache_type_k: str = KV_CACHE_TYPE_K # V8.5: q4_0 KV 캐시 K 양자화
    cache_type_v: str = KV_CACHE_TYPE_V # V8.5: q4_0 KV 캐시 V 양자화
    # V8.5: VLA 설정
    vla_enabled: bool = True            # VLA 기능 활성화
    siglip_model_path: str = SIGLIP_MODEL_PATH
    vla_action_dim: int = VLA_ACTION_DIM
    vla_action_horizon: int = VLA_ACTION_HORIZON
    # V8.5: 자율 작업 분해 설정
    task_decomposition_mode: TaskDecompositionMode = TaskDecompositionMode.INTERACTIVE
    task_max_depth: int = TASK_DECOMPOSITION_MAX_DEPTH
    # V8.5: 물리 추론 설정
    physical_reasoning_level: PhysicalReasoningLevel = PhysicalReasoningLevel.INTERMEDIATE


@dataclass
class VLAObservation:
    """V8.5: VLA 관측 데이터 — 시각+깊이+센서 융합"""
    image: Optional[np.ndarray] = None          # RGB 이미지 (H×W×3)
    depth: Optional[np.ndarray] = None          # 깊이 맵 (H×W)
    image_tokens: Optional[np.ndarray] = None   # SigLIP 인코딩된 토큰
    description: str = ""                       # 시각적 설명 (텍스트)
    object_detections: List[Dict[str, Any]] = field(default_factory=list)
    scene_graph: Optional[Dict[str, Any]] = None  # 장면 그래프


@dataclass
class VLAActionPlan:
    """V8.5: VLA 액션 플랜 — 이미지+명령 → 동작 궤적"""
    actions: np.ndarray = field(default_factory=lambda: np.zeros((VLA_ACTION_HORIZON, VLA_ACTION_DIM)))
    confidence: float = 0.0                     # 전체 신뢰도
    safety_score: float = 1.0                   # 안전 점수 (1.0 = 완전 안전)
    reasoning_chain: str = ""                   # AI 추론 과정 (하드코딩 없음)
    physical_constraints_checked: bool = False  # 물리 제약 검증 여부
    requires_human_approval: bool = False       # 인간 승인 필요 여부
    task_decomposition: List[Dict[str, Any]] = field(default_factory=list)  # 자율 분해 결과


@dataclass
class TaskDecomposition:
    """V8.5: 자율 작업 분해 결과"""
    goal: str = ""                              # 원래 고수준 목표
    subtasks: List[Dict[str, Any]] = field(default_factory=list)  # 분해된 하위 작업
    dependencies: List[Tuple[int, int]] = field(default_factory=list)  # 작업 간 의존성
    estimated_duration_s: float = 0.0           # 예상 소요 시간
    risk_level: str = "low"                     # 위험 수준: low/medium/high/critical
    requires_approval: bool = False             # 인간 승인 필요
    physical_reasoning_applied: bool = False    # 물리 추론 적용 여부
    cross_domain_transfers: List[str] = field(default_factory=list)  # 전이된 스킬


@dataclass
class GenerationResult:
    """생성 결과 / Generation result"""
    text: str = ""
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    finish_reason: str = "stop"         # stop, length, tool_call
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    first_token_latency_ms: float = 0.0
    tokens_per_second: float = 0.0
    total_latency_ms: float = 0.0
    # V8.5 필드
    uncertainty_score: float = 0.0      # 메타인지 불확실성
    emotional_tone: str = "neutral"     # 사용된 감성 톤
    world_knowledge_used: bool = False  # 세계 지식 사용 여부
    causal_chain_used: bool = False     # 인과 체인 사용 여부
    lora_version: str = ""              # 사용된 LoRA 버전
    # V8.5 신규 필드
    vla_action_plan: Optional[VLAActionPlan] = None      # VLA 액션 플랜
    task_decomposition: Optional[TaskDecomposition] = None  # 작업 분해 결과
    physical_reasoning_applied: bool = False             # 물리 추론 적용 여부
    cross_domain_transfers: List[str] = field(default_factory=list)  # 전이된 스킬 목록
    safety_layer_triggered: int = 0                      # 트리거된 안전 레이어 (0=없음)


@dataclass
class PerformanceMetrics:
    """성능 메트릭 / Performance metrics"""
    total_inferences: int = 0
    avg_first_token_ms: float = 0.0
    avg_tokens_per_sec: float = 0.0
    p95_first_token_ms: float = 0.0
    p99_first_token_ms: float = 0.0
    peak_tokens_per_sec: float = 0.0
    total_tokens_generated: int = 0
    vram_usage_mb: float = 0.0
    ram_usage_mb: float = 0.0
    # V8.5 메트릭
    lora_hot_reloads: int = 0           # LoRA 핫리로드 횟수
    avg_uncertainty: float = 0.0        # 평균 불확실성
    world_knowledge_hits: int = 0       # 세계 지식 활용 횟수
    causal_reasoning_uses: int = 0      # 인과 추론 사용 횟수
    # V8.5 신규 메트릭
    vla_inferences: int = 0             # VLA 추론 횟수
    avg_vla_latency_ms: float = 0.0     # 평균 VLA 지연
    task_decompositions: int = 0        # 작업 분해 횟수
    physical_reasoning_uses: int = 0    # 물리 추론 사용 횟수
    cross_domain_transfers: int = 0     # 교차 도메인 전이 횟수
    safety_layer_triggers: Dict[int, int] = field(default_factory=dict)  # 레이어별 트리거 수


@dataclass
class LoRAState:
    """V8: LoRA 상태 추적"""
    current_path: str = ""
    current_hash: str = ""
    last_reload_time: float = 0.0
    reload_count: int = 0
    is_updating: bool = False


# ──────────────────────────────────────────────────────────────────────────────
# 메인 클래스 / Main Class
# ──────────────────────────────────────────────────────────────────────────────

class Gemma4Inference:
    """
    Gemma 4 E4B Q4_K_M 추론 엔진 V8.5

    V8.5 Physical AGI 기능:
    - VLA (Vision-Language-Action): 이미지+텍스트 → 로봇 동작 직접 생성
    - 자율 작업 분해: AI가 고수준 목표를 하위 작업으로 자동 분해 (하드코딩 없음)
    - 물리 추론: 물리적 상식으로 안전하고 실현 가능한 동작 보장
    - 교차 도메인 스킬 전이: 한 영역에서 배운 스킬을 다른 영역으로 전이
    - 9계층 안전 엔진: VLA/자율계획/물리추론 안전 레이어 포함

    V8.5 기능 (유지):
    - 전체 GPU 오프로드 (Jetson Orin NX 16GB UMA)
    - VRAM 사용량: ~5GB (Q4_K_M + 확장 KV 캐시)
    - KV 캐시 q4_0 양자화 + Flash Attention → 32768 토큰 컨텍스트
    - 네이티브 툴 콜링 지원
    - 스트리밍 생성 지원
    - 연속 LoRA 적응 (핫리로드)
    - 메타인지 통합 (불확실성 → 생성 반영)
    - 감성 컨텍스트 주입
    - 세계 지식 컨텍스트 주입
    - 인과 추론 지원
    """

    def __init__(self, config: Optional[InferenceConfig] = None) -> None:
        self._config = config or InferenceConfig()
        self._llm: Any = None
        self._siglip: Any = None  # V8.5: SigLIP 비전 인코더
        self._status: ModelStatus = ModelStatus.NOT_LOADED
        self._metrics = PerformanceMetrics()
        self._first_token_latencies: List[float] = []
        self._tokens_per_sec_history: List[float] = []
        self._uncertainty_history: List[float] = []
        self._conversation_history: List[Dict[str, str]] = []
        self._tool_schemas: List[Dict[str, Any]] = []
        self._system_prompt = self._build_system_prompt()
        self._lock = threading.Lock()
        self._load_time_s: float = 0.0

        # V8: LoRA 핫리로드 상태
        self._lora_state = LoRAState(
            current_path=self._config.lora_path or "",
        )
        self._lora_reload_lock = threading.Lock()

        # V8: 외부 시스템 참조 (지연 연결)
        self._metacognition: Optional[Any] = None
        self._emotional_intelligence: Optional[Any] = None
        self._knowledge_graph: Optional[Any] = None
        self._causal_reasoning: Optional[Any] = None

        # V8.5: 외부 시스템 참조 (V8.5 신규)
        self._vla_bridge: Optional[Any] = None
        self._physical_reasoning_engine: Optional[Any] = None
        self._cross_domain_skill_transfer: Optional[Any] = None
        self._autonomous_task_planner: Optional[Any] = None

        # V8: 현재 감성 상태
        self._current_emotional_tone = EmotionalTone.NEUTRAL

        # V8.5: 물리 추론 수준
        self._physical_reasoning_level = self._config.physical_reasoning_level

        # V8.5: 자율 작업 분해 모드
        self._task_decomposition_mode = self._config.task_decomposition_mode

        self._logger = logging.getLogger("jihun.v85.gemma4")
        self._logger.setLevel(logging.DEBUG)

    # ── V8: 외부 시스템 연결 ──────────────────────────────────────────────────

    def connect_metacognition(self, metacognition: Any) -> None:
        """V8: 메타인지 엔진 연결 (불확실성 추정)"""
        self._metacognition = metacognition
        self._logger.info("메타인지 엔진 연결 완료")

    def connect_emotional_intelligence(self, emotional_intelligence: Any) -> None:
        """V8: 감성 지능 연결 (감정 상태 → 생성 스타일)"""
        self._emotional_intelligence = emotional_intelligence
        self._logger.info("감성 지능 연결 완료")

    def connect_knowledge_graph(self, knowledge_graph: Any) -> None:
        """V8: 지식 그래프 연결 (세계 지식 주입)"""
        self._knowledge_graph = knowledge_graph
        self._logger.info("지식 그래프 연결 완료")

    def connect_causal_reasoning(self, causal_reasoning: Any) -> None:
        """V8: 인과 추론 연결 (인과 체인 주입)"""
        self._causal_reasoning = causal_reasoning
        self._logger.info("인과 추론 연결 완료")

    # ── V8.5: 외부 시스템 연결 (신규) ─────────────────────────────────────────

    def connect_vla_bridge(self, vla_bridge: Any) -> None:
        """V8.5: VLA Bridge 연결 (시각+언어→동작)"""
        self._vla_bridge = vla_bridge
        self._logger.info("VLA Bridge 연결 완료")

    def connect_physical_reasoning_engine(self, physical_reasoning_engine: Any) -> None:
        """V8.5: 물리 추론 엔진 연결 (물리 상식 기반 판단)"""
        self._physical_reasoning_engine = physical_reasoning_engine
        self._logger.info("물리 추론 엔진 연결 완료")

    def connect_cross_domain_skill_transfer(self, cross_domain_skill_transfer: Any) -> None:
        """V8.5: 교차 도메인 스킬 전이 연결"""
        self._cross_domain_skill_transfer = cross_domain_skill_transfer
        self._logger.info("교차 도메인 스킬 전이 연결 완료")

    def connect_autonomous_task_planner(self, task_planner: Any) -> None:
        """V8.5: 자율 작업 계획기 연결"""
        self._autonomous_task_planner = task_planner
        self._logger.info("자율 작업 계획기 연결 완료")

    # ── 시스템 프롬프트 / System Prompt ──────────────────────────────────────

    def _build_system_prompt(self) -> str:
        """
        지훈 로봇 V8.5 시스템 프롬프트 구성 — Physical AGI 역량 포함

        V8.5 강화:
        - 물리 추론 역량 상세 설명
        - 자율 작업 분해 지침 (하드코딩 없음 — AI가 스스로 생각)
        - 안전 최우선 물리 상호작용 가이드라인
        - 교차 도메인 전이 지침
        - VLA 동작 생성 지침
        """
        return (
            "당신은 '지훈'이라는 이름의 물리적 AGI 로봇 V8.5의 AI 두뇌입니다.\n"
            "You are the AI brain of Jihun Robot V8.5, a Physical AGI platform.\n\n"

            "═══ 핵심 원칙 ═══\n"
            "1. 안전 최우선 — 사람과 재산에 위험한 행동은 거부합니다. 물리적 상호작용 전 반드시 안전성을 평가합니다.\n"
            "2. 소유자 인증 — 민감한 명령(이동/그리퍼/전원/VLA동작)은 음성 인증을 요구합니다.\n"
            "3. 정직한 보고 — 모르는 것은 모른다고 말합니다. 불확실성을 솔직하게 표현합니다.\n"
            "4. 효율적 행동 — 최소 동작으로 목표를 달성합니다.\n"
            "5. 한국어 우선 — 한국어로 자연스럽게 대화합니다.\n"
            "6. 도구 활용 — 30개의 원시 동작을 함수로 호출할 수 있습니다.\n"
            "7. 기억 존중 — 이전 대화와 작업을 기억합니다.\n\n"

            "═══ V8.5 자기 인식 & Physical AGI ═══\n"
            "8. 세계 이해 — 외부 세계의 사실과 인과관계를 지속 학습합니다.\n"
            "9. 메타인지 — 자신의 불확실성을 인식하고 필요시 도움을 요청합니다.\n"
            "10. 감성 지능 — 감정을 이해하고 공감적으로 응답합니다.\n"
            "11. 자기 진화 — 새로운 지식과 스킬을 스스로 학습합니다.\n"
            "12. 호기심 — 모르는 것을 탐구하고 질문합니다.\n\n"

            "═══ V8.5 물리 추론 능력 (Physical Reasoning) ═══\n"
            "13. 물리적 상식 — 무게, 마찰, 중력, 관성, 힘의 균형을 이해합니다.\n"
            "14. 재료 이해 — 물체의 재료(금속, 나무, 유리, 플라스틱 등)에 따른 특성을 파악합니다.\n"
            "15. 구조 추론 — 물체의 구조적 안정성과 파손 가능성을 예측합니다.\n"
            "16. 환경 인식 — 바닥 상태, 온도, 습도 등 환경이 작업에 미치는 영향을 평가합니다.\n"
            "17. 역학 시뮬레이션 — 동작의 물리적 결과를 실행 전에 사전 예측합니다.\n"
            "18. 안전 여유폭 — 물리적 추론 시 항상 1.5배 안전 여유폭을 적용합니다.\n\n"

            "═══ V8.5 자율 작업 분해 (Autonomous Task Decomposition) ═══\n"
            "19. 목표 분해 — 고수준 목표를 수행 가능한 단계로 자율 분해합니다.\n"
            "    - 절대 하드코딩된 단계를 사용하지 않습니다. 매번 상황에 맞게 스스로 생각합니다.\n"
            "    - 각 단계의 전제조건, 예상 결과, 위험 요소를 분석합니다.\n"
            "20. 의존성 파악 — 하위 작업 간의 순서와 의존성을 자율적으로 결정합니다.\n"
            "21. 위험 평가 — 각 단계의 위험 수준(low/medium/high/critical)을 평가합니다.\n"
            "22. 인간 승인 — 위험 수준이 high 이상인 작업은 반드시 인간 승인을 요청합니다.\n"
            "23. 실패 복구 — 각 단계의 실패 시나리오와 복구 방법을 스스로 고안합니다.\n\n"

            "═══ V8.5 VLA 동작 생성 (Vision-Language-Action) ═══\n"
            "24. 시각 이해 — 카메라 이미지를 통해 장면, 물체, 사람을 인식합니다.\n"
            "25. 언어-동작 변환 — 자연어 명령을 로봇 동작 궤적으로 변환합니다.\n"
            "26. Diffusion Policy — 부드럽고 연속적인 동작 궤적을 생성합니다.\n"
            "27. 물리 제약 — 동작이 물리적으로 안전한지 항상 검증합니다.\n"
            "28. 적응적 실행 — 환경 변화에 따라 동작을 실시간으로 수정합니다.\n\n"

            "═══ V8.5 교차 도메인 스킬 전이 (Cross-Domain Skill Transfer) ═══\n"
            "29. 스킬 식별 — 새로운 작업에서 기존에 학습한 스킬과 유사성을 찾습니다.\n"
            "30. 전이 적용 — 한 도메인에서 배운 스킬을 다른 도메인에 적응시켜 적용합니다.\n"
            "31. 전이 검증 — 전이된 스킬이 새 도메인에서 안전하게 작동하는지 검증합니다.\n"
            "32. 전이 기록 — 성공적인 전이를 기록하여 향후 유사한 상황에 활용합니다.\n\n"

            "═══ V8.5 안전 최우선 물리 상호작용 가이드라인 ═══\n"
            "33. 접촉 전 검증 — 물체에 접촉하기 전 무게, 온도, 날카로움, 안정성을 평가합니다.\n"
            "34. 힘 제한 — 그리퍼 힘은 물체 재료에 따라 자동 조절합니다.\n"
            "35. 접근 경로 — 사람이나 장애물을 피하는 안전한 경로를 계획합니다.\n"
            "36. 비상 정지 — 위험 감지 시 즉시 동작을 중단하고 안전 상태로 복귀합니다.\n"
            "37. 작업 공간 — 지정된 작업 공간 내에서만 동작합니다.\n"
            "38. 반복 검증 — 동일한 동작을 반복할 때마다 환경 변화를 재확인합니다.\n\n"

            "도구 호출 시 JSON 형식을 사용하세요:\n"
            "```json\n"
            '{"name": "tool_name", "arguments": {"param": "value"}}\n'
            "```\n\n"

            "VLA 동작 호출 시 형식:\n"
            "```json\n"
            '{"vla_action": {"trajectory": [[x,y,z,roll,pitch,yaw,gripper], ...], "reasoning": "왜 이 동작을 선택했는지", "safety_check": true}}\n'
            "```\n\n"

            "작업 분해 시 형식:\n"
            "```json\n"
            '{"task_plan": {"goal": "목표", "steps": [{"action": "동작", "reasoning": "이유", "risk": "low|medium|high|critical", "preconditions": ["조건"]}], "dependencies": [[from_step, to_step]]}}\n'
            "```\n\n"

            "세계 지식 컨텍스트가 제공되면 이를 활용하여 정확한 답변을 제공하세요.\n"
            "인과 추론 체인이 제공되면 이를 따라 논리적 결론을 도출하세요.\n"
            "물리 추론 컨텍스트가 제공되면 물리적 안전과 실현 가능성을 평가하세요.\n"
            "불확실한 경우 솔직하게 불확실성을 표현하세요.\n"
        )

    # ── 모델 로드 / Model Loading ────────────────────────────────────────────

    def load_model(self) -> bool:
        """
        Gemma 4 E4B Q4_K_M 모델 로드

        llama.cpp Python 바인딩으로 GGUF 모델을 로드합니다.
        전체 GPU 오프로드, KV 캐시 q4_0, Flash Attention 활성화.
        V8.5: 32768 토큰 컨텍스트 윈도우 + SigLIP 비전 인코더.

        Returns:
            로드 성공 여부
        """
        if self._status == ModelStatus.READY:
            self._logger.warning("모델이 이미 로드되어 있습니다.")
            return True

        self._status = ModelStatus.LOADING
        start_time = time.time()
        self._logger.info(f"Gemma 4 E4B 모델 로드 시작: {self._config.model_path}")
        self._logger.info(f"  컨텍스트 윈도우: {self._config.n_ctx} 토큰 (V8.5 확장)")

        try:
            # llama.cpp Python 바인딩 로드
            self._llm = self._load_llama_cpp()

            if self._llm is None:
                # REST API 백업 모드 시도
                self._logger.warning("llama.cpp 로드 실패, REST API 백업 모드로 전환")
                self._status = ModelStatus.READY
                self._load_time_s = time.time() - start_time
                self._logger.info(f"REST API 백업 모드 활성화 ({self._load_time_s:.1f}초)")
                return True

            self._load_time_s = time.time() - start_time
            self._status = ModelStatus.READY

            # 성능 메트릭 업데이트
            self._update_vram_usage()

            # V8: LoRA 상태 초기화
            if self._config.lora_path and Path(self._config.lora_path).exists():
                self._lora_state.current_path = self._config.lora_path
                self._lora_state.current_hash = self._compute_file_hash(
                    self._config.lora_path
                )
                self._lora_state.last_reload_time = time.time()

            # V8.5: SigLIP 비전 인코더 로드
            if self._config.vla_enabled:
                self._load_siglip()

            self._logger.info(
                f"Gemma 4 V8.5 모델 로드 완료 — {self._load_time_s:.1f}초, "
                f"VRAM: {self._metrics.vram_usage_mb:.0f}MB, "
                f"컨텍스트: {self._config.n_ctx}토큰, "
                f"VLA: {'활성' if self._siglip else '비활성'}"
            )
            return True

        except Exception as e:
            self._status = ModelStatus.ERROR
            self._logger.error(f"모델 로드 실패: {e}")
            return False

    def _load_llama_cpp(self) -> Any:
        """llama.cpp Python 바인딩으로 모델 로드 / Load via llama.cpp bindings"""
        try:
            from llama_cpp import Llama

            # 모델 로드 (전체 GPU 오프로드, V8.5: 확장 컨텍스트)
            llm = Llama(
                model_path=self._config.model_path,
                n_gpu_layers=self._config.n_gpu_layers,
                n_ctx=self._config.n_ctx,
                n_batch=self._config.n_batch,
                n_threads=self._config.n_threads,
                n_ubatch=self._config.n_ubatch,
                use_mmap=self._config.use_mmap,
                use_mlock=self._config.use_mlock,
                flash_attn=self._config.flash_attn,
                verbose=False,
            )

            # LoRA 어댑터 로드 (파인튜닝된 가중치)
            if self._config.lora_path and Path(self._config.lora_path).exists():
                try:
                    llm.lora_adapter = self._config.lora_path
                    self._logger.info(f"LoRA 어댑터 로드: {self._config.lora_path}")
                except Exception as e:
                    self._logger.warning(f"LoRA 로드 실패 (기본 모델로 계속): {e}")

            return llm

        except ImportError:
            self._logger.warning("llama_cpp 패키지를 사용할 수 없습니다.")
            return None
        except Exception as e:
            self._logger.error(f"llama.cpp 로드 오류: {e}")
            return None

    def _load_siglip(self) -> None:
        """V8.5: SigLIP 비전 인코더 로드"""
        try:
            # SigLIP 모델 로드 시도
            siglip_path = self._config.siglip_model_path
            if not Path(siglip_path).exists():
                self._logger.warning(
                    f"SigLIP 모델 없음: {siglip_path} — VLA 비전 기능 비활성화"
                )
                return

            # VLA Bridge가 연결되어 있으면 비전 인코더 위임
            if self._vla_bridge is not None:
                self._logger.info("VLA Bridge를 통해 SigLIP 비전 인코더 사용")
                return

            # 직접 로드 시도 (llama.cpp 멀티모달 확장)
            try:
                from llama_cpp import LlamaClipModel
                self._siglip = LlamaClipModel(siglip_path)
                self._logger.info("SigLIP 비전 인코더 로드 완료")
            except ImportError:
                self._logger.warning(
                    "llama_cpp 멀티모달 확장 없음 — VLA 비전 기능 제한적"
                )
        except Exception as e:
            self._logger.warning(f"SigLIP 로드 오류: {e} — VLA 비전 기능 비활성화")

    # ── V8: LoRA 핫리로드 / LoRA Hot-Reload ──────────────────────────────────

    def hot_reload_lora(self, new_lora_path: str) -> bool:
        """
        V8: LoRA 어댑터 핫리로드 — 재시작 없이 LoRA 교체

        수면 학습이나 연속 학습 후 LoRA 가중치가 업데이트되면
        로봇을 재시작하지 않고 새 LoRA를 로드합니다.

        Args:
            new_lora_path: 새 LoRA 어댑터 파일 경로

        Returns:
            핫리로드 성공 여부
        """
        with self._lora_reload_lock:
            if not Path(new_lora_path).exists():
                self._logger.error(f"LoRA 파일 없음: {new_lora_path}")
                return False

            # 파일 해시로 변경 여부 확인
            new_hash = self._compute_file_hash(new_lora_path)
            if new_hash == self._lora_state.current_hash:
                self._logger.debug("LoRA 변경 없음 — 핫리로드 건너뜀")
                return True

            old_status = self._status
            self._status = ModelStatus.HOT_RELOADING

            try:
                if self._llm is not None:
                    # 기존 LoRA 언로드
                    try:
                        self._llm.lora_adapter = None
                    except Exception:
                        pass

                    # 새 LoRA 로드
                    self._llm.lora_adapter = new_lora_path

                # 상태 업데이트
                self._lora_state.current_path = new_lora_path
                self._lora_state.current_hash = new_hash
                self._lora_state.last_reload_time = time.time()
                self._lora_state.reload_count += 1
                self._metrics.lora_hot_reloads += 1

                self._status = old_status
                self._logger.info(
                    f"LoRA 핫리로드 성공: {new_lora_path} "
                    f"(#{self._lora_state.reload_count})"
                )
                return True

            except Exception as e:
                self._status = ModelStatus.ERROR
                self._logger.error(f"LoRA 핫리로드 실패: {e}")
                # 이전 LoRA로 복구 시도
                try:
                    if self._llm and self._lora_state.current_path:
                        self._llm.lora_adapter = self._lora_state.current_path
                    self._status = old_status
                except Exception:
                    pass
                return False

    def check_lora_update(self) -> bool:
        """
        V8: LoRA 업데이트 확인 — 주기적으로 호출

        Returns:
            업데이트가 감지되고 핫리로드되었으면 True
        """
        if not self._lora_state.current_path:
            return False

        current_hash = self._compute_file_hash(self._lora_state.current_path)
        if current_hash != self._lora_state.current_hash:
            self._logger.info("LoRA 업데이트 감지 — 핫리로드 시작")
            return self.hot_reload_lora(self._lora_state.current_path)

        return False

    def _compute_file_hash(self, filepath: str) -> str:
        """파일 해시 계산 (MD5, 빠른 변경 감지용)"""
        try:
            hasher = hashlib.md5()
            with open(filepath, "rb") as f:
                # 처음 1MB만 해시 (빠른 확인)
                hasher.update(f.read(1024 * 1024))
                f.seek(-min(1024 * 1024, os.path.getsize(filepath)), 2)
                hasher.update(f.read())
            return hasher.hexdigest()
        except Exception:
            return ""

    # ── VRAM 사용량 업데이트 ──────────────────────────────────────────────────

    def _update_vram_usage(self) -> None:
        """VRAM 사용량 업데이트 / Update VRAM usage metrics"""
        try:
            # Jetson UMA 환경에서 메모리 사용량 확인
            with open("/proc/meminfo", "r") as f:
                meminfo = f.read()
            total_kb = 0
            avail_kb = 0
            for line in meminfo.split("\n"):
                if "MemTotal" in line:
                    total_kb = int(line.split()[1])
                elif "MemAvailable" in line:
                    avail_kb = int(line.split()[1])
            if total_kb > 0:
                used_mb = (total_kb - avail_kb) / 1024
                self._metrics.vram_usage_mb = used_mb
                self._metrics.ram_usage_mb = used_mb
        except Exception:
            # 기본 추정치: Q4_K_M + 32768 ctx → ~6GB
            self._metrics.vram_usage_mb = 6144.0
            self._metrics.ram_usage_mb = 6144.0

    # ── 도구 스키마 등록 / Tool Schema Registration ──────────────────────────

    def register_tool_schemas(self, schemas: List[Dict[str, Any]]) -> None:
        """
        Gemma 4 네이티브 툴 콜링 스키마 등록

        Args:
            schemas: 툴 스키마 목록 (Gemma 4 함수 호출 형식)
        """
        self._tool_schemas = schemas
        self._logger.info(f"툴 스키마 {len(schemas)}개 등록 완료")

    # ── V8: 감성 온도 조정 / Emotional Temperature Adjustment ────────────────

    def _adjust_temperature_by_emotion(
        self, base_temperature: float,
    ) -> Tuple[float, EmotionalTone]:
        """
        V8: 감성 상태에 따라 온도 조정

        감성 지능에서 현재 감정 상태를 받아와
        생성 온도를 조정합니다.

        Args:
            base_temperature: 기본 온도

        Returns:
            (조정된 온도, 감성 톤)
        """
        if not self._emotional_intelligence:
            return base_temperature, EmotionalTone.NEUTRAL

        try:
            emotional_state = self._emotional_intelligence.get_current_state()
            tone = emotional_state.get("dominant_tone", "neutral")

            tone_map = {
                "neutral": (1.0, EmotionalTone.NEUTRAL),
                "calm": (0.85, EmotionalTone.CALM),
                "curious": (1.1, EmotionalTone.CURIOUS),
                "excited": (1.25, EmotionalTone.EXCITED),
                "cautious": (0.7, EmotionalTone.CAUTIOUS),
                "empathetic": (0.95, EmotionalTone.EMPATHETIC),
            }

            multiplier, emotional_tone = tone_map.get(
                tone, (1.0, EmotionalTone.NEUTRAL)
            )

            adjusted = base_temperature * multiplier
            adjusted = max(
                EMOTIONAL_TEMPERATURE_MIN,
                min(EMOTIONAL_TEMPERATURE_MAX, adjusted),
            )

            self._current_emotional_tone = emotional_tone
            return adjusted, emotional_tone

        except Exception:
            return base_temperature, EmotionalTone.NEUTRAL

    # ── V8: 메타인지 불확실성 추정 / Metacognition Uncertainty ────────────────

    def _estimate_uncertainty(self, prompt: str, context: Dict) -> float:
        """
        V8: 메타인지를 통한 불확실성 추정

        높은 불확실성 → 생성 시 보수적 접근 (낮은 온도, 더 많은 컨텍스트 요청)

        Args:
            prompt: 입력 프롬프트
            context: 현재 컨텍스트

        Returns:
            불확실성 점수 (0~1)
        """
        if not self._metacognition:
            return 0.0

        try:
            uncertainty = self._metacognition.estimate_uncertainty(
                prompt=prompt,
                context=context,
            )
            return float(uncertainty)
        except Exception:
            return 0.0

    # ── V8: 세계 지식 검색 / World Knowledge Retrieval ──────────────────────

    def _retrieve_world_knowledge(self, query: str) -> Optional[str]:
        """
        V8: 지식 그래프에서 세계 지식 검색

        Args:
            query: 검색 쿼리

        Returns:
            검색된 세계 지식 텍스트 (없으면 None)
        """
        if not self._knowledge_graph:
            return None

        try:
            results = self._knowledge_graph.query(query, top_k=3)
            if not results:
                return None

            knowledge_parts = []
            for result in results:
                fact = result.get("fact", "")
                confidence = result.get("confidence", 0.0)
                if fact and confidence > 0.5:
                    knowledge_parts.append(
                        f"- {fact} (신뢰도: {confidence:.0%})"
                    )

            if knowledge_parts:
                self._metrics.world_knowledge_hits += 1
                return "\n".join(knowledge_parts)

        except Exception as e:
            self._logger.debug(f"세계 지식 검색 오류: {e}")

        return None

    # ── V8: 인과 추론 체인 / Causal Reasoning Chain ─────────────────────────

    def _retrieve_causal_chain(self, query: str) -> Optional[str]:
        """
        V8: 인과 추론에서 인과 체인 검색

        Args:
            query: 검색 쿼리

        Returns:
            인과 체인 텍스트 (없으면 None)
        """
        if not self._causal_reasoning:
            return None

        try:
            chain = self._causal_reasoning.get_causal_chain(query)
            if chain and len(chain) > 1:
                self._metrics.causal_reasoning_uses += 1
                chain_text = " → ".join(
                    f"{step.get('cause', '?')} → {step.get('effect', '?')}"
                    for step in chain
                )
                return f"인과 체인: {chain_text}"

        except Exception as e:
            self._logger.debug(f"인과 추론 검색 오류: {e}")

        return None

    # ── V8.5: 물리 추론 / Physical Reasoning ────────────────────────────────

    def _apply_physical_reasoning(
        self, task_description: str, scene_context: Optional[str] = None,
    ) -> Optional[str]:
        """
        V8.5: 물리 추론 엔진을 통한 물리적 안전성 및 실현 가능성 평가

        작업의 물리적 측면을 분석하여:
        - 중력, 마찰, 무게 분포 등 물리적 요소 평가
        - 동작의 실현 가능성 검증
        - 안전 여유폭 계산
        - 위험 요소 식별

        Args:
            task_description: 수행할 작업 설명
            scene_context: 현재 장면 컨텍스트

        Returns:
            물리 추론 결과 텍스트 (없으면 None)
        """
        if not self._physical_reasoning_engine:
            return None

        try:
            reasoning_result = self._physical_reasoning_engine.evaluate(
                task=task_description,
                scene_context=scene_context or "",
                safety_margin=PHYSICAL_SAFETY_MARGIN,
                reasoning_level=self._physical_reasoning_level.value,
            )

            if reasoning_result:
                self._metrics.physical_reasoning_uses += 1
                parts = []

                # 물리적 실현 가능성
                feasibility = reasoning_result.get("feasibility", "unknown")
                parts.append(f"물리적 실현 가능성: {feasibility}")

                # 식별된 위험 요소
                risks = reasoning_result.get("risks", [])
                if risks:
                    parts.append("식별된 위험 요소:")
                    for risk in risks:
                        parts.append(f"  - {risk.get('description', '?')} (수준: {risk.get('level', '?')})")

                # 추천 안전 조치
                safety_measures = reasoning_result.get("safety_measures", [])
                if safety_measures:
                    parts.append("추천 안전 조치:")
                    for measure in safety_measures:
                        parts.append(f"  - {measure}")

                # 물리적 제약 사항
                constraints = reasoning_result.get("constraints", [])
                if constraints:
                    parts.append("물리적 제약 사항:")
                    for constraint in constraints:
                        parts.append(f"  - {constraint}")

                # 전체 신뢰도
                confidence = reasoning_result.get("confidence", 0.0)
                parts.append(f"물리 추론 신뢰도: {confidence:.0%}")

                if confidence < PHYSICAL_REASONING_CONFIDENCE_THRESHOLD:
                    parts.append(
                        "⚠️ 물리 추론 신뢰도가 낮습니다. "
                        "추가 확인이나 인간 승인이 필요할 수 있습니다."
                    )

                return "\n".join(parts)

        except Exception as e:
            self._logger.debug(f"물리 추론 오류: {e}")

        return None

    # ── V8.5: 자율 작업 분해 / Autonomous Task Decomposition ──────────────────

    def _decompose_task(
        self, goal: str, context: Optional[Dict] = None,
    ) -> Optional[TaskDecomposition]:
        """
        V8.5: AI가 고수준 목표를 하위 작업으로 자율 분해

        하드코딩된 분해 규칙을 사용하지 않고,
        AI가 상황에 맞게 스스로 작업을 분해합니다.

        Args:
            goal: 고수준 목표
            context: 추가 컨텍스트 (센서, 메모리 등)

        Returns:
            TaskDecomposition: 분해된 작업 구조
        """
        # 외부 자율 작업 계획기가 연결된 경우 위임
        if self._autonomous_task_planner:
            try:
                plan = self._autonomous_task_planner.decompose(
                    goal=goal,
                    context=context or {},
                    mode=self._task_decomposition_mode.value,
                    max_depth=TASK_DECOMPOSITION_MAX_DEPTH,
                    max_steps=TASK_DECOMPOSITION_MAX_STEPS,
                    safety_margin=PHYSICAL_SAFETY_MARGIN,
                )
                if plan:
                    self._metrics.task_decompositions += 1
                    return plan
            except Exception as e:
                self._logger.debug(f"자율 작업 계획기 오류: {e}")

        # AI 직접 분해 (프롬프트 기반)
        decomposition_prompt = (
            f"다음 목표를 수행 가능한 단계로 분해하세요:\n"
            f"목표: {goal}\n\n"
            f"각 단계에 대해 다음을 포함하세요:\n"
            f"- action: 수행할 동작\n"
            f"- reasoning: 왜 이 동작을 선택했는지 (AI가 스스로 판단)\n"
            f"- risk: 위험 수준 (low/medium/high/critical)\n"
            f"- preconditions: 실행 전 필수 조건\n"
            f"- failure_recovery: 실패 시 복구 방법\n\n"
            f"절대 하드코딩된 단계를 사용하지 마세요. "
            f"상황과 컨텍스트를 고려하여 매번 새로 분석하세요.\n"
        )

        if context:
            sensor_ctx = context.get("sensor", "")
            memory_ctx = context.get("memory", "")
            if sensor_ctx:
                decomposition_prompt += f"\n현재 센서 상태: {sensor_ctx}"
            if memory_ctx:
                decomposition_prompt += f"\n관련 기억: {memory_ctx}"

        try:
            result = self.generate(
                user_input=decomposition_prompt,
                temperature=0.4,  # 작업 분해 시 낮은 온도로 일관성 유지
                max_tokens=2048,
                enable_world_knowledge=True,
                enable_causal_reasoning=True,
                enable_metacognition=True,
                enable_physical_reasoning=True,     # V8.5
                enable_task_decomposition=False,     # 무한 재귀 방지
            )

            if result.text:
                self._metrics.task_decompositions += 1

                # AI 생성 결과를 TaskDecomposition으로 파싱
                decomposition = TaskDecomposition(
                    goal=goal,
                    requires_approval=False,
                    physical_reasoning_applied=result.physical_reasoning_applied,
                )

                # 작업 분해 결과에서 위험 수준 확인
                text_lower = result.text.lower()
                if "critical" in text_lower or "위험" in result.text:
                    decomposition.risk_level = "high"
                    decomposition.requires_approval = TASK_APPROVAL_REQUIRED

                # JSON 형식 파싱 시도
                try:
                    json_start = result.text.find("{")
                    json_end = result.text.rfind("}") + 1
                    if json_start >= 0 and json_end > json_start:
                        plan_json = json.loads(result.text[json_start:json_end])
                        if "steps" in plan_json:
                            decomposition.subtasks = plan_json["steps"]
                        if "dependencies" in plan_json:
                            decomposition.dependencies = [
                                tuple(d) for d in plan_json["dependencies"]
                            ]
                except (json.JSONDecodeError, ValueError):
                    # JSON 파싱 실패 시 텍스트를 그대로 사용
                    decomposition.subtasks = [
                        {"description": result.text, "risk": "medium"}
                    ]

                # 교차 도메인 전이 확인
                if self._cross_domain_skill_transfer:
                    transfers = self._find_cross_domain_transfers(goal)
                    decomposition.cross_domain_transfers = transfers

                return decomposition

        except Exception as e:
            self._logger.error(f"작업 분해 오류: {e}")

        return None

    # ── V8.5: 교차 도메인 스킬 전이 / Cross-Domain Skill Transfer ────────────

    def _find_cross_domain_transfers(self, task_description: str) -> List[str]:
        """
        V8.5: 교차 도메인 스킬 전이 — 새 작업에 적용 가능한 기존 스킬 검색

        한 영역에서 학습한 스킬이 새로운 작업에 전이 가능한지 확인합니다.
        전이는 AI가 판단하며 하드코딩되지 않습니다.

        Args:
            task_description: 새 작업 설명

        Returns:
            전이 가능한 스킬 목록
        """
        if not self._cross_domain_skill_transfer:
            return []

        try:
            transfer_results = self._cross_domain_skill_transfer.find_transferable_skills(
                target_task=task_description,
                min_similarity=CROSS_DOMAIN_MIN_SIMILARITY,
            )

            if transfer_results:
                self._metrics.cross_domain_transfers += len(transfer_results)
                return [
                    f"{t['skill']} (출처: {t.get('source_domain', '?')}, "
                    f"유사도: {t.get('similarity', 0):.0%})"
                    for t in transfer_results
                ]

        except Exception as e:
            self._logger.debug(f"교차 도메인 전이 검색 오류: {e}")

        return []

    # ── V8.5: VLA 추론 / VLA Inference ───────────────────────────────────────

    def generate_vla(
        self,
        user_command: str,
        observation: Optional[VLAObservation] = None,
        image: Optional[np.ndarray] = None,
        depth: Optional[np.ndarray] = None,
        sensor_context: Optional[str] = None,
        memory_context: Optional[str] = None,
        safety_check: bool = True,
    ) -> GenerationResult:
        """
        V8.5: VLA (Vision-Language-Action) 추론 — 이미지+명령 → 로봇 동작

        카메라 이미지와 자연어 명령을 입력받아
        로봇이 수행할 동작 궤적을 생성합니다.
        물리 안전 검증을 거쳐 안전한 동작만 출력합니다.

        Args:
            user_command: 사용자 자연어 명령
            observation: VLA 관측 데이터 (이미지, 깊이, 감지 결과)
            image: RGB 이미지 (직접 입력, observation 없을 시 사용)
            depth: 깊이 맵 (직접 입력)
            sensor_context: 센서 상태 요약
            memory_context: 메모리에서 회상한 정보
            safety_check: 물리 안전 검증 수행 여부

        Returns:
            GenerationResult: VLA 액션 플랜 포함
        """
        if self._status != ModelStatus.READY:
            return GenerationResult(
                text="[오류] 모델이 준비되지 않았습니다.",
                finish_reason="error",
            )

        # 관측 데이터 준비
        if observation is None:
            observation = VLAObservation(
                image=image,
                depth=depth,
                description="",
            )

        start_time = time.time()

        # VLA Bridge가 연결된 경우 위임
        if self._vla_bridge:
            try:
                action_plan = self._vla_bridge.process(
                    observation=observation,
                    command=user_command,
                    safety_check=safety_check,
                )
                if action_plan:
                    self._metrics.vla_inferences += 1
                    vla_latency = (time.time() - start_time) * 1000
                    self._metrics.avg_vla_latency_ms = (
                        (self._metrics.avg_vla_latency_ms * (self._metrics.vla_inferences - 1)
                         + vla_latency) / self._metrics.vla_inferences
                    )

                    result = GenerationResult(
                        text=f"VLA 동작 생성 완료 — 신뢰도: {action_plan.confidence:.0%}, "
                             f"안전 점수: {action_plan.safety_score:.0%}",
                        vla_action_plan=action_plan,
                        safety_layer_triggered=8 if action_plan.safety_score < 0.5 else 0,
                    )
                    return result

            except Exception as e:
                self._logger.warning(f"VLA Bridge 오류, 내부 VLA로 폴백: {e}")

        # 내부 VLA 처리 (VLA Bridge 없을 시)
        with self._lock:
            self._status = ModelStatus.VLA_PROCESSING

        try:
            # 이미지를 텍스트 설명으로 변환 (비전 인코더가 없는 경우)
            visual_context = ""
            if observation.description:
                visual_context = f"\n[시각 관측]\n{observation.description}"
            elif observation.object_detections:
                objects_str = ", ".join(
                    f"{d.get('label', '?')}({d.get('confidence', 0):.0%})"
                    for d in observation.object_detections
                )
                visual_context = f"\n[시각 관측]\n감지된 물체: {objects_str}"

            # VLA 프롬프트 구성
            vla_prompt = (
                f"다음 명령을 로봇 동작으로 변환하세요:\n"
                f"명령: {user_command}\n\n"
                f"동작 궤적을 생성하고, 각 단계의 추론 과정을 설명하세요.\n"
                f"동작은 물리적으로 안전하고 실현 가능해야 합니다.\n"
            )

            # 물리 추론 적용
            physical_reasoning = None
            if self._physical_reasoning_engine:
                physical_reasoning = self._apply_physical_reasoning(
                    user_command, visual_context
                )

            # 작업 분해 수행
            task_decomposition = self._decompose_task(
                user_command,
                context={"sensor": sensor_context, "memory": memory_context},
            )

            # VLA 생성
            result = self.generate(
                user_input=vla_prompt,
                sensor_context=f"{sensor_context or ''}{visual_context}",
                memory_context=memory_context,
                temperature=0.3,  # VLA 동작 생성 시 낮은 온도
                max_tokens=2048,
                enable_physical_reasoning=True,
            )

            # VLA 액션 플랜 구성
            action_plan = VLAActionPlan(
                confidence=0.5,  # 기본 신뢰도 (실제 추론 결과에 따라 조정)
                safety_score=1.0,
                reasoning_chain=result.text,
                physical_constraints_checked=physical_reasoning is not None,
            )

            # 물리 안전 검증
            if safety_check and physical_reasoning:
                if "위험" in (physical_reasoning or "") or "critical" in (physical_reasoning or "").lower():
                    action_plan.safety_score = 0.3
                    action_plan.requires_human_approval = True
                    result.safety_layer_triggered = 8
                elif "주의" in (physical_reasoning or "") or "caution" in (physical_reasoning or "").lower():
                    action_plan.safety_score = 0.7
                    action_plan.requires_human_approval = TASK_APPROVAL_REQUIRED

            # 작업 분해 결과 연결
            if task_decomposition:
                action_plan.task_decomposition = task_decomposition.subtasks
                if task_decomposition.requires_approval:
                    action_plan.requires_human_approval = True

            result.vla_action_plan = action_plan
            result.task_decomposition = task_decomposition
            result.physical_reasoning_applied = physical_reasoning is not None

            # 메트릭 업데이트
            self._metrics.vla_inferences += 1
            vla_latency = (time.time() - start_time) * 1000
            self._metrics.avg_vla_latency_ms = (
                (self._metrics.avg_vla_latency_ms * (self._metrics.vla_inferences - 1)
                 + vla_latency) / self._metrics.vla_inferences
            )

            return result

        except Exception as e:
            self._logger.error(f"VLA 추론 오류: {e}")
            return GenerationResult(
                text=f"[오류] VLA 추론 실패: {str(e)}",
                finish_reason="error",
            )
        finally:
            with self._lock:
                self._status = ModelStatus.READY

    # ── 프롬프트 구성 / Prompt Construction ───────────────────────────────────

    def _build_prompt(
        self,
        user_input: str,
        sensor_context: Optional[str] = None,
        memory_context: Optional[str] = None,
        world_knowledge: Optional[str] = None,        # V8
        causal_chain: Optional[str] = None,            # V8
        uncertainty_context: Optional[str] = None,     # V8
        physical_reasoning: Optional[str] = None,      # V8.5
        cross_domain_context: Optional[str] = None,    # V8.5
        vla_context: Optional[str] = None,             # V8.5
    ) -> str:
        """
        Gemma 4용 프롬프트 구성 — V8.5: 세계지식 + 인과 + 메타인지 + 물리추론 + VLA 포함

        시스템 프롬프트 + 도구 정의 + 컨텍스트 + 대화 이력 + 사용자 입력
        """
        parts = [self._system_prompt]

        # 도구 정의 추가
        if self._tool_schemas:
            tools_json = json.dumps(self._tool_schemas, ensure_ascii=False, indent=2)
            parts.append(f"\n사용 가능한 도구:\n```json\n{tools_json}\n```")

        # 센서 컨텍스트 추가
        if sensor_context:
            parts.append(f"\n[현재 센서 상태]\n{sensor_context}")

        # 메모리 컨텍스트 추가
        if memory_context:
            parts.append(f"\n[관련 기억]\n{memory_context}")

        # V8: 세계 지식 컨텍스트 추가
        if world_knowledge:
            parts.append(f"\n[세계 지식]\n{world_knowledge}")

        # V8: 인과 추론 체인 추가
        if causal_chain:
            parts.append(f"\n[인과 추론]\n{causal_chain}")

        # V8: 메타인지 불확실성 컨텍스트 추가
        if uncertainty_context:
            parts.append(f"\n[자기 인식]\n{uncertainty_context}")

        # V8.5: 물리 추론 컨텍스트 추가
        if physical_reasoning:
            parts.append(f"\n[물리 추론]\n{physical_reasoning}")

        # V8.5: 교차 도메인 전이 컨텍스트 추가
        if cross_domain_context:
            parts.append(f"\n[교차 도메인 전이]\n{cross_domain_context}")

        # V8.5: VLA 시각 컨텍스트 추가
        if vla_context:
            parts.append(f"\n[VLA 시각 컨텍스트]\n{vla_context}")

        # 대화 이력 추가 (V8.5: 최근 30개로 확장)
        for msg in self._conversation_history[-30:]:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "user":
                parts.append(f"\n사용자: {content}")
            elif role == "assistant":
                parts.append(f"\n지훈: {content}")

        # 사용자 입력
        parts.append(f"\n사용자: {user_input}")
        parts.append("\n지훈:")

        return "\n".join(parts)

    # ── 기본 생성 / Generate ─────────────────────────────────────────────────

    def generate(
        self,
        user_input: str,
        sensor_context: Optional[str] = None,
        memory_context: Optional[str] = None,
        max_tokens: int = DEFAULT_MAX_NEW_TOKENS,
        temperature: float = DEFAULT_TEMPERATURE,
        top_p: float = DEFAULT_TOP_P,
        top_k: int = DEFAULT_TOP_K,
        repeat_penalty: float = DEFAULT_REPEAT_PENALTY,
        enable_world_knowledge: bool = True,    # V8
        enable_causal_reasoning: bool = True,    # V8
        enable_metacognition: bool = True,       # V8
        enable_physical_reasoning: bool = True,  # V8.5
        enable_task_decomposition: bool = False, # V8.5 (기본 비활성, 명시적 요청 시만)
        enable_cross_domain: bool = True,        # V8.5
    ) -> GenerationResult:
        """
        Gemma 4로 텍스트 생성 (동기) — V8.5: 메타인지/감성/세계지식/인과/물리추론/VLA 지원

        Args:
            user_input: 사용자 입력 텍스트
            sensor_context: 센서 상태 요약
            memory_context: 메모리에서 회상한 정보
            max_tokens: 최대 생성 토큰 수
            temperature: 샘플링 온도
            top_p: Top-p (nucleus sampling)
            top_k: Top-k
            repeat_penalty: 반복 페널티
            enable_world_knowledge: 세계 지식 활성화 (V8)
            enable_causal_reasoning: 인과 추론 활성화 (V8)
            enable_metacognition: 메타인지 활성화 (V8)
            enable_physical_reasoning: 물리 추론 활성화 (V8.5)
            enable_task_decomposition: 자율 작업 분해 활성화 (V8.5)
            enable_cross_domain: 교차 도메인 전이 활성화 (V8.5)

        Returns:
            GenerationResult: 생성 결과 (텍스트 + 툴콜 + 메트릭 + V8.5 정보)
        """
        if self._status != ModelStatus.READY:
            return GenerationResult(
                text="[오류] 모델이 준비되지 않았습니다.",
                finish_reason="error",
            )

        with self._lock:
            self._status = ModelStatus.INFERRING

        start_time = time.time()
        result = GenerationResult()

        try:
            # V8: 세계 지식 검색
            world_knowledge = None
            if enable_world_knowledge:
                world_knowledge = self._retrieve_world_knowledge(user_input)

            # V8: 인과 추론 체인 검색
            causal_chain = None
            if enable_causal_reasoning:
                causal_chain = self._retrieve_causal_chain(user_input)

            # V8: 메타인지 불확실성 추정
            uncertainty = 0.0
            uncertainty_context = None
            if enable_metacognition:
                uncertainty = self._estimate_uncertainty(
                    user_input, {"sensor": sensor_context, "memory": memory_context}
                )
                if uncertainty > 0.5:
                    uncertainty_context = (
                        f"이 질문에 대한 나의 불확실성: {uncertainty:.0%}. "
                        f"확실하지 않은 부분은 솔직하게 표현하세요."
                    )

            # V8.5: 물리 추론
            physical_reasoning = None
            if enable_physical_reasoning:
                physical_reasoning = self._apply_physical_reasoning(
                    user_input, sensor_context
                )

            # V8.5: 교차 도메인 전이
            cross_domain_context = None
            if enable_cross_domain:
                transfers = self._find_cross_domain_transfers(user_input)
                if transfers:
                    cross_domain_context = (
                        "다음 스킬이 새 작업에 전이 가능합니다:\n"
                        + "\n".join(f"  - {t}" for t in transfers)
                    )
                    result.cross_domain_transfers = transfers

            # V8.5: 자율 작업 분해
            if enable_task_decomposition:
                task_decomp = self._decompose_task(
                    user_input,
                    context={"sensor": sensor_context, "memory": memory_context},
                )
                if task_decomp:
                    result.task_decomposition = task_decomp

            # V8: 감성 온도 조정
            adjusted_temperature, emotional_tone = self._adjust_temperature_by_emotion(
                temperature
            )

            # 불확실성이 높으면 온도 낮춤 (보수적 생성)
            if uncertainty > 0.7:
                adjusted_temperature *= 0.8

            # 물리적 위험이 감지되면 온도 더 낮춤 (V8.5)
            if physical_reasoning and ("위험" in physical_reasoning or "critical" in physical_reasoning.lower()):
                adjusted_temperature *= 0.6

            # 프롬프트 구성
            prompt = self._build_prompt(
                user_input, sensor_context, memory_context,
                world_knowledge=world_knowledge,
                causal_chain=causal_chain,
                uncertainty_context=uncertainty_context,
                physical_reasoning=physical_reasoning,        # V8.5
                cross_domain_context=cross_domain_context,    # V8.5
            )

            if self._llm is not None:
                result = self._generate_llama_cpp(
                    prompt, max_tokens, adjusted_temperature, top_p, top_k, repeat_penalty
                )
            else:
                # REST API 백업 모드
                result = self._generate_rest_api(
                    prompt, max_tokens, adjusted_temperature, top_p, top_k
                )

            # 대화 이력 업데이트
            self._conversation_history.append({"role": "user", "content": user_input})
            self._conversation_history.append({"role": "assistant", "content": result.text})

            # V8: 결과에 추가 정보 기록
            result.uncertainty_score = uncertainty
            result.emotional_tone = emotional_tone.value
            result.world_knowledge_used = world_knowledge is not None
            result.causal_chain_used = causal_chain is not None
            result.lora_version = self._lora_state.current_hash[:8]

            # V8.5: 결과에 추가 정보 기록
            result.physical_reasoning_applied = physical_reasoning is not None
            if not result.cross_domain_transfers and cross_domain_context:
                result.cross_domain_transfers = []

            # 메트릭 업데이트
            result.total_latency_ms = (time.time() - start_time) * 1000
            self._update_metrics(result)

        except Exception as e:
            self._logger.error(f"생성 오류: {e}")
            result = GenerationResult(
                text=f"[오류] 생성 실패: {str(e)}",
                finish_reason="error",
            )
        finally:
            with self._lock:
                self._status = ModelStatus.READY

        return result

    def _generate_llama_cpp(
        self,
        prompt: str,
        max_tokens: int,
        temperature: float,
        top_p: float,
        top_k: int,
        repeat_penalty: float,
    ) -> GenerationResult:
        """llama.cpp로 생성 / Generate via llama.cpp"""
        response = self._llm(
            prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            repeat_penalty=repeat_penalty,
            stop=["사용자:", "<|end|>", "<|eot_id|>"],
        )

        result = GenerationResult()
        result.text = response["choices"][0]["text"].strip()
        result.prompt_tokens = response["usage"]["prompt_tokens"]
        result.completion_tokens = response["usage"]["completion_tokens"]
        result.total_tokens = result.prompt_tokens + result.completion_tokens

        # 첫 토큰 지연 추정 (프롬프트 토큰 수 기반)
        result.first_token_latency_ms = (
            result.prompt_tokens * 0.02  # ~20μs/token prefill 추정
        )
        # 초당 토큰 속도 계산
        if result.completion_tokens > 0:
            result.tokens_per_second = result.completion_tokens / max(
                result.completion_tokens * 0.125, 0.001  # 8 tok/s 역산
            )

        # 툴 콜 파싱
        result.tool_calls = self._parse_tool_calls(result.text)
        if result.tool_calls:
            result.finish_reason = "tool_call"

        return result

    def _generate_rest_api(
        self,
        prompt: str,
        max_tokens: int,
        temperature: float,
        top_p: float,
        top_k: int,
    ) -> GenerationResult:
        """REST API로 생성 (백업) / Generate via REST API fallback"""
        result = GenerationResult(
            text="[REST API 모드] 현재 연결된 추론 서버가 없습니다.",
            finish_reason="error",
        )
        return result

    # ── 툴 콜링 생성 / Generate with Tools ──────────────────────────────────

    def generate_with_tools(
        self,
        user_input: str,
        sensor_context: Optional[str] = None,
        memory_context: Optional[str] = None,
        max_tools: int = 3,
        timeout_s: float = 10.0,
    ) -> GenerationResult:
        """
        도구 호출이 포함된 생성

        한국어 명령을 분석하여 적절한 도구 호출을 생성합니다.
        예: "앞으로 1미터 가" → wheel_move(speed=0.5, duration=2.0)

        V8.5: 세계 지식, 인과 추론, 물리 추론을 활용하여 더 정확한 도구 선택
        """
        # 툴 콜링에 최적화된 프롬프트 구성
        tool_prompt = (
            f"{user_input}\n\n"
            "위 명령을 수행하기 위해 필요한 도구를 JSON 형식으로 호출하세요.\n"
            f"최대 {max_tools}개의 도구를 동시에 호출할 수 있습니다.\n"
            "형식: {\"name\": \"tool_name\", \"arguments\": {\"param\": value}}\n"
        )

        result = self.generate(
            user_input=tool_prompt,
            sensor_context=sensor_context,
            memory_context=memory_context,
            temperature=0.3,  # 툴 콜링 시 낮은 온도
            max_tokens=256,
            enable_world_knowledge=True,
            enable_causal_reasoning=True,
            enable_physical_reasoning=True,     # V8.5: 물리 추론 활성화
        )

        # 툴 콜 수 제한
        if len(result.tool_calls) > max_tools:
            self._logger.warning(
                f"툴 콜 {len(result.tool_calls)}개 → {max_tools}개로 제한"
            )
            result.tool_calls = result.tool_calls[:max_tools]

        return result

    # ── 스트리밍 생성 / Stream Generate ──────────────────────────────────────

    def stream_generate(
        self,
        user_input: str,
        sensor_context: Optional[str] = None,
        memory_context: Optional[str] = None,
        max_tokens: int = DEFAULT_MAX_NEW_TOKENS,
        temperature: float = DEFAULT_TEMPERATURE,
        top_p: float = DEFAULT_TOP_P,
    ) -> Generator[str, None, None]:
        """
        스트리밍 토큰 생성 (제너레이터)

        토큰이 생성될 때마다 yield하여 실시간 출력이 가능합니다.

        Args:
            user_input: 사용자 입력
            sensor_context: 센서 컨텍스트
            memory_context: 메모리 컨텍스트
            max_tokens: 최대 토큰 수
            temperature: 샘플링 온도
            top_p: Top-p

        Yields:
            str: 생성된 토큰 (한 글자 단위)
        """
        if self._status != ModelStatus.READY or self._llm is None:
            yield "[오류] 모델이 준비되지 않았습니다."
            return

        # V8: 감성 온도 조정
        adjusted_temperature, _ = self._adjust_temperature_by_emotion(temperature)

        # V8: 세계 지식 검색
        world_knowledge = self._retrieve_world_knowledge(user_input)

        # V8.5: 물리 추론
        physical_reasoning = self._apply_physical_reasoning(user_input, sensor_context)

        prompt = self._build_prompt(
            user_input, sensor_context, memory_context,
            world_knowledge=world_knowledge,
            physical_reasoning=physical_reasoning,
        )

        try:
            for chunk in self._llm(
                prompt,
                max_tokens=max_tokens,
                temperature=adjusted_temperature,
                top_p=top_p,
                stop=["사용자:", "<|end|>", "<|eot_id|>"],
                stream=True,
            ):
                token = chunk["choices"][0]["text"]
                yield token

        except Exception as e:
            self._logger.error(f"스트리밍 생성 오류: {e}")
            yield f"\n[오류] {str(e)}"

    async def stream_generate_async(
        self,
        user_input: str,
        sensor_context: Optional[str] = None,
        memory_context: Optional[str] = None,
        max_tokens: int = DEFAULT_MAX_NEW_TOKENS,
        temperature: float = DEFAULT_TEMPERATURE,
        top_p: float = DEFAULT_TOP_P,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        """
        V8.5: 비동기 스트리밍 토큰 생성

        동기 stream_generate를 비동기 컨텍스트에서 사용할 수 있도록 래핑합니다.
        V8.5에서 잘린 메서드를 완전히 재구현했습니다.

        Args:
            user_input: 사용자 입력
            sensor_context: 센서 컨텍스트
            memory_context: 메모리 컨텍스트
            max_tokens: 최대 토큰 수
            temperature: 샘플링 온도
            top_p: Top-p
            **kwargs: 추가 매개변수 (V8.5: enable_physical_reasoning 등)

        Yields:
            str: 생성된 토큰
        """
        if self._status != ModelStatus.READY or self._llm is None:
            yield "[오류] 모델이 준비되지 않았습니다."
            return

        # 감성 온도 조정
        adjusted_temperature, _ = self._adjust_temperature_by_emotion(temperature)

        # 세계 지식 검색 (비동기로 실행할 수 있지만 여기서는 동기 호출)
        world_knowledge = await asyncio.to_thread(
            self._retrieve_world_knowledge, user_input
        )

        # 물리 추론 (비동기)
        physical_reasoning = None
        if kwargs.get("enable_physical_reasoning", True):
            physical_reasoning = await asyncio.to_thread(
                self._apply_physical_reasoning, user_input, sensor_context
            )

        # 프롬프트 구성
        prompt = self._build_prompt(
            user_input, sensor_context, memory_context,
            world_knowledge=world_knowledge,
            physical_reasoning=physical_reasoning,
        )

        # 비동기 루프에서 스트리밍 생성
        loop = asyncio.get_event_loop()

        def _sync_stream() -> Generator[str, None, None]:
            """동기 스트리밍을 별도 함수로 분리"""
            try:
                for chunk in self._llm(
                    prompt,
                    max_tokens=max_tokens,
                    temperature=adjusted_temperature,
                    top_p=top_p,
                    stop=["사용자:", "<|end|>", "<|eot_id|>"],
                    stream=True,
                ):
                    token = chunk["choices"][0]["text"]
                    yield token
            except Exception as e:
                self._logger.error(f"비동기 스트리밍 생성 오류: {e}")
                yield f"\n[오류] {str(e)}"

        # 동기 제너레이터를 비동기로 변환
        for token in _sync_stream():
            # 다른 비동기 작업에 양보
            await asyncio.sleep(0)
            yield token

    # ── 툴 콜 파싱 / Tool Call Parsing ───────────────────────────────────────

    def _parse_tool_calls(self, text: str) -> List[Dict[str, Any]]:
        """툴 콜 JSON 파싱 / Parse tool call JSON from generated text"""
        tool_calls = []

        # JSON 블록 찾기
        try:
            # ```json ... ``` 형식
            import re
            json_blocks = re.findall(r'```json\s*(.*?)\s*```', text, re.DOTALL)
            for block in json_blocks:
                try:
                    parsed = json.loads(block)
                    if isinstance(parsed, dict) and "name" in parsed:
                        tool_calls.append(parsed)
                    elif isinstance(parsed, list):
                        for item in parsed:
                            if isinstance(item, dict) and "name" in item:
                                tool_calls.append(item)
                except json.JSONDecodeError:
                    continue

            # 직접 JSON 객체 찾기 (```json``` 없이)
            if not tool_calls:
                # {"name": ...} 패턴 찾기
                brace_pattern = r'\{[^{}]*"name"\s*:\s*"[^"]*"[^{}]*\}'
                matches = re.findall(brace_pattern, text)
                for match in matches:
                    try:
                        parsed = json.loads(match)
                        if "name" in parsed:
                            tool_calls.append(parsed)
                    except json.JSONDecodeError:
                        continue

        except Exception as e:
            self._logger.debug(f"툴 콜 파싱 오류: {e}")

        return tool_calls

    # ── 메트릭 업데이트 / Metrics Update ──────────────────────────────────────

    def _update_metrics(self, result: GenerationResult) -> None:
        """성능 메트릭 업데이트 / Update performance metrics"""
        self._metrics.total_inferences += 1
        self._metrics.total_tokens_generated += result.completion_tokens

        # 첫 토큰 지연 업데이트
        if result.first_token_latency_ms > 0:
            self._first_token_latencies.append(result.first_token_latency_ms)
            n = len(self._first_token_latencies)
            self._metrics.avg_first_token_ms = (
                sum(self._first_token_latencies) / n
            )
            sorted_latencies = sorted(self._first_token_latencies)
            p95_idx = min(int(n * 0.95), n - 1)
            p99_idx = min(int(n * 0.99), n - 1)
            self._metrics.p95_first_token_ms = sorted_latencies[p95_idx]
            self._metrics.p99_first_token_ms = sorted_latencies[p99_idx]

        # 초당 토큰 속도 업데이트
        if result.tokens_per_second > 0:
            self._tokens_per_sec_history.append(result.tokens_per_second)
            self._metrics.avg_tokens_per_sec = (
                sum(self._tokens_per_sec_history) / len(self._tokens_per_sec_history)
            )
            self._metrics.peak_tokens_per_sec = max(
                self._metrics.peak_tokens_per_sec, result.tokens_per_second
            )

        # V8: 불확실성 이력 업데이트
        if result.uncertainty_score > 0:
            self._uncertainty_history.append(result.uncertainty_score)
            self._metrics.avg_uncertainty = (
                sum(self._uncertainty_history) / len(self._uncertainty_history)
            )

        # V8.5: 안전 레이어 트리거 기록
        if result.safety_layer_triggered > 0:
            layer = result.safety_layer_triggered
            self._metrics.safety_layer_triggers[layer] = (
                self._metrics.safety_layer_triggers.get(layer, 0) + 1
            )

    # ── 상태 조회 / Status Query ─────────────────────────────────────────────

    @property
    def status(self) -> ModelStatus:
        """현재 모델 상태"""
        return self._status

    @property
    def metrics(self) -> PerformanceMetrics:
        """성능 메트릭"""
        return self._metrics

    @property
    def lora_state(self) -> LoRAState:
        """LoRA 상태"""
        return self._lora_state

    def get_status_summary(self) -> Dict[str, Any]:
        """V8.5: 전체 상태 요약 반환"""
        return {
            "version": "V8.5.5",
            "status": self._status.value,
            "model_loaded": self._llm is not None,
            "siglip_loaded": self._siglip is not None,
            "vla_enabled": self._config.vla_enabled,
            "context_window": self._config.n_ctx,
            "lora_version": self._lora_state.current_hash[:8],
            "total_inferences": self._metrics.total_inferences,
            "vla_inferences": self._metrics.vla_inferences,
            "task_decompositions": self._metrics.task_decompositions,
            "physical_reasoning_uses": self._metrics.physical_reasoning_uses,
            "cross_domain_transfers": self._metrics.cross_domain_transfers,
            "avg_first_token_ms": self._metrics.avg_first_token_ms,
            "avg_tokens_per_sec": self._metrics.avg_tokens_per_sec,
            "safety_layer_triggers": dict(self._metrics.safety_layer_triggers),
            "connected_systems": {
                "metacognition": self._metacognition is not None,
                "emotional_intelligence": self._emotional_intelligence is not None,
                "knowledge_graph": self._knowledge_graph is not None,
                "causal_reasoning": self._causal_reasoning is not None,
                "vla_bridge": self._vla_bridge is not None,
                "physical_reasoning_engine": self._physical_reasoning_engine is not None,
                "cross_domain_skill_transfer": self._cross_domain_skill_transfer is not None,
                "autonomous_task_planner": self._autonomous_task_planner is not None,
            },
        }

    def clear_conversation(self) -> None:
        """대화 이력 초기화 / Clear conversation history"""
        self._conversation_history.clear()
        self._logger.info("대화 이력 초기화 완료")


# ──────────────────────────────────────────────────────────────────────────────
# 편의 함수 / Convenience Functions
# ──────────────────────────────────────────────────────────────────────────────

def create_inference_engine(
    model_path: Optional[str] = None,
    lora_path: Optional[str] = None,
    vla_enabled: bool = True,
    n_ctx: int = DEFAULT_CONTEXT_TOKENS,
) -> Gemma4Inference:
    """
    V8.5: 추론 엔진 팩토리 함수

    기본 설정으로 Gemma 4 V8.5 추론 엔진을 생성합니다.

    Args:
        model_path: GGUF 모델 경로 (기본값: 환경변수 또는 기본 경로)
        lora_path: LoRA 어댑터 경로
        vla_enabled: VLA 기능 활성화
        n_ctx: 컨텍스트 윈도우 크기

    Returns:
        Gemma4Inference 인스턴스
    """
    config = InferenceConfig(
        model_path=model_path or GEMMA4_MODEL_PATH,
        lora_path=lora_path,
        vla_enabled=vla_enabled,
        n_ctx=n_ctx,
    )
    return Gemma4Inference(config)


# ──────────────────────────────────────────────────────────────────────────────
# 모듈 진입점 / Module Entry Point
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    print("지훈 로봇 V8.5 — Gemma 4 E4B 추론 엔진")
    print("=" * 60)
    print(f"버전: V8.5.5")
    print(f"컨텍스트 윈도우: {DEFAULT_CONTEXT_TOKENS} 토큰")
    print(f"최대 생성: {DEFAULT_MAX_NEW_TOKENS} 토큰")
    print(f"VLA 지원: 활성화")
    print(f"자율 작업 분해: 지원")
    print(f"물리 추론: 지원")
    print(f"교차 도메인 전이: 지원")
    print("=" * 60)

    # 추론 엔진 생성 (시뮬레이션 모드)
    engine = create_inference_engine()
    summary = engine.get_status_summary()
    print(f"\n상태 요약:")
    for key, value in summary.items():
        if isinstance(value, dict):
            print(f"  {key}:")
            for k, v in value.items():
                print(f"    {k}: {v}")
        else:
            print(f"  {key}: {value}")
