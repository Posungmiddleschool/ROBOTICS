#!/usr/bin/env python3
"""
rl_policy.py — V8.5 Reinforcement Learning Policy Module
지훈 로봇 물리적 AGI — V8.5 강화학습 정책 모듈

V8.5 had NO actual RL. This module provides real PPO and SAC implementations
for continuous control of the Jihun Robot platform.

V8.5은 실제 RL이 없었다. 이 모듈은 지훈 로봇 플랫폼의 연속 제어를 위한
실제 PPO 및 SAC 구현을 제공한다.

Components / 구성요소:
  1. MLPActorCritic  — Actor-Critic 신경망 (Gaussian policy + value head)
  2. PPOAgent        — Proximal Policy Optimization 에이전트
  3. SACAgent        — Soft Actor-Critic 에이전트
  4. MultiObjectiveReward — 다목적 보상 계산
  5. RLTrainingLoop  — 학습 오케스트레이션
  6. RolloutBuffer   — PPO 롤아웃 데이터 저장
"""

from __future__ import annotations

import logging
import math
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.distributions import Normal, Independent
except ImportError:
    raise ImportError(
        "PyTorch is required for rl_policy.py. "
        "Install with: pip install torch  /  pip install torch로 설치하세요"
    )

# ---------------------------------------------------------------------------
# Constants / 상수
# ---------------------------------------------------------------------------
STATE_DIM = 62       # PhysicalState vector dimension / 물리상태 벡터 차원
ACTION_DIM = 16      # Continuous action parameter dimension / 연속 행동 파라미터 차원
HIDDEN_DIMS = [256, 256, 128]  # Hidden layer sizes / 은닉층 크기
LOG_STD_MIN = -20.0  # Minimum log standard deviation
LOG_STD_MAX = 2.0    # Maximum log standard deviation
EPS = 1e-8           # Numerical stability epsilon / 수치 안정성 엡실론

logger = logging.getLogger("rl_policy")
logger.setLevel(logging.INFO)


# ===========================================================================
# 1. RolloutBuffer — PPO 롤아웃 데이터 저장소
# ===========================================================================

@dataclass
class RolloutBuffer:
    """
    Stores trajectory data collected during a PPO rollout.
    PPO 롤아웃 중 수집된 궤적 데이터를 저장한다.

    Attributes:
        states:     관측 상태 리스트
        actions:    실행된 행동 리스트
        rewards:    수신된 보상 리스트
        values:     Critic이 추정한 가치 리스트
        log_probs:  행동의 로그 확률 리스트
        dones:      에피소드 종료 플래그 리스트
    """
    states: List[np.ndarray] = field(default_factory=list)
    actions: List[np.ndarray] = field(default_factory=list)
    rewards: List[float] = field(default_factory=list)
    values: List[float] = field(default_factory=list)
    log_probs: List[float] = field(default_factory=list)
    dones: List[bool] = field(default_factory=list)

    # Computed after rollout / 롤아웃 후 계산됨
    advantages: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    returns: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    def __len__(self) -> int:
        return len(self.states)

    def insert(
        self,
        state: np.ndarray,
        action: np.ndarray,
        reward: float,
        value: float,
        log_prob: float,
        done: bool,
    ) -> None:
        """Insert one transition into the buffer. / 전이 하나를 버퍼에 삽입."""
        self.states.append(np.asarray(state, dtype=np.float32))
        self.actions.append(np.asarray(action, dtype=np.float32))
        self.rewards.append(float(reward))
        self.values.append(float(value))
        self.log_probs.append(float(log_prob))
        self.dones.append(bool(done))

    def compute_returns_and_advantages(
        self,
        last_value: float,
        gamma: float = 0.99,
        lam: float = 0.95,
    ) -> None:
        """
        Compute returns and GAE advantages (Schulman et al., 2016).
        반환값과 GAE 어드밴티지를 계산한다 (Schulman et al., 2016).

        Args:
            last_value: Value estimate for the last state (bootstrap) / 마지막 상태의 가치 추정
            gamma: Discount factor / 할인 인자
            lam:   GAE lambda / GAE 람다
        """
        n = len(self.rewards)
        self.advantages = np.zeros(n, dtype=np.float32)
        self.returns = np.zeros(n, dtype=np.float32)

        last_gae = 0.0
        next_value = last_value

        for t in reversed(range(n)):
            # 부트스트랩 가치: 다음 상태가 종료 상태면 0 / bootstrap: 0 if next is terminal
            mask = 1.0 - float(self.dones[t])
            delta = self.rewards[t] + gamma * next_value * mask - self.values[t]
            last_gae = delta + gamma * lam * mask * last_gae
            self.advantages[t] = last_gae
            self.returns[t] = last_gae + self.values[t]
            next_value = self.values[t]

        # 정규화 (안정성) / Normalize for stability
        adv_mean = self.advantages.mean()
        adv_std = self.advantages.std() + EPS
        self.advantages = (self.advantages - adv_mean) / adv_std

    def get_tensors(self, device: torch.device) -> Dict[str, torch.Tensor]:
        """Return all buffer data as tensors on the given device. / 버퍼 데이터를 텐서로 반환."""
        return {
            "states": torch.tensor(np.array(self.states), dtype=torch.float32, device=device),
            "actions": torch.tensor(np.array(self.actions), dtype=torch.float32, device=device),
            "old_log_probs": torch.tensor(np.array(self.log_probs), dtype=torch.float32, device=device),
            "advantages": torch.tensor(self.advantages, dtype=torch.float32, device=device),
            "returns": torch.tensor(self.returns, dtype=torch.float32, device=device),
        }

    def clear(self) -> None:
        """Reset buffer for next rollout. / 다음 롤아웃을 위해 버퍼 초기화."""
        self.states.clear()
        self.actions.clear()
        self.rewards.clear()
        self.values.clear()
        self.log_probs.clear()
        self.dones.clear()
        self.advantages = None
        self.returns = None


# ===========================================================================
# 2. ReplayBuffer — SAC 경험 재생 버퍼 (원형 버퍼)
# ===========================================================================

class ReplayBuffer:
    """
    Circular replay buffer for off-policy SAC training.
    오프폴리시 SAC 학습을 위한 원형 재생 버퍼.

    Args:
        capacity: Maximum number of transitions to store / 최대 전이 저장 수
        state_dim: State vector dimension / 상태 벡터 차원
        action_dim: Action vector dimension / 행동 벡터 차원
    """

    def __init__(
        self,
        capacity: int = 100_000,
        state_dim: int = STATE_DIM,
        action_dim: int = ACTION_DIM,
    ) -> None:
        self.capacity = capacity
        self.ptr = 0       # Current write pointer / 현재 쓰기 포인터
        self.size = 0      # Current buffer size / 현재 버퍼 크기

        # Pre-allocate numpy arrays for speed / 속도를 위해 넘파이 배열 사전 할당
        self.states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.actions = np.zeros((capacity, action_dim), dtype=np.float32)
        self.rewards = np.zeros(capacity, dtype=np.float32)
        self.next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.dones = np.zeros(capacity, dtype=np.float32)

    def push(
        self,
        state: np.ndarray,
        action: np.ndarray,
        reward: float,
        next_state: np.ndarray,
        done: bool,
    ) -> None:
        """Store a transition. / 전이 하나를 저장."""
        self.states[self.ptr] = state
        self.actions[self.ptr] = action
        self.rewards[self.ptr] = reward
        self.next_states[self.ptr] = next_state
        self.dones[self.ptr] = float(done)

        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int) -> Dict[str, torch.Tensor]:
        """
        Sample a random batch. / 무작위 배치를 샘플링.
        Returns dict of tensors on CPU.
        """
        indices = np.random.randint(0, self.size, size=batch_size)
        return {
            "states": torch.tensor(self.states[indices], dtype=torch.float32),
            "actions": torch.tensor(self.actions[indices], dtype=torch.float32),
            "rewards": torch.tensor(self.rewards[indices], dtype=torch.float32).unsqueeze(1),
            "next_states": torch.tensor(self.next_states[indices], dtype=torch.float32),
            "dones": torch.tensor(self.dones[indices], dtype=torch.float32).unsqueeze(1),
        }

    def __len__(self) -> int:
        return self.size


# ===========================================================================
# 3. MLPActorCritic — Actor-Critic 신경망
# ===========================================================================

def _orthogonal_init(module: nn.Module, gain: float = np.sqrt(2)) -> None:
    """Orthogonal weight initialization (improved training stability). / 직교 가중치 초기화."""
    if isinstance(module, nn.Linear):
        nn.init.orthogonal_(module.weight, gain=gain)
        if module.bias is not None:
            nn.init.zeros_(module.bias)


class MLPActorCritic(nn.Module):
    """
    Actor-Critic network for continuous action spaces.
    연속 행동 공간을 위한 Actor-Critic 신경망.

    Actor:  state → (action_mean, action_log_std) → squashed Gaussian policy
    Critic: state → scalar value estimate

    Args:
        state_dim:  Observation dimension / 관측 차원
        action_dim: Action dimension / 행동 차원
        hidden_dims: Hidden layer sizes / 은닉층 크기 리스트
        activation: Activation function class / 활성화 함수 클래스
    """

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        action_dim: int = ACTION_DIM,
        hidden_dims: List[int] = None,
        activation: type = nn.ReLU,
    ) -> None:
        super().__init__()

        if hidden_dims is None:
            hidden_dims = HIDDEN_DIMS

        # ---- Actor (정책 네트워크) ----
        actor_layers: List[nn.Module] = []
        prev_dim = state_dim
        for h_dim in hidden_dims:
            actor_layers.append(nn.Linear(prev_dim, h_dim))
            actor_layers.append(activation())
            prev_dim = h_dim
        self.actor_backbone = nn.Sequential(*actor_layers)

        # Action mean head / 행동 평균 헤드
        self.actor_mean = nn.Linear(prev_dim, action_dim)
        # Action log-std head / 행동 로그표준편차 헤드
        self.actor_log_std = nn.Parameter(torch.zeros(action_dim, dtype=torch.float32))

        # ---- Critic (가치 네트워크) ----
        critic_layers: List[nn.Module] = []
        prev_dim = state_dim
        for h_dim in hidden_dims:
            critic_layers.append(nn.Linear(prev_dim, h_dim))
            critic_layers.append(activation())
            prev_dim = h_dim
        self.critic_backbone = nn.Sequential(*critic_layers)
        self.critic_head = nn.Linear(prev_dim, 1)

        # Initialize weights / 가중치 초기화
        self.apply(lambda m: _orthogonal_init(m, gain=np.sqrt(2)))
        # Policy output uses smaller gain / 정책 출력은 더 작은 gain 사용
        _orthogonal_init(self.actor_mean, gain=0.01)
        _orthogonal_init(self.critic_head, gain=1.0)

    def forward(self, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Forward pass returning action distribution parameters and value.
        순전파: 행동 분포 파라미터와 가치를 반환.

        Returns:
            action_mean:    [batch, action_dim] — 평균 (tanh 전)
            action_log_std: [action_dim]        — 로그 표준편차
            value:          [batch, 1]          — 상태 가치
        """
        action_mean = self.actor_mean(self.actor_backbone(state))
        value = self.critic_head(self.critic_backbone(state))
        return action_mean, self.actor_log_std, value

    def _get_distribution(
        self,
        state: torch.Tensor,
    ) -> Tuple[Independent, torch.Tensor]:
        """Build squashed Gaussian distribution from state. / 상태로부터 스퀴시드 가우시안 분포 생성."""
        action_mean, log_std, _ = self.forward(state)
        # Clamp log-std for numerical stability / 수치 안정성을 위해 클램프
        log_std = torch.clamp(log_std, LOG_STD_MIN, LOG_STD_MAX)
        std = torch.exp(log_std)
        # Independent ensures correct log_prob shape / Independent로 올바른 log_prob 형태 보장
        dist = Independent(Normal(loc=action_mean, scale=std), reinterpreted_batch_ndims=1)
        return dist, action_mean

    @torch.no_grad()
    def get_action(
        self,
        state: np.ndarray,
        deterministic: bool = False,
    ) -> Tuple[np.ndarray, float, float]:
        """
        Sample an action from the policy. / 정책으로부터 행동을 샘플링.

        Args:
            state:         [state_dim] numpy array
            deterministic: If True, return mean action / True면 평균 행동 반환

        Returns:
            action:    [action_dim] numpy array (tanh-squashed)
            log_prob:  Scalar log probability of the action
            value:     Scalar value estimate
        """
        state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        dist, _ = self._get_distribution(state_t)
        _, _, value = self.forward(state_t)

        if deterministic:
            # Use the mean directly, squashed / 평균을 직접 사용, tanh 적용
            raw_action = dist.base_dist.loc  # [1, action_dim]
            action = torch.tanh(raw_action)
            # Compute log_prob for tanh-squashed action / tanh 변환 후 log_prob 계산
            log_prob = self._tanh_log_prob(raw_action, dist.base_dist)
        else:
            # Sample then squash / 샘플 후 tanh 적용
            raw_action = dist.rsample()  # reparameterization sample for differentiability
            action = torch.tanh(raw_action)
            log_prob = self._tanh_log_prob(raw_action, dist.base_dist)

        return (
            action.squeeze(0).cpu().numpy(),
            log_prob.squeeze().item(),
            value.squeeze().item(),
        )

    def evaluate_actions(
        self,
        states: torch.Tensor,
        actions: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Evaluate log-probabilities and values for given state-action pairs.
        주어진 상태-행동 쌍에 대한 로그확률과 가치를 평가.

        Used during PPO update to compute importance ratios.
        PPO 업데이트 중 중요도 비율을 계산하는 데 사용.

        Args:
            states:  [batch, state_dim]
            actions: [batch, action_dim] — already tanh-squashed

        Returns:
            log_probs: [batch]
            entropy:   [batch]
            values:    [batch]
        """
        dist, _ = self._get_distribution(states)
        _, _, values = self.forward(states)

        # Inverse tanh to get pre-squash action / tanh 역변환으로 스퀴시 전 행동 복원
        # atanh for numerical stability / 수치 안정성을 위한 atanh
        pre_tanh_action = self._atanh(actions.clamp(-1.0 + EPS, 1.0 - EPS))

        # Log prob with tanh correction / tanh 보정이 포함된 로그 확률
        log_probs = self._tanh_log_prob(pre_tanh_action, dist.base_dist)
        entropy = dist.entropy()

        return log_probs, entropy, values.squeeze(-1)

    @staticmethod
    def _tanh_log_prob(
        pre_tanh_action: torch.Tensor,
        base_dist: Normal,
    ) -> torch.Tensor:
        """
        Compute log probability of tanh-squashed action.
        tanh 변환된 행동의 로그 확률을 계산.

        log π(a|s) = log μ(u|s) - Σ_i log(1 - tanh(u_i)²)
        where a = tanh(u)
        """
        log_prob_mu = base_dist.log_prob(pre_tanh_action).sum(dim=-1)
        correction = torch.log(1.0 - torch.tanh(pre_tanh_action) ** 2 + EPS).sum(dim=-1)
        return log_prob_mu - correction

    @staticmethod
    def _atanh(x: torch.Tensor) -> torch.Tensor:
        """Inverse hyperbolic tangent (numerically stable). / 역쌍곡탄젠트 (수치 안정)."""
        return 0.5 * (torch.log(1.0 + x + EPS) - torch.log(1.0 - x + EPS))


# ===========================================================================
# 4. PPOAgent — Proximal Policy Optimization
# ===========================================================================

class PPOAgent:
    """
    Proximal Policy Optimization agent with GAE and value clipping.
    GAE 및 가치 클리핑을 적용한 Proximal Policy Optimization 에이전트.

    Reference: Schulman et al., "Proximal Policy Optimization Algorithms", 2017

    Args:
        state_dim:   관측 차원
        action_dim:  행동 차원
        lr:          Learning rate / 학습률
        gamma:       Discount factor / 할인 인자
        lam:         GAE lambda / GAE 람다
        clip_ratio:  PPO clipping parameter ε / PPO 클리핑 파라미터
        epochs:      Number of update epochs per rollout / 롤아웃당 업데이트 에포크 수
        entropy_coef: Entropy bonus coefficient / 엔트로피 보너스 계수
        max_grad_norm: Gradient clipping norm / 그래디언트 클리핑 노름
        device:      Torch device / 토치 디바이스
    """

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        action_dim: int = ACTION_DIM,
        lr: float = 3e-4,
        gamma: float = 0.99,
        lam: float = 0.95,
        clip_ratio: float = 0.2,
        epochs: int = 10,
        entropy_coef: float = 0.01,
        max_grad_norm: float = 0.5,
        device: Optional[torch.device] = None,
    ) -> None:
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.lam = lam
        self.clip_ratio = clip_ratio
        self.epochs = epochs
        self.entropy_coef = entropy_coef
        self.max_grad_norm = max_grad_norm

        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = device

        # Actor-Critic network / Actor-Critic 신경망
        self.ac = MLPActorCritic(state_dim, action_dim).to(self.device)

        # Optimizer / 옵티마이저
        self.optimizer = torch.optim.Adam(self.ac.parameters(), lr=lr)

        # Training step counter / 학습 스텝 카운터
        self._step = 0

        logger.info(
            "PPOAgent 초기화 완료 / PPOAgent initialized: "
            "state_dim=%d, action_dim=%d, device=%s",
            state_dim, action_dim, self.device,
        )

    # ------------------------------------------------------------------
    # Rollout collection / 롤아웃 수집
    # ------------------------------------------------------------------

    def collect_rollout(
        self,
        env_step_fn: Callable[[np.ndarray], Tuple[np.ndarray, float, bool, dict]],
        n_steps: int = 2048,
    ) -> RolloutBuffer:
        """
        Collect a rollout by interacting with the environment.
        환경과 상호작용하며 롤아웃을 수집한다.

        Args:
            env_step_fn:  Callable(state) → (next_state, reward, done, info)
            n_steps:      Number of steps to collect / 수집할 스텝 수

        Returns:
            Populated RolloutBuffer
        """
        buffer = RolloutBuffer()
        state = None  # Will be set by env_step_fn on first call or from outside

        # Get initial state from env_step_fn if needed
        # env_step_fn should handle None state for initial observation
        # 첫 관측을 위해 env_step_fn이 None 상태를 처리해야 함

        for _ in range(n_steps):
            if state is None:
                # First step: ask env for initial observation
                # 첫 스텝: 환경에 초기 관측 요청
                state, _, done, info = env_step_fn(None)
                if done:
                    state, _, _, _ = env_step_fn(None)

            action, log_prob, value = self.ac.get_action(state)
            next_state, reward, done, info = env_step_fn(action)

            buffer.insert(
                state=state,
                action=action,
                reward=reward,
                value=value,
                log_prob=log_prob,
                done=done,
            )

            state = next_state

            # If episode ended, reset state / 에피소드 종료 시 상태 리셋
            if done:
                state = None

        # Bootstrap value for last state / 마지막 상태의 부트스트랩 가치
        if state is not None:
            with torch.no_grad():
                state_t = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
                _, _, last_val = self.ac(state_t)
                last_value = last_val.squeeze().item()
        else:
            last_value = 0.0

        # Compute GAE returns and advantages / GAE 반환값과 어드밴티지 계산
        buffer.compute_returns_and_advantages(last_value, self.gamma, self.lam)

        return buffer

    # ------------------------------------------------------------------
    # GAE advantage computation (delegated to buffer) / GAE 어드밴티지 계산
    # ------------------------------------------------------------------

    def compute_advantages(self, buffer: RolloutBuffer) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute advantages and returns from buffer (uses GAE).
        버퍼로부터 어드밴티지와 반환값을 계산한다 (GAE 사용).

        Returns:
            advantages: [N] array
            returns:    [N] array
        """
        if buffer.advantages is None or buffer.returns is None:
            raise ValueError(
                "Buffer에 returns/advantages가 없습니다. compute_returns_and_advantages를 먼저 호출하세요. / "
                "Buffer has no returns/advantages. Call compute_returns_and_advantages first."
            )
        return buffer.advantages, buffer.returns

    # ------------------------------------------------------------------
    # PPO update / PPO 업데이트
    # ------------------------------------------------------------------

    def update(self, buffer: RolloutBuffer) -> Dict[str, float]:
        """
        Perform PPO update using collected rollout data.
        수집된 롤아웃 데이터를 사용하여 PPO 업데이트를 수행한다.

        Returns:
            Dictionary of average losses: policy_loss, value_loss, entropy, total_loss
        """
        data = buffer.get_tensors(self.device)
        states = data["states"]
        actions = data["actions"]
        old_log_probs = data["old_log_probs"]
        advantages = data["advantages"]
        returns = data["returns"]

        batch_size = states.shape[0]
        total_policy_loss = 0.0
        total_value_loss = 0.0
        total_entropy = 0.0

        for _epoch in range(self.epochs):
            # Evaluate current policy on the batch / 현재 정책으로 배치 평가
            log_probs, entropy, values = self.ac.evaluate_actions(states, actions)

            # Importance ratio / 중요도 비율
            ratio = torch.exp(log_probs - old_log_probs)

            # Clipped surrogate objective / 클리핑된 서로게이트 목적함수
            surr1 = ratio * advantages
            surr2 = torch.clamp(ratio, 1.0 - self.clip_ratio, 1.0 + self.clip_ratio) * advantages
            policy_loss = -torch.min(surr1, surr2).mean()

            # Value loss with clipping (value function clipping) / 가치 클리핑 손실
            # Get old values from buffer / 버퍼에서 이전 가치 가져오기
            old_values = torch.tensor(
                np.array(buffer.values), dtype=torch.float32, device=self.device
            )
            values_clipped = old_values + torch.clamp(
                values - old_values, -self.clip_ratio, self.clip_ratio
            )
            value_loss_unclipped = F.mse_loss(values, returns)
            value_loss_clipped = F.mse_loss(values_clipped, returns)
            value_loss = torch.max(value_loss_unclipped, value_loss_clipped)

            # Entropy bonus / 엔트로피 보너스
            entropy_mean = entropy.mean()

            # Total loss / 총 손실
            loss = policy_loss + 0.5 * value_loss - self.entropy_coef * entropy_mean

            # Gradient step / 그래디언트 스텝
            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.ac.parameters(), self.max_grad_norm)
            self.optimizer.step()

            total_policy_loss += policy_loss.item()
            total_value_loss += value_loss.item()
            total_entropy += entropy_mean.item()

        self._step += 1

        avg_policy_loss = total_policy_loss / self.epochs
        avg_value_loss = total_value_loss / self.epochs
        avg_entropy = total_entropy / self.epochs
        avg_total_loss = avg_policy_loss + 0.5 * avg_value_loss - self.entropy_coef * avg_entropy

        result = {
            "policy_loss": avg_policy_loss,
            "value_loss": avg_value_loss,
            "entropy": avg_entropy,
            "total_loss": avg_total_loss,
            "step": self._step,
        }

        logger.debug(
            "PPO 업데이트 / PPO update: policy_loss=%.4f, value_loss=%.4f, entropy=%.4f",
            avg_policy_loss, avg_value_loss, avg_entropy,
        )

        return result

    # ------------------------------------------------------------------
    # Save / Load / 저장 / 불러오기
    # ------------------------------------------------------------------

    def save_policy(self, path: str) -> None:
        """Save agent state to file. / 에이전트 상태를 파일에 저장."""
        path = str(path)
        save_dict = {
            "ac_state_dict": self.ac.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "step": self._step,
            "config": {
                "state_dim": self.state_dim,
                "action_dim": self.action_dim,
                "gamma": self.gamma,
                "lam": self.lam,
                "clip_ratio": self.clip_ratio,
                "epochs": self.epochs,
                "entropy_coef": self.entropy_coef,
                "max_grad_norm": self.max_grad_norm,
            },
        }
        torch.save(save_dict, path)
        logger.info("PPO 정책 저장 완료 / PPO policy saved: %s", path)

    def load_policy(self, path: str) -> None:
        """Load agent state from file. / 파일에서 에이전트 상태를 불러온다."""
        path = str(path)
        checkpoint = torch.load(path, map_location=self.device, weights_only=False)

        self.ac.load_state_dict(checkpoint["ac_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self._step = checkpoint.get("step", 0)

        logger.info(
            "PPO 정책 로드 완료 / PPO policy loaded: %s (step=%d)",
            path, self._step,
        )


# ===========================================================================
# 5. SACAgent — Soft Actor-Critic
# ===========================================================================

class SACQNetwork(nn.Module):
    """
    Twin Q-network for SAC. Two separate Q-functions to mitigate overestimation.
    SAC용 쌍둥이 Q-네트워크. 과대추정 완화를 위한 두 개의 Q-함수.
    """

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden_dims: List[int] = None,
        activation: type = nn.ReLU,
    ) -> None:
        super().__init__()
        if hidden_dims is None:
            hidden_dims = HIDDEN_DIMS

        # Q1 network
        layers1: List[nn.Module] = []
        prev = state_dim + action_dim
        for h in hidden_dims:
            layers1.append(nn.Linear(prev, h))
            layers1.append(activation())
            prev = h
        layers1.append(nn.Linear(prev, 1))
        self.q1 = nn.Sequential(*layers1)

        # Q2 network (independent) / Q2 네트워크 (독립적)
        layers2: List[nn.Module] = []
        prev = state_dim + action_dim
        for h in hidden_dims:
            layers2.append(nn.Linear(prev, h))
            layers2.append(activation())
            prev = h
        layers2.append(nn.Linear(prev, 1))
        self.q2 = nn.Sequential(*layers2)

        self.apply(lambda m: _orthogonal_init(m, gain=1.0))

    def forward(
        self, state: torch.Tensor, action: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through both Q-networks.
        두 Q-네트워크를 통한 순전파.

        Args:
            state:  [batch, state_dim]
            action: [batch, action_dim]

        Returns:
            q1, q2:  [batch, 1]
        """
        sa = torch.cat([state, action], dim=-1)
        return self.q1(sa), self.q2(sa)


class SACAgent:
    """
    Soft Actor-Critic agent with automatic temperature tuning.
    자동 온도 조절이 포함된 Soft Actor-Critic 에이전트.

    Reference: Haarnoja et al., "Soft Actor-Critic: Off-Policy Maximum Entropy
    Deep RL with a Stochastic Actor", 2018

    Args:
        state_dim:   관측 차원
        action_dim:  행동 차원
        lr:          Learning rate / 학습률
        alpha:       Initial temperature (overridden by auto-tuning) / 초기 온도
        tau:         Soft update coefficient / 소프트 업데이트 계수
        gamma:       Discount factor / 할인 인자
        target_update_interval: Target network update frequency / 타겟 네트워크 업데이트 주기
        auto_alpha:  Whether to auto-tune alpha / alpha 자동 조절 여부
        device:      Torch device
    """

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        action_dim: int = ACTION_DIM,
        lr: float = 3e-4,
        alpha: float = 0.2,
        tau: float = 0.005,
        gamma: float = 0.99,
        target_update_interval: int = 1,
        auto_alpha: bool = True,
        device: Optional[torch.device] = None,
    ) -> None:
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.tau = tau
        self.gamma = gamma
        self.target_update_interval = target_update_interval
        self.auto_alpha = auto_alpha

        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = device

        # Actor network (same MLPActorCritic) / 행위자 네트워크 (동일한 MLPActorCritic)
        self.actor = MLPActorCritic(state_dim, action_dim).to(self.device)

        # Twin Q-networks + targets / 쌍둥이 Q-네트워크 + 타겟
        self.critic = SACQNetwork(state_dim, action_dim).to(self.device)
        self.critic_target = SACQNetwork(state_dim, action_dim).to(self.device)
        # Hard copy initial weights / 초기 가중치 하드 카피
        self.critic_target.load_state_dict(self.critic.state_dict())

        # Freeze target networks / 타겟 네트워크 고정
        for param in self.critic_target.parameters():
            param.requires_grad = False

        # Optimizers / 옵티마이저
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=lr)

        # Automatic temperature tuning / 자동 온도 조절
        if auto_alpha:
            self._log_alpha = torch.tensor(
                math.log(alpha), dtype=torch.float32, device=self.device, requires_grad=True
            )
            self._alpha_optimizer = torch.optim.Adam([self._log_alpha], lr=lr)
            self._target_entropy = -action_dim  # Standard heuristic / 표준 휴리스틱
        else:
            self._log_alpha = torch.tensor(
                math.log(alpha), dtype=torch.float32, device=self.device
            )
            self._alpha_optimizer = None
            self._target_entropy = None

        self._update_count = 0

        logger.info(
            "SACAgent 초기화 완료 / SACAgent initialized: "
            "state_dim=%d, action_dim=%d, auto_alpha=%s, device=%s",
            state_dim, action_dim, auto_alpha, self.device,
        )

    @property
    def alpha(self) -> float:
        """Current temperature value. / 현재 온도 값."""
        return self._log_alpha.exp().item()

    def select_action(
        self,
        state: np.ndarray,
        evaluate: bool = False,
    ) -> np.ndarray:
        """
        Select an action, optionally in evaluation mode (deterministic).
        행동을 선택한다. 평가 모드에서는 결정론적 행동 선택.

        Args:
            state:     [state_dim] numpy array
            evaluate:  If True, use mean action / True면 평균 행동 사용

        Returns:
            action: [action_dim] numpy array, in [-1, 1] (tanh-squashed)
        """
        action, _, _ = self.actor.get_action(state, deterministic=evaluate)
        return action

    def update(
        self,
        replay_buffer: ReplayBuffer,
        batch_size: int = 256,
    ) -> Dict[str, float]:
        """
        Perform one SAC update step.
        SAC 업데이트 스텝을 수행한다.

        Args:
            replay_buffer: Experience replay buffer / 경험 재생 버퍼
            batch_size:    Minibatch size / 미니배치 크기

        Returns:
            Dictionary of losses: critic_loss, actor_loss, alpha, alpha_loss
        """
        if len(replay_buffer) < batch_size:
            # Not enough data yet / 아직 충분한 데이터가 없음
            return {"critic_loss": 0.0, "actor_loss": 0.0, "alpha": self.alpha, "alpha_loss": 0.0}

        # Sample batch / 배치 샘플링
        batch = replay_buffer.sample(batch_size)
        states = batch["states"].to(self.device)
        actions = batch["actions"].to(self.device)
        rewards = batch["rewards"].to(self.device)
        next_states = batch["next_states"].to(self.device)
        dones = batch["dones"].to(self.device)

        # ------- Critic update / 크리틱 업데이트 -------
        with torch.no_grad():
            # Sample next actions from current policy / 현재 정책에서 다음 행동 샘플링
            next_dist, _ = self.actor._get_distribution(next_states)
            next_raw_action = next_dist.rsample()
            next_action = torch.tanh(next_raw_action)
            next_log_prob = self.actor._tanh_log_prob(next_raw_action, next_dist.base_dist)

            # Target Q-values (take minimum of two Q-functions) / 타겟 Q-값 (두 Q함수의 최솟값)
            q1_target, q2_target = self.critic_target(next_states, next_action)
            q_target_min = torch.min(q1_target, q2_target)

            # Entropy-regularized target / 엔트로피 정규화된 타겟
            alpha_val = self._log_alpha.exp()
            q_target = rewards + (1.0 - dones) * self.gamma * (
                q_target_min - alpha_val * next_log_prob.unsqueeze(-1)
            )

        # Current Q-values / 현재 Q-값
        q1, q2 = self.critic(states, actions)
        critic_loss = F.mse_loss(q1, q_target) + F.mse_loss(q2, q_target)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # ------- Actor update / 행위자 업데이트 -------
        # Sample actions from current policy (reparameterization) / 현재 정책에서 행동 샘플링
        dist, _ = self.actor._get_distribution(states)
        raw_action = dist.rsample()
        action_new = torch.tanh(raw_action)
        log_prob_new = self.actor._tanh_log_prob(raw_action, dist.base_dist)

        q1_new, q2_new = self.critic(states, action_new)
        q_new = torch.min(q1_new, q2_new)

        alpha_val = self._log_alpha.exp()
        actor_loss = (alpha_val * log_prob_new - q_new.squeeze(-1)).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # ------- Alpha (temperature) update / 온도 업데이트 -------
        alpha_loss_val = 0.0
        if self.auto_alpha and self._alpha_optimizer is not None:
            alpha_loss = -(
                self._log_alpha.exp() * (log_prob_new + self._target_entropy).detach()
            ).mean()
            self._alpha_optimizer.zero_grad()
            alpha_loss.backward()
            self._alpha_optimizer.step()
            alpha_loss_val = alpha_loss.item()

        # ------- Soft update of target networks / 타겟 네트워크 소프트 업데이트 -------
        self._update_count += 1
        if self._update_count % self.target_update_interval == 0:
            self._soft_update_target()

        result = {
            "critic_loss": critic_loss.item(),
            "actor_loss": actor_loss.item(),
            "alpha": self.alpha,
            "alpha_loss": alpha_loss_val,
        }

        logger.debug(
            "SAC 업데이트 / SAC update: critic=%.4f, actor=%.4f, alpha=%.4f",
            result["critic_loss"], result["actor_loss"], result["alpha"],
        )

        return result

    def _soft_update_target(self) -> None:
        """Polyak averaging for target networks. / 타겟 네트워크 폴리악 평균."""
        for param, target_param in zip(
            self.critic.parameters(), self.critic_target.parameters()
        ):
            target_param.data.copy_(
                self.tau * param.data + (1.0 - self.tau) * target_param.data
            )

    def save_policy(self, path: str) -> None:
        """Save SAC agent state. / SAC 에이전트 상태 저장."""
        path = str(path)
        save_dict = {
            "actor_state_dict": self.actor.state_dict(),
            "critic_state_dict": self.critic.state_dict(),
            "critic_target_state_dict": self.critic_target.state_dict(),
            "actor_optimizer_state_dict": self.actor_optimizer.state_dict(),
            "critic_optimizer_state_dict": self.critic_optimizer.state_dict(),
            "log_alpha": self._log_alpha,
            "alpha_optimizer_state_dict": (
                self._alpha_optimizer.state_dict() if self._alpha_optimizer else None
            ),
            "update_count": self._update_count,
            "config": {
                "state_dim": self.state_dim,
                "action_dim": self.action_dim,
                "tau": self.tau,
                "gamma": self.gamma,
                "auto_alpha": self.auto_alpha,
            },
        }
        torch.save(save_dict, path)
        logger.info("SAC 정책 저장 완료 / SAC policy saved: %s", path)

    def load_policy(self, path: str) -> None:
        """Load SAC agent state. / SAC 에이전트 상태 불러오기."""
        path = str(path)
        checkpoint = torch.load(path, map_location=self.device, weights_only=False)

        self.actor.load_state_dict(checkpoint["actor_state_dict"])
        self.critic.load_state_dict(checkpoint["critic_state_dict"])
        self.critic_target.load_state_dict(checkpoint["critic_target_state_dict"])
        self.actor_optimizer.load_state_dict(checkpoint["actor_optimizer_state_dict"])
        self.critic_optimizer.load_state_dict(checkpoint["critic_optimizer_state_dict"])
        self._log_alpha = checkpoint["log_alpha"]

        if self._alpha_optimizer is not None and checkpoint.get("alpha_optimizer_state_dict"):
            self._alpha_optimizer.load_state_dict(checkpoint["alpha_optimizer_state_dict"])

        self._update_count = checkpoint.get("update_count", 0)
        logger.info(
            "SAC 정책 로드 완료 / SAC policy loaded: %s (update_count=%d)",
            path, self._update_count,
        )


# ===========================================================================
# 6. MultiObjectiveReward — 다목적 보상 계산
# ===========================================================================

class MultiObjectiveReward:
    """
    Computes a weighted multi-objective reward from physical experience data.
    물리적 경험 데이터로부터 가중 다목적 보상을 계산한다.

    Each reward component is normalized to [-1, 1] before weighting.
    각 보상 구성요소는 가중치 적용 전 [-1, 1]로 정규화된다.

    Components / 구성요소:
        success_reward:        Task completion / 작업 완성도 (weight=0.30)
        precision_reward:      Execution accuracy / 실행 정밀도 (weight=0.25)
        energy_efficiency:     Energy per task / 작업당 에너지 효율 (weight=0.20)
        stability_reward:      Balance/stability / 균형/안정성 (weight=0.15)
        time_efficiency:       Speed / 속도 효율 (weight=0.10)
    """

    def __init__(
        self,
        success_weight: float = 0.30,
        precision_weight: float = 0.25,
        energy_weight: float = 0.20,
        stability_weight: float = 0.15,
        time_weight: float = 0.10,
    ) -> None:
        self.weights = {
            "success": success_weight,
            "precision": precision_weight,
            "energy": energy_weight,
            "stability": stability_weight,
            "time": time_weight,
        }
        # Running statistics for normalization / 정규화를 위한 실행 통계
        self._stats = {
            key: {"mean": 0.0, "std": 1.0, "count": 0, "sum": 0.0, "sum_sq": 0.0}
            for key in self.weights
        }
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Individual reward components / 개별 보상 구성요소
    # ------------------------------------------------------------------

    def success_reward(self, experience: dict) -> float:
        """
        Task completion reward. Binary or partial completion signal.
        작업 완성도 보상. 이진 또는 부분 완료 신호.

        Args:
            experience: dict with 'task_success' (float 0-1), 'subtask_completion' (float 0-1)
        """
        task_success = experience.get("task_success", 0.0)
        subtask_completion = experience.get("subtask_completion", 0.0)
        # Weighted combination / 가중 조합
        raw = 0.7 * task_success + 0.3 * subtask_completion
        return self._normalize("success", raw)

    def precision_reward(self, experience: dict) -> float:
        """
        Execution accuracy reward. Measures how close the action was to the target.
        실행 정밀도 보상. 행동이 목표에 얼마나 가까운지 측정.

        Args:
            experience: dict with 'target_error' (float, lower is better),
                        'position_error' (float)
        """
        target_error = experience.get("target_error", 1.0)
        position_error = experience.get("position_error", 1.0)
        # Exponential decay: smaller error → higher reward / 지수 감소: 오차 작을수록 보상 높음
        precision = math.exp(-5.0 * target_error) * 0.6 + math.exp(-3.0 * position_error) * 0.4
        # Convert [0,1] to [-1,1] / [0,1]을 [-1,1]로 변환
        raw = 2.0 * precision - 1.0
        return self._normalize("precision", raw)

    def energy_efficiency_reward(self, experience: dict) -> float:
        """
        Energy efficiency reward. Less energy per unit of work is better.
        에너지 효율 보상. 단위 작업당 적은 에너지가 좋음.

        Args:
            experience: dict with 'energy_consumed' (float, Joules),
                        'work_done' (float, 0-1)
        """
        energy = experience.get("energy_consumed", 1.0)
        work = max(experience.get("work_done", 0.0), EPS)
        # Efficiency = work / energy / 효율 = 작업 / 에너지
        efficiency = work / (energy + EPS)
        # Reference efficiency for normalization / 정규화 기준 효율
        ref_efficiency = 0.01  # 예상 기준 / expected baseline
        raw = np.clip(efficiency / ref_efficiency - 1.0, -1.0, 1.0)
        return self._normalize("energy", raw)

    def stability_reward(self, experience: dict) -> float:
        """
        Balance and stability reward. Penalizes tilt, vibration, and jerk.
        균형 및 안정성 보상. 기울기, 진동, 가가속도를 벌점.

        Args:
            experience: dict with 'tilt_angle' (rad), 'vibration' (float),
                        'max_jerk' (float)
        """
        tilt = experience.get("tilt_angle", 0.5)
        vibration = experience.get("vibration", 0.5)
        max_jerk = experience.get("max_jerk", 1.0)

        # Stability score: higher is more stable / 안정성 점수: 높을수록 안정
        tilt_score = math.exp(-3.0 * abs(tilt))
        vib_score = math.exp(-2.0 * vibration)
        jerk_score = math.exp(-1.0 * max_jerk)
        stability = 0.4 * tilt_score + 0.35 * vib_score + 0.25 * jerk_score

        raw = 2.0 * stability - 1.0  # Map to [-1, 1] / [-1, 1]로 매핑
        return self._normalize("stability", raw)

    def time_efficiency_reward(self, experience: dict) -> float:
        """
        Time efficiency reward. Faster completion is better, but with diminishing returns.
        시간 효율 보상. 빠른 완료가 좋지만 수확 체감 적용.

        Args:
            experience: dict with 'elapsed_time' (seconds), 'target_time' (seconds)
        """
        elapsed = experience.get("elapsed_time", 10.0)
        target_time = experience.get("target_time", 5.0)
        if target_time <= 0:
            target_time = 1.0
        # Time ratio / 시간 비율
        time_ratio = target_time / (elapsed + EPS)
        # Sigmoid-like mapping / 시그모이드 유사 매핑
        raw = 2.0 / (1.0 + math.exp(-2.0 * (time_ratio - 1.0))) - 1.0
        return self._normalize("time", raw)

    # ------------------------------------------------------------------
    # Normalization / 정규화
    # ------------------------------------------------------------------

    def _normalize(self, key: str, value: float) -> float:
        """
        Running z-score normalization clamped to [-1, 1].
        실행 중 z-score 정규화 후 [-1, 1]로 클램핑.
        """
        with self._lock:
            stats = self._stats[key]
            stats["count"] += 1
            stats["sum"] += value
            stats["sum_sq"] += value * value
            # Update running mean/std / 실행 중 평균/표준편차 업데이트
            stats["mean"] = stats["sum"] / stats["count"]
            if stats["count"] > 1:
                variance = stats["sum_sq"] / stats["count"] - stats["mean"] ** 2
                stats["std"] = math.sqrt(max(variance, EPS))
            normalized = (value - stats["mean"]) / (stats["std"] + EPS)
            return float(np.clip(normalized, -1.0, 1.0))

    # ------------------------------------------------------------------
    # Total reward / 총 보상
    # ------------------------------------------------------------------

    def compute_total(self, experience: dict) -> float:
        """
        Compute the weighted total reward from an experience dictionary.
        경험 딕셔너리로부터 가중 총 보상을 계산한다.

        Args:
            experience: dict containing all reward-related fields

        Returns:
            Total reward as weighted sum of normalized components / 정규화된 구성요소의 가중 합
        """
        components = {
            "success": self.success_reward(experience),
            "precision": self.precision_reward(experience),
            "energy": self.energy_efficiency_reward(experience),
            "stability": self.stability_reward(experience),
            "time": self.time_efficiency_reward(experience),
        }

        total = sum(self.weights[k] * components[k] for k in self.weights)
        logger.debug(
            "보상 분해 / Reward breakdown: %s → total=%.4f",
            {k: f"{v:.3f}" for k, v in components.items()},
            total,
        )
        return total

    def get_breakdown(self, experience: dict) -> Dict[str, float]:
        """Return individual reward components. / 개별 보상 구성요소 반환."""
        return {
            "success": self.success_reward(experience),
            "precision": self.precision_reward(experience),
            "energy": self.energy_efficiency_reward(experience),
            "stability": self.stability_reward(experience),
            "time": self.time_efficiency_reward(experience),
            "total": self.compute_total(experience),
        }


# ===========================================================================
# 7. CurriculumScheduler — 커리큘럼 스케줄러
# ===========================================================================

class CurriculumScheduler:
    """
    Increases task difficulty as the agent's skill improves.
    에이전트의 기술이 향상됨에 따라 작업 난이도를 증가시킨다.

    Uses a sliding window of recent evaluation scores.
    최근 평가 점수의 이동 창을 사용한다.
    """

    def __init__(
        self,
        initial_difficulty: float = 0.1,
        max_difficulty: float = 1.0,
        increase_threshold: float = 0.75,
        decrease_threshold: float = 0.30,
        window_size: int = 10,
        increment: float = 0.05,
    ) -> None:
        self.difficulty = initial_difficulty
        self.max_difficulty = max_difficulty
        self.increase_threshold = increase_threshold
        self.decrease_threshold = decrease_threshold
        self.window_size = window_size
        self.increment = increment
        self._scores: List[float] = []

    def update(self, score: float) -> float:
        """
        Record a score and potentially adjust difficulty.
        점수를 기록하고 난이도를 조정한다.

        Args:
            score: Evaluation score in [0, 1]

        Returns:
            Current difficulty level / 현재 난이도 수준
        """
        self._scores.append(score)
        if len(self._scores) > self.window_size:
            self._scores = self._scores[-self.window_size:]

        if len(self._scores) >= 3:
            avg = np.mean(self._scores)
            if avg >= self.increase_threshold:
                self.difficulty = min(self.difficulty + self.increment, self.max_difficulty)
                logger.info(
                    "난이도 증가 / Difficulty increased: %.2f (avg_score=%.3f)",
                    self.difficulty, avg,
                )
            elif avg <= self.decrease_threshold:
                self.difficulty = max(self.difficulty - self.increment * 0.5, 0.05)
                logger.info(
                    "난이도 감소 / Difficulty decreased: %.2f (avg_score=%.3f)",
                    self.difficulty, avg,
                )

        return self.difficulty

    @property
    def level(self) -> float:
        """Current difficulty level. / 현재 난이도 수준."""
        return self.difficulty


# ===========================================================================
# 8. RLTrainingLoop — 학습 오케스트레이션
# ===========================================================================

class RLTrainingLoop:
    """
    Orchestrates the RL training process with logging, evaluation, and checkpointing.
    로깅, 평가, 체크포인트 저장과 함께 RL 학습 과정을 관리한다.

    Supports both PPOAgent and SACAgent.
    PPOAgent와 SACAgent 모두 지원한다.

    Args:
        agent:        PPOAgent or SACAgent instance / PPOAgent 또는 SACAgent 인스턴스
        reward_fn:    MultiObjectiveReward instance / MultiObjectiveReward 인스턴스
        env_step_fn:  Environment step function / 환경 스텝 함수
        db_path:      SQLite database path for training logs / 학습 로그용 SQLite 경로
        checkpoint_dir: Directory for model checkpoints / 모델 체크포인트 디렉토리
        curriculum:   Optional CurriculumScheduler / 선택적 커리큘럼 스케줄러
    """

    def __init__(
        self,
        agent,  # Union[PPOAgent, SACAgent]
        reward_fn: MultiObjectiveReward,
        env_step_fn: Callable,
        db_path: str = "rl_training.db",
        checkpoint_dir: str = "checkpoints",
        curriculum: Optional[CurriculumScheduler] = None,
    ) -> None:
        self.agent = agent
        self.reward_fn = reward_fn
        self.env_step_fn = env_step_fn
        self.db_path = db_path
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.curriculum = curriculum or CurriculumScheduler()

        # Thread safety for DB writes / DB 쓰기 스레드 안전성
        self._db_lock = threading.Lock()

        # Initialize database / 데이터베이스 초기화
        self._init_db()

        # Training state / 학습 상태
        self._iteration = 0
        self._best_eval_score = -float("inf")

        # For SAC: replay buffer / SAC용: 재생 버퍼
        self._sac_buffer: Optional[ReplayBuffer] = None
        if isinstance(agent, SACAgent):
            self._sac_buffer = ReplayBuffer(capacity=100_000)

        logger.info(
            "RLTrainingLoop 초기화 / RLTrainingLoop initialized: "
            "agent=%s, db=%s, checkpoint_dir=%s",
            type(agent).__name__, self.db_path, self.checkpoint_dir,
        )

    # ------------------------------------------------------------------
    # Database / 데이터베이스
    # ------------------------------------------------------------------

    def _init_db(self) -> None:
        """Create training log tables. / 학습 로그 테이블 생성."""
        with self._db_lock:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()

            # Training steps table / 학습 스텝 테이블
            c.execute("""
                CREATE TABLE IF NOT EXISTS training_steps (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    iteration INTEGER NOT NULL,
                    timestamp REAL NOT NULL,
                    policy_loss REAL,
                    value_loss REAL,
                    entropy REAL,
                    total_loss REAL,
                    mean_reward REAL,
                    difficulty REAL
                )
            """)

            # Evaluations table / 평가 테이블
            c.execute("""
                CREATE TABLE IF NOT EXISTS evaluations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    iteration INTEGER NOT NULL,
                    timestamp REAL NOT NULL,
                    mean_score REAL NOT NULL,
                    std_score REAL,
                    max_score REAL,
                    min_score REAL,
                    n_episodes INTEGER,
                    difficulty REAL
                )
            """)

            conn.commit()
            conn.close()

    def _log_step(self, iteration: int, losses: Dict[str, float],
                  mean_reward: float, difficulty: float) -> None:
        """Log a training step to SQLite. / 학습 스텝을 SQLite에 기록."""
        with self._db_lock:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            c.execute("""
                INSERT INTO training_steps
                    (iteration, timestamp, policy_loss, value_loss, entropy,
                     total_loss, mean_reward, difficulty)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                iteration,
                time.time(),
                losses.get("policy_loss", losses.get("actor_loss", 0.0)),
                losses.get("value_loss", losses.get("critic_loss", 0.0)),
                losses.get("entropy", 0.0),
                losses.get("total_loss", 0.0),
                mean_reward,
                difficulty,
            ))
            conn.commit()
            conn.close()

    def _log_evaluation(self, iteration: int, eval_result: Dict[str, float],
                        difficulty: float) -> None:
        """Log an evaluation result to SQLite. / 평가 결과를 SQLite에 기록."""
        with self._db_lock:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            c.execute("""
                INSERT INTO evaluations
                    (iteration, timestamp, mean_score, std_score,
                     max_score, min_score, n_episodes, difficulty)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                iteration,
                time.time(),
                eval_result["mean_score"],
                eval_result.get("std_score", 0.0),
                eval_result.get("max_score", 0.0),
                eval_result.get("min_score", 0.0),
                eval_result.get("n_episodes", 0),
                difficulty,
            ))
            conn.commit()
            conn.close()

    # ------------------------------------------------------------------
    # Training / 학습
    # ------------------------------------------------------------------

    def train(
        self,
        n_iterations: int = 1000,
        eval_interval: int = 50,
        checkpoint_interval: int = 100,
    ) -> Dict[str, float]:
        """
        Run the main training loop.
        메인 학습 루프를 실행한다.

        Args:
            n_iterations:      Total training iterations / 총 학습 반복 횟수
            eval_interval:     Evaluate every N iterations / N 반복마다 평가
            checkpoint_interval: Save checkpoint every N iterations / N 반복마다 체크포인트 저장

        Returns:
            Final training statistics / 최종 학습 통계
        """
        logger.info(
            "학습 시작 / Training started: n_iterations=%d, agent=%s",
            n_iterations, type(self.agent).__name__,
        )

        all_rewards: List[float] = []
        start_time = time.time()

        for i in range(n_iterations):
            self._iteration += 1
            iteration = self._iteration

            if isinstance(self.agent, PPOAgent):
                losses, mean_reward = self._train_ppo_step()
            elif isinstance(self.agent, SACAgent):
                losses, mean_reward = self._train_sac_step()
            else:
                raise TypeError(
                    f"지원하지 않는 에이전트 타입 / Unsupported agent type: {type(self.agent)}"
                )

            all_rewards.append(mean_reward)
            difficulty = self.curriculum.level

            # Log to DB / DB에 기록
            self._log_step(iteration, losses, mean_reward, difficulty)

            # Periodic evaluation / 주기적 평가
            if iteration % eval_interval == 0:
                eval_result = self.evaluate(n_episodes=10)
                self._log_evaluation(iteration, eval_result, difficulty)

                # Update curriculum / 커리큘럼 업데이트
                self.curriculum.update(eval_result["mean_score"])

                # Checkpoint on improvement / 향상 시 체크포인트
                if eval_result["mean_score"] > self._best_eval_score:
                    self._best_eval_score = eval_result["mean_score"]
                    self._save_checkpoint("best")

                logger.info(
                    "반복 %d / Iteration %d: eval_score=%.4f, difficulty=%.2f, "
                    "alpha/entropy=%.4f",
                    iteration, iteration,
                    eval_result["mean_score"],
                    difficulty,
                    losses.get("entropy", losses.get("alpha", 0.0)),
                )

            # Periodic checkpoint / 주기적 체크포인트
            if iteration % checkpoint_interval == 0:
                self._save_checkpoint(f"iter_{iteration}")

        elapsed = time.time() - start_time
        final_stats = {
            "total_iterations": n_iterations,
            "elapsed_seconds": elapsed,
            "final_mean_reward": float(np.mean(all_rewards[-100:])) if all_rewards else 0.0,
            "best_eval_score": self._best_eval_score,
            "final_difficulty": self.curriculum.level,
        }

        logger.info(
            "학습 완료 / Training complete: %s",
            {k: f"{v:.4f}" for k, v in final_stats.items()},
        )

        return final_stats

    def _train_ppo_step(self) -> Tuple[Dict[str, float], float]:
        """Execute one PPO training step (collect rollout + update). / PPO 학습 스텝 실행."""
        agent: PPOAgent = self.agent

        # Collect rollout / 롤아웃 수집
        buffer = agent.collect_rollout(self.env_step_fn, n_steps=2048)
        mean_reward = float(np.mean(buffer.rewards))

        # Update policy / 정책 업데이트
        losses = agent.update(buffer)

        return losses, mean_reward

    def _train_sac_step(self) -> Tuple[Dict[str, float], float]:
        """
        Execute one SAC training step (collect transitions + update).
        SAC 학습 스텝 실행 (전이 수집 + 업데이트).
        """
        agent: SACAgent = self.agent
        buffer = self._sac_buffer
        assert buffer is not None

        # Collect some transitions / 일부 전이 수집
        state = None
        step_rewards: List[float] = []

        for _ in range(256):  # Collect 256 transitions per iteration / 반복당 256 전이 수집
            if state is None:
                state, _, done, _ = self.env_step_fn(None)
                if done:
                    state, _, _, _ = self.env_step_fn(None)

            action = agent.select_action(state, evaluate=False)
            next_state, reward, done, info = self.env_step_fn(action)

            buffer.push(state, action, reward, next_state, done)
            step_rewards.append(reward)

            state = next_state if not done else None

        # Perform multiple gradient steps / 여러 그래디언트 스텝 수행
        total_losses = {"critic_loss": 0.0, "actor_loss": 0.0, "alpha": 0.0, "alpha_loss": 0.0}
        n_updates = 4  # Multiple updates per data collection / 데이터 수집당 여러 업데이트

        for _ in range(n_updates):
            losses = agent.update(buffer, batch_size=256)
            for k in total_losses:
                total_losses[k] += losses.get(k, 0.0)

        # Average over updates / 업데이트에 대해 평균
        for k in total_losses:
            total_losses[k] /= n_updates

        mean_reward = float(np.mean(step_rewards)) if step_rewards else 0.0
        return total_losses, mean_reward

    # ------------------------------------------------------------------
    # Evaluation / 평가
    # ------------------------------------------------------------------

    def evaluate(self, n_episodes: int = 10) -> Dict[str, float]:
        """
        Evaluate the current policy over multiple episodes.
        현재 정책을 여러 에피소드에 걸쳐 평가한다.

        Args:
            n_episodes: Number of evaluation episodes / 평가 에피소드 수

        Returns:
            Dict with mean_score, std_score, max_score, min_score, n_episodes
        """
        scores: List[float] = []

        for ep in range(n_episodes):
            state, _, done, info = self.env_step_fn(None)
            episode_reward = 0.0
            steps = 0
            max_steps = 500  # Safety limit / 안전 한계

            while not done and steps < max_steps:
                if isinstance(self.agent, PPOAgent):
                    action, _, _ = self.agent.ac.get_action(state, deterministic=True)
                else:
                    action = self.agent.select_action(state, evaluate=True)

                state, reward, done, info = self.env_step_fn(action)

                # Compute multi-objective reward if info has reward components
                # info에 보상 구성요소가 있으면 다목적 보상 계산
                if isinstance(info, dict) and "target_error" in info:
                    mo_reward = self.reward_fn.compute_total(info)
                    episode_reward += mo_reward
                else:
                    episode_reward += reward

                steps += 1

            scores.append(episode_reward)

        result = {
            "mean_score": float(np.mean(scores)),
            "std_score": float(np.std(scores)),
            "max_score": float(np.max(scores)),
            "min_score": float(np.min(scores)),
            "n_episodes": n_episodes,
        }

        logger.info(
            "평가 결과 / Evaluation: mean=%.3f ± %.3f (n=%d)",
            result["mean_score"], result["std_score"], n_episodes,
        )

        return result

    # ------------------------------------------------------------------
    # Checkpointing / 체크포인트
    # ------------------------------------------------------------------

    def _save_checkpoint(self, tag: str) -> None:
        """Save a training checkpoint. / 학습 체크포인트 저장."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"checkpoint_{tag}_{timestamp}.pt"
        path = self.checkpoint_dir / filename
        self.agent.save_policy(str(path))
        logger.info("체크포인트 저장 / Checkpoint saved: %s", path)


# ===========================================================================
# Utility functions / 유틸리티 함수
# ===========================================================================

def create_ppo_agent(
    state_dim: int = STATE_DIM,
    action_dim: int = ACTION_DIM,
    lr: float = 3e-4,
    device: Optional[str] = None,
) -> PPOAgent:
    """
    Factory function to create a PPO agent with default settings.
    기본 설정으로 PPO 에이전트를 생성하는 팩토리 함수.
    """
    dev = torch.device(device) if device else None
    return PPOAgent(state_dim=state_dim, action_dim=action_dim, lr=lr, device=dev)


def create_sac_agent(
    state_dim: int = STATE_DIM,
    action_dim: int = ACTION_DIM,
    lr: float = 3e-4,
    device: Optional[str] = None,
) -> SACAgent:
    """
    Factory function to create a SAC agent with default settings.
    기본 설정으로 SAC 에이전트를 생성하는 팩토리 함수.
    """
    dev = torch.device(device) if device else None
    return SACAgent(state_dim=state_dim, action_dim=action_dim, lr=lr, device=dev)


# ===========================================================================
# Quick self-test / 빠른 자체 테스트
# ===========================================================================

def _self_test() -> None:
    """
    Run a quick sanity check of all components.
    모든 구성요소의 빠른 건전성 검사를 실행.
    """
    print("=" * 60)
    print("rl_policy.py 자체 테스트 / Self-test")
    print("=" * 60)

    # 1. RolloutBuffer test
    print("\n[1] RolloutBuffer 테스트 / RolloutBuffer test...")
    buf = RolloutBuffer()
    for i in range(10):
        buf.insert(
            state=np.random.randn(STATE_DIM).astype(np.float32),
            action=np.random.randn(ACTION_DIM).astype(np.float32),
            reward=float(np.random.randn()),
            value=float(np.random.randn()),
            log_prob=float(np.random.randn()),
            done=(i == 9),
        )
    buf.compute_returns_and_advantages(last_value=0.0)
    assert buf.advantages is not None
    assert buf.returns is not None
    print(f"    버퍼 크기 / Buffer size: {len(buf)}")
    print(f"    어드밴티지 평균 / Advantages mean: {buf.advantages.mean():.4f}")
    print(f"    반환값 평균 / Returns mean: {buf.returns.mean():.4f}")

    # 2. ReplayBuffer test
    print("\n[2] ReplayBuffer 테스트 / ReplayBuffer test...")
    replay = ReplayBuffer(capacity=1000)
    for _ in range(500):
        replay.push(
            state=np.random.randn(STATE_DIM).astype(np.float32),
            action=np.random.randn(ACTION_DIM).astype(np.float32),
            reward=float(np.random.randn()),
            next_state=np.random.randn(STATE_DIM).astype(np.float32),
            done=bool(np.random.randint(2)),
        )
    batch = replay.sample(32)
    print(f"    버퍼 크기 / Buffer size: {len(replay)}")
    print(f"    샘플 배치 형태 / Sample batch shapes: "
          f"states={batch['states'].shape}, actions={batch['actions'].shape}")

    # 3. MLPActorCritic test
    print("\n[3] MLPActorCritic 테스트 / MLPActorCritic test...")
    ac = MLPActorCritic(STATE_DIM, ACTION_DIM)
    state = np.random.randn(STATE_DIM).astype(np.float32)
    action, log_prob, value = ac.get_action(state)
    print(f"    행동 형태 / Action shape: {action.shape}, 범위 / range: [{action.min():.3f}, {action.max():.3f}]")
    print(f"    로그 확률 / Log prob: {log_prob:.4f}, 가치 / Value: {value:.4f}")

    # Test evaluate_actions
    states_t = torch.randn(8, STATE_DIM)
    actions_t = torch.randn(8, ACTION_DIM).clamp(-0.99, 0.99)  # tanh range
    log_probs, entropy, values = ac.evaluate_actions(states_t, actions_t)
    print(f"    평가 로그 확률 / Eval log_probs shape: {log_probs.shape}")
    print(f"    엔트로피 평균 / Entropy mean: {entropy.mean():.4f}")

    # 4. PPOAgent test
    print("\n[4] PPOAgent 테스트 / PPOAgent test...")
    ppo = create_ppo_agent()

    def dummy_env(action):
        """Dummy environment for testing / 테스트용 더미 환경"""
        if action is None:
            return np.random.randn(STATE_DIM).astype(np.float32), 0.0, False, {}
        reward = float(-np.sum((action - 0.5) ** 2))  # Simple target / 간단한 타겟
        done = np.random.random() < 0.02
        return np.random.randn(STATE_DIM).astype(np.float32), reward, done, {}

    buffer = ppo.collect_rollout(dummy_env, n_steps=256)
    losses = ppo.update(buffer)
    print(f"    정책 손실 / Policy loss: {losses['policy_loss']:.4f}")
    print(f"    가치 손실 / Value loss: {losses['value_loss']:.4f}")
    print(f"    엔트로피 / Entropy: {losses['entropy']:.4f}")

    # 5. SACAgent test
    print("\n[5] SACAgent 테스트 / SACAgent test...")
    sac = create_sac_agent()
    sac_buffer = ReplayBuffer(capacity=5000)

    # Fill replay buffer / 재생 버퍼 채우기
    for _ in range(1000):
        sac_buffer.push(
            state=np.random.randn(STATE_DIM).astype(np.float32),
            action=np.random.uniform(-1, 1, ACTION_DIM).astype(np.float32),
            reward=float(np.random.randn()),
            next_state=np.random.randn(STATE_DIM).astype(np.float32),
            done=bool(np.random.randint(2)),
        )

    sac_losses = sac.update(sac_buffer, batch_size=64)
    print(f"    크리틱 손실 / Critic loss: {sac_losses['critic_loss']:.4f}")
    print(f"    행위자 손실 / Actor loss: {sac_losses['actor_loss']:.4f}")
    print(f"    온도 / Alpha: {sac_losses['alpha']:.4f}")

    # 6. MultiObjectiveReward test
    print("\n[6] MultiObjectiveReward 테스트 / MultiObjectiveReward test...")
    reward_fn = MultiObjectiveReward()
    experience = {
        "task_success": 0.9,
        "subtask_completion": 0.85,
        "target_error": 0.05,
        "position_error": 0.1,
        "energy_consumed": 2.5,
        "work_done": 0.8,
        "tilt_angle": 0.05,
        "vibration": 0.1,
        "max_jerk": 0.3,
        "elapsed_time": 3.0,
        "target_time": 5.0,
    }
    breakdown = reward_fn.get_breakdown(experience)
    for k, v in breakdown.items():
        print(f"    {k}: {v:.4f}")

    # 7. CurriculumScheduler test
    print("\n[7] CurriculumScheduler 테스트 / CurriculumScheduler test...")
    curriculum = CurriculumScheduler()
    for score in [0.6, 0.7, 0.8, 0.85, 0.9, 0.92]:
        diff = curriculum.update(score)
        print(f"    score={score:.2f} → difficulty={diff:.2f}")

    # 8. Save/Load test
    print("\n[8] 저장/로드 테스트 / Save/Load test...")
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        ppo_path = f"{tmpdir}/ppo_test.pt"
        sac_path = f"{tmpdir}/sac_test.pt"

        ppo.save_policy(ppo_path)
        ppo.load_policy(ppo_path)
        print(f"    PPO 저장/로드 성공 / PPO save/load OK")

        sac.save_policy(sac_path)
        sac.load_policy(sac_path)
        print(f"    SAC 저장/로드 성공 / SAC save/load OK")

    print("\n" + "=" * 60)
    print("모든 자체 테스트 통과 / All self-tests passed!")
    print("=" * 60)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )
    _self_test()


# ═══════════════════════════════════════════════════════════════════════════
# V8.5 Physical AGI 추가 클래스 / V8.5 Physical AGI Additional Classes
# ═══════════════════════════════════════════════════════════════════════════


class DiffusionPolicy:
    """
    디퓨전 정책 / Diffusion Policy.

    Google DeepMind의 Diffusion Policy 접근법을 구현합니다.
    노이즈에서 시작하여 점진적으로 행동을 정제하여 부드럽고
    자연스러운 행동을 생성합니다. 이는 로봇 제어의
    state-of-the-art 접근법입니다.

    핵심 아이디어:
        1. 조건부 노이즈에서 시작 (상태 + 언어 + 비전 조건)
        2. T 스텝의 디노이징으로 행동 궤적 생성
        3. 각 스텝에서 노이즈를 점진적으로 제거
        4. 최종 결과 = 부드럽고 일관된 행동 시퀀스

    Reference: Chi et al., "Diffusion Policy: Visuomotor Policy Learning
    via Action Diffusion", 2023

    Usage:
        policy = DiffusionPolicy(state_dim=62, action_dim=16)
        action = policy.predict_action(state, num_steps=10)
    """

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        action_dim: int = ACTION_DIM,
        num_diffusion_steps: int = 20,
        hidden_dim: int = 256,
        device: Optional[torch.device] = None,
    ) -> None:
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.num_diffusion_steps = num_diffusion_steps
        self.hidden_dim = hidden_dim

        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = device

        # ── 디노이징 네트워크 / Denoising network ──
        # ε_θ(s, a_t, t) → 예측된 노이즈 / Predicted noise
        self.denoiser = nn.Sequential(
            nn.Linear(state_dim + action_dim + 1, hidden_dim),  # +1 for timestep
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
        ).to(self.device)

        # 노이즈 스케줄 / Noise schedule (선형 / linear)
        self.betas = torch.linspace(1e-4, 0.02, num_diffusion_steps).to(self.device)
        self.alphas = 1.0 - self.betas
        self.alpha_cumprod = torch.cumprod(self.alphas, dim=0)

        self.optimizer = torch.optim.Adam(self.denoiser.parameters(), lr=3e-4)
        self._step_count = 0

        logger.info(
            "DiffusionPolicy 초기화: state=%d, action=%d, steps=%d, device=%s",
            state_dim, action_dim, num_diffusion_steps, self.device,
        )

    def predict_action(
        self,
        state: np.ndarray,
        num_steps: Optional[int] = None,
        temperature: float = 1.0,
    ) -> np.ndarray:
        """
        디퓨전 샘플링으로 행동 생성 / Generate action via diffusion sampling.

        Args:
            state: 현재 상태 [state_dim]
            num_steps: 디노이징 스텝 수 (None이면 기본값 사용)
            temperature: 샘플링 온도 (높을수록 더 무작위)

        Returns:
            행동 벡터 [action_dim], 범위 [-1, 1]
        """
        T = num_steps or self.num_diffusion_steps
        state_t = torch.tensor(state, dtype=torch.float32, device=self.device)

        # 순수 노이즈에서 시작 / Start from pure noise
        action = torch.randn(1, self.action_dim, device=self.device) * temperature

        for t_idx in reversed(range(T)):
            t_val = torch.tensor([t_idx / T], dtype=torch.float32, device=self.device)

            # 조건부 입력 / Conditional input
            cond = torch.cat([state_t.unsqueeze(0), action, t_val.unsqueeze(0)], dim=-1)

            # 노이즈 예측 / Predict noise
            predicted_noise = self.denoiser(cond)

            # DDPM 디노이징 스텝 / DDPM denoising step
            alpha_t = self.alphas[t_idx]
            alpha_cumprod_t = self.alpha_cumprod[t_idx]

            # x_0 예측 / Predict x_0
            x0_pred = (action - torch.sqrt(1 - alpha_cumprod_t) * predicted_noise) / torch.sqrt(alpha_cumprod_t)

            # 분산 계산 / Compute variance
            if t_idx > 0:
                noise = torch.randn_like(action) * temperature
                beta_t = self.betas[t_idx]
                action = (
                    torch.sqrt(alpha_t) * (1 - alpha_cumprod_t) / (1 - alpha_cumprod_t)
                    * action
                    + torch.sqrt(1 - alpha_t) * predicted_noise
                    + torch.sqrt(beta_t) * noise
                )
            else:
                action = x0_pred

        # tanh로 클램프 / Clamp with tanh
        action = torch.tanh(action.squeeze(0))
        return action.cpu().detach().numpy()

    def train_step(
        self,
        states: torch.Tensor,
        actions: torch.Tensor,
    ) -> Dict[str, float]:
        """
        디퓨전 정책 학습 스텝 / Diffusion policy training step.

        Args:
            states: [batch, state_dim]
            actions: [batch, action_dim]

        Returns:
            손실 딕셔너리
        """
        batch_size = states.shape[0]

        # 무작위 타임스텝 샘플링 / Sample random timesteps
        t = torch.randint(0, self.num_diffusion_steps, (batch_size,), device=self.device)

        # 노이즈 추가 / Add noise
        noise = torch.randn_like(actions)
        alpha_cumprod_t = self.alpha_cumprod[t].unsqueeze(-1)
        sqrt_alpha = torch.sqrt(alpha_cumprod_t)
        sqrt_one_minus_alpha = torch.sqrt(1 - alpha_cumprod_t)
        noisy_actions = sqrt_alpha * actions + sqrt_one_minus_alpha * noise

        # 노이즈 예측 / Predict noise
        t_norm = (t.float() / self.num_diffusion_steps).unsqueeze(-1)
        cond = torch.cat([states, noisy_actions, t_norm], dim=-1)
        predicted_noise = self.denoiser(cond)

        # 손실 / Loss
        loss = F.mse_loss(predicted_noise, noise)

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.denoiser.parameters(), 1.0)
        self.optimizer.step()

        self._step_count += 1
        return {"diffusion_loss": loss.item(), "step": self._step_count}

    def save_policy(self, path: str) -> None:
        """정책 저장 / Save policy."""
        torch.save({
            "denoiser": self.denoiser.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "step": self._step_count,
            "config": {
                "state_dim": self.state_dim,
                "action_dim": self.action_dim,
                "num_diffusion_steps": self.num_diffusion_steps,
            },
        }, path)
        logger.info("DiffusionPolicy 저장 완료: %s", path)

    def load_policy(self, path: str) -> None:
        """정책 로드 / Load policy."""
        ckpt = torch.load(path, map_location=self.device, weights_only=False)
        self.denoiser.load_state_dict(ckpt["denoiser"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self._step_count = ckpt.get("step", 0)
        logger.info("DiffusionPolicy 로드 완료: %s", path)


class H2OActionPredictor:
    """
    H2O 행동 예측기 / H2O Action Predictor.

    언어 + 비전 + 고유수용감(proprioception)으로부터 행동을 예측합니다.
    인간의 "Hand-Object" 상호작용(H2O)에서 영감을 받아,
    다양한 모달리티를 융합하여 물리적 행동을 생성합니다.

    Usage:
        predictor = H2OActionPredictor()
        action = predictor.predict(
            language_instruction="pick up the red cup",
            visual_features=np.random.randn(128),
            proprioceptive_state=current_state_vector,
        )
    """

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        action_dim: int = ACTION_DIM,
        language_dim: int = 128,
        visual_dim: int = 128,
        hidden_dim: int = 256,
        device: Optional[torch.device] = None,
    ) -> None:
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.language_dim = language_dim
        self.visual_dim = visual_dim

        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = device

        # ── 모달리티별 인코더 / Per-modality encoders ──
        total_input = language_dim + visual_dim + state_dim

        self.language_encoder = nn.Sequential(
            nn.Linear(language_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        ).to(self.device)

        self.visual_encoder = nn.Sequential(
            nn.Linear(visual_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        ).to(self.device)

        self.proprio_encoder = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        ).to(self.device)

        # ── 융합 + 행동 헤드 / Fusion + action head ──
        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, action_dim),
            nn.Tanh(),
        ).to(self.device)

        # ── 크로스 어텐션 (간소화) / Simplified cross-attention ──
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=hidden_dim, num_heads=4, batch_first=True,
        ).to(self.device)

        self.optimizer = torch.optim.Adam(
            list(self.language_encoder.parameters())
            + list(self.visual_encoder.parameters())
            + list(self.proprio_encoder.parameters())
            + list(self.fusion.parameters())
            + list(self.cross_attn.parameters()),
            lr=3e-4,
        )

        logger.info(
            "H2OActionPredictor 초기화: lang=%d, vis=%d, state=%d → action=%d",
            language_dim, visual_dim, state_dim, action_dim,
        )

    def predict(
        self,
        language_instruction: Optional[str] = None,
        language_features: Optional[np.ndarray] = None,
        visual_features: Optional[np.ndarray] = None,
        proprioceptive_state: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """
        다중 모달리티 행동 예측 / Predict action from multiple modalities.

        Args:
            language_instruction: 언어 지시 (텍스트)
            language_features: 언어 특징 벡터 (사전 인코딩된 경우)
            visual_features: 시각 특징 벡터
            proprioceptive_state: 고유수용감 상태 벡터

        Returns:
            예측된 행동 [action_dim]
        """
        # 언어 특징 / Language features
        if language_features is not None:
            lang_feat = torch.tensor(
                language_features.flatten()[:self.language_dim], dtype=torch.float32
            ).to(self.device)
        elif language_instruction is not None:
            # 간소화된 텍스트 인코딩 (해시 기반) / Simplified text encoding (hash-based)
            lang_feat = self._simple_text_encode(language_instruction)
        else:
            lang_feat = torch.zeros(self.language_dim, device=self.device)

        # 시각 특징 / Visual features
        if visual_features is not None:
            vis_feat = torch.tensor(
                visual_features.flatten()[:self.visual_dim], dtype=torch.float32
            ).to(self.device)
        else:
            vis_feat = torch.zeros(self.visual_dim, device=self.device)

        # 고유수용감 / Proprioception
        if proprioceptive_state is not None:
            prop_feat = torch.tensor(
                proprioceptive_state.flatten()[:self.state_dim], dtype=torch.float32
            ).to(self.device)
        else:
            prop_feat = torch.zeros(self.state_dim, device=self.device)

        # 인코딩 / Encode
        lang_enc = self.language_encoder(lang_feat.unsqueeze(0))      # [1, hidden]
        vis_enc = self.visual_encoder(vis_feat.unsqueeze(0))          # [1, hidden]
        prop_enc = self.proprio_encoder(prop_feat.unsqueeze(0))       # [1, hidden]

        # 크로스 어텐션 / Cross-attention
        stacked = torch.stack([lang_enc, vis_enc, prop_enc], dim=1)   # [1, 3, hidden]
        attn_out, _ = self.cross_attn(stacked, stacked, stacked)      # [1, 3, hidden]
        fused_attn = attn_out.mean(dim=1)                              # [1, hidden]

        # 융합 / Fusion
        concat = torch.cat([lang_enc, vis_enc, prop_enc], dim=-1)     # [1, hidden*3]
        action = self.fusion(concat)                                    # [1, action_dim]

        return action.squeeze(0).cpu().detach().numpy()

    def _simple_text_encode(self, text: str) -> torch.Tensor:
        """간소화된 텍스트 인코딩 (해시 기반) / Simplified text encoding via hashing."""
        features = torch.zeros(self.language_dim, device=self.device)
        words = text.lower().split()
        for word in words:
            h = hash(word) % self.language_dim
            features[h] = 1.0
        # 정규화 / Normalize
        norm = features.norm()
        if norm > 1e-8:
            features = features / norm
        return features

    def train_step(
        self,
        language_features: torch.Tensor,
        visual_features: torch.Tensor,
        state_features: torch.Tensor,
        target_actions: torch.Tensor,
    ) -> Dict[str, float]:
        """학습 스텝 / Training step."""
        lang_enc = self.language_encoder(language_features)
        vis_enc = self.visual_encoder(visual_features)
        prop_enc = self.proprio_encoder(state_features)

        concat = torch.cat([lang_enc, vis_enc, prop_enc], dim=-1)
        pred_actions = self.fusion(concat)

        loss = F.mse_loss(pred_actions, target_actions)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return {"h2o_loss": loss.item()}


class MultiTaskPolicy:
    """
    다중 작업 정책 / Multi-Task Policy.

    단일 정책으로 여러 작업을 처리합니다.
    작업 ID 또는 언어 지시에 따라 조건부로 행동을 생성합니다.

    Usage:
        policy = MultiTaskPolicy(tasks=["walk", "grasp", "carry"])
        action = policy.predict(state, task_id="grasp")
    """

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        action_dim: int = ACTION_DIM,
        task_embedding_dim: int = 32,
        num_tasks: int = 10,
        hidden_dim: int = 256,
        device: Optional[torch.device] = None,
    ) -> None:
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.task_embedding_dim = task_embedding_dim
        self.num_tasks = num_tasks

        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = device

        # ── 작업 임베딩 / Task embeddings ──
        self.task_embeddings = nn.Embedding(num_tasks, task_embedding_dim).to(self.device)

        # ── 공유 백본 / Shared backbone ──
        self.shared_backbone = nn.Sequential(
            nn.Linear(state_dim + task_embedding_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        ).to(self.device)

        # ── 작업별 헤드 / Per-task heads ──
        self.task_heads = nn.ModuleDict({
            "default": nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim // 2),
                nn.ReLU(),
                nn.Linear(hidden_dim // 2, action_dim),
                nn.Tanh(),
            ),
        }).to(self.device)

        # ── 작업 이름 → ID 매핑 / Task name → ID mapping ──
        self._task_name_to_id: Dict[str, int] = {}
        self._next_task_id: int = 0

        self.optimizer = torch.optim.Adam(
            list(self.task_embeddings.parameters())
            + list(self.shared_backbone.parameters())
            + list(self.task_heads.parameters()),
            lr=3e-4,
        )

        logger.info(
            "MultiTaskPolicy 초기화: state=%d, action=%d, max_tasks=%d",
            state_dim, action_dim, num_tasks,
        )

    def register_task(self, task_name: str) -> int:
        """
        새 작업 등록 / Register a new task.

        Args:
            task_name: 작업 이름

        Returns:
            작업 ID
        """
        if task_name in self._task_name_to_id:
            return self._task_name_to_id[task_name]

        if self._next_task_id >= self.num_tasks:
            logger.warning("최대 작업 수 초과: %s", task_name)
            return 0

        task_id = self._next_task_id
        self._task_name_to_id[task_name] = task_id
        self._next_task_id += 1

        # 작업별 헤드 추가 / Add task-specific head
        self.task_heads[task_name] = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, self.action_dim),
            nn.Tanh(),
        ).to(self.device)

        logger.info("작업 등록: '%s' → ID %d", task_name, task_id)
        return task_id

    def predict(
        self,
        state: np.ndarray,
        task_id: Optional[int] = None,
        task_name: Optional[str] = None,
        deterministic: bool = True,
    ) -> np.ndarray:
        """
        작업 조건부 행동 예측 / Predict task-conditioned action.

        Args:
            state: 현재 상태
            task_id: 작업 ID
            task_name: 작업 이름 (task_id 대신 사용 가능)
            deterministic: 결정론적 여부

        Returns:
            행동 벡터
        """
        state_t = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)

        # 작업 ID 결정 / Determine task ID
        if task_id is None and task_name is not None:
            task_id = self._task_name_to_id.get(task_name, 0)
        if task_id is None:
            task_id = 0

        # 작업 임베딩 / Task embedding
        task_emb = self.task_embeddings(
            torch.tensor([task_id], dtype=torch.long, device=self.device)
        )

        # 공유 백본 / Shared backbone
        combined = torch.cat([state_t, task_emb], dim=-1)
        shared_features = self.shared_backbone(combined)

        # 작업별 헤드 선택 / Select task-specific head
        head_name = task_name if task_name and task_name in self.task_heads else "default"
        head = self.task_heads[head_name]
        action = head(shared_features)

        if not deterministic:
            noise = torch.randn_like(action) * 0.1
            action = action + noise

        return action.squeeze(0).cpu().detach().numpy()

    def train_step(
        self,
        states: torch.Tensor,
        actions: torch.Tensor,
        task_ids: torch.Tensor,
        task_names: Optional[List[str]] = None,
    ) -> Dict[str, float]:
        """
        다중 작업 학습 스텝 / Multi-task training step.

        Args:
            states: [batch, state_dim]
            actions: [batch, action_dim]
            task_ids: [batch] 작업 ID
            task_names: 작업 이름 리스트 (선택적)

        Returns:
            손실 딕셔너리
        """
        task_emb = self.task_embeddings(task_ids)
        combined = torch.cat([states, task_emb], dim=-1)
        shared_features = self.shared_backbone(combined)

        # 기본 헤드로 손실 계산 / Compute loss with default head
        pred_actions = self.task_heads["default"](shared_features)
        loss = F.mse_loss(pred_actions, actions)

        # 작업별 헤드가 있으면 추가 손실 / Additional loss for task-specific heads
        if task_names:
            for tname in set(task_names):
                if tname in self.task_heads and tname != "default":
                    mask = torch.tensor(
                        [1.0 if n == tname else 0.0 for n in task_names],
                        dtype=torch.float32, device=self.device,
                    ).unsqueeze(-1)
                    task_pred = self.task_heads[tname](shared_features)
                    task_loss = F.mse_loss(task_pred * mask, actions * mask)
                    loss = loss + 0.5 * task_loss

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.shared_backbone.parameters(), 1.0)
        self.optimizer.step()

        return {"multitask_loss": loss.item()}

    def save_policy(self, path: str) -> None:
        """정책 저장 / Save policy."""
        torch.save({
            "task_embeddings": self.task_embeddings.state_dict(),
            "shared_backbone": self.shared_backbone.state_dict(),
            "task_heads": {k: v.state_dict() for k, v in self.task_heads.items()},
            "task_name_to_id": self._task_name_to_id,
            "next_task_id": self._next_task_id,
            "optimizer": self.optimizer.state_dict(),
        }, path)
        logger.info("MultiTaskPolicy 저장 완료: %s", path)

    def load_policy(self, path: str) -> None:
        """정책 로드 / Load policy."""
        ckpt = torch.load(path, map_location=self.device, weights_only=False)
        self.task_embeddings.load_state_dict(ckpt["task_embeddings"])
        self.shared_backbone.load_state_dict(ckpt["shared_backbone"])
        for k, v in ckpt["task_heads"].items():
            if k in self.task_heads:
                self.task_heads[k].load_state_dict(v)
        self._task_name_to_id = ckpt.get("task_name_to_id", {})
        self._next_task_id = ckpt.get("next_task_id", 0)
        self.optimizer.load_state_dict(ckpt["optimizer"])
        logger.info("MultiTaskPolicy 로드 완료: %s", path)
