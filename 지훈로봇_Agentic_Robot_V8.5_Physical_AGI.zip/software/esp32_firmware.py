#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TODO 6: ESP32-S3 펌웨어 빌드 환경
====================================================

ESP-IDF v5.3 기반 ESP32-S3-WROOM-1 N8R8 펌웨어
역할:
  - 웨이크워드 감지 (저전력 상시 대기)
  - FSR-402 ADC 촉각 센서 읽기
  - BMS UART 모니터링
  - Jetson #2 UART 통신 (921600bps)

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from hardware.config import ESP32Config, JihunRobotV7Config

logger = logging.getLogger("jihun.v84.esp32_firmware")

# ============================================================================
# 상수
# ============================================================================

ESP_IDF_VERSION = "v5.3"
ESP_IDF_PATH = Path.home() / "esp" / "esp-idf"
ESP_PORT = "/dev/ttyUSB0"
ESP_BAUDRATE = 921600

# 펌웨어 프로젝트 경로
FIRMWARE_DIR = Path("/home/z/my-project/download/jihun-robot-v7/esp32")

CONFIG_DIR = Path("/opt/jihun")


@dataclass
class ESP32BuildResult:
    """ESP32 빌드 결과"""
    success: bool = False
    build_time_s: float = 0.0
    firmware_size_kb: int = 0
    flash_ok: bool = False
    monitor_ok: bool = False
    errors: List[str] = field(default_factory=list)


class ESP32Firmware:
    """
    TODO 6: ESP32-S3 펌웨어 빌드 환경

    기능:
      - ESP-IDF v5.3 환경 확인
      - 펌웨어 빌드
      - 플래시
      - 시리얼 모니터
    """

    def __init__(self, config: Optional[JihunRobotV7Config] = None):
        self.config = config or JihunRobotV7Config()
        self.esp32 = self.config.compute.esp32
        self._build_result: Optional[ESP32BuildResult] = None

    # ========================================================================
    # 공용 메서드
    # ========================================================================

    def setup(self) -> bool:
        """전체 ESP32 펌웨어 빌드 환경 설정"""
        logger.info("=== ESP32-S3 펌웨어 빌드 환경 설정 ===")

        # 1. ESP-IDF 확인
        if not self._check_esp_idf():
            logger.error("ESP-IDF 미설치")
            return False

        # 2. 펌웨어 소스 확인
        if not self._check_firmware_source():
            logger.error("펌웨어 소스 없음")
            return False

        # 3. 빌드
        result = self.build()
        if not result.success:
            logger.error("펌웨어 빌드 실패")
            return False

        logger.info("=== ESP32-S3 펌웨어 빌드 환경 설정 완료 ===")
        return True

    def verify(self) -> bool:
        """빌드 환경 검증"""
        return self._check_esp_idf()

    # ========================================================================
    # ESP-IDF 환경 확인
    # ========================================================================

    def _check_esp_idf(self) -> bool:
        """ESP-IDF v5.3 설치 확인"""
        if ESP_IDF_PATH.exists():
            logger.info(f"  ✓ ESP-IDF 경로: {ESP_IDF_PATH}")
            return True

        # 대체 경로 확인
        try:
            result = subprocess.run(
                ["idf.py", "--version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                logger.info(f"  ✓ ESP-IDF: {result.stdout.strip()}")
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        logger.error("  ✗ ESP-IDF 미설치")
        logger.info("  설치: https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/get-started/")
        return False

    def _check_firmware_source(self) -> bool:
        """펌웨어 소스 파일 확인"""
        required_files = [
            FIRMWARE_DIR / "CMakeLists.txt",
            FIRMWARE_DIR / "main" / "main.c",
        ]
        for f in required_files:
            if not f.exists():
                logger.warning(f"  펌웨어 소스 없음: {f}")
                return False
        logger.info("  ✓ 펌웨어 소스 확인")
        return True

    # ========================================================================
    # 빌드 / 플래시 / 모니터
    # ========================================================================

    def build(self) -> ESP32BuildResult:
        """ESP32-S3 펌웨어 빌드"""
        result = ESP32BuildResult()
        start = time.time()

        logger.info("ESP32-S3 펌웨어 빌드 중...")

        try:
            build_cmd = (
                f"cd {FIRMWARE_DIR} && "
                f". {ESP_IDF_PATH}/export.sh && "
                "idf.py build"
            )
            proc = subprocess.run(
                ["bash", "-c", build_cmd],
                capture_output=True, text=True, timeout=300,
            )

            result.build_time_s = time.time() - start

            if proc.returncode == 0:
                result.success = True
                # 펌웨어 크기 확인
                fw_path = FIRMWARE_DIR / "build" / "jihun_firmware.bin"
                if fw_path.exists():
                    result.firmware_size_kb = fw_path.stat().st_size // 1024
                logger.info(
                    f"  ✓ 빌드 성공 ({result.build_time_s:.1f}s, "
                    f"{result.firmware_size_kb}KB)"
                )
            else:
                result.success = False
                result.errors.append(proc.stderr[-500:] if proc.stderr else "빌드 오류")
                logger.error(f"  ✗ 빌드 실패: {result.errors[0][:200]}")

        except subprocess.TimeoutExpired:
            result.errors.append("빌드 타임아웃 (300s)")
            logger.error("  ✗ 빌드 타임아웃")

        self._build_result = result
        return result

    def flash(self, port: str = ESP_PORT) -> bool:
        """ESP32-S3 펌웨어 플래시"""
        logger.info(f"ESP32-S3 펌웨어 플래시 중... (port={port})")

        try:
            flash_cmd = (
                f"cd {FIRMWARE_DIR} && "
                f". {ESP_IDF_PATH}/export.sh && "
                f"idf.py -p {port} flash"
            )
            proc = subprocess.run(
                ["bash", "-c", flash_cmd],
                capture_output=True, text=True, timeout=120,
            )

            if proc.returncode == 0:
                logger.info("  ✓ 플래시 성공")
                return True
            else:
                logger.error(f"  ✗ 플래시 실패: {proc.stderr[-300:]}")
                return False

        except subprocess.TimeoutExpired:
            logger.error("  ✗ 플래시 타임아웃")
            return False

    def monitor(self, port: str = ESP_PORT) -> None:
        """ESP32-S3 시리얼 모니터"""
        logger.info(f"ESP32-S3 모니터 시작 (port={port})")

        try:
            monitor_cmd = (
                f"cd {FIRMWARE_DIR} && "
                f". {ESP_IDF_PATH}/export.sh && "
                f"idf.py -p {port} monitor"
            )
            subprocess.run(["bash", "-c", monitor_cmd])
        except KeyboardInterrupt:
            logger.info("모니터 종료")

    def flash_and_monitor(self, port: str = ESP_PORT) -> bool:
        """플래시 후 모니터"""
        if self.flash(port):
            self.monitor(port)
            return True
        return False
