#!/usr/bin/env python3
"""
sim_experience_generator.py — V8.5 Simulation-Based Synthetic Experience Generator
지훈 로봇 물리적 AGI — V8.5 시뮬레이션 기반 합성 경험 생성기

Real robots cannot collect enough training data through physical interaction alone.
Simulation generates vast quantities of synthetic experiences, which — combined
with domain randomization — transfer effectively to the real world.

실제 로봇은 물리적 상호작용만으로 충분한 학습 데이터를 수집할 수 없습니다.
시뮬레이션은 대량의 합성 경험을 생성하며, 도메인 랜덤화와 결합하면
실제 환경으로 효과적으로 전이됩니다.

Components / 구성요소:
  1. PhysicsSimulator       — 단순화된 물리 시뮬레이터
  2. SyntheticExperienceGenerator — 시뮬레이션에서 학습 경험 생성
  3. DomainRandomizer       — 시뮬레이션 파라미터 랜덤화
  4. ExperienceQualityFilter — 합성 경험 품질 필터

Simulation Physics / 시뮬레이션 물리:
  - 중력: 9.81 m/s²
  - 마찰: 도메인 랜덤화 (0.1 ~ 0.9)
  - 질량: 기본값의 0.5x ~ 2x
  - 센서 노이즈: 가우시안
  - 충돌: 단순 탄성 모델
  - 관절 제한: 하드 리미트

Hardware: Dual Jetson Orin NX 16GB
AI Model: Gemma 4 E4B Q4_K_M
Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.sim_experience_generator")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 상수 / Constants ────────────────────────────────────────────────────────

GRAVITY = 9.81          # m/s²
STATE_DIM = 62          # PhysicalState 벡터 차원
STATE_ACTUAL_DIM = 41   # 실제 상태 차원 (3+3+4+3+12+12+4=41)
ACTION_DIM = 16         # 행동 파라미터 차원
DT_DEFAULT = 0.01       # 시뮬레이션 타임스텝 (초)
COLLISION_RESTITUTION = 0.3  # 충돌 탄성 계수
NOISE_STD = 0.02        # 센서 노이즈 표준편차
MAX_CURRICULUM_LEVEL = 10
ROBOT_RADIUS = 0.15     # 로봇 구형 충돌 반경 (m)
LEG_RADIUS = 0.03       # 다리 끝 구형 반경 (m)
NUM_LEGS = 4            # 다리 수


class TerrainType(str, Enum):
    """지형 유형 / Terrain types."""
    FLAT = "flat"
    CARPET = "carpet"
    GRAVEL = "gravel"
    SLOPE = "slope"
    STAIRS = "stairs"
    UNEVEN = "uneven"
    WET = "wet"
    SAND = "sand"


class ObjectType(str, Enum):
    """객체 유형 / Object types."""
    RIGID_BOX = "rigid_box"
    SOFT_BALL = "soft_ball"
    CYLINDER = "cylinder"
    FRAGILE = "fragile"
    HEAVY = "heavy"
    SLIPPERY = "slippery"
    IRREGULAR = "irregular"


# ─── 데이터 클래스 / Data Classes ────────────────────────────────────────────


@dataclass
class SimState:
    """
    시뮬레이션 상태 / Simulation state.

    로봇의 물리적 상태를 나타냅니다.

    Attributes:
        position: 3D 위치 [x, y, z] (m)
        velocity: 3D 속도 [vx, vy, vz] (m/s)
        orientation: 4D 자세 [qw, qx, qy, qz] (쿼터니언)
        angular_vel: 3D 각속도 [wx, wy, wz] (rad/s)
        joint_angles: 관절 각도 배열 (rad)
        joint_velocities: 관절 속도 배열 (rad/s)
        contact_forces: 접촉력 배열 (N)
    """
    position: np.ndarray = field(default_factory=lambda: np.zeros(3))
    velocity: np.ndarray = field(default_factory=lambda: np.zeros(3))
    orientation: np.ndarray = field(
        default_factory=lambda: np.array([1.0, 0.0, 0.0, 0.0])
    )
    angular_vel: np.ndarray = field(default_factory=lambda: np.zeros(3))
    joint_angles: np.ndarray = field(
        default_factory=lambda: np.zeros(12)  # 6관절 x 2다리
    )
    joint_velocities: np.ndarray = field(
        default_factory=lambda: np.zeros(12)
    )
    contact_forces: np.ndarray = field(
        default_factory=lambda: np.zeros(4)  # 4 접촉점
    )

    def to_vector(self) -> np.ndarray:
        """상태 벡터로 변환 (62차원) / Convert to state vector (62-dim).

        Layout: position(3) + velocity(3) + orientation(4) + angular_vel(3)
                + joint_angles(12) + joint_velocities(12) + contact_forces(4)
                + padding(21)
        The 21-dim padding stores leg foot positions (4×3=12) + ground flags (4)
                + reserved (5) for future use.
        """
        parts = [
            self.position,           # 3
            self.velocity,           # 3
            self.orientation,        # 4
            self.angular_vel,        # 3
            self.joint_angles,       # 12
            self.joint_velocities,   # 12
            self.contact_forces,     # 4
        ]
        vec = np.concatenate(parts)
        # 62차원으로 패딩 / Pad to 62 dimensions
        if len(vec) < STATE_DIM:
            vec = np.concatenate([vec, np.zeros(STATE_DIM - len(vec))])
        return vec[:STATE_DIM].astype(np.float32)

    @classmethod
    def from_vector(cls, vec: np.ndarray) -> "SimState":
        """상태 벡터에서 복원 / Restore from state vector.

        Lossless round-trip: extracts all 41 actual dims from the 62-dim vector.
        Padding data (indices 41-61) is discarded as it's derived geometry.
        """
        vec = vec.flatten()[:STATE_DIM]  # 보존: 62차원 모두 사용
        return cls(
            position=vec[0:3].copy(),
            velocity=vec[3:6].copy(),
            orientation=vec[6:10].copy(),
            angular_vel=vec[10:13].copy(),
            joint_angles=vec[13:25].copy(),
            joint_velocities=vec[25:37].copy(),
            contact_forces=vec[37:41].copy(),
        )


@dataclass
class SimAction:
    """
    시뮬레이션 행동 / Simulation action.

    Attributes:
        joint_targets: 목표 관절 각도 (rad)
        grip_force: 파지력 (N)
        locomotion_velocity: 이동 속도 명령 [vx, vy, ω]
    """
    joint_targets: np.ndarray = field(
        default_factory=lambda: np.zeros(12)
    )
    grip_force: float = 0.0
    locomotion_velocity: np.ndarray = field(
        default_factory=lambda: np.zeros(3)
    )

    def to_vector(self) -> np.ndarray:
        """행동 벡터로 변환 (16차원) / Convert to action vector (16-dim)."""
        parts = [
            self.joint_targets,         # 12
            np.array([self.grip_force]),  # 1
            self.locomotion_velocity,    # 3
        ]
        vec = np.concatenate(parts)
        if len(vec) < ACTION_DIM:
            vec = np.concatenate([vec, np.zeros(ACTION_DIM - len(vec))])
        return vec[:ACTION_DIM].astype(np.float32)


@dataclass
class SimExperience:
    """
    시뮬레이션 경험 / Simulation experience.

    하나의 전이 (transition) 를 나타냅니다.

    Attributes:
        state_before: 행동 전 상태
        action: 수행된 행동
        state_after: 행동 후 상태
        reward: 보상 값
        metadata: 추가 메타데이터 (지형, 객체, 난이도 등)
        experience_id: 경험 식별자
        timestamp: 생성 시각
    """
    state_before: np.ndarray = field(default_factory=lambda: np.zeros(STATE_DIM))
    action: np.ndarray = field(default_factory=lambda: np.zeros(ACTION_DIM))
    state_after: np.ndarray = field(default_factory=lambda: np.zeros(STATE_DIM))
    reward: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    experience_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ─── 물리 시뮬레이터 / Physics Simulator ─────────────────────────────────────


class PhysicsSimulator:
    """
    단순화된 물리 시뮬레이터 / Simplified physics simulator.

    로봇의 물리적 상호작용을 단순화된 모델로 시뮬레이션합니다.
    중력, 마찰, 충돌, 관절 제한을 처리합니다.
    도메인 랜덤화를 통해 실제 환경의 다양성을 모사합니다.

    Usage:
        sim = PhysicsSimulator(friction=0.5, mass_scale=1.0)
        next_state = sim.simulate_step(state, action, dt=0.01)
    """

    def __init__(
        self,
        friction: float = 0.5,
        mass_scale: float = 1.0,
        sensor_noise_std: float = NOISE_STD,
        gravity: float = GRAVITY,
    ) -> None:
        self._friction = friction
        self._mass_scale = mass_scale
        self._sensor_noise_std = sensor_noise_std
        self._gravity = gravity

        # 로봇 기본 파라미터 / Default robot parameters
        self._base_mass = 5.0  # kg
        self._base_height = 0.3  # m
        self._joint_limits = (-math.pi * 0.8, math.pi * 0.8)  # rad

        logger.info(
            "PhysicsSimulator 초기화: 마찰=%.2f, 질량배율=%.2f, 노이즈=%.3f",
            friction, mass_scale, sensor_noise_std,
        )

    @staticmethod
    def _quaternion_multiply(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
        """쿼터니언 곱셈 / Quaternion multiplication (w, x, y, z format)."""
        w1, x1, y1, z1 = q1
        w2, x2, y2, z2 = q2
        return np.array([
            w1*w2 - x1*x2 - y1*y2 - z1*z2,
            w1*x2 + x1*w2 + y1*z2 - z1*y2,
            w1*y2 - x1*z2 + y1*w2 + z1*x2,
            w1*z2 + x1*y2 - y1*x2 + z1*w2,
        ])

    @staticmethod
    def _quaternion_normalize(q: np.ndarray) -> np.ndarray:
        """쿼터니언 정규화 / Normalize quaternion."""
        norm = np.linalg.norm(q)
        if norm < 1e-10:
            return np.array([1.0, 0.0, 0.0, 0.0])
        return q / norm

    def _integrate_orientation(
        self, orientation: np.ndarray, angular_vel: np.ndarray, dt: float
    ) -> np.ndarray:
        """각속도로부터 쿼터니언 적분 / Integrate quaternion from angular velocity.

        Uses first-order Rodrigues integration:
          q_dot = 0.5 * omega_quat * q
          q_new = q + q_dot * dt, then normalize.

        Args:
            orientation: 현재 쿼터니언 [w, x, y, z]
            angular_vel: 각속도 [wx, wy, wz] (rad/s)
            dt: 타임스텝

        Returns:
            np.ndarray: 업데이트된 쿼터니언
        """
        wx, wy, wz = angular_vel
        omega_quat = np.array([0.0, wx, wy, wz])

        q_dot = 0.5 * self._quaternion_multiply(omega_quat, orientation)
        new_q = orientation + q_dot * dt
        return self._quaternion_normalize(new_q)

    @staticmethod
    def _sphere_plane_collision(
        center: np.ndarray, radius: float, ground_z: float = 0.0,
        restitution: float = COLLISION_RESTITUTION,
    ) -> Tuple[np.ndarray, bool, float]:
        """구-평면 충돌 감지 및 응답 / Sphere-plane collision detection and response.

        Args:
            center: 구 중심 위치 [x, y, z]
            radius: 구 반경
            ground_z: 지면 높이 (기본 0.0)
            restitution: 탄성 계수

        Returns:
            Tuple: (수정된 위치, 충돌 여부, 침투 깊이)
        """
        penetration = ground_z + radius - center[2]
        if penetration > 0.0:
            corrected_center = center.copy()
            corrected_center[2] = ground_z + radius
            return corrected_center, True, penetration
        return center, False, 0.0

    def _compute_leg_positions(
        self, state: SimState,
    ) -> List[np.ndarray]:
        """관절 각도로부터 다리 끝점 위치 계산 / Compute leg foot positions from joint angles.

        Simple 2-segment forward kinematics for each leg.
        Each leg has hip (yaw) + knee (pitch) joints.

        Args:
            state: 현재 상태

        Returns:
            List[np.ndarray]: 4개 다리 끝점 위치 (월드 좌표)
        """
        foot_positions = []
        leg_offsets = [
            np.array([0.1, 0.1, 0.0]),    # 전방좌 / Front-left
            np.array([0.1, -0.1, 0.0]),   # 전방우 / Front-right
            np.array([-0.1, 0.1, 0.0]),   # 후방좌 / Rear-left
            np.array([-0.1, -0.1, 0.0]),  # 후방우 / Rear-right
        ]
        upper_leg_len = 0.15  # m
        lower_leg_len = 0.15  # m

        for leg_idx in range(NUM_LEGS):
            hip_angle = state.joint_angles[leg_idx * 3] if leg_idx * 3 < 12 else 0.0
            knee_angle = state.joint_angles[leg_idx * 3 + 1] if leg_idx * 3 + 1 < 12 else 0.0

            # 힙 오프셋 + 다리 길이 방향 / Hip offset + leg direction
            hip_pos = state.position + leg_offsets[leg_idx]
            knee_pos = hip_pos + np.array([
                0.0,
                np.sin(hip_angle) * upper_leg_len,
                -np.cos(hip_angle) * upper_leg_len,
            ])
            foot_pos = knee_pos + np.array([
                0.0,
                np.sin(hip_angle + knee_angle) * lower_leg_len,
                -np.cos(hip_angle + knee_angle) * lower_leg_len,
            ])
            foot_positions.append(foot_pos)

        return foot_positions

    def simulate_step(
        self,
        state: SimState,
        action: SimAction,
        dt: float = DT_DEFAULT,
    ) -> SimState:
        """
        한 스텝 시뮬레이션 / Simulate one step.

        중력, 마찰, 충돌(구-평면), 관절 제한, 쿼터니언 적분, 다리-지면 상호작용을
        적용하여 다음 상태를 계산합니다.

        Args:
            state: 현재 상태
            action: 수행할 행동
            dt: 타임스텝 (초)

        Returns:
            SimState: 다음 상태
        """
        mass = self._base_mass * self._mass_scale

        # ── 중력 적용 / Apply gravity ──────────────────────────────
        gravity_acc = np.array([0.0, 0.0, -self._gravity])

        # 지면 접촉 시 수직 속도 제한 / Ground contact: limit vertical velocity
        on_ground = state.position[2] <= self._base_height + 0.01
        if on_ground:
            gravity_acc[2] = 0.0

        # ── 속도 업데이트 / Velocity update ─────────────────────────
        new_velocity = state.velocity.copy()

        # 이동 속도 명령 적용 / Apply locomotion velocity command
        new_velocity[0] += action.locomotion_velocity[0] * dt
        new_velocity[1] += action.locomotion_velocity[1] * dt

        # 중력 효과 / Gravity effect
        new_velocity += gravity_acc * dt

        # ── 마찰 적용 / Apply friction ─────────────────────────────
        horizontal_vel = new_velocity[:2]
        speed = np.linalg.norm(horizontal_vel)
        if speed > 0.0:
            friction_decel = self._friction * self._gravity * dt
            if friction_decel >= speed:
                new_velocity[:2] = 0.0
            else:
                new_velocity[:2] *= (1.0 - friction_decel / speed)

        # ── 관절 각도 업데이트 / Update joint angles ───────────────
        new_joint_angles = state.joint_angles.copy()
        joint_diff = action.joint_targets - state.joint_angles
        # PD 제어기 모방 / Mimic PD controller
        kp = 10.0
        kd = 2.0
        joint_acc = kp * joint_diff - kd * state.joint_velocities
        new_joint_velocities = state.joint_velocities + joint_acc * dt
        new_joint_angles += new_joint_velocities * dt

        # 관절 제한 적용 / Apply joint limits
        new_joint_angles = np.clip(
            new_joint_angles, self._joint_limits[0], self._joint_limits[1]
        )

        # ── 위치 업데이트 / Position update ────────────────────────
        new_position = state.position + new_velocity * dt

        # ── 구-평면 충돌 감지 (로봇 본체) / Sphere-plane collision (body) ──
        new_position, body_collision, _ = self._sphere_plane_collision(
            new_position, ROBOT_RADIUS, ground_z=0.0,
            restitution=COLLISION_RESTITUTION,
        )
        if body_collision and new_velocity[2] < 0.0:
            new_velocity[2] = abs(new_velocity[2]) * COLLISION_RESTITUTION

        # ── 다리-지면 다물체 상호작용 / Leg-ground multi-body interaction ──
        temp_state_for_legs = SimState(
            position=new_position, velocity=new_velocity,
            orientation=state.orientation, angular_vel=state.angular_vel,
            joint_angles=new_joint_angles, joint_velocities=new_joint_velocities,
            contact_forces=state.contact_forces,
        )
        foot_positions = self._compute_leg_positions(temp_state_for_legs)
        new_contact_forces = np.zeros(4)

        for i, foot_pos in enumerate(foot_positions):
            corrected_pos, leg_contact, penetration = self._sphere_plane_collision(
                foot_pos, LEG_RADIUS, ground_z=0.0,
            )
            if leg_contact:
                # 지면 반발력 = k * penetration + c * velocity / Ground reaction
                k_ground = 5000.0  # N/m (지면 강성)
                c_ground = 100.0   # Ns/m (지면 감쇠)
                foot_vel_z = new_velocity[2] + new_joint_velocities[i * 3 + 1] * 0.15 if i * 3 + 1 < 12 else new_velocity[2]
                normal_force = k_ground * penetration - c_ground * min(foot_vel_z, 0.0)
                new_contact_forces[i] = max(0.0, normal_force)

                # 반발력이 로봇에 미치는 효과 / Apply reaction to body
                if i < NUM_LEGS:
                    impulse = normal_force * dt / mass
                    new_velocity[2] += impulse * 0.25  # 각 다리가 체중의 1/4 지지

        # ── 파지력에 의한 접촉력 / Contact forces from grip ──────
        if action.grip_force > 0.0:
            new_contact_forces[:2] += action.grip_force / 2.0

        # ── 쿼터니언 적분 / Quaternion integration ─────────────────
        new_angular_vel = state.angular_vel.copy()
        new_angular_vel[2] += action.locomotion_velocity[2] * dt  # 요 속도

        # 관절 움직임에 의한 회전 토크 / Rotation torque from joint motion
        joint_torque = np.zeros(3)
        joint_torque[0] += np.sum(new_joint_velocities[:6]) * 0.001  # 피치
        joint_torque[1] += np.sum(new_joint_velocities[6:12]) * 0.001  # 롤
        new_angular_vel += joint_torque * dt

        new_angular_vel *= 0.95  # 각속도 감쇠 / Angular damping

        # 쿼터니언 적분 (이전: state.orientation.copy()로 단순화됨)
        new_orientation = self._integrate_orientation(
            state.orientation, new_angular_vel, dt
        )

        # ── 센서 노이즈 추가 / Add sensor noise ────────────────────
        if self._sensor_noise_std > 0.0:
            new_position += np.random.randn(3) * self._sensor_noise_std
            new_velocity += np.random.randn(3) * self._sensor_noise_std * 0.1
            new_joint_angles += np.random.randn(12) * self._sensor_noise_std

        return SimState(
            position=new_position,
            velocity=new_velocity,
            orientation=new_orientation,
            angular_vel=new_angular_vel,
            joint_angles=new_joint_angles,
            joint_velocities=new_joint_velocities,
            contact_forces=new_contact_forces,
        )


# ─── 도메인 랜덤화기 / Domain Randomizer ────────────────────────────────────


class DomainRandomizer:
    """
    시뮬레이션 도메인 랜덤화기 / Simulation domain randomizer.

    시뮬레이션 파라미터를 랜덤화하여 Sim-to-Real 갭을 줄입니다.
    마찰, 질량, 센서 노이즈, 지형, 객체 속성을 무작위화합니다.

    Usage:
        randomizer = DomainRandomizer()
        terrain = randomizer.randomize_terrain("slope")
        robot = randomizer.randomize_robot()
    """

    def __init__(self, seed: Optional[int] = None) -> None:
        self._rng = np.random.RandomState(seed)
        logger.info("DomainRandomizer 초기화: seed=%s", seed)

    def randomize_terrain(self, terrain_type: str) -> Dict[str, Any]:
        """
        지형 파라미터 랜덤화 / Randomize terrain parameters.

        Args:
            terrain_type: 지형 유형

        Returns:
            Dict: 랜덤화된 지형 파라미터
        """
        base_params = {
            TerrainType.FLAT.value: {"friction": 0.6, "roughness": 0.0, "slope_deg": 0.0},
            TerrainType.CARPET.value: {"friction": 0.8, "roughness": 0.1, "slope_deg": 0.0},
            TerrainType.GRAVEL.value: {"friction": 0.4, "roughness": 0.5, "slope_deg": 0.0},
            TerrainType.SLOPE.value: {"friction": 0.5, "roughness": 0.1, "slope_deg": 15.0},
            TerrainType.STAIRS.value: {"friction": 0.6, "roughness": 0.2, "slope_deg": 0.0},
            TerrainType.UNEVEN.value: {"friction": 0.5, "roughness": 0.7, "slope_deg": 0.0},
            TerrainType.WET.value: {"friction": 0.2, "roughness": 0.0, "slope_deg": 0.0},
            TerrainType.SAND.value: {"friction": 0.3, "roughness": 0.6, "slope_deg": 0.0},
        }

        params = dict(base_params.get(terrain_type, base_params[TerrainType.FLAT.value]))

        # 도메인 랜덤화: 마찰 0.1~0.9 / Domain randomization: friction 0.1-0.9
        params["friction"] = float(np.clip(
            params["friction"] + self._rng.uniform(-0.15, 0.15),
            0.1, 0.9
        ))
        # 거칠기 랜덤화 / Roughness randomization
        params["roughness"] = float(np.clip(
            params["roughness"] + self._rng.uniform(-0.1, 0.1),
            0.0, 1.0
        ))
        # 경사 랜덤화 / Slope randomization
        params["slope_deg"] = float(np.clip(
            params["slope_deg"] + self._rng.uniform(-5.0, 5.0),
            0.0, 35.0
        ))
        params["terrain_type"] = terrain_type

        return params

    def randomize_object(self, object_type: str = "") -> Dict[str, Any]:
        """
        객체 속성 랜덤화 / Randomize object properties.

        Args:
            object_type: 객체 유형

        Returns:
            Dict: 랜덤화된 객체 속성
        """
        base_mass = 0.5  # kg
        if object_type == ObjectType.HEAVY.value:
            base_mass = 5.0
        elif object_type == ObjectType.FRAGILE.value:
            base_mass = 0.2

        return {
            "mass_kg": float(base_mass * self._rng.uniform(0.5, 2.0)),
            "friction": float(self._rng.uniform(0.1, 0.9)),
            "size_m": float(self._rng.uniform(0.02, 0.15)),
            "is_rigid": object_type != ObjectType.SOFT_BALL.value,
            "is_fragile": object_type == ObjectType.FRAGILE.value,
            "is_slippery": object_type == ObjectType.SLIPPERY.value,
            "shape": "box" if object_type == ObjectType.RIGID_BOX.value
                     else "sphere" if object_type == ObjectType.SOFT_BALL.value
                     else "cylinder" if object_type == ObjectType.CYLINDER.value
                     else "irregular",
            "object_type": object_type or ObjectType.RIGID_BOX.value,
        }

    def randomize_robot(self) -> Dict[str, Any]:
        """
        로봇 파라미터 랜덤화 (안전 범위 내) / Randomize robot parameters (within safe bounds).

        질량, 관절 감쇠, 센서 노이즈를 안전한 범위 내에서 랜덤화합니다.

        Returns:
            Dict: 랜덤화된 로봇 파라미터
        """
        return {
            "mass_scale": float(self._rng.uniform(0.5, 2.0)),
            "friction": float(self._rng.uniform(0.1, 0.9)),
            "sensor_noise_std": float(self._rng.uniform(0.005, 0.05)),
            "joint_damping": float(self._rng.uniform(0.8, 1.2)),
            "motor_strength": float(self._rng.uniform(0.8, 1.2)),
            "delay_ms": float(self._rng.uniform(0.0, 20.0)),  # 제어 지연 / Control delay
        }


# ─── 합성 경험 생성기 / Synthetic Experience Generator ──────────────────────


class SyntheticExperienceGenerator:
    """
    시뮬레이션 기반 합성 경험 생성기 / Simulation-based synthetic experience generator.

    자동 커리큘럼을 사용하여 쉬운 환경부터 어려운 환경까지
    점진적으로 난이도를 높이며 경험을 생성합니다.

    Curriculum / 커리큘럼:
        Level 1-3: 평지 걷기, 단순 파지
        Level 4-6: 경사면, 잡물 파지
        Level 7-8: 계단, 정밀 조작
        Level 9-10: 복합 지형, 복합 조작

    Usage:
        gen = SyntheticExperienceGenerator()
        locomotion_exps = gen.generate_locomotion_experiences(n=1000)
        grip_exps = gen.generate_grip_experiences(n=1000)
        manip_exps = gen.generate_manipulation_experiences(n=1000)
    """

    def __init__(
        self,
        seed: Optional[int] = None,
        curriculum_level: int = 1,
    ) -> None:
        self._rng = np.random.RandomState(seed)
        self._curriculum_level = min(curriculum_level, MAX_CURRICULUM_LEVEL)
        self._randomizer = DomainRandomizer(seed=seed)
        self._total_generated = 0
        self._lock = threading.Lock()

        logger.info(
            "SyntheticExperienceGenerator 초기화: 커리큘럼 레벨=%d",
            self._curriculum_level,
        )

    def _get_simulator(self, robot_params: Dict[str, Any]) -> PhysicsSimulator:
        """랜덤화된 파라미터로 시뮬레이터 생성 / Create simulator with randomized params."""
        return PhysicsSimulator(
            friction=robot_params.get("friction", 0.5),
            mass_scale=robot_params.get("mass_scale", 1.0),
            sensor_noise_std=robot_params.get("sensor_noise_std", NOISE_STD),
        )

    def _compute_reward(
        self,
        state_before: SimState,
        state_after: SimState,
        action: SimAction,
        task_params: Dict[str, Any],
    ) -> float:
        """
        경험 보상 계산 / Compute experience reward.

        작업 성공, 안정성, 에너지 효율을 기반으로 보상을 계산합니다.

        Args:
            state_before: 행동 전 상태
            state_after: 행동 후 상태
            action: 수행된 행동
            task_params: 작업 파라미터

        Returns:
            float: 보상 값 [-1, 1]
        """
        # 작업 성공: 목표 방향으로 이동했는가 / Task success: moved toward goal?
        goal = task_params.get("goal_position", np.array([1.0, 0.0, 0.0]))
        dist_before = np.linalg.norm(state_before.position - goal)
        dist_after = np.linalg.norm(state_after.position - goal)
        progress = dist_before - dist_after
        task_reward = np.clip(progress * 5.0, -1.0, 1.0)

        # 안정성: 균형 유지 / Stability: maintained balance
        height_diff = abs(state_after.position[2] - 0.3)  # 기본 높이에서 벗어남
        stability_reward = np.clip(1.0 - height_diff * 5.0, -1.0, 1.0)

        # 에너지: 과도한 관절 움직임 벌점 / Energy: penalize excessive joint motion
        joint_effort = np.sum(np.abs(action.joint_targets))
        energy_penalty = np.clip(-joint_effort * 0.01, -0.5, 0.0)

        reward = 0.4 * task_reward + 0.4 * stability_reward + 0.2 * energy_penalty
        return float(np.clip(reward, -1.0, 1.0))

    def generate_locomotion_experiences(
        self,
        n: int = 1000,
        terrain_types: Optional[List[str]] = None,
        episode_length: int = 50,
    ) -> List[Dict[str, Any]]:
        """
        이동 경험 생성 / Generate locomotion experiences.

        다양한 지형에서의 이동 경험을 생성합니다.
        커리큘럼에 따라 지형 난이도가 자동 조정됩니다.

        Args:
            n: 생성할 경험 수
            terrain_types: 지형 유형 목록 (None=커리큘럼 기반)
            episode_length: 에피소드 길이

        Returns:
            List[Dict]: 생성된 경험 목록
        """
        if terrain_types is None:
            terrain_types = self._curriculum_terrains()

        experiences: List[Dict[str, Any]] = []
        generated = 0

        while generated < n:
            # 랜덤 지형 선택 / Random terrain selection
            terrain_type = self._rng.choice(terrain_types)
            terrain_params = self._randomizer.randomize_terrain(terrain_type)
            robot_params = self._randomizer.randomize_robot()
            sim = self._get_simulator(robot_params)

            # 초기 상태 / Initial state
            state = SimState(position=np.array([0.0, 0.0, 0.3]))

            goal = np.array([
                self._rng.uniform(0.5, 2.0),
                self._rng.uniform(-1.0, 1.0),
                0.3,
            ])

            for step in range(episode_length):
                # 행동 생성 / Generate action
                direction = goal - state.position
                direction_norm = direction / (np.linalg.norm(direction) + 1e-8)
                speed = 0.3 * (1.0 + 0.1 * self._curriculum_level)

                action = SimAction(
                    joint_targets=state.joint_angles + self._rng.randn(12) * 0.1,
                    grip_force=0.0,
                    locomotion_velocity=np.array([
                        direction_norm[0] * speed,
                        direction_norm[1] * speed,
                        self._rng.uniform(-0.3, 0.3),
                    ]),
                )

                # 시뮬레이션 스텝 / Simulation step
                next_state = sim.simulate_step(state, action)

                # 보상 계산 / Compute reward
                reward = self._compute_reward(
                    state, next_state, action,
                    {"goal_position": goal, "terrain": terrain_params},
                )

                # 경험 기록 / Record experience
                exp = SimExperience(
                    state_before=state.to_vector(),
                    action=action.to_vector(),
                    state_after=next_state.to_vector(),
                    reward=reward,
                    metadata={
                        "type": "locomotion",
                        "terrain": terrain_params,
                        "robot": robot_params,
                        "goal": goal.tolist(),
                        "step": step,
                        "curriculum_level": self._curriculum_level,
                    },
                )

                experiences.append({
                    "state_before": exp.state_before.tolist(),
                    "action": exp.action.tolist(),
                    "state_after": exp.state_after.tolist(),
                    "reward": exp.reward,
                    "metadata": exp.metadata,
                    "experience_id": exp.experience_id,
                })
                generated += 1

                state = next_state
                if generated >= n:
                    break

        with self._lock:
            self._total_generated += generated

        logger.info(
            "이동 경험 생성: %d개 (지형=%s, 커리큘럼=%d)",
            generated, terrain_types, self._curriculum_level,
        )
        return experiences

    def generate_grip_experiences(
        self,
        n: int = 1000,
        object_types: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        파지 경험 생성 / Generate grip experiences.

        다양한 객체에 대한 파지 경험을 생성합니다.

        Args:
            n: 생성할 경험 수
            object_types: 객체 유형 목록

        Returns:
            List[Dict]: 생성된 경험 목록
        """
        if object_types is None:
            object_types = self._curriculum_objects()

        experiences: List[Dict[str, Any]] = []
        robot_params = self._randomizer.randomize_robot()
        sim = self._get_simulator(robot_params)

        for i in range(n):
            object_type = self._rng.choice(object_types)
            obj_params = self._randomizer.randomize_object(object_type)

            # 초기 상태 / Initial state
            state = SimState(
                position=np.array([0.0, 0.0, 0.3]),
                joint_angles=np.zeros(12),
            )

            # 파지 행동 생성 / Generate grip action
            grip_force = self._rng.uniform(1.0, 20.0)
            success_prob = 0.5

            # 객체 속성에 따른 파지 성공 확률 / Grip success probability based on object
            if obj_params.get("is_slippery"):
                success_prob *= 0.4
            if obj_params.get("is_fragile"):
                success_prob *= 0.7
                if grip_force > 10.0:
                    success_prob *= 0.3  # 너무 세면 파손 / Too strong = break
            if obj_params["mass_kg"] > 2.0 and grip_force < 5.0:
                success_prob *= 0.2  # 너무 무거우면 실패 / Too heavy = fail

            success = self._rng.random() < success_prob

            action = SimAction(
                joint_targets=state.joint_angles + self._rng.randn(12) * 0.05,
                grip_force=grip_force,
            )

            next_state = sim.simulate_step(state, action)

            # 보상 / Reward
            if success:
                reward = np.clip(0.5 + 0.5 * (grip_force / 20.0), 0.0, 1.0)
                if obj_params.get("is_fragile") and grip_force > 10.0:
                    reward = -0.5  # 깨짐 / Broke it
            else:
                reward = np.clip(-0.3 - 0.2 * (1.0 - success_prob), -1.0, 0.0)

            experiences.append({
                "state_before": state.to_vector().tolist(),
                "action": action.to_vector().tolist(),
                "state_after": next_state.to_vector().tolist(),
                "reward": float(reward),
                "metadata": {
                    "type": "grip",
                    "object": obj_params,
                    "robot": robot_params,
                    "grip_success": success,
                    "grip_force": grip_force,
                    "curriculum_level": self._curriculum_level,
                },
                "experience_id": uuid.uuid4().hex[:12],
            })

        with self._lock:
            self._total_generated += n

        logger.info("파지 경험 생성: %d개", n)
        return experiences

    def generate_manipulation_experiences(
        self,
        n: int = 1000,
    ) -> List[Dict[str, Any]]:
        """
        조작 경험 생성 / Generate manipulation experiences.

        객체 이동, 회전, 배치 등의 조작 경험을 생성합니다.

        Args:
            n: 생성할 경험 수

        Returns:
            List[Dict]: 생성된 경험 목록
        """
        experiences: List[Dict[str, Any]] = []

        for i in range(n):
            robot_params = self._randomizer.randomize_robot()
            sim = self._get_simulator(robot_params)

            # 조작 작업 유형 / Manipulation task type
            task_types = ["push", "pull", "rotate", "lift", "place"]
            task_type = self._rng.choice(task_types)

            state = SimState(
                position=np.array([0.0, 0.0, 0.3]),
                joint_angles=np.zeros(12),
            )

            # 조작 행동 / Manipulation action
            action = SimAction(
                joint_targets=state.joint_angles + self._rng.randn(12) * 0.15,
                grip_force=self._rng.uniform(0.0, 15.0),
                locomotion_velocity=self._rng.randn(3) * 0.2,
            )

            next_state = sim.simulate_step(state, action)

            # 보상: 조작 정밀도 / Reward: manipulation precision
            target_displacement = self._rng.randn(3) * 0.1
            actual_displacement = next_state.position - state.position
            precision = np.exp(-np.linalg.norm(actual_displacement - target_displacement))
            reward = float(np.clip(2.0 * precision - 1.0, -1.0, 1.0))

            experiences.append({
                "state_before": state.to_vector().tolist(),
                "action": action.to_vector().tolist(),
                "state_after": next_state.to_vector().tolist(),
                "reward": reward,
                "metadata": {
                    "type": "manipulation",
                    "task": task_type,
                    "target_displacement": target_displacement.tolist(),
                    "actual_displacement": actual_displacement.tolist(),
                    "precision": float(precision),
                    "robot": robot_params,
                    "curriculum_level": self._curriculum_level,
                },
                "experience_id": uuid.uuid4().hex[:12],
            })

        with self._lock:
            self._total_generated += n

        logger.info("조작 경험 생성: %d개", n)
        return experiences

    def _curriculum_terrains(self) -> List[str]:
        """커리큘럼 기반 지형 목록 / Curriculum-based terrain list."""
        terrain_progression = {
            1: [TerrainType.FLAT.value],
            2: [TerrainType.FLAT.value, TerrainType.CARPET.value],
            3: [TerrainType.FLAT.value, TerrainType.CARPET.value, TerrainType.GRAVEL.value],
            4: [TerrainType.FLAT.value, TerrainType.GRAVEL.value, TerrainType.SLOPE.value],
            5: [TerrainType.GRAVEL.value, TerrainType.SLOPE.value, TerrainType.WET.value],
            6: [TerrainType.SLOPE.value, TerrainType.WET.value, TerrainType.SAND.value],
            7: [TerrainType.SLOPE.value, TerrainType.STAIRS.value, TerrainType.SAND.value],
            8: [TerrainType.STAIRS.value, TerrainType.UNEVEN.value, TerrainType.SAND.value],
            9: [TerrainType.STAIRS.value, TerrainType.UNEVEN.value, TerrainType.WET.value],
            10: [t.value for t in TerrainType],
        }
        level = min(self._curriculum_level, MAX_CURRICULUM_LEVEL)
        return terrain_progression.get(level, [TerrainType.FLAT.value])

    def _curriculum_objects(self) -> List[str]:
        """커리큘럼 기반 객체 목록 / Curriculum-based object list."""
        object_progression = {
            1: [ObjectType.RIGID_BOX.value],
            2: [ObjectType.RIGID_BOX.value, ObjectType.CYLINDER.value],
            3: [ObjectType.RIGID_BOX.value, ObjectType.CYLINDER.value, ObjectType.SOFT_BALL.value],
            5: [ObjectType.RIGID_BOX.value, ObjectType.CYLINDER.value,
                ObjectType.SOFT_BALL.value, ObjectType.SLIPPERY.value],
            7: [ObjectType.RIGID_BOX.value, ObjectType.CYLINDER.value,
                ObjectType.SOFT_BALL.value, ObjectType.SLIPPERY.value, ObjectType.FRAGILE.value],
            10: [t.value for t in ObjectType],
        }
        level = min(self._curriculum_level, MAX_CURRICULUM_LEVEL)
        for threshold in sorted(object_progression.keys(), reverse=True):
            if level >= threshold:
                return object_progression[threshold]
        return [ObjectType.RIGID_BOX.value]

    def advance_curriculum(self) -> int:
        """
        커리큘럼 레벨 증가 / Advance curriculum level.

        Returns:
            int: 새 커리큘럼 레벨
        """
        if self._curriculum_level < MAX_CURRICULUM_LEVEL:
            self._curriculum_level += 1
            logger.info("커리큘럼 레벨 증가: %d", self._curriculum_level)
        return self._curriculum_level

    def get_stats(self) -> Dict[str, Any]:
        """생성기 통계 / Return generator statistics."""
        return {
            "total_generated": self._total_generated,
            "curriculum_level": self._curriculum_level,
        }


# ─── 경험 품질 필터 / Experience Quality Filter ─────────────────────────────


class ExperienceQualityFilter:
    """
    합성 경험 품질 필터 / Synthetic experience quality filter.

    시뮬레이션에서 생성된 경험의 품질을 평가하고 필터링합니다.
    새로움(novelty), 다양성(diversity)을 기준으로
    고품질 경험만 선택합니다.

    Usage:
        qf = ExperienceQualityFilter()
        score = qf.novelty_score(experience, existing_experiences)
        diversity = qf.diversity_score(batch)
        filtered = qf.filter_batch(experiences, max_batch=500)
    """

    def __init__(
        self,
        novelty_threshold: float = 0.1,
        diversity_threshold: float = 0.3,
    ) -> None:
        self._novelty_threshold = novelty_threshold
        self._diversity_threshold = diversity_threshold
        self._embedding_cache: Dict[str, np.ndarray] = {}
        self._lock = threading.Lock()

        logger.info(
            "ExperienceQualityFilter 초기화: 새로움=%.2f, 다양성=%.2f",
            novelty_threshold, diversity_threshold,
        )

    def _embed(self, experience: Dict[str, Any]) -> np.ndarray:
        """
        경험을 임베딩 벡터로 변환 / Convert experience to embedding vector.

        state_before + action + reward를 결합하여 임베딩합니다.

        Args:
            experience: 경험 딕셔너리

        Returns:
            np.ndarray: 임베딩 벡터
        """
        exp_id = experience.get("experience_id", "")
        if exp_id in self._embedding_cache:
            return self._embedding_cache[exp_id]

        sb = np.asarray(experience.get("state_before", []), dtype=np.float32).flatten()
        act = np.asarray(experience.get("action", []), dtype=np.float32).flatten()
        reward = np.array([experience.get("reward", 0.0)], dtype=np.float32)

        embedding = np.concatenate([sb, act, reward])
        if len(embedding) < 10:
            embedding = np.concatenate([embedding, np.zeros(10 - len(embedding))])

        with self._lock:
            self._embedding_cache[exp_id] = embedding

        return embedding

    def novelty_score(
        self,
        experience: Dict[str, Any],
        existing_experiences: List[Dict[str, Any]],
    ) -> float:
        """
        새로움 점수 계산 / Compute novelty score.

        기존 경험과의 최소 거리를 기반으로 새로움을 평가합니다.
        거리가 멀수록 새로운 경험입니다.

        Args:
            experience: 평가할 경험
            existing_experiences: 기존 경험 목록

        Returns:
            float: 새로움 점수 (0~1, 높을수록 새로움)
        """
        if not existing_experiences:
            return 1.0

        query_emb = self._embed(experience)

        # 기존 경험과의 최소 거리 / Minimum distance to existing experiences
        min_dist = float("inf")
        for existing in existing_experiences:
            existing_emb = self._embed(existing)
            if len(query_emb) != len(existing_emb):
                min_len = min(len(query_emb), len(existing_emb))
                dist = float(np.linalg.norm(query_emb[:min_len] - existing_emb[:min_len]))
            else:
                dist = float(np.linalg.norm(query_emb - existing_emb))
            min_dist = min(min_dist, dist)

        # 거리를 [0, 1]로 매핑 / Map distance to [0, 1]
        novelty = 1.0 - np.exp(-min_dist * 0.5)
        return float(novelty)

    def diversity_score(self, batch: List[Dict[str, Any]]) -> float:
        """
        다양성 점수 계산 / Compute diversity score.

        배치 내 경험 간의 평균 거리를 기반으로 다양성을 평가합니다.

        Args:
            batch: 경험 배치

        Returns:
            float: 다양성 점수 (0~1, 높을수록 다양함)
        """
        if len(batch) < 2:
            return 0.0

        embeddings = [self._embed(exp) for exp in batch]

        # 샘플링으로 계산량 제한 / Limit computation by sampling
        n_pairs = min(100, len(embeddings) * (len(embeddings) - 1) // 2)
        distances = []

        for _ in range(n_pairs):
            i, j = np.random.choice(len(embeddings), size=2, replace=False)
            emb_i, emb_j = embeddings[i], embeddings[j]
            min_len = min(len(emb_i), len(emb_j))
            dist = float(np.linalg.norm(emb_i[:min_len] - emb_j[:min_len]))
            distances.append(dist)

        if not distances:
            return 0.0

        avg_dist = float(np.mean(distances))
        diversity = 1.0 - np.exp(-avg_dist * 0.3)
        return float(diversity)

    def filter_batch(
        self,
        experiences: List[Dict[str, Any]],
        max_batch: int = 500,
    ) -> List[Dict[str, Any]]:
        """
        경험 배치 필터링 / Filter experience batch.

        새로움과 보상을 기준으로 고품질 경험만 선택합니다.

        Args:
            experiences: 원본 경험 목록
            max_batch: 최대 배치 크기

        Returns:
            List[Dict]: 필터링된 경험 목록
        """
        if len(experiences) <= max_batch:
            return experiences

        # 보상 기반 정렬 / Sort by reward
        scored = []
        for exp in experiences:
            novelty = self.novelty_score(exp, experiences[:100])
            reward = abs(exp.get("reward", 0.0))
            score = 0.6 * novelty + 0.4 * reward
            scored.append((score, exp))

        scored.sort(key=lambda x: x[0], reverse=True)

        # 다양성 확보를 위한 그리드 샘플링 / Grid sampling for diversity
        filtered = [exp for _, exp in scored[:max_batch]]

        diversity = self.diversity_score(filtered)
        logger.info(
            "경험 필터링: %d → %d (다양성=%.3f)",
            len(experiences), len(filtered), diversity,
        )

        return filtered


# ─── 모듈 진입점 / Module Entry Point ───────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("=" * 60)
    print("시뮬레이션 경험 생성기 테스트 / Sim Experience Generator Test")
    print("=" * 60)

    # 물리 시뮬레이터 테스트 / Physics simulator test
    sim = PhysicsSimulator(friction=0.5, mass_scale=1.0)
    state = SimState(position=np.array([0.0, 0.0, 0.3]))
    action = SimAction(
        joint_targets=np.zeros(12),
        locomotion_velocity=np.array([0.5, 0.0, 0.1]),
    )
    for i in range(10):
        state = sim.simulate_step(state, action)
    print(f"10스텝 후 위치: {state.position}")

    # 경험 생성기 테스트 / Experience generator test
    gen = SyntheticExperienceGenerator(seed=42, curriculum_level=3)

    loc_exps = gen.generate_locomotion_experiences(n=50)
    print(f"\n이동 경험: {len(loc_exps)}개 생성")

    grip_exps = gen.generate_grip_experiences(n=50)
    print(f"파지 경험: {len(grip_exps)}개 생성")

    manip_exps = gen.generate_manipulation_experiences(n=50)
    print(f"조작 경험: {len(manip_exps)}개 생성")

    # 품질 필터 테스트 / Quality filter test
    qf = ExperienceQualityFilter()
    all_exps = loc_exps + grip_exps + manip_exps
    filtered = qf.filter_batch(all_exps, max_batch=30)
    print(f"\n필터링: {len(all_exps)} → {len(filtered)}")
    print(f"다양성: {qf.diversity_score(filtered):.3f}")
    print(f"통계: {gen.get_stats()}")
    print("\n모든 테스트 완료 / All tests completed.")
