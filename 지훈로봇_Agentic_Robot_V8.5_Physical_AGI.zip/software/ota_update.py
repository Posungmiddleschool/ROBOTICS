#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — OTA 펌웨어 업데이트 관리자
============================================

ESP32-S3 → WiFi → GitHub Release → 자동 펌웨어 다운로드/설치
Jetson: systemd 서비스로 자동 업데이트 (GitHub Actions)

TODO 53: ota_update.py

기능:
  - GitHub Release에서 펌웨어 자동 다운로드
  - 버전 관리 및 체인지로그 추적
  - 업데이트 실패 시 자동 롤백
  - 무결성 검증 (SHA256)
  - ESP32 + Jetson 듀얼 업데이트 경로

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

# HTTP 요청
try:
    import urllib.request
    import urllib.error
    HTTP_AVAILABLE = True
except ImportError:
    HTTP_AVAILABLE = False

logger = logging.getLogger(__name__)


# ============================================================================
# 열거형 및 상수
# ============================================================================

class UpdateTarget(Enum):
    """업데이트 대상"""
    ESP32 = "esp32"
    JETSON = "jetson"


class UpdateState(Enum):
    """업데이트 상태"""
    IDLE = "idle"
    CHECKING = "checking"
    DOWNLOADING = "downloading"
    VERIFYING = "verifying"
    INSTALLING = "installing"
    ROLLING_BACK = "rolling_back"
    COMPLETED = "completed"
    FAILED = "failed"


# GitHub 설정
GITHUB_REPO = "jihun-robot/v7"
GITHUB_API_BASE = f"https://api.github.com/repos/{GITHUB_REPO}"
FIRMWARE_DIR = Path("/opt/jihun/firmware")
BACKUP_DIR = Path("/opt/jihun/firmware/backup")
VERSION_FILE = Path("/opt/jihun/firmware/version.json")
CHANGELOG_FILE = Path("/opt/jihun/firmware/CHANGELOG.md")

# 다운로드 설정
DOWNLOAD_CHUNK_SIZE = 8192
DOWNLOAD_TIMEOUT_S = 120
MAX_RETRIES = 3

# 검증
HASH_ALGORITHM = "sha256"


# ============================================================================
# 데이터 클래스
# ============================================================================

@dataclass
class FirmwareVersion:
    """펌웨어 버전 정보"""
    version: str = "7.0.0"
    build_number: int = 1
    release_date: str = ""
    target: UpdateTarget = UpdateTarget.JETSON
    changelog: str = ""
    download_url: str = ""
    file_size_bytes: int = 0
    sha256_hash: str = ""


@dataclass
class UpdateStatus:
    """업데이트 진행 상태"""
    state: UpdateState = UpdateState.IDLE
    current_version: str = "7.0.0"
    target_version: str = ""
    progress_percent: float = 0.0
    downloaded_bytes: int = 0
    total_bytes: int = 0
    error_message: str = ""
    start_time: float = 0.0
    elapsed_s: float = 0.0
    target: UpdateTarget = UpdateTarget.JETSON


@dataclass
class RollbackInfo:
    """롤백 정보"""
    backup_version: str = ""
    backup_path: str = ""
    backup_timestamp: float = 0.0
    can_rollback: bool = False


# ============================================================================
# 메인 클래스: OTAUpdateManager
# ============================================================================

class OTAUpdateManager:
    """
    지훈 로봇 V8.5 — OTA 펌웨어 업데이트 관리자

    기능:
      - GitHub Release에서 펌웨어 확인/다운로드
      - SHA256 무결성 검증
      - 업데이트 실패 시 자동 롤백
      - 버전 관리 및 체인지로그 추적
      - ESP32 + Jetson 듀얼 타겟 지원
    """

    def __init__(
        self,
        github_repo: str = GITHUB_REPO,
        firmware_dir: Optional[Path] = None,
    ):
        self._github_repo = github_repo
        self._api_base = f"https://api.github.com/repos/{github_repo}"
        self._firmware_dir = firmware_dir or FIRMWARE_DIR
        self._backup_dir = BACKUP_DIR
        self._version_file = VERSION_FILE

        # 현재 상태
        self._current_version = self._load_current_version()
        self._update_status = UpdateStatus(current_version=self._current_version)
        self._rollback_info = RollbackInfo()

        # 업데이트 락 (동시 업데이트 방지)
        self._update_lock = threading.Lock()
        self._is_updating = False

        # 콜백
        self._on_update_complete: Optional[Callable[[bool, str], None]] = None

        # 디렉토리 보장
        self._firmware_dir.mkdir(parents=True, exist_ok=True)
        self._backup_dir.mkdir(parents=True, exist_ok=True)

        logger.info("OTAUpdateManager 초기화 (현재 버전: %s)", self._current_version)

    # --- 버전 관리 ---

    def _load_current_version(self) -> str:
        """현재 설치된 버전 로드"""
        try:
            if self._version_file.exists():
                with open(self._version_file, "r") as f:
                    data = json.load(f)
                return data.get("version", "7.0.0")
        except Exception as e:
            logger.warning("버전 파일 로드 실패: %s", e)
        return "7.0.0"

    def _save_current_version(self, version: str) -> None:
        """현재 버전 저장"""
        try:
            data = {
                "version": version,
                "installed_at": time.time(),
                "installed_date": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
            with open(self._version_file, "w") as f:
                json.dump(data, f, indent=2)
            self._current_version = version
        except Exception as e:
            logger.error("버전 파일 저장 실패: %s", e)

    # --- 업데이트 확인 ---

    def check_update(self, target: UpdateTarget = UpdateTarget.JETSON) -> Optional[FirmwareVersion]:
        """
        GitHub Release에서 새 펌웨어 확인

        Args:
            target: 업데이트 대상 (ESP32 또는 Jetson)

        Returns:
            새 버전 정보 (없으면 None)
        """
        self._update_status.state = UpdateState.CHECKING
        logger.info("업데이트 확인 중... (대상: %s)", target.value)

        try:
            url = f"{self._api_base}/releases/latest"
            req = urllib.request.Request(url, headers={"User-Agent": "JihunRobot-V7"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                release = json.loads(resp.read().decode())

            tag = release.get("tag_name", "").lstrip("v")
            logger.info("최신 릴리즈: %s (현재: %s)", tag, self._current_version)

            # 버전 비교
            if self._compare_versions(tag, self._current_version) <= 0:
                logger.info("이미 최신 버전입니다")
                self._update_status.state = UpdateState.IDLE
                return None

            # 에셋에서 펌웨어 파일 찾기
            firmware_asset = None
            for asset in release.get("assets", []):
                name = asset.get("name", "")
                if target == UpdateTarget.ESP32 and name.endswith(".bin"):
                    firmware_asset = asset
                    break
                elif target == UpdateTarget.JETSON and name.endswith(".tar.gz"):
                    firmware_asset = asset
                    break

            if not firmware_asset:
                logger.warning("대상 %s의 펌웨어 파일을 찾을 수 없음", target.value)
                self._update_status.state = UpdateState.IDLE
                return None

            # 체인지로그에서 해시 찾기
            sha256 = ""
            body = release.get("body", "")
            for line in body.split("\n"):
                if "sha256" in line.lower():
                    parts = line.split()
                    for part in parts:
                        if len(part) == 64:
                            sha256 = part
                            break

            new_version = FirmwareVersion(
                version=tag,
                build_number=int(release.get("id", 0)),
                release_date=release.get("published_at", ""),
                target=target,
                changelog=body[:500],
                download_url=firmware_asset.get("browser_download_url", ""),
                file_size_bytes=firmware_asset.get("size", 0),
                sha256_hash=sha256,
            )

            self._update_status.state = UpdateState.IDLE
            return new_version

        except urllib.error.HTTPError as e:
            logger.error("GitHub API 오류: %d %s", e.code, e.reason)
            self._update_status.state = UpdateState.FAILED
            return None
        except Exception as e:
            logger.error("업데이트 확인 실패: %s", e)
            self._update_status.state = UpdateState.FAILED
            return None

    # --- 펌웨어 다운로드 ---

    def download_firmware(self, firmware: FirmwareVersion) -> Optional[Path]:
        """
        펌웨어 파일 다운로드

        Args:
            firmware: 다운로드할 펌웨어 버전 정보

        Returns:
            다운로드된 파일 경로 (실패 시 None)
        """
        self._update_status.state = UpdateState.DOWNLOADING
        self._update_status.target_version = firmware.version
        self._update_status.total_bytes = firmware.file_size_bytes
        self._update_status.downloaded_bytes = 0
        self._update_status.start_time = time.time()

        if not firmware.download_url:
            logger.error("다운로드 URL 없음")
            self._update_status.state = UpdateState.FAILED
            return None

        # 파일명 결정
        ext = ".bin" if firmware.target == UpdateTarget.ESP32 else ".tar.gz"
        filename = f"jihun_v844_{firmware.target.value}_{firmware.version}{ext}"
        filepath = self._firmware_dir / filename

        logger.info("펌웨어 다운로드 시작: %s → %s", firmware.download_url, filepath)

        for attempt in range(MAX_RETRIES):
            try:
                req = urllib.request.Request(
                    firmware.download_url, headers={"User-Agent": "JihunRobot-V7"}
                )
                with urllib.request.urlopen(req, timeout=DOWNLOAD_TIMEOUT_S) as resp:
                    with open(filepath, "wb") as f:
                        while True:
                            chunk = resp.read(DOWNLOAD_CHUNK_SIZE)
                            if not chunk:
                                break
                            f.write(chunk)
                            self._update_status.downloaded_bytes += len(chunk)
                            if self._update_status.total_bytes > 0:
                                self._update_status.progress_percent = (
                                    self._update_status.downloaded_bytes
                                    / self._update_status.total_bytes * 100
                                )

                logger.info("다운로드 완료: %s (%d bytes)", filepath, self._update_status.downloaded_bytes)
                return filepath

            except Exception as e:
                logger.warning("다운로드 시도 %d/%d 실패: %s", attempt + 1, MAX_RETRIES, e)
                if attempt < MAX_RETRIES - 1:
                    time.sleep(2 ** attempt)  # 지수 백오프

        self._update_status.state = UpdateState.FAILED
        self._update_status.error_message = "다운로드 실패 (최대 재시도 초과)"
        return None

    # --- 검증 ---

    def _verify_hash(self, filepath: Path, expected_hash: str) -> bool:
        """SHA256 해시 검증"""
        if not expected_hash:
            logger.warning("예상 해시 없음 — 검증 생략")
            return True

        logger.info("해시 검증 중: %s", filepath)
        sha256 = hashlib.sha256()
        with open(filepath, "rb") as f:
            while True:
                chunk = f.read(DOWNLOAD_CHUNK_SIZE)
                if not chunk:
                    break
                sha256.update(chunk)

        actual_hash = sha256.hexdigest()
        if actual_hash == expected_hash:
            logger.info("해시 검증 통과")
            return True
        else:
            logger.error("해시 불일치! 예상: %s, 실제: %s", expected_hash, actual_hash)
            return False

    # --- 설치 ---

    def install_update(self, firmware: FirmwareVersion, filepath: Path) -> bool:
        """
        펌웨어 설치

        Args:
            firmware: 설치할 펌웨어 버전 정보
            filepath: 다운로드된 펌웨어 파일 경로

        Returns:
            설치 성공 여부
        """
        self._update_status.state = UpdateState.VERIFYING

        # 해시 검증
        if firmware.sha256_hash and not self._verify_hash(filepath, firmware.sha256_hash):
            self._update_status.state = UpdateState.FAILED
            self._update_status.error_message = "해시 검증 실패 — 파일 손상"
            return False

        # 백업 생성 (롤백용)
        self._create_backup()

        self._update_status.state = UpdateState.INSTALLING
        logger.info("펌웨어 설치 시작: v%s", firmware.version)

        try:
            if firmware.target == UpdateTarget.JETSON:
                success = self._install_jetson(filepath)
            else:
                success = self._install_esp32(filepath)

            if success:
                self._save_current_version(firmware.version)
                self._update_status.state = UpdateState.COMPLETED
                self._update_status.target_version = firmware.version
                self._update_status.elapsed_s = time.time() - self._update_status.start_time
                logger.info("펌웨어 설치 완료: v%s (%.1f초)", firmware.version, self._update_status.elapsed_s)

                if self._on_update_complete:
                    self._on_update_complete(True, firmware.version)
            else:
                self._update_status.state = UpdateState.FAILED
                logger.error("펌웨어 설치 실패 — 롤백 시작")
                self.rollback()

            return success

        except Exception as e:
            logger.error("펌웨어 설치 예외: %s", e)
            self._update_status.state = UpdateState.FAILED
            self._update_status.error_message = str(e)
            self.rollback()
            return False

    def _install_jetson(self, filepath: Path) -> bool:
        """Jetson 펌웨어 설치 (tar.gz 아카이브)"""
        try:
            install_dir = Path("/opt/jihun")
            # 아카이브 해제
            result = subprocess.run(
                ["tar", "-xzf", str(filepath), "-C", str(install_dir)],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode != 0:
                logger.error("아카이브 해제 실패: %s", result.stderr)
                return False

            # systemd 서비스 재시작
            result = subprocess.run(
                ["sudo", "systemctl", "restart", "jihun.service"],
                capture_output=True, text=True, timeout=30,
            )
            return result.returncode == 0
        except Exception as e:
            logger.error("Jetson 설치 오류: %s", e)
            return False

    def _install_esp32(self, filepath: Path) -> bool:
        """ESP32 펌웨어 설치 (esptool 플래시)"""
        try:
            result = subprocess.run(
                [
                    "esptool.py", "--chip", "esp32s3",
                    "--port", "/dev/ttyUSB0",
                    "--baud", "460800",
                    "write_flash", "-z", "0x0",
                    str(filepath),
                ],
                capture_output=True, text=True, timeout=300,
            )
            return result.returncode == 0
        except Exception as e:
            logger.error("ESP32 플래시 오류: %s", e)
            return False

    # --- 롤백 ---

    def _create_backup(self) -> None:
        """현재 펌웨어 백업 (롤백용)"""
        try:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            backup_path = self._backup_dir / f"backup_{timestamp}"
            shutil.copytree("/opt/jihun/software", backup_path / "software",
                            dirs_exist_ok=True)
            self._rollback_info = RollbackInfo(
                backup_version=self._current_version,
                backup_path=str(backup_path),
                backup_timestamp=time.time(),
                can_rollback=True,
            )
            logger.info("백업 생성: %s (v%s)", backup_path, self._current_version)
        except Exception as e:
            logger.error("백업 생성 실패: %s", e)
            self._rollback_info.can_rollback = False

    def rollback(self) -> bool:
        """
        이전 버전으로 롤백

        Returns:
            롤백 성공 여부
        """
        self._update_status.state = UpdateState.ROLLING_BACK
        logger.info("롤백 시작...")

        if not self._rollback_info.can_rollback:
            logger.error("롤백 불가 — 백업 없음")
            self._update_status.state = UpdateState.FAILED
            return False

        try:
            backup_path = Path(self._rollback_info.backup_path)
            if not backup_path.exists():
                logger.error("백업 경로 없음: %s", backup_path)
                return False

            # 백업에서 복원
            software_backup = backup_path / "software"
            if software_backup.exists():
                shutil.copytree(software_backup, "/opt/jihun/software", dirs_exist_ok=True)

            # 버전 복원
            self._save_current_version(self._rollback_info.backup_version)

            # 서비스 재시작
            subprocess.run(
                ["sudo", "systemctl", "restart", "jihun.service"],
                capture_output=True, timeout=30,
            )

            self._update_status.state = UpdateState.COMPLETED
            logger.info("롤백 완료: v%s", self._rollback_info.backup_version)
            return True

        except Exception as e:
            logger.error("롤백 실패: %s", e)
            self._update_status.state = UpdateState.FAILED
            return False

    # --- 유틸리티 ---

    @staticmethod
    def _compare_versions(v1: str, v2: str) -> int:
        """세만틱 버전 비교 (v1 > v2 → 양수)"""
        parts1 = [int(x) for x in v1.split(".")]
        parts2 = [int(x) for x in v2.split(".")]
        for a, b in zip(parts1, parts2):
            if a != b:
                return a - b
        return len(parts1) - len(parts2)

    def get_status(self) -> Dict:
        """업데이트 관리자 상태 반환"""
        return {
            "current_version": self._current_version,
            "update_state": self._update_status.state.value,
            "target_version": self._update_status.target_version,
            "progress_percent": self._update_status.progress_percent,
            "error_message": self._update_status.error_message,
            "can_rollback": self._rollback_info.can_rollback,
            "rollback_version": self._rollback_info.backup_version,
        }


# ============================================================================
# 메인 진입점
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    ota = OTAUpdateManager()
    print("=== OTA 업데이트 관리자 테스트 ===")
    print(f"현재 버전: {ota._current_version}")

    # 업데이트 확인
    print("\n--- 업데이트 확인 ---")
    for target in UpdateTarget:
        new = ota.check_update(target)
        if new:
            print(f"새 버전 발견 ({target.value}): v{new.version}")
            print(f"  URL: {new.download_url}")
            print(f"  크기: {new.file_size_bytes} bytes")
            print(f"  변경사항: {new.changelog[:100]}...")
        else:
            print(f"최신 버전입니다 ({target.value})")

    print(f"\n상태: {ota.get_status()}")
