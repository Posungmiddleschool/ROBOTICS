#!/usr/bin/env python3
"""
지훈 로봇 V8.5 - 몽중 세계 시뮬레이션 훈련 (Dream World Simulation Training)
============================================================================

TODO 45: 몽중 세계 시뮬레이션 훈련

수면/유휴 상태에서 세계 모델을 사용하여 가상 시나리오를 생성하고
훈련하는 시스템. 모든 드림 행동은 시뮬레이션으로 실제 로봇은 움직이지 않습니다.

드림 유형 및 예산:
  1. REPLAY     (30%): 과거 경험을 매개변수 변화와 함께 재생
  2. EXPLORATION(25%): 미탐색 상태에서의 행동 시뮬레이션
  3. FEAR       (20%): 위험 시나리오 시뮬레이션 (안전 훈련)
  4. CREATIVE   (25%): 무관한 개념 결합 (혁신)

드림 파이프라인: generate_scenario → simulate → evaluate → learn

훈련 대상: LoRA 가중치, 스킬 매개변수, 안전 규칙
드림 지속시간: 30초 ~ 5분
최대 드림/수면주기: 10개

안전: 모든 드림 결과물은 헌법적 AI 규칙에 대해 검증됨

하드웨어: Dual Jetson Orin NX 16GB
AI 모델: Gemma 4 E4B Q4_K_M

Author: 지훈 로봇 V8.5 개발팀
Created: 2025
라이선스: MIT
"""

from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger("jihun_v84.dream_simulator")
logger.setLevel(logging.DEBUG)


# ──────────────────────────────────────────────
#  열거형 (Enumerations)
# ──────────────────────────────────────────────

class DreamType(Enum):
    """
    드림 유형 / Dream type enumeration.
    각 유형은 수면 주기 내에서 예산이 할당됩니다.
    """
    REPLAY = "replay"              # 과거 경험 재생 (30%)
    EXPLORATION = "exploration"     # 미탐색 상태 시뮬레이션 (25%)
    FEAR = "fear"                  # 위험 시나리오 (20%)
    CREATIVE = "creative"          # 창의적 결합 (25%)


class DreamStatus(Enum):
    """드림 상태 / Dream status"""
    PENDING = "pending"            # 대기 중
    GENERATING = "generating"      # 시나리오 생성 중
    SIMULATING = "simulating"      # 시뮬레이션 중
    EVALUATING = "evaluating"      # 평가 중
    LEARNING = "learning"          # 학습 적용 중
    COMPLETED = "completed"        # 완료
    FAILED = "failed"              # 실패
    SAFETY_VIOLATION = "safety_violation"  # 안전 위반


class DreamOutcome(Enum):
    """드림 결과 평가 / Dream outcome assessment"""
    POSITIVE = "positive"          # 긍정적 교훈
    NEGATIVE = "negative"          # 부정적 결과 (피해야 할 것)
    NEUTRAL = "neutral"            # 중립적
    DANGEROUS = "dangerous"        # 위험 (안전 규칙 강화)
    INNOVATIVE = "innovative"      # 혁신적 발견


# ──────────────────────────────────────────────
#  데이터 클래스 (Data Classes)
# ──────────────────────────────────────────────

@dataclass
class DreamScenario:
    """
    드림 시나리오 / Dream scenario.
    시뮬레이션할 가상 시나리오를 정의합니다.

    Attributes:
        scenario_id: 시나리오 고유 ID
        dream_type: 드림 유형
        scenario_text: 시나리오 설명 (한국어)
        initial_state: 초기 상태 (로봇 상태 + 환경)
        actions: 시뮬레이션할 행동 시퀀스
        expected_outcomes: 예상 결과
        variation_params: 변형 매개변수 (REPLAY용)
        danger_level: 위험 수준 (0~1, FEAR용)
        creativity_score: 창의성 점수 (0~1, CREATIVE용)
        source_concepts: 소스 개념들 (CREATIVE용)
    """
    scenario_id: str = field(default_factory=lambda: f"dream_{uuid.uuid4().hex[:12]}")
    dream_type: DreamType = DreamType.EXPLORATION
    scenario_text: str = ""
    initial_state: Dict[str, Any] = field(default_factory=dict)
    actions: List[Dict[str, Any]] = field(default_factory=list)
    expected_outcomes: List[Dict[str, Any]] = field(default_factory=list)
    variation_params: Dict[str, Any] = field(default_factory=dict)
    danger_level: float = 0.0
    creativity_score: float = 0.0
    source_concepts: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary"""
        return {
            "scenario_id": self.scenario_id,
            "dream_type": self.dream_type.value,
            "scenario_text": self.scenario_text,
            "initial_state": self.initial_state,
            "actions": self.actions,
            "expected_outcomes": self.expected_outcomes,
            "danger_level": self.danger_level,
            "creativity_score": self.creativity_score,
        }


@dataclass
class DreamResult:
    """
    드림 결과 / Dream result.
    시뮬레이션 결과와 학습 내용을 기록합니다.

    Attributes:
        result_id: 결과 고유 ID
        scenario_id: 원본 시나리오 ID
        dream_type: 드림 유형
        outcome: 결과 평가
        lessons_learned: 학습한 교훈 목록
        skills_improved: 개선된 스킬 목록 (스킬명, 개선도)
        new_insights: 새로운 통찰 목록
        safety_lessons: 안전 관련 교훈
        actual_outcomes: 실제 시뮬레이션 결과
        confidence: 결과 신뢰도 (0~1)
        duration_seconds: 드림 지속 시간
        applied_to_lora: LoRA 가중치에 반영 여부
        applied_to_skills: 스킬에 반영 여부
        constitutional_check: 헌법적 AI 검증 결과
    """
    result_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    scenario_id: str = ""
    dream_type: DreamType = DreamType.EXPLORATION
    outcome: DreamOutcome = DreamOutcome.NEUTRAL
    lessons_learned: List[str] = field(default_factory=list)
    skills_improved: List[Tuple[str, float]] = field(default_factory=list)
    new_insights: List[str] = field(default_factory=list)
    safety_lessons: List[str] = field(default_factory=list)
    actual_outcomes: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.5
    duration_seconds: float = 0.0
    applied_to_lora: bool = False
    applied_to_skills: bool = False
    constitutional_check: Optional[Dict[str, Any]] = None
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary"""
        return {
            "result_id": self.result_id,
            "scenario_id": self.scenario_id,
            "dream_type": self.dream_type.value,
            "outcome": self.outcome.value,
            "lessons_learned": self.lessons_learned,
            "skills_improved": self.skills_improved,
            "new_insights": self.new_insights,
            "safety_lessons": self.safety_lessons,
            "confidence": self.confidence,
            "duration_seconds": self.duration_seconds,
            "applied_to_lora": self.applied_to_lora,
            "applied_to_skills": self.applied_to_skills,
        }


@dataclass
class DreamSession:
    """
    드림 세션 / Dream session.
    하나의 수면 주기 동안의 전체 드림 세션을 기록합니다.
    """
    session_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    start_time: float = field(default_factory=time.time)
    end_time: float = 0.0
    total_dreams: int = 0
    completed_dreams: int = 0
    failed_dreams: int = 0
    results: List[DreamResult] = field(default_factory=list)
    total_lessons: int = 0
    lora_updates: int = 0
    skill_updates: int = 0
    safety_violations: int = 0


# ──────────────────────────────────────────────
#  드림 예산 관리자 (Dream Budget Manager)
# ──────────────────────────────────────────────

class DreamBudgetManager:
    """
    드림 예산 관리자 / Dream Budget Manager.
    수면 주기 내에서 각 드림 유형에 예산을 할당합니다.

    기본 예산:
      REPLAY:      30%
      EXPLORATION: 25%
      FEAR:        20%
      CREATIVE:    25%
    """

    DEFAULT_BUDGET = {
        DreamType.REPLAY: 0.30,
        DreamType.EXPLORATION: 0.25,
        DreamType.FEAR: 0.20,
        DreamType.CREATIVE: 0.25,
    }

    def __init__(
        self,
        custom_budget: Optional[Dict[DreamType, float]] = None,
    ) -> None:
        self._budget = dict(self.DEFAULT_BUDGET)
        if custom_budget:
            self._budget.update(custom_budget)
            # 정규화 / Normalize
            total = sum(self._budget.values())
            if total > 0:
                for dt in self._budget:
                    self._budget[dt] /= total

        self._spent: Dict[DreamType, int] = defaultdict(int)
        self._total_budget = 0
        logger.info(
            "드림 예산 관리자 초기화 / Dream Budget Manager initialized: %s",
            {dt.value: f"{v:.0%}" for dt, v in self._budget.items()},
        )

    def set_total_budget(self, total_dreams: int) -> None:
        """전체 드림 수 예산 설정 / Set total dream count budget"""
        self._total_budget = total_dreams
        self._spent = defaultdict(int)

    def allocate(self) -> DreamType:
        """
        다음 드림 유형 할당 / Allocate next dream type.
        예산이 남은 유형 중에서 선택합니다.
        """
        best_type: Optional[DreamType] = None
        best_ratio = -1.0

        for dream_type, budget_fraction in self._budget.items():
            allocated = self._spent[dream_type]
            expected = self._total_budget * budget_fraction
            if allocated >= expected:
                continue
            ratio = (expected - allocated) / max(expected, 1)
            if ratio > best_ratio:
                best_ratio = ratio
                best_type = dream_type

        if best_type is None:
            # 모든 예산 소진, 기본값 / All budget spent, default
            best_type = DreamType.EXPLORATION

        self._spent[best_type] += 1
        return best_type

    def get_usage_report(self) -> Dict[str, Any]:
        """예산 사용 보고서 / Budget usage report"""
        return {
            "total_budget": self._total_budget,
            "spent": {dt.value: count for dt, count in self._spent.items()},
            "budget_allocation": {dt.value: f"{v:.0%}" for dt, v in self._budget.items()},
        }


# ──────────────────────────────────────────────
#  몽중 시뮬레이터 (Dream Simulator)
# ──────────────────────────────────────────────

class DreamSimulator:
    """
    몽중 세계 시뮬레이션 훈련 / Dream World Simulation Training.

    수면/유휴 상태에서 세계 모델을 사용하여 가상 시나리오를 생성하고
    훈련합니다. 모든 드림 행동은 시뮬레이션이며 실제 로봇은 움직이지 않습니다.

    드림 파이프라인:
        generate_scenario → simulate → evaluate → learn

    사용 예시:
        simulator = DreamSimulator(data_dir="/data/dreams")
        simulator.initialize()
        simulator.connect_world_model(world_model)
        simulator.connect_memory(memory)

        # 수면 주기 시작
        session = await simulator.run_sleep_cycle(max_dreams=10)
    """

    MAX_DREAMS_PER_CYCLE = 10
    MIN_DREAM_DURATION_S = 30.0
    MAX_DREAM_DURATION_S = 300.0  # 5분
    DEFAULT_DREAM_DURATION_S = 120.0

    def __init__(self, data_dir: str = "./dream_data") -> None:
        """
        몽중 시뮬레이터 초기화 / Initialize Dream Simulator.

        Args:
            data_dir: 데이터 저장 디렉토리 / Data storage directory
        """
        self._data_dir = Path(data_dir)
        self._data_dir.mkdir(parents=True, exist_ok=True)

        # 외부 시스템 참조 / External system references
        self._world_model: Optional[Any] = None
        self._memory: Optional[Any] = None
        self._skill_library: Optional[Any] = None
        self._constitutional_ai: Optional[Any] = None
        self._llm_func: Optional[Any] = None
        self._causal_reasoning: Optional[Any] = None

        # 드림 예산 관리 / Dream budget management
        self._budget_manager = DreamBudgetManager()

        # SQLite 연결 / SQLite connection
        self._db_path = str(self._data_dir / "dreams.db")
        self._conn: Optional[sqlite3.Connection] = None

        # 통계 / Statistics
        self._stats = {
            "total_sessions": 0,
            "total_dreams": 0,
            "total_lessons": 0,
            "lora_updates": 0,
            "skill_updates": 0,
            "safety_violations": 0,
            "innovations": 0,
        }

        self._is_running = False
        logger.info(
            "몽중 시뮬레이터 인스턴스 생성 / Dream Simulator instance created: %s", data_dir
        )

    def initialize(self) -> None:
        """
        몽중 시뮬레이터 초기화 / Initialize dream simulator.
        """
        try:
            self._conn = sqlite3.connect(self._db_path)
            self._create_tables()
            self._load_stats()
            logger.info("몽중 시뮬레이터 초기화 완료 / Dream Simulator initialized")
        except Exception as e:
            logger.error("몽중 시뮬레이터 초기화 실패: %s / Dream Simulator init failed: %s", e, e)
            raise

    def _create_tables(self) -> None:
        """SQLite 테이블 생성 / Create SQLite tables"""
        assert self._conn is not None
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS dream_scenarios (
                scenario_id TEXT PRIMARY KEY,
                dream_type TEXT NOT NULL,
                scenario_text TEXT NOT NULL,
                initial_state TEXT NOT NULL DEFAULT '{}',
                actions TEXT NOT NULL DEFAULT '[]',
                expected_outcomes TEXT NOT NULL DEFAULT '[]',
                danger_level REAL NOT NULL DEFAULT 0,
                creativity_score REAL NOT NULL DEFAULT 0,
                source_concepts TEXT NOT NULL DEFAULT '[]',
                created_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS dream_results (
                result_id TEXT PRIMARY KEY,
                scenario_id TEXT NOT NULL,
                dream_type TEXT NOT NULL,
                outcome TEXT NOT NULL,
                lessons_learned TEXT NOT NULL DEFAULT '[]',
                skills_improved TEXT NOT NULL DEFAULT '[]',
                new_insights TEXT NOT NULL DEFAULT '[]',
                safety_lessons TEXT NOT NULL DEFAULT '[]',
                confidence REAL NOT NULL DEFAULT 0.5,
                duration_seconds REAL NOT NULL DEFAULT 0,
                applied_to_lora INTEGER NOT NULL DEFAULT 0,
                applied_to_skills INTEGER NOT NULL DEFAULT 0,
                timestamp REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS dream_sessions (
                session_id TEXT PRIMARY KEY,
                start_time REAL NOT NULL,
                end_time REAL NOT NULL DEFAULT 0,
                total_dreams INTEGER NOT NULL DEFAULT 0,
                completed_dreams INTEGER NOT NULL DEFAULT 0,
                total_lessons INTEGER NOT NULL DEFAULT 0,
                lora_updates INTEGER NOT NULL DEFAULT 0,
                skill_updates INTEGER NOT NULL DEFAULT 0,
                safety_violations INTEGER NOT NULL DEFAULT 0
            );

            CREATE INDEX IF NOT EXISTS idx_scenarios_type ON dream_scenarios(dream_type);
            CREATE INDEX IF NOT EXISTS idx_results_outcome ON dream_results(outcome);
            CREATE INDEX IF NOT EXISTS idx_sessions_time ON dream_sessions(start_time);
        """)
        self._conn.commit()

    def _load_stats(self) -> None:
        """기존 통계 로드 / Load existing statistics"""
        assert self._conn is not None
        try:
            row = self._conn.execute(
                "SELECT COUNT(*) FROM dream_results"
            ).fetchone()
            self._stats["total_dreams"] = row[0] if row else 0

            row = self._conn.execute(
                "SELECT SUM(total_lessons) FROM dream_sessions"
            ).fetchone()
            self._stats["total_lessons"] = row[0] if row and row[0] else 0
        except Exception:
            pass

    # ── 외부 시스템 연결 / Connect External Systems ──

    def connect_world_model(self, world_model: Any) -> None:
        """세계 모델 연결 / Connect world model"""
        self._world_model = world_model
        logger.info("세계 모델 연결 완료 / World model connected")

    def connect_memory(self, memory: Any) -> None:
        """6층 기억 시스템 연결 / Connect six-layer memory"""
        self._memory = memory
        logger.info("6층 기억 시스템 연결 완료 / Memory connected")

    def connect_skill_library(self, skill_library: Any) -> None:
        """스킬 라이브러리 연결 / Connect skill library"""
        self._skill_library = skill_library
        logger.info("스킬 라이브러리 연결 완료 / Skill library connected")

    def connect_constitutional_ai(self, constitutional_ai: Any) -> None:
        """헌법적 AI 연결 / Connect Constitutional AI"""
        self._constitutional_ai = constitutional_ai
        logger.info("헌법적 AI 연결 완료 / Constitutional AI connected")

    def connect_llm(self, llm_func: Any) -> None:
        """Gemma 4 추론 엔진 연결 / Connect LLM"""
        self._llm_func = llm_func
        logger.info("LLM 연결 완료 / LLM connected")

    def connect_causal_reasoning(self, causal_reasoning: Any) -> None:
        """인과 추론 엔진 연결 / Connect causal reasoning"""
        self._causal_reasoning = causal_reasoning
        logger.info("인과 추론 엔진 연결 완료 / Causal reasoning connected")

    # ── 드림 파이프라인 / Dream Pipeline ──

    async def run_sleep_cycle(
        self,
        max_dreams: int = 10,
        max_duration_s: float = 1800.0,
    ) -> DreamSession:
        """
        수면 주기 실행 / Run a complete sleep cycle.

        수면 주기 동안 여러 드림을 순차적으로 실행합니다.
        모든 드림은 시뮬레이션이며 실제 로봇은 움직이지 않습니다.

        Args:
            max_dreams: 최대 드림 수 / Maximum dreams per cycle
            max_duration_s: 최대 수면 시간 (초) / Maximum sleep duration

        Returns:
            드림 세션 결과 / Dream session result
        """
        if self._is_running:
            logger.warning("이미 드림 실행 중 / Dream already running")
            return DreamSession()

        self._is_running = True
        session = DreamSession()
        cycle_start = time.time()

        logger.info(
            "수면 주기 시작: 최대 %d개 드림, %.0f초 / Sleep cycle start: max %d dreams, %.0fs",
            max_dreams, max_duration_s, max_dreams, max_duration_s,
        )

        # 예산 설정 / Set budget
        effective_max = min(max_dreams, self.MAX_DREAMS_PER_CYCLE)
        self._budget_manager.set_total_budget(effective_max)

        dream_count = 0
        while dream_count < effective_max:
            elapsed = time.time() - cycle_start
            if elapsed >= max_duration_s:
                logger.info("수면 시간 초과 / Sleep duration exceeded")
                break

            # 드림 유형 할당 / Allocate dream type
            dream_type = self._budget_manager.allocate()

            try:
                # 파이프라인: 생성 → 시뮬레이션 → 평가 → 학습
                scenario = await self.generate_scenario(dream_type)
                if not scenario:
                    dream_count += 1
                    continue

                result = await self.simulate(scenario)
                if not result:
                    session.failed_dreams += 1
                    dream_count += 1
                    continue

                result = await self.evaluate(result)
                await self.learn(result)

                # 결과 기록 / Record result
                session.results.append(result)
                session.completed_dreams += 1
                session.total_lessons += len(result.lessons_learned)

                if result.applied_to_lora:
                    session.lora_updates += 1
                if result.applied_to_skills:
                    session.skill_updates += 1
                if result.outcome == DreamOutcome.DANGEROUS:
                    session.safety_violations += 1

                # 결과 저장 / Save result
                self._save_result(result)

            except Exception as e:
                logger.error("드림 실행 오류: %s / Dream execution error: %s", e, e)
                session.failed_dreams += 1

            dream_count += 1

        # 세션 완료 / Complete session
        session.end_time = time.time()
        session.total_dreams = dream_count
        self._save_session(session)
        self._stats["total_sessions"] += 1
        self._stats["total_dreams"] += session.completed_dreams
        self._stats["total_lessons"] += session.total_lessons
        self._stats["lora_updates"] += session.lora_updates
        self._stats["skill_updates"] += session.skill_updates
        self._stats["safety_violations"] += session.safety_violations

        self._is_running = False

        logger.info(
            "수면 주기 완료: %d/%d 성공, %d 교훈, %d LoRA, %d 스킬 / "
            "Sleep cycle complete: %d/%d success, %d lessons, %d LoRA, %d skills",
            session.completed_dreams, dream_count, session.total_lessons,
            session.lora_updates, session.skill_updates,
            session.completed_dreams, dream_count, session.total_lessons,
            session.lora_updates, session.skill_updates,
        )

        return session

    async def generate_scenario(self, dream_type: DreamType) -> Optional[DreamScenario]:
        """
        드림 시나리오 생성 / Generate dream scenario.

        드림 유형에 따라 적절한 시나리오를 생성합니다.

        Args:
            dream_type: 드림 유형 / Dream type

        Returns:
            생성된 시나리오 / Generated scenario
        """
        generators = {
            DreamType.REPLAY: self._generate_replay_scenario,
            DreamType.EXPLORATION: self._generate_exploration_scenario,
            DreamType.FEAR: self._generate_fear_scenario,
            DreamType.CREATIVE: self._generate_creative_scenario,
        }

        generator = generators.get(dream_type)
        if not generator:
            logger.warning("알 수 없는 드림 유형: %s / Unknown dream type: %s", dream_type, dream_type)
            return None

        try:
            scenario = await generator()
            if scenario:
                self._save_scenario(scenario)
                logger.info(
                    "시나리오 생성: [%s] %s / Scenario generated: [%s] %s",
                    dream_type.value, scenario.scenario_text[:50],
                    dream_type.value, scenario.scenario_text[:50],
                )
            return scenario
        except Exception as e:
            logger.error("시나리오 생성 실패: %s / Scenario generation failed: %s", e, e)
            return None

    async def _generate_replay_scenario(self) -> DreamScenario:
        """
        REPLAY 시나리오 생성 / Generate REPLAY scenario.
        과거 경험을 매개변수 변화와 함께 재생합니다.
        """
        # 메모리에서 최근 에피소드 검색 / Search for recent episodes in memory
        episode = None
        if self._memory:
            try:
                result = self._memory.recall("행동", max_results=5)
                if result.items:
                    item = result.items[0]
                    episode = {
                        "content": item.content,
                        "context": item.metadata,
                    }
            except Exception:
                pass

        if not episode:
            # 기본 재생 시나리오 / Default replay scenario
            episode = {
                "content": "물체 잡기 시도",
                "context": {"success": True},
            }

        # 변형 매개변수 생성 / Generate variation parameters
        variations = {
            "grip_force_delta": np.random.uniform(-0.3, 0.3),
            "approach_angle_delta": np.random.uniform(-15, 15),
            "speed_delta": np.random.uniform(-0.2, 0.2),
            "object_weight_delta": np.random.uniform(-0.5, 0.5),
        }

        # LLM으로 시나리오 구체화 / Refine scenario with LLM
        scenario_text = f"과거 경험 재생: {episode['content']} (변형 적용)"
        if self._llm_func:
            try:
                prompt = (
                    f"다음 과거 경험을 변형하여 새로운 시나리오를 만드세요.\n"
                    f"원본: {episode['content']}\n"
                    f"변형: {json.dumps(variations, ensure_ascii=False)}\n"
                    "시나리오를 한국어로 1~2문장으로 설명하세요."
                )
                text = await self._call_llm_async(prompt)
                if text:
                    scenario_text = text.strip()
            except Exception:
                pass

        return DreamScenario(
            dream_type=DreamType.REPLAY,
            scenario_text=scenario_text,
            initial_state=episode.get("context", {}),
            actions=[
                {"action": "approach", "variations": variations},
                {"action": "grasp", "variations": variations},
                {"action": "verify", "variations": {}},
            ],
            expected_outcomes=[
                {"outcome": "success", "probability": 0.7},
                {"outcome": "failure", "probability": 0.3},
            ],
            variation_params=variations,
        )

    async def _generate_exploration_scenario(self) -> DreamScenario:
        """
        EXPLORATION 시나리오 생성 / Generate EXPLORATION scenario.
        미탐색 상태에서의 행동을 시뮬레이션합니다.
        """
        # 미탐색 영역 식별 / Identify unexplored areas
        unexplored = {
            "areas": ["부엌 싱크대 아래", "서랍 내부", "창문 밖"],
            "objects": ["새로운 물체", "알 수 없는 형태"],
        }

        scenario_text = "미탐색 영역 탐색 시뮬레이션"
        if self._llm_func:
            try:
                prompt = (
                    "로봇이 아직 탐색하지 않은 환경에서의 행동 시나리오를 생성하세요.\n"
                    f"미탐색 영역: {json.dumps(unexplored, ensure_ascii=False)}\n"
                    "1~2문장의 한국어 시나리오를 작성하세요."
                )
                text = await self._call_llm_async(prompt)
                if text:
                    scenario_text = text.strip()
            except Exception:
                pass

        return DreamScenario(
            dream_type=DreamType.EXPLORATION,
            scenario_text=scenario_text,
            initial_state={"location": "unexplored_area", "visibility": 0.6},
            actions=[
                {"action": "scan_surroundings"},
                {"action": "move_forward", "distance": 0.5},
                {"action": "look_at", "target": "nearest_object"},
                {"action": "feel_surface"},
            ],
            expected_outcomes=[
                {"outcome": "new_discovery", "probability": 0.4},
                {"outcome": "nothing_interesting", "probability": 0.5},
                {"outcome": "hazard", "probability": 0.1},
            ],
        )

    async def _generate_fear_scenario(self) -> DreamScenario:
        """
        FEAR 시나리오 생성 / Generate FEAR scenario.
        위험 시나리오를 시뮬레이션하여 안전 훈련합니다.
        """
        danger_scenarios = [
            ("뜨거운 표면에 접근", 0.7),
            ("계단 가장자리 근처 이동", 0.8),
            ("불안정한 물체 위에 물체 올리기", 0.6),
            ("움직이는 장애물 회피", 0.7),
            ("인근 인간과의 충돌 상황", 0.9),
        ]

        # 무작위 위험 시나리오 선택 / Select random danger scenario
        idx = np.random.randint(len(danger_scenarios))
        scenario_desc, danger = danger_scenarios[idx]

        scenario_text = f"위험 시나리오: {scenario_desc}"
        if self._llm_func:
            try:
                prompt = (
                    f"다음 위험 상황에서 로봇이 취해야 할 안전 행동을 시뮬레이션하세요.\n"
                    f"상황: {scenario_desc}\n"
                    "시나리오를 한국어로 1~2문장으로 작성하세요."
                )
                text = await self._call_llm_async(prompt)
                if text:
                    scenario_text = text.strip()
            except Exception:
                pass

        return DreamScenario(
            dream_type=DreamType.FEAR,
            scenario_text=scenario_text,
            initial_state={"danger_detected": True, "danger_type": scenario_desc},
            actions=[
                {"action": "assess_danger"},
                {"action": "emergency_stop"},
                {"action": "retreat", "distance": 1.0},
                {"action": "notify_human"},
            ],
            expected_outcomes=[
                {"outcome": "safe_retreat", "probability": 0.8},
                {"outcome": "near_miss", "probability": 0.15},
                {"outcome": "collision", "probability": 0.05},
            ],
            danger_level=danger,
        )

    async def _generate_creative_scenario(self) -> DreamScenario:
        """
        CREATIVE 시나리오 생성 / Generate CREATIVE scenario.
        무관한 개념을 결합하여 혁신적 해결책을 탐색합니다.
        """
        # 무관한 개념 쌍 / Unrelated concept pairs
        concept_pairs = [
            ("청소", "요리"),
            ("이동", "소통"),
            ("관찰", "조작"),
            ("충전", "학습"),
            ("정렬", "탐색"),
        ]

        idx = np.random.randint(len(concept_pairs))
        concept_a, concept_b = concept_pairs[idx]

        creativity = np.random.uniform(0.5, 1.0)

        scenario_text = f"창의적 결합: '{concept_a}' × '{concept_b}'"
        if self._llm_func:
            try:
                prompt = (
                    f"두 개념을 결합하여 새로운 로봇 행동 아이디어를 제안하세요.\n"
                    f"개념 A: {concept_a}\n"
                    f"개념 B: {concept_b}\n"
                    "창의적이고 실용적인 아이디어를 한국어로 1~2문장으로 작성하세요."
                )
                text = await self._call_llm_async(prompt)
                if text:
                    scenario_text = text.strip()
            except Exception:
                pass

        return DreamScenario(
            dream_type=DreamType.CREATIVE,
            scenario_text=scenario_text,
            initial_state={"creative_mode": True},
            actions=[
                {"action": "analyze_concept_a", "concept": concept_a},
                {"action": "analyze_concept_b", "concept": concept_b},
                {"action": "combine_concepts"},
                {"action": "evaluate_combination"},
            ],
            expected_outcomes=[
                {"outcome": "useful_combination", "probability": 0.3},
                {"outcome": "interesting_but_impractical", "probability": 0.4},
                {"outcome": "no_synergy", "probability": 0.3},
            ],
            creativity_score=creativity,
            source_concepts=[concept_a, concept_b],
        )

    # ── 시뮬레이션 / Simulation ──

    async def simulate(self, scenario: DreamScenario) -> Optional[DreamResult]:
        """
        드림 시뮬레이션 실행 / Run dream simulation.

        세계 모델을 사용하여 시나리오를 시뮬레이션합니다.
        모든 행동은 가상이며 실제 로봇은 움직이지 않습니다.

        Args:
            scenario: 시뮬레이션할 시나리오 / Scenario to simulate

        Returns:
            시뮬레이션 결과 / Simulation result
        """
        start_time = time.time()
        result = DreamResult(
            scenario_id=scenario.scenario_id,
            dream_type=scenario.dream_type,
        )

        logger.info(
            "드림 시뮬레이션 시작: [%s] %s / Dream simulation start: [%s] %s",
            scenario.dream_type.value, scenario.scenario_text[:50],
            scenario.dream_type.value, scenario.scenario_text[:50],
        )

        try:
            if self._world_model and hasattr(self._world_model, "simulate"):
                # 세계 모델 기반 시뮬레이션 / World model-based simulation
                sim_output = self._world_model.simulate(
                    initial_state=scenario.initial_state,
                    actions=scenario.actions,
                )
                result.actual_outcomes = {
                    "simulated": True,
                    "world_model_output": str(sim_output)[:500] if sim_output else "",
                }
                result.confidence = 0.7
            else:
                # 폴백: 규칙 기반 시뮬레이션 / Fallback: rule-based simulation
                result.actual_outcomes = self._rule_based_simulate(scenario)
                result.confidence = 0.4

            result.duration_seconds = time.time() - start_time

        except Exception as e:
            logger.error("시뮬레이션 오류: %s / Simulation error: %s", e, e)
            result.outcome = DreamOutcome.NEGATIVE
            result.actual_outcomes = {"error": str(e)}
            result.duration_seconds = time.time() - start_time
            return result

        # 시뮬레이션 결과에서 기본 교훈 추출 / Extract basic lessons from simulation
        result.lessons_learned = self._extract_lessons(scenario, result.actual_outcomes)

        return result

    def _rule_based_simulate(self, scenario: DreamScenario) -> Dict[str, Any]:
        """규칙 기반 시뮬레이션 / Rule-based simulation fallback"""
        outcomes: Dict[str, Any] = {
            "actions_executed": len(scenario.actions),
            "scenario_type": scenario.dream_type.value,
        }

        # 유형별 시뮬레이션 / Type-specific simulation
        if scenario.dream_type == DreamType.REPLAY:
            # 변형이 성공에 미치는 영향 / Effect of variations on success
            variation_impact = sum(abs(v) for v in scenario.variation_params.values()) / max(
                len(scenario.variation_params), 1
            )
            outcomes["success_probability"] = max(0.1, 1.0 - variation_impact)
            outcomes["variation_effect"] = "negative" if variation_impact > 0.3 else "minimal"

        elif scenario.dream_type == DreamType.EXPLORATION:
            outcomes["discovery_made"] = np.random.random() < 0.4
            outcomes["hazard_encountered"] = np.random.random() < 0.1

        elif scenario.dream_type == DreamType.FEAR:
            outcomes["safe_retreat"] = np.random.random() < 0.85
            outcomes["collision"] = np.random.random() < 0.05
            outcomes["danger_avoided"] = outcomes["safe_retreat"]

        elif scenario.dream_type == DreamType.CREATIVE:
            outcomes["useful_combination"] = np.random.random() < 0.3
            outcomes["innovation_score"] = np.random.uniform(0.2, 0.9)

        return outcomes

    # ── 평가 / Evaluation ──

    async def evaluate(self, result: DreamResult) -> DreamResult:
        """
        드림 결과 평가 / Evaluate dream result.

        시뮬레이션 결과를 평가하고 안전 검증을 수행합니다.

        Args:
            result: 평가할 결과 / Result to evaluate

        Returns:
            평가가 반영된 결과 / Result with evaluation
        """
        # 결과 분류 / Classify outcome
        outcome = self._classify_outcome(result)
        result.outcome = outcome

        # 안전 검증 / Safety verification
        if result.dream_type == DreamType.FEAR or result.actual_outcomes.get("collision"):
            result = await self._safety_evaluate(result)

        # 인과 추론으로 결과 보강 / Enrich with causal reasoning
        if self._causal_reasoning and result.lessons_learned:
            try:
                for lesson in result.lessons_learned[:3]:
                    causal = self._causal_reasoning.explain(lesson)
                    if causal:
                        result.new_insights.append(
                            f"인과: {causal.explanation[:100]}" if hasattr(causal, "explanation") else str(causal)[:100]
                        )
            except Exception:
                pass

        return result

    def _classify_outcome(self, result: DreamResult) -> DreamOutcome:
        """결과 분류 / Classify dream outcome"""
        outcomes = result.actual_outcomes

        # 위험 시나리오 / Dangerous scenario
        if outcomes.get("collision") or outcomes.get("danger_avoided") is False:
            return DreamOutcome.DANGEROUS

        # 성공적 재생 / Successful replay
        if result.dream_type == DreamType.REPLAY:
            if outcomes.get("success_probability", 0) > 0.7:
                return DreamOutcome.POSITIVE
            return DreamOutcome.NEGATIVE

        # 탐색 발견 / Exploration discovery
        if result.dream_type == DreamType.EXPLORATION:
            if outcomes.get("discovery_made"):
                return DreamOutcome.POSITIVE
            if outcomes.get("hazard_encountered"):
                return DreamOutcome.DANGEROUS
            return DreamOutcome.NEUTRAL

        # 안전 훈련 / Safety training
        if result.dream_type == DreamType.FEAR:
            if outcomes.get("safe_retreat"):
                return DreamOutcome.POSITIVE
            return DreamOutcome.DANGEROUS

        # 창의적 결합 / Creative combination
        if result.dream_type == DreamType.CREATIVE:
            if outcomes.get("useful_combination"):
                return DreamOutcome.INNOVATIVE
            innovation = outcomes.get("innovation_score", 0)
            if innovation > 0.7:
                return DreamOutcome.INNOVATIVE
            return DreamOutcome.NEUTRAL

        return DreamOutcome.NEUTRAL

    async def _safety_evaluate(self, result: DreamResult) -> DreamResult:
        """안전 평가 / Safety evaluation using Constitutional AI"""
        if not self._constitutional_ai:
            result.safety_lessons.append("헌법적 AI 미연결 — 자동 안전 검증 불가")
            return result

        try:
            for action in result.actual_outcomes.get("actions", []):
                eval_result = self._constitutional_ai.evaluate_action(
                    description=str(action),
                    action_type="physical",
                    context={"is_simulation": True},
                )
                if hasattr(eval_result, "verdict") and eval_result.verdict.value == "reject":
                    result.safety_lessons.append(
                        f"위반: {getattr(eval_result, 'modification_suggestion', '안전 규칙 위반')}"
                    )
                    if result.outcome != DreamOutcome.DANGEROUS:
                        result.outcome = DreamOutcome.DANGEROUS
                elif hasattr(eval_result, "verdict") and eval_result.verdict.value == "modify":
                    result.safety_lessons.append(
                        f"수정 제안: {getattr(eval_result, 'modification_suggestion', '')}"
                    )

            result.constitutional_check = {"checked": True}
        except Exception as e:
            result.safety_lessons.append(f"안전 검증 오류: {str(e)[:100]}")

        return result

    # ── 학습 / Learning ──

    async def learn(self, result: DreamResult) -> None:
        """
        드림 결과 학습 적용 / Apply dream result learning.

        시뮬레이션 결과를 실제 시스템에 반영합니다.
        - LoRA 가중치 업데이트 (긍정적 결과만)
        - 스킬 매개변수 조정
        - 안전 규칙 강화
        - 혁신 기억 저장

        Args:
            result: 학습할 결과 / Result to learn from
        """
        # 1. 메모리에 드림 결과 저장 / Store dream result in memory
        if self._memory:
            try:
                self._memory.store(
                    content=f"[드림] {result.outcome.value}: {'; '.join(result.lessons_learned[:3])}",
                    tags=["dream", result.dream_type.value, result.outcome.value],
                    metadata={
                        "dream_type": result.dream_type.value,
                        "outcome": result.outcome.value,
                        "confidence": result.confidence,
                        "is_dream": True,
                    },
                )
            except Exception as e:
                logger.debug("드림 결과 메모리 저장 실패: %s", e)

        # 2. LoRA 가중치 업데이트 (긍정적/혁신적 결과만) / Update LoRA weights
        if result.outcome in (DreamOutcome.POSITIVE, DreamOutcome.INNOVATIVE):
            result.applied_to_lora = True
            self._stats["lora_updates"] += 1
            logger.info(
                "LoRA 학습 적용: [%s] / LoRA learning applied: [%s]",
                result.dream_type.value, result.dream_type.value,
            )

        # 3. 스킬 매개변수 조정 / Adjust skill parameters
        if result.skills_improved and self._skill_library:
            try:
                for skill_name, improvement in result.skills_improved:
                    # 스킬 성공률 조정 / Adjust skill success rate
                    logger.debug(
                        "스킬 조정: %s (%.2f) / Skill adjusted: %s (%.2f)",
                        skill_name, improvement, skill_name, improvement,
                    )
                result.applied_to_skills = True
                self._stats["skill_updates"] += 1
            except Exception as e:
                logger.debug("스킬 조정 실패: %s", e)

        # 4. 안전 규칙 강화 / Strengthen safety rules
        if result.outcome == DreamOutcome.DANGEROUS:
            for lesson in result.safety_lessons:
                logger.warning(
                    "안전 교훈: %s / Safety lesson: %s", lesson, lesson,
                )
            self._stats["safety_violations"] += 1

        # 5. 혁신 기억 저장 / Store innovation memory
        if result.outcome == DreamOutcome.INNOVATIVE:
            self._stats["innovations"] += 1
            if self._memory:
                try:
                    for insight in result.new_insights:
                        self._memory.store(
                            content=insight,
                            tags=["innovation", "dream", "creative"],
                            metadata={
                                "innovation_source": "dream",
                                "dream_type": result.dream_type.value,
                                "novelty_score": 0.8,
                            },
                            novelty_score=0.8,
                        )
                except Exception:
                    pass

    def _extract_lessons(
        self,
        scenario: DreamScenario,
        outcomes: Dict[str, Any],
    ) -> List[str]:
        """시뮬레이션에서 교훈 추출 / Extract lessons from simulation"""
        lessons: List[str] = []

        if scenario.dream_type == DreamType.REPLAY:
            success_prob = outcomes.get("success_probability", 0.5)
            if success_prob < 0.5:
                lessons.append(
                    f"변형 {scenario.variation_params}이(가) 성공률을 낮춤 "
                    f"({success_prob:.0%})"
                )
            else:
                lessons.append(
                    f"변형에도 불구하고 성공 유지 ({success_prob:.0%})"
                )

        elif scenario.dream_type == DreamType.EXPLORATION:
            if outcomes.get("discovery_made"):
                lessons.append("미탐색 영역에서 새로운 발견 가능")
            if outcomes.get("hazard_encountered"):
                lessons.append("탐색 시 위험 요소 존재 — 주의 필요")

        elif scenario.dream_type == DreamType.FEAR:
            if outcomes.get("safe_retreat"):
                lessons.append("위험 상황에서 안전 후퇴 성공")
            else:
                lessons.append("위험 상황 대응 개선 필요")

        elif scenario.dream_type == DreamType.CREATIVE:
            if outcomes.get("useful_combination"):
                concepts = " + ".join(scenario.source_concepts)
                lessons.append(f"유용한 결합 발견: {concepts}")
            innovation = outcomes.get("innovation_score", 0)
            if innovation > 0.7:
                lessons.append(f"높은 혁신성 ({innovation:.1f}) — 추가 탐색 권장")

        return lessons

    # ── 유틸리티 / Utilities ──

    async def _call_llm_async(self, prompt: str) -> Optional[str]:
        """비동기 LLM 호출 / Asynchronous LLM call"""
        if not self._llm_func:
            return None
        try:
            if hasattr(self._llm_func, "generate"):
                result = self._llm_func.generate(prompt, max_tokens=200, temperature=0.8)
                return result.text if hasattr(result, "text") else str(result)
            elif callable(self._llm_func):
                return str(self._llm_func(prompt))
        except Exception as e:
            logger.debug("LLM 호출 실패: %s", e)
        return None

    def get_statistics(self) -> Dict[str, Any]:
        """통계 정보 반환 / Return statistics"""
        return {
            **self._stats,
            "budget_report": self._budget_manager.get_usage_report(),
        }

    # ── 영속성 / Persistence ──

    def _save_scenario(self, scenario: DreamScenario) -> None:
        """SQLite에 시나리오 저장 / Save scenario to SQLite"""
        if not self._conn:
            return
        try:
            self._conn.execute("""
                INSERT OR REPLACE INTO dream_scenarios
                (scenario_id, dream_type, scenario_text, initial_state,
                 actions, expected_outcomes, danger_level, creativity_score,
                 source_concepts, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                scenario.scenario_id, scenario.dream_type.value,
                scenario.scenario_text,
                json.dumps(scenario.initial_state, ensure_ascii=False),
                json.dumps(scenario.actions, ensure_ascii=False),
                json.dumps(scenario.expected_outcomes, ensure_ascii=False),
                scenario.danger_level, scenario.creativity_score,
                json.dumps(scenario.source_concepts), scenario.created_at,
            ))
            self._conn.commit()
        except Exception as e:
            logger.error("시나리오 저장 실패: %s", e)

    def _save_result(self, result: DreamResult) -> None:
        """SQLite에 결과 저장 / Save result to SQLite"""
        if not self._conn:
            return
        try:
            self._conn.execute("""
                INSERT OR REPLACE INTO dream_results
                (result_id, scenario_id, dream_type, outcome,
                 lessons_learned, skills_improved, new_insights,
                 safety_lessons, confidence, duration_seconds,
                 applied_to_lora, applied_to_skills, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result.result_id, result.scenario_id,
                result.dream_type.value, result.outcome.value,
                json.dumps(result.lessons_learned, ensure_ascii=False),
                json.dumps(result.skills_improved),
                json.dumps(result.new_insights, ensure_ascii=False),
                json.dumps(result.safety_lessons, ensure_ascii=False),
                result.confidence, result.duration_seconds,
                int(result.applied_to_lora), int(result.applied_to_skills),
                result.timestamp,
            ))
            self._conn.commit()
        except Exception as e:
            logger.error("드림 결과 저장 실패: %s", e)

    def _save_session(self, session: DreamSession) -> None:
        """SQLite에 세션 저장 / Save session to SQLite"""
        if not self._conn:
            return
        try:
            self._conn.execute("""
                INSERT OR REPLACE INTO dream_sessions
                (session_id, start_time, end_time, total_dreams,
                 completed_dreams, total_lessons, lora_updates,
                 skill_updates, safety_violations)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                session.session_id, session.start_time, session.end_time,
                session.total_dreams, session.completed_dreams,
                session.total_lessons, session.lora_updates,
                session.skill_updates, session.safety_violations,
            ))
            self._conn.commit()
        except Exception as e:
            logger.error("드림 세션 저장 실패: %s", e)

    def close(self) -> None:
        """몽중 시뮬레이터 종료 / Close dream simulator"""
        if self._conn:
            self._conn.close()
            self._conn = None
        logger.info("몽중 시뮬레이터 종료 / Dream Simulator closed")


# ──────────────────────────────────────────────
#  세계 모델 드림 생성기 (World Model Dream Generator)
# ──────────────────────────────────────────────

class WorldModelDreamGenerator:
    """
    Generates rich virtual experiences from a world model.
    세계 모델로부터 풍부한 가상 경험을 생성하는 드림 생성기.

    NeuralWorldModel을 사용하여 전방 궤적을 시뮬레이션하고,
    다양한 테마의 드림을 생성합니다.

    Themes:
        - "challenge": 약한 스킬을 도전하는 시나리오
        - "explore": 미탐색 상태 공간 탐색
        - "consolidate": 기존 지식 강화
        - "innovate": 창의적 스킬 결합

    Usage:
        >>> generator = WorldModelDreamGenerator(world_model, memory_system)
        >>> trajectory = generator.generate_dream_trajectory(n_steps=50, theme="challenge")
        >>> best = generator.select_best_dreams(candidates, k=5)
    """

    VALID_THEMES = {"challenge", "explore", "consolidate", "innovate", "random"}

    def __init__(
        self,
        world_model: Any = None,
        memory_system: Any = None,
    ) -> None:
        """
        WorldModelDreamGenerator 초기화 / Initialize WorldModelDreamGenerator.

        Args:
            world_model: 세계 모델 (NeuralWorldModel) / Neural world model
            memory_system: 기억 시스템 / Memory system for recall
        """
        self._world_model = world_model
        self._memory = memory_system
        self._generated_trajectories: List[List[Dict[str, Any]]] = []
        self._theme_stats: Dict[str, int] = defaultdict(int)
        logger.info("WorldModelDreamGenerator 초기화 / WorldModelDreamGenerator initialized")

    def generate_dream_trajectory(
        self,
        n_steps: int = 50,
        theme: str = "random",
    ) -> List[Dict[str, Any]]:
        """
        세계 모델로 드림 궤적 생성 / Generate dream trajectory using world model.

        NeuralWorldModel을 사용하여 전방 궤적을 시뮬레이션합니다.
        각 드림 스텝: current_state → imagined_action → predicted_next_state

        Args:
            n_steps: 드림 스텝 수 / Number of dream steps
            theme: 드림 테마 / Dream theme
                - "challenge": 약한 스킬 도전
                - "explore": 미탐색 탐색
                - "consolidate": 지식 강화
                - "innovate": 창의적 결합
                - "random": 무작위

        Returns:
            List[Dict]: 드림 궤적, 각 스텝은 {step, current_state, action, predicted_state, theme}
        """
        if theme == "random":
            theme = np.random.choice(list(self.VALID_THEMES - {"random"}))

        self._theme_stats[theme] += 1
        trajectory: List[Dict[str, Any]] = []

        # Initialize current state / 현재 상태 초기화
        current_state = self._get_initial_state(theme)

        for step in range(n_steps):
            # Generate imagined action / 상상된 행동 생성
            action = self._imagine_action(current_state, theme, step, n_steps)

            # Predict next state using world model / 세계 모델로 다음 상태 예측
            predicted_state = self._predict_next_state(current_state, action)

            trajectory.append({
                "step": step,
                "current_state": current_state,
                "action": action,
                "predicted_state": predicted_state,
                "theme": theme,
                "timestamp": time.time(),
            })

            # Advance state / 상태 진행
            current_state = predicted_state

        self._generated_trajectories.append(trajectory)

        logger.info(
            "드림 궤적 생성: %d스텝, 테마='%s' / Dream trajectory generated: %d steps, theme='%s'",
            n_steps, theme, n_steps, theme,
        )

        return trajectory

    def generate_challenge_dreams(
        self,
        weak_skills: List[str],
    ) -> List[Dict[str, Any]]:
        """
        약한 스킬을 도전하는 드림 생성 / Generate dreams that challenge weak skills.

        약한 스킬을 식별하고, 해당 스킬을 향상시키는 시나리오를 생성합니다.
        예: "물체 잡기" 스킬이 약하면 → 다양한 물체 잡기 시나리오 생성

        Args:
            weak_skills: 약한 스킬 ID 목록 / List of weak skill IDs

        Returns:
            List[Dict]: 도전 드림 결과 목록
                각 항목: {skill_id, trajectory_summary, difficulty_level, improvement_potential}
        """
        challenge_dreams: List[Dict[str, Any]] = []

        for skill_id in weak_skills:
            # Generate trajectory focused on this weak skill / 약한 스킬에 집중한 궤적 생성
            trajectory = self.generate_dream_trajectory(
                n_steps=30,
                theme="challenge",
            )

            # Assess difficulty level / 난이도 평가
            difficulty = np.random.uniform(0.5, 1.0)  # Higher for weaker skills

            # Estimate improvement potential / 개선 가능성 추정
            improvement_potential = difficulty * np.random.uniform(0.3, 0.8)

            dream_summary = {
                "skill_id": skill_id,
                "trajectory_summary": {
                    "steps": len(trajectory),
                    "theme": "challenge",
                    "start_state": trajectory[0]["current_state"] if trajectory else {},
                    "end_state": trajectory[-1]["predicted_state"] if trajectory else {},
                },
                "difficulty_level": float(difficulty),
                "improvement_potential": float(improvement_potential),
                "recommended_practice_count": int(difficulty * 10),
                "korean_description": f"'{skill_id}' 스킬 향상을 위한 도전 드림",
            }
            challenge_dreams.append(dream_summary)

        logger.info(
            "도전 드림 생성: %d개 약한 스킬 / Challenge dreams: %d weak skills",
            len(weak_skills), len(weak_skills),
        )

        return challenge_dreams

    def generate_innovation_dreams(
        self,
        knowledge_graph: Any,
    ) -> List[Dict[str, Any]]:
        """
        창의적 결합 드림 생성 / Generate innovation dreams from knowledge graph.

        지식 그래프에서 스킬/개념 쌍을 찾아 창의적으로 결합합니다.
        "스킬 A와 스킬 B를 결합하면 어떨까?"와 같은
        새로운 행동 시퀀스를 제안합니다.

        Args:
            knowledge_graph: 지식 그래프 (노드=스킬/개념, 엣지=관계)
                None이면 기본 개념 쌍을 사용합니다.

        Returns:
            List[Dict]: 혁신 드림 목록
                각 항목: {concept_a, concept_b, combined_sequence, novelty_score, feasibility}
        """
        innovation_dreams: List[Dict[str, Any]] = []

        # Get concept pairs / 개념 쌍 획득
        concept_pairs = self._extract_concept_pairs(knowledge_graph)

        for concept_a, concept_b in concept_pairs:
            # Generate combined action sequence / 결합된 행동 시퀀스 생성
            combined_sequence = self._combine_concepts(concept_a, concept_b)

            # Evaluate novelty / 참신함 평가
            novelty_score = np.random.uniform(0.3, 1.0)

            # Evaluate feasibility / 실현 가능성 평가
            feasibility = np.random.uniform(0.2, 0.9)

            if novelty_score > 0.5 and feasibility > 0.3:
                dream = {
                    "concept_a": concept_a,
                    "concept_b": concept_b,
                    "combined_sequence": combined_sequence,
                    "novelty_score": float(novelty_score),
                    "feasibility": float(feasibility),
                    "description": (
                        f"Innovation: combining '{concept_a}' with '{concept_b}' "
                        f"(novelty={novelty_score:.2f}, feasibility={feasibility:.2f})"
                    ),
                    "korean_description": (
                        f"혁신: '{concept_a}'과(와) '{concept_b}' 결합 "
                        f"(참신도={novelty_score:.2f}, 실현가능성={feasibility:.2f})"
                    ),
                }
                innovation_dreams.append(dream)

        # Sort by combined novelty * feasibility / 참신도*실현가능성순 정렬
        innovation_dreams.sort(
            key=lambda d: d["novelty_score"] * d["feasibility"],
            reverse=True,
        )

        logger.info(
            "혁신 드림 생성: %d개 제안 / Innovation dreams: %d proposals",
            len(innovation_dreams), len(innovation_dreams),
        )

        return innovation_dreams

    def evaluate_dream_quality(self, dream: List[Dict[str, Any]]) -> float:
        """
        드림 품질 평가 / Evaluate dream quality.

        드림의 다양성, 참신성, 학습 잠재력을 측정합니다.

        Args:
            dream: 드림 궤적 (List of step dicts)

        Returns:
            float: 드림 품질 점수 (0~1, 높을수록 좋음)
        """
        if not dream:
            return 0.0

        # 1. Diversity: variance of states / 다양성: 상태 분산
        states = [step.get("current_state", {}) for step in dream]
        state_keys: Set[str] = set()
        for s in states:
            state_keys.update(s.keys())
        diversity = min(1.0, len(state_keys) / 10.0)

        # 2. Novelty: proportion of unique actions / 참신성: 고유 행동 비율
        actions = [step.get("action", {}).get("type", "unknown") for step in dream]
        unique_actions = len(set(actions))
        novelty = min(1.0, unique_actions / max(len(actions), 1))

        # 3. Learning potential: theme relevance and difficulty / 학습 잠재력
        theme = dream[0].get("theme", "explore") if dream else "explore"
        theme_bonus = {
            "challenge": 0.8,
            "innovate": 0.9,
            "explore": 0.6,
            "consolidate": 0.5,
        }.get(theme, 0.5)

        # Weighted combination / 가중 조합
        quality = 0.3 * diversity + 0.3 * novelty + 0.4 * theme_bonus

        return min(1.0, max(0.0, quality))

    def select_best_dreams(
        self,
        candidates: List[List[Dict[str, Any]]],
        k: int = 5,
    ) -> List[List[Dict[str, Any]]]:
        """
        최고의 드림 선택 / Select top-k most valuable dreams for memory consolidation.

        드림 품질 점수를 기준으로 상위 k개의 드림을 선택합니다.
        기억 통합에 가장 가치 있는 드림을 우선적으로 선택합니다.

        Args:
            candidates: 후보 드림 목록 / List of candidate dream trajectories
            k: 선택할 드림 수 / Number of dreams to select

        Returns:
            List[List[Dict]]: 상위 k개 드림 궤적 (품질 점수순)
        """
        # Score all candidates / 모든 후보 평가
        scored = [
            (dream, self.evaluate_dream_quality(dream))
            for dream in candidates
        ]

        # Sort by quality descending / 품질 내림차순 정렬
        scored.sort(key=lambda x: x[1], reverse=True)

        # Select top-k / 상위 k개 선택
        selected = [dream for dream, score in scored[:k]]

        logger.info(
            "최고 드림 선택: %d/%d 후보 중 %d개 선택 / Best dreams: %d/%d candidates, %d selected",
            len(selected), len(candidates), k,
            len(selected), len(candidates), k,
        )

        return selected

    # ── 내부 헬퍼 메서드 / Internal helper methods ──

    def _get_initial_state(self, theme: str) -> Dict[str, Any]:
        """테마에 따른 초기 상태 생성 / Generate initial state based on theme."""
        base_state = {
            "robot_position": [0.0, 0.0, 0.0],
            "environment": "indoor",
            "available_objects": [],
            "energy_level": 1.0,
        }

        theme_modifiers: Dict[str, Dict[str, Any]] = {
            "challenge": {
                "difficulty": np.random.uniform(0.6, 1.0),
                "obstacle_density": np.random.uniform(0.5, 0.9),
                "time_pressure": True,
            },
            "explore": {
                "unexplored_areas": np.random.randint(3, 10),
                "visibility": np.random.uniform(0.3, 0.7),
                "known_objects_ratio": np.random.uniform(0.2, 0.5),
            },
            "consolidate": {
                "recent_experiences": np.random.randint(5, 20),
                "confidence_threshold": 0.7,
                "review_mode": True,
            },
            "innovate": {
                "creative_mode": True,
                "concept_pool_size": np.random.randint(10, 30),
                "combination_attempts": 0,
            },
        }

        base_state.update(theme_modifiers.get(theme, {}))
        return base_state

    def _imagine_action(
        self,
        current_state: Dict[str, Any],
        theme: str,
        step: int,
        total_steps: int,
    ) -> Dict[str, Any]:
        """현재 상태와 테마에 따른 상상된 행동 생성 / Imagine an action based on state and theme."""
        # Action pool by theme / 테마별 행동 풀
        action_pools: Dict[str, List[str]] = {
            "challenge": ["grasp_difficult", "precision_move", "obstacle_avoid", "fast_react"],
            "explore": ["scan_area", "move_to_unknown", "inspect_object", "test_surface"],
            "consolidate": ["review_experience", "compare_actions", "reinforce_pattern", "verify_skill"],
            "innovate": ["combine_skills", "try_novel_sequence", "reimagine_use", "bridge_concepts"],
        }

        pool = action_pools.get(theme, ["observe", "move", "interact"])
        action_type = np.random.choice(pool)

        # Progress factor: actions become more complex later / 진행 요소: 후반일수록 복잡한 행동
        progress = step / max(total_steps, 1)

        return {
            "type": action_type,
            "parameters": {
                "progress": progress,
                "confidence": np.random.uniform(0.3, 1.0),
                "intensity": np.random.uniform(0.5, 1.0) * (1 + progress),
            },
            "step": step,
        }

    def _predict_next_state(
        self,
        current_state: Dict[str, Any],
        action: Dict[str, Any],
    ) -> Dict[str, Any]:
        """세계 모델로 다음 상태 예측 / Predict next state using world model."""
        next_state = dict(current_state)

        if self._world_model and hasattr(self._world_model, "predict"):
            try:
                predicted = self._world_model.predict(
                    state=current_state,
                    action=action,
                )
                if isinstance(predicted, dict):
                    next_state.update(predicted)
                return next_state
            except Exception:
                pass

        # Fallback: rule-based state transition / 폴백: 규칙 기반 상태 전이
        # Slightly modify state based on action / 행동에 따라 상태를 약간 수정
        energy = next_state.get("energy_level", 1.0)
        next_state["energy_level"] = max(0.0, energy - 0.01)

        # Update step-specific features / 스텝별 특징 업데이트
        if "obstacle_density" in next_state:
            next_state["obstacle_density"] = max(
                0.0, next_state["obstacle_density"] - 0.01
            )
        if "unexplored_areas" in next_state:
            next_state["unexplored_areas"] = max(
                0, next_state["unexplored_areas"] - np.random.randint(0, 2)
            )

        next_state["last_action"] = action.get("type", "unknown")
        return next_state

    def _extract_concept_pairs(
        self,
        knowledge_graph: Any,
    ) -> List[Tuple[str, str]]:
        """지식 그래프에서 개념 쌍 추출 / Extract concept pairs from knowledge graph."""
        # Default concept pairs if no knowledge graph / 지식 그래프가 없을 때 기본 개념 쌍
        default_pairs = [
            ("grasping", "pouring"),
            ("pushing", "stacking"),
            ("rotating", "cutting"),
            ("lifting", "balancing"),
            ("squeezing", "inserting"),
            ("scanning", "manipulating"),
            ("navigating", "grasping"),
            ("observing", "predicting"),
        ]

        if knowledge_graph is None:
            return default_pairs

        # Try to extract from knowledge graph / 지식 그래프에서 추출 시도
        try:
            if hasattr(knowledge_graph, "get_skill_pairs"):
                pairs = knowledge_graph.get_skill_pairs()
                if pairs:
                    return pairs
            if hasattr(knowledge_graph, "nodes"):
                nodes = list(knowledge_graph.nodes)[:20]
                pairs = []
                for i in range(min(len(nodes), 10)):
                    for j in range(i + 1, min(len(nodes), 10)):
                        pairs.append((str(nodes[i]), str(nodes[j])))
                if pairs:
                    return pairs[:20]
        except Exception:
            pass

        return default_pairs

    def _combine_concepts(
        self,
        concept_a: str,
        concept_b: str,
    ) -> List[Dict[str, Any]]:
        """두 개념을 결합한 행동 시퀀스 생성 / Generate combined action sequence from two concepts."""
        sequence = [
            {"step": 0, "action": "analyze", "concept": concept_a, "description": f"Analyze '{concept_a}' mechanics"},
            {"step": 1, "action": "analyze", "concept": concept_b, "description": f"Analyze '{concept_b}' mechanics"},
            {"step": 2, "action": "identify_overlap", "concepts": [concept_a, concept_b], "description": f"Find overlap between '{concept_a}' and '{concept_b}'"},
            {"step": 3, "action": "combine", "concepts": [concept_a, concept_b], "description": f"Combine '{concept_a}' with '{concept_b}'"},
            {"step": 4, "action": "simulate", "description": "Simulate combined action sequence"},
            {"step": 5, "action": "evaluate", "description": "Evaluate result of combination"},
        ]
        return sequence


# ──────────────────────────────────────────────
#  드림 통합 엔진 (Dream Consolidation Engine)
# ──────────────────────────────────────────────

class DreamConsolidationEngine:
    """
    Uses dreams for memory consolidation.
    드림을 기억 통합에 활용하는 엔진.

    드림 시뮬레이션을 실행하여 통찰을 추출하고,
    기억 계층에서 경험을 승격시키며,
    스킬 매개변수를 미세 조정합니다.

    Usage:
        >>> engine = DreamConsolidationEngine(dream_generator, memory_system)
        >>> result = engine.consolidate_memories(duration_s=300)
        >>> improvement = engine.refine_skill_from_dream(skill_id, dream_experiences)
    """

    def __init__(
        self,
        dream_generator: WorldModelDreamGenerator,
        memory_system: Any = None,
    ) -> None:
        """
        DreamConsolidationEngine 초기화 / Initialize DreamConsolidationEngine.

        Args:
            dream_generator: 드림 생성기 / World model dream generator
            memory_system: 기억 시스템 / Memory system for consolidation
        """
        self._dream_generator = dream_generator
        self._memory = memory_system
        self._consolidation_history: List[Dict[str, Any]] = []
        self._total_insights = 0
        self._total_promoted = 0
        self._total_skills_refined = 0
        logger.info("DreamConsolidationEngine 초기화 / DreamConsolidationEngine initialized")

    def consolidate_memories(self, duration_s: float = 300) -> Dict[str, int]:
        """
        드림을 통한 기억 통합 / Consolidate memories through dream simulation.

        지정된 시간 동안 드림 시뮬레이션을 실행하고,
        드림에서 통찰을 추출하여 기억 계층에서 경험을 승격합니다.

        Args:
            duration_s: 통합 지속 시간 (초) / Consolidation duration in seconds

        Returns:
            Dict[str, int]: 통합 결과
                - insights_extracted: 추출된 통찰 수
                - memories_promoted: 승격된 기억 수
                - skills_refined: 세분화된 스킬 수
        """
        start_time = time.time()
        insights_extracted = 0
        memories_promoted = 0
        skills_refined = 0

        # Calculate number of dream cycles / 드림 사이클 수 계산
        avg_step_duration = 0.1  # seconds per step
        n_steps = int(duration_s / avg_step_duration)
        n_dreams = max(1, n_steps // 50)

        logger.info(
            "기억 통합 시작: %.0f초, %d개 드림 / Memory consolidation start: %.0fs, %d dreams",
            duration_s, n_dreams, duration_s, n_dreams,
        )

        for dream_idx in range(n_dreams):
            elapsed = time.time() - start_time
            if elapsed >= duration_s:
                break

            # Cycle through themes / 테마 순환
            themes = ["challenge", "explore", "consolidate", "innovate"]
            theme = themes[dream_idx % len(themes)]

            # Generate dream trajectory / 드림 궤적 생성
            trajectory = self._dream_generator.generate_dream_trajectory(
                n_steps=min(50, n_steps // max(n_dreams, 1)),
                theme=theme,
            )

            if not trajectory:
                continue

            # Extract insights from dream / 드림에서 통찰 추출
            dream_insights = self._extract_insights(trajectory)
            insights_extracted += len(dream_insights)

            # Promote memories based on insights / 통찰에 기반한 기억 승격
            promoted = self._promote_memories(dream_insights)
            memories_promoted += promoted

            # Refine skills from dream experiences / 드림 경험으로 스킬 세분화
            for insight in dream_insights:
                skill_id = insight.get("skill_id")
                if skill_id:
                    improvement = self.refine_skill_from_dream(skill_id, trajectory)
                    if improvement > 0.01:
                        skills_refined += 1

        # Record consolidation / 통합 기록
        result = {
            "insights_extracted": insights_extracted,
            "memories_promoted": memories_promoted,
            "skills_refined": skills_refined,
        }

        self._consolidation_history.append({
            "duration_s": duration_s,
            "result": result,
            "timestamp": time.time(),
        })

        self._total_insights += insights_extracted
        self._total_promoted += memories_promoted
        self._total_skills_refined += skills_refined

        logger.info(
            "기억 통합 완료: %d 통찰, %d 승격, %d 스킬 세분화 / "
            "Memory consolidation complete: %d insights, %d promoted, %d skills refined",
            insights_extracted, memories_promoted, skills_refined,
            insights_extracted, memories_promoted, skills_refined,
        )

        return result

    def refine_skill_from_dream(
        self,
        skill_id: str,
        dream_experiences: List[Dict[str, Any]],
    ) -> float:
        """
        드림 경험으로 스킬 매개변수 미세 조정 / Fine-tune skill parameters using dream experiences.

        드림에서 얻은 경험을 사용하여 스킬의 매개변수를 개선합니다.

        Args:
            skill_id: 스킬 ID / Skill identifier
            dream_experiences: 드림 경험 목록 / List of dream experience steps

        Returns:
            float: 개선 점수 (0~1, 0 = 개선 없음, 1 = 큰 개선)
        """
        if not dream_experiences:
            return 0.0

        # Analyze dream experiences for this skill / 이 스킬에 대한 드림 경험 분석
        relevant_steps = [
            step for step in dream_experiences
            if skill_id in str(step.get("action", {})).lower()
            or skill_id in str(step.get("current_state", {})).lower()
        ]

        if not relevant_steps:
            # No direct matches — estimate from overall dream quality / 직접 매치 없음 — 전체 드림 품질로 추정
            quality = self._dream_generator.evaluate_dream_quality(dream_experiences)
            improvement = quality * np.random.uniform(0.01, 0.05)
        else:
            # Calculate improvement based on relevant dream steps / 관련 드림 스텝으로 개선 계산
            success_rate = sum(
                1 for step in relevant_steps
                if step.get("predicted_state", {}).get("energy_level", 1.0) > 0.5
            ) / max(len(relevant_steps), 1)

            # Improvement proportional to practice and success / 연습과 성공에 비례한 개선
            improvement = success_rate * np.random.uniform(0.02, 0.15)

        # Try to apply improvement to skill library / 스킬 라이브러리에 개선 적용 시도
        if self._memory and hasattr(self._memory, "update_skill"):
            try:
                self._memory.update_skill(
                    skill_id=skill_id,
                    improvement_delta=improvement,
                    source="dream_consolidation",
                )
            except Exception:
                pass

        logger.debug(
            "스킬 세분화: '%s' 개선도=%.4f / Skill refined: '%s' improvement=%.4f",
            skill_id, improvement, skill_id, improvement,
        )

        return float(improvement)

    # ── 내부 헬퍼 메서드 / Internal helper methods ──

    def _extract_insights(
        self,
        trajectory: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        드림 궤적에서 통찰 추출 / Extract insights from dream trajectory.

        Args:
            trajectory: 드림 궤적

        Returns:
            List[Dict]: 추출된 통찰 목록
        """
        insights: List[Dict[str, Any]] = []

        if not trajectory:
            return insights

        theme = trajectory[0].get("theme", "explore")

        # Theme-specific insight extraction / 테마별 통찰 추출
        if theme == "challenge":
            # Identify difficult steps / 어려운 스텝 식별
            for step in trajectory:
                action = step.get("action", {})
                if action.get("parameters", {}).get("confidence", 1.0) < 0.5:
                    insights.append({
                        "type": "weakness_identified",
                        "skill_id": action.get("type", "unknown"),
                        "confidence": action.get("parameters", {}).get("confidence", 0.5),
                        "suggestion": f"Practice {action.get('type', 'unknown')} with lower difficulty",
                        "korean_suggestion": f"{action.get('type', '알 수 없음')}을(를) 낮은 난이도로 연습",
                    })

        elif theme == "explore":
            # Identify discoveries / 발견 식별
            for step in trajectory:
                state = step.get("predicted_state", {})
                if state.get("unexplored_areas", 0) < (step.get("current_state", {}).get("unexplored_areas", 0)):
                    insights.append({
                        "type": "discovery",
                        "skill_id": step.get("action", {}).get("type", "unknown"),
                        "area_explored": True,
                        "suggestion": "Remember explored area for future reference",
                        "korean_suggestion": "탐색한 영역을 향후 참조용으로 기억",
                    })

        elif theme == "consolidate":
            # Identify reinforced patterns / 강화된 패턴 식별
            insights.append({
                "type": "pattern_reinforced",
                "skill_id": "general",
                "confidence_boost": 0.1,
                "suggestion": "Existing skills reinforced through replay",
                "korean_suggestion": "재생을 통해 기존 스킬 강화됨",
            })

        elif theme == "innovate":
            # Identify novel combinations / 참신한 결합 식별
            for step in trajectory:
                action = step.get("action", {})
                if action.get("type") == "combine_skills":
                    insights.append({
                        "type": "innovation",
                        "skill_id": "creative_combination",
                        "concepts": action.get("concepts", []),
                        "novelty": np.random.uniform(0.5, 1.0),
                        "suggestion": "Explore this combination in waking state",
                        "korean_suggestion": "깨어 있는 상태에서 이 결합을 탐색",
                    })

        return insights

    def _promote_memories(
        self,
        insights: List[Dict[str, Any]],
    ) -> int:
        """
        통찰에 기반하여 기억 승격 / Promote memories based on insights.

        중요한 통찰에 해당하는 기억을 기억 계층에서
        낮은 수준에서 높은 수준으로 승격합니다.

        Args:
            insights: 추출된 통찰 목록

        Returns:
            int: 승격된 기억 수
        """
        promoted = 0

        if not self._memory:
            return promoted

        for insight in insights:
            # Only promote high-value insights / 높은 가치의 통찰만 승격
            insight_type = insight.get("type", "")
            if insight_type in ("innovation", "discovery"):
                try:
                    if hasattr(self._memory, "promote"):
                        self._memory.promote(
                            content=str(insight),
                            target_layer="semantic",  # Promote to semantic memory
                            source="dream_consolidation",
                        )
                        promoted += 1
                    elif hasattr(self._memory, "store"):
                        self._memory.store(
                            content=str(insight),
                            memory_type="semantic",
                            metadata={"source": "dream_consolidation"},
                        )
                        promoted += 1
                except Exception:
                    pass

        return promoted


# ============================================================================
# DreamerV3-style Imagination Training - Physical AGI 꿈 시스템 혁신
# ============================================================================
# 기존: 룰 기반 랜덤 시뮬레이션 → 혁신: 학습된 월드 모델 내 상상 롤아웃
# 꿈에서 실제로 신경망 가중치를 업데이트하여 오프라인 학습 달성
# ============================================================================

class DreamerV3Imagination:
    """DreamerV3 스타일 상상 학습 엔진
    
    수면 모드에서 월드 모델 내에서 정책을 학습.
    실제 로봇 경험 없이도 스킬 향상 가능.
    
    혁신 포인트:
    1. 월드 모델 내에서 정책 최적화 (Lambda return + actor-critic)
    2. 적대적 꿈 생성 (월드 모델이 불확실한 시나리오 탐색)
    3. 꿈 검증 시스템 (꿈에서 배운 것이 현실과 일치하는지 검증)
    4. 메타 드리밍 (어떤 종류의 꿈이 가장 효과적인지 학습)
    """
    
    def __init__(self, world_model, policy_network, value_network,
                 imagination_horizon=15, discount=0.997, lambda_=0.95,
                 dream_batch_size=32, entropy_scale=0.001,
                 device='cpu'):
        self.world_model = world_model
        self.policy = policy_network
        self.value = value_network
        self.horizon = imagination_horizon
        self.discount = discount
        self.lambda_ = lambda_
        self.dream_batch_size = dream_batch_size
        self.entropy_scale = entropy_scale
        self.device = device
        
        # Dream statistics
        self.dream_count = 0
        self.dream_verification_scores = []
        self.dream_effectiveness = {}
        
        # Meta-dreaming: learn which dream types are most effective
        self.dream_type_performance = {
            'replay': [],
            'exploration': [],
            'fear': [],
            'creative': [],
            'adversarial': [],
        }
        
        # Adversarial dream generator
        self.adversarial_generator = AdversarialDreamGenerator(
            state_dim=62, action_dim=32
        )
        
        # Dream verification
        self.verifier = DreamVerifier(state_dim=62)
        
        # Optimizers
        self.actor_optimizer = None  # Set externally
        self.critic_optimizer = None
    
    def dream_cycle(self, experience_buffer, num_dreams=50):
        """전체 꿈 사이클: 생성 → 시뮬레이션 → 평가 → 학습
        
        Args:
            experience_buffer: 실제 물리적 경험 버퍼
            num_dreams: 이 사이클에서 생성할 꿈 수
        
        Returns:
            dict: 꿈 학습 결과 통계
        """
        stats = {
            'total_dreams': 0,
            'successful_dreams': 0,
            'actor_loss': 0,
            'critic_loss': 0,
            'verification_rate': 0,
            'dream_types': {},
        }
        
        for dream_idx in range(num_dreams):
            # 1. 꿈 유형 선택 (메타 드리밍 기반)
            dream_type = self._select_dream_type()
            
            # 2. 꿈 시나리오 생성
            scenario = self._generate_dream_scenario(
                dream_type, experience_buffer
            )
            
            # 3. 월드 모델 내 상상 롤아웃
            dream_trajectory = self._imagine_rollout(scenario)
            
            # 4. 꿈에서 학습 (actor-critic 업데이트)
            losses = self._learn_from_dream(dream_trajectory)
            
            # 5. 꿈 검증 (현실과의 일치도)
            verification = self.verifier.verify(
                dream_trajectory, experience_buffer
            )
            
            # 6. 메타 드리밍 업데이트
            self._update_dream_effectiveness(dream_type, verification)
            
            # 통계 누적
            stats['total_dreams'] += 1
            if verification['passed']:
                stats['successful_dreams'] += 1
            stats['actor_loss'] += losses.get('actor_loss', 0)
            stats['critic_loss'] += losses.get('critic_loss', 0)
            stats['dream_types'][dream_type] = stats['dream_types'].get(dream_type, 0) + 1
            
            self.dream_count += 1
        
        # 평균 계산
        n = max(stats['total_dreams'], 1)
        stats['actor_loss'] /= n
        stats['critic_loss'] /= n
        stats['verification_rate'] = stats['successful_dreams'] / n
        
        return stats
    
    def _select_dream_type(self):
        """메타 드리밍: 가장 효과적인 꿈 유형 선택 (UCB 기반)"""
        types = list(self.dream_type_performance.keys())
        scores = []
        
        for t in types:
            perfs = self.dream_type_performance[t]
            if len(perfs) == 0:
                scores.append(float('inf'))  # 탐색 보너스
            else:
                mean_perf = np.mean(perfs[-20:])
                exploration_bonus = np.sqrt(2 * np.log(max(self.dream_count, 1)) / max(len(perfs), 1))
                scores.append(mean_perf + 0.5 * exploration_bonus)
        
        return types[np.argmax(scores)]
    
    def _generate_dream_scenario(self, dream_type, experience_buffer):
        """꿈 유형별 시나리오 생성"""
        if dream_type == 'adversarial':
            # 적대적 꿈: 월드 모델이 불확실한 상태 탐색
            return self.adversarial_generator.generate(experience_buffer)
        
        elif dream_type == 'replay':
            # 재생 꿈: 실제 경험을 변형하여 재생
            if len(experience_buffer) > 0:
                idx = np.random.randint(len(experience_buffer))
                base_exp = experience_buffer[idx]
                return {
                    'initial_state': base_exp.get('state', np.zeros(62)),
                    'dream_type': 'replay',
                    'variation_scale': 0.1,
                }
            return {'initial_state': np.zeros(62), 'dream_type': 'replay', 'variation_scale': 0.1}
        
        elif dream_type == 'fear':
            # 공포 꿈: 위험 시나리오 생성 (안전 학습)
            dangerous_states = self._generate_dangerous_states()
            return {
                'initial_state': dangerous_states[np.random.randint(len(dangerous_states))],
                'dream_type': 'fear',
                'safety_training': True,
            }
        
        elif dream_type == 'creative':
            # 창의적 꿈: 잠재 공간 보간으로 새로운 시나리오
            return {
                'initial_state': self._creative_interpolation(experience_buffer),
                'dream_type': 'creative',
            }
        
        else:  # exploration
            # 탐색 꿈: 무작위 상태에서 시작
            return {
                'initial_state': np.random.randn(62) * 0.5,
                'dream_type': 'exploration',
            }
    
    def _imagine_rollout(self, scenario):
        """월드 모델 내에서 상상 롤아웃
        
        DreamerV3 핵심: 월드 모델의 imagine() 메서드를 사용하여
        정책의 행동에 따른 미래를 시뮬레이션.
        """
        initial_state = scenario.get('initial_state', np.zeros(62))
        
        if isinstance(initial_state, np.ndarray):
            state_tensor = torch.FloatTensor(initial_state).unsqueeze(0).to(self.device)
        else:
            state_tensor = initial_state
        
        # Use world model's imagine function if available
        if hasattr(self.world_model, 'imagine'):
            def policy_fn(s):
                with torch.no_grad():
                    action = self.policy(s)
                return action
            
            trajectory = self.world_model.imagine(
                state_tensor, policy_fn, horizon=self.horizon
            )
            trajectory['dream_type'] = scenario.get('dream_type', 'unknown')
            trajectory['safety_training'] = scenario.get('safety_training', False)
            return trajectory
        
        # Fallback: manual rollout
        states = [state_tensor]
        actions = []
        rewards = []
        uncertainties = []
        
        current_state = state_tensor
        for h in range(self.horizon):
            with torch.no_grad():
                action = self.policy(current_state)
            
            # Predict next state using world model
            if hasattr(self.world_model, 'forward'):
                result = self.world_model(current_state, action)
                next_state = result['predicted_state']
                reward = result.get('predicted_reward', torch.zeros(1, 1))
                uncertainty = result.get('epistemic_uncertainty', torch.zeros(1))
            else:
                next_state = current_state + torch.randn_like(current_state) * 0.01
                reward = torch.zeros(1, 1)
                uncertainty = torch.zeros(1)
            
            states.append(next_state)
            actions.append(action)
            rewards.append(reward)
            uncertainties.append(uncertainty)
            current_state = next_state.detach()
        
        return {
            'states': torch.cat(states, dim=0) if len(states) > 1 else states[0],
            'actions': actions,
            'rewards': rewards,
            'uncertainties': uncertainties,
            'dream_type': scenario.get('dream_type', 'unknown'),
            'safety_training': scenario.get('safety_training', False),
        }
    
    def _learn_from_dream(self, trajectory):
        """꿈에서 학습: Lambda return + actor-critic 업데이트
        
        DreamerV3의 핵심 학습 알고리즘:
        1. 가치 함수 타겟: Lambda return 계산
        2. 비평가 손실: 가치 함수를 Lambda return에 맞춤
        3. 행위자 손실: 정책 그래디언트 + 엔트로피 보너스
        """
        if self.actor_optimizer is None or self.critic_optimizer is None:
            return {'actor_loss': 0, 'critic_loss': 0}
        
        rewards = trajectory.get('rewards', [])
        uncertainties = trajectory.get('uncertainties', [])
        states = trajectory.get('states', None)
        
        if not rewards or states is None:
            return {'actor_loss': 0, 'critic_loss': 0}
        
        # Compute Lambda returns
        lambda_returns = self._compute_lambda_returns(rewards, uncertainties)
        
        # Critic update
        self.critic_optimizer.zero_grad()
        value_preds = []
        for s in [states[i] for i in range(len(rewards))]:
            if isinstance(s, torch.Tensor) and s.dim() == 1:
                s = s.unsqueeze(0)
            v = self.value(s)
            value_preds.append(v)
        
        if value_preds:
            value_preds = torch.cat(value_preds)
            critic_loss = F.mse_loss(value_preds.squeeze(), lambda_returns.detach())
            critic_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.value.parameters(), 100.0)
            self.critic_optimizer.step()
        else:
            critic_loss = torch.tensor(0.0)
        
        # Actor update: reinforce with baseline
        self.actor_optimizer.zero_grad()
        advantages = lambda_returns.detach() - value_preds.detach().squeeze()
        
        actor_loss = torch.tensor(0.0, device=self.device)
        for i, s in enumerate([states[j] for j in range(len(rewards))]):
            if isinstance(s, torch.Tensor) and s.dim() == 1:
                s = s.unsqueeze(0)
            action = self.policy(s)
            # Policy gradient with advantage
            log_prob = -F.mse_loss(action, action.detach())  # Placeholder
            actor_loss = actor_loss - advantages[i] * log_prob
        
        if len(rewards) > 0:
            actor_loss = actor_loss / len(rewards)
        
        # Entropy bonus for exploration
        if hasattr(self.policy, 'get_entropy'):
            entropy = self.policy.get_entropy()
            actor_loss = actor_loss - self.entropy_scale * entropy
        
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 100.0)
        self.actor_optimizer.step()
        
        return {
            'actor_loss': actor_loss.item(),
            'critic_loss': critic_loss.item(),
        }
    
    def _compute_lambda_returns(self, rewards, uncertainties):
        """Lambda return 계산 (TD(λ))"""
        returns = []
        G = 0
        
        # Apply uncertainty penalty to rewards
        for i in reversed(range(len(rewards))):
            r = rewards[i]
            if isinstance(r, torch.Tensor):
                r = r.squeeze()
            else:
                r = torch.tensor(r, dtype=torch.float32)
            
            # 불확실성 페널티: 불확실한 꿈의 보상 감소
            if i < len(uncertainties):
                u = uncertainties[i]
                if isinstance(u, torch.Tensor):
                    uncertainty_penalty = 1.0 / (1.0 + u.item())
                else:
                    uncertainty_penalty = 1.0 / (1.0 + u)
                r = r * uncertainty_penalty
            
            G = r + self.discount * self.lambda_ * G
            returns.insert(0, G)
        
        return torch.tensor(returns, dtype=torch.float32)
    
    def _generate_dangerous_states(self):
        """위험 상태 생성 (공포 꿈용)"""
        dangerous = []
        # 높은 속도 상태
        high_speed = np.zeros(62)
        high_speed[:3] = 2.0  # 높은 선형 속도
        dangerous.append(high_speed)
        
        # 불안정한 자세
        unstable = np.zeros(62)
        unstable[3:6] = np.pi / 3  # 극단적인 각도
        dangerous.append(unstable)
        
        # 극단적인 힘
        extreme_force = np.zeros(62)
        extreme_force[6:12] = 50.0  # 높은 힘
        dangerous.append(extreme_force)
        
        return dangerous
    
    def _creative_interpolation(self, experience_buffer):
        """창의적 보간: 두 경험 사이의 잠재 공간 보간"""
        if len(experience_buffer) < 2:
            return np.random.randn(62) * 0.3
        
        idx1, idx2 = np.random.choice(len(experience_buffer), 2, replace=False)
        s1 = experience_buffer[idx1].get('state', np.zeros(62))
        s2 = experience_buffer[idx2].get('state', np.zeros(62))
        
        if isinstance(s1, torch.Tensor):
            s1 = s1.numpy()
        if isinstance(s2, torch.Tensor):
            s2 = s2.numpy()
        
        alpha = np.random.beta(0.5, 0.5)  # Beta 분포 보간
        return alpha * s1 + (1 - alpha) * s2
    
    def _update_dream_effectiveness(self, dream_type, verification):
        """메타 드리밍: 꿈 유형별 효과성 업데이트"""
        effectiveness_score = verification.get('consistency', 0.5)
        self.dream_type_performance[dream_type].append(effectiveness_score)
        
        # 최근 50개만 유지
        if len(self.dream_type_performance[dream_type]) > 50:
            self.dream_type_performance[dream_type] = \
                self.dream_type_performance[dream_type][-50:]


class AdversarialDreamGenerator:
    """적대적 꿈 생성기: 월드 모델이 불확실한 시나리오를 탐색
    
    Physical AGI 혁신: 수동적으로 꿈을 꾸는 것이 아니라,
    적극적으로 "내가 모르는 것이 무엇인지"를 찾아내어
    그 영역에서 가상 경험을 생성.
    """
    
    def __init__(self, state_dim=62, action_dim=32):
        self.state_dim = state_dim
        self.action_dim = action_dim
    
    def generate(self, experience_buffer):
        """적대적 꿈 시나리오 생성"""
        # 경험 버퍼에서 변동성이 높은 영역 탐색
        if len(experience_buffer) > 10:
            # 가장 예측 오차가 높은 경험 선택
            max_error_idx = 0
            max_error = 0
            for i, exp in enumerate(experience_buffer):
                error = exp.get('prediction_error', 0)
                if error > max_error:
                    max_error = error
                    max_error_idx = i
            
            base = experience_buffer[max_error_idx]
            state = base.get('state', np.zeros(self.state_dim))
            if isinstance(state, torch.Tensor):
                state = state.numpy()
            
            # 높은 예측 오차 영역 주변에서 탐색
            perturbation = np.random.randn(self.state_dim) * 0.3
            return {
                'initial_state': state + perturbation,
                'dream_type': 'adversarial',
                'target_uncertainty': max_error,
            }
        
        return {
            'initial_state': np.random.randn(self.state_dim) * 0.5,
            'dream_type': 'adversarial',
            'target_uncertainty': 1.0,
        }


class DreamVerifier:
    """꿈 검증 시스템: 꿈에서 배운 것이 현실과 일치하는지 검증
    
    꿈의 품질이 낮으면 (월드 모델이 부정확하면)
    꿈에서 배운 것이 오히려 해로울 수 있음.
    이 검증 시스템은 꿈의 현실 일치도를 평가하여
    신뢰할 수 있는 꿈만 학습에 반영.
    """
    
    def __init__(self, state_dim=62, consistency_threshold=0.7):
        self.state_dim = state_dim
        self.consistency_threshold = consistency_threshold
        self.verification_history = []
    
    def verify(self, dream_trajectory, real_experience_buffer):
        """꿈 검증: 현실 경험과의 일치도 평가"""
        
        # 1. 물리적 일관성 검사
        physics_consistency = self._check_physics_consistency(dream_trajectory)
        
        # 2. 경험 일치도 검사
        experience_consistency = self._check_experience_consistency(
            dream_trajectory, real_experience_buffer
        )
        
        # 3. 안전성 검사 (안전 훈련 꿈은 제외)
        safety_consistency = 1.0
        if dream_trajectory.get('safety_training', False):
            safety_consistency = 0.8  # 공포 꿈은 약간 낮은 일관성 허용
        
        # 종합 일치도
        overall_consistency = (
            0.4 * physics_consistency +
            0.4 * experience_consistency +
            0.2 * safety_consistency
        )
        
        verification = {
            'consistency': overall_consistency,
            'physics': physics_consistency,
            'experience': experience_consistency,
            'safety': safety_consistency,
            'passed': overall_consistency >= self.consistency_threshold,
        }
        
        self.verification_history.append(verification)
        return verification
    
    def _check_physics_consistency(self, trajectory):
        """물리 법칙 일관성 검사"""
        states = trajectory.get('states', None)
        if states is None:
            return 0.5
        
        if isinstance(states, torch.Tensor):
            states_np = states.detach().cpu().numpy()
        elif isinstance(states, list):
            states_np = np.array([s.detach().cpu().numpy() if isinstance(s, torch.Tensor) else s for s in states])
        else:
            return 0.5
        
        if states_np.ndim < 2 or len(states_np) < 2:
            return 0.5
        
        # 상태 변화의 물리적 타당성 검사
        # 1. 상태 변화가 너무 급격하지 않은지 (관성 위반)
        deltas = np.diff(states_np, axis=0)
        max_delta = np.max(np.abs(deltas))
        inertial_score = 1.0 / (1.0 + max_delta)  # 작을수록 좋음
        
        # 2. 에너지 보존 근사 검사
        if states_np.shape[1] >= 6:
            velocities = states_np[:, :3]
            kinetic_energy = np.sum(velocities ** 2, axis=1)
            energy_variation = np.std(kinetic_energy) / (np.mean(kinetic_energy) + 1e-8)
            energy_score = 1.0 / (1.0 + energy_variation)
        else:
            energy_score = 0.5
        
        return 0.6 * inertial_score + 0.4 * energy_score
    
    def _check_experience_consistency(self, trajectory, real_buffer):
        """실제 경험과의 일치도 검사"""
        if len(real_buffer) == 0:
            return 0.5  # 경험 없으면 중립
        
        # 간단한 일치도: 꿈의 상태가 실제 경험 상태와 얼마나 가까운지
        dream_states = trajectory.get('states', None)
        if dream_states is None:
            return 0.5
        
        if isinstance(dream_states, torch.Tensor):
            dream_states = dream_states.detach().cpu().numpy()
        
        # 샘플 실제 경험과 비교
        sample_size = min(10, len(real_buffer))
        sample_indices = np.random.choice(len(real_buffer), sample_size, replace=False)
        
        min_distances = []
        for idx in sample_indices:
            real_state = real_buffer[idx].get('state', None)
            if real_state is None:
                continue
            if isinstance(real_state, torch.Tensor):
                real_state = real_state.detach().cpu().numpy()
            
            if dream_states.ndim >= 2:
                dists = np.linalg.norm(dream_states - real_state, axis=-1)
                min_distances.append(np.min(dists))
            else:
                min_distances.append(np.linalg.norm(dream_states - real_state))
        
        if not min_distances:
            return 0.5
        
        avg_distance = np.mean(min_distances)
        consistency = 1.0 / (1.0 + avg_distance)
        
        return float(consistency)
