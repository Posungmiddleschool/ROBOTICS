#!/usr/bin/env python3
"""
agi_metrics_v2.py - 9-Dimensional AGI Evaluation System
9차원 AGI 평가 시스템

Tracks mastery across 9 dimensions, estimates overall AGI level
using harmonic mean (weak dimensions drag down score),
detects emergent capabilities, and generates progress reports.
9개 차원의 숙련도를 추적하고 조화 평균으로 전체 AGI 수준을 추정하며
(약한 차원이 점수를 끌어내림), 창발적 능력을 감지하고 진행 보고서를 생성.
"""

import json
import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Dict, Tuple

import numpy as np
from scipy import stats as scipy_stats

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# ─── Constants / 상수 ────────────────────────────────────────────────
DB_PATH = "agi_metrics.db"
SNAPSHOT_INTERVAL_SEC = 3600   # hourly snapshots / 시간당 스냅샷
MIN_TASKS_FOR_MASTERY = 5      # minimum tasks for reliable mastery / 신뢰할 숙련도 최소 작업 수
EMERGENCE_THRESHOLD = 0.15     # min improvement for emergence / 창발 감지 최소 향상도
PLATEAU_WINDOW = 10            # window for plateau detection / 정체 감지 윈도우
BREAKTHROUGH_THRESHOLD = 0.1   # min jump for breakthrough / 돌파구 최소 점프


# ─── AGIDimension / AGI 차원 ─────────────────────────────────────────
class AGIDimension(Enum):
    """
    9차원 AGI 평가 차원 / 9-dimensional AGI evaluation dimensions.
    """
    LOCOMOTION = "locomotion"       # 이동 능력 / Movement ability
    MANIPULATION = "manipulation"   # 조작 능력 / Object manipulation
    PERCEPTION = "perception"       # 지각 능력 / Sensory perception
    REASONING = "reasoning"         # 추론 능력 / Logical reasoning
    LEARNING = "learning"           # 학습 능력 / Learning ability
    MEMORY = "memory"               # 기억 능력 / Memory systems
    SAFETY = "safety"               # 안전 능력 / Safety awareness
    ADAPTATION = "adaptation"       # 적응 능력 / Environmental adaptation
    CREATIVITY = "creativity"       # 창의성 / Creative problem-solving

    @classmethod
    def all(cls) -> List["AGIDimension"]:
        return list(cls)

    @classmethod
    def names(cls) -> List[str]:
        return [d.value for d in cls]


# ─── AGI Level Categories / AGI 수준 카테고리 ───────────────────────
@dataclass
class AGILevel:
    """AGI 수준 카테고리 / AGI level category."""
    name: str
    min_score: float
    max_score: float
    description: str
    description_ko: str


AGI_LEVELS = [
    AGILevel("Narrow AI", 0.0, 0.2,
             "Specialized single-task capability",
             "특화된 단일 작업 수행 능력"),
    AGILevel("Emerging", 0.2, 0.4,
             "Early multi-task capability with significant gaps",
             "초기 다중 작업 능력, 중대한 간격 존재"),
    AGILevel("Competent", 0.4, 0.6,
             "Reliable performance across most dimensions",
             "대부분 차원에서 신뢰할 수 있는 성능"),
    AGILevel("Advanced", 0.6, 0.8,
             "Strong capability with minor weaknesses",
             "사소한 약점을 가진 강력한 능력"),
    AGILevel("Physical AGI", 0.8, 1.0,
             "Human-equivalent or superhuman across all dimensions",
             "모든 차원에서 인간 동등 또는 초인적 능력"),
]


# ─── Data Classes / 데이터 클래스 ─────────────────────────────────────
@dataclass
class TaskResult:
    """단일 작업 결과 / A single task execution result."""
    dimension: AGIDimension
    task_name: str
    success: bool
    score: float            # 0.0 - 1.0 normalized / 정규화된 점수
    difficulty: float        # 0.0 - 1.0 / 난이도
    timestamp: float = field(default_factory=time.time)


@dataclass
class AGISnapshot:
    """특정 시점의 AGI 메트릭 스냅샷 / AGI metrics snapshot at a point in time."""
    metrics: Dict[str, float]    # dimension → mastery value
    overall_level: float
    category: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class EmergentCapability:
    """감지된 창발적 능력 / Detected emergent capability."""
    name: str
    combining_dimensions: List[str]
    improvement: float
    description: str
    timestamp: float = field(default_factory=time.time)


# ─── SkillMasteryTracker / 스킬 숙련도 추적기 ────────────────────────
class SkillMasteryTracker:
    """
    각 차원별 숙련도를 베이지안 업데이트로 추적
    Tracks mastery per dimension using Bayesian updating with Beta distribution prior.
    Beta(α, β) 사전 분포: α=성공 횟수+1, β=실패 횟수+1 / Beta(α, β) prior: α=successes+1, β=failures+1
    숙련도 = 기대값 α/(α+β) / Mastery = expected value α/(α+β)
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._lock = threading.Lock()
        # 각 차원의 Beta 분포 파라미터 / Beta distribution parameters per dimension
        self._alpha: Dict[str, float] = {}
        self._beta: Dict[str, float] = {}
        # 초기화: 약한 사전 (α=1, β=1 → 균등 분포) / Weak prior (uniform distribution)
        for dim in AGIDimension.all():
            self._alpha[dim.value] = 1.0
            self._beta[dim.value] = 1.0
        self._task_history: Dict[str, List[TaskResult]] = {d.value: [] for d in AGIDimension.all()}
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._ensure_db()
        self._load_state()
        logger.info("SkillMasteryTracker 초기화 / Initialized")

    def _ensure_db(self):
        """데이터베이스 스키마 보장 / Ensure database schema."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS mastery_state (
                dimension TEXT PRIMARY KEY,
                alpha REAL NOT NULL,
                beta REAL NOT NULL,
                updated_at REAL NOT NULL
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS task_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dimension TEXT NOT NULL,
                task_name TEXT NOT NULL,
                success INTEGER NOT NULL,
                score REAL NOT NULL,
                difficulty REAL NOT NULL,
                timestamp REAL NOT NULL
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_dim ON task_results(dimension)")
        self._conn.commit()

    def _load_state(self):
        """저장된 상태 로드 / Load persisted state."""
        rows = self._conn.execute("SELECT dimension, alpha, beta FROM mastery_state").fetchall()
        for dim, a, b in rows:
            if dim in self._alpha:
                self._alpha[dim] = a
                self._beta[dim] = b
                logger.debug(f"상태 로드: {dim} α={a:.2f} β={b:.2f} / State loaded")

    def _save_state(self):
        """상태 저장 / Persist state."""
        for dim in AGIDimension.all():
            self._conn.execute(
                "INSERT OR REPLACE INTO mastery_state (dimension, alpha, beta, updated_at) "
                "VALUES (?, ?, ?, ?)",
                (dim.value, self._alpha[dim.value], self._beta[dim.value], time.time())
            )
        self._conn.commit()

    def update_mastery(self, task_result: TaskResult):
        """
        작업 결과로 숙련도 베이지안 업데이트 / Bayesian update mastery with task result.
        성공 시 α 증가, 실패 시 β 증가 (난이도 가중) / Success → increase α, failure → increase β (difficulty-weighted).
        """
        dim = task_result.dimension.value

        with self._lock:
            # 난이도 가중치: 어려운 작업의 성공이 더 큰 영향 / Difficulty weight: harder task success matters more
            weight = 0.5 + 0.5 * task_result.difficulty

            if task_result.success:
                self._alpha[dim] += weight * task_result.score
            else:
                self._beta[dim] += weight * (1.0 - task_result.score)

            self._task_history[dim].append(task_result)

            # 데이터베이스에 작업 결과 저장 / Save task result to DB
            self._conn.execute(
                "INSERT INTO task_results (dimension, task_name, success, score, difficulty, timestamp) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (dim, task_result.task_name, int(task_result.success),
                 task_result.score, task_result.difficulty, task_result.timestamp)
            )
            self._conn.commit()

            self._save_state()

        mastery = self.get_mastery(task_result.dimension)
        logger.debug(f"숙련도 업데이트: {dim} → {mastery:.3f} / Mastery updated")

    def get_mastery(self, dimension: AGIDimension) -> float:
        """
        차원의 숙련도 반환 (0-1) / Return mastery for dimension (0-1).
        베이지안 기대값: α / (α + β) / Bayesian expected value: α / (α + β)
        """
        dim = dimension.value
        a = self._alpha.get(dim, 1.0)
        b = self._beta.get(dim, 1.0)
        return a / (a + b)

    def get_confidence(self, dimension: AGIDimension) -> float:
        """
        숙련도 추정의 신뢰도 반환 / Return confidence in mastery estimate.
        신뢰도 = 관측 수에 기반 (관측이 많을수록 높음) / Based on observation count.
        """
        dim = dimension.value
        a = self._alpha.get(dim, 1.0)
        b = self._beta.get(dim, 1.0)
        n = a + b - 2  # 초기 사전 제외 / Exclude initial prior
        # 신뢰도: 관측 수의 로그 스케일 / Confidence in log scale of observations
        return min(1.0, np.log1p(n) / np.log1p(MIN_TASKS_FOR_MASTERY * 10))

    def get_all_mastery(self) -> Dict[str, float]:
        """모든 차원의 숙련도 반환 / Return mastery for all dimensions."""
        return {dim.value: self.get_mastery(dim) for dim in AGIDimension.all()}

    def get_task_count(self, dimension: AGIDimension) -> int:
        """차원의 작업 수 반환 / Return task count for dimension."""
        dim = dimension.value
        return len(self._task_history.get(dim, []))


# ─── AGIMetricsCollector / AGI 메트릭 수집기 ──────────────────────────
class AGIMetricsCollector:
    """
    모든 하위 시스템으로부터 메트릭을 수집 / Collects metrics from all subsystems.
    connect_subsystem로 하위 시스템을 등록하고 collect_all_metrics로 통합 수집.
    Register subsystems via connect_subsystem, collect via collect_all_metrics.
    """

    def __init__(self, mastery_tracker: Optional[SkillMasteryTracker] = None):
        self.mastery_tracker = mastery_tracker or SkillMasteryTracker()
        self._subsystems: Dict[str, object] = {}
        self._metric_extractors: Dict[str, callable] = {}
        self._lock = threading.Lock()
        logger.info("AGIMetricsCollector 초기화 / Initialized")

    def connect_subsystem(self, name: str, subsystem: object,
                          metric_extractor: Optional[callable] = None):
        """
        하위 시스템 연결 / Connect a subsystem for metric collection.
        metric_extractor: subsystem → Dict[AGIDimension, float] 변환 함수
        metric_extractor: function to convert subsystem → Dict[AGIDimension, float]
        """
        with self._lock:
            self._subsystems[name] = subsystem
            if metric_extractor is not None:
                self._metric_extractors[name] = metric_extractor
        logger.info(f"하위 시스템 연결: {name} / Subsystem connected: {name}")

    def disconnect_subsystem(self, name: str):
        """하위 시스템 연결 해제 / Disconnect a subsystem."""
        with self._lock:
            self._subsystems.pop(name, None)
            self._metric_extractors.pop(name, None)
        logger.info(f"하위 시스템 해제: {name} / Subsystem disconnected")

    def collect_all_metrics(self) -> Dict[AGIDimension, float]:
        """
        모든 하위 시스템에서 메트릭 수집 / Collect metrics from all subsystems.
        각 차원의 메트릭을 가중 평균으로 통합 / Aggregate via weighted average.
        """
        # 기본: 마스터리 트래커 값 / Default: mastery tracker values
        metrics = {dim: self.mastery_tracker.get_mastery(dim) for dim in AGIDimension.all()}

        # 하위 시스템 메트릭 수집 / Collect from subsystems
        subsystem_contributions: Dict[AGIDimension, List[float]] = {
            dim: [] for dim in AGIDimension.all()
        }

        with self._lock:
            for name, extractor in self._metric_extractors.items():
                try:
                    sub_metrics = extractor(self._subsystems[name])
                    if isinstance(sub_metrics, dict):
                        for key, value in sub_metrics.items():
                            if isinstance(key, AGIDimension) and 0 <= value <= 1:
                                subsystem_contributions[key].append(value)
                            elif isinstance(key, str):
                                try:
                                    dim = AGIDimension(key)
                                    if 0 <= value <= 1:
                                        subsystem_contributions[dim].append(value)
                                except ValueError:
                                    pass
                except Exception as e:
                    logger.warning(f"하위 시스템 {name} 메트릭 수집 실패: {e} / "
                                    f"Failed to collect from {name}")

        # 마스터리 트래커와 하위 시스템 가중 평균 / Weighted average with subsystem contributions
        for dim in AGIDimension.all():
            contributions = subsystem_contributions[dim]
            if contributions:
                base = metrics[dim]
                sub_avg = np.mean(contributions)
                # 하위 시스템 가중치 0.3 / Subsystem weight 0.3
                metrics[dim] = 0.7 * base + 0.3 * sub_avg

        return metrics

    def get_connected_subsystems(self) -> List[str]:
        """연결된 하위 시스템 목록 반환 / Return list of connected subsystems."""
        return list(self._subsystems.keys())


# ─── AGILevelEstimator / AGI 수준 추정기 ─────────────────────────────
class AGILevelEstimator:
    """
    전체 AGI 수준 추정 / Estimates overall AGI level.
    조화 평균 사용: 약한 차원이 점수를 끌어내림
    Uses harmonic mean: a weak dimension drags down the score.
    level = harmonic_mean(all_9_dimensions)
    """

    def __init__(self):
        self._last_estimate: Optional[float] = None
        logger.info("AGILevelEstimator 초기화 / Initialized")

    @staticmethod
    def harmonic_mean(values: List[float]) -> float:
        """
        조화 평균 계산 / Compute harmonic mean.
        H = n / Σ(1/x_i), 약한 차원이 점수를 크게 끌어내림
        H = n / Σ(1/x_i), weak dimensions significantly drag down score.
        """
        if not values or len(values) == 0:
            return 0.0
        # 0 방지: 최소값 0.01 보장 / Avoid zero: ensure minimum 0.01
        safe_values = [max(0.01, v) for v in values]
        n = len(safe_values)
        return n / sum(1.0 / v for v in safe_values)

    def estimate_level(self, metrics: Dict[AGIDimension, float]) -> float:
        """
        9차원 메트릭으로 전체 AGI 수준 추정 / Estimate overall AGI level from 9D metrics.
        조화 평균 사용 / Uses harmonic mean.
        """
        values = [metrics.get(dim, 0.01) for dim in AGIDimension.all()]
        level = self.harmonic_mean(values)
        self._last_estimate = level
        return level

    @staticmethod
    def categorize_level(level: float) -> AGILevel:
        """
        수준을 카테고리로 분류 / Categorize level into AGI level.
        0-0.2=Narrow AI, 0.2-0.4=Emerging, 0.4-0.6=Competent,
        0.6-0.8=Advanced, 0.8-1.0=Physical AGI
        """
        for agi_level in AGI_LEVELS:
            if agi_level.min_score <= level < agi_level.max_score:
                return agi_level
        # 정확히 1.0인 경우 / Edge case: exactly 1.0
        return AGI_LEVELS[-1]

    def get_weakest_dimension(self, metrics: Dict[AGIDimension, float]) -> Tuple[AGIDimension, float]:
        """가장 약한 차원 반환 / Return the weakest dimension."""
        weakest_dim = min(metrics, key=metrics.get)
        return weakest_dim, metrics[weakest_dim]

    def get_strongest_dimension(self, metrics: Dict[AGIDimension, float]) -> Tuple[AGIDimension, float]:
        """가장 강한 차원 반환 / Return the strongest dimension."""
        strongest_dim = max(metrics, key=metrics.get)
        return strongest_dim, metrics[strongest_dim]


# ─── AGIProgressTracker / AGI 진행 추적기 ─────────────────────────────
class AGIProgressTracker:
    """
    시간에 따른 AGI 진행 추적 / Tracks AGI progress over time.
    record_snapshot: 스냅샷 기록 / Record snapshot
    get_progress_report: 추세, 정체, 돌파구 보고 / Report trends, plateaus, breakthroughs
    detect_emergent_capabilities: 차원 조합에서의 창발 감지 / Detect emergence from dimension combinations
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._snapshots: List[AGISnapshot] = []
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._ensure_db()
        self._load_snapshots()
        logger.info("AGIProgressTracker 초기화 / Initialized")

    def _ensure_db(self):
        """데이터베이스 스키마 보장 / Ensure database schema."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS agi_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metrics_json TEXT NOT NULL,
                overall_level REAL NOT NULL,
                category TEXT NOT NULL,
                timestamp REAL NOT NULL
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_snap_time ON agi_snapshots(timestamp)")
        self._conn.commit()

    def _load_snapshots(self):
        """저장된 스냅샷 로드 / Load persisted snapshots."""
        rows = self._conn.execute(
            "SELECT metrics_json, overall_level, category, timestamp FROM agi_snapshots "
            "ORDER BY timestamp ASC"
        ).fetchall()
        for row in rows:
            metrics_dict = json.loads(row[0])
            metrics = {AGIDimension(k): v for k, v in metrics_dict.items()}
            self._snapshots.append(AGISnapshot(
                metrics={k.value: v for k, v in metrics.items()},
                overall_level=row[1], category=row[2], timestamp=row[3]
            ))

    def record_snapshot(self, metrics: Dict[AGIDimension, float]):
        """
        현재 메트릭의 스냅샷 기록 / Record a snapshot of current metrics.
        """
        level_estimator = AGILevelEstimator()
        overall = level_estimator.estimate_level(metrics)
        category = level_estimator.categorize_level(overall).name

        metrics_dict = {dim.value: val for dim, val in metrics.items()}
        snapshot = AGISnapshot(
            metrics=metrics_dict, overall_level=overall,
            category=category, timestamp=time.time()
        )

        with self._lock:
            self._snapshots.append(snapshot)

        # 데이터베이스에 저장 / Save to DB
        self._conn.execute(
            "INSERT INTO agi_snapshots (metrics_json, overall_level, category, timestamp) "
            "VALUES (?, ?, ?, ?)",
            (json.dumps(metrics_dict), overall, category, snapshot.timestamp)
        )
        self._conn.commit()

        logger.info(f"스냅샷 기록: level={overall:.3f}, category={category} / Snapshot recorded")

    def get_progress_report(self) -> Dict:
        """
        진행 보고서 생성 / Generate progress report with trends, plateaus, breakthroughs.
        """
        if len(self._snapshots) < 2:
            return {"status": "insufficient_data", "message": "데이터 부족 / Insufficient data"}

        report = {
            "total_snapshots": len(self._snapshots),
            "time_span_hours": 0.0,
            "current_level": self._snapshots[-1].overall_level,
            "initial_level": self._snapshots[0].overall_level,
            "overall_improvement": 0.0,
            "trends": {},
            "plateaus": [],
            "breakthroughs": [],
            "dimension_trends": {},
        }

        # 시간 범위 / Time span
        report["time_span_hours"] = (
            self._snapshots[-1].timestamp - self._snapshots[0].timestamp
        ) / 3600.0

        # 전체 향상도 / Overall improvement
        report["overall_improvement"] = (
            self._snapshots[-1].overall_level - self._snapshots[0].overall_level
        )

        # 차원별 추세 / Per-dimension trends
        for dim in AGIDimension.names():
            values = [s.metrics.get(dim, 0.0) for s in self._snapshots]
            if len(values) >= 3:
                # 선형 회귀로 추세 추정 / Estimate trend via linear regression
                x = np.arange(len(values))
                slope, intercept, r_value, _, _ = scipy_stats.linregress(x, values)
                report["dimension_trends"][dim] = {
                    "current": values[-1],
                    "slope": float(slope),
                    "r_squared": float(r_value ** 2),
                    "direction": "improving" if slope > 0.001 else (
                        "declining" if slope < -0.001 else "stable"
                    ),
                }

        # 정체 감지 / Plateau detection
        report["plateaus"] = self._detect_plateaus()

        # 돌파구 감지 / Breakthrough detection
        report["breakthroughs"] = self._detect_breakthroughs()

        return report

    def _detect_plateaus(self) -> List[Dict]:
        """
        정체 구간 감지 / Detect plateau periods.
        연속 PLATEAU_WINDOW 기간 동안 향상이 거의 없으면 정체로 판단.
        Plateau if almost no improvement over PLATEAU_WINDOW consecutive snapshots.
        """
        plateaus = []
        if len(self._snapshots) < PLATEAU_WINDOW:
            return plateaus

        levels = [s.overall_level for s in self._snapshots]

        for i in range(len(levels) - PLATEAU_WINDOW + 1):
            window = levels[i:i + PLATEAU_WINDOW]
            variation = max(window) - min(window)
            if variation < 0.02:  # 2% 미만 변화면 정체 / Less than 2% change = plateau
                plateaus.append({
                    "start_idx": i,
                    "end_idx": i + PLATEAU_WINDOW - 1,
                    "start_time": self._snapshots[i].timestamp,
                    "end_time": self._snapshots[i + PLATEAU_WINDOW - 1].timestamp,
                    "level": float(np.mean(window)),
                    "variation": float(variation),
                })

        return plateaus

    def _detect_breakthroughs(self) -> List[Dict]:
        """
        돌파구 감지 / Detect breakthrough moments.
        연속 스냅샷 간 향상이 BREAKTHROUGH_THRESHOLD 이상이면 돌파구.
        Breakthrough if improvement between consecutive snapshots exceeds threshold.
        """
        breakthroughs = []
        if len(self._snapshots) < 2:
            return breakthroughs

        levels = [s.overall_level for s in self._snapshots]

        for i in range(1, len(levels)):
            jump = levels[i] - levels[i - 1]
            if jump >= BREAKTHROUGH_THRESHOLD:
                breakthroughs.append({
                    "snapshot_idx": i,
                    "timestamp": self._snapshots[i].timestamp,
                    "previous_level": levels[i - 1],
                    "new_level": levels[i],
                    "jump": float(jump),
                })

        return breakthroughs

    def detect_emergent_capabilities(self) -> List[EmergentCapability]:
        """
        차원 조합에서의 창발적 능력 감지 / Detect emergent capabilities from dimension combinations.
        두 차원이 모두 일정 수준 이상일 때 새로운 능력이 창발할 수 있음.
        New capabilities may emerge when two dimensions are both above threshold.
        """
        if len(self._snapshots) < 2:
            return []

        current = self._snapshots[-1]
        previous = self._snapshots[-2] if len(self._snapshots) >= 2 else None

        emergent = []
        # 차원 쌍의 창발 규칙 / Emergence rules for dimension pairs
        emergence_rules = [
            (AGIDimension.PERCEPTION.value, AGIDimension.MANIPULATION.value,
             "Precise Object Handling", "지각과 조작의 융합으로 정밀한 객체 조작",
             "Fusion of perception and manipulation enables precise object handling"),
            (AGIDimension.LEARNING.value, AGIDimension.MEMORY.value,
             "Experience-Based Reasoning", "학습과 기억의 융합으로 경험 기반 추론",
             "Fusion of learning and memory enables experience-based reasoning"),
            (AGIDimension.REASONING.value, AGIDimension.CREATIVITY.value,
             "Novel Problem Solving", "추론과 창의성의 융합으로 새로운 문제 해결",
             "Fusion of reasoning and creativity enables novel problem solving"),
            (AGIDimension.LOCOMOTION.value, AGIDimension.ADAPTATION.value,
             "Terrain Mastery", "이동과 적응의 융합으로 지형 숙달",
             "Fusion of locomotion and adaptation enables terrain mastery"),
            (AGIDimension.SAFETY.value, AGIDimension.LEARNING.value,
             "Safe Exploration", "안전과 학습의 융합으로 안전한 탐색",
             "Fusion of safety and learning enables safe exploration"),
            (AGIDimension.PERCEPTION.value, AGIDimension.REASONING.value,
             "Physical Understanding", "지각과 추론의 융합으로 물리적 이해",
             "Fusion of perception and reasoning enables physical understanding"),
            (AGIDimension.MANIPULATION.value, AGIDimension.CREATIVITY.value,
             "Tool Innovation", "조작과 창의성의 융합으로 도구 혁신",
             "Fusion of manipulation and creativity enables tool innovation"),
        ]

        for dim1_name, dim2_name, cap_name, desc_ko, desc_en in emergence_rules:
            val1 = current.metrics.get(dim1_name, 0.0)
            val2 = current.metrics.get(dim2_name, 0.0)
            # 두 차원 모두 0.5 이상이면 창발 가능 / Both dimensions above 0.5 → emergence possible
            combined = (val1 + val2) / 2.0

            if previous is not None:
                prev1 = previous.metrics.get(dim1_name, 0.0)
                prev2 = previous.metrics.get(dim2_name, 0.0)
                prev_combined = (prev1 + prev2) / 2.0
            else:
                prev_combined = 0.0

            improvement = combined - prev_combined

            if combined >= 0.5 and improvement >= EMERGENCE_THRESHOLD:
                emergent.append(EmergentCapability(
                    name=cap_name,
                    combining_dimensions=[dim1_name, dim2_name],
                    improvement=improvement,
                    description=f"{desc_ko} / {desc_en}",
                    timestamp=time.time(),
                ))

        if emergent:
            logger.info(f"창발적 능력 {len(emergent)}개 감지 / "
                         f"{len(emergent)} emergent capabilities detected")
        return emergent


# ─── AGIMetricsDashboard / AGI 메트릭 대시보드 ────────────────────────
class AGIMetricsDashboard:
    """
    AGI 상태 보고서 생성 / Generates AGI status reports.
    format_report: 텍스트 보고서 / Text report
    get_radar_chart_data: 레이더 차트 데이터 / Radar chart data for visualization
    """

    def __init__(self, collector: Optional[AGIMetricsCollector] = None,
                 level_estimator: Optional[AGILevelEstimator] = None,
                 progress_tracker: Optional[AGIProgressTracker] = None):
        self.collector = collector or AGIMetricsCollector()
        self.level_estimator = level_estimator or AGILevelEstimator()
        self.progress_tracker = progress_tracker or AGIProgressTracker()
        logger.info("AGIMetricsDashboard 초기화 / Initialized")

    def format_report(self, metrics: Optional[Dict[AGIDimension, float]] = None) -> str:
        """
        서식 있는 텍스트 보고서 생성 / Generate formatted text report.
        """
        if metrics is None:
            metrics = self.collector.collect_all_metrics()

        overall = self.level_estimator.estimate_level(metrics)
        category = self.level_estimator.categorize_level(overall)
        weakest_dim, weakest_val = self.level_estimator.get_weakest_dimension(metrics)
        strongest_dim, strongest_val = self.level_estimator.get_strongest_dimension(metrics)

        lines = [
            "=" * 60,
            "  AGI METRICS REPORT / AGI 메트릭 보고서",
            "=" * 60,
            f"  Overall Level / 전체 수준:  {overall:.3f}",
            f"  Category / 카테고리:      {category.name}",
            f"                           {category.description_ko}",
            f"  Strongest / 최강 차원:    {strongest_dim.value} ({strongest_val:.3f})",
            f"  Weakest / 최약 차원:      {weakest_dim.value} ({weakest_val:.3f})",
            "-" * 60,
            "  Dimension Breakdown / 차원별 상세",
            "-" * 60,
        ]

        for dim in AGIDimension.all():
            val = metrics.get(dim, 0.0)
            bar_len = int(val * 30)
            bar = "█" * bar_len + "░" * (30 - bar_len)
            confidence = self.collector.mastery_tracker.get_confidence(dim)
            lines.append(f"  {dim.value:14s} |{bar}| {val:.3f} (conf:{confidence:.2f})")

        # 창발적 능력 / Emergent capabilities
        emergent = self.progress_tracker.detect_emergent_capabilities()
        if emergent:
            lines.append("-" * 60)
            lines.append("  Emergent Capabilities / 창발적 능력")
            lines.append("-" * 60)
            for ec in emergent:
                lines.append(f"  ★ {ec.name}: +{ec.improvement:.3f}")
                lines.append(f"    [{', '.join(ec.combining_dimensions)}]")

        lines.append("=" * 60)
        return "\n".join(lines)

    def get_radar_chart_data(self, metrics: Optional[Dict[AGIDimension, float]] = None) -> Dict:
        """
        레이더 차트 시각화 데이터 생성 / Generate radar chart data for visualization.
        ECharts, matplotlib, Plotly 등에서 사용 가능 / Compatible with ECharts, matplotlib, Plotly.
        """
        if metrics is None:
            metrics = self.collector.collect_all_metrics()

        overall = self.level_estimator.estimate_level(metrics)
        category = self.level_estimator.categorize_level(overall)

        return {
            "dimensions": [dim.value for dim in AGIDimension.all()],
            "values": [metrics.get(dim, 0.0) for dim in AGIDimension.all()],
            "overall_level": overall,
            "category": category.name,
            "confidence": [
                self.collector.mastery_tracker.get_confidence(dim)
                for dim in AGIDimension.all()
            ],
            # ECharts 레이더 차트용 인디케이터 / ECharts radar chart indicators
            "indicator": [
                {"name": dim.value, "max": 1.0}
                for dim in AGIDimension.all()
            ],
            # 시계열 데이터 (최근 스냅샷) / Time series data (recent snapshots)
            "time_series": [
                {"timestamp": s.timestamp, "level": s.overall_level, "category": s.category}
                for s in self.progress_tracker._snapshots[-20:]
            ],
        }

    def get_dimension_comparison(self, metrics: Dict[AGIDimension, float]) -> Dict:
        """
        차원 간 비교 분석 / Dimension comparison analysis.
        균형 점수: 차원 간 분산이 낮을수록 균형 잡힌 발전 / Lower variance = more balanced development.
        """
        values = [metrics.get(dim, 0.0) for dim in AGIDimension.all()]
        balance_score = 1.0 - np.std(values)  # 표준편차가 낮을수록 균형 / Lower std = more balanced

        return {
            "mean": float(np.mean(values)),
            "std": float(np.std(values)),
            "min": float(np.min(values)),
            "max": float(np.max(values)),
            "range": float(np.max(values) - np.min(values)),
            "balance_score": float(np.clip(balance_score, 0, 1)),
            "percentile_25": float(np.percentile(values, 25)),
            "percentile_75": float(np.percentile(values, 75)),
        }


# ─── Module-level demo / 모듈 레벨 데모 ──────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    # 마스터리 트래커 데모 / Mastery tracker demo
    tracker = SkillMasteryTracker(db_path=":memory:")

    for dim in AGIDimension.all():
        for _ in range(10):
            result = TaskResult(
                dimension=dim,
                task_name=f"task_{dim.value}",
                success=np.random.rand() > 0.3,
                score=np.random.uniform(0.3, 1.0),
                difficulty=np.random.uniform(0.2, 0.9),
            )
            tracker.update_mastery(result)

    # 메트릭 수집기 / Metrics collector
    collector = AGIMetricsCollector(tracker)
    metrics = collector.collect_all_metrics()

    # 수준 추정기 / Level estimator
    estimator = AGILevelEstimator()
    level = estimator.estimate_level(metrics)
    category = estimator.categorize_level(level)
    logger.info(f"AGI 수준: {level:.3f} ({category.name}) / AGI Level")

    # 진행 추적기 / Progress tracker
    progress = AGIProgressTracker(db_path=":memory:")
    for i in range(5):
        # 점진적 향상 시뮬레이션 / Simulate gradual improvement
        improved = {dim: min(1.0, metrics[dim] + 0.03 * i) for dim in metrics}
        progress.record_snapshot(improved)

    report = progress.get_progress_report()
    logger.info(f"진행 보고서: improvement={report.get('overall_improvement', 0):.3f}")

    # 창발 감지 / Emergence detection
    emergent = progress.detect_emergent_capabilities()
    for ec in emergent:
        logger.info(f"창발: {ec.name} (+{ec.improvement:.3f}) / Emergent: {ec.name}")

    # 대시보드 / Dashboard
    dashboard = AGIMetricsDashboard(collector, estimator, progress)
    print(dashboard.format_report(metrics))

    radar = dashboard.get_radar_chart_data(metrics)
    logger.info(f"레이더 차트 데이터: {len(radar['dimensions'])} 차원 / "
                 f"Radar chart: {len(radar['dimensions'])} dimensions")

    logger.info("agi_metrics_v2.py 데모 완료 / Demo complete")


# ============================================================================
# IRT AGI Metrics + Unified Metrics System — Physical AGI 평가 혁신
# ============================================================================
# 기존: 단순 베타 분포 마스터리 추적 → 한계: 태스크 난이도 미고려
# 혁신 1: IRT (Item Response Theory) — 태스크 난이도와 능력 분리 측정
# 혁신 2: 통합 AGI 메트릭 — v1과 v2를 하나로 통합
# 혁신 3: 물리적 튜링 테스트 — 로봇 행동을 인간과 구별 가능한가?
# ============================================================================

class IRTMetricsEngine:
    """IRT (Item Response Theory) 기반 AGI 메트릭
    
    3PL (Three-Parameter Logistic) 모델:
    P(θ) = c + (1-c) / (1 + exp(-1.7 * a * (θ - b)))
    
    θ: 로봇 능력 (ability)
    a: 태스크 변별도 (discrimination)
    b: 태스크 난이도 (difficulty)
    c: 추측 확률 (guessing)
    
    혁신: "쉬운 태스크를 100번 성공" ≠ "어려운 태스크를 1번 성공"
    IRT는 태스크 난이도를 고려하여 능력을 정확히 측정.
    """
    
    def __init__(self, num_dimensions=9, initial_ability=0.0):
        self.num_dimensions = num_dimensions
        self.abilities = np.full(num_dimensions, initial_ability)
        
        # 태스크 파라미터 (학습됨)
        self.task_params = {}  # task_id → {a, b, c}
        
        # 관측 기록
        self.observations = []  # [(task_id, dimension, success, timestamp)]
    
    def register_task(self, task_id, dimension, difficulty=0.0,
                      discrimination=1.0, guessing=0.1):
        """태스크 등록"""
        self.task_params[task_id] = {
            'a': discrimination,
            'b': difficulty,
            'c': guessing,
            'dimension': dimension,
        }
    
    def record_observation(self, task_id, success, timestamp=None):
        """관측 기록 및 능력 추정 업데이트"""
        if task_id not in self.task_params:
            return
        
        timestamp = timestamp or time.time()
        self.observations.append((task_id, self.task_params[task_id]['dimension'], success, timestamp))
        
        # 능력 추정 업데이트 (MML - Marginal Maximum Likelihood)
        self._update_ability_estimate(self.task_params[task_id]['dimension'])
    
    def _update_ability_estimate(self, dimension):
        """능력 추정 업데이트 (Newton-Raphson)"""
        dim_obs = [(o[0], o[2]) for o in self.observations 
                    if o[1] == dimension and o[0] in self.task_params]
        
        if not dim_obs:
            return
        
        theta = self.abilities[dimension]
        
        for _ in range(10):  # Newton-Raphson 반복
            first_deriv = 0
            second_deriv = 0
            
            for task_id, success in dim_obs:
                params = self.task_params[task_id]
                p = self._irt_probability(theta, params['a'], params['b'], params['c'])
                p = np.clip(p, 1e-8, 1 - 1e-8)
                
                W = params['a'] * (p - params['c']) * (1 - p) / (p * (1 - params['c']))
                first_deriv += W * (success - p) / p
                
                d2p = -1.7 * params['a'] * p * (1 - p) * (1 - 2 * p * (1 - params['c']))
                second_deriv += W * (p - success) / (p ** 2) * (1 - p)
            
            if abs(second_deriv) > 1e-8:
                theta = theta - first_deriv / second_deriv
                theta = np.clip(theta, -5, 5)
        
        self.abilities[dimension] = theta
    
    def _irt_probability(self, theta, a, b, c):
        """3PL IRT 확률"""
        return c + (1 - c) / (1 + np.exp(-1.7 * a * (theta - b)))
    
    def get_ability(self, dimension):
        """특정 차원의 능력 추정치"""
        return self.abilities[dimension]
    
    def get_abilities(self):
        """모든 차원의 능력 추정치"""
        return dict(enumerate(self.abilities))
    
    def predict_success_probability(self, task_id):
        """태스크 성공 확률 예측"""
        if task_id not in self.task_params:
            return 0.5
        
        params = self.task_params[task_id]
        dim = params['dimension']
        return self._irt_probability(
            self.abilities[dim], params['a'], params['b'], params['c']
        )
    
    def get_composite_score(self):
        """통합 AGI 점수 (조화 평균)"""
        # IRT 능력을 0~1로 정규화
        normalized = 1 / (1 + np.exp(-self.abilities))
        return float(len(normalized) / np.sum(1.0 / (normalized + 1e-8)))


class PhysicalTuringTest:
    """물리적 튜링 테스트 — 로봇의 행동을 인간과 구별 가능한가?
    
    5가지 카테고리:
    1. 이동 자연스러움 (locomotion naturalness)
    2. 파지 유연성 (grasp flexibility)
    3. 환경 적응성 (environmental adaptability)
    4. 도구 사용 숙련도 (tool use proficiency)
    5. 예외 상황 대처 (exception handling)
    """
    
    def __init__(self):
        self.test_results = {}
        self.human_baselines = {
            'locomotion_naturalness': 0.85,
            'grasp_flexibility': 0.90,
            'environmental_adaptability': 0.80,
            'tool_use_proficiency': 0.75,
            'exception_handling': 0.85,
        }
    
    def evaluate_category(self, category, robot_score):
        """카테고리별 평가"""
        human_baseline = self.human_baselines.get(category, 0.5)
        turing_ratio = robot_score / max(human_baseline, 0.01)
        
        self.test_results[category] = {
            'robot_score': robot_score,
            'human_baseline': human_baseline,
            'turing_ratio': turing_ratio,
            'pass': turing_ratio >= 0.8,  # 80% 이상이면 통과
        }
        
        return self.test_results[category]
    
    def overall_turing_score(self):
        """전체 튜링 점수"""
        if not self.test_results:
            return 0.0
        
        ratios = [r['turing_ratio'] for r in self.test_results.values()]
        return float(np.mean(ratios))
    
    def is_agi_level(self, threshold=0.8):
        """AGI 수준 도달 여부"""
        return self.overall_turing_score() >= threshold
