#!/usr/bin/env python3
"""
recovery_policy.py - Emergency Recovery Policy Network
긴급 복구 정책 네트워크

Detects faults, generates recovery action sequences, and evaluates recovery success.
Escalates to human operator after repeated failures.
결함을 감지하고, 복구 행동 시퀀스를 생성하며, 복구 성공 여부를 평가.
반복 실패 후 인간 운영자에게 에스컬레이션.
"""

import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple, Dict

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.utils.data import Dataset, DataLoader
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    nn = object
    Dataset = object

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# ─── Constants / 상수 ────────────────────────────────────────────────
DB_PATH = "recovery_experience.db"
STATE_DIM = 62                 # current state dimension / 현재 상태 차원
FAULT_DIM = 8                  # fault type one-hot dimension / 결함 유형 원핫 차원
ACTION_DIM = 32                # recovery action dimension / 복구 행동 차원
HIDDEN_DIM = 256
MID_DIM = 128
MAX_RECOVERY_ATTEMPTS = 3      # max attempts before escalation / 에스컬레이션 전 최대 시도
RECOVERY_TIMEOUT_SEC = 30.0    # recovery timeout / 복구 타임아웃
BC_LEARNING_RATE = 1e-3        # behavioral cloning LR / 행동 복제 학습률
RL_LEARNING_RATE = 1e-4        # RL fine-tuning LR / RL 미세조정 학습률
SUCCESS_REWARD = 1.0           # sparse reward for successful recovery / 성공적 복구 희소 보상
FAILURE_REWARD = -1.0          # penalty for failed recovery / 실패 시 페널티
GAMMA = 0.99                   # discount factor / 할인 인자


# ─── Fault Types / 결함 유형 ─────────────────────────────────────────
class FaultType(Enum):
    """
    8가지 결함 유형 (원핫 인코딩) / 8 fault types (one-hot encoded).
    """
    FALL = 0            # 넘어짐 / Fall
    COLLISION = 1       # 충돌 / Collision
    STUCK = 2           # 걸림 / Stuck
    TIPPED = 3          # 기울어짐 / Tipped
    JOINT_LIMIT = 4     # 관절 한계 / Joint limit reached
    LOW_BATTERY = 5     # 배터리 부족 / Low battery
    SENSOR_FAILURE = 6  # 센서 고장 / Sensor failure
    OVERHEATING = 7     # 과열 / Overheating

    @classmethod
    def to_onehot(cls, fault_type: "FaultType") -> np.ndarray:
        """결함 유형을 원핫 벡터로 변환 / Convert fault type to one-hot vector."""
        vec = np.zeros(FAULT_DIM, dtype=np.float32)
        vec[fault_type.value] = 1.0
        return vec

    @classmethod
    def from_onehot(cls, onehot: np.ndarray) -> "FaultType":
        """원핫 벡터에서 결함 유형 복원 / Recover fault type from one-hot vector."""
        idx = int(np.argmax(onehot))
        return cls(idx)


# ─── Data Classes / 데이터 클래스 ─────────────────────────────────────
@dataclass
class RecoveryExperience:
    """단일 복구 경험 / A single recovery experience."""
    fault_state: np.ndarray      # state at fault onset (62-dim) / 결함 발생 시 상태
    fault_type: FaultType        # detected fault type / 감지된 결함 유형
    recovery_action: np.ndarray  # executed recovery action (32-dim) / 실행된 복구 행동
    success: bool                # whether recovery succeeded / 복구 성공 여부
    time_to_recover: float       # seconds to recover / 복구 소요 시간(초)
    timestamp: float = field(default_factory=time.time)


@dataclass
class RecoveryAttempt:
    """진행 중인 복구 시도 / An ongoing recovery attempt."""
    fault_type: FaultType
    start_time: float
    attempt_number: int
    action_sequence: Optional[np.ndarray] = None
    safety_score: float = 0.0


# ─── RecoveryPolicyNet / 복구 정책 네트워크 ──────────────────────────
if HAS_TORCH:
    class RecoveryPolicyNet(nn.Module):
        """
        긴급 복구 정책 네트워크 / Emergency recovery policy network.
        Input: current_state(62-dim) + fault_type(8-dim one-hot)
        Architecture: FC(70→256→256→128) + ReLU + BN
        Output: recovery_action(32-dim) + safety_head(1-dim sigmoid)
        """

        def __init__(self, state_dim: int = STATE_DIM, fault_dim: int = FAULT_DIM,
                     action_dim: int = ACTION_DIM, hidden_dim: int = HIDDEN_DIM,
                     mid_dim: int = MID_DIM):
            super().__init__()
            input_dim = state_dim + fault_dim

            # 공유 백본 / Shared backbone
            self.backbone = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.BatchNorm1d(hidden_dim),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.BatchNorm1d(hidden_dim),
                nn.Linear(hidden_dim, mid_dim),
                nn.ReLU(),
                nn.BatchNorm1d(mid_dim),
            )

            # 복구 행동 헤드 / Recovery action head
            self.action_head = nn.Sequential(
                nn.Linear(mid_dim, mid_dim),
                nn.ReLU(),
                nn.Linear(mid_dim, action_dim),
                nn.Tanh()  # 행동을 [-1, 1]로 제한 / Clip actions to [-1, 1]
            )

            # 안전성 평가 헤드 / Safety estimation head
            self.safety_head = nn.Sequential(
                nn.Linear(mid_dim, 64),
                nn.ReLU(),
                nn.Linear(64, 1),
                nn.Sigmoid()  # 0~1 안전성 확률 / Safety probability 0-1
            )

            self._init_weights()
            logger.info(f"RecoveryPolicyNet 초기화: input={input_dim}, output={action_dim}+1 / "
                         f"Initialized")

        def _init_weights(self):
            """가중치 직교 초기화 / Orthogonal weight initialization."""
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    nn.init.orthogonal_(module.weight, gain=np.sqrt(2))
                    nn.init.zeros_(module.bias)

        def forward(self, state: "torch.Tensor",
                    fault_type: "torch.Tensor") -> Tuple["torch.Tensor", "torch.Tensor"]:
            """
            순전파 / Forward pass.
            Args:
                state: (batch, 62) — 현재 상태 / current state
                fault_type: (batch, 8) — 결함 유형 원핫 / fault type one-hot
            Returns:
                action: (batch, 32) — 복구 행동 파라미터 / recovery action parameters
                safety: (batch, 1) — 안전성 추정 / estimated safety
            """
            x = torch.cat([state, fault_type], dim=-1)
            features = self.backbone(x)
            action = self.action_head(features)
            safety = self.safety_head(features)
            return action, safety


# ─── RecoveryExperienceDataset / 복구 경험 데이터셋 ───────────────────
if HAS_TORCH:
    class RecoveryExperienceDataset(Dataset):
        """복구 경험을 위한 PyTorch Dataset / PyTorch Dataset for recovery experiences."""

        def __init__(self, experiences: List[RecoveryExperience]):
            self.experiences = experiences

        def __len__(self) -> int:
            return len(self.experiences)

        def __getitem__(self, idx: int):
            exp = self.experiences[idx]
            fault_onehot = FaultType.to_onehot(exp.fault_type)
            return (
                torch.FloatTensor(exp.fault_state),
                torch.FloatTensor(fault_onehot),
                torch.FloatTensor(exp.recovery_action),
                torch.FloatTensor([1.0 if exp.success else 0.0]),
                torch.FloatTensor([exp.time_to_recover])
            )


# ─── RecoveryExperienceBuffer / 복구 경험 버퍼 ───────────────────────
class RecoveryExperienceBuffer:
    """
    복구 경험을 SQLite에 저장하는 버퍼 / Buffer that stores recovery experiences in SQLite.
    (fault_state, recovery_action, success, time_to_recover)
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._ensure_schema()

    def _ensure_schema(self):
        """데이터베이스 스키마 보장 / Ensure database schema."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS recovery_experiences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fault_state BLOB NOT NULL,
                fault_type INTEGER NOT NULL,
                recovery_action BLOB NOT NULL,
                success INTEGER NOT NULL,
                time_to_recover REAL NOT NULL,
                timestamp REAL NOT NULL
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_success ON recovery_experiences(success)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_fault ON recovery_experiences(fault_type)")
        self._conn.commit()
        logger.info("RecoveryExperienceBuffer 스키마 초기화 / Schema initialized")

    def add(self, experience: RecoveryExperience) -> int:
        """복구 경험 추가 / Add a recovery experience."""
        state_blob = experience.fault_state.astype(np.float32).tobytes()
        action_blob = experience.recovery_action.astype(np.float32).tobytes()
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO recovery_experiences "
                "(fault_state, fault_type, recovery_action, success, time_to_recover, timestamp) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (state_blob, experience.fault_type.value, action_blob,
                 int(experience.success), experience.time_to_recover, experience.timestamp)
            )
            row_id = cursor.lastrowid
            self._conn.commit()
        return row_id

    def get_successful(self) -> List[RecoveryExperience]:
        """성공적인 복구 경험만 로드 / Load only successful recovery experiences."""
        rows = self._conn.execute(
            "SELECT fault_state, fault_type, recovery_action, success, "
            "time_to_recover, timestamp FROM recovery_experiences WHERE success=1"
        ).fetchall()
        return self._rows_to_experiences(rows)

    def get_all(self) -> List[RecoveryExperience]:
        """모든 복구 경험 로드 / Load all recovery experiences."""
        rows = self._conn.execute(
            "SELECT fault_state, fault_type, recovery_action, success, "
            "time_to_recover, timestamp FROM recovery_experiences"
        ).fetchall()
        return self._rows_to_experiences(rows)

    def get_by_fault_type(self, fault_type: FaultType) -> List[RecoveryExperience]:
        """특정 결함 유형의 경험 로드 / Load experiences for a specific fault type."""
        rows = self._conn.execute(
            "SELECT fault_state, fault_type, recovery_action, success, "
            "time_to_recover, timestamp FROM recovery_experiences WHERE fault_type=?",
            (fault_type.value,)
        ).fetchall()
        return self._rows_to_experiences(rows)

    def _rows_to_experiences(self, rows) -> List[RecoveryExperience]:
        """데이터베이스 행을 RecoveryExperience로 변환 / Convert DB rows to RecoveryExperience."""
        experiences = []
        for row in rows:
            state = np.frombuffer(row[0], dtype=np.float32).copy()
            fault_type = FaultType(row[1])
            action = np.frombuffer(row[2], dtype=np.float32).copy()
            experiences.append(RecoveryExperience(
                fault_state=state, fault_type=fault_type, recovery_action=action,
                success=bool(row[3]), time_to_recover=row[4], timestamp=row[5]
            ))
        return experiences

    def count(self) -> int:
        """저장된 경험 수 반환 / Return count of stored experiences."""
        count = self._conn.execute("SELECT COUNT(*) FROM recovery_experiences").fetchone()[0]
        return count


# ─── RecoveryTrainer / 복구 트레이너 ─────────────────────────────────
class RecoveryTrainer:
    """
    복구 정책 훈련기: 행동 복제 + RL 미세조정
    Trains recovery policy via behavioral cloning from successful recoveries,
    then RL fine-tuning with sparse reward (1.0 for successful recovery).
    성공적 복구로부터 행동 복제, 이후 희소 보상 RL 미세조정.
    """

    def __init__(self, buffer: Optional[RecoveryExperienceBuffer] = None):
        self.buffer = buffer or RecoveryExperienceBuffer()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu") if HAS_TORCH else None
        self.model: Optional[RecoveryPolicyNet] = None
        self._bc_losses: List[float] = []
        self._rl_rewards: List[float] = []

        if HAS_TORCH:
            self.model = RecoveryPolicyNet().to(self.device)
        else:
            logger.warning("PyTorch 미설치 — RecoveryTrainer 제한 모드 / Limited mode")

    def behavioral_cloning(self, epochs: int = 50, batch_size: int = 32) -> List[float]:
        """
        성공적 복구 경험으로 행동 복제 훈련 / Behavioral cloning from successful recoveries.
        성공한 경험만 사용하여 정책 모방 / Imitate policy using only successful experiences.
        """
        if not HAS_TORCH or self.model is None:
            return []

        successes = self.buffer.get_successful()
        if len(successes) < 2:
            logger.warning("성공적 복구 경험 부족 / Insufficient successful recovery data")
            return []

        dataset = RecoveryExperienceDataset(successes)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True)
        optimizer = torch.optim.Adam(self.model.parameters(), lr=BC_LEARNING_RATE)

        self.model.train()
        epoch_losses = []

        for epoch in range(epochs):
            epoch_loss = 0.0
            count = 0
            for state, fault_oh, action, success, ttr in dataloader:
                state = state.to(self.device)
                fault_oh = fault_oh.to(self.device)
                action = action.to(self.device)

                pred_action, safety = self.model(state, fault_oh)

                # 행동 복제 손실 / Behavioral cloning loss
                action_loss = F.mse_loss(pred_action, action)

                # 안전성 정규화 손실 (성공 시 safety → 1) / Safety regularization
                safety_target = torch.ones_like(safety) * 0.9  # 성공 경험이므로 높은 안전성 / high safety
                safety_loss = F.binary_cross_entropy(safety, safety_target)

                loss = action_loss + 0.1 * safety_loss

                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                optimizer.step()

                epoch_loss += loss.item()
                count += 1

            avg = epoch_loss / max(1, count)
            epoch_losses.append(avg)
            self._bc_losses.append(avg)
            if (epoch + 1) % 10 == 0:
                logger.info(f"[행동복제/BC] epoch {epoch+1}/{epochs} loss={avg:.4f}")

        logger.info(f"행동 복제 완료: {len(successes)} 성공 경험 / BC complete")
        return epoch_losses

    def rl_finetune(self, num_episodes: int = 100,
                    buffer: Optional[RecoveryExperienceBuffer] = None) -> List[float]:
        """
        희소 보상 RL 미세조정 / RL fine-tuning with sparse reward.
        보상: 성공=+1.0, 실패=-1.0 / Reward: success=+1.0, failure=-1.0
        REINFORCE 알고리즘 사용 / Uses REINFORCE algorithm.
        """
        if not HAS_TORCH or self.model is None:
            return []

        src_buffer = buffer or self.buffer
        all_experiences = src_buffer.get_all()
        if len(all_experiences) < 2:
            return []

        optimizer = torch.optim.Adam(self.model.parameters(), lr=RL_LEARNING_RATE)
        self.model.train()
        episode_rewards = []

        for ep in range(num_episodes):
            # 무작위 경험 샘플링 / Sample random experience
            exp = all_experiences[np.random.randint(len(all_experiences))]

            state = torch.FloatTensor(exp.fault_state).unsqueeze(0).to(self.device)
            fault_oh = torch.FloatTensor(FaultType.to_onehot(exp.fault_type)).unsqueeze(0).to(self.device)

            pred_action, safety = self.model(state, fault_oh)

            # 보상 계산 / Compute reward
            reward = SUCCESS_REWARD if exp.success else FAILURE_REWARD
            # 안전성 기반 보너스 / Safety-based bonus
            safety_bonus = float(safety.item()) * 0.1 if exp.success else -0.1 * float(safety.item())
            total_reward = reward + safety_bonus

            # REINFORCE 손실 / REINFORCE loss
            # 정책 그래디언트: -log_prob * reward (간소화된 버전)
            action_std = 0.1
            log_prob = -0.5 * ((pred_action - torch.FloatTensor(
                exp.recovery_action).unsqueeze(0).to(self.device)) ** 2).sum() / (action_std ** 2)
            loss = -log_prob * total_reward

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            optimizer.step()

            episode_rewards.append(total_reward)
            self._rl_rewards.append(total_reward)

            if (ep + 1) % 20 == 0:
                avg_r = np.mean(episode_rewards[-20:])
                logger.info(f"[RL 미세조정] episode {ep+1}/{num_episodes} "
                             f"avg_reward={avg_r:.3f}")

        logger.info("RL 미세조정 완료 / RL fine-tuning complete")
        return episode_rewards

    def predict(self, state: np.ndarray,
                fault_type: FaultType) -> Tuple[np.ndarray, float]:
        """
        복구 행동 및 안전성 예측 / Predict recovery action and safety score.
        """
        if not HAS_TORCH or self.model is None:
            return np.zeros(ACTION_DIM, dtype=np.float32), 0.5

        self.model.eval()
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            fault_oh = torch.FloatTensor(FaultType.to_onehot(fault_type)).unsqueeze(0).to(self.device)
            action, safety = self.model(state_t, fault_oh)
        return action.cpu().numpy().squeeze(0), float(safety.item())


# ─── EmergencyRecoverySystem / 긴급 복구 시스템 ───────────────────────
class EmergencyRecoverySystem:
    """
    고수준 복구 오케스트레이션 / High-level recovery orchestration.
    detect_fault(sensor_data) → fault_type
    attempt_recovery(fault_type, current_state) → action_sequence
    evaluate_recovery(state_after) → bool
    escalate_to_human() after 3 tries or 30 seconds
    """

    def __init__(self, trainer: Optional[RecoveryTrainer] = None):
        self.trainer = trainer or RecoveryTrainer()
        self.buffer = self.trainer.buffer
        self._current_attempt: Optional[RecoveryAttempt] = None
        self._attempt_history: List[RecoveryAttempt] = []
        self._lock = threading.Lock()
        self._escalated = False
        self._fault_thresholds = {
            FaultType.FALL: {"acc_z": -5.0, "gyro_norm": 3.0},
            FaultType.COLLISION: {"force_norm": 50.0, "acc_norm": 8.0},
            FaultType.STUCK: {"vel_norm": 0.01, "duration": 5.0},
            FaultType.TIPPED: {"tilt_angle": 45.0, "gyro_norm": 2.0},
            FaultType.JOINT_LIMIT: {"joint_pos_limit": 0.98},
            FaultType.LOW_BATTERY: {"voltage": 18.0},
            FaultType.SENSOR_FAILURE: {"variance": 0.001},
            FaultType.OVERHEATING: {"temperature": 70.0},
        }
        logger.info("EmergencyRecoverySystem 초기화 / Initialized")

    def detect_fault(self, sensor_data: Dict[str, np.ndarray]) -> Optional[FaultType]:
        """
        센서 데이터에서 결함 유형 감지 / Detect fault type from sensor data.
        우선순위: 과열 > 센서 고장 > 저배터리 > 넘어짐 > 충돌 > 기울어짐 > 걸림 > 관절 한계
        Priority: overheating > sensor_failure > low_battery > fall > collision > tipped > stuck > joint_limit
        """
        # 과열 감지 / Overheating detection
        if "temperature" in sensor_data:
            if np.max(sensor_data["temperature"]) > self._fault_thresholds[FaultType.OVERHEATING]["temperature"]:
                logger.warning("과열 감지! / Overheating detected!")
                return FaultType.OVERHEATING

        # 센서 고장 감지 / Sensor failure detection
        if "sensor_variance" in sensor_data:
            if np.min(sensor_data["sensor_variance"]) < self._fault_thresholds[FaultType.SENSOR_FAILURE]["variance"]:
                logger.warning("센서 고장 감지! / Sensor failure detected!")
                return FaultType.SENSOR_FAILURE

        # 저배터리 감지 / Low battery detection
        if "battery_voltage" in sensor_data:
            if np.mean(sensor_data["battery_voltage"]) < self._fault_thresholds[FaultType.LOW_BATTERY]["voltage"]:
                logger.warning("저배터리 감지! / Low battery detected!")
                return FaultType.LOW_BATTERY

        # 넘어짐 감지 / Fall detection
        if "acceleration" in sensor_data:
            acc_z = sensor_data["acceleration"][2] if sensor_data["acceleration"].shape[0] > 2 else 0.0
            if acc_z < self._fault_thresholds[FaultType.FALL]["acc_z"]:
                logger.warning("넘어짐 감지! / Fall detected!")
                return FaultType.FALL

        # 충돌 감지 / Collision detection
        if "contact_force" in sensor_data:
            force_norm = np.linalg.norm(sensor_data["contact_force"])
            if force_norm > self._fault_thresholds[FaultType.COLLISION]["force_norm"]:
                logger.warning("충돌 감지! / Collision detected!")
                return FaultType.COLLISION

        # 기울어짐 감지 / Tipped detection
        if "imu_tilt" in sensor_data:
            tilt = np.abs(sensor_data["imu_tilt"][0])
            if tilt > self._fault_thresholds[FaultType.TIPPED]["tilt_angle"]:
                logger.warning("기울어짐 감지! / Tipped detected!")
                return FaultType.TIPPED

        # 걸림 감지 / Stuck detection
        if "velocity" in sensor_data:
            vel_norm = np.linalg.norm(sensor_data["velocity"])
            if vel_norm < self._fault_thresholds[FaultType.STUCK]["vel_norm"]:
                logger.warning("걸림 감지! / Stuck detected!")
                return FaultType.STUCK

        # 관절 한계 감지 / Joint limit detection
        if "joint_positions" in sensor_data:
            if np.any(np.abs(sensor_data["joint_positions"]) > self._fault_thresholds[FaultType.JOINT_LIMIT]["joint_pos_limit"]):
                logger.warning("관절 한계 감지! / Joint limit detected!")
                return FaultType.JOINT_LIMIT

        return None

    def attempt_recovery(self, fault_type: FaultType,
                         current_state: np.ndarray) -> Optional[np.ndarray]:
        """
        복구 시도: 결함 유형과 현재 상태로 복구 행동 생성
        Attempt recovery: generate recovery action from fault type and current state.
        3회 초과 시도 또는 30초 타임아웃 시 에스컬레이션 / Escalate after 3 attempts or 30s timeout.
        """
        with self._lock:
            # 이전 시도 기록 확인 / Check previous attempt history
            fault_attempts = [a for a in self._attempt_history
                              if a.fault_type == fault_type]
            recent_attempts = [a for a in fault_attempts
                               if time.time() - a.start_time < RECOVERY_TIMEOUT_SEC]

            if len(recent_attempts) >= MAX_RECOVERY_ATTEMPTS:
                logger.error(f"최대 복구 시도 초과 ({MAX_RECOVERY_ATTEMPTS})! "
                              f"인간 에스컬레이션 / Max attempts exceeded! Escalating")
                self.escalate_to_human()
                return None

            # 타임아웃 확인 / Check timeout
            if fault_attempts:
                elapsed = time.time() - fault_attempts[-1].start_time
                if elapsed > RECOVERY_TIMEOUT_SEC and not any(a.safety_score > 0.5 for a in recent_attempts):
                    logger.error(f"복구 타임아웃 ({RECOVERY_TIMEOUT_SEC}s)! "
                                  f"인간 에스컬레이션 / Recovery timeout! Escalating")
                    self.escalate_to_human()
                    return None

        # 정책으로 복구 행동 예측 / Predict recovery action from policy
        action, safety = self.trainer.predict(current_state, fault_type)

        attempt = RecoveryAttempt(
            fault_type=fault_type,
            start_time=time.time(),
            attempt_number=len(recent_attempts) + 1,
            action_sequence=action,
            safety_score=safety,
        )
        with self._lock:
            self._current_attempt = attempt
            self._attempt_history.append(attempt)

        logger.info(f"복구 시도 #{attempt.attempt_number}: fault={fault_type.name}, "
                      f"safety={safety:.3f} / Recovery attempt")

        # 안전성이 너무 낮으면 에스컬레이션 / Escalate if safety too low
        if safety < 0.2:
            logger.warning(f"안전성 너무 낮음 ({safety:.3f})! 에스컬레이션 / "
                            f"Safety too low! Escalating")
            self.escalate_to_human()
            return None

        return action

    def evaluate_recovery(self, state_after: np.ndarray) -> bool:
        """
        복구 후 상태 평가 / Evaluate state after recovery attempt.
        정상 상태로 복원되었는지 확인 / Check if returned to normal state.
        """
        # 간단한 휴리스틱: 속도/가속도/기울기가 정상 범위인지 / Simple heuristic check
        recovered = True

        # 상태 벡터에서 관련 필드 확인 / Check relevant fields in state vector
        if state_after.shape[0] >= STATE_DIM:
            # 속도가 0이 아닌지 (걸림 해제) / Velocity non-zero (unstuck)
            velocity_norm = np.linalg.norm(state_after[:3])
            if velocity_norm < 0.001:
                recovered = False
            # 기울기가 정상인지 / Tilt normal
            tilt = np.abs(state_after[3]) if state_after.shape[0] > 3 else 0.0
            if tilt > 30.0:
                recovered = False

        # 현재 시도 결과 기록 / Record current attempt result
        if self._current_attempt is not None:
            experience = RecoveryExperience(
                fault_state=np.zeros(STATE_DIM, dtype=np.float32),  # 원래 결함 상태는 별도 저장 필요
                fault_type=self._current_attempt.fault_type,
                recovery_action=self._current_attempt.action_sequence or np.zeros(ACTION_DIM, dtype=np.float32),
                success=recovered,
                time_to_recover=time.time() - self._current_attempt.start_time,
            )
            self.buffer.add(experience)

            if recovered:
                logger.info(f"복구 성공! 소요 시간: {experience.time_to_recover:.1f}s / "
                             f"Recovery successful!")
                self._current_attempt = None
                self._escalated = False
            else:
                logger.warning("복구 실패 / Recovery failed")

        return recovered

    def escalate_to_human(self):
        """
        인간 운영자에게 에스컬레이션 / Escalate to human operator.
        모든 자동 복구 시도가 실패한 경우 호출 / Called when all automatic recovery attempts fail.
        """
        self._escalated = True
        logger.critical("⚠️ 인간 에스컬레이션! 자동 복구 불가 / "
                         "HUMAN ESCALATION! Automatic recovery impossible")
        # 실제 시스템에서는 알림/이메일/음성 경고 발송 / In real system: send alerts/email/voice warning

    def is_escalated(self) -> bool:
        """에스컬레이션 상태 반환 / Return escalation status."""
        return self._escalated

    def reset(self):
        """복구 시스템 리셋 / Reset recovery system state."""
        with self._lock:
            self._current_attempt = None
            self._attempt_history.clear()
            self._escalated = False
        logger.info("복구 시스템 리셋 / Recovery system reset")

    def get_status(self) -> Dict[str, object]:
        """현재 복구 시스템 상태 반환 / Return current recovery system status."""
        return {
            "escalated": self._escalated,
            "current_attempt": (self._current_attempt.fault_type.name
                                if self._current_attempt else None),
            "total_attempts": len(self._attempt_history),
            "experience_count": self.buffer.count(),
        }


# ─── Module-level demo / 모듈 레벨 데모 ──────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    if not HAS_TORCH:
        logger.error("PyTorch 설치 필요 / PyTorch required")
    else:
        # 데모: 가상 복구 경험으로 훈련 / Demo: train with synthetic recovery experiences
        buffer = RecoveryExperienceBuffer(db_path=":memory:")

        for _ in range(100):
            fault_type = np.random.choice(list(FaultType))
            state = np.random.randn(STATE_DIM).astype(np.float32)
            action = np.random.randn(ACTION_DIM).astype(np.float32)
            success = np.random.rand() > 0.3
            ttr = np.random.uniform(0.5, 10.0) if success else 30.0
            buffer.add(RecoveryExperience(
                fault_state=state, fault_type=fault_type,
                recovery_action=action, success=success, time_to_recover=ttr
            ))

        trainer = RecoveryTrainer(buffer)
        bc_losses = trainer.behavioral_cloning(epochs=20, batch_size=16)
        logger.info(f"BC 손실: {bc_losses[-3:]} / BC losses (last 3)")

        # 긴급 복구 시스템 데모 / Emergency recovery system demo
        ers = EmergencyRecoverySystem(trainer)

        sensor_data = {
            "acceleration": np.array([0.1, 0.2, -8.0]),
            "contact_force": np.array([2.0, 1.0, 0.5]),
            "temperature": np.array([55.0]),
            "velocity": np.array([0.001, 0.0, 0.0]),
        }
        fault = ers.detect_fault(sensor_data)
        logger.info(f"감지된 결함: {fault} / Detected fault")

        if fault is not None:
            current_state = np.random.randn(STATE_DIM).astype(np.float32)
            action = ers.attempt_recovery(fault, current_state)
            if action is not None:
                logger.info(f"복구 행동 생성: shape={action.shape} / Recovery action generated")

        logger.info("recovery_policy.py 데모 완료 / Demo complete")
