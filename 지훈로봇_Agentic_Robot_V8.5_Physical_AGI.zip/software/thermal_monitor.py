#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TODO 46: 써멀 모니터 (Thermal Monitor)
======================================================

Jetson Orin NX 16GB 온도 모니터링 및 써멀 관리:
  - CPU/GPU 온도 실시간 읽기 (thermal_zone0/1)
  - 75°C 스로틀, 85°C 긴급 셧다운
  - 70°C+ 40mm 쿨링팬 제어 (ESP32-S3 GPIO 경유)
  - 15W 연속 부하 30분 안정성 검증 지원

V8.5 추가 기능:
  - 먼지 누적 감지 (온도 상승률 기반) (PDF #76)
  - 멀티존 써멀 모니터링 (CPU/GPU + 기타 존)
  - 열적 피로 감지 (PDF #45: 냉각 효율 저하로 인한 칩 열적 피로)
  - 팬 베어링 마모 감지 (전류 소비 변화) (PDF #27)
  - 냉각수 누수 감지 플레이스홀더 (PDF #26)

하드웨어 경로:
  /sys/devices/virtual/thermal/thermal_zone0/temp  → CPU
  /sys/devices/virtual/thermal/thermal_zone1/temp  → GPU
  ESP32-S3 GPIO 41 → 40mm 쿨링팬 PWM 제어

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import os
import signal
import subprocess
import time

import numpy as np
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("jihun.v84.thermal_monitor")


# ============================================================================
# 상수 및 열거형
# ============================================================================

class ThermalLevel(IntEnum):
    """써멀 위험도 레벨"""
    NORMAL = 0       # < 60°C
    WARM = 1         # 60-70°C
    FAN_ON = 2       # 70-75°C (팬 활성화)
    THROTTLE = 3     # 75-85°C (성능 제한)
    EMERGENCY = 4    # >= 85°C (긴급 셧다운)


class ThrottleAction(Enum):
    """스로틀 동작"""
    NONE = "none"
    REDUCE_CLOCK = "reduce_clock"
    DISABLE_TURBO = "disable_turbo"
    SHUTDOWN = "shutdown"


# Jetson thermal zone 경로
THERMAL_ZONE_BASE = Path("/sys/devices/virtual/thermal/thermal_zone")
CPU_ZONE = 0   # thermal_zone0 → CPU
GPU_ZONE = 1   # thermal_zone1 → GPU

# V8.5: 멀티존 정의 (CPU/GPU 이외 추가 존)
THERMAL_ZONES = {
    "cpu": 0,       # thermal_zone0 → CPU
    "gpu": 1,       # thermal_zone1 → GPU
    "soc": 2,       # thermal_zone2 → SoC (Jetson Orin NX)
    "board": 3,     # thermal_zone3 → 보드 온도
    "tdiode": 4,    # thermal_zone4 → Thermal diode
}

# 온도 임계값 (°C)
TEMP_FAN_ON = 70.0
TEMP_THROTTLE = 75.0
TEMP_EMERGENCY = 85.0
TEMP_WARM = 60.0
TEMP_HYSTERESIS = 3.0   # 히스테리시스 (팬 끄기 기준)

# 팬 PWM 설정
FAN_PWM_MIN = 0.3    # 최소 PWM (30%)
FAN_PWM_MAX = 1.0    # 최대 PWM (100%)
FAN_PWM_STEP = 0.1   # PWM 증감 단계

# 모니터링 주기
MONITOR_INTERVAL_S = 1.0
SHUTDOWN_GRACE_S = 5.0

# V8.5: 먼지 누적 감지 임계값 (PDF #76)
DUST_TEMP_RISE_THRESHOLD_C_PER_MIN = 3.0  # 분당 온도 상승률 임계 (°C/min)
DUST_MONITOR_WINDOW_S = 300.0             # 모니터링 윈도우 (5분)
DUST_ALERT_COUNT_THRESHOLD = 3            # 연속 알림 횟수

# V8.5: 열적 피로 감지 임계값 (PDF #45)
THERMAL_FATIGUE_CYCLE_COUNT = 100         # 열 사이클 누적 임계
THERMAL_FATIGUE_DELTA_C = 20.0            # 사이클당 온도 변화 임계 (°C)
THERMAL_FATIGUE_EFFICIENCY_DROP_PCT = 15.0  # 냉각 효율 저하 임계 (%)

# V8.5: 팬 베어링 마모 감지 임계값 (PDF #27)
FAN_BEARING_CURRENT_MA_BASELINE = 150.0   # 정상 팬 전류 베이스라인 (mA)
FAN_BEARING_CURRENT_MA_THRESHOLD = 50.0   # 전류 증가 임계 (mA)
FAN_BEARING_RPM_DROP_PCT = 15.0           # RPM 저하 임계 (%)


@dataclass
class ThermalReading:
    """써멀 센서 읽기 결과"""
    timestamp: float
    cpu_temp_c: float
    gpu_temp_c: float
    thermal_level: ThermalLevel = ThermalLevel.NORMAL
    fan_active: bool = False
    fan_pwm: float = 0.0
    throttled: bool = False
    # V8.5: 멀티존 온도
    zone_temps: Dict[str, float] = field(default_factory=dict)

    @property
    def max_temp_c(self) -> float:
        return max(self.cpu_temp_c, self.gpu_temp_c)

    @property
    def max_all_zone_temp_c(self) -> float:
        """V8.5: 모든 존 중 최대 온도"""
        all_temps = [self.cpu_temp_c, self.gpu_temp_c] + list(self.zone_temps.values())
        return max(all_temps) if all_temps else 0.0


@dataclass
class ThermalMonitorConfig:
    """써멀 모니터 설정"""
    cpu_zone_path: str = str(THERMAL_ZONE_BASE / f"zone{CPU_ZONE}/temp")
    gpu_zone_path: str = str(THERMAL_ZONE_BASE / f"zone{GPU_ZONE}/temp")
    esp32_fan_gpio: int = 41               # ESP32-S3 GPIO 41
    esp32_uart_port: str = "/dev/ttyTHS1"
    esp32_uart_baud: int = 921600
    temp_fan_on: float = TEMP_FAN_ON
    temp_throttle: float = TEMP_THROTTLE
    temp_emergency: float = TEMP_EMERGENCY
    temp_warm: float = TEMP_WARM
    temp_hysteresis: float = TEMP_HYSTERESIS
    monitor_interval_s: float = MONITOR_INTERVAL_S
    simulation_mode: bool = False           # 하드웨어 없을 시 시뮬레이션
    shutdown_callback: Optional[Callable[[], None]] = None
    # V8.5: 멀티존 활성화
    multi_zone_enabled: bool = True


# ============================================================================
# V8.5: 먼지 누적 감지기 (PDF #76)
# ============================================================================

class DustAccumulationDetector:
    """
    먼지 누적 감지 — 온도 상승률 기반

    PDF #76: 방열판/팬 먼지 누적 → 냉각 효율 저하 → 동일 부하에서 온도 상승률 증가
    → 부하 대비 온도 상승률 분석으로 먼지 누적 간접 감지
    """

    def __init__(self, rise_threshold_c_per_min: float = DUST_TEMP_RISE_THRESHOLD_C_PER_MIN,
                 window_s: float = DUST_MONITOR_WINDOW_S,
                 alert_count_threshold: int = DUST_ALERT_COUNT_THRESHOLD):
        self._rise_threshold = rise_threshold_c_per_min
        self._window_s = window_s
        self._alert_count_threshold = alert_count_threshold
        self._temp_history: List[Tuple[float, float]] = []  # (timestamp, temp_c)
        self._alert_count: int = 0
        self._dust_detected: bool = False

    def update(self, current_temp_c: float, load_pct: float = 0.0) -> Dict:
        """
        온도 업데이트 및 먼지 누적 여부 분석

        Args:
            current_temp_c: 현재 최대 온도 (°C)
            load_pct: 현재 CPU/GPU 부하 (%)

        Returns:
            먼지 누적 분석 결과
        """
        now = time.time()
        self._temp_history.append((now, current_temp_c))

        # 윈도우 내 데이터만 유지
        self._temp_history = [(t, temp) for t, temp in self._temp_history
                              if now - t <= self._window_s]

        if len(self._temp_history) < 10:
            return {"dust_detected": False, "rise_rate_c_per_min": 0.0, "confidence": "low"}

        # 온도 상승률 계산 (°C/min)
        t0, temp0 = self._temp_history[0]
        t1, temp1 = self._temp_history[-1]
        dt_min = (t1 - t0) / 60.0
        rise_rate = (temp1 - temp0) / dt_min if dt_min > 0 else 0.0

        # 부하 보정: 부하가 낮은데 온도가 높으면 먼지 의심
        load_adjusted_threshold = self._rise_threshold
        if load_pct < 30.0:
            # 저부하에서 온도 상승이면 먼지 의심도 증가
            load_adjusted_threshold = self._rise_threshold * 0.7

        is_suspect = rise_rate > load_adjusted_threshold

        if is_suspect:
            self._alert_count += 1
            if self._alert_count >= self._alert_count_threshold:
                self._dust_detected = True
                logger.warning(
                    "먼지 누적 의심! 온도 상승률: %.2f°C/min (임계: %.2f°C/min, "
                    "부하: %.0f%%) — PDF #76",
                    rise_rate, load_adjusted_threshold, load_pct
                )
        else:
            self._alert_count = max(0, self._alert_count - 1)
            if self._alert_count == 0:
                self._dust_detected = False

        return {
            "dust_detected": self._dust_detected,
            "rise_rate_c_per_min": round(rise_rate, 2),
            "alert_count": self._alert_count,
            "threshold_c_per_min": round(load_adjusted_threshold, 2),
            "confidence": "high" if len(self._temp_history) > 30 else "medium",
        }


# ============================================================================
# V8.5: 열적 피로 감지기 (PDF #45: 냉각 효율 저하로 인한 칩 열적 피로)
# ============================================================================

class ThermalFatigueDetector:
    """
    열적 피로 감지 — 반복 열 사이클로 인한 칩 열적 피로 누적

    PDF #45: 냉각 효율 저하 → 칩 온도 사이클 증가 → 열적 피로 누적 → 수명 단축
    → 열 사이클 카운팅 및 냉각 효율 추적
    """

    def __init__(self, cycle_count_threshold: int = THERMAL_FATIGUE_CYCLE_COUNT,
                 delta_threshold_c: float = THERMAL_FATIGUE_DELTA_C,
                 efficiency_drop_pct: float = THERMAL_FATIGUE_EFFICIENCY_DROP_PCT):
        self._cycle_count_threshold = cycle_count_threshold
        self._delta_threshold = delta_threshold_c
        self._efficiency_drop_threshold = efficiency_drop_pct

        # 열 사이클 추적
        self._total_cycles: int = 0
        self._last_temp: Optional[float] = None
        self._cycle_direction: Optional[str] = None  # 'rising' or 'falling'

        # 냉각 효율 추적
        self._cooling_efficiency_history: List[Tuple[float, float]] = []  # (timestamp, efficiency)
        self._baseline_efficiency: Optional[float] = None

    def update(self, current_temp_c: float, fan_pwm: float = 0.0) -> Dict:
        """
        온도 업데이트 및 열적 피로 분석

        Args:
            current_temp_c: 현재 온도 (°C)
            fan_pwm: 현재 팬 PWM (0.0~1.0)

        Returns:
            열적 피로 분석 결과
        """
        now = time.time()

        # 열 사이클 카운팅
        if self._last_temp is not None:
            delta = current_temp_c - self._last_temp
            if abs(delta) > 2.0:  # 2°C 이상 변화를 사이클로 간주
                current_direction = 'rising' if delta > 0 else 'falling'
                if self._cycle_direction is not None and current_direction != self._cycle_direction:
                    self._total_cycles += 1
                self._cycle_direction = current_direction

        self._last_temp = current_temp_c

        # 냉각 효율 추정: 팬이 켜진 상태에서 온도가 얼마나 떨어지는지
        if fan_pwm > 0.3:
            # 간이 냉각 효율 = 팬 출력 대비 온도 강하율
            efficiency = max(0.0, (TEMP_FAN_ON - current_temp_c) / (fan_pwm * 30.0) + 1.0)
        else:
            efficiency = 1.0

        self._cooling_efficiency_history.append((now, efficiency))
        # 최근 1시간 데이터만 유지
        self._cooling_efficiency_history = [(t, e) for t, e in self._cooling_efficiency_history
                                             if now - t <= 3600]

        if self._baseline_efficiency is None and len(self._cooling_efficiency_history) >= 5:
            baseline_samples = [e for _, e in self._cooling_efficiency_history[:10]]
            self._baseline_efficiency = sum(baseline_samples) / len(baseline_samples)

        # 효율 저하 계산
        efficiency_drop_pct = 0.0
        if self._baseline_efficiency and self._baseline_efficiency > 0:
            current_efficiency = efficiency
            efficiency_drop_pct = ((self._baseline_efficiency - current_efficiency)
                                    / self._baseline_efficiency * 100.0)

        fatigue_detected = (
            self._total_cycles >= self._cycle_count_threshold
            or efficiency_drop_pct >= self._efficiency_drop_threshold
        )

        if fatigue_detected:
            logger.warning(
                "열적 피로 의심! 사이클: %d (임계: %d), 효율 저하: %.1f%% (임계: %.1f%%) — PDF #45",
                self._total_cycles, self._cycle_count_threshold,
                efficiency_drop_pct, self._efficiency_drop_threshold
            )

        return {
            "fatigue_detected": fatigue_detected,
            "total_thermal_cycles": self._total_cycles,
            "cycle_threshold": self._cycle_count_threshold,
            "efficiency_drop_pct": round(efficiency_drop_pct, 1),
            "current_efficiency": round(efficiency, 3),
            "baseline_efficiency": round(self._baseline_efficiency, 3) if self._baseline_efficiency else None,
        }


# ============================================================================
# V8.5: 팬 베어링 마모 감지 (PDF #27)
# ============================================================================

class FanBearingWearDetector:
    """
    팬 베어링 마모 감지 — 팬 전류 소비 변화 기반

    PDF #27: 베어링 마모 → 마찰 증가 → 전류 소비 증가 + RPM 저하
    → 팬 전류/RPM 모니터링으로 마모 간접 감지
    """

    def __init__(self, current_baseline_ma: float = FAN_BEARING_CURRENT_MA_BASELINE,
                 current_threshold_ma: float = FAN_BEARING_CURRENT_MA_THRESHOLD,
                 rpm_drop_pct: float = FAN_BEARING_RPM_DROP_PCT):
        self._current_baseline = current_baseline_ma
        self._current_threshold = current_threshold_ma
        self._rpm_drop_threshold = rpm_drop_pct

        self._current_samples: List[float] = []
        self._rpm_samples: List[float] = []
        self._baseline_rpm: Optional[float] = None
        self._wear_detected: bool = False

    def update(self, fan_current_ma: float, fan_rpm: float, fan_pwm: float) -> Dict:
        """
        팬 전류 및 RPM 업데이트

        Args:
            fan_current_ma: 패 전류 (mA)
            fan_rpm: 팬 RPM
            fan_pwm: 현재 팬 PWM (0.0~1.0)

        Returns:
            베어링 마모 분석 결과
        """
        if fan_pwm < 0.5:
            # 팬이 충분히 돌고 있지 않으면 스킵
            return {"wear_detected": False, "skipped": True}

        self._current_samples.append(fan_current_ma)
        self._rpm_samples.append(fan_rpm)

        # 샘플 보관 (최대 100)
        if len(self._current_samples) > 100:
            self._current_samples = self._current_samples[-100:]
        if len(self._rpm_samples) > 100:
            self._rpm_samples = self._rpm_samples[-100:]

        # RPM 베이스라인 설정
        if self._baseline_rpm is None and len(self._rpm_samples) >= 5:
            self._baseline_rpm = sum(self._rpm_samples[:5]) / 5.0
            logger.info("팬 RPM 베이스라인 설정: %.0f RPM", self._baseline_rpm)

        # 전류 증가 분석
        avg_current = sum(self._current_samples) / len(self._current_samples)
        current_increase = avg_current - self._current_baseline
        current_exceeded = current_increase > self._current_threshold

        # RPM 저하 분석
        rpm_drop_pct = 0.0
        rpm_exceeded = False
        if self._baseline_rpm and self._baseline_rpm > 0 and len(self._rpm_samples) >= 5:
            recent_rpm = sum(self._rpm_samples[-5:]) / 5.0
            rpm_drop_pct = (self._baseline_rpm - recent_rpm) / self._baseline_rpm * 100.0
            rpm_exceeded = rpm_drop_pct > self._rpm_drop_threshold

        self._wear_detected = current_exceeded or rpm_exceeded

        if self._wear_detected:
            logger.warning(
                "팬 베어링 마모 의심! 전류: %.1fmA (베이스라인: %.1fmA, 증가: %.1fmA), "
                "RPM 저하: %.1f%% — PDF #27",
                avg_current, self._current_baseline, current_increase, rpm_drop_pct
            )

        return {
            "wear_detected": self._wear_detected,
            "avg_current_ma": round(avg_current, 1),
            "current_increase_ma": round(current_increase, 1),
            "rpm_drop_pct": round(rpm_drop_pct, 1),
            "current_exceeded": current_exceeded,
            "rpm_exceeded": rpm_exceeded,
        }


# ============================================================================
# V8.5: 냉각수 누수 감지 플레이스홀더 (PDF #26)
# ============================================================================

class CoolantLeakDetector:
    """
    냉각수 누수 감지 — 플레이스홀더 (향후 하드웨어 센서 연동)

    PDF #26: 수랭식 냉각 시스템 누수 → 치명적 과열
    → 현재: 소프트웨어 감지 로직만 구현 (하드웨어 센서 미장착)
    → 향후: 유량 센서, 습도 센서 연동 예정
    """

    def __init__(self):
        self._last_flow_rate: Optional[float] = None
        self._flow_rate_history: List[Tuple[float, float]] = []  # (timestamp, flow_rate)
        self._leak_detected: bool = False
        self._flow_sensor_available: bool = False

    def update(self, flow_rate: Optional[float] = None,
               humidity_pct: Optional[float] = None) -> Dict:
        """
        냉각수 상태 업데이트

        Args:
            flow_rate: 냉각수 유량 (L/min) — 센서 미장착 시 None
            humidity_pct: 내부 습도 (%) — 센서 미장착 시 None

        Returns:
            냉각수 누수 감지 결과
        """
        now = time.time()

        # 하드웨어 센서 미장착 시 플레이스홀더 동작
        if flow_rate is None and humidity_pct is None:
            return {
                "leak_detected": False,
                "sensor_available": False,
                "status": "placeholder — 하드웨어 센서 미장착 (PDF #26)",
                "flow_rate_l_per_min": None,
                "humidity_pct": None,
            }

        # 유량 기반 감지
        if flow_rate is not None:
            self._flow_sensor_available = True
            self._flow_rate_history.append((now, flow_rate))

            # 최근 5분 데이터 유지
            self._flow_rate_history = [(t, f) for t, f in self._flow_rate_history
                                       if now - t <= 300]

            # 유량 급감 감지
            if len(self._flow_rate_history) >= 5:
                avg_flow = sum(f for _, f in self._flow_rate_history) / len(self._flow_rate_history)
                recent_flow = self._flow_rate_history[-1][1]
                if avg_flow > 0 and recent_flow < avg_flow * 0.5:
                    self._leak_detected = True
                    logger.critical(
                        "냉각수 유량 급감! 현재: %.2f L/min (평균: %.2f L/min) — PDF #26",
                        recent_flow, avg_flow
                    )

        # 습도 기반 감지 (보조)
        if humidity_pct is not None and humidity_pct > 80:
            logger.warning("내부 습도 높음: %.1f%% — 냉각수 누수 의심 (PDF #26)", humidity_pct)
            self._leak_detected = True

        return {
            "leak_detected": self._leak_detected,
            "sensor_available": self._flow_sensor_available,
            "flow_rate_l_per_min": flow_rate,
            "humidity_pct": humidity_pct,
        }

    @property
    def is_leak_detected(self) -> bool:
        return self._leak_detected


# ============================================================================
# ThermalMonitor 클래스 — V8.5
# ============================================================================

class ThermalMonitor:
    """
    Jetson Orin NX 써멀 모니터 및 팬 제어 — V8.5

    온도 → 동작 매핑:
      < 60°C  → NORMAL (팬 OFF)
      60-70°C → WARM (팬 OFF, 모니터링 강화)
      70-75°C → FAN_ON (팬 ON, PWM 보간)
      75-85°C → THROTTLE (클럭 제한 + 팬 MAX)
      >= 85°C → EMERGENCY (긴급 셧다운)

    V8.5 추가:
      - 멀티존 써멀 모니터링 (CPU/GPU + SoC/보드/다이오드)
      - 먼지 누적 감지 (DustAccumulationDetector)
      - 열적 피로 감지 (ThermalFatigueDetector)
      - 팬 베어링 마모 감지 (FanBearingWearDetector)
      - 냉각수 누수 감지 (CoolantLeakDetector)

    사용 예시:
        monitor = ThermalMonitor()
        reading = monitor.read_temp()
        monitor.check_throttle(reading)
        monitor.control_fan(reading)
    """

    def __init__(self, config: Optional[ThermalMonitorConfig] = None) -> None:
        self._config = config or ThermalMonitorConfig()
        self._running: bool = False
        self._fan_active: bool = False
        self._current_pwm: float = 0.0
        self._throttled: bool = False
        self._history: List[ThermalReading] = []
        self._max_history: int = 3600  # 1시간 @ 1Hz

        # V8.5: 서브 감지기 인스턴스
        self._dust_detector = DustAccumulationDetector()
        self._fatigue_detector = ThermalFatigueDetector()
        self._fan_wear_detector = FanBearingWearDetector()
        self._coolant_leak_detector = CoolantLeakDetector()

        # 시뮬레이션 모드 자동 감지
        if not self._config.simulation_mode:
            if not Path(self._config.cpu_zone_path).exists():
                logger.warning("써멀 존 경로 없음 — 시뮬레이션 모드 전환")
                self._config.simulation_mode = True

        # ESP32 UART 연결 (팬 제어용)
        self._esp32_serial = None
        if not self._config.simulation_mode:
            self._init_esp32_comm()

        logger.info("ThermalMonitor V8.5 초기화 완료 (시뮬레이션=%s)", self._config.simulation_mode)

    def _init_esp32_comm(self) -> None:
        """ESP32-S3 UART 통신 초기화 (팬 제어용)"""
        try:
            import serial
            self._esp32_serial = serial.Serial(
                port=self._config.esp32_uart_port,
                baudrate=self._config.esp32_uart_baud,
                timeout=0.1
            )
            logger.info("ESP32 UART 연결: %s @ %dbps", self._config.esp32_uart_port, self._config.esp32_uart_baud)
        except Exception as e:
            logger.warning("ESP32 UART 연결 실패: %s — 팬 제어 불가", e)
            self._esp32_serial = None

    # ========================================================================
    # 온도 읽기 — V8.5: 멀티존 지원
    # ========================================================================

    def read_temp(self) -> ThermalReading:
        """
        CPU/GPU 온도 읽기 — V8.5: 멀티존 확장

        Returns:
            ThermalReading: 현재 온도 및 상태 (V8.5 확장 필드 포함)
        """
        cpu_temp = self._read_zone_temp(self._config.cpu_zone_path)
        gpu_temp = self._read_zone_temp(self._config.gpu_zone_path)
        level = self._classify_thermal_level(cpu_temp, gpu_temp)

        # V8.5: 멀티존 온도 읽기
        zone_temps = {}
        if self._config.multi_zone_enabled:
            zone_temps = self._read_all_zones()

        reading = ThermalReading(
            timestamp=time.time(),
            cpu_temp_c=cpu_temp,
            gpu_temp_c=gpu_temp,
            thermal_level=level,
            fan_active=self._fan_active,
            fan_pwm=self._current_pwm,
            throttled=self._throttled,
            # V8.5
            zone_temps=zone_temps,
        )

        # 이력 기록
        self._history.append(reading)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

        return reading

    def _read_zone_temp(self, path: str) -> float:
        """
        thermal_zone 파일에서 온도 읽기 (밀리도 → 섭씨 변환)

        Args:
            path: thermal_zone temp 파일 경로

        Returns:
            온도 (°C)
        """
        if self._config.simulation_mode:
            # 시뮬레이션: 부하 기반 가상 온도
            return 45.0 + (time.time() % 100) * 0.3

        try:
            temp_str = Path(path).read_text().strip()
            temp_mc = int(temp_str)   # 밀리섭씨
            return temp_mc / 1000.0
        except (FileNotFoundError, ValueError, PermissionError) as e:
            logger.error("온도 읽기 실패 [%s]: %s", path, e)
            return 0.0

    def _read_all_zones(self) -> Dict[str, float]:
        """
        V8.5: 모든 써멀 존 온도 읽기

        Returns:
            존 이름 → 온도 (°C) 매핑
        """
        zone_temps = {}
        for zone_name, zone_id in THERMAL_ZONES.items():
            if zone_name in ("cpu", "gpu"):
                continue  # 이미 읽음
            zone_path = str(THERMAL_ZONE_BASE / f"zone{zone_id}/temp")
            temp = self._read_zone_temp(zone_path)
            if temp > 0:
                zone_temps[zone_name] = round(temp, 1)
        return zone_temps

    def _classify_thermal_level(self, cpu_temp: float, gpu_temp: float) -> ThermalLevel:
        """온도 기반 써멀 레벨 분류"""
        max_temp = max(cpu_temp, gpu_temp)

        if max_temp >= self._config.temp_emergency:
            return ThermalLevel.EMERGENCY
        elif max_temp >= self._config.temp_throttle:
            return ThermalLevel.THROTTLE
        elif max_temp >= self._config.temp_fan_on:
            return ThermalLevel.FAN_ON
        elif max_temp >= self._config.temp_warm:
            return ThermalLevel.WARM
        else:
            return ThermalLevel.NORMAL

    # ========================================================================
    # 스로틀 검사
    # ========================================================================

    def check_throttle(self, reading: ThermalReading) -> Optional[ThrottleAction]:
        """
        온도 기반 스로틀 동작 결정

        Args:
            reading: 최신 써멀 읽기

        Returns:
            수행할 동작 (없으면 None)
        """
        level = reading.thermal_level

        if level == ThermalLevel.EMERGENCY:
            logger.critical("🚨 긴급 셧다운! CPU=%.1f°C GPU=%.1f°C",
                          reading.cpu_temp_c, reading.gpu_temp_c)
            self._throttled = True
            self.emergency_shutdown()
            return ThrottleAction.SHUTDOWN

        elif level == ThermalLevel.THROTTLE:
            if not self._throttled:
                logger.warning("⚠️ 써멀 스로틀 활성화: CPU=%.1f°C GPU=%.1f°C",
                             reading.cpu_temp_c, reading.gpu_temp_c)
                self._throttled = True
                self._apply_clock_reduction()
            return ThrottleAction.REDUCE_CLOCK

        elif level == ThermalLevel.FAN_ON:
            # 팬만으로 관리 가능
            pass

        else:
            # 정상 복귀
            if self._throttled and reading.max_temp_c < (self._config.temp_throttle - TEMP_HYSTERESIS):
                logger.info("✅ 써멀 정상 복귀: 스로틀 해제")
                self._throttled = False
                self._restore_clock()

        return None

    def _apply_clock_reduction(self) -> None:
        """Jetson 클럭 제한 적용 (nvpmodel 15W 모드)"""
        if self._config.simulation_mode:
            logger.info("[시뮬] 클럭 제한 적용")
            return

        try:
            # 전원 모드를 15W로 강제 전환
            subprocess.run(
                ["sudo", "nvpmodel", "-m", "1"],
                timeout=5, capture_output=True
            )
            logger.info("nvpmodel 15W 모드 전환 완료")
        except Exception as e:
            logger.error("클럭 제한 실패: %s", e)

    def _restore_clock(self) -> None:
        """클럭 복원 (nvpmodel 20W 모드)"""
        if self._config.simulation_mode:
            logger.info("[시뮬] 클럭 복원")
            return

        try:
            subprocess.run(
                ["sudo", "nvpmodel", "-m", "0"],
                timeout=5, capture_output=True
            )
            logger.info("nvpmodel 20W 모드 복원 완료")
        except Exception as e:
            logger.error("클럭 복원 실패: %s", e)

    # ========================================================================
    # 팬 제어
    # ========================================================================

    def control_fan(self, reading: ThermalReading) -> float:
        """
        온도 기반 40mm 쿨링팬 PWM 제어

        로직:
          - 70°C+ → 팬 ON (PWM 보간: 30%~100%)
          - 67°C 이하 → 팬 OFF (히스테리시스)
          - 75°C+ → 팬 MAX

        Args:
            reading: 최신 써멀 읽기

        Returns:
            현재 PWM 듀티 (0.0~1.0)
        """
        max_temp = reading.max_temp_c

        # 팬 ON 조건
        if max_temp >= self._config.temp_fan_on:
            if not self._fan_active:
                logger.info("🌀 쿨링팬 ON (온도: %.1f°C)", max_temp)
                self._fan_active = True

            # PWM 보간
            if max_temp >= self._config.temp_throttle:
                target_pwm = FAN_PWM_MAX
            else:
                # 70°C→30%, 75°C→100% 선형 보간
                ratio = (max_temp - self._config.temp_fan_on) / (
                    self._config.temp_throttle - self._config.temp_fan_on
                )
                target_pwm = FAN_PWM_MIN + ratio * (FAN_PWM_MAX - FAN_PWM_MIN)
                target_pwm = max(FAN_PWM_MIN, min(FAN_PWM_MAX, target_pwm))

            # 단계적 PWM 변화 (급격한 변화 방지)
            if abs(target_pwm - self._current_pwm) > FAN_PWM_STEP:
                if target_pwm > self._current_pwm:
                    self._current_pwm += FAN_PWM_STEP
                else:
                    self._current_pwm -= FAN_PWM_STEP
            else:
                self._current_pwm = target_pwm

            self._send_fan_command(self._current_pwm)

        # 팬 OFF 조건 (히스테리시스 적용)
        elif self._fan_active and max_temp < (self._config.temp_fan_on - self._config.temp_hysteresis):
            logger.info("🌀 쿨링팬 OFF (온도: %.1f°C)", max_temp)
            self._fan_active = False
            self._current_pwm = 0.0
            self._send_fan_command(0.0)

        return self._current_pwm

    def _send_fan_command(self, pwm: float) -> None:
        """
        ESP32-S3에 팬 PWM 명령 전송

        프로토콜: JSON {"cmd":"fan","gpio":41,"pwm":0.7}
        """
        if self._config.simulation_mode:
            logger.debug("[시뮬] 팬 PWM: %.1f%%", pwm * 100)
            return

        if self._esp32_serial is None:
            return

        try:
            cmd = f'{{"cmd":"fan","gpio":{self._config.esp32_fan_gpio},"pwm":{pwm:.2f}}}\n'
            self._esp32_serial.write(cmd.encode("utf-8"))
            logger.debug("팬 명령 전송: PWM=%.1f%%", pwm * 100)
        except Exception as e:
            logger.error("팬 명령 전송 실패: %s", e)

    # ========================================================================
    # V8.5: 종합 진단
    # ========================================================================

    def run_diagnostics(self, reading: ThermalReading, load_pct: float = 0.0) -> Dict:
        """
        V8.5: 써멀 종합 진단 — 모든 감지기 실행

        Args:
            reading: 최신 써멀 읽기
            load_pct: 현재 시스템 부하 (%)

        Returns:
            종합 진단 결과
        """
        max_temp = reading.max_temp_c

        # 먼지 누적 감지 (PDF #76)
        dust_result = self._dust_detector.update(max_temp, load_pct)

        # 열적 피로 감지 (PDF #45)
        fatigue_result = self._fatigue_detector.update(max_temp, self._current_pwm)

        # 팬 베어링 마모 감지 (PDF #27)
        # 시뮬레이션 시 가상 값 사용
        if self._config.simulation_mode:
            fan_current_ma = 150.0 + (time.time() % 60) * 0.5
            fan_rpm = 5000.0 - (time.time() % 300) * 2.0
        else:
            # 실제 센서 읽기 (향후 구현)
            fan_current_ma = 150.0
            fan_rpm = 5000.0
        wear_result = self._fan_wear_detector.update(fan_current_ma, fan_rpm, self._current_pwm)

        # 냉각수 누수 감지 (PDF #26) — 플레이스홀더
        leak_result = self._coolant_leak_detector.update()

        # 종합 평가
        any_warning = (
            dust_result.get("dust_detected", False)
            or fatigue_result.get("fatigue_detected", False)
            or wear_result.get("wear_detected", False)
            or leak_result.get("leak_detected", False)
        )

        return {
            "dust_accumulation": dust_result,
            "thermal_fatigue": fatigue_result,
            "fan_bearing_wear": wear_result,
            "coolant_leak": leak_result,
            "overall_warning": any_warning,
            "max_temp_c": max_temp,
            "fan_pwm": self._current_pwm,
        }

    # ========================================================================
    # 긴급 셧다운
    # ========================================================================

    def emergency_shutdown(self) -> None:
        """
        85°C 긴급 셧다운 절차

        순서:
          1. 모터 정지
          2. 팬 MAX
          3. 안전 메시지 브로드캐스트
          4. 시스템 셧다운
        """
        logger.critical("=" * 50)
        logger.critical("🚨 긴급 셧다운 시작!")
        logger.critical("CPU/GPU 과열 — 85°C 초과")
        logger.critical("=" * 50)

        # 1. 팬 MAX
        self._current_pwm = FAN_PWM_MAX
        self._send_fan_command(FAN_PWM_MAX)

        # 2. 셧다운 콜백
        if self._config.shutdown_callback:
            try:
                self._config.shutdown_callback()
            except Exception as e:
                logger.error("셧다운 콜백 실패: %s", e)

        # 3. 시스템 셧다운 (실제 환경)
        if not self._config.simulation_mode:
            logger.critical("%d초 후 시스템 셧다운...", SHUTDOWN_GRACE_S)
            try:
                subprocess.run(
                    ["sudo", "shutdown", "-P", "now"],
                    timeout=3, capture_output=True
                )
            except Exception as e:
                logger.error("셧다운 명령 실패: %s", e)

        self._running = False

    # ========================================================================
    # 모니터링 루프
    # ========================================================================

    def start_monitoring(self) -> None:
        """백그라운드 써멀 모니터링 시작"""
        self._running = True
        logger.info("써멀 모니터링 시작 (주기: %.1fs) — V8.5", self._config.monitor_interval_s)

        while self._running:
            try:
                reading = self.read_temp()
                self.check_throttle(reading)
                self.control_fan(reading)

                # V8.5: 주기적 종합 진단 (30초마다)
                if int(reading.timestamp) % 30 == 0:
                    diag = self.run_diagnostics(reading)
                    if diag["overall_warning"]:
                        logger.warning("써멀 진단 경고: %s", diag)

                # 주기적 상태 로깅 (10초마다)
                if int(reading.timestamp) % 10 == 0:
                    zone_info = ""
                    if reading.zone_temps:
                        zone_info = " " + " ".join(
                            f"{k}={v:.1f}°C" for k, v in reading.zone_temps.items()
                        )
                    logger.debug("써멀: CPU=%.1f°C GPU=%.1f°C%s 팬=%.0f%% 스로틀=%s",
                               reading.cpu_temp_c, reading.gpu_temp_c,
                               zone_info,
                               self._current_pwm * 100, self._throttled)

            except Exception as e:
                logger.error("모니터링 루프 오류: %s", e)

            time.sleep(self._config.monitor_interval_s)

    def stop_monitoring(self) -> None:
        """모니터링 중지"""
        self._running = False
        logger.info("써멀 모니터링 중지")

    # ========================================================================
    # 유틸리티
    # ========================================================================

    def get_status(self) -> Dict:
        """현재 써멀 상태 요약 — V8.5 확장"""
        if self._history:
            latest = self._history[-1]
            status = {
                "cpu_temp_c": latest.cpu_temp_c,
                "gpu_temp_c": latest.gpu_temp_c,
                "max_temp_c": latest.max_temp_c,
                "thermal_level": latest.thermal_level.name,
                "fan_active": self._fan_active,
                "fan_pwm": round(self._current_pwm, 2),
                "throttled": self._throttled,
                "history_count": len(self._history),
                # V8.5
                "zone_temps": latest.zone_temps,
                "max_all_zone_temp_c": latest.max_all_zone_temp_c,
            }
            return status
        return {"status": "no_data"}

    def get_temp_history(self, last_n: int = 60) -> List[ThermalReading]:
        """최근 온도 이력 반환"""
        return self._history[-last_n:]

    @property
    def is_throttled(self) -> bool:
        """현재 스로틀 상태"""
        return self._throttled

    @property
    def is_fan_active(self) -> bool:
        """팬 활성 상태"""
        return self._fan_active

    def __del__(self) -> None:
        """소멸자 — 팬 정지"""
        if self._esp32_serial:
            try:
                self._send_fan_command(0.0)
                self._esp32_serial.close()
            except Exception:
                pass


# ============================================================================
# 독립 실행
# ============================================================================

def main() -> None:
    """독립 실행: 써멀 모니터링 데모"""
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    monitor = ThermalMonitor()

    # SIGINT 핸들러
    def signal_handler(sig: int, frame: object) -> None:
        logger.info("종료 신호 수신 — 모니터링 중지")
        monitor.stop_monitoring()

    signal.signal(signal.SIGINT, signal_handler)

    # 모니터링 시작
    logger.info("지훈 로봇 V8.5 — 써멀 모니터 시작")
    logger.info("임계값: 팬 ON %.0f°C / 스로틀 %.0f°C / 셧다운 %.0f°C",
                TEMP_FAN_ON, TEMP_THROTTLE, TEMP_EMERGENCY)
    logger.info("V8.5 기능: 먼지감지/멀티존/열적피로/팬마모/냉각수누수")

    monitor.start_monitoring()


if __name__ == "__main__":
    main()


# ============================================================================
# Thermal Safety Improvements — V8.5 온도 안전성 강화
# ============================================================================

class SmoothFanController:
    """부드러운 팬 속도 제어 — 1% 단계 제어로 소음 최소화

    기존: 10% 단계 계단식 제어 → 소음 불쾌감
    개선: 1% 단계 + 이동 평균으로 부드러운 램핑
    """

    def __init__(self, min_pwm=20, max_pwm=100, ramp_rate=2.0,
                 smoothing_window=5):
        self.min_pwm = min_pwm
        self.max_pwm = max_pwm
        self.ramp_rate = ramp_rate  # %/s
        self.smoothing_window = smoothing_window
        self._current_pwm = 0
        self._target_pwm = 0
        self._pwm_history = []
        self._last_update = time.time()

    def update(self, temperature):
        """온도 기반 팬 속도 업데이트"""
        # 온도 → 목표 PWM 매핑
        if temperature < 45:
            self._target_pwm = self.min_pwm
        elif temperature < 55:
            self._target_pwm = self.min_pwm + (temperature - 45) / 10 * 20
        elif temperature < 65:
            self._target_pwm = 40 + (temperature - 55) / 10 * 30
        elif temperature < 75:
            self._target_pwm = 70 + (temperature - 65) / 10 * 20
        else:
            self._target_pwm = self.max_pwm

        # 램핑 (급격한 변화 방지)
        now = time.time()
        dt = now - self._last_update
        self._last_update = now

        max_change = self.ramp_rate * dt * 100  # % change
        diff = self._target_pwm - self._current_pwm
        if abs(diff) > max_change:
            self._current_pwm += np.sign(diff) * max_change
        else:
            self._current_pwm = self._target_pwm

        # 스무딩
        self._pwm_history.append(self._current_pwm)
        if len(self._pwm_history) > self.smoothing_window:
            self._pwm_history = self._pwm_history[-self.smoothing_window:]
        smoothed = np.mean(self._pwm_history)

        return int(np.clip(smoothed, self.min_pwm, self.max_pwm))

    @property
    def current_pwm(self):
        return self._current_pwm


class ThermalSafetyManager:
    """통합 온도 안전 관리자 V8.5 — 다중 레벨 보호

    기존 문제:
    1. shutdown -h +5 → 5분 후 종료 (5초가 아님!)
    2. 코어별 온도 모니터링 없음
    3. 팬 제어가 계단식

    개선:
    1. shutdown -P now → 즉시 전원 종료
    2. 핵심 온도 임계값 3단계 (85°C 경고, 90°C 쓰로틀, 95°C 즉시 종료)
    3. 부드러운 팬 램핑

    V8.5 추가:
    - 열적 피로, 먼지 누적 등 서브 감지기 결과 반영
    """

    CRITICAL_TEMP = 95.0  # 즉시 종료
    EMERGENCY_TEMP = 90.0  # 강제 쓰로틀
    WARNING_TEMP = 85.0   # 경고 + 최대 팬
    THROTTLE_TEMP = 75.0  # 클럭 저감

    def __init__(self, fan_controller=None):
        self.fan_controller = fan_controller or SmoothFanController()
        self._safety_callbacks = []
        self._shutdown_initiated = False

    def check_thermal_safety(self, cpu_temp, gpu_temp, zone_temps=None):
        """온도 안전 검사 — V8.5: 멀티존 지원"""
        all_temps = [cpu_temp, gpu_temp]
        if zone_temps:
            all_temps.extend(zone_temps.values())
        max_temp = max(all_temps) if all_temps else 0.0

        if max_temp >= self.CRITICAL_TEMP and not self._shutdown_initiated:
            self._shutdown_initiated = True
            logging.critical(f"[ThermalSafety V8.5] {max_temp}°C — 즉시 종료!")
            self._emergency_shutdown()
            return 'shutdown'

        elif max_temp >= self.EMERGENCY_TEMP:
            logging.error(f"[ThermalSafety V8.5] {max_temp}°C — 강제 쓰로틀")
            self._force_throttle()
            return 'throttle'

        elif max_temp >= self.WARNING_TEMP:
            logging.warning(f"[ThermalSafety V8.5] {max_temp}°C — 경고")
            for cb in self._safety_callbacks:
                try:
                    cb('warning', max_temp)
                except:
                    pass
            return 'warning'

        return 'normal'

    def _emergency_shutdown(self):
        """긴급 종료 — 수정된 셧다운 명령어"""
        try:
            # 5분이 아닌 즉시 종료!
            subprocess.run(['sudo', 'shutdown', '-P', 'now'],
                         capture_output=True, timeout=5)
        except Exception as e:
            logging.critical(f"[ThermalSafety V8.5] 셧다운 실패: {e}")
            # 강제 전원 차단 시도
            try:
                subprocess.run(['sudo', 'poweroff', '-f'],
                             capture_output=True, timeout=3)
            except:
                pass

    def _force_throttle(self):
        """강제 클럭 저감"""
        try:
            subprocess.run(['sudo', 'nvpmodel', '-m', '0'],  # 최저 전력 모드
                         capture_output=True, timeout=5)
        except Exception as e:
            logging.error(f"[ThermalSafety V8.5] 쓰로틀 실패: {e}")

    def add_safety_callback(self, callback):
        self._safety_callbacks.append(callback)
