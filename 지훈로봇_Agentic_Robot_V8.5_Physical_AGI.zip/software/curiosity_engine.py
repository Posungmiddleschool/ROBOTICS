"""
curiosity_engine.py — Curiosity-Driven Exploration for Jihun Robot V8.5 Physical AGI

Provides three core curiosity / intrinsic-motivation modules:

1. CuriosityEngine  — High-level orchestration: generates exploration targets,
                       tracks explored vs. unexplored state-action spaces,
                       safety-aware exploration scheduling.

2. RNDEngine        — Random Network Distillation (Burda et al. 2018):
                       Predictor network learns to match a *fixed* random target
                       network.  Prediction error = novelty = intrinsic reward.

3. ICMEngine        — Intrinsic Curiosity Module (Pathak et al. 2017):
                       Forward model predicts next-state features; inverse model
                       recovers action from state-feature pairs.  Forward
                       prediction error = intrinsic reward.  Feature encoder
                       learns to ignore irrelevant aspects of the environment.

All neural networks are real PyTorch (torch / torch.nn) implementations.
Thread-safe via threading.Lock where shared state is mutated.
"""

from __future__ import annotations

import hashlib
import logging
import math
import random
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Deque, Dict, List, Optional, Set, Tuple

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset
    _HAS_TORCH = True
except ImportError:
    _HAS_TORCH = False
    logging.warning("PyTorch not available — curiosity_engine will use fallback stubs")

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
#  Enums & Data Classes
# ---------------------------------------------------------------------------

class ExplorationType(Enum):
    """Kinds of physical exploration a robot can perform."""
    TOUCH = auto()
    PUSH = auto()
    LIFT = auto()
    MANIPULATE = auto()
    OBSERVE = auto()
    NAVIGATE = auto()
    INTERACT = auto()
    COMPOSITE = auto()


class CuriosityLevel(Enum):
    """How curious the engine is about a particular target."""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class SafetyRating(Enum):
    """Safety classification for exploration targets."""
    SAFE = auto()
    CAUTION = auto()
    DANGEROUS = auto()
    FORBIDDEN = auto()


@dataclass
class ExplorationTarget:
    """A single exploration target the robot may pursue."""
    target_id: str
    exploration_type: ExplorationType
    curiosity_level: CuriosityLevel
    safety_rating: SafetyRating = SafetyRating.SAFE
    description: str = ""
    state_vector: Optional[np.ndarray] = None
    action_vector: Optional[np.ndarray] = None
    expected_information_gain: float = 0.0
    visit_count: int = 0
    last_visited: float = 0.0
    intrinsic_reward: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def novelty(self) -> float:
        """Inverse of visit frequency — rarely-visited targets are more novel."""
        if self.visit_count == 0:
            return 1.0
        return 1.0 / (1.0 + self.visit_count)


@dataclass
class StateActionKey:
    """Hashable representation of a (state, action) pair for visit tracking."""
    state_hash: str
    action_hash: str

    def __hash__(self) -> int:
        return hash((self.state_hash, self.action_hash))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, StateActionKey):
            return NotImplemented
        return self.state_hash == other.state_hash and self.action_hash == other.action_hash


@dataclass
class CuriosityStats:
    """Running statistics for the curiosity engine."""
    total_targets_generated: int = 0
    total_targets_explored: int = 0
    total_exploration_cycles: int = 0
    avg_intrinsic_reward: float = 0.0
    exploration_coverage: float = 0.0
    safety_violations: int = 0
    time_spent_exploring: float = 0.0


# ---------------------------------------------------------------------------
#  Utility helpers
# ---------------------------------------------------------------------------

def _hash_vector(vec: Optional[np.ndarray], bins: int = 32) -> str:
    """Discretise a continuous vector into *bins* and return a hex hash."""
    if vec is None:
        return "none"
    discretised = np.digitize(vec, bins=np.linspace(-1.0, 1.0, bins))
    h = hashlib.md5(discretised.tobytes()).hexdigest()
    return h


def _safe_sigmoid(x: float) -> float:
    """Numerically stable sigmoid."""
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    return math.exp(x) / (1.0 + math.exp(x))


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


# ---------------------------------------------------------------------------
#  RNDEngine — Random Network Distillation
# ---------------------------------------------------------------------------

if _HAS_TORCH:

    class _RNDTargetNetwork(nn.Module):
        """Fixed random target network — never updated."""

        def __init__(self, input_dim: int, hidden_dim: int, output_dim: int):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Linear(hidden_dim, output_dim),
            )
            # Orthogonal initialisation (standard for RND)
            for layer in self.net:
                if isinstance(layer, nn.Linear):
                    nn.init.orthogonal_(layer.weight, gain=nn.init.calculate_gain("leaky_relu"))
                    nn.init.zeros_(layer.bias)
            # Freeze all parameters — this network is *never* trained
            for p in self.parameters():
                p.requires_grad = False

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            return self.net(x)

    class _RNDPredictorNetwork(nn.Module):
        """Predictor network — learns to match the target network's output."""

        def __init__(self, input_dim: int, hidden_dim: int, output_dim: int):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Linear(hidden_dim, output_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for layer in self.net:
                if isinstance(layer, nn.Linear):
                    nn.init.orthogonal_(layer.weight, gain=nn.init.calculate_gain("leaky_relu"))
                    nn.init.zeros_(layer.bias)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            return self.net(x)

else:
    # Stub classes so type annotations still resolve without torch
    class _RNDTargetNetwork:  # type: ignore[no-redef]
        pass

    class _RNDPredictorNetwork:  # type: ignore[no-redef]
        pass


class RNDEngine:
    """Random Network Distillation for intrinsic motivation.

    The core idea (Burda et al., 2018):
      • A *fixed* randomly-initialised neural network (target) maps states to
        an embedding space.
      • A *trainable* predictor network tries to match the target's output.
      • The prediction error is used as an intrinsic reward signal: states that
        are hard to predict (i.e. novel) yield high reward; familiar states
        yield low reward.

    Thread-safe: all mutations go through ``self._lock``.
    """

    # Default hyper-parameters
    DEFAULT_INPUT_DIM: int = 62       # matches robot state vector size
    DEFAULT_HIDDEN_DIM: int = 256
    DEFAULT_OUTPUT_DIM: int = 128
    DEFAULT_LR: float = 1e-4
    DEFAULT_BUFFER_SIZE: int = 10000
    DEFAULT_BATCH_SIZE: int = 64
    DEFAULT_UPDATE_FREQ: int = 4      # update every N calls to compute_reward
    DEFAULT_REWARD_NORM_CLIP: float = 5.0
    DEFAULT_DISCOUNT: float = 0.99

    def __init__(
        self,
        input_dim: int = DEFAULT_INPUT_DIM,
        hidden_dim: int = DEFAULT_HIDDEN_DIM,
        output_dim: int = DEFAULT_OUTPUT_DIM,
        lr: float = DEFAULT_LR,
        buffer_size: int = DEFAULT_BUFFER_SIZE,
        batch_size: int = DEFAULT_BATCH_SIZE,
        update_freq: int = DEFAULT_UPDATE_FREQ,
        device: Optional[str] = None,
    ):
        self._lock = threading.Lock()
        self._input_dim = input_dim
        self._hidden_dim = hidden_dim
        self._output_dim = output_dim
        self._lr = lr
        self._buffer_size = buffer_size
        self._batch_size = batch_size
        self._update_freq = update_freq
        self._call_count: int = 0

        # Running statistics for reward normalisation
        self._reward_mean: float = 0.0
        self._reward_var: float = 1.0
        self._reward_count: int = 0

        # Experience buffer (state tensors)
        self._buffer: Deque[torch.Tensor] = deque(maxlen=buffer_size)

        # Device selection
        if _HAS_TORCH:
            self._device = torch.device(
                device or ("cuda" if torch.cuda.is_available() else "cpu")
            )
        else:
            self._device = None

        # Networks (created lazily in initialise)
        self._target_net: Optional[_RNDTargetNetwork] = None
        self._predictor_net: Optional[_RNDPredictorNetwork] = None
        self._optimizer: Optional[optim.Optimizer] = None
        self._initialised: bool = False

    # ------------------------------------------------------------------
    #  Life-cycle
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """Build and initialise networks."""
        if not _HAS_TORCH:
            logger.warning("RNDEngine.initialize: PyTorch not available, using stub mode")
            self._initialised = True
            return

        self._target_net = _RNDTargetNetwork(
            self._input_dim, self._hidden_dim, self._output_dim
        ).to(self._device)
        self._target_net.eval()  # never in training mode

        self._predictor_net = _RNDPredictorNetwork(
            self._input_dim, self._hidden_dim, self._output_dim
        ).to(self._device)
        self._predictor_net.train()

        self._optimizer = optim.Adam(
            self._predictor_net.parameters(), lr=self._lr, eps=1e-5
        )

        self._initialised = True
        logger.info(
            "RNDEngine initialised — input=%d hidden=%d output=%d device=%s",
            self._input_dim, self._hidden_dim, self._output_dim, self._device,
        )

    # ------------------------------------------------------------------
    #  Core API
    # ------------------------------------------------------------------

    def compute_intrinsic_reward(self, state: np.ndarray) -> float:
        """Compute intrinsic (novelty) reward for *state*.

        This is the primary method called by main.py's exploration loop.
        Internally it also triggers periodic online learning.

        Parameters
        ----------
        state : np.ndarray
            State observation vector (shape: ``(input_dim,)`` or ``(1, input_dim)``).

        Returns
        -------
        float
            Normalised intrinsic reward — higher means more novel.
        """
        if not self._initialised:
            self.initialize()

        if not _HAS_TORCH or self._predictor_net is None or self._target_net is None:
            # Fallback: hash-based novelty estimate
            return self._fallback_reward(state)

        with self._lock:
            self._call_count += 1
            state_tensor = self._to_tensor(state)

            # --- prediction error ---
            with torch.no_grad():
                target_out = self._target_net(state_tensor)
            pred_out = self._predictor_net(state_tensor)
            raw_error = F.mse_loss(pred_out, target_out, reduction="mean").item()

            # Normalise using running statistics
            normalised = self._normalise_reward(raw_error)

            # Store in buffer for later training
            self._buffer.append(state_tensor.detach().cpu())

            # Periodic online update
            if self._call_count % self._update_freq == 0:
                self._train_step()

            return float(_clamp(normalised, 0.0, self.DEFAULT_REWARD_NORM_CLIP))

    def update(self, states: np.ndarray) -> Dict[str, float]:
        """Explicitly train the predictor on a batch of *states*.

        Parameters
        ----------
        states : np.ndarray
            Array of shape ``(N, input_dim)``.

        Returns
        -------
        dict
            ``{"loss": float, "mean_error": float}``
        """
        if not _HAS_TORCH or self._predictor_net is None or self._target_net is None:
            return {"loss": 0.0, "mean_error": 0.0}

        with self._lock:
            return self._train_on_states(states)

    def get_novelty_scores(self, states: np.ndarray) -> np.ndarray:
        """Return per-state novelty (prediction error) without side-effects.

        Parameters
        ----------
        states : np.ndarray
            ``(N, input_dim)`` batch of states.

        Returns
        -------
        np.ndarray
            ``(N,)`` novelty scores.
        """
        if not _HAS_TORCH or self._predictor_net is None or self._target_net is None:
            return np.zeros(len(states), dtype=np.float32)

        with torch.no_grad():
            t = torch.as_tensor(states, dtype=torch.float32, device=self._device)
            target_out = self._target_net(t)
            pred_out = self._predictor_net(t)
            errors = F.mse_loss(pred_out, target_out, reduction="none").mean(dim=-1)
            return errors.cpu().numpy()

    # ------------------------------------------------------------------
    #  Internal helpers
    # ------------------------------------------------------------------

    def _to_tensor(self, state: np.ndarray) -> torch.Tensor:
        arr = np.asarray(state, dtype=np.float32).ravel()
        if len(arr) < self._input_dim:
            arr = np.pad(arr, (0, self._input_dim - len(arr)))
        elif len(arr) > self._input_dim:
            arr = arr[: self._input_dim]
        return torch.as_tensor(arr, dtype=torch.float32, device=self._device).unsqueeze(0)

    def _normalise_reward(self, raw: float) -> float:
        """Online Welford-style normalisation of raw prediction errors."""
        self._reward_count += 1
        delta = raw - self._reward_mean
        self._reward_mean += delta / self._reward_count
        delta2 = raw - self._reward_mean
        self._reward_var += delta * delta2
        variance = self._reward_var / max(self._reward_count, 1)
        std = math.sqrt(max(variance, 1e-8))
        return (raw - self._reward_mean) / std

    def _train_step(self) -> None:
        """One gradient step on a mini-batch from the replay buffer."""
        if len(self._buffer) < self._batch_size:
            return
        if self._optimizer is None or self._target_net is None or self._predictor_net is None:
            return

        # Sample from buffer
        indices = random.sample(range(len(self._buffer)), self._batch_size)
        batch = torch.stack([self._buffer[i] for i in indices])
        batch = batch.to(self._device)

        with torch.no_grad():
            target_out = self._target_net(batch)

        pred_out = self._predictor_net(batch)
        loss = F.mse_loss(pred_out, target_out, reduction="mean")

        self._optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self._predictor_net.parameters(), max_norm=0.5)
        self._optimizer.step()

    def _train_on_states(self, states: np.ndarray) -> Dict[str, float]:
        """Train predictor on an explicit batch of states."""
        if self._optimizer is None or self._target_net is None or self._predictor_net is None:
            return {"loss": 0.0, "mean_error": 0.0}

        t = torch.as_tensor(states, dtype=torch.float32, device=self._device)
        with torch.no_grad():
            target_out = self._target_net(t)
        pred_out = self._predictor_net(t)
        loss = F.mse_loss(pred_out, target_out, reduction="mean")

        self._optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self._predictor_net.parameters(), max_norm=0.5)
        self._optimizer.step()

        mean_error = F.mse_loss(pred_out.detach(), target_out, reduction="none").mean().item()
        return {"loss": loss.item(), "mean_error": mean_error}

    def _fallback_reward(self, state: np.ndarray) -> float:
        """Simple hash-frequency based novelty when PyTorch is unavailable."""
        key = _hash_vector(state)
        count = getattr(self, "_fallback_counts", {}).get(key, 0)
        if not hasattr(self, "_fallback_counts"):
            self._fallback_counts: Dict[str, int] = {}
        self._fallback_counts[key] = count + 1
        return 1.0 / (1.0 + count)

    # ------------------------------------------------------------------
    #  Serialisation
    # ------------------------------------------------------------------

    def state_dict(self) -> Dict[str, Any]:
        """Return serialisable state."""
        with self._lock:
            return {
                "predictor_state": (
                    self._predictor_net.state_dict()
                    if self._predictor_net is not None
                    else None
                ),
                "reward_mean": self._reward_mean,
                "reward_var": self._reward_var,
                "reward_count": self._reward_count,
                "call_count": self._call_count,
            }

    def load_state_dict(self, sd: Dict[str, Any]) -> None:
        """Restore from a saved state dict."""
        with self._lock:
            if sd.get("predictor_state") and self._predictor_net is not None and _HAS_TORCH:
                self._predictor_net.load_state_dict(sd["predictor_state"])
            self._reward_mean = sd.get("reward_mean", 0.0)
            self._reward_var = sd.get("reward_var", 1.0)
            self._reward_count = sd.get("reward_count", 0)
            self._call_count = sd.get("call_count", 0)


# ---------------------------------------------------------------------------
#  ICMEngine — Intrinsic Curiosity Module
# ---------------------------------------------------------------------------

if _HAS_TORCH:

    class _ICMFeatureEncoder(nn.Module):
        """Learned feature encoder φ(s) that maps raw state to compact features.

        The encoder is trained jointly with the forward and inverse models so
        that it learns to ignore aspects of the environment that the agent
        cannot influence (e.g. a TV playing in the background).
        """

        def __init__(self, input_dim: int, feature_dim: int):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(input_dim, 256),
                nn.ELU(inplace=True),
                nn.Linear(256, 256),
                nn.ELU(inplace=True),
                nn.Linear(256, feature_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for layer in self.net:
                if isinstance(layer, nn.Linear):
                    nn.init.orthogonal_(layer.weight, gain=nn.init.calculate_gain("linear"))
                    nn.init.zeros_(layer.bias)

        def forward(self, state: torch.Tensor) -> torch.Tensor:
            return self.net(state)

    class _ICMForwardModel(nn.Module):
        """Forward model: f(φ(s_t), a_t) → φ(s_{t+1}) ̂.

        Predicts next-state features from current features and action.
        Training error on this model is the intrinsic reward.
        """

        def __init__(self, feature_dim: int, action_dim: int, hidden_dim: int = 256):
            super().__init__()
            input_size = feature_dim + action_dim
            self.net = nn.Sequential(
                nn.Linear(input_size, hidden_dim),
                nn.ELU(inplace=True),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ELU(inplace=True),
                nn.Linear(hidden_dim, feature_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for layer in self.net:
                if isinstance(layer, nn.Linear):
                    nn.init.orthogonal_(layer.weight, gain=nn.init.calculate_gain("linear"))
                    nn.init.zeros_(layer.bias)

        def forward(self, state_features: torch.Tensor, action: torch.Tensor) -> torch.Tensor:
            x = torch.cat([state_features, action], dim=-1)
            return self.net(x)

    class _ICMInverseModel(nn.Module):
        """Inverse model: g(φ(s_t), φ(s_{t+1})) → â_t.

        Predicts the action taken from two consecutive feature vectors.
        This provides a training signal for the feature encoder so it
        discards information that the agent's actions cannot affect.
        """

        def __init__(self, feature_dim: int, action_dim: int, hidden_dim: int = 256):
            super().__init__()
            input_size = feature_dim * 2
            self.net = nn.Sequential(
                nn.Linear(input_size, hidden_dim),
                nn.ELU(inplace=True),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ELU(inplace=True),
                nn.Linear(hidden_dim, action_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for layer in self.net:
                if isinstance(layer, nn.Linear):
                    nn.init.orthogonal_(layer.weight, gain=nn.init.calculate_gain("linear"))
                    nn.init.zeros_(layer.bias)

        def forward(self, state_features: torch.Tensor, next_state_features: torch.Tensor) -> torch.Tensor:
            x = torch.cat([state_features, next_state_features], dim=-1)
            return self.net(x)

else:

    class _ICMFeatureEncoder:  # type: ignore[no-redef]
        pass

    class _ICMForwardModel:  # type: ignore[no-redef]
        pass

    class _ICMInverseModel:  # type: ignore[no-redef]
        pass


class ICMEngine:
    """Intrinsic Curiosity Module (Pathak et al., 2017).

    Three components:
      1. **Feature encoder** φ(s) — compresses raw observations into a feature
         space that discards "boring" (uncontrollable) aspects.
      2. **Forward model** — predicts φ(s') from (φ(s), a).  Its prediction
         error is the *intrinsic reward*.
      3. **Inverse model** — predicts action a from (φ(s), φ(s')).  It forces
         the encoder to retain only action-relevant features.

    Loss = λ_forward * L_forward + (1 − λ_forward) * L_inverse + β * ‖φ‖²

    Thread-safe via ``self._lock``.
    """

    DEFAULT_STATE_DIM: int = 62
    DEFAULT_ACTION_DIM: int = 12
    DEFAULT_FEATURE_DIM: int = 64
    DEFAULT_HIDDEN_DIM: int = 256
    DEFAULT_LR: float = 1e-4
    DEFAULT_FORWARD_WEIGHT: float = 0.2   # λ_forward — weight on forward loss
    DEFAULT_INVERSE_WEIGHT: float = 0.8   # (1 − λ_forward)
    DEFAULT_FEATURE_WEIGHT: float = 1e-3  # β — L2 regularisation on features
    DEFAULT_BUFFER_SIZE: int = 10000
    DEFAULT_BATCH_SIZE: int = 64
    DEFAULT_UPDATE_FREQ: int = 4
    DEFAULT_REWARD_SCALE: float = 1.0

    def __init__(
        self,
        state_dim: int = DEFAULT_STATE_DIM,
        action_dim: int = DEFAULT_ACTION_DIM,
        feature_dim: int = DEFAULT_FEATURE_DIM,
        hidden_dim: int = DEFAULT_HIDDEN_DIM,
        lr: float = DEFAULT_LR,
        forward_weight: float = DEFAULT_FORWARD_WEIGHT,
        inverse_weight: float = DEFAULT_INVERSE_WEIGHT,
        feature_weight: float = DEFAULT_FEATURE_WEIGHT,
        buffer_size: int = DEFAULT_BUFFER_SIZE,
        batch_size: int = DEFAULT_BATCH_SIZE,
        update_freq: int = DEFAULT_UPDATE_FREQ,
        reward_scale: float = DEFAULT_REWARD_SCALE,
        device: Optional[str] = None,
    ):
        self._lock = threading.Lock()
        self._state_dim = state_dim
        self._action_dim = action_dim
        self._feature_dim = feature_dim
        self._hidden_dim = hidden_dim
        self._lr = lr
        self._forward_weight = forward_weight
        self._inverse_weight = inverse_weight
        self._feature_weight = feature_weight
        self._buffer_size = buffer_size
        self._batch_size = batch_size
        self._update_freq = update_freq
        self._reward_scale = reward_scale
        self._call_count: int = 0

        # Reward normalisation stats
        self._reward_mean: float = 0.0
        self._reward_var: float = 1.0
        self._reward_count: int = 0

        # Experience buffer: (state, action, next_state) tuples
        self._buffer_s: Deque[torch.Tensor] = deque(maxlen=buffer_size)
        self._buffer_a: Deque[torch.Tensor] = deque(maxlen=buffer_size)
        self._buffer_ns: Deque[torch.Tensor] = deque(maxlen=buffer_size)

        # Device
        if _HAS_TORCH:
            self._device = torch.device(
                device or ("cuda" if torch.cuda.is_available() else "cpu")
            )
        else:
            self._device = None

        # Networks (built in initialise)
        self._encoder: Optional[_ICMFeatureEncoder] = None
        self._forward_model: Optional[_ICMForwardModel] = None
        self._inverse_model: Optional[_ICMInverseModel] = None
        self._optimizer: Optional[optim.Optimizer] = None
        self._initialised: bool = False

    # ------------------------------------------------------------------
    #  Life-cycle
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """Build networks and optimizer."""
        if not _HAS_TORCH:
            logger.warning("ICMEngine.initialize: PyTorch not available, using stub mode")
            self._initialised = True
            return

        self._encoder = _ICMFeatureEncoder(self._state_dim, self._feature_dim).to(self._device)
        self._forward_model = _ICMForwardModel(
            self._feature_dim, self._action_dim, self._hidden_dim
        ).to(self._device)
        self._inverse_model = _ICMInverseModel(
            self._feature_dim, self._action_dim, self._hidden_dim
        ).to(self._device)

        all_params = (
            list(self._encoder.parameters())
            + list(self._forward_model.parameters())
            + list(self._inverse_model.parameters())
        )
        self._optimizer = optim.Adam(all_params, lr=self._lr, eps=1e-5)

        self._encoder.train()
        self._forward_model.train()
        self._inverse_model.train()

        self._initialised = True
        logger.info(
            "ICMEngine initialised — state=%d action=%d feature=%d device=%s",
            self._state_dim, self._action_dim, self._feature_dim, self._device,
        )

    # ------------------------------------------------------------------
    #  Core API
    # ------------------------------------------------------------------

    def compute_intrinsic_reward(
        self,
        state: np.ndarray,
        action: np.ndarray,
        next_state: np.ndarray,
    ) -> float:
        """Compute ICM intrinsic reward for a single transition.

        The intrinsic reward is the forward-model prediction error in
        feature space:

            r^i = η * ½ ‖φ(s') − f(φ(s), a)‖²

        Parameters
        ----------
        state : np.ndarray
            Current state vector ``(state_dim,)``.
        action : np.ndarray
            Action vector ``(action_dim,)``.
        next_state : np.ndarray
            Next state vector ``(state_dim,)``.

        Returns
        -------
        float
            Intrinsic reward (non-negative).
        """
        if not self._initialised:
            self.initialize()

        if not _HAS_TORCH or self._encoder is None or self._forward_model is None:
            return self._fallback_reward(state, next_state)

        with self._lock:
            self._call_count += 1

            s_t = self._to_tensor(state, self._state_dim)
            a_t = self._to_tensor(action, self._action_dim)
            ns_t = self._to_tensor(next_state, self._state_dim)

            # Store transition in buffer
            self._buffer_s.append(s_t.detach().cpu())
            self._buffer_a.append(a_t.detach().cpu())
            self._buffer_ns.append(ns_t.detach().cpu())

            # Compute intrinsic reward
            with torch.no_grad():
                phi_s = self._encoder(s_t)
                phi_ns = self._encoder(ns_t)
                pred_phi_ns = self._forward_model(phi_s, a_t)
                raw_reward = F.mse_loss(pred_phi_ns, phi_ns, reduction="mean").item()

            # Normalise
            normalised = self._normalise_reward(raw_reward)

            # Periodic training
            if self._call_count % self._update_freq == 0:
                self._train_step()

            return float(_clamp(normalised * self._reward_scale, 0.0, 10.0))

    def update(
        self,
        states: np.ndarray,
        actions: np.ndarray,
        next_states: np.ndarray,
    ) -> Dict[str, float]:
        """Explicitly train on a batch of transitions.

        Parameters
        ----------
        states, actions, next_states : np.ndarray
            Arrays of shape ``(N, dim)``.

        Returns
        -------
        dict
            ``{"total_loss", "forward_loss", "inverse_loss", "feature_reg"}``
        """
        if not _HAS_TORCH or self._encoder is None or self._forward_model is None or self._inverse_model is None:
            return {"total_loss": 0.0, "forward_loss": 0.0, "inverse_loss": 0.0, "feature_reg": 0.0}

        with self._lock:
            return self._train_on_batch(states, actions, next_states)

    def encode_features(self, state: np.ndarray) -> np.ndarray:
        """Return the feature encoding φ(s) for a given state.

        Parameters
        ----------
        state : np.ndarray
            ``(state_dim,)`` state vector.

        Returns
        -------
        np.ndarray
            ``(feature_dim,)`` feature vector.
        """
        if not _HAS_TORCH or self._encoder is None:
            return np.zeros(self._feature_dim, dtype=np.float32)

        with torch.no_grad():
            s = self._to_tensor(state, self._state_dim)
            features = self._encoder(s)
            return features.cpu().numpy().ravel()

    def predict_next_features(
        self, state: np.ndarray, action: np.ndarray
    ) -> np.ndarray:
        """Forward-model prediction: φ̂(s') = f(φ(s), a).

        Returns
        -------
        np.ndarray
            Predicted next-state features ``(feature_dim,)``.
        """
        if not _HAS_TORCH or self._encoder is None or self._forward_model is None:
            return np.zeros(self._feature_dim, dtype=np.float32)

        with torch.no_grad():
            s = self._to_tensor(state, self._state_dim)
            a = self._to_tensor(action, self._action_dim)
            phi_s = self._encoder(s)
            pred = self._forward_model(phi_s, a)
            return pred.cpu().numpy().ravel()

    def predict_action(
        self, state: np.ndarray, next_state: np.ndarray
    ) -> np.ndarray:
        """Inverse-model prediction: â = g(φ(s), φ(s')).

        Returns
        -------
        np.ndarray
            Predicted action ``(action_dim,)``.
        """
        if not _HAS_TORCH or self._encoder is None or self._inverse_model is None:
            return np.zeros(self._action_dim, dtype=np.float32)

        with torch.no_grad():
            s = self._to_tensor(state, self._state_dim)
            ns = self._to_tensor(next_state, self._state_dim)
            phi_s = self._encoder(s)
            phi_ns = self._encoder(ns)
            pred_a = self._inverse_model(phi_s, phi_ns)
            return pred_a.cpu().numpy().ravel()

    # ------------------------------------------------------------------
    #  Internal helpers
    # ------------------------------------------------------------------

    def _to_tensor(self, arr: np.ndarray, dim: int) -> torch.Tensor:
        a = np.asarray(arr, dtype=np.float32).ravel()
        if len(a) < dim:
            a = np.pad(a, (0, dim - len(a)))
        elif len(a) > dim:
            a = a[:dim]
        return torch.as_tensor(a, dtype=torch.float32, device=self._device).unsqueeze(0)

    def _normalise_reward(self, raw: float) -> float:
        self._reward_count += 1
        delta = raw - self._reward_mean
        self._reward_mean += delta / self._reward_count
        delta2 = raw - self._reward_mean
        self._reward_var += delta * delta2
        variance = self._reward_var / max(self._reward_count, 1)
        std = math.sqrt(max(variance, 1e-8))
        return (raw - self._reward_mean) / std

    def _train_step(self) -> None:
        """One gradient step sampled from the replay buffer."""
        if (
            len(self._buffer_s) < self._batch_size
            or self._optimizer is None
            or self._encoder is None
            or self._forward_model is None
            or self._inverse_model is None
        ):
            return

        indices = random.sample(range(len(self._buffer_s)), self._batch_size)
        batch_s = torch.stack([self._buffer_s[i] for i in indices]).to(self._device)
        batch_a = torch.stack([self._buffer_a[i] for i in indices]).to(self._device)
        batch_ns = torch.stack([self._buffer_ns[i] for i in indices]).to(self._device)

        self._apply_gradient_step(batch_s, batch_a, batch_ns)

    def _train_on_batch(
        self,
        states: np.ndarray,
        actions: np.ndarray,
        next_states: np.ndarray,
    ) -> Dict[str, float]:
        """Train on an explicit batch."""
        if self._optimizer is None or self._encoder is None or self._forward_model is None or self._inverse_model is None:
            return {"total_loss": 0.0, "forward_loss": 0.0, "inverse_loss": 0.0, "feature_reg": 0.0}

        batch_s = torch.as_tensor(states, dtype=torch.float32, device=self._device)
        batch_a = torch.as_tensor(actions, dtype=torch.float32, device=self._device)
        batch_ns = torch.as_tensor(next_states, dtype=torch.float32, device=self._device)

        return self._apply_gradient_step(batch_s, batch_a, batch_ns)

    def _apply_gradient_step(
        self,
        batch_s: torch.Tensor,
        batch_a: torch.Tensor,
        batch_ns: torch.Tensor,
    ) -> Dict[str, float]:
        """Forward + backward + optimiser step."""
        assert self._encoder is not None
        assert self._forward_model is not None
        assert self._inverse_model is not None
        assert self._optimizer is not None

        # Encode
        phi_s = self._encoder(batch_s)
        phi_ns = self._encoder(batch_ns)

        # Forward loss: ‖f(φ(s), a) − φ(s')‖²
        pred_phi_ns = self._forward_model(phi_s, batch_a)
        forward_loss = F.mse_loss(pred_phi_ns, phi_ns.detach(), reduction="mean")

        # Inverse loss: ‖g(φ(s), φ(s')) − a‖²
        pred_a = self._inverse_model(phi_s.detach(), phi_ns.detach())
        inverse_loss = F.mse_loss(pred_a, batch_a, reduction="mean")

        # Feature regularisation
        feature_reg = (phi_s.pow(2).mean() + phi_ns.pow(2).mean()) * 0.5

        # Total loss
        total_loss = (
            self._forward_weight * forward_loss
            + self._inverse_weight * inverse_loss
            + self._feature_weight * feature_reg
        )

        self._optimizer.zero_grad()
        total_loss.backward()
        nn.utils.clip_grad_norm_(
            list(self._encoder.parameters())
            + list(self._forward_model.parameters())
            + list(self._inverse_model.parameters()),
            max_norm=0.5,
        )
        self._optimizer.step()

        return {
            "total_loss": total_loss.item(),
            "forward_loss": forward_loss.item(),
            "inverse_loss": inverse_loss.item(),
            "feature_reg": feature_reg.item(),
        }

    def _fallback_reward(self, state: np.ndarray, next_state: np.ndarray) -> float:
        """Simple distance-based fallback when PyTorch is unavailable."""
        diff = np.linalg.norm(next_state - state)
        return float(_clamp(diff, 0.0, 5.0))

    # ------------------------------------------------------------------
    #  Serialisation
    # ------------------------------------------------------------------

    def state_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "encoder": self._encoder.state_dict() if self._encoder is not None else None,
                "forward_model": self._forward_model.state_dict() if self._forward_model is not None else None,
                "inverse_model": self._inverse_model.state_dict() if self._inverse_model is not None else None,
                "reward_mean": self._reward_mean,
                "reward_var": self._reward_var,
                "reward_count": self._reward_count,
                "call_count": self._call_count,
            }

    def load_state_dict(self, sd: Dict[str, Any]) -> None:
        with self._lock:
            if sd.get("encoder") and self._encoder is not None and _HAS_TORCH:
                self._encoder.load_state_dict(sd["encoder"])
            if sd.get("forward_model") and self._forward_model is not None and _HAS_TORCH:
                self._forward_model.load_state_dict(sd["forward_model"])
            if sd.get("inverse_model") and self._inverse_model is not None and _HAS_TORCH:
                self._inverse_model.load_state_dict(sd["inverse_model"])
            self._reward_mean = sd.get("reward_mean", 0.0)
            self._reward_var = sd.get("reward_var", 1.0)
            self._reward_count = sd.get("reward_count", 0)
            self._call_count = sd.get("call_count", 0)


# ---------------------------------------------------------------------------
#  CuriosityEngine — High-level Curiosity-Driven Exploration Orchestrator
# ---------------------------------------------------------------------------

class CuriosityEngine:
    """Main curiosity-driven exploration engine for the Jihun Robot V8.5.

    Responsibilities:
      • Maintain a map of explored vs. unexplored state-action spaces.
      • Generate exploration targets with curiosity scores.
      • Integrate with the world model and knowledge graph for informed
        exploration.
      • Safety-aware: never suggest dangerous or forbidden exploration targets.
      • Progressive complexity: start with simple (touch, observe) and advance
        to complex (manipulate, composite) exploration.
      • Thread-safe.

    The engine can be in two modes:
      * **Exploration enabled** — actively generates curiosity targets.
      * **Exploration disabled** — returns empty suggestions (e.g. during
        manual control or emergency stop).

    Interface consumed by ``main.py``:
      - ``CuriosityEngine()`` → constructor
      - ``.initialize()`` → post-init setup
      - ``.connect_world_model(world_model)``
      - ``.connect_knowledge_graph(knowledge_graph)``
      - ``.suggest_exploration() → dict``
      - ``.enable_exploration()``
      - ``.disable_exploration()``
    """

    # Exploration parameters
    MAX_ACTIVE_TARGETS: int = 50
    MAX_VISIT_MEMORY: int = 50000
    CURIOSITY_DECAY: float = 0.995          # per-cycle decay on curiosity scores
    RECENCY_BONUS_DECAY: float = 3600.0     # seconds — half-life for recency bonus
    SAFETY_PENALTY: float = 0.1             # multiplier for CAUTION targets
    DANGER_PENALTY: float = 0.01            # multiplier for DANGEROUS targets
    PROGRESSIVE_ADVANCE_INTERVAL: int = 100  # explored targets before advancing level
    MIN_TARGETS_BEFORE_SUGGEST: int = 1

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._initialised: bool = False
        self._exploration_enabled: bool = False

        # Connected subsystems
        self._world_model: Any = None
        self._knowledge_graph: Any = None

        # Internal RND and ICM engines for self-contained novelty
        self._rnd: Optional[RNDEngine] = None
        self._icm: Optional[ICMEngine] = None

        # State-action visit tracking
        self._visit_counts: Dict[StateActionKey, int] = {}
        self._state_visits: Dict[str, int] = {}          # state_hash → count
        self._action_visits: Dict[str, int] = {}          # action_hash → count
        self._total_visits: int = 0
        self._unique_states: int = 0
        self._unique_actions: int = 0

        # Active exploration targets
        self._active_targets: Dict[str, ExplorationTarget] = {}
        self._completed_targets: Set[str] = set()
        self._failed_targets: Set[str] = set()

        # Curiosity map: quantised state bucket → curiosity value
        self._curiosity_map: Dict[str, float] = {}
        self._curiosity_ema: float = 0.5     # running average curiosity

        # Progressive complexity
        self._current_complexity_tier: int = 0   # 0=simple, 1=medium, 2=complex
        self._targets_explored_this_tier: int = 0
        self._complexity_thresholds: List[int] = [10, 30, 80]  # targets to advance

        # Statistics
        self._stats = CuriosityStats()

        # Safety
        self._forbidden_regions: Set[str] = set()
        self._danger_state_patterns: List[np.ndarray] = []

        # Timing
        self._last_exploration_time: float = 0.0
        self._exploration_start_time: float = 0.0

        # History ring buffers for trend analysis
        self._reward_history: Deque[float] = deque(maxlen=1000)
        self._coverage_history: Deque[float] = deque(maxlen=200)

    # ------------------------------------------------------------------
    #  Life-cycle
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """Initialise internal engines and data structures."""
        with self._lock:
            # Create internal RND/ICM for novelty computation
            try:
                self._rnd = RNDEngine()
                self._rnd.initialize()
                logger.info("CuriosityEngine: internal RNDEngine initialised")
            except Exception as e:
                logger.warning("CuriosityEngine: RNDEngine init failed: %s", e)
                self._rnd = None

            try:
                self._icm = ICMEngine()
                self._icm.initialize()
                logger.info("CuriosityEngine: internal ICMEngine initialised")
            except Exception as e:
                logger.warning("CuriosityEngine: ICMEngine init failed: %s", e)
                self._icm = None

            # Seed initial curiosity map with some regions
            self._seed_curiosity_map()

            self._initialised = True
            self._exploration_start_time = time.time()
            logger.info("CuriosityEngine initialised — ready for exploration")

    def connect_world_model(self, world_model: Any) -> None:
        """Connect to the world model for informed exploration."""
        with self._lock:
            self._world_model = world_model
            logger.info("CuriosityEngine: connected to world model")

    def connect_knowledge_graph(self, knowledge_graph: Any) -> None:
        """Connect to the knowledge graph for informed exploration."""
        with self._lock:
            self._knowledge_graph = knowledge_graph
            logger.info("CuriosityEngine: connected to knowledge graph")

    # ------------------------------------------------------------------
    #  Enable / Disable
    # ------------------------------------------------------------------

    def enable_exploration(self) -> None:
        """Enable autonomous exploration mode."""
        with self._lock:
            self._exploration_enabled = True
            self._last_exploration_time = time.time()
            logger.info("CuriosityEngine: exploration ENABLED")

    def disable_exploration(self) -> None:
        """Disable autonomous exploration mode."""
        with self._lock:
            self._exploration_enabled = False
            logger.info("CuriosityEngine: exploration DISABLED")

    @property
    def is_exploring(self) -> bool:
        with self._lock:
            return self._exploration_enabled

    # ------------------------------------------------------------------
    #  Suggest Exploration (main entry point for main.py)
    # ------------------------------------------------------------------

    def suggest_exploration(self) -> Dict[str, Any]:
        """Suggest an exploration target.

        Called by ``main.py``'s ``_run_curiosity_exploration()`` loop.

        Returns
        -------
        dict
            ``{"has_target": bool, "target": dict}`` where *target* contains
            ``"type"``, ``"description"``, ``"curiosity_level"``,
            ``"intrinsic_reward"``, ``"safety_rating"``, etc.
        """
        with self._lock:
            if not self._exploration_enabled or not self._initialised:
                return {"has_target": False, "target": {}}

            self._stats.total_exploration_cycles += 1

            # Refresh curiosity map (decay old values, integrate RND novelty)
            self._refresh_curiosity_map()

            # Generate candidate targets
            candidates = self._generate_candidates()

            if not candidates:
                return {"has_target": False, "target": {}}

            # Score and rank candidates
            scored = self._score_candidates(candidates)

            # Filter out unsafe targets
            safe_candidates = [c for c in scored if c.safety_rating != SafetyRating.FORBIDDEN]
            if not safe_candidates:
                return {"has_target": False, "target": {}}

            # Pick the best target (highest curiosity score)
            best = safe_candidates[0]

            # Register as active target
            self._active_targets[best.target_id] = best
            self._stats.total_targets_generated += 1

            # Build result dict for main.py
            result = {
                "has_target": True,
                "target": {
                    "id": best.target_id,
                    "type": best.exploration_type.name.lower(),
                    "description": best.description,
                    "curiosity_level": best.curiosity_level.name,
                    "safety_rating": best.safety_rating.name,
                    "expected_information_gain": best.expected_information_gain,
                    "visit_count": best.visit_count,
                    "novelty": best.novelty,
                    "intrinsic_reward": best.intrinsic_reward,
                },
            }

            self._last_exploration_time = time.time()
            return result

    # ------------------------------------------------------------------
    #  Record feedback (called after exploration attempt)
    # ------------------------------------------------------------------

    def record_exploration_result(
        self,
        target_id: str,
        success: bool,
        state: Optional[np.ndarray] = None,
        action: Optional[np.ndarray] = None,
        next_state: Optional[np.ndarray] = None,
        reward: float = 0.0,
    ) -> None:
        """Record the outcome of an exploration attempt.

        Parameters
        ----------
        target_id : str
            ID of the explored target.
        success : bool
            Whether the exploration succeeded.
        state, action, next_state : np.ndarray, optional
            Observed transition for visit counting and ICM training.
        reward : float
            Extrinsic reward received (if any).
        """
        with self._lock:
            # Update visit counts
            if state is not None:
                sh = _hash_vector(state)
                self._state_visits[sh] = self._state_visits.get(sh, 0) + 1
                if self._state_visits[sh] == 1:
                    self._unique_states += 1

            if action is not None:
                ah = _hash_vector(action)
                self._action_visits[ah] = self._action_visits.get(ah, 0) + 1
                if self._action_visits[ah] == 1:
                    self._unique_actions += 1

            if state is not None and action is not None:
                key = StateActionKey(_hash_vector(state), _hash_vector(action))
                self._visit_counts[key] = self._visit_counts.get(key, 0) + 1
                self._total_visits += 1

            # Update target
            if target_id in self._active_targets:
                target = self._active_targets[target_id]
                target.visit_count += 1
                target.last_visited = time.time()
                target.intrinsic_reward = reward

                if success:
                    self._completed_targets.add(target_id)
                    self._stats.total_targets_explored += 1
                    self._targets_explored_this_tier += 1

                    # Update curiosity map — reduce curiosity for explored region
                    bucket = _hash_vector(target.state_vector) if target.state_vector is not None else target_id
                    self._curiosity_map[bucket] = self._curiosity_map.get(bucket, 0.5) * 0.5
                else:
                    self._failed_targets.add(target_id)

                # Remove from active targets (regardless of success)
                del self._active_targets[target_id]

            # Update ICM if transition data available
            if (
                self._icm is not None
                and state is not None
                and action is not None
                and next_state is not None
            ):
                try:
                    self._icm.compute_intrinsic_reward(state, action, next_state)
                except Exception as e:
                    logger.debug("ICM update failed: %s", e)

            # Update RND if state available
            if self._rnd is not None and state is not None:
                try:
                    self._rnd.compute_intrinsic_reward(state)
                except Exception as e:
                    logger.debug("RND update failed: %s", e)

            # Record reward history
            self._reward_history.append(reward)

            # Update statistics
            if self._reward_history:
                self._stats.avg_intrinsic_reward = float(np.mean(list(self._reward_history)))
            self._stats.exploration_coverage = self._compute_coverage()

            # Check progressive complexity advancement
            self._maybe_advance_complexity()

    # ------------------------------------------------------------------
    #  Curiosity Map Management
    # ------------------------------------------------------------------

    def _seed_curiosity_map(self) -> None:
        """Create initial curiosity seeds across the state space."""
        # Seed curiosity for different physical interaction types
        seed_descriptions = {
            "touch_flat_surface": "Touch a flat surface — basic contact exploration",
            "push_light_object": "Push a lightweight object — force interaction",
            "observe_motion": "Observe object motion — visual tracking",
            "lift_small_object": "Lift a small object — grasp + lift coordination",
            "navigate_new_area": "Navigate to an unexplored area — spatial exploration",
            "manipulate_tool": "Manipulate a tool — complex interaction",
            "interact_person": "Interact with a person — social exploration",
        }

        for i, (key, desc) in enumerate(seed_descriptions.items()):
            target = ExplorationTarget(
                target_id=f"seed_{i}_{key}",
                exploration_type=list(ExplorationType)[i % len(ExplorationType)],
                curiosity_level=CuriosityLevel.HIGH,
                safety_rating=SafetyRating.SAFE,
                description=desc,
                expected_information_gain=0.8,
            )
            self._curiosity_map[key] = 1.0  # max curiosity for seeds
            self._active_targets[target.target_id] = target

    def _refresh_curiosity_map(self) -> None:
        """Apply decay and integrate novelty signals."""
        now = time.time()

        # Decay all curiosity values
        keys_to_remove: List[str] = []
        for key in self._curiosity_map:
            self._curiosity_map[key] *= self.CURIOSITY_DECAY
            if self._curiosity_map[key] < 0.01:
                keys_to_remove.append(key)

        for key in keys_to_remove:
            del self._curiosity_map[key]

        # Integrate RND novelty for recently visited states
        # (novel states get a curiosity boost)
        if self._rnd is not None:
            try:
                # Check novelty of a random sample of known state regions
                sampled_keys = random.sample(
                    list(self._curiosity_map.keys()),
                    min(10, len(self._curiosity_map)),
                )
                for key in sampled_keys:
                    # Use a synthetic state vector based on the hash
                    rng = np.random.RandomState(hash(key) % (2**31))
                    synthetic_state = rng.randn(62).astype(np.float32) * 0.1
                    novelty = self._rnd.compute_intrinsic_reward(synthetic_state)
                    # Boost curiosity proportional to novelty
                    self._curiosity_map[key] = min(
                        1.0, self._curiosity_map.get(key, 0.0) + novelty * 0.1
                    )
            except Exception:
                pass

        # Add curiosity for completely new regions (information-theoretic)
        self._maybe_add_new_regions()

        # Update EMA
        if self._curiosity_map:
            current_avg = float(np.mean(list(self._curiosity_map.values())))
            self._curiosity_ema = 0.95 * self._curiosity_ema + 0.05 * current_avg

        # Record coverage history
        self._coverage_history.append(self._compute_coverage())

    def _maybe_add_new_regions(self) -> None:
        """Probabilistically add new curiosity regions for unexplored areas."""
        if len(self._curiosity_map) >= self.MAX_ACTIVE_TARGETS:
            return

        # Information gain heuristic: add regions at boundaries of explored space
        exploration_types = self._available_exploration_types()
        for etype in exploration_types:
            region_key = f"region_{etime_name(etype)}_{int(time.time())}"
            if region_key not in self._curiosity_map:
                information_gain = self._estimate_information_gain(etype)
                if information_gain > 0.3:
                    self._curiosity_map[region_key] = information_gain

    def _available_exploration_types(self) -> List[ExplorationType]:
        """Return exploration types available at the current complexity tier."""
        simple = [ExplorationType.OBSERVE, ExplorationType.TOUCH]
        medium = simple + [ExplorationType.PUSH, ExplorationType.NAVIGATE]
        complex_types = medium + [ExplorationType.LIFT, ExplorationType.MANIPULATE, ExplorationType.INTERACT, ExplorationType.COMPOSITE]

        tier = self._current_complexity_tier
        if tier == 0:
            return simple
        elif tier == 1:
            return medium
        else:
            return complex_types

    def _estimate_information_gain(self, etype: ExplorationType) -> float:
        """Heuristic estimate of information gain for an exploration type."""
        # More complex types potentially yield more information
        base_gain = {
            ExplorationType.OBSERVE: 0.4,
            ExplorationType.TOUCH: 0.5,
            ExplorationType.PUSH: 0.6,
            ExplorationType.NAVIGATE: 0.55,
            ExplorationType.LIFT: 0.7,
            ExplorationType.MANIPULATE: 0.75,
            ExplorationType.INTERACT: 0.8,
            ExplorationType.COMPOSITE: 0.9,
        }
        gain = base_gain.get(etype, 0.5)

        # Reduce gain for frequently explored types
        type_count = sum(
            1 for t in self._active_targets.values()
            if t.exploration_type == etype
        )
        gain *= 1.0 / (1.0 + type_count * 0.2)

        return float(_clamp(gain, 0.0, 1.0))

    # ------------------------------------------------------------------
    #  Candidate Generation & Scoring
    # ------------------------------------------------------------------

    def _generate_candidates(self) -> List[ExplorationTarget]:
        """Generate exploration candidates from the curiosity map."""
        candidates: List[ExplorationTarget] = []

        # Convert curiosity map entries into exploration targets
        for key, curiosity_value in self._curiosity_map.items():
            if curiosity_value < 0.05:
                continue

            # Determine exploration type from key
            etype = self._infer_exploration_type(key)
            if etype is None:
                continue

            # Determine safety rating
            safety = self._assess_safety(key, etype)
            if safety == SafetyRating.FORBIDDEN:
                continue

            # Determine curiosity level from value
            clevel = self._curiosity_value_to_level(curiosity_value)

            # Compute visit count for this region
            visit_count = self._state_visits.get(key, 0)

            # Estimate information gain
            info_gain = self._estimate_information_gain(etype)

            # Compute intrinsic reward estimate
            intrinsic = self._estimate_intrinsic_reward(key, curiosity_value)

            target = ExplorationTarget(
                target_id=f"tgt_{key}_{int(time.time()*1000)}",
                exploration_type=etype,
                curiosity_level=clevel,
                safety_rating=safety,
                description=f"Explore {key} ({etype.name.lower()})",
                expected_information_gain=info_gain,
                visit_count=visit_count,
                last_visited=0.0 if visit_count == 0 else time.time() - 60.0,
                intrinsic_reward=intrinsic,
            )
            candidates.append(target)

        # Also generate candidates from world model if connected
        wm_candidates = self._generate_from_world_model()
        candidates.extend(wm_candidates)

        # And from knowledge graph gaps
        kg_candidates = self._generate_from_knowledge_gaps()
        candidates.extend(kg_candidates)

        return candidates

    def _infer_exploration_type(self, key: str) -> Optional[ExplorationType]:
        """Infer the exploration type from a curiosity map key string."""
        key_lower = key.lower()
        type_keywords = {
            ExplorationType.TOUCH: ["touch", "contact", "feel", "surface"],
            ExplorationType.PUSH: ["push", "force", "shove"],
            ExplorationType.LIFT: ["lift", "grasp", "pick", "raise"],
            ExplorationType.MANIPULATE: ["manipulate", "tool", "rotate", "turn"],
            ExplorationType.OBSERVE: ["observe", "watch", "visual", "look"],
            ExplorationType.NAVIGATE: ["navigate", "area", "spatial", "move"],
            ExplorationType.INTERACT: ["interact", "person", "social", "human"],
            ExplorationType.COMPOSITE: ["composite", "complex", "multi"],
        }
        for etype, keywords in type_keywords.items():
            for kw in keywords:
                if kw in key_lower:
                    return etype

        # Default: pick from available types based on tier
        available = self._available_exploration_types()
        return available[hash(key) % len(available)] if available else None

    def _assess_safety(self, key: str, etype: ExplorationType) -> SafetyRating:
        """Assess the safety of exploring a target."""
        # Check forbidden regions
        for forbidden in self._forbidden_regions:
            if forbidden in key:
                return SafetyRating.FORBIDDEN

        # Check for danger patterns
        key_lower = key.lower()
        danger_keywords = ["sharp", "hot", "electrical", "chemical", "high", "edge", "cliff"]
        caution_keywords = ["heavy", "fragile", "wet", "unstable", "moving"]

        for dk in danger_keywords:
            if dk in key_lower:
                return SafetyRating.DANGEROUS
        for ck in caution_keywords:
            if ck in key_lower:
                return SafetyRating.CAUTION

        # More complex exploration types are slightly more risky
        if etype in (ExplorationType.COMPOSITE, ExplorationType.MANIPULATE):
            return SafetyRating.CAUTION

        return SafetyRating.SAFE

    def _curiosity_value_to_level(self, value: float) -> CuriosityLevel:
        """Convert a continuous curiosity value to a discrete level."""
        if value > 0.8:
            return CuriosityLevel.CRITICAL
        elif value > 0.5:
            return CuriosityLevel.HIGH
        elif value > 0.2:
            return CuriosityLevel.MEDIUM
        else:
            return CuriosityLevel.LOW

    def _estimate_intrinsic_reward(self, key: str, curiosity_value: float) -> float:
        """Estimate intrinsic reward for a candidate target."""
        # Base intrinsic reward from curiosity value
        reward = curiosity_value

        # Boost for unvisited regions
        visit_count = self._state_visits.get(key, 0)
        if visit_count == 0:
            reward *= 1.5

        # RND novelty bonus
        if self._rnd is not None:
            try:
                rng = np.random.RandomState(hash(key) % (2**31))
                synthetic_state = rng.randn(62).astype(np.float32) * 0.1
                rnd_reward = self._rnd.compute_intrinsic_reward(synthetic_state)
                reward += rnd_reward * 0.3
            except Exception:
                pass

        return float(_clamp(reward, 0.0, 5.0))

    def _score_candidates(self, candidates: List[ExplorationTarget]) -> List[ExplorationTarget]:
        """Score and sort candidates by combined curiosity score."""
        now = time.time()

        for target in candidates:
            # Base score from curiosity level
            level_scores = {
                CuriosityLevel.LOW: 0.2,
                CuriosityLevel.MEDIUM: 0.5,
                CuriosityLevel.HIGH: 0.8,
                CuriosityLevel.CRITICAL: 1.0,
            }
            score = level_scores.get(target.curiosity_level, 0.3)

            # Novelty bonus (inverse visit count)
            score *= (0.5 + 0.5 * target.novelty)

            # Information gain bonus
            score += target.expected_information_gain * 0.3

            # Intrinsic reward bonus
            score += target.intrinsic_reward * 0.2

            # Recency bonus — targets not visited recently are more interesting
            if target.last_visited > 0:
                time_since = now - target.last_visited
                recency = 1.0 - math.exp(-time_since / self.RECENCY_BONUS_DECAY)
                score += recency * 0.15

            # Safety penalty
            safety_multipliers = {
                SafetyRating.SAFE: 1.0,
                SafetyRating.CAUTION: self.SAFETY_PENALTY,
                SafetyRating.DANGEROUS: self.DANGER_PENALTY,
                SafetyRating.FORBIDDEN: 0.0,
            }
            score *= safety_multipliers.get(target.safety_rating, 1.0)

            # Store the computed score in metadata
            target.metadata["curiosity_score"] = score

        # Sort by score descending
        candidates.sort(key=lambda t: t.metadata.get("curiosity_score", 0.0), reverse=True)
        return candidates

    # ------------------------------------------------------------------
    #  World Model & Knowledge Graph Integration
    # ------------------------------------------------------------------

    def _generate_from_world_model(self) -> List[ExplorationTarget]:
        """Generate exploration targets from the world model's uncertain regions."""
        targets: List[ExplorationTarget] = []
        if self._world_model is None:
            return targets

        try:
            # Query world model for high-uncertainty predictions
            # The world model may expose an uncertainty interface
            if hasattr(self._world_model, "get_uncertain_regions"):
                regions = self._world_model.get_uncertain_regions(top_k=5)
                for region in regions:
                    state_vec = region.get("state", np.zeros(62))
                    uncertainty = region.get("uncertainty", 0.5)
                    key = _hash_vector(state_vec) if isinstance(state_vec, np.ndarray) else str(region)

                    target = ExplorationTarget(
                        target_id=f"wm_{key[:12]}_{int(time.time()*1000)}",
                        exploration_type=ExplorationType.INTERACT,
                        curiosity_level=self._curiosity_value_to_level(uncertainty),
                        safety_rating=SafetyRating.SAFE,
                        description=f"Reduce world model uncertainty (unc={uncertainty:.2f})",
                        state_vector=state_vec if isinstance(state_vec, np.ndarray) else None,
                        expected_information_gain=uncertainty,
                        intrinsic_reward=uncertainty,
                    )
                    targets.append(target)

            elif hasattr(self._world_model, "predict"):
                # Probe the world model with random actions to find
                # high-prediction-error regions
                for _ in range(3):
                    probe_state = np.random.randn(62).astype(np.float32) * 0.1
                    probe_action = np.random.randn(12).astype(np.float32) * 0.05
                    try:
                        prediction = self._world_model.predict(probe_state, probe_action)
                        if isinstance(prediction, dict):
                            uncertainty = prediction.get("uncertainty", 0.5)
                        else:
                            uncertainty = 0.5
                    except Exception:
                        uncertainty = 0.5

                    if uncertainty > 0.3:
                        key = _hash_vector(probe_state)
                        target = ExplorationTarget(
                            target_id=f"wm_probe_{key[:12]}_{int(time.time()*1000)}",
                            exploration_type=ExplorationType.INTERACT,
                            curiosity_level=self._curiosity_value_to_level(uncertainty),
                            safety_rating=SafetyRating.SAFE,
                            description=f"Explore uncertain region (unc={uncertainty:.2f})",
                            state_vector=probe_state,
                            expected_information_gain=uncertainty,
                            intrinsic_reward=uncertainty,
                        )
                        targets.append(target)

        except Exception as e:
            logger.debug("World model exploration generation failed: %s", e)

        return targets

    def _generate_from_knowledge_gaps(self) -> List[ExplorationTarget]:
        """Generate targets from gaps in the knowledge graph."""
        targets: List[ExplorationTarget] = []
        if self._knowledge_graph is None:
            return targets

        try:
            # Look for unexplored nodes or weak connections
            if hasattr(self._knowledge_graph, "get_unexplored_nodes"):
                nodes = self._knowledge_graph.get_unexplored_nodes(limit=5)
                for node in nodes:
                    node_id = str(node.get("id", "unknown"))
                    node_type = str(node.get("type", "object"))
                    importance = float(node.get("importance", 0.5))

                    # Map knowledge graph node types to exploration types
                    kg_type_map = {
                        "object": ExplorationType.TOUCH,
                        "surface": ExplorationType.TOUCH,
                        "container": ExplorationType.LIFT,
                        "tool": ExplorationType.MANIPULATE,
                        "location": ExplorationType.NAVIGATE,
                        "person": ExplorationType.INTERACT,
                        "action": ExplorationType.PUSH,
                    }
                    etype = kg_type_map.get(node_type, ExplorationType.OBSERVE)

                    target = ExplorationTarget(
                        target_id=f"kg_{node_id}_{int(time.time()*1000)}",
                        exploration_type=etype,
                        curiosity_level=self._curiosity_value_to_level(importance),
                        safety_rating=SafetyRating.SAFE,
                        description=f"Explore knowledge gap: {node_id} ({node_type})",
                        expected_information_gain=importance,
                        intrinsic_reward=importance * 0.8,
                    )
                    targets.append(target)

            elif hasattr(self._knowledge_graph, "query"):
                # Fallback: query for unknown properties
                query_result = self._knowledge_graph.query("unexplored")
                if isinstance(query_result, list):
                    for item in query_result[:5]:
                        item_str = str(item)
                        target = ExplorationTarget(
                            target_id=f"kg_gap_{hash(item_str) % 10000}_{int(time.time()*1000)}",
                            exploration_type=ExplorationType.OBSERVE,
                            curiosity_level=CuriosityLevel.MEDIUM,
                            safety_rating=SafetyRating.SAFE,
                            description=f"Fill knowledge gap: {item_str[:50]}",
                            expected_information_gain=0.5,
                            intrinsic_reward=0.4,
                        )
                        targets.append(target)

        except Exception as e:
            logger.debug("Knowledge graph gap generation failed: %s", e)

        return targets

    # ------------------------------------------------------------------
    #  Coverage & Complexity
    # ------------------------------------------------------------------

    def _compute_coverage(self) -> float:
        """Compute exploration coverage as fraction of state-action space visited."""
        if self._total_visits == 0:
            return 0.0
        # Coverage heuristic: ratio of unique (state, action) pairs to total visits
        unique_pairs = len(self._visit_counts)
        # Use logarithmic scaling since the true space is enormous
        coverage = _safe_sigmoid(math.log1p(unique_pairs) / 5.0)
        return float(coverage)

    def _maybe_advance_complexity(self) -> None:
        """Advance to a higher complexity tier if sufficient exploration done."""
        if self._current_complexity_tier >= len(self._complexity_thresholds):
            return  # already at max tier

        threshold = self._complexity_thresholds[self._current_complexity_tier]
        if self._targets_explored_this_tier >= threshold:
            self._current_complexity_tier += 1
            self._targets_explored_this_tier = 0
            logger.info(
                "CuriosityEngine: advanced to complexity tier %d",
                self._current_complexity_tier,
            )

    # ------------------------------------------------------------------
    #  Safety
    # ------------------------------------------------------------------

    def add_forbidden_region(self, region_key: str) -> None:
        """Mark a region as forbidden for exploration."""
        with self._lock:
            self._forbidden_regions.add(region_key)

    def add_danger_pattern(self, state_pattern: np.ndarray) -> None:
        """Add a state pattern that indicates danger (e.g. near edge)."""
        with self._lock:
            self._danger_state_patterns.append(state_pattern.copy())

    def check_safety(self, state: np.ndarray) -> SafetyRating:
        """Check the safety of a given state for exploration.

        Returns the safety rating based on proximity to known danger patterns.
        """
        if not self._danger_state_patterns:
            return SafetyRating.SAFE

        for pattern in self._danger_state_patterns:
            if len(state) == len(pattern):
                dist = np.linalg.norm(state - pattern)
                if dist < 0.5:
                    return SafetyRating.DANGEROUS
                elif dist < 1.5:
                    return SafetyRating.CAUTION

        return SafetyRating.SAFE

    # ------------------------------------------------------------------
    #  Statistics & Reporting
    # ------------------------------------------------------------------

    def get_stats(self) -> Dict[str, Any]:
        """Return current curiosity engine statistics."""
        with self._lock:
            self._stats.exploration_coverage = self._compute_coverage()
            self._stats.time_spent_exploring = (
                time.time() - self._exploration_start_time
                if self._exploration_start_time > 0
                else 0.0
            )
            return {
                "total_targets_generated": self._stats.total_targets_generated,
                "total_targets_explored": self._stats.total_targets_explored,
                "total_exploration_cycles": self._stats.total_exploration_cycles,
                "avg_intrinsic_reward": round(self._stats.avg_intrinsic_reward, 4),
                "exploration_coverage": round(self._stats.exploration_coverage, 4),
                "safety_violations": self._stats.safety_violations,
                "time_spent_exploring": round(self._stats.time_spent_exploring, 2),
                "current_complexity_tier": self._current_complexity_tier,
                "unique_states_explored": self._unique_states,
                "unique_actions_explored": self._unique_actions,
                "total_visits": self._total_visits,
                "active_targets": len(self._active_targets),
                "completed_targets": len(self._completed_targets),
                "failed_targets": len(self._failed_targets),
                "curiosity_ema": round(self._curiosity_ema, 4),
                "exploration_enabled": self._exploration_enabled,
            }

    def get_coverage_trend(self, n: int = 20) -> List[float]:
        """Return the last *n* coverage measurements."""
        with self._lock:
            return list(self._coverage_history)[-n:]

    def get_curiosity_map_snapshot(self) -> Dict[str, float]:
        """Return a copy of the current curiosity map."""
        with self._lock:
            return dict(self._curiosity_map)

    # ------------------------------------------------------------------
    #  State management
    # ------------------------------------------------------------------

    def reset(self) -> None:
        """Reset the curiosity engine (keep connections, clear state)."""
        with self._lock:
            self._visit_counts.clear()
            self._state_visits.clear()
            self._action_visits.clear()
            self._total_visits = 0
            self._unique_states = 0
            self._unique_actions = 0
            self._active_targets.clear()
            self._completed_targets.clear()
            self._failed_targets.clear()
            self._curiosity_map.clear()
            self._curiosity_ema = 0.5
            self._current_complexity_tier = 0
            self._targets_explored_this_tier = 0
            self._stats = CuriosityStats()
            self._reward_history.clear()
            self._coverage_history.clear()
            self._seed_curiosity_map()
            logger.info("CuriosityEngine: reset complete")


# ---------------------------------------------------------------------------
#  Module-level helper
# ---------------------------------------------------------------------------

def etime_name(etype: ExplorationType) -> str:
    """Return a short lowercase name for an ExplorationType."""
    return etype.name.lower()


# ---------------------------------------------------------------------------
#  Self-test
# ---------------------------------------------------------------------------

def _self_test() -> None:
    """Basic smoke test for all three engines."""
    import sys

    print("=" * 60)
    print("curiosity_engine self-test")
    print("=" * 60)

    # --- RNDEngine ---
    print("\n--- RNDEngine ---")
    rnd = RNDEngine(input_dim=32, hidden_dim=64, output_dim=32)
    rnd.initialize()

    # Test single reward
    state = np.random.randn(32).astype(np.float32)
    reward = rnd.compute_intrinsic_reward(state)
    print(f"  Intrinsic reward (novel state): {reward:.4f}")

    # Same state again — should be less novel
    reward2 = rnd.compute_intrinsic_reward(state)
    print(f"  Intrinsic reward (same state):  {reward2:.4f}")

    # Novelty scores for batch
    batch = np.random.randn(5, 32).astype(np.float32)
    scores = rnd.get_novelty_scores(batch)
    print(f"  Batch novelty scores: {scores}")

    # --- ICMEngine ---
    print("\n--- ICMEngine ---")
    icm = ICMEngine(state_dim=32, action_dim=8, feature_dim=16)
    icm.initialize()

    s = np.random.randn(32).astype(np.float32)
    a = np.random.randn(8).astype(np.float32)
    ns = s + np.random.randn(32).astype(np.float32) * 0.1

    icm_reward = icm.compute_intrinsic_reward(s, a, ns)
    print(f"  ICM intrinsic reward: {icm_reward:.4f}")

    features = icm.encode_features(s)
    print(f"  Feature vector shape: {features.shape}, norm: {np.linalg.norm(features):.4f}")

    pred_next = icm.predict_next_features(s, a)
    print(f"  Predicted next-features shape: {pred_next.shape}")

    pred_action = icm.predict_action(s, ns)
    print(f"  Predicted action shape: {pred_action.shape}")

    # --- CuriosityEngine ---
    print("\n--- CuriosityEngine ---")
    engine = CuriosityEngine()
    engine.initialize()
    engine.enable_exploration()

    result = engine.suggest_exploration()
    print(f"  Has target: {result['has_target']}")
    if result["has_target"]:
        t = result["target"]
        print(f"  Target type: {t['type']}, level: {t['curiosity_level']}, safety: {t['safety_rating']}")
        print(f"  Description: {t['description']}")

        # Record a result
        engine.record_exploration_result(
            target_id=t["id"],
            success=True,
            state=np.random.randn(62).astype(np.float32) * 0.1,
            action=np.random.randn(12).astype(np.float32) * 0.05,
            next_state=np.random.randn(62).astype(np.float32) * 0.1,
            reward=0.75,
        )

    stats = engine.get_stats()
    print(f"  Stats: {stats}")

    print("\n" + "=" * 60)
    print("All self-tests PASSED ✓")
    print("=" * 60)


# ============================================================================
# Go-Explore + Ensemble Disagreement Curiosity — Physical AGI 탐색 혁신
# ============================================================================
# 기존: RND/ICM만 사용 → 한계: 구조화된 공간에서 비효율적 탐색
# 혁신 1: Go-Explore — "먼저 돌아가라, 그 후 탐색하라"
# 혁신 2: 앙상블 불일치 — 모델 간 의견 불일치를 호기심으로
# 혁신 3: 물리적 호기심 — 힘/토크 공간에서의 새로움
# 혁신 4: 예산 제한 탐색 — 시간/에너지 대비 최대 정보 획득
# ============================================================================


class GoExplore:
    """Go-Explore 탐색 전략
    
    "먼저 돌아가라, 그 후 탐색하라" (First Return, Then Explore)
    
    기존 탐색: 무작위 → 새로운 상태 발견
    Go-Explore: 이전에 발견한 흥미로운 상태로 복귀 → 거기서 탐색
    
    Physical AGI에 유리: 복잡한 물리적 환경에서 효율적 탐색
    """
    
    def __init__(self, state_dim=62, max_archive_size=10000,
                 novelty_threshold=0.1, cell_resolution=0.5):
        self.state_dim = state_dim
        self.max_archive_size = max_archive_size
        self.novelty_threshold = novelty_threshold
        self.cell_resolution = cell_resolution
        
        # 상태 아카이브 (셀 기반)
        self.archive = {}  # cell_key → (state, trajectory, score, visit_count)
        self.best_score = -float('inf')
        self.best_trajectory = None
    
    def _discretize_state(self, state):
        """상태를 이산 셀로 변환"""
        if isinstance(state, torch.Tensor):
            state = state.detach().cpu().numpy()
        state = np.atleast_1d(state)
        
        cell = tuple(
            int(s / self.cell_resolution) for s in state[:min(10, len(state))]
        )
        return cell
    
    def update_archive(self, state, trajectory, score):
        """아카이브 업데이트"""
        cell = self._discretize_state(state)
        
        if cell not in self.archive:
            self.archive[cell] = {
                'state': state,
                'trajectory': trajectory,
                'score': score,
                'visit_count': 0,
            }
        else:
            existing = self.archive[cell]
            if score > existing['score']:
                existing['state'] = state
                existing['trajectory'] = trajectory
                existing['score'] = score
        
        # 최고 점수 갱신
        if score > self.best_score:
            self.best_score = score
            self.best_trajectory = trajectory
    
    def select_target(self):
        """탐색 대상 선택: 방문 횟수가 적고 점수가 높은 셀"""
        if not self.archive:
            return None
        
        # 점수와 방문 횟수로 가중 선택
        cells = list(self.archive.keys())
        weights = []
        for cell in cells:
            entry = self.archive[cell]
            # 높은 점수 + 낮은 방문 = 높은 가중치
            w = max(entry['score'], 0.01) / (entry['visit_count'] + 1)
            weights.append(w)
        
        total = sum(weights)
        if total == 0:
            probs = np.ones(len(cells)) / len(cells)
        else:
            probs = np.array(weights) / total
        
        selected_idx = np.random.choice(len(cells), p=probs)
        selected_cell = cells[selected_idx]
        
        # 방문 카운트 증가
        self.archive[selected_cell]['visit_count'] += 1
        
        return self.archive[selected_cell]
    
    def is_novel(self, state):
        """상태의 새로움 평가"""
        cell = self._discretize_state(state)
        return cell not in self.archive
    
    def get_statistics(self):
        """아카이브 통계"""
        return {
            'archive_size': len(self.archive),
            'best_score': self.best_score,
            'total_visits': sum(e['visit_count'] for e in self.archive.values()),
        }


if _HAS_TORCH:

    class EnsembleDisagreementCuriosity(nn.Module):
        """앙상블 불일치 호기심 엔진
        
        5개의 다음 상태 예측 모델이 얼마나 다르게 예측하는지로
        호기심 보상을 계산. 구조화된 물리적 공간에서 RND보다 효과적.
        """
        
        def __init__(self, state_dim=62, action_dim=32, hidden_dim=128,
                     num_ensemble=5):
            super().__init__()
            self.num_ensemble = num_ensemble
            
            self.ensemble = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(state_dim + action_dim, hidden_dim),
                    nn.GELU(),
                    nn.Linear(hidden_dim, hidden_dim),
                    nn.GELU(),
                    nn.Linear(hidden_dim, state_dim),
                ) for _ in range(num_ensemble)
            ])
        
        def forward(self, state, action):
            """불일치 호기심 보상 계산"""
            if isinstance(state, np.ndarray):
                state = torch.FloatTensor(state)
            if isinstance(action, np.ndarray):
                action = torch.FloatTensor(action)
            if state.dim() == 1:
                state = state.unsqueeze(0)
            if action.dim() == 1:
                action = action.unsqueeze(0)
            
            x = torch.cat([state, action], dim=-1)
            
            # 각 앙상블 멤버의 예측
            predictions = []
            for member in self.ensemble:
                predictions.append(member(x))
            
            predictions = torch.stack(predictions, dim=0)  # [ensemble, batch, state_dim]
            
            # 불일치 = 예측 분산
            disagreement = predictions.var(dim=0).mean(dim=-1)  # [batch]
            
            return {
                'intrinsic_reward': disagreement,
                'predictions': predictions,
                'mean_prediction': predictions.mean(dim=0),
            }

else:
    # Stub class for when PyTorch is not available
    class EnsembleDisagreementCuriosity:  # type: ignore[no-redef]
        """스텁: PyTorch 미설치 / Stub for when PyTorch is not installed."""
        pass


class PhysicalCuriosityEngine:
    """물리적 호기심 엔진 — 힘/토크 공간에서의 새로움
    
    단순한 상태 공간 새로움이 아닌,
    물리적 상호작용의 새로움에 집중:
    - 새로운 힘 반응 패턴
    - 새로운 마찰 특성
    - 새로운 무게 감각
    """
    
    def __init__(self, force_dim=12, tactile_dim=12, novelty_decay=0.99):
        self.force_dim = force_dim
        self.tactile_dim = tactile_dim
        self.novelty_decay = novelty_decay
        
        # 힘 반응 패턴 메모리
        self.force_patterns = []
        self.tactile_patterns = []
        
        # 새로움 임계값
        self.force_novelty_threshold = 0.5
        self.tactile_novelty_threshold = 0.3
    
    def compute_physical_novelty(self, force_response, tactile_response):
        """물리적 새로움 계산"""
        if isinstance(force_response, torch.Tensor):
            force_response = force_response.detach().cpu().numpy()
        if isinstance(tactile_response, torch.Tensor):
            tactile_response = tactile_response.detach().cpu().numpy()
        
        force_response = np.atleast_1d(force_response)
        tactile_response = np.atleast_1d(tactile_response)
        
        # 기존 패턴과의 최소 거리
        force_novelty = self._compute_novelty(
            force_response, self.force_patterns, self.force_novelty_threshold
        )
        
        tactile_novelty = self._compute_novelty(
            tactile_response, self.tactile_patterns, self.tactile_novelty_threshold
        )
        
        # 패턴 메모리 업데이트
        if force_novelty > self.force_novelty_threshold:
            self.force_patterns.append(force_response)
            if len(self.force_patterns) > 1000:
                self.force_patterns = self.force_patterns[-500:]
        
        if tactile_novelty > self.tactile_novelty_threshold:
            self.tactile_patterns.append(tactile_response)
            if len(self.tactile_patterns) > 1000:
                self.tactile_patterns = self.tactile_patterns[-500:]
        
        # 가중 새로움 (힘 > 촉각, 안전 관련성)
        total_novelty = 0.6 * force_novelty + 0.4 * tactile_novelty
        
        return {
            'total_novelty': total_novelty,
            'force_novelty': force_novelty,
            'tactile_novelty': tactile_novelty,
            'is_novel': total_novelty > 0.5,
        }
    
    def _compute_novelty(self, pattern, memory, threshold):
        """패턴 새로움 계산 (최근접 이웃 거리)"""
        if not memory:
            return 1.0  # 빈 메모리 = 모든 것이 새로움
        
        distances = [
            np.linalg.norm(pattern - mem) for mem in memory
            if len(mem) == len(pattern)
        ]
        
        if not distances:
            return 1.0
        
        min_distance = min(distances)
        novelty = min(min_distance / threshold, 1.0)
        
        return novelty


class BudgetConstrainedExploration:
    """예산 제한 탐색: 시간/에너지 대비 최대 정보 획득
    
    Physical AGI는 배터리와 시간이 제한되어 있으므로,
    탐색도 효율적으로 수행해야 함.
    """
    
    def __init__(self, energy_budget_wh=76.8, time_budget_hours=1.4,
                 exploration_energy_fraction=0.2):
        self.energy_budget_wh = energy_budget_wh
        self.time_budget_hours = time_budget_hours
        self.exploration_fraction = exploration_energy_fraction
        
        self.energy_spent = 0
        self.time_spent = 0
        self.information_gained = 0
    
    def should_explore(self, estimated_info_gain, estimated_energy_cost,
                       estimated_time_cost):
        """탐색 여부 결정 (정보/비용 비율 기반)"""
        remaining_energy = self.energy_budget_wh * self.exploration_fraction - self.energy_spent
        remaining_time = self.time_budget_hours - self.time_spent
        
        if remaining_energy <= 0 or remaining_time <= 0:
            return False
        
        # 정보 획득 효율
        info_per_joule = estimated_info_gain / max(estimated_energy_cost, 0.001)
        info_per_minute = estimated_info_gain / max(estimated_time_cost, 0.001)
        
        # 예산 대비 충분한 효율인지 확인
        min_efficiency = 0.5  # 최소 정보 획득 효율
        return info_per_joule > min_efficiency or info_per_minute > min_efficiency
    
    def update(self, info_gained, energy_cost, time_cost):
        """탐색 결과 업데이트"""
        self.information_gained += info_gained
        self.energy_spent += energy_cost
        self.time_spent += time_cost
    
    @property
    def exploration_efficiency(self):
        """탐색 효율: 정보/에너지"""
        if self.energy_spent == 0:
            return 0
        return self.information_gained / self.energy_spent


if __name__ == "__main__":
    _self_test()
