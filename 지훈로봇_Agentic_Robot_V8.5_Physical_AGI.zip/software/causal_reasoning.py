"""
causal_reasoning.py — Jihun Robot V8.5 Physical AGI: Causal Reasoning Module

Three-layer causal reasoning for physical intelligence:
  1. CausalReasoning          — causal graph engine, intervention queries, explain/find_related API
  2. PCAlgorithm              — Peter-Spirtes-Clark-Glymour constraint-based causal discovery
  3. DoCalculusCounterfactualReasoner — Pearl's do-calculus + counterfactual reasoning over SCM

Design principles
-----------------
- Physical causality: force → motion, friction → slip, gravity → fall
- Temporal precedence: cause must precede effect
- Mechanistic understanding: not just correlation but WHY
- Interventional reasoning: predict effects of actions not yet taken
- Counterfactual: learn from "what could have been"
"""

from __future__ import annotations

import math
import random
import logging
import time

import numpy as np

# ─── PyTorch 선택적 임포트 / Optional PyTorch Import ─────────────────────────

TORCH_AVAILABLE = False
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    TORCH_AVAILABLE = True
except ImportError:
    torch = None
    nn = None
    F = None
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import (
    Any,
    Callable,
    Dict,
    FrozenSet,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)

logger = logging.getLogger(__name__)

try:
    from scipy import stats as scipy_stats
    from scipy.optimize import minimize_scalar
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

class EdgeType(Enum):
    UNDIRECTED = auto()
    DIRECTED = auto()
    BIDIRECTED = auto()      # latent confounder


@dataclass
class CausalEdge:
    """A single edge in a causal graph."""
    source: str
    target: str
    edge_type: EdgeType = EdgeType.DIRECTED
    confidence: float = 1.0
    mechanism: Optional[str] = None       # e.g. "force → acceleration (F=ma)"
    timestamp: float = field(default_factory=time.time)

    def __repr__(self) -> str:
        arrow = {
            EdgeType.UNDIRECTED: "---",
            EdgeType.DIRECTED: "-->",
            EdgeType.BIDIRECTED: "<->",
        }[self.edge_type]
        return f"{self.source} {arrow} {self.target}  (conf={self.confidence:.2f})"


@dataclass
class CausalRelation:
    """A named cause-effect pair with metadata."""
    cause: str
    effect: str
    confidence: float
    source: str = "unknown"
    mechanism: Optional[str] = None
    temporal_lag: Optional[float] = None
    evidence_count: int = 1


@dataclass
class InterventionResult:
    """Result of a do(X=x) intervention query."""
    target: str
    intervened_var: str
    intervened_value: Any
    expected_value: Optional[float] = None
    distribution: Optional[Dict[Any, float]] = None
    confidence: float = 0.0
    mechanism_trace: List[str] = field(default_factory=list)


@dataclass
class CounterfactualResult:
    """Result of a counterfactual query."""
    factual_var: str
    factual_value: Any
    counterfactual_var: str
    counterfactual_value: Any
    target_var: str
    factual_target: Any
    counterfactual_target: Any
    explanation: str = ""


# ---------------------------------------------------------------------------
# Helpers: statistical primitives
# ---------------------------------------------------------------------------

def _pearson_r(x: List[float], y: List[float]) -> float:
    """Pearson correlation coefficient."""
    n = len(x)
    if n < 2 or n != len(y):
        return 0.0
    mx = sum(x) / n
    my = sum(y) / n
    dx = [xi - mx for xi in x]
    dy = [yi - my for yi in y]
    num = sum(a * b for a, b in zip(dx, dy))
    den_x = math.sqrt(sum(a * a for a in dx))
    den_y = math.sqrt(sum(b * b for b in dy))
    if den_x < 1e-12 or den_y < 1e-12:
        return 0.0
    return max(-1.0, min(1.0, num / (den_x * den_y)))


def _partial_correlation(x: List[float], y: List[float],
                         z_sets: List[List[float]]) -> float:
    """Partial correlation of x and y given conditioning sets z.

    Uses recursive formula:  r_xy.z = (r_xy - r_xz * r_yz) / sqrt((1-r_xz^2)(1-r_yz^2))
    For multiple Z variables we regress out one at a time (first-order approximation).
    """
    if not z_sets:
        return _pearson_r(x, y)

    rxz_list = [_pearson_r(x, z) for z in z_sets]
    ryz_list = [_pearson_r(y, z) for z in z_sets]

    rxy = _pearson_r(x, y)

    # Regress out each conditioning variable sequentially
    for rxz, ryz in zip(rxz_list, ryz_list):
        denom_x = 1.0 - rxz * rxz
        denom_y = 1.0 - ryz * ryz
        if denom_x < 1e-12 or denom_y < 1e-12:
            return 0.0
        rxy = (rxy - rxz * ryz) / math.sqrt(denom_x * denom_y)

    return max(-1.0, min(1.0, rxy))


def _fisher_z(r: float, n: int, k: int = 0) -> float:
    """Fisher z-transformation for testing significance of partial correlation.

    Returns z-statistic. Under H0 (independence) this is approximately N(0, 1/(n-3-k)).
    """
    if n - 3 - k < 1:
        return 0.0
    r_clamped = max(-0.9999, min(0.9999, r))
    z_val = 0.5 * math.log((1 + r_clamped) / (1 - r_clamped))
    se = 1.0 / math.sqrt(n - 3 - k)
    return z_val / se if se > 1e-12 else 0.0


def _chi_square_test(observed: List[List[int]]) -> Tuple[float, float]:
    """Chi-square test of independence for a contingency table.

    Returns (chi2_statistic, p_value_approximation).
    p-value is approximated via chi2 CDF (Wilson-Hilferty).
    """
    if not observed or not observed[0]:
        return 0.0, 1.0

    rows = len(observed)
    cols = len(observed[0])
    row_totals = [sum(row) for row in observed]
    col_totals = [sum(observed[r][c] for r in range(rows)) for c in range(cols)]
    grand_total = sum(row_totals)

    if grand_total < 1:
        return 0.0, 1.0

    chi2 = 0.0
    for r in range(rows):
        for c in range(cols):
            expected = row_totals[r] * col_totals[c] / grand_total
            if expected > 1e-12:
                chi2 += (observed[r][c] - expected) ** 2 / expected

    df = (rows - 1) * (cols - 1)
    if df < 1:
        return chi2, 1.0

    # Wilson-Hilferty approximation for chi2 CDF
    z = ((chi2 / df) ** (1.0 / 3.0) - 1.0 + 2.0 / (9.0 * df)) / math.sqrt(2.0 / (9.0 * df))
    # Standard normal CDF approximation
    p = 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))
    return chi2, 1.0 - p


def _gaussian_cdf(x: float) -> float:
    """Standard normal CDF."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _linear_regression_coeffs(X: List[List[float]], y: List[float]) -> List[float]:
    """Ordinary least-squares regression  y = X @ beta.

    Uses normal equations:  beta = (X^T X)^-1 X^T y
    Simplified for small matrices via Gaussian elimination.
    """
    n = len(y)
    if n < 2 or not X:
        return [0.0] * (len(X[0]) if X else 1)

    p = len(X[0])

    # X^T X
    XtX = [[0.0] * p for _ in range(p)]
    for i in range(p):
        for j in range(p):
            XtX[i][j] = sum(X[k][i] * X[k][j] for k in range(n))

    # X^T y
    Xty = [sum(X[k][i] * y[k] for k in range(n)) for i in range(p)]

    # Solve via Gaussian elimination with partial pivoting
    aug = [XtX[i][:] + [Xty[i]] for i in range(p)]

    for col in range(p):
        # pivot
        max_row = col
        for row in range(col + 1, p):
            if abs(aug[row][col]) > abs(aug[max_row][col]):
                max_row = row
        aug[col], aug[max_row] = aug[max_row], aug[col]

        if abs(aug[col][col]) < 1e-12:
            continue

        for row in range(col + 1, p):
            factor = aug[row][col] / aug[col][col]
            for j in range(col, p + 1):
                aug[row][j] -= factor * aug[col][j]

    # Back substitution
    beta = [0.0] * p
    for i in range(p - 1, -1, -1):
        if abs(aug[i][i]) < 1e-12:
            continue
        beta[i] = aug[i][p]
        for j in range(i + 1, p):
            beta[i] -= aug[i][j] * beta[j]
        beta[i] /= aug[i][i]

    return beta


# ---------------------------------------------------------------------------
# 1. CausalReasoning — main causal reasoning engine
# ---------------------------------------------------------------------------

class CausalReasoning:
    """Central causal reasoning engine for the Jihun Robot V8.5 Physical AGI.

    Maintains a causal graph built from physical experiences and supports:
    - Adding causal relations with confidence and mechanism annotation
    - Intervention queries  ("what if I push harder?")
    - Explanation queries   ("why did the object slip?")
    - Causal chain traversal for multi-step reasoning
    """

    # Physical-domain causal priors — these seed the graph with known physics
    PHYSICAL_PRIORS: List[Dict[str, Any]] = [
        {"cause": "applied_force", "effect": "acceleration", "mechanism": "F=ma", "confidence": 0.99},
        {"cause": "friction_force", "effect": "deceleration", "mechanism": "kinetic friction", "confidence": 0.95},
        {"cause": "static_friction_exceeded", "effect": "slip", "mechanism": "Coulomb friction model", "confidence": 0.93},
        {"cause": "gravity", "effect": "fall", "mechanism": "gravitational acceleration g=9.81m/s²", "confidence": 0.99},
        {"cause": "normal_force", "effect": "friction_force", "mechanism": "f=μN", "confidence": 0.94},
        {"cause": "contact", "effect": "normal_force", "mechanism": "contact mechanics", "confidence": 0.92},
        {"cause": "torque", "effect": "angular_acceleration", "mechanism": "τ=Iα", "confidence": 0.95},
        {"cause": "grip_force", "effect": "stable_grasp", "mechanism": "friction cone closure", "confidence": 0.90},
        {"cause": "weight", "effect": "required_grip_force", "mechanism": "force equilibrium", "confidence": 0.91},
        {"cause": "surface_roughness", "effect": "friction_coefficient", "mechanism": "surface interaction", "confidence": 0.85},
        {"cause": "velocity", "effect": "kinetic_energy", "mechanism": "KE=½mv²", "confidence": 0.96},
        {"cause": "height", "effect": "potential_energy", "mechanism": "PE=mgh", "confidence": 0.96},
        {"cause": "impact_force", "effect": "deformation", "mechanism": "material stress-strain", "confidence": 0.88},
        {"cause": "push_action", "effect": "applied_force", "mechanism": "actuator command", "confidence": 0.90},
        {"cause": "lift_action", "effect": "overcome_gravity", "mechanism": "vertical force", "confidence": 0.89},
    ]

    def __init__(self) -> None:
        self._initialized = False
        # Adjacency: node -> list of (target, CausalEdge)
        self._forward: Dict[str, List[Tuple[str, CausalEdge]]] = defaultdict(list)
        self._backward: Dict[str, List[Tuple[str, CausalEdge]]] = defaultdict(list)
        # Named relations for query/explain API
        self._relations: List[CausalRelation] = []
        # Index: cause keyword -> list of relation indices
        self._cause_index: Dict[str, List[int]] = defaultdict(list)
        self._effect_index: Dict[str, List[int]] = defaultdict(list)
        # Experience data for causal discovery
        self._experiences: List[Dict[str, Any]] = []
        # PCAlgorithm instance (lazy)
        self._pc_algorithm: Optional[PCAlgorithm] = None
        # Counterfactual reasoner (lazy)
        self._counterfactual_reasoner: Optional[DoCalculusCounterfactualReasoner] = None

    # ----- Lifecycle -----

    def initialize(self) -> None:
        """Initialize with physical-domain causal priors."""
        if self._initialized:
            return
        for prior in self.PHYSICAL_PRIORS:
            self.add_causal_relation(
                cause=prior["cause"],
                effect=prior["effect"],
                confidence=prior["confidence"],
                source="physical_prior",
                mechanism=prior.get("mechanism"),
            )
        self._initialized = True
        logger.info(f"CausalReasoning 초기화 완료 — {len(self._relations)}개 물리 선행 인과관계 로드")

    # ----- Graph construction -----

    def add_causal_relation(
        self,
        cause: str,
        effect: str,
        confidence: float = 0.5,
        source: str = "experience",
        mechanism: Optional[str] = None,
        temporal_lag: Optional[float] = None,
    ) -> None:
        """Add a causal relation to the graph.

        If a relation with the same cause→effect already exists, the confidence
        is updated via a Bayesian-style online update.
        """
        # Check for existing relation
        for idx, rel in enumerate(self._relations):
            if rel.cause == cause and rel.effect == effect:
                # Bayesian online update: posterior ∝ prior × likelihood
                old_conf = rel.confidence
                n = rel.evidence_count
                new_conf = (old_conf * n + confidence) / (n + 1)
                rel.confidence = new_conf
                rel.evidence_count += 1
                if mechanism:
                    rel.mechanism = mechanism
                if temporal_lag is not None:
                    rel.temporal_lag = temporal_lag
                rel.source = source

                # Update edge confidence in graph
                for tgt, edge in self._forward.get(cause, []):
                    if tgt == effect:
                        edge.confidence = new_conf
                return

        # New relation
        rel = CausalRelation(
            cause=cause,
            effect=effect,
            confidence=confidence,
            source=source,
            mechanism=mechanism,
            temporal_lag=temporal_lag,
        )
        idx = len(self._relations)
        self._relations.append(rel)
        self._cause_index[cause].append(idx)
        self._effect_index[effect].append(idx)

        edge = CausalEdge(
            source=cause,
            target=effect,
            edge_type=EdgeType.DIRECTED,
            confidence=confidence,
            mechanism=mechanism,
        )
        self._forward[cause].append((effect, edge))
        self._backward[effect].append((cause, edge))

    def add_experience(self, experience: Dict[str, Any]) -> None:
        """Record a physical experience for later causal discovery.

        An experience dict should contain at least:
          - 'observations': dict of variable → value
          - 'timestamp': float
        Optionally:
          - 'action': str — action taken
          - 'outcome': dict of variable → value after action
        """
        self._experiences.append(experience)

        # Auto-extract candidate causal relations from temporal sequences
        obs = experience.get("observations", {})
        outcome = experience.get("outcome", {})
        action = experience.get("action")

        if action and outcome:
            for var, val in outcome.items():
                if var not in obs:
                    self.add_causal_relation(
                        cause=action,
                        effect=var,
                        confidence=0.4,
                        source="auto_extracted",
                        temporal_lag=experience.get("timestamp", 0) - experience.get("prev_timestamp", 0),
                    )

    # ----- Query API -----

    def find_related(self, query: str, top_k: int = 10) -> List[CausalRelation]:
        """Find causal relations related to a query string.

        Matches against cause, effect, and mechanism fields using
        keyword overlap scoring.
        """
        query_terms = set(query.lower().replace("_", " ").split())
        if not query_terms:
            return []

        scored: List[Tuple[float, int]] = []
        for idx, rel in enumerate(self._relations):
            text = f"{rel.cause} {rel.effect} {rel.mechanism or ''}".lower()
            text_terms = set(text.replace("_", " ").split())
            overlap = len(query_terms & text_terms)
            if overlap > 0:
                score = overlap * rel.confidence
                scored.append((score, idx))

        scored.sort(key=lambda t: (-t[0], t[1]))
        return [self._relations[idx] for _, idx in scored[:top_k]]

    def explain(self, query: str, max_depth: int = 5) -> List[CausalRelation]:
        """Explain why something happened by tracing causal chains backward.

        Returns the causal chain from root causes to the queried effect,
        following backward edges (effect → cause) up to max_depth.
        """
        # Find nodes matching query
        matching_effects = set()
        for rel in self._relations:
            if query.lower() in rel.effect.lower() or query.lower() in (rel.mechanism or "").lower():
                matching_effects.add(rel.effect)

        if not matching_effects:
            # Fallback: try cause side
            for rel in self._relations:
                if query.lower() in rel.cause.lower():
                    matching_effects.add(rel.effect)

        if not matching_effects:
            return self.find_related(query, top_k=5)

        # BFS backward from matching effects
        visited: Set[str] = set()
        queue: deque[Tuple[str, int]] = deque()
        for eff in matching_effects:
            queue.append((eff, 0))
            visited.add(eff)

        chain_relations: List[CausalRelation] = []
        seen_pairs: Set[Tuple[str, str]] = set()

        while queue:
            node, depth = queue.popleft()
            if depth >= max_depth:
                continue

            for src, edge in self._backward.get(node, []):
                pair = (src, node)
                if pair in seen_pairs:
                    continue
                seen_pairs.add(pair)

                # Find corresponding relation
                for rel in self._relations:
                    if rel.cause == src and rel.effect == node:
                        chain_relations.append(rel)
                        break

                if src not in visited:
                    visited.add(src)
                    queue.append((src, depth + 1))

        # Sort: root causes first (those that appear as causes but not as effects in chain)
        cause_set = {r.cause for r in chain_relations}
        effect_set = {r.effect for r in chain_relations}
        roots = cause_set - effect_set

        def _sort_key(r: CausalRelation) -> int:
            if r.cause in roots:
                return 0
            return 1

        chain_relations.sort(key=_sort_key)
        return chain_relations

    def get_causal_chain(self, query: str, max_depth: int = 5) -> List[CausalRelation]:
        """Get forward causal chain starting from query cause.

        Traces forward edges from a cause to predict downstream effects.
        """
        matching_causes = set()
        for rel in self._relations:
            if query.lower() in rel.cause.lower() or query.lower() in (rel.mechanism or "").lower():
                matching_causes.add(rel.cause)

        if not matching_causes:
            related = self.find_related(query, top_k=5)
            if related:
                matching_causes.add(related[0].cause)
            else:
                return []

        visited: Set[str] = set()
        queue: deque[Tuple[str, int]] = deque()
        for c in matching_causes:
            queue.append((c, 0))
            visited.add(c)

        chain: List[CausalRelation] = []
        seen_pairs: Set[Tuple[str, str]] = set()

        while queue:
            node, depth = queue.popleft()
            if depth >= max_depth:
                continue

            for tgt, edge in self._forward.get(node, []):
                pair = (node, tgt)
                if pair in seen_pairs:
                    continue
                seen_pairs.add(pair)

                for rel in self._relations:
                    if rel.cause == node and rel.effect == tgt:
                        chain.append(rel)
                        break

                if tgt not in visited:
                    visited.add(tgt)
                    queue.append((tgt, depth + 1))

        return chain

    # ----- Intervention queries -----

    def intervene(
        self,
        variable: str,
        value: Any,
        target: str,
        graph: Optional[Dict[str, List[Tuple[str, CausalEdge]]]] = None,
    ) -> InterventionResult:
        """Compute the effect of do(variable=value) on target.

        Implements the graph mutilation approach:
        1. Remove all incoming edges to the intervened variable
        2. Fix the variable to the given value
        3. Propagate through the graph using structural equations
        """
        fwd = graph if graph is not None else self._forward

        # Build mutilated graph: remove all edges into the intervened variable
        mutilated = defaultdict(list)
        for src, edges in fwd.items():
            for tgt, edge in edges:
                if tgt != variable:
                    mutilated[src].append((tgt, edge))

        # Propagate: set variable=value, compute downstream
        values: Dict[str, Any] = {variable: value}
        trace: List[str] = [f"do({variable}={value})"]

        # Topological propagation (BFS from intervened variable)
        visited: Set[str] = {variable}
        queue: deque[str] = deque([variable])

        while queue:
            node = queue.popleft()
            for tgt, edge in mutilated.get(node, []):
                if tgt in visited:
                    continue
                visited.add(tgt)

                # Compute target value from structural equation (simplified linear model)
                parent_val = values.get(node, 0.0)
                weight = edge.confidence  # Use confidence as proxy for coefficient
                if isinstance(parent_val, (int, float)):
                    noise = random.gauss(0, 0.05)  # Small Gaussian noise
                    computed = weight * parent_val + noise
                    values[tgt] = computed
                    trace.append(f"{node}={parent_val:.2f} → {tgt}={computed:.2f} (w={weight:.2f})")
                else:
                    values[tgt] = parent_val
                    trace.append(f"{node}={parent_val} → {tgt}={parent_val}")

                queue.append(tgt)

        target_value = values.get(target)
        confidence = 1.0
        for _, edge in self._forward.get(variable, []):
            if edge.target == target:
                confidence = edge.confidence
                break

        return InterventionResult(
            target=target,
            intervened_var=variable,
            intervened_value=value,
            expected_value=target_value,
            confidence=confidence,
            mechanism_trace=trace,
        )

    def query_intervention(self, query: str) -> Optional[InterventionResult]:
        """Natural-language-ish intervention query.

        Parses queries like "what if I push harder?" to identify the variable
        to intervene on and the target of interest.
        """
        query_lower = query.lower()

        # Simple pattern matching for physical interventions
        intervention_map = {
            "push harder": ("applied_force", "high", "acceleration"),
            "push softer": ("applied_force", "low", "acceleration"),
            "grip tighter": ("grip_force", "high", "stable_grasp"),
            "grip looser": ("grip_force", "low", "stable_grasp"),
            "lift higher": ("height", "high", "potential_energy"),
            "go faster": ("velocity", "high", "kinetic_energy"),
            "rougher surface": ("surface_roughness", "high", "friction_coefficient"),
            "smoother surface": ("surface_roughness", "low", "friction_coefficient"),
            "heavier object": ("weight", "high", "required_grip_force"),
            "lighter object": ("weight", "low", "required_grip_force"),
        }

        for pattern, (var, level, target) in intervention_map.items():
            if pattern in query_lower:
                value = 1.5 if level == "high" else 0.5
                return self.intervene(var, value, target)

        # Fallback: try to match against known causes
        for rel in self._relations:
            if rel.cause in query_lower:
                return self.intervene(rel.cause, 1.5, rel.effect)

        return None

    # ----- Graph analysis -----

    def get_ancestors(self, node: str) -> Set[str]:
        """Return all ancestors of a node in the causal graph."""
        ancestors: Set[str] = set()
        queue: deque[str] = deque([node])
        while queue:
            current = queue.popleft()
            for src, _ in self._backward.get(current, []):
                if src not in ancestors:
                    ancestors.add(src)
                    queue.append(src)
        return ancestors

    def get_descendants(self, node: str) -> Set[str]:
        """Return all descendants of a node in the causal graph."""
        descendants: Set[str] = set()
        queue: deque[str] = deque([node])
        while queue:
            current = queue.popleft()
            for tgt, _ in self._forward.get(current, []):
                if tgt not in descendants:
                    descendants.add(tgt)
                    queue.append(tgt)
        return descendants

    def get_all_paths(self, source: str, target: str, max_len: int = 8) -> List[List[str]]:
        """Find all directed paths from source to target."""
        paths: List[List[str]] = []
        stack: List[Tuple[str, List[str]]] = [(source, [source])]

        while stack:
            current, path = stack.pop()
            if current == target and len(path) > 1:
                paths.append(path)
                continue
            if len(path) >= max_len:
                continue
            for tgt, _ in self._forward.get(current, []):
                if tgt not in path:  # avoid cycles
                    stack.append((tgt, path + [tgt]))

        return paths

    def d_separated(self, X: str, Y: str, Z: Set[str]) -> bool:
        """Test d-separation of X and Y given Z using the Bayes-Ball algorithm.

        Returns True if X ⊥ Y | Z (d-separated).
        """
        # Phase 1: find all ancestors of Z
        ancestors_of_Z: Set[str] = set(Z.copy())
        queue: deque[str] = deque(Z)
        while queue:
            node = queue.popleft()
            for parent, _ in self._backward.get(node, []):
                if parent not in ancestors_of_Z:
                    ancestors_of_Z.add(parent)
                    queue.append(parent)

        # Phase 2: Bayes-Ball traversal
        # State: (node, direction) where direction is "up" (from child) or "down" (from parent)
        visited: Set[Tuple[str, str]] = set()
        reachable: Set[str] = set()
        visit_queue: deque[Tuple[str, str]] = deque()

        # Start from X going both up and down
        visit_queue.append((X, "up"))
        visit_queue.append((X, "down"))

        while visit_queue:
            node, direction = visit_queue.popleft()
            if (node, direction) in visited:
                continue
            visited.add((node, direction))

            if node != X:
                reachable.add(node)

            # If coming from a child (going "up")
            if direction == "up" and node not in Z:
                # Pass through to parents
                for parent, _ in self._backward.get(node, []):
                    visit_queue.append((parent, "up"))
                # Pass through to children (v-structure unblocked if ancestor of Z)
                for child, _ in self._forward.get(node, []):
                    visit_queue.append((child, "down"))

            # If coming from a parent (going "down")
            if direction == "down":
                if node not in Z:
                    # Pass through to children
                    for child, _ in self._forward.get(node, []):
                        visit_queue.append((child, "down"))
                    # Also go up (collider case)
                    for parent, _ in self._backward.get(node, []):
                        visit_queue.append((parent, "up"))
                else:
                    # Node is in Z — blocked going down, but can go up if ancestor of Z
                    if node in ancestors_of_Z:
                        for parent, _ in self._backward.get(node, []):
                            visit_queue.append((parent, "up"))

        return Y not in reachable

    @property
    def num_relations(self) -> int:
        return len(self._relations)

    @property
    def num_nodes(self) -> int:
        nodes: Set[str] = set()
        for rel in self._relations:
            nodes.add(rel.cause)
            nodes.add(rel.effect)
        return len(nodes)

    @property
    def relations(self) -> List[CausalRelation]:
        return list(self._relations)

    @property
    def experiences(self) -> List[Dict[str, Any]]:
        return list(self._experiences)


# ---------------------------------------------------------------------------
# 2. PCAlgorithm — constraint-based causal structure learning
# ---------------------------------------------------------------------------

class PCAlgorithm:
    """Peter-Spirtes-Clark-Glymour (PC) algorithm for causal discovery.

    Phase I  — Skeleton discovery:
        Start with a complete undirected graph. For each pair (X, Y), test
        conditional independence given increasing-size subsets of adj(X) ∖ {Y}.
        Remove edge if X ⊥ Y | S for some S.

    Phase II — Edge orientation:
        Orient v-structures:  X — Z — Y  →  X → Z ← Y  if Z not in sep(X,Y).
        Apply orientation rules (Meek rules R1-R3) to propagate directions
        while maintaining acyclicity.

    Works with physical experience data (continuous and discrete variables).
    """

    def __init__(
        self,
        alpha: float = 0.05,
        max_cond_set_size: int = 3,
        min_samples: int = 10,
        continuous: bool = True,
    ) -> None:
        """
        Args:
            alpha: Significance level for independence tests.
            max_cond_set_size: Maximum size of conditioning sets to test.
            min_samples: Minimum number of observations required.
            continuous: Whether variables are continuous (True: partial correlation,
                        False: chi-square test).
        """
        self.alpha = alpha
        self.max_cond_set_size = max_cond_set_size
        self.min_samples = min_samples
        self.continuous = continuous

        # Discovered structure
        self._nodes: List[str] = []
        self._skeleton: Set[FrozenSet[str]] = set()     # undirected edges
        self._separating_sets: Dict[FrozenSet[str], Set[str]] = {}
        self._directed_edges: Set[Tuple[str, str]] = set()
        self._undirected_edges: Set[FrozenSet[str]] = set()
        self._data: Optional[Dict[str, List[float]]] = None
        self._discrete_data: Optional[Dict[str, List[int]]] = None

    # ----- Public API -----

    def discover(
        self,
        data: Dict[str, List[float]],
        discrete_data: Optional[Dict[str, List[int]]] = None,
    ) -> Dict[str, Any]:
        """Run the full PC algorithm on the given data.

        Args:
            data: Variable name → list of observations (continuous).
            discrete_data: Variable name → list of observations (discrete/categorical).

        Returns:
            Dict with 'nodes', 'directed_edges', 'undirected_edges', 'v_structures'.
        """
        self._data = data
        self._discrete_data = discrete_data
        self._nodes = list(data.keys())

        n_samples = len(next(iter(data.values())))
        if n_samples < self.min_samples:
            logger.warning(f"PC algorithm: only {n_samples} samples (need {self.min_samples})")
            return self._empty_result()

        # Phase I: Skeleton discovery
        self._phase1_skeleton()

        # Phase II: Edge orientation
        v_structures = self._phase2_orient()

        result = {
            "nodes": self._nodes,
            "directed_edges": list(self._directed_edges),
            "undirected_edges": [list(e) for e in self._undirected_edges],
            "v_structures": v_structures,
            "num_edges": len(self._directed_edges) + len(self._undirected_edges),
        }
        logger.info(f"PC algorithm 완료: {len(self._directed_edges)}개 방향성, "
                     f"{len(self._undirected_edges)}개 무방향성, "
                     f"{len(v_structures)}개 v-구조")
        return result

    def discover_from_experiences(
        self,
        experiences: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Convenience: run PC discovery on a list of experience dicts.

        Each experience should have 'observations': {var: value, ...}.
        Variables are extracted and aligned automatically.
        """
        if not experiences:
            return self._empty_result()

        # Collect all variable names
        all_vars: Set[str] = set()
        for exp in experiences:
            obs = exp.get("observations", {})
            all_vars.update(obs.keys())

        # Build aligned data columns
        data: Dict[str, List[float]] = {v: [] for v in all_vars}
        for exp in experiences:
            obs = exp.get("observations", {})
            for v in all_vars:
                val = obs.get(v, 0.0)
                data[v].append(float(val) if isinstance(val, (int, float)) else 0.0)

        return self.discover(data)

    def get_causal_graph(self) -> CausalReasoning:
        """Convert the discovered structure into a CausalReasoning graph."""
        cr = CausalReasoning()
        cr.initialize()

        for src, tgt in self._directed_edges:
            cr.add_causal_relation(
                cause=src,
                effect=tgt,
                confidence=0.7,
                source="pc_algorithm",
            )

        for edge in self._undirected_edges:
            pair = list(edge)
            cr.add_causal_relation(
                cause=pair[0],
                effect=pair[1],
                confidence=0.5,
                source="pc_algorithm_undirected",
            )
            cr.add_causal_relation(
                cause=pair[1],
                effect=pair[0],
                confidence=0.5,
                source="pc_algorithm_undirected",
            )

        return cr

    # ----- Phase I: Skeleton discovery -----

    def _phase1_skeleton(self) -> None:
        """Remove edges from the complete graph based on conditional independence."""
        # Start with complete undirected graph
        self._skeleton = set()
        for i, n1 in enumerate(self._nodes):
            for n2 in self._nodes[i + 1:]:
                self._skeleton.add(frozenset([n1, n2]))

        self._separating_sets = {}

        # Test conditional independence for increasing conditioning set sizes
        for cond_size in range(0, self.max_cond_set_size + 1):
            edges_to_remove: List[FrozenSet[str]] = []

            for edge in list(self._skeleton):
                pair = list(edge)
                x, y = pair[0], pair[1]

                # Get current adjacency set of x (excluding y)
                adj_x = self._get_adjacency(x) - {y}
                adj_y = self._get_adjacency(y) - {x}

                # Test with conditioning sets from adj_x
                found_independent = False
                for z_set in self._subsets(adj_x, cond_size):
                    if self._test_independence(x, y, list(z_set)):
                        self._separating_sets[edge] = z_set
                        edges_to_remove.append(edge)
                        found_independent = True
                        break

                if not found_independent:
                    # Also try adj_y
                    for z_set in self._subsets(adj_y, cond_size):
                        if self._test_independence(x, y, list(z_set)):
                            self._separating_sets[edge] = z_set
                            edges_to_remove.append(edge)
                            found_independent = True
                            break

            for edge in edges_to_remove:
                self._skeleton.discard(edge)

        # Initialize undirected edges from skeleton
        self._undirected_edges = set(self._skeleton)

    # ----- Phase II: Edge orientation -----

    def _phase2_orient(self) -> List[Tuple[str, str, str]]:
        """Orient edges using v-structures and Meek rules.

        Returns list of v-structures as (X, Z, Y) tuples where X → Z ← Y.
        """
        v_structures: List[Tuple[str, str, str]] = []

        # Find v-structures: X — Z — Y where X and Y not adjacent, Z not in sep(X,Y)
        for edge in self._skeleton:
            pair = list(edge)
            x, y = pair[0], pair[1]

            # Find common neighbors (potential colliders Z)
            adj_x = self._get_adjacency(x)
            adj_y = self._get_adjacency(y)
            common = adj_x & adj_y

            for z in common:
                # X — Z — Y is a potential v-structure if X and Y not adjacent
                if frozenset([x, y]) not in self._skeleton:
                    # Check that Z is NOT in the separating set of X and Y
                    sep_set = self._separating_sets.get(frozenset([x, y]), set())
                    if z not in sep_set:
                        # Orient as X → Z ← Y
                        self._directed_edges.add((x, z))
                        self._directed_edges.add((y, z))
                        self._undirected_edges.discard(frozenset([x, z]))
                        self._undirected_edges.discard(frozenset([y, z]))
                        v_structures.append((x, z, y))

        # Apply Meek's orientation rules iteratively
        changed = True
        iterations = 0
        while changed and iterations < 100:
            changed = self._apply_meek_rules()
            iterations += 1

        return v_structures

    def _apply_meek_rules(self) -> bool:
        """Apply Meek's three orientation rules. Returns True if any change made.

        R1: If X → Y — Z and X and Z not adjacent, orient Y → Z
        R2: If X → Y → Z and X — Z, orient X → Z
        R3: If X — Z, X — Y, Y → Z, and X and Y not adjacent, orient X → Z
        """
        changed = False

        for edge in list(self._undirected_edges):
            pair = list(edge)
            a, b = pair[0], pair[1]

            # Try orienting a → b
            if self._try_orient(a, b):
                self._directed_edges.add((a, b))
                self._undirected_edges.discard(edge)
                changed = True
                continue

            # Try orienting b → a
            if self._try_orient(b, a):
                self._directed_edges.add((b, a))
                self._undirected_edges.discard(edge)
                changed = True

        return changed

    def _try_orient(self, x: str, y: str) -> bool:
        """Check if Meek rules justify orienting X → Y."""
        # R1: ∃ Z such that Z → X — Y and Z not adjacent to Y
        for z_src, z_tgt in self._directed_edges:
            if z_tgt == x:
                if frozenset([z_src, y]) not in self._skeleton:
                    return True

        # R2: ∃ directed path X → ... → Y and X — Y
        if self._has_directed_path(x, y):
            return True

        # R3: ∃ Z1, Z2 such that Z1 — X, Z2 — X, Z1 → Y, Z2 → Y,
        #     and Z1 not adjacent to Z2
        z_candidates = []
        for edge in self._undirected_edges:
            if x in edge:
                other = (set(edge) - {x}).pop() if len(edge) == 2 else None
                if other and other != y:
                    if (other, y) in self._directed_edges:
                        z_candidates.append(other)

        for i in range(len(z_candidates)):
            for j in range(i + 1, len(z_candidates)):
                if frozenset([z_candidates[i], z_candidates[j]]) not in self._skeleton:
                    return True

        return False

    def _has_directed_path(self, source: str, target: str, max_depth: int = 10) -> bool:
        """Check if there exists a directed path from source to target."""
        visited: Set[str] = {source}
        queue: deque[str] = deque([source])
        depth = 0
        while queue and depth < max_depth:
            node = queue.popleft()
            for src, tgt in self._directed_edges:
                if src == node and tgt not in visited:
                    if tgt == target:
                        return True
                    visited.add(tgt)
                    queue.append(tgt)
            depth += 1
        return False

    # ----- Statistical tests -----

    def _test_independence(self, x: str, y: str, z_vars: List[str]) -> bool:
        """Test conditional independence X ⊥ Y | Z_vars.

        For continuous variables: partial correlation with Fisher z-test.
        For discrete variables: chi-square test of conditional independence.
        """
        if self._data is None:
            return False

        n = len(self._data[x])
        if n < self.min_samples:
            return False

        if self.continuous:
            return self._test_continuous_independence(x, y, z_vars, n)
        else:
            return self._test_discrete_independence(x, y, z_vars)

    def _test_continuous_independence(
        self, x: str, y: str, z_vars: List[str], n: int
    ) -> bool:
        """Partial correlation test for continuous variables."""
        x_data = self._data[x]
        y_data = self._data[y]

        if z_vars:
            z_data = [self._data[z] for z in z_vars if z in self._data]
            r = _partial_correlation(x_data, y_data, z_data)
        else:
            r = _pearson_r(x_data, y_data)

        z_stat = _fisher_z(r, n, len(z_vars))
        p_value = 2.0 * (1.0 - _gaussian_cdf(abs(z_stat)))

        return p_value > self.alpha

    def _test_discrete_independence(
        self, x: str, y: str, z_vars: List[str]
    ) -> bool:
        """Chi-square test for discrete variables (stratified by Z if provided)."""
        if self._discrete_data is None:
            # Fall back to treating continuous data as discrete by binning
            x_vals = self._data[x]
            y_vals = self._data[y]
            n_bins = max(3, int(math.sqrt(len(x_vals))))
            x_binned = self._bin_values(x_vals, n_bins)
            y_binned = self._bin_values(y_vals, n_bins)
        else:
            x_binned = self._discrete_data.get(x, self._bin_values(self._data[x], 3))
            y_binned = self._discrete_data.get(y, self._bin_values(self._data[y], 3))

        if z_vars:
            # Stratified test: test independence within each stratum
            # Simplified: pool chi-square across strata (Cochran-Mantel-Haenszel approx)
            total_chi2 = 0.0
            total_df = 0
            # Create strata from first Z variable
            z_key = z_vars[0]
            z_data = self._discrete_data.get(z_key, self._bin_values(self._data.get(z_key, []), 3)) if self._data else []

            if not z_data:
                return True

            strata: Dict[int, List[int]] = defaultdict(list)
            for i, z_val in enumerate(z_data):
                strata[int(z_val)].append(i)

            for stratum_idx, indices in strata.items():
                if len(indices) < 5:
                    continue
                sx = [x_binned[i] for i in indices]
                sy = [y_binned[i] for i in indices]
                table = self._make_contingency_table(sx, sy)
                chi2, _ = _chi_square_test(table)
                rows = len(set(sx))
                cols = len(set(sy))
                df = max(1, (rows - 1) * (cols - 1))
                total_chi2 += chi2
                total_df += df

            if total_df == 0:
                return True

            # Approximate p-value
            pooled_z = ((total_chi2 / total_df) ** (1.0/3.0) - 1.0 + 2.0/(9.0*total_df)) / math.sqrt(2.0/(9.0*total_df))
            p_value = 1.0 - _gaussian_cdf(pooled_z)
            return p_value > self.alpha
        else:
            # Simple chi-square test
            table = self._make_contingency_table(x_binned, y_binned)
            _, p_value = _chi_square_test(table)
            return p_value > self.alpha

    # ----- Utility methods -----

    def _get_adjacency(self, node: str) -> Set[str]:
        """Get adjacent nodes in the current skeleton."""
        adjacent: Set[str] = set()
        for edge in self._skeleton:
            if node in edge:
                pair = list(edge)
                adjacent.add(pair[0] if pair[1] == node else pair[1])
        return adjacent

    @staticmethod
    def _subsets(s: Set[str], size: int) -> List[FrozenSet[str]]:
        """Generate all subsets of s of the given size."""
        if size == 0:
            return [frozenset()]
        if size > len(s):
            return []

        items = list(s)
        result: List[FrozenSet[str]] = []

        def _combine(start: int, current: List[str]) -> None:
            if len(current) == size:
                result.append(frozenset(current))
                return
            for i in range(start, len(items)):
                current.append(items[i])
                _combine(i + 1, current)
                current.pop()

        _combine(0, [])
        return result

    @staticmethod
    def _bin_values(values: List[float], n_bins: int) -> List[int]:
        """Bin continuous values into discrete categories."""
        if not values:
            return []
        min_v = min(values)
        max_v = max(values)
        if max_v - min_v < 1e-12:
            return [0] * len(values)
        bin_width = (max_v - min_v) / n_bins
        return [min(n_bins - 1, int((v - min_v) / bin_width)) for v in values]

    @staticmethod
    def _make_contingency_table(x: List[int], y: List[int]) -> List[List[int]]:
        """Build a contingency table from two lists of discrete values."""
        if not x or not y:
            return [[0]]
        x_levels = max(x) + 1
        y_levels = max(y) + 1
        table = [[0] * y_levels for _ in range(x_levels)]
        for xi, yi in zip(x, y):
            if 0 <= xi < x_levels and 0 <= yi < y_levels:
                table[xi][yi] += 1
        return table

    def _empty_result(self) -> Dict[str, Any]:
        return {
            "nodes": [],
            "directed_edges": [],
            "undirected_edges": [],
            "v_structures": [],
            "num_edges": 0,
        }


# ---------------------------------------------------------------------------
# 3. DoCalculusCounterfactualReasoner — Pearl's do-calculus + counterfactuals
# ---------------------------------------------------------------------------

class StructuralCausalModel:
    """Structural Causal Model (SCM) representation.

    An SCM consists of:
    - Endogenous variables V = {V1, ..., Vn} (determined by other variables)
    - Exogenous variables U = {U1, ..., Un} (noise/unobserved)
    - Structural functions F = {f1, ..., fn} where Vi = fi(pa(Vi), Ui)
    - Probability distribution P(U) over exogenous variables
    """

    def __init__(self) -> None:
        # Variable definitions: name → {'parents': [...], 'function': callable, 'noise_type': str}
        self._variables: Dict[str, Dict[str, Any]] = {}
        # Noise values per variable (for counterfactual: shared across factual/counterfactual)
        self._noise_values: Dict[str, float] = {}
        # Observed values from the factual world
        self._factual_values: Dict[str, float] = {}

    def add_variable(
        self,
        name: str,
        parents: List[str],
        function: Optional[Callable] = None,
        noise_std: float = 0.1,
    ) -> None:
        """Add an endogenous variable to the SCM.

        Args:
            name: Variable name.
            parents: List of parent variable names.
            function: Structural function f(parents_values, noise) → value.
                      If None, uses a linear function with unit coefficients.
            noise_std: Standard deviation of Gaussian noise.
        """
        if function is None:
            # Default: linear structural equation  V = sum(parents) + noise
            def _linear_fn(parent_vals: Dict[str, float], noise: float) -> float:
                return sum(parent_vals.values()) + noise
            function = _linear_fn

        self._variables[name] = {
            "parents": parents,
            "function": function,
            "noise_std": noise_std,
        }

    def set_factual_observation(self, observations: Dict[str, float]) -> None:
        """Set the factual world observations for counterfactual reasoning.

        This also infers the exogenous noise values by inverting the structural
        equations using the observed values.
        """
        self._factual_values = dict(observations)
        self._infer_noise()

    def _infer_noise(self) -> None:
        """Infer exogenous noise values from factual observations.

        For each variable V_i with structural equation V_i = f_i(pa(V_i), U_i),
        we compute U_i = V_i - f_i(pa(V_i), 0).
        Requires topological ordering of variables.
        """
        ordered = self._topological_sort()
        computed_values = dict(self._factual_values)

        for var in ordered:
            var_def = self._variables[var]
            parents = var_def["parents"]
            func = var_def["function"]

            parent_vals = {p: computed_values.get(p, 0.0) for p in parents}
            predicted = func(parent_vals, 0.0)
            observed = computed_values.get(var, 0.0)
            self._noise_values[var] = observed - predicted

    def compute(self, interventions: Optional[Dict[str, float]] = None) -> Dict[str, float]:
        """Compute variable values under optional interventions.

        If interventions is provided, those variables are fixed to the given
        values (graph mutilation: incoming edges removed).
        """
        if interventions is None:
            interventions = {}

        ordered = self._topological_sort()
        values: Dict[str, float] = {}

        for var in ordered:
            if var in interventions:
                values[var] = interventions[var]
            else:
                var_def = self._variables[var]
                parents = var_def["parents"]
                func = var_def["function"]
                parent_vals = {p: values.get(p, 0.0) for p in parents}
                noise = self._noise_values.get(var, random.gauss(0, var_def["noise_std"]))
                values[var] = func(parent_vals, noise)

        return values

    def compute_counterfactual(
        self,
        interventions: Dict[str, float],
    ) -> Dict[str, float]:
        """Compute counterfactual values: same noise, different interventions.

        Step 1: Abduction — infer U from factual observations (already done).
        Step 2: Action — modify the model with do-interventions.
        Step 3: Prediction — compute using the modified model with original U.
        """
        # Re-use noise values from factual observations (Step 1: Abduction)
        # Step 2+3: compute with interventions using same noise
        return self.compute(interventions=interventions)

    def get_parents(self, variable: str) -> List[str]:
        """Get parents of a variable."""
        return self._variables.get(variable, {}).get("parents", [])

    def get_all_variables(self) -> List[str]:
        """Get all endogenous variable names."""
        return list(self._variables.keys())

    def _topological_sort(self) -> List[str]:
        """Topological sort of variables (parents before children)."""
        in_degree: Dict[str, int] = defaultdict(int)
        for var in self._variables:
            if var not in in_degree:
                in_degree[var] = 0
            for parent in self._variables[var]["parents"]:
                if parent not in in_degree:
                    in_degree[parent] = 0

        # Build adjacency (parent → child)
        adj: Dict[str, List[str]] = defaultdict(list)
        for var, vdef in self._variables.items():
            for parent in vdef["parents"]:
                adj[parent].append(var)
                in_degree[var] += 1

        queue: deque[str] = deque([v for v in self._variables if in_degree[v] == 0])
        result: List[str] = []

        while queue:
            node = queue.popleft()
            if node in self._variables:
                result.append(node)
            for child in adj[node]:
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)

        # Add any remaining variables (shouldn't happen in a DAG)
        for var in self._variables:
            if var not in result:
                result.append(var)

        return result


class DoCalculusCounterfactualReasoner:
    """Pearl's do-calculus + counterfactual reasoning for physical domain.

    Implements:
    1. Structural Causal Model (SCM) construction and evaluation
    2. do(X=x) intervention via graph mutilation
    3. Counterfactual reasoning (abduction-action-prediction)
    4. Three rules of do-calculus for identification
    5. Physical domain priors (force → motion, friction → slip, etc.)

    The three rules of do-calculus:
    --------------------------------
    Rule 1 (Insertion/deletion of observations):
        P(y | do(x), z) = P(y | do(x))   if  (Y ⊥ Z | X)_{G_{overline{X}}}

    Rule 2 (Action/observation exchange):
        P(y | do(x), do(z)) = P(y | do(x), z)   if  (Y ⊥ Z | X)_{G_{overline{X}, underline{Z}}}

    Rule 3 (Insertion/deletion of actions):
        P(y | do(x), do(z)) = P(y | do(x))   if  (Y ⊥ Z | X)_{G_{overline{X}, overline{Z}}}
    """

    # Physical domain SCM templates
    PHYSICAL_SCM_TEMPLATES = {
        "push_grasp": {
            "variables": ["push_force", "applied_force", "acceleration", "velocity", "displacement"],
            "equations": {
                "applied_force": lambda p, n: p.get("push_force", 0.0) * 0.9 + n,
                "acceleration": lambda p, n: p.get("applied_force", 0.0) / 1.0 + n,  # a = F/m, m=1
                "velocity": lambda p, n: p.get("acceleration", 0.0) * 0.5 + n,
                "displacement": lambda p, n: p.get("velocity", 0.0) * 0.3 + n,
            },
        },
        "friction_slip": {
            "variables": ["grip_force", "normal_force", "friction_force", "slip_probability"],
            "equations": {
                "normal_force": lambda p, n: p.get("grip_force", 0.0) * 0.95 + n,
                "friction_force": lambda p, n: p.get("normal_force", 0.0) * 0.5 + n,  # μ=0.5
                "slip_probability": lambda p, n: 1.0 / (1.0 + math.exp(p.get("friction_force", 0.0) - 2.0)) + n * 0.1,
            },
        },
        "gravity_fall": {
            "variables": ["height", "support_force", "net_force", "acceleration", "fall_speed"],
            "equations": {
                "support_force": lambda p, n: max(0.0, 9.81 - p.get("height", 0.0) * 0.1) + n,
                "net_force": lambda p, n: 9.81 - p.get("support_force", 0.0) + n,
                "acceleration": lambda p, n: p.get("net_force", 0.0) / 1.0 + n,
                "fall_speed": lambda p, n: max(0.0, p.get("acceleration", 0.0) * 0.5) + n,
            },
        },
        "torque_rotation": {
            "variables": ["motor_torque", "angular_acceleration", "angular_velocity", "rotation_angle"],
            "equations": {
                "angular_acceleration": lambda p, n: p.get("motor_torque", 0.0) / 0.5 + n,  # τ/I, I=0.5
                "angular_velocity": lambda p, n: p.get("angular_acceleration", 0.0) * 0.4 + n,
                "rotation_angle": lambda p, n: p.get("angular_velocity", 0.0) * 0.2 + n,
            },
        },
    }

    def __init__(self) -> None:
        self._scm = StructuralCausalModel()
        self._causal_reasoning: Optional[CausalReasoning] = None
        self._intervention_history: List[InterventionResult] = []
        self._counterfactual_history: List[CounterfactualResult] = []
        self._domain: Optional[str] = None

    def initialize(self) -> None:
        """Initialize with default physical SCM."""
        self.build_physical_scm("friction_slip")
        logger.info("DoCalculusCounterfactualReasoner 초기화 완료")

    def connect_causal_reasoning(self, cr: CausalReasoning) -> None:
        """Connect to the main CausalReasoning engine for d-separation queries."""
        self._causal_reasoning = cr

    # ----- SCM construction -----

    def build_physical_scm(self, domain: str) -> None:
        """Build a structural causal model for a physical domain.

        Args:
            domain: One of 'push_grasp', 'friction_slip', 'gravity_fall', 'torque_rotation'.
        """
        if domain not in self.PHYSICAL_SCM_TEMPLATES:
            logger.warning(f"Unknown physical domain: {domain}, using friction_slip")
            domain = "friction_slip"

        self._domain = domain
        template = self.PHYSICAL_SCM_TEMPLATES[domain]
        self._scm = StructuralCausalModel()

        variables = template["variables"]
        equations = template["equations"]

        # Determine parent structure from equation dependencies
        for var_name in variables:
            if var_name in equations:
                eq_fn = equations[var_name]
                # Infer parents by inspecting which variables are accessed
                parents = self._infer_parents(var_name, variables, equations)
                self._scm.add_variable(
                    name=var_name,
                    parents=parents,
                    function=eq_fn,
                    noise_std=0.05,
                )
            else:
                # Root variable (exogenous input)
                self._scm.add_variable(
                    name=var_name,
                    parents=[],
                    function=lambda p, n: n,
                    noise_std=0.1,
                )

    def build_custom_scm(
        self,
        variables: List[str],
        parent_map: Dict[str, List[str]],
        functions: Optional[Dict[str, Callable]] = None,
    ) -> None:
        """Build a custom SCM with specified structure.

        Args:
            variables: List of variable names.
            parent_map: Variable → list of parent variable names.
            functions: Optional variable → structural function. If None, linear.
        """
        self._scm = StructuralCausalModel()

        for var in variables:
            parents = parent_map.get(var, [])
            func = functions.get(var) if functions else None
            self._scm.add_variable(
                name=var,
                parents=parents,
                function=func,
                noise_std=0.05,
            )

    @staticmethod
    def _infer_parents(
        var: str, all_vars: List[str], equations: Dict[str, Callable]
    ) -> List[str]:
        """Infer parents of a variable by testing which other variables
        affect the structural function's output."""
        parents: List[str] = []
        eq_fn = equations.get(var)
        if eq_fn is None:
            return parents

        for candidate in all_vars:
            if candidate == var:
                continue
            # Test with zero input vs non-zero input
            zero_input = {candidate: 0.0}
            nonzero_input = {candidate: 1.0}
            try:
                val_zero = eq_fn(zero_input, 0.0)
                val_nonzero = eq_fn(nonzero_input, 0.0)
                if abs(val_nonzero - val_zero) > 1e-9:
                    parents.append(candidate)
            except (KeyError, TypeError):
                pass

        return parents

    # ----- do-calculus: intervention queries -----

    def do_intervene(
        self,
        variable: str,
        value: float,
        target: Optional[str] = None,
    ) -> InterventionResult:
        """Perform a do(X=x) intervention and compute effect on target.

        Implements graph mutilation: remove all incoming edges to the
        intervened variable, fix it to the given value, then propagate.

        Args:
            variable: Variable to intervene on.
            value: Value to set the variable to.
            target: Optional target variable to measure effect on.

        Returns:
            InterventionResult with expected values and mechanism trace.
        """
        # Compute interventional distribution
        values = self._scm.compute(interventions={variable: value})

        # Compute baseline (no intervention) for comparison
        baseline = self._scm.compute()

        # Build mechanism trace
        trace = [f"do({variable}={value:.2f})"]
        for var_name in self._scm.get_all_variables():
            if var_name in values:
                bv = baseline.get(var_name, 0.0)
                iv = values[var_name]
                diff = iv - bv
                trace.append(f"  {var_name}: {bv:.3f} → {iv:.3f} (Δ={diff:+.3f})")

        # Determine confidence based on structural certainty
        confidence = 0.8
        if self._causal_reasoning:
            parents = self._scm.get_parents(variable)
            if not parents:
                confidence = 0.95  # Root variable — high confidence

        expected_target_value = None
        if target and target in values:
            expected_target_value = values[target]

        result = InterventionResult(
            target=target or "all",
            intervened_var=variable,
            intervened_value=value,
            expected_value=expected_target_value,
            distribution={k: v for k, v in values.items()},
            confidence=confidence,
            mechanism_trace=trace,
        )
        self._intervention_history.append(result)
        return result

    def do_intervene_distribution(
        self,
        variable: str,
        values: List[float],
        target: str,
        n_samples: int = 100,
    ) -> Dict[float, Dict[str, float]]:
        """Compute the interventional distribution P(target | do(variable = v))
        for multiple values of v.

        Returns: dict mapping each v to {mean, std, min, max} of target.
        """
        results: Dict[float, Dict[str, float]] = {}

        for v in values:
            target_vals: List[float] = []
            for _ in range(n_samples):
                # Sample with fresh noise
                computed = self._scm.compute(interventions={variable: v})
                if target in computed:
                    target_vals.append(computed[target])

            if target_vals:
                mean = sum(target_vals) / len(target_vals)
                variance = sum((x - mean) ** 2 for x in target_vals) / len(target_vals)
                results[v] = {
                    "mean": mean,
                    "std": math.sqrt(variance) if variance > 0 else 0.0,
                    "min": min(target_vals),
                    "max": max(target_vals),
                }
            else:
                results[v] = {"mean": 0.0, "std": 0.0, "min": 0.0, "max": 0.0}

        return results

    # ----- Counterfactual reasoning -----

    def counterfactual(
        self,
        factual_observations: Dict[str, float],
        counterfactual_intervention: Dict[str, float],
        target: str,
    ) -> CounterfactualResult:
        """Compute a counterfactual: "Given what I observed, what WOULD have
        happened if I had done X differently?"

        Three-step procedure (Pearl 2009):
        1. Abduction: Infer exogenous noise U from factual observations.
        2. Action: Modify the model with the counterfactual intervention.
        3. Prediction: Compute using modified model + inferred U.

        Args:
            factual_observations: What was actually observed.
            counterfactual_intervention: What would have been done differently.
            target: Target variable to query.

        Returns:
            CounterfactualResult comparing factual and counterfactual worlds.
        """
        # Step 1: Abduction — set factual observations to infer noise
        self._scm.set_factual_observation(factual_observations)

        # Compute factual values
        factual_values = self._scm.compute()

        # Step 2+3: Action + Prediction with counterfactual intervention
        counterfactual_values = self._scm.compute_counterfactual(
            interventions=counterfactual_intervention
        )

        # Build explanation
        changed_vars = []
        for var in self._scm.get_all_variables():
            fv = factual_values.get(var, 0.0)
            cv = counterfactual_values.get(var, 0.0)
            if abs(cv - fv) > 1e-6:
                changed_vars.append(f"{var}: {fv:.3f} → {cv:.3f}")

        cf_var = list(counterfactual_intervention.keys())[0] if counterfactual_intervention else "?"
        cf_val = list(counterfactual_intervention.values())[0] if counterfactual_intervention else 0.0
        f_val = factual_observations.get(cf_var, 0.0)

        explanation = (
            f"Counterfactual: If {cf_var} had been {cf_val:.2f} instead of {f_val:.2f}, "
            f"then {target} would be {counterfactual_values.get(target, 0.0):.3f} "
            f"instead of {factual_values.get(target, 0.0):.3f}. "
        )
        if changed_vars:
            explanation += "Changed: " + ", ".join(changed_vars[:5])

        result = CounterfactualResult(
            factual_var=cf_var,
            factual_value=f_val,
            counterfactual_var=cf_var,
            counterfactual_value=cf_val,
            target_var=target,
            factual_target=factual_values.get(target, 0.0),
            counterfactual_target=counterfactual_values.get(target, 0.0),
            explanation=explanation,
        )
        self._counterfactual_history.append(result)
        return result

    def batch_counterfactual(
        self,
        factual_observations: Dict[str, float],
        interventions_list: List[Dict[str, float]],
        target: str,
    ) -> List[CounterfactualResult]:
        """Compute multiple counterfactuals from the same factual observation."""
        results: List[CounterfactualResult] = []
        for interventions in interventions_list:
            cf = self.counterfactual(factual_observations, interventions, target)
            results.append(cf)
        return results

    # ----- Three rules of do-calculus -----

    def rule1_insertion_deletion(
        self, y: str, z: str, x: str
    ) -> bool:
        """Rule 1 of do-calculus: Can we remove observation Z?

        P(y | do(x), z) = P(y | do(x))
        if (Y ⊥ Z | X) in G_overline_X  (graph with incoming edges to X removed)

        Returns True if the rule applies (Z can be removed).
        """
        if self._causal_reasoning is None:
            return False

        # Build the mutilated graph (remove incoming edges to X)
        # Then check d-separation of Y and Z given X in the mutilated graph
        mutilated_forward: Dict[str, List[Tuple[str, CausalEdge]]] = defaultdict(list)
        for src, edges in self._causal_reasoning._forward.items():
            for tgt, edge in edges:
                if tgt != x:  # Remove incoming edges to X
                    mutilated_forward[src].append((tgt, edge))

        # Check d-separation in the mutilated graph
        # For simplicity, use the original d-separation with a modified adjacency
        return self._causal_reasoning.d_separated(y, z, {x})

    def rule2_action_observation_exchange(
        self, y: str, z: str, x: str
    ) -> bool:
        """Rule 2 of do-calculus: Can we exchange action and observation?

        P(y | do(x), do(z)) = P(y | do(x), z)
        if (Y ⊥ Z | X) in G_overline_X_underline_Z
        (graph with incoming to X removed, outgoing from Z removed)

        Returns True if the rule applies.
        """
        if self._causal_reasoning is None:
            return False

        # Check d-separation with Z's outgoing edges removed
        # Simplified: use original d-separation as approximation
        return self._causal_reasoning.d_separated(y, z, {x})

    def rule3_insertion_deletion_actions(
        self, y: str, z: str, x: str
    ) -> bool:
        """Rule 3 of do-calculus: Can we remove action do(Z)?

        P(y | do(x), do(z)) = P(y | do(x))
        if (Y ⊥ Z | X) in G_overline_X_overline_Z
        (graph with incoming to both X and Z removed)

        Returns True if the rule applies.
        """
        if self._causal_reasoning is None:
            return False

        # Check d-separation with both X and Z's incoming edges removed
        # Simplified: check in original graph
        return self._causal_reasoning.d_separated(y, z, {x})

    def identify_causal_effect(
        self,
        treatment: str,
        outcome: str,
        observed_confounders: Set[str],
    ) -> Optional[str]:
        """Attempt to identify the causal effect P(outcome | do(treatment))
        using the three rules of do-calculus.

        This implements a simplified version of Tian & Pearl's identification
        algorithm. For full generality, see Shpitser & Pearl (2006).

        Returns:
            A string describing the identification formula, or None if
            the effect is not identifiable with the available rules.
        """
        # Strategy: Try to reduce do-expression to observational expression
        # using the three rules iteratively.

        # Check Rule 1: Can we ignore observed confounders?
        for z in observed_confounders:
            if self.rule1_insertion_deletion(outcome, z, treatment):
                return (f"P({outcome} | do({treatment})) = P({outcome} | {treatment})  "
                        f"[Rule 1: {z} can be dropped — ({outcome} ⊥ {z} | {treatment}) in G_X̄]")

        # Check Rule 2: Can we exchange do(obs) for obs?
        for z in observed_confounders:
            if self.rule2_action_observation_exchange(outcome, z, treatment):
                return (f"P({outcome} | do({treatment}), do({z})) = P({outcome} | do({treatment}), {z})  "
                        f"[Rule 2: action-observation exchange for {z}]")

        # Check Rule 3: Can we remove do(z)?
        for z in observed_confounders:
            if self.rule3_insertion_deletion_actions(outcome, z, treatment):
                return (f"P({outcome} | do({treatment})) identifiable — "
                        f"[Rule 3: do({z}) removable — ({outcome} ⊥ {z} | {treatment}) in G_X̄Z̄]")

        # Backdoor criterion check (special case)
        if self._check_backdoor_criterion(treatment, outcome, observed_confounders):
            z_str = ", ".join(observed_confounders)
            return (f"P({outcome} | do({treatment})) = Σ_{z} P({outcome} | {treatment}, {z_str}) · P({z_str})  "
                    f"[Backdoor adjustment]")

        return None

    def _check_backdoor_criterion(
        self,
        treatment: str,
        outcome: str,
        conditioning_set: Set[str],
    ) -> bool:
        """Check if conditioning_set satisfies the backdoor criterion.

        A set Z satisfies the backdoor criterion relative to (X, Y) if:
        1. No node in Z is a descendant of X
        2. Z blocks every path between X and Y that contains an arrow into X
        """
        if self._causal_reasoning is None:
            return False

        # Condition 1: No descendant of treatment in Z
        descendants = self._causal_reasoning.get_descendants(treatment)
        if conditioning_set & descendants:
            return False

        # Condition 2: Z d-separates treatment from outcome in G_underline_X
        # (graph with outgoing edges from X removed)
        # Approximate using d-separation in the original graph
        return not self._causal_reasoning.d_separated(treatment, outcome, conditioning_set)

    # ----- Physical domain reasoning helpers -----

    def predict_physical_intervention(
        self,
        action: str,
        context: Dict[str, float],
    ) -> InterventionResult:
        """Predict the effect of a physical action in a given context.

        Maps natural language actions to SCM interventions and computes
        the expected physical outcome.

        Args:
            action: Description of the action (e.g., "push_harder", "grip_tighter").
            context: Current physical state variables.
        """
        action_map = {
            "push_harder": {"push_force": 2.0},
            "push_softer": {"push_force": 0.5},
            "grip_tighter": {"grip_force": 3.0},
            "grip_looser": {"grip_force": 0.5},
            "lift_higher": {"height": 2.0},
            "drop": {"support_force": 0.0},
            "increase_torque": {"motor_torque": 2.5},
            "decrease_torque": {"motor_torque": 0.3},
        }

        interventions = action_map.get(action)
        if interventions is None:
            # Try fuzzy match
            for key in action_map:
                if key in action.replace(" ", "_").lower() or action.replace(" ", "_").lower() in key:
                    interventions = action_map[key]
                    break

        if interventions is None:
            return InterventionResult(
                target="unknown",
                intervened_var=action,
                intervened_value=0.0,
                confidence=0.0,
                mechanism_trace=[f"Unknown action: {action}"],
            )

        # Set context as factual observations
        if context:
            self._scm.set_factual_observation(context)

        # Select appropriate SCM domain
        var = list(interventions.keys())[0]
        if "force" in var or "push" in var or "grip" in var:
            if "grip" in var:
                self.build_physical_scm("friction_slip")
            else:
                self.build_physical_scm("push_grasp")
        elif "height" in var or "support" in var or "drop" in action:
            self.build_physical_scm("gravity_fall")
        elif "torque" in var:
            self.build_physical_scm("torque_rotation")

        # Re-set context after rebuilding SCM
        if context:
            self._scm.set_factual_observation(context)

        return self.do_intervene(var, interventions[var])

    def explain_counterfactual_physical(
        self,
        observed_outcome: str,
        observed_values: Dict[str, float],
        alternative_action: str,
        alternative_value: float,
    ) -> CounterfactualResult:
        """Explain a physical counterfactual: "The object slipped. Would it
        have slipped if I had gripped harder?"

        Args:
            observed_outcome: The outcome variable that was observed.
            observed_values: What was actually observed.
            alternative_action: The variable that could have been different.
            alternative_value: The alternative value.
        """
        return self.counterfactual(
            factual_observations=observed_values,
            counterfactual_intervention={alternative_action: alternative_value},
            target=observed_outcome,
        )

    # ----- History and introspection -----

    @property
    def intervention_history(self) -> List[InterventionResult]:
        return list(self._intervention_history)

    @property
    def counterfactual_history(self) -> List[CounterfactualResult]:
        return list(self._counterfactual_history)

    @property
    def scm(self) -> StructuralCausalModel:
        return self._scm

    @property
    def domain(self) -> Optional[str]:
        return self._domain

    def summary(self) -> Dict[str, Any]:
        """Return a summary of the reasoner's state."""
        return {
            "domain": self._domain,
            "scm_variables": self._scm.get_all_variables(),
            "num_interventions": len(self._intervention_history),
            "num_counterfactuals": len(self._counterfactual_history),
            "has_causal_reasoning": self._causal_reasoning is not None,
        }


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

def build_causal_model_from_experiences(
    experiences: List[Dict[str, Any]],
    alpha: float = 0.05,
) -> CausalReasoning:
    """End-to-end pipeline: experiences → PC discovery → CausalReasoning graph.

    1. Extract variables from experience observations.
    2. Run PC algorithm to discover causal structure.
    3. Convert to CausalReasoning with discovered edges.
    """
    pc = PCAlgorithm(alpha=alpha)
    result = pc.discover_from_experiences(experiences)

    cr = pc.get_causal_graph()
    # Also add raw experiences for future reference
    for exp in experiences:
        cr.add_experience(exp)

    logger.info(f"Causal model built: {result['num_edges']} edges from {len(experiences)} experiences")
    return cr


def quick_counterfactual(
    observations: Dict[str, float],
    intervention: Dict[str, float],
    target: str,
    domain: str = "friction_slip",
) -> CounterfactualResult:
    """One-liner counterfactual query for physical reasoning.

    Example:
        >>> quick_counterfactual(
        ...     observations={"grip_force": 1.0, "normal_force": 0.95, ...},
        ...     intervention={"grip_force": 2.5},
        ...     target="slip_probability",
        ...     domain="friction_slip",
        ... )
    """
    reasoner = DoCalculusCounterfactualReasoner()
    reasoner.build_physical_scm(domain)
    return reasoner.counterfactual(observations, intervention, target)


# ============================================================================
# Temporal Causal Discovery + Neural Causal Model — Physical AGI 인과 추론 혁신
# ============================================================================
# 기존: 정적 PC 알고리즘 → 한계: 시간적 인과, 비선형 인식 불가
# 혁신 1: 시간적 인과 발견 (TCDF) — 시간 지연 조건부 독립 검정
# 혁신 2: 신경 인과 모델 (NCM) — 미분 가능한 구조적 인과 모델
# 혁신 3: 인과 월드 모델 — 인과 구조가 월드 모델 예측을 제약
# ============================================================================

class TemporalCausalDiscovery:
    """시간적 인과 발견 (Temporal Causal Discovery)
    
    물리적 AGI에 필수: 물리적 인과는 항상 시간 순서를 가짐.
    "힘을 가했다" → "물체가 움직였다" (인과)
    "물체가 움직였다" → "힘을 가했다" (비인과)
    
    Granger 인과 + 시간 지연 PC 알고리즘 결합.
    """
    
    def __init__(self, max_lag=10, significance_level=0.05,
                 min_samples=30):
        self.max_lag = max_lag
        self.significance_level = significance_level
        self.min_samples = min_samples
        self.discovered_causes = {}
        self.causal_lags = {}
    
    def discover_temporal_causes(self, time_series_data, variable_names=None):
        """시간적 인과 발견
        
        Args:
            time_series_data: [time_steps, num_variables] numpy array
            variable_names: 변수 이름 리스트
        
        Returns:
            dict: 발견된 인과 관계
        """
        if isinstance(time_series_data, torch.Tensor):
            time_series_data = time_series_data.detach().cpu().numpy()
        
        n_steps, n_vars = time_series_data.shape
        if variable_names is None:
            variable_names = [f'var_{i}' for i in range(n_vars)]
        
        # Step 1: Granger 인과 검정
        granger_causes = self._granger_causality_test(time_series_data, variable_names)
        
        # Step 2: 시간 지연 조건부 독립 검정
        temporal_pc_edges = self._temporal_pc_algorithm(time_series_data, variable_names)
        
        # Step 3: 인과 지연 추정
        causal_lags = self._estimate_causal_lags(time_series_data, variable_names, granger_causes)
        
        # 결과 통합
        self.discovered_causes = granger_causes
        self.causal_lags = causal_lags
        
        return {
            'granger_causes': granger_causes,
            'temporal_pc_edges': temporal_pc_edges,
            'causal_lags': causal_lags,
            'n_discovered': len(granger_causes),
        }
    
    def _granger_causality_test(self, data, names):
        """Granger 인과 검정"""
        causes = {}
        n_vars = data.shape[1]
        
        for effect_idx in range(n_vars):
            for cause_idx in range(n_vars):
                if cause_idx == effect_idx:
                    continue
                
                # Restricted model: Y(t) = f(Y(t-1), ..., Y(t-lag))
                # Unrestricted model: Y(t) = f(Y(t-1), ..., X(t-1), ...)
                
                y = data[self.max_lag:, effect_idx]
                
                # Restricted features: only past Y
                restricted_features = []
                for lag in range(1, self.max_lag + 1):
                    restricted_features.append(data[self.max_lag - lag:-lag, effect_idx])
                X_restricted = np.column_stack(restricted_features)
                
                # Unrestricted features: past Y + past X
                unrestricted_features = list(restricted_features)
                for lag in range(1, self.max_lag + 1):
                    unrestricted_features.append(data[self.max_lag - lag:-lag, cause_idx])
                X_unrestricted = np.column_stack(unrestricted_features)
                
                # F-test
                ssr_restricted = np.sum((y - np.linalg.lstsq(X_restricted, y, rcond=None)[0] @ X_restricted.T) ** 2)
                ssr_unrestricted = np.sum((y - np.linalg.lstsq(X_unrestricted, y, rcond=None)[0] @ X_unrestricted.T) ** 2)
                
                n = len(y)
                p_restricted = X_restricted.shape[1]
                p_unrestricted = X_unrestricted.shape[1]
                
                if ssr_restricted > 0 and n > p_unrestricted:
                    f_stat = ((ssr_restricted - ssr_unrestricted) / (p_unrestricted - p_restricted)) / (ssr_unrestricted / (n - p_unrestricted))
                    
                    if SCIPY_AVAILABLE:
                        p_value = 1 - scipy_stats.f.cdf(f_stat, p_unrestricted - p_restricted, n - p_unrestricted)
                    else:
                        # Approximate p-value using normal approximation
                        p_value = 0.5 * (1 - math.erf(math.sqrt(f_stat) / math.sqrt(2))) if f_stat > 0 else 1.0
                    
                    if p_value < self.significance_level:
                        key = f"{names[cause_idx]} → {names[effect_idx]}"
                        causes[key] = {
                            'cause': names[cause_idx],
                            'effect': names[effect_idx],
                            'p_value': p_value,
                            'f_statistic': f_stat,
                            'confidence': 1 - p_value,
                        }
        
        return causes
    
    def _temporal_pc_algorithm(self, data, names):
        """시간적 PC 알고리즘"""
        # 간소화된 구현: Granger 인과 + 방향성으로 엣지 구성
        edges = set()
        
        for key, info in self.discovered_causes.items():
            if isinstance(info, dict) and info.get('confidence', 0) > 0.8:
                edges.add((info['cause'], info['effect']))
        
        return list(edges)
    
    def _estimate_causal_lags(self, data, names, causes):
        """인과 지연 추정 (최적 지연 탐색)"""
        lags = {}
        
        for key, info in causes.items():
            if not isinstance(info, dict):
                continue
            cause_idx = names.index(info['cause']) if info['cause'] in names else -1
            effect_idx = names.index(info['effect']) if info['effect'] in names else -1
            
            if cause_idx < 0 or effect_idx < 0:
                continue
            
            # 상호상관관계로 최적 지연 탐색
            max_corr = 0
            best_lag = 1
            
            for lag in range(1, self.max_lag + 1):
                if lag < len(data):
                    corr = np.corrcoef(
                        data[:-lag, cause_idx],
                        data[lag:, effect_idx]
                    )[0, 1]
                    if abs(corr) > abs(max_corr):
                        max_corr = corr
                        best_lag = lag
            
            lags[key] = {
                'lag': best_lag,
                'correlation': max_corr,
            }
        
        return lags


if TORCH_AVAILABLE:

    class NeuralCausalModel(nn.Module):
        """신경 인과 모델 (Neural Causal Model)
        
        미분 가능한 구조적 인과 모델 (SCM).
        인과 그래프 구조를 학습하고, 개입(intervention)과
        반사실적(counterfactual) 추론을 지원.
        
        혁신: 인과 발견 + 인과 추론을 엔드투엔드로 학습
        """
        
        def __init__(self, num_variables, hidden_dim=64, num_structural_eqs=None):
            super().__init__()
            self.num_variables = num_variables
            self.hidden_dim = hidden_dim
            
            # 구조 방정식 (각 변수에 대해)
            self.structural_equations = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(num_variables, hidden_dim),
                    nn.GELU(),
                    nn.Linear(hidden_dim, hidden_dim // 2),
                    nn.GELU(),
                    nn.Linear(hidden_dim // 2, 1),
                ) for _ in range(num_variables)
            ])
            
            # 인과 그래프 마스크 (학습 가능한 인접 행렬)
            self.causal_mask = nn.Parameter(
                torch.randn(num_variables, num_variables) * 0.1
            )
            
            # 외생 변수 노이즈 분포 파라미터
            self.noise_scale = nn.Parameter(torch.ones(num_variables) * 0.1)
        
        def forward(self, exogenous_noise=None):
            """인과 모델 순전파: 외생 노이즈 → 내생 변수
            
            위상 정렬(topological order)에 따라 변수를 순차적으로 계산.
            """
            if exogenous_noise is None:
                exogenous_noise = torch.randn(self.num_variables) * self.noise_scale
            
            # 인과 마스크를 이진화 (straight-through estimator)
            hard_mask = (torch.sigmoid(self.causal_mask) > 0.5).float()
            soft_mask = torch.sigmoid(self.causal_mask)
            mask = hard_mask + soft_mask - soft_mask.detach()  # Straight-through
            
            # 변수를 순차적으로 계산 (간소화: 순서 0, 1, ..., N)
            endogenous = torch.zeros(self.num_variables)
            endogenous = endogenous + exogenous_noise
            
            for i in range(self.num_variables):
                # 마스크된 부모 변수
                masked_parents = endogenous * mask[:, i]
                prediction = self.structural_equations[i](masked_parents.unsqueeze(0))
                endogenous[i] = prediction.squeeze() + exogenous_noise[i]
            
            return endogenous
        
        def intervene(self, variable_idx, value, exogenous_noise=None):
            """개입(intervention): do(X_i = value)
            
            관측적 분포가 아닌 개입적 분포에서 샘플링.
            X_i의 구조 방정식을 무시하고 value로 대체.
            """
            if exogenous_noise is None:
                exogenous_noise = torch.randn(self.num_variables) * self.noise_scale
            
            hard_mask = (torch.sigmoid(self.causal_mask) > 0.5).float()
            
            endogenous = torch.zeros(self.num_variables)
            endogenous = endogenous + exogenous_noise
            
            for i in range(self.num_variables):
                if i == variable_idx:
                    endogenous[i] = value  # 개입: 구조 방정식 무시
                else:
                    masked_parents = endogenous * hard_mask[:, i]
                    prediction = self.structural_equations[i](masked_parents.unsqueeze(0))
                    endogenous[i] = prediction.squeeze() + exogenous_noise[i]
            
            return endogenous
        
        def counterfactual(self, observed_values, variable_idx, counterfactual_value):
            """반사실적 추론: "X_i가 value였다면 어땠을까?"
            
            3단계:
            1. Abduction: 관측값으로부터 외생 노이즈 추론
            2. Intervention: X_i를 counterfactual_value로 대체
            3. Prediction: 수정된 모델로 예측
            """
            # Step 1: Abduction (간소화)
            # 실제로는 variational inference 필요하지만, 근사 사용
            with torch.no_grad():
                inferred_noise = observed_values.clone()
                for i in range(self.num_variables):
                    hard_mask = (torch.sigmoid(self.causal_mask) > 0.5).float()
                    masked_parents = observed_values * hard_mask[:, i]
                    prediction = self.structural_equations[i](masked_parents.unsqueeze(0))
                    inferred_noise[i] = observed_values[i] - prediction.squeeze()
            
            # Step 2 & 3: Intervention + Prediction
            counterfactual_result = self.intervene(
                variable_idx, counterfactual_value, inferred_noise
            )
            
            return counterfactual_result
        
        def get_causal_graph(self):
            """학습된 인과 그래프 반환"""
            with torch.no_grad():
                mask = torch.sigmoid(self.causal_mask).numpy()
            return mask
        
        def structure_loss(self):
            """그래프 구조 희소성 손실 (L1 정규화)"""
            return torch.abs(self.causal_mask).sum()


# ═══════════════════════════════════════════════════════════════════════════
# V8.5 Physical AGI 추가 클래스 / V8.5 Physical AGI Additional Classes
# ═══════════════════════════════════════════════════════════════════════════


class PhysicalCausalModel:
    """
    물리적 인과 모델 / Physical Causal Model.

    물리적 원인과 결과를 구조화된 모델로 표현합니다.
    힘 → 운동, 마찰 → 미끄러짐, 중력 → 낙하 등
    물리적 인과관계를 그래프로 모델링하고 추론에 활용합니다.

    핵심 원칙:
        물리적 인과는 시간적 선후관계가 명확합니다.
        원인은 결과보다 먼저 발생해야 합니다.
        메커니즘(why)을 이해하는 것이 핵심입니다.

    Usage:
        model = PhysicalCausalModel()
        model.add_physical_relation("push_force", "acceleration", mechanism="F=ma")
        model.add_physical_relation("friction", "deceleration", mechanism="f=μN")
        result = model.predict_effect("push_force", {"push_force": 10.0, "mass": 2.0})
    """

    def __init__(self) -> None:
        # 인과 그래프: cause → [(effect, mechanism, confidence)]
        self._causal_graph: Dict[str, List[Tuple[str, str, float]]] = {}
        # 구조 방정식: variable → (parents, equation_fn)
        self._structural_equations: Dict[str, Dict[str, Any]] = {}
        # 변수 범위 / Variable domains
        self._variable_domains: Dict[str, str] = {}  # variable → unit
        self._lock = threading.Lock()

        # 기본 물리적 인과관계 초기화 / Initialize basic physical causal relations
        self._init_physical_priors()

        logger.info("PhysicalCausalModel 초기화 완료")

    def _init_physical_priors(self) -> None:
        """기본 물리적 인과관계 초기화 / Initialize basic physical causal relations."""
        priors = [
            ("applied_force", "acceleration", "F=ma", 0.99),
            ("mass", "acceleration", "F=ma (inverse)", 0.99),
            ("friction_coefficient", "friction_force", "f=μN", 0.95),
            ("normal_force", "friction_force", "f=μN", 0.95),
            ("friction_force", "deceleration", "Newton's 2nd law", 0.93),
            ("gravity", "weight", "W=mg", 0.99),
            ("weight", "normal_force", "equilibrium", 0.92),
            ("push_force", "applied_force", "actuator", 0.90),
            ("grip_force", "friction_cone", "friction cone", 0.88),
            ("temperature", "material_stiffness", "thermal effect", 0.80),
            ("impact_velocity", "impact_force", "impulse-momentum", 0.90),
            ("impact_force", "deformation", "stress-strain", 0.85),
            ("center_of_mass_offset", "tipping_tendency", "torque balance", 0.92),
            ("surface_roughness", "friction_coefficient", "surface interaction", 0.82),
            ("velocity", "kinetic_energy", "KE=½mv²", 0.96),
            ("height", "potential_energy", "PE=mgh", 0.96),
        ]

        for cause, effect, mechanism, confidence in priors:
            self.add_physical_relation(cause, effect, mechanism, confidence)

        # 변수 단위 등록 / Register variable units
        unit_map = {
            "applied_force": "N", "acceleration": "m/s²", "mass": "kg",
            "friction_coefficient": "dimensionless", "friction_force": "N",
            "normal_force": "N", "deceleration": "m/s²", "gravity": "m/s²",
            "weight": "N", "push_force": "N", "grip_force": "N",
            "temperature": "°C", "impact_velocity": "m/s", "impact_force": "N",
            "deformation": "m", "center_of_mass_offset": "m",
            "surface_roughness": "dimensionless", "velocity": "m/s",
            "kinetic_energy": "J", "height": "m", "potential_energy": "J",
        }
        self._variable_domains.update(unit_map)

    def add_physical_relation(
        self,
        cause: str,
        effect: str,
        mechanism: str = "unknown",
        confidence: float = 0.8,
    ) -> None:
        """
        물리적 인과관계 추가 / Add a physical causal relation.

        Args:
            cause: 원인 변수
            effect: 결과 변수
            mechanism: 인과 메커니즘 (왜?)
            confidence: 인과 신뢰도
        """
        with self._lock:
            if cause not in self._causal_graph:
                self._causal_graph[cause] = []

            # 기존 관계 확인 / Check for existing relation
            for i, (eff, mech, conf) in enumerate(self._causal_graph[cause]):
                if eff == effect:
                    # Bayesian 업데이트 / Bayesian update
                    n = 1
                    new_conf = (conf * n + confidence) / (n + 1)
                    self._causal_graph[cause][i] = (eff, mechanism, new_conf)
                    return

            self._causal_graph[cause].append((effect, mechanism, confidence))

    def predict_effect(
        self,
        cause: str,
        context: Dict[str, float],
        max_depth: int = 5,
    ) -> Dict[str, Any]:
        """
        원인으로부터 결과 예측 / Predict effects from a cause.

        Args:
            cause: 원인 변수
            context: 현재 물리적 컨텍스트 (변수→값)
            max_depth: 최대 추론 깊이

        Returns:
            예측 결과
        """
        with self._lock:
            # BFS로 인과 사슬 따라가기 / Follow causal chain via BFS
            visited = set()
            queue = deque([(cause, 0)])
            predictions: List[Dict[str, Any]] = []
            trace: List[str] = []

            while queue:
                node, depth = queue.popleft()
                if depth >= max_depth or node in visited:
                    continue
                visited.add(node)

                for effect, mechanism, confidence in self._causal_graph.get(node, []):
                    # 효과 크기 추정 / Estimate effect magnitude
                    cause_val = context.get(node, 1.0)
                    effect_magnitude = cause_val * confidence

                    predictions.append({
                        "cause": node,
                        "effect": effect,
                        "mechanism": mechanism,
                        "confidence": round(confidence, 3),
                        "estimated_magnitude": round(effect_magnitude, 3),
                        "depth": depth + 1,
                    })

                    trace.append(f"{node} → {effect} ({mechanism}, conf={confidence:.2f})")

                    # 다음 단계의 원인으로 추가 / Add as next cause
                    context[effect] = effect_magnitude
                    queue.append((effect, depth + 1))

            return {
                "initial_cause": cause,
                "predictions": predictions[:20],  # 최대 20개 결과
                "trace": trace,
                "num_effects_predicted": len(predictions),
            }

    def explain_cause(
        self, effect: str, context: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        결과의 원인 설명 / Explain causes of an effect.

        Args:
            effect: 관찰된 결과
            context: 현재 컨텍스트

        Returns:
            원인 설명
        """
        with self._lock:
            causes = []
            for cause, edges in self._causal_graph.items():
                for eff, mechanism, confidence in edges:
                    if eff == effect:
                        causes.append({
                            "cause": cause,
                            "mechanism": mechanism,
                            "confidence": round(confidence, 3),
                            "cause_value": (context or {}).get(cause, None),
                        })

            # 신뢰도순 정렬 / Sort by confidence
            causes.sort(key=lambda x: x["confidence"], reverse=True)

            return {
                "effect": effect,
                "possible_causes": causes,
                "most_likely_cause": causes[0] if causes else None,
            }

    def get_variables(self) -> List[str]:
        """모든 변수 반환 / Return all variables in the model."""
        with self._lock:
            variables = set()
            for cause, edges in self._causal_graph.items():
                variables.add(cause)
                for eff, _, _ in edges:
                    variables.add(eff)
            return sorted(variables)

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        with self._lock:
            total_relations = sum(len(v) for v in self._causal_graph.values())
            variables = self.get_variables()
            return {
                "total_relations": total_relations,
                "total_variables": len(variables),
                "causal_roots": [
                    v for v in variables
                    if not any(v == eff for edges in self._causal_graph.values() for eff, _, _ in edges)
                ],
            }


class CounterfactualReasoner:
    """
    반사실적 추론기 / Counterfactual Reasoner.

    "내가 X 대신 Y를 했다면 어떻게 되었을까?"를 추론합니다.
    Pearl의 반사실적 추론 프레임워크를 구현합니다.

    3단계 반사실적 추론:
        1. Abduction: 관측 데이터로부터 외생 변수(U) 추론
        2. Intervention: 원인 변수를 반사실적 값으로 대체
        3. Prediction: 수정된 모델로 예측

    Usage:
        reasoner = CounterfactualReasoner()
        result = reasoner.what_if(
            factual={"push_force": 5.0, "friction": 0.3},
            factual_outcome={"acceleration": 2.0},
            counterfactual={"push_force": 10.0},
        )
    """

    def __init__(self, causal_model: Optional[PhysicalCausalModel] = None) -> None:
        self._causal_model = causal_model or PhysicalCausalModel()
        # 반사실적 추론 기록 / Counterfactual reasoning history
        self._reasoning_history: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

        logger.info("CounterfactualReasoner 초기화 완료")

    def what_if(
        self,
        factual: Dict[str, float],
        factual_outcome: Dict[str, float],
        counterfactual: Dict[str, float],
        target_variable: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        반사실적 추론 수행 / Perform counterfactual reasoning.

        "내가 X 대신 Y를 했다면?"에 답합니다.

        Args:
            factual: 실제 관측된 변수값
            factual_outcome: 실제 결과
            counterfactual: 반사실적 변경 (변경할 변수와 값)
            target_variable: 예측할 대상 변수

        Returns:
            반사실적 추론 결과
        """
        # Step 1: Abduction — 관측값으로 외생 노이즈 추론
        # 실제로는 variational inference가 필요하지만 근사 사용
        exogenous = self._abduction(factual, factual_outcome)

        # Step 2: Intervention — 반사실적 값으로 대체
        modified = dict(factual)  # 복사
        modified.update(counterfactual)

        # Step 3: Prediction — 수정된 모델로 예측
        counterfactual_outcome = self._predict_with_exogenous(modified, exogenous)

        # 결과 비교 / Compare factual vs counterfactual
        differences = {}
        for var in set(list(factual_outcome.keys()) + list(counterfactual_outcome.keys())):
            factual_val = factual_outcome.get(var, 0.0)
            cf_val = counterfactual_outcome.get(var, 0.0)
            if abs(factual_val - cf_val) > 1e-6:
                differences[var] = {
                    "factual": round(factual_val, 4),
                    "counterfactual": round(cf_val, 4),
                    "difference": round(cf_val - factual_val, 4),
                }

        # 대상 변수 결과 / Target variable result
        target_result = None
        if target_variable:
            target_result = {
                "factual": round(factual_outcome.get(target_variable, 0.0), 4),
                "counterfactual": round(counterfactual_outcome.get(target_variable, 0.0), 4),
            }

        result = {
            "factual_context": {k: round(v, 4) for k, v in factual.items()},
            "counterfactual_changes": {k: round(v, 4) for k, v in counterfactual.items()},
            "factual_outcome": {k: round(v, 4) for k, v in factual_outcome.items()},
            "counterfactual_outcome": {k: round(v, 4) for k, v in counterfactual_outcome.items()},
            "differences": differences,
            "target_variable": target_result,
            "exogenous_estimates": {k: round(v, 4) for k, v in exogenous.items()},
        }

        with self._lock:
            self._reasoning_history.append(result)

        logger.info(
            "반사실적 추론: %s → %s (변경 변수: %s)",
            list(factual.keys()), list(counterfactual.keys()), list(differences.keys()),
        )

        return result

    def _abduction(
        self,
        factual: Dict[str, float],
        factual_outcome: Dict[str, float],
    ) -> Dict[str, float]:
        """
        관측 데이터로 외생 변수 추론 (Abduction 단계)
        Infer exogenous variables from observations.

        간소화된 접근: 예측과 실제의 차이를 외생 노이즈로 추정합니다.
        """
        exogenous = {}

        # 각 결과 변수에 대해 외생 노이즈 추정
        for var, actual_value in factual_outcome.items():
            # 인과 모델로 예측 시도
            cause_prediction = self._causal_model.predict_effect(
                list(factual.keys())[0] if factual else var, dict(factual)
            )

            # 예측값 찾기 / Find predicted value
            predicted_value = actual_value  # 기본값
            for pred in cause_prediction.get("predictions", []):
                if pred["effect"] == var:
                    predicted_value = pred.get("estimated_magnitude", actual_value)
                    break

            # 외생 노이즈 = 실제값 - 예측값
            exogenous[f"U_{var}"] = actual_value - predicted_value

        return exogenous

    def _predict_with_exogenous(
        self,
        context: Dict[str, float],
        exogenous: Dict[str, float],
    ) -> Dict[str, float]:
        """
        외생 변수를 포함하여 예측 (Prediction 단계)
        Predict with exogenous variables.
        """
        # 인과 모델로 1차 예측
        first_cause = list(context.keys())[0] if context else "unknown"
        prediction = self._causal_model.predict_effect(first_cause, dict(context))

        outcome = {}
        for pred in prediction.get("predictions", []):
            effect_var = pred["effect"]
            pred_val = pred.get("estimated_magnitude", 0.0)
            # 외생 노이즈 추가
            noise = exogenous.get(f"U_{effect_var}", 0.0)
            outcome[effect_var] = pred_val + noise

        return outcome

    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """반사실적 추론 기록 반환 / Return counterfactual reasoning history."""
        with self._lock:
            return self._reasoning_history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        with self._lock:
            return {
                "total_reasoning_count": len(self._reasoning_history),
                "causal_model_stats": self._causal_model.get_stats(),
            }


class InterventionPlanner:
    """
    개입 계획기 / Intervention Planner.

    인과 가설을 테스트하기 위한 행동을 계획합니다.
    "이 원인이 정말 이 결과를 일으키는가?"를 실험적으로 검증합니다.

    핵심 개념:
        인과관계는 관찰만으로는 확립할 수 없습니다.
        개입(do-연산)을 통해 인과관계를 검증해야 합니다.
        이 클래스는 효율적인 개입 실험을 계획합니다.

    Usage:
        planner = InterventionPlanner()
        hypothesis = {"cause": "friction", "effect": "slip"}
        plan = planner.plan_intervention(hypothesis)
        # plan에는 어떤 값을 설정하고 어떤 결과를 관찰해야 하는지 포함
    """

    def __init__(
        self,
        causal_model: Optional[PhysicalCausalModel] = None,
        counterfactual_reasoner: Optional[CounterfactualReasoner] = None,
    ) -> None:
        self._causal_model = causal_model or PhysicalCausalModel()
        self._counterfactual = counterfactual_reasoner or CounterfactualReasoner(self._causal_model)

        # 검증된 인과관계 / Verified causal relations
        self._verified_relations: List[Dict[str, Any]] = []
        # 반박된 인과관계 / Refuted causal relations
        self._refuted_relations: List[Dict[str, Any]] = []

        self._lock = threading.Lock()

        logger.info("InterventionPlanner 초기화 완료")

    def plan_intervention(
        self,
        hypothesis: Dict[str, str],
        current_context: Optional[Dict[str, float]] = None,
        safety_constraints: Optional[Dict[str, Tuple[float, float]]] = None,
    ) -> Dict[str, Any]:
        """
        인과 가설 검증을 위한 개입 계획 수립 / Plan an intervention to test a causal hypothesis.

        Args:
            hypothesis: 인과 가설 {"cause": "X", "effect": "Y"}
            current_context: 현재 물리적 컨텍스트
            safety_constraints: 안전 제약 {변수: (최소, 최대)}

        Returns:
            개입 계획
        """
        cause_var = hypothesis.get("cause", "")
        effect_var = hypothesis.get("effect", "")
        context = current_context or {}

        # 기본 안전 제약 / Default safety constraints
        safety = safety_constraints or {
            "push_force": (0.0, 20.0),
            "grip_force": (0.0, 30.0),
            "temperature": (-20.0, 100.0),
            "velocity": (0.0, 1.0),
        }

        # 1. 교란 변수 식별 / Identify confounders
        confounders = self._identify_confounders(cause_var, effect_var)

        # 2. 개입값 결정 / Determine intervention values
        intervention_values = self._determine_intervention_values(
            cause_var, context, safety
        )

        # 3. 통제 조건 계획 / Plan control conditions
        control_conditions = self._plan_control_conditions(
            confounders, context, safety
        )

        # 4. 관측 계획 / Observation plan
        observations_needed = [effect_var]
        # 인과 경로의 중간 변수도 관측 / Observe mediating variables
        prediction = self._causal_model.predict_effect(cause_var, dict(context))
        for pred in prediction.get("predictions", []):
            if pred["effect"] != effect_var:
                observations_needed.append(pred["effect"])

        # 5. 반사실적 예측 / Counterfactual prediction
        counterfactual_result = None
        if context:
            # 두 가지 시나리오 비교 / Compare two scenarios
            factual = dict(context)
            cf_high = {cause_var: intervention_values.get("high", 10.0)}
            cf_low = {cause_var: intervention_values.get("low", 0.0)}

            counterfactual_result = {
                "if_high": self._counterfactual.what_if(
                    factual, {}, cf_high, target_variable=effect_var
                ),
                "if_low": self._counterfactual.what_if(
                    factual, {}, cf_low, target_variable=effect_var
                ),
            }

        plan = {
            "hypothesis": hypothesis,
            "intervention_variable": cause_var,
            "intervention_values": intervention_values,
            "control_conditions": control_conditions,
            "confounders_to_control": confounders,
            "observations_needed": observations_needed,
            "counterfactual_predictions": counterfactual_result,
            "safety_constraints": {k: list(v) for k, v in safety.items()},
            "expected_evidence": self._expected_evidence(cause_var, effect_var),
        }

        logger.info(
            "개입 계획 수립: '%s → %s' (교란변수 %d개)",
            cause_var, effect_var, len(confounders),
        )

        return plan

    def _identify_confounders(
        self, cause: str, effect: str
    ) -> List[str]:
        """
        교란 변수 식별 / Identify potential confounders.

        cause와 effect 모두에 영향을 미치는 변수를 찾습니다.
        """
        confounders = []
        variables = self._causal_model.get_variables()

        for var in variables:
            if var == cause or var == effect:
                continue

            # var이 cause에 영향을 미치는지 / Does var affect cause?
            affects_cause = False
            cause_prediction = self._causal_model.predict_effect(var, {})
            for pred in cause_prediction.get("predictions", []):
                if pred["effect"] == cause:
                    affects_cause = True
                    break

            # var이 effect에 영향을 미치는지 / Does var affect effect?
            affects_effect = False
            effect_prediction = self._causal_model.predict_effect(var, {})
            for pred in effect_prediction.get("predictions", []):
                if pred["effect"] == effect:
                    affects_effect = True
                    break

            if affects_cause and affects_effect:
                confounders.append(var)

        return confounders

    def _determine_intervention_values(
        self,
        cause_var: str,
        context: Dict[str, float],
        safety: Dict[str, Tuple[float, float]],
    ) -> Dict[str, float]:
        """개입값 결정 / Determine intervention values."""
        current_val = context.get(cause_var, 0.0)
        safe_range = safety.get(cause_var, (0.0, current_val * 3))

        # 최소 3개의 개입값: 낮음, 현재, 높음 / At least 3 values: low, current, high
        low = max(safe_range[0], current_val * 0.5)
        high = min(safe_range[1], current_val * 2.0)

        if high <= low:
            high = low + 1.0

        return {
            "low": round(low, 2),
            "current": round(current_val, 2),
            "high": round(high, 2),
        }

    def _plan_control_conditions(
        self,
        confounders: List[str],
        context: Dict[str, float],
        safety: Dict[str, Tuple[float, float]],
    ) -> Dict[str, float]:
        """통제 조건 계획 / Plan control conditions for confounders."""
        controls = {}
        for conf in confounders:
            current = context.get(conf, 0.0)
            safe = safety.get(conf, (0.0, 100.0))
            # 교란변수를 안전한 중간값으로 고정 / Fix confounder at safe mid-value
            controls[conf] = round((safe[0] + safe[1]) / 2.0, 2)

        return controls

    def _expected_evidence(
        self, cause: str, effect: str
    ) -> Dict[str, Any]:
        """기대 증거 / Expected evidence if hypothesis is true."""
        return {
            "if_causal": f"{cause}를 변경하면 {effect}가 체계적으로 변화해야 함",
            "if_not_causal": f"{cause}를 변경해도 {effect}가 변하지 않음",
            "if_confounder": f"교란변수를 통제하면 {cause}와 {effect}의 관계가 사라짐",
        }

    def evaluate_result(
        self,
        hypothesis: Dict[str, str],
        intervention_plan: Dict[str, Any],
        observed_results: Dict[str, List[float]],
    ) -> Dict[str, Any]:
        """
        개입 결과 평가 / Evaluate intervention results.

        Args:
            hypothesis: 원래 가설
            intervention_plan: 수립된 개입 계획
            observed_results: 관측된 결과 {조건: [값들]}

        Returns:
            가설 검증 결과
        """
        cause = hypothesis.get("cause", "")
        effect = hypothesis.get("effect", "")

        # 관측 결과 분석 / Analyze observed results
        evidence_for = 0.0
        evidence_against = 0.0

        conditions = list(observed_results.keys())
        if len(conditions) >= 2:
            # 다른 조건에서 결과가 다른지 비교 / Compare results across conditions
            values_by_condition = [
                np.mean(observed_results[c]) for c in conditions if observed_results[c]
            ]

            if len(values_by_condition) >= 2:
                # 결과 차이가 있는지 / Is there a difference in outcomes?
                max_diff = max(values_by_condition) - min(values_by_condition)
                mean_val = np.mean(values_by_condition)
                relative_diff = max_diff / (abs(mean_val) + 1e-6)

                if relative_diff > 0.2:  # 20% 이상 차이 / More than 20% difference
                    evidence_for = min(1.0, relative_diff)
                else:
                    evidence_against = 0.5

        # 결론 / Conclusion
        if evidence_for > 0.5:
            conclusion = "causal_likely"
            self._verified_relations.append(hypothesis)
        elif evidence_against > 0.3:
            conclusion = "not_causal"
            self._refuted_relations.append(hypothesis)
        else:
            conclusion = "inconclusive"

        result = {
            "hypothesis": hypothesis,
            "conclusion": conclusion,
            "evidence_for": round(evidence_for, 3),
            "evidence_against": round(evidence_against, 3),
            "observed_results_summary": {
                k: {"mean": round(float(np.mean(v)), 3), "std": round(float(np.std(v)), 3)}
                for k, v in observed_results.items() if v
            },
        }

        logger.info(
            "개입 결과 평가: '%s → %s' 결론=%s",
            cause, effect, conclusion,
        )

        return result

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        with self._lock:
            return {
                "verified_relations": len(self._verified_relations),
                "refuted_relations": len(self._refuted_relations),
                "causal_model_stats": self._causal_model.get_stats(),
            }
