#!/usr/bin/env python3
"""
지훈 로봇 V8.5 - 물리적 경험 기반 연속 학습 엔진
Jihun Robot V8.5 - Continuous Physical Learning Engine

TODO 41-48: 연속 학습 엔진 (Physical AGI 재설계)
로봇이 물리적으로 행동하면서 끊임없이 학습하고 파인튜닝되는 엔진입니다.
매 스텝, 매 파지, 매 지형 횡단이 학습 기회입니다.

핵심 원칙:
    WORLD DATA = 물리적 경험. 웹 크롤링이 아님.
    로봇은 직접 물리적으로 행동하면서 끊임없이 파인튜닝됩니다.
    PRIMITIVE ACTION을 더 자유자재로 활용하는 것이 목표입니다.

하드웨어: Dual Jetson Orin NX 16GB
AI 모델: Gemma 4 E4B Q4_K_M
작성일: 2026-05-19
버전: V8.5.4 — Physical AGI 재설계
"""

from __future__ import annotations

import json
import heapq
import logging
import math
import random
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Set, Tuple, Union

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.continuous_physical_learner")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 열거형 / Enums ─────────────────────────────────────────────────────────


class SkillCategory(str, Enum):
    """스킬 카테고리 / Skill categories."""
    LOCOMOTION = "locomotion"
    TERRAIN_NAVIGATION = "terrain_navigation"
    LIFTING = "lifting"
    CARRYING = "carrying"
    PRECISE_MANIPULATION = "precise_manipulation"
    CRAFTWORK = "craftwork"
    TOOL_USE = "tool_use"
    MULTI_STEP = "multi_step"
    EXPLORATION = "exploration"


class LearningPhase(str, Enum):
    """학습 단계 / Learning phases."""
    IDLE = "idle"
    COLLECTING = "collecting"
    TRAINING = "training"
    VALIDATING = "validating"
    DEPLOYING = "deploying"
    CONSOLIDATING = "consolidating"
    DREAMING = "dreaming"


class ReplayStrategy(str, Enum):
    """경험 재생 전략 / Experience replay strategies."""
    UNIFORM = "uniform"
    RECENT = "recent"
    HIGH_REWARD = "high_reward"
    HIGH_ERROR = "high_error"
    NOVEL = "novel"
    CURRICULUM = "curriculum"


# ─── 데이터 클래스 / Data Classes ───────────────────────────────────────────


@dataclass
class PhysicalSkill:
    """
    학습된 물리적 스킬 / Learned physical skill.

    로봇이 습득한 각 물리적 능력을 추적합니다.
    마스터리 레벨, 시도 횟수, 성공률, 학습 곡선을 관리합니다.

    Attributes:
        skill_id: 스킬 식별자
        name: 스킬 이름 (예: "rough_terrain_walking")
        category: 스킬 카테고리
        mastery_level: 숙련도 (0.0=미시도, 1.0=전문가)
        attempt_count: 시도 횟수
        success_count: 성공 횟수
        best_performance: 최고 성능 기록
        last_practiced: 마지막 연습 시각
        learning_curve: 학습 곡선 (최근 N 성공률)
        lora_adapter_id: 연결된 LoRA 어댑터
    """
    skill_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    name: str = ""
    category: SkillCategory = SkillCategory.LOCOMOTION
    mastery_level: float = 0.0
    attempt_count: int = 0
    success_count: int = 0
    best_performance: Dict[str, float] = field(default_factory=dict)
    last_practiced: str = ""
    learning_curve: List[float] = field(default_factory=list)
    lora_adapter_id: str = ""

    @property
    def success_rate(self) -> float:
        """성공률 / Success rate."""
        return self.success_count / max(1, self.attempt_count)

    def record_attempt(self, success: bool, performance: Dict[str, float] = None) -> None:
        """시도 기록 / Record attempt."""
        self.attempt_count += 1
        if success:
            self.success_count += 1
        self.last_practiced = datetime.now(timezone.utc).isoformat()

        # 학습 곡선 업데이트 / Update learning curve
        self.learning_curve.append(1.0 if success else 0.0)
        if len(self.learning_curve) > 50:
            self.learning_curve = self.learning_curve[-50:]

        # 마스터리 레벨 갱신 / Update mastery level
        if self.attempt_count >= 5:
            recent = self.learning_curve[-10:] if len(self.learning_curve) >= 10 else self.learning_curve
            self.mastery_level = float(np.mean(recent))

        # 최고 성능 갱신 / Update best performance
        if performance:
            for key, val in performance.items():
                if key not in self.best_performance or val > self.best_performance[key]:
                    self.best_performance[key] = val


@dataclass
class LoRAAdapter:
    """
    LoRA 어댑터 / LoRA adapter for physical skill fine-tuning.

    Attributes:
        adapter_id: 어댑터 식별자
        category: 스킬 카테고리
        rank: LoRA 랭크
        input_dim: 입력 차원 (하드코딩 4096 제거)
        output_dim: 출력 차원
        weights: 가중치 딕셔너리 (간소화된 표현)
        prev_weights: 이전 태스크의 가중치 (EWC star 파라미터)
        fisher_information: Fisher 정보 행렬 (EWC 정규화용, 기울기 제곱 기반)
        training_steps: 학습 스텝 수
        created_at: 생성 시각
    """
    adapter_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    category: SkillCategory = SkillCategory.LOCOMOTION
    rank: int = 8
    input_dim: int = 256
    output_dim: int = 256
    weights: Dict[str, np.ndarray] = field(default_factory=dict)
    prev_weights: Dict[str, np.ndarray] = field(default_factory=dict)
    fisher_information: Dict[str, np.ndarray] = field(default_factory=dict)
    training_steps: int = 0
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class PhysicalExperienceRecord:
    """
    물리적 경험 기록 / Physical experience record for replay.

    Attributes:
        record_id: 기록 식별자
        task_type: 작업 유형
        terrain_type: 지형 유형
        primitive_actions: 수행한 원시 행동 목록
        outcome: 결과 (성공/실패, 정밀도, 안정성 등)
        reward: 복합 보상
        priority: 재생 우선순위
        prediction_error: 모델 예측 오차
        novelty: 새로움 점수
        timestamp: 발생 시각
    """
    record_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    task_type: str = ""
    terrain_type: str = "flat"
    primitive_actions: List[str] = field(default_factory=list)
    outcome: Dict[str, Any] = field(default_factory=dict)
    reward: float = 0.0
    priority: float = 1.0
    prediction_error: float = 0.0
    novelty: float = 0.0
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ─── SQLite 저장소 / SQLite Repository ──────────────────────────────────────


class PhysicalLearningRepository:
    """물리적 학습 데이터 SQLite 저장소 / Physical learning SQLite repository."""

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS skills (
        skill_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        mastery_level REAL DEFAULT 0.0,
        attempt_count INTEGER DEFAULT 0,
        success_count INTEGER DEFAULT 0,
        best_performance_json TEXT,
        last_practiced TEXT,
        learning_curve_json TEXT,
        lora_adapter_id TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_skill_category ON skills(category);
    CREATE INDEX IF NOT EXISTS idx_skill_mastery ON skills(mastery_level);

    CREATE TABLE IF NOT EXISTS experience_records (
        record_id TEXT PRIMARY KEY,
        task_type TEXT,
        terrain_type TEXT,
        outcome_json TEXT,
        reward REAL,
        priority REAL DEFAULT 1.0,
        prediction_error REAL DEFAULT 0.0,
        novelty REAL DEFAULT 0.0,
        timestamp TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_exp_task ON experience_records(task_type);
    CREATE INDEX IF NOT EXISTS idx_exp_priority ON experience_records(priority DESC);

    CREATE TABLE IF NOT EXISTS lora_checkpoints (
        adapter_id TEXT PRIMARY KEY,
        category TEXT NOT NULL,
        rank INTEGER,
        training_steps INTEGER DEFAULT 0,
        weights_json TEXT,
        fisher_json TEXT,
        created_at TEXT,
        updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS training_history (
        step INTEGER PRIMARY KEY AUTOINCREMENT,
        loss REAL,
        validation_score REAL,
        experiences_used INTEGER,
        skill_category TEXT,
        duration_seconds REAL,
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP
    );
    """

    def __init__(self, db_path: Union[str, Path] = "physical_learning.db") -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()
        logger.info("PhysicalLearningRepository 초기화: %s", self._db_path)

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(
                str(self._db_path), check_same_thread=False
            )
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript(self.SCHEMA)
        conn.commit()

    def save_skill(self, skill: PhysicalSkill) -> bool:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT OR REPLACE INTO skills
                (skill_id, name, category, mastery_level, attempt_count,
                 success_count, best_performance_json, last_practiced,
                 learning_curve_json, lora_adapter_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    skill.skill_id, skill.name, skill.category.value,
                    skill.mastery_level, skill.attempt_count, skill.success_count,
                    json.dumps(skill.best_performance, default=str),
                    skill.last_practiced,
                    json.dumps(skill.learning_curve),
                    skill.lora_adapter_id,
                ),
            )
            conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error("스킬 저장 실패: %s", e)
            return False

    def save_experience(self, exp: PhysicalExperienceRecord) -> bool:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT OR REPLACE INTO experience_records
                (record_id, task_type, terrain_type, outcome_json, reward,
                 priority, prediction_error, novelty, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    exp.record_id, exp.task_type, exp.terrain_type,
                    json.dumps(exp.outcome, default=str), exp.reward,
                    exp.priority, exp.prediction_error, exp.novelty,
                    exp.timestamp,
                ),
            )
            conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error("경험 기록 저장 실패: %s", e)
            return False

    def save_training_step(
        self,
        loss: float,
        validation_score: float,
        experiences_used: int,
        skill_category: str,
        duration_seconds: float,
    ) -> None:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT INTO training_history
                (loss, validation_score, experiences_used, skill_category, duration_seconds)
                VALUES (?, ?, ?, ?, ?)""",
                (loss, validation_score, experiences_used, skill_category, duration_seconds),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("학습 스텝 기록 실패: %s", e)

    def get_skills_by_category(self, category: str) -> List[Dict]:
        try:
            conn = self._get_conn()
            rows = conn.execute(
                "SELECT * FROM skills WHERE category = ?", (category,)
            ).fetchall()
            return [dict(r) for r in rows]
        except sqlite3.Error:
            return []

    def get_stats(self) -> Dict[str, Any]:
        try:
            conn = self._get_conn()
            total_skills = conn.execute("SELECT COUNT(*) FROM skills").fetchone()[0]
            avg_mastery = conn.execute("SELECT AVG(mastery_level) FROM skills").fetchone()[0] or 0.0
            total_exp = conn.execute("SELECT COUNT(*) FROM experience_records").fetchone()[0]
            return {
                "total_skills": total_skills,
                "avg_mastery": round(avg_mastery, 3),
                "total_experiences": total_exp,
            }
        except sqlite3.Error:
            return {}


# ─── 물리적 LoRA 관리자 / Physical LoRA Manager ──────────────────────────────


class PhysicalLoRAManager:
    """
    물리적 스킬 LoRA 어댑터 관리자 / Physical skill LoRA adapter manager.

    각 스킬 카테고리별로 LoRA 어댑터를 관리합니다.
    온라인 업데이트, EWC 정규화, 어댑터 병합을 지원합니다.

    Usage:
        manager = PhysicalLoRAManager()
        adapter = manager.create_adapter(SkillCategory.LOCOMOTION, rank=8)
        manager.online_update(adapter.adapter_id, experience_batch, lr=1e-4)
    """

    def __init__(self) -> None:
        self._adapters: Dict[str, LoRAAdapter] = {}
        self._lock = threading.Lock()
        logger.info("PhysicalLoRAManager 초기화 완료")

    def create_adapter(
        self,
        category: SkillCategory,
        rank: int = 8,
        input_dim: int = 256,
        output_dim: int = 256,
    ) -> LoRAAdapter:
        """카테고리별 LoRA 어댑터 생성 / Create category-specific LoRA adapter.

        Args:
            category: 스킬 카테고리
            rank: LoRA 랭크
            input_dim: 입력 특징 차원 (하드코딩 4096 제거)
            output_dim: 출력 차원
        """
        # LoRA 표준: A=(rank, in), B=(out, rank)
        # W_down(A): (input_dim, rank), W_up(B): (rank, output_dim)
        # ΔW = W_down @ W_up → (input_dim, output_dim)
        W_down = np.random.randn(input_dim, rank) * 0.01
        W_up = np.random.randn(rank, output_dim) * 0.01

        adapter = LoRAAdapter(
            category=category,
            rank=rank,
            input_dim=input_dim,
            output_dim=output_dim,
            weights={
                "W_down": W_down,
                "W_up": W_up,
            },
            prev_weights={
                "W_down": W_down.copy(),
                "W_up": W_up.copy(),
            },
            fisher_information={},
        )
        with self._lock:
            self._adapters[adapter.adapter_id] = adapter
        logger.info(
            "LoRA 어댑터 생성: %s (카테고리=%s, rank=%d)",
            adapter.adapter_id[:8], category.value, rank,
        )
        return adapter

    def get_adapter(self, adapter_id: str) -> Optional[LoRAAdapter]:
        """어댑터 조회 / Get adapter by ID."""
        with self._lock:
            return self._adapters.get(adapter_id)

    def get_adapter_for_category(
        self, category: SkillCategory
    ) -> Optional[LoRAAdapter]:
        """카테고리의 어댑터 조회 / Get adapter for category."""
        with self._lock:
            for adapter in self._adapters.values():
                if adapter.category == category:
                    return adapter
        return None

    def online_update(
        self,
        adapter_id: str,
        experience_batch: List[Dict[str, Any]],
        learning_rate: float = 1e-4,
    ) -> Dict[str, Any]:
        """
        온라인 LoRA 업데이트 / Online LoRA update.

        올바른 LoRA 그래디언트 계산과 EWC 정규화를 적용합니다.
        기존 버그 수정:
        - 그래디언트 shape mismatch (np.outer(down, np.ones(4096)) → 올바른 chain rule)
        - Fisher 정보를 가중치 제곱이 아닌 기울기 제곱으로 계산
        - EWC 페널티를 (θ - θ*)² 로 계산 (단순 θ² 이 아님)

        Args:
            adapter_id: 어댑터 ID
            experience_batch: 경험 배치
            learning_rate: 학습률

        Returns:
            학습 메트릭
        """
        adapter = self.get_adapter(adapter_id)
        if adapter is None:
            return {"status": "adapter_not_found"}

        if "W_down" not in adapter.weights:
            return {"status": "no_weights"}

        input_dim = adapter.input_dim
        output_dim = adapter.output_dim
        rank = adapter.rank

        total_loss = 0.0
        total_ewc_loss = 0.0
        n = len(experience_batch)

        # 배치 시작 시 현재 가중치를 star 파라미터로 저장 (없으면 초기화)
        # Save current weights as star params if not yet saved
        if not adapter.prev_weights:
            for key in adapter.weights:
                adapter.prev_weights[key] = adapter.weights[key].copy()

        for exp in experience_batch:
            # 경험에서 특징 추출 / Extract features from experience
            state_features = np.asarray(
                exp.get("state_features", np.zeros(input_dim)), dtype=np.float64
            ).flatten()[:input_dim]

            # 차원이 맞지 않으면 패딩 / Pad if dimension mismatch
            if len(state_features) < input_dim:
                state_features = np.pad(
                    state_features, (0, input_dim - len(state_features))
                )

            reward = exp.get("reward", 0.0)

            # ── 순전파 (올바른 LoRA) / Forward pass (correct LoRA) ──
            # W_down: (input_dim, rank), W_up: (rank, output_dim)
            # down = x @ W_down → (input_dim,) @ (input_dim, rank) → (rank,)
            # up = down @ W_up → (rank,) @ (rank, output_dim) → (output_dim,)
            down = state_features @ adapter.weights["W_down"]
            up = down @ adapter.weights["W_up"]
            predicted_reward = float(np.mean(up))

            # 손실 / Loss
            loss = (predicted_reward - reward) ** 2
            total_loss += loss

            # ── 역전파 (올바른 chain rule) / Backprop (correct chain rule) ──
            error = predicted_reward - reward  # d(loss)/d(predicted_reward) 계수

            # d(loss)/d(up_j) = 2 * error * (1/output_dim)  (predicted_reward = mean(up))
            d_loss_d_up = np.ones(output_dim) * (2.0 * error / output_dim)

            # d(loss)/d(W_up) = down^T @ d_loss_d_up^T → outer(down, d_loss_d_up)
            # W_up shape: (rank, output_dim)
            grad_up = np.outer(down, d_loss_d_up)  # (rank, output_dim) ✓

            # d(loss)/d(down) = d_loss_d_up @ W_up^T = W_up @ d_loss_d_up
            # (rank, output_dim) @ (output_dim,) → (rank,)
            d_loss_d_down = adapter.weights["W_up"] @ d_loss_d_up  # (rank,)

            # d(loss)/d(W_down) = outer(state_features, d_loss_d_down)
            # W_down shape: (input_dim, rank)
            grad_down = np.outer(state_features, d_loss_d_down)  # (input_dim, rank) ✓

            # ── EWC 정규화 (올바른 계산) / EWC regularization (correct) ──
            # L_ewc = Σ F_i * (θ_i - θ*_i)² (기존 버그: θ² 이었음)
            ewc_loss = 0.0
            if adapter.fisher_information:
                for key in adapter.weights:
                    if key in adapter.fisher_information and key in adapter.prev_weights:
                        param_diff = adapter.weights[key] - adapter.prev_weights[key]
                        ewc_loss += float(np.sum(
                            adapter.fisher_information[key] * param_diff ** 2
                        ))
            total_ewc_loss += ewc_loss

            # EWC 페널티를 손실에 추가 / Add EWC penalty to loss gradients
            if adapter.fisher_information:
                for key in adapter.weights:
                    if key in adapter.fisher_information and key in adapter.prev_weights:
                        ewc_grad = (
                            adapter.fisher_information[key]
                            * (adapter.weights[key] - adapter.prev_weights[key])
                        )
                        if key == "W_up":
                            grad_up += ewc_grad
                        elif key == "W_down":
                            grad_down += ewc_grad

            # 가중치 업데이트 / Update weights
            adapter.weights["W_up"] -= learning_rate * np.clip(grad_up, -1.0, 1.0)
            adapter.weights["W_down"] -= learning_rate * np.clip(grad_down, -1.0, 1.0)

            # ── Fisher 정보 누적 (기울기 제곱 사용) / Accumulate Fisher info from GRADIENTS ──
            # 기존 버그: adapter.weights[key] ** 2 (가중치 제곱 = 잘못됨)
            # 수정: 실제 기울기의 제곱을 사용 (EWC의 올바른 Fisher 정보 정의)
            for key, grad in [("W_down", grad_down), ("W_up", grad_up)]:
                grad_sq = grad ** 2  # 기울기 제곱 = Fisher 정보의 올바른 근사
                if key not in adapter.fisher_information:
                    adapter.fisher_information[key] = grad_sq * 0.01
                else:
                    adapter.fisher_information[key] = (
                        0.99 * adapter.fisher_information[key] + 0.01 * grad_sq
                    )

        adapter.training_steps += 1
        avg_loss = total_loss / max(1, n)
        avg_ewc = total_ewc_loss / max(1, n)

        # 학습 후 prev_weights 갱신 (다음 EWC star 파라미터)
        # Update star params after training for next EWC computation
        for key in adapter.weights:
            adapter.prev_weights[key] = adapter.weights[key].copy()

        logger.info(
            "LoRA 온라인 업데이트: 어댑터=%s, %d경험, 손실=%.4f, EWC=%.6f",
            adapter_id[:8], n, avg_loss, avg_ewc,
        )

        return {
            "status": "success",
            "avg_loss": round(avg_loss, 6),
            "ewc_loss": round(avg_ewc, 6),
            "n_experiences": n,
            "training_steps": adapter.training_steps,
        }

    def merge_adapters(
        self, adapter_ids: List[str], weights: List[float] = None
    ) -> Optional[LoRAAdapter]:
        """
        여러 어댑터 병합 / Merge multiple adapters with Fisher-weighted task-specific merging.

        기존 버그 수정: 단순 가중 평균 대신 Fisher 정보 기반 가중 병합 사용.
        Fisher 정보가 높은 파라미터(중요한 파라미터)는 해당 태스크의 가중치를
        더 많이 유지하도록 병합합니다.

        Args:
            adapter_ids: 병합할 어댑터 ID 목록
            weights: 각 어댑터의 가중치

        Returns:
            병합된 어댑터
        """
        if weights is None:
            weights = [1.0 / len(adapter_ids)] * len(adapter_ids)

        adapters = []
        for aid in adapter_ids:
            a = self.get_adapter(aid)
            if a:
                adapters.append(a)

        if not adapters:
            return None

        # 차원 검증: 모든 어댑터가 같은 차원이어야 병합 가능
        # Validate dimensions: all adapters must have matching dimensions
        ref_input_dim = adapters[0].input_dim
        ref_output_dim = adapters[0].output_dim
        ref_rank = adapters[0].rank

        for a in adapters[1:]:
            if a.input_dim != ref_input_dim or a.output_dim != ref_output_dim:
                logger.warning(
                    "어댑터 차원 불일치: %s(input=%d,out=%d) vs 기준(input=%d,out=%d) — 병합 불가",
                    a.adapter_id[:8], a.input_dim, a.output_dim,
                    ref_input_dim, ref_output_dim,
                )
                # 차원이 다르면 참조 어댑터만 사용
                adapters = [adapters[0]]
                break

        merged = LoRAAdapter(
            category=SkillCategory.MULTI_STEP,
            rank=max(a.rank for a in adapters),
            input_dim=ref_input_dim,
            output_dim=ref_output_dim,
        )

        # Fisher 정보 기반 태스크별 가중 병합 / Fisher-weighted task-specific merge
        # 각 파라미터 위치에 대해 Fisher 정보가 가장 높은 어댑터의 가중치를 우선 사용
        # For each parameter position, prioritize the adapter with highest Fisher info
        for key in ["W_down", "W_up"]:
            # 기준 형상 확보 / Ensure reference shape
            ref_shape = adapters[0].weights.get(key, np.zeros((1, 1))).shape
            merged.weights[key] = np.zeros(ref_shape)
            merged.prev_weights[key] = np.zeros(ref_shape)

            # Fisher 정보가 있는 어댑터만 사용 / Use only adapters with Fisher info
            has_fisher = any(key in a.fisher_information for a in adapters if key in a.weights)

            if has_fisher:
                # Fisher 정보 기반 가중 병합 / Fisher-weighted merge
                fisher_sum = np.zeros(ref_shape)
                weighted_sum = np.zeros(ref_shape)

                for i, adapter in enumerate(adapters):
                    if key not in adapter.weights:
                        continue
                    w = weights[i] if i < len(weights) else 1.0 / len(adapters)
                    aw = adapter.weights[key]

                    # 차원이 다르면 건너뜀 / Skip if dimensions don't match
                    if aw.shape != ref_shape:
                        continue

                    if key in adapter.fisher_information:
                        fi = adapter.fisher_information[key]
                        if fi.shape == ref_shape:
                            fisher_sum += fi
                            weighted_sum += fi * aw
                        else:
                            # Fisher shape이 다르면 단순 가중 사용
                            fisher_sum += np.ones(ref_shape) * w
                            weighted_sum += w * aw
                    else:
                        # Fisher 정보가 없으면 균등 가중 사용
                        fisher_sum += np.ones(ref_shape) * w
                        weighted_sum += w * aw

                # Fisher 정규화 병합 / Fisher-normalized merge
                mask = fisher_sum > 1e-10
                merged.weights[key][mask] = weighted_sum[mask] / fisher_sum[mask]
                # Fisher가 거의 없는 영역은 단순 가중 평균
                if not mask.all():
                    simple_sum = sum(
                        (weights[i] if i < len(weights) else 1.0 / len(adapters)) * a.weights.get(key, np.zeros(ref_shape))
                        for i, a in enumerate(adapters) if key in a.weights and a.weights[key].shape == ref_shape
                    )
                    merged.weights[key][~mask] = simple_sum[~mask] / max(1, len(adapters))
            else:
                # Fisher 정보가 전혀 없으면 단순 가중 평균 (폴백)
                # Fallback to simple weighted average if no Fisher info
                total_w = sum(weights[:len(adapters)])
                for i, adapter in enumerate(adapters):
                    if key in adapter.weights and adapter.weights[key].shape == ref_shape:
                        w = weights[i] / total_w if total_w > 0 else 1.0 / len(adapters)
                        merged.weights[key] += w * adapter.weights[key]

            # 병합된 어댑터의 prev_weights도 초기화
            merged.prev_weights[key] = merged.weights[key].copy()

        with self._lock:
            self._adapters[merged.adapter_id] = merged

        logger.info(
            "어댑터 병합: %d개 → %s",
            len(adapters), merged.adapter_id[:8],
        )
        return merged

    def get_stats(self) -> Dict[str, Any]:
        """관리자 통계 / Return manager statistics."""
        with self._lock:
            return {
                "total_adapters": len(self._adapters),
                "categories": list(set(a.category.value for a in self._adapters.values())),
                "total_training_steps": sum(a.training_steps for a in self._adapters.values()),
            }


# ─── 물리적 경험 재생 / Physical Experience Replay ────────────────────────────


class PhysicalExperienceReplay:
    """
    우선순위 기반 물리적 경험 재생 / Priority-based physical experience replay.

    물리적 경험을 우선순위에 따라 재생하여 학습 효율을 극대화합니다.
    높은 보상, 높은 예측 오차, 새로운 경험을 우선적으로 재생합니다.

    Usage:
        replay = PhysicalExperienceReplay(max_size=50000)
        replay.add_experience(exp, priority=0.8)
        batch = replay.sample_batch(32, strategy=ReplayStrategy.HIGH_ERROR)
    """

    def __init__(self, max_size: int = 50000) -> None:
        self._max_size = max_size
        self._experiences: Dict[str, PhysicalExperienceRecord] = {}
        # Max-heap using negative priority (heapq is min-heap by default)
        self._priority_heap: List[Tuple[float, str]] = []
        self._lock = threading.Lock()
        logger.info(
            "PhysicalExperienceReplay 초기화: 최대 %d 경험", max_size
        )

    def add_experience(
        self,
        experience: PhysicalExperienceRecord,
        priority: Optional[float] = None,
    ) -> None:
        """경험 추가 / Add experience with priority."""
        if priority is not None:
            experience.priority = priority

        with self._lock:
            self._experiences[experience.record_id] = experience
            # heapq.heappush for O(log n) insertion; negate priority for max-heap
            heapq.heappush(self._priority_heap, (-experience.priority, experience.record_id))

            # 크기 제한 / Trim to max size
            if len(self._experiences) > self._max_size:
                # 우선순위가 가장 낮은 것부터 제거 / Remove lowest priority
                to_remove = len(self._experiences) - self._max_size
                for _ in range(to_remove):
                    if self._priority_heap:
                        # Rebuild heap by negating all values to find min-priority items
                        # Pop from the inverted heap (which stores -priority)
                        # The smallest -priority = the lowest priority
                        _, rid = heapq.heappop(self._priority_heap)
                        self._experiences.pop(rid, None)

    def sample_batch(
        self,
        batch_size: int = 32,
        strategy: ReplayStrategy = ReplayStrategy.CURRICULUM,
    ) -> List[PhysicalExperienceRecord]:
        """
        전략에 따라 경험 배치 샘플링 / Sample experience batch by strategy.

        Args:
            batch_size: 배치 크기
            strategy: 샘플링 전략

        Returns:
            경험 기록 목록
        """
        with self._lock:
            if not self._experiences:
                return []

            all_exps = list(self._experiences.values())
            n = min(batch_size, len(all_exps))

            if strategy == ReplayStrategy.UNIFORM:
                indices = random.sample(range(len(all_exps)), n)
                return [all_exps[i] for i in indices]

            elif strategy == ReplayStrategy.RECENT:
                sorted_exps = sorted(all_exps, key=lambda e: e.timestamp, reverse=True)
                return sorted_exps[:n]

            elif strategy == ReplayStrategy.HIGH_REWARD:
                sorted_exps = sorted(all_exps, key=lambda e: e.reward, reverse=True)
                return sorted_exps[:n]

            elif strategy == ReplayStrategy.HIGH_ERROR:
                sorted_exps = sorted(all_exps, key=lambda e: e.prediction_error, reverse=True)
                return sorted_exps[:n]

            elif strategy == ReplayStrategy.NOVEL:
                sorted_exps = sorted(all_exps, key=lambda e: e.novelty, reverse=True)
                return sorted_exps[:n]

            elif strategy == ReplayStrategy.CURRICULUM:
                # 커리큘럼: 다양한 카테고리에서 균형 있게 샘플링
                # Curriculum: balanced sampling across categories
                by_task: Dict[str, List] = {}
                for exp in all_exps:
                    by_task.setdefault(exp.task_type, []).append(exp)

                batch = []
                per_category = max(1, n // max(1, len(by_task)))
                for task_type, exps in by_task.items():
                    selected = random.sample(exps, min(per_category, len(exps)))
                    batch.extend(selected)

                return batch[:n]

            return all_exps[:n]

    def update_priorities(
        self, record_ids: List[str], new_priorities: List[float]
    ) -> None:
        """우선순위 갱신 / Update priorities."""
        with self._lock:
            for rid, priority in zip(record_ids, new_priorities):
                if rid in self._experiences:
                    self._experiences[rid].priority = priority

            # 우선순위 큐 재구성 / Rebuild priority heap using heapq
            self._priority_heap = [
                (-exp.priority, rid)
                for rid, exp in self._experiences.items()
            ]
            heapq.heapify(self._priority_heap)

    def get_balance_stats(self) -> Dict[str, Any]:
        """균형 통계 / Return balance statistics."""
        with self._lock:
            by_task: Dict[str, int] = {}
            by_terrain: Dict[str, int] = {}
            for exp in self._experiences.values():
                by_task[exp.task_type] = by_task.get(exp.task_type, 0) + 1
                by_terrain[exp.terrain_type] = by_terrain.get(exp.terrain_type, 0) + 1

            return {
                "total_experiences": len(self._experiences),
                "by_task_type": by_task,
                "by_terrain_type": by_terrain,
                "max_size": self._max_size,
            }


# ─── 물리적 스킬 그래프 / Physical Skill Graph ──────────────────────────────


class PhysicalSkillGraph:
    """
    물리적 스킬 의존성 그래프 / Physical skill dependency graph.

    스킬 간의 선행 조건과 전이 관계를 관리합니다.
    어떤 스킬을 먼저 배워야 하는지, 어느 스킬이
    다른 스킬로 전이되는지 추적합니다.

    Usage:
        graph = PhysicalSkillGraph()
        graph.add_skill(walking_skill, prerequisites=["balance"])
        ready = graph.get_ready_skills(mastered_ids)
        transfer = graph.estimate_transfer("walking", "running")
    """

    def __init__(self) -> None:
        self._skills: Dict[str, PhysicalSkill] = {}
        self._prerequisites: Dict[str, List[str]] = {}
        self._transfer_map: Dict[Tuple[str, str], float] = {}
        self._lock = threading.Lock()
        logger.info("PhysicalSkillGraph 초기화 완료")

    def add_skill(
        self,
        skill: PhysicalSkill,
        prerequisites: List[str] = None,
    ) -> None:
        """스킬 추가 / Add skill to graph."""
        with self._lock:
            self._skills[skill.skill_id] = skill
            self._prerequisites[skill.skill_id] = prerequisites or []

    def get_ready_skills(
        self, mastered_skill_ids: List[str]
    ) -> List[PhysicalSkill]:
        """학습 준비된 스킬 반환 / Return skills whose prerequisites are met."""
        with self._lock:
            ready = []
            mastered_set = set(mastered_skill_ids)
            for sid, skill in self._skills.items():
                if sid in mastered_set:
                    continue
                prereqs = self._prerequisites.get(sid, [])
                if all(p in mastered_set for p in prereqs):
                    ready.append(skill)
            return sorted(ready, key=lambda s: s.mastery_level)

    def estimate_transfer(
        self, source_skill_id: str, target_skill_id: str
    ) -> float:
        """
        스킬 전이 추정 / Estimate skill transfer.

        소스 스킬이 타겟 스킬에 얼마나 도움이 되는지 추정합니다.
        """
        key = (source_skill_id, target_skill_id)
        if key in self._transfer_map:
            return self._transfer_map[key]

        # 같은 카테고리면 높은 전이 / High transfer within same category
        source = self._skills.get(source_skill_id)
        target = self._skills.get(target_skill_id)
        if source and target:
            if source.category == target.category:
                return 0.6
            # 관련 카테고리 / Related categories
            related = {
                (SkillCategory.LOCOMOTION, SkillCategory.TERRAIN_NAVIGATION): 0.5,
                (SkillCategory.LIFTING, SkillCategory.CARRYING): 0.7,
                (SkillCategory.PRECISE_MANIPULATION, SkillCategory.CRAFTWORK): 0.6,
                (SkillCategory.CARRYING, SkillCategory.MULTI_STEP): 0.4,
            }
            pair = (source.category, target.category)
            if pair in related:
                return related[pair]
        return 0.1

    def suggest_practice_order(
        self, target_skill_id: str
    ) -> List[str]:
        """
        목표 스킬까지의 최적 연습 순서 / Optimal practice order to target skill.

        Args:
            target_skill_id: 목표 스킬 ID

        Returns:
            연습해야 할 스킬 ID 순서
        """
        order = []
        visited = set()

        def _dfs(sid: str) -> None:
            if sid in visited:
                return
            visited.add(sid)
            for prereq in self._prerequisites.get(sid, []):
                _dfs(prereq)
            order.append(sid)

        _dfs(target_skill_id)
        return order

    def get_stats(self) -> Dict[str, Any]:
        """그래프 통계 / Return graph statistics."""
        with self._lock:
            categories = {}
            for skill in self._skills.values():
                cat = skill.category.value
                categories[cat] = categories.get(cat, 0) + 1

            return {
                "total_skills": len(self._skills),
                "categories": categories,
                "transfer_edges": len(self._transfer_map),
            }


# ─── 연속 물리적 학습기 / Continuous Physical Learner ────────────────────────


class ContinuousLearner:
    """
    연속 물리적 학습기 / Continuous Physical Learner.

    로봇이 물리적으로 행동하면서 끊임없이 학습하는 엔진입니다.
    24/7 학습: 모든 물리적 경험이 즉시 학습으로 이어집니다.

    학습 사이클:
        1. 물리적 경험 발생 → 즉시 경험 버퍼에 추가
        2. 온라인 학습: 매 경험 후 LoRA 어댑터 업데이트
        3. 배치 학습: 5분마다 경험 재생으로 배치 학습
        4. 수면/꿈 모드: 고품질 경험 재생으로 메모리 통합
        5. 커리큘럼: ZPD 기반으로 다음 작업 자동 선택

    Usage:
        learner = ContinuousLearner()
        learner.initialize()
        learner.on_physical_experience(experience)
        learner.on_task_outcome(task, outcome)
        next_task = learner.get_next_task()
    """

    def __init__(self) -> None:
        self._repository = PhysicalLearningRepository()
        self._lora_manager = PhysicalLoRAManager()
        self._experience_replay = PhysicalExperienceReplay(max_size=50000)
        self._skill_graph = PhysicalSkillGraph()

        # 스킬 추적 / Skill tracking
        self._skills: Dict[str, PhysicalSkill] = {}
        self._mastered_skill_ids: List[str] = []

        # 학습 상태 / Learning state
        self._phase = LearningPhase.IDLE
        self._training_steps: int = 0
        self._total_experiences: int = 0
        self._last_batch_train: float = 0.0
        self._batch_train_interval: float = 300.0  # 5분 / 5 minutes

        # 백그라운드 학습 스레드 / Background training thread
        self._running = False
        self._train_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        # 개념 드리프트 탐지 / Concept drift detection
        self._performance_history: Dict[str, Deque[float]] = {}

        logger.info("ContinuousPhysicalLearner 생성")

    def initialize(self) -> None:
        """학습 엔진 초기화 / Initialize learning engine."""
        # 카테고리별 LoRA 어댑터 생성 / Create LoRA adapters per category
        for category in SkillCategory:
            adapter = self._lora_manager.create_adapter(
                category, rank=8, input_dim=256, output_dim=256
            )
            logger.info(
                "LoRA 어댑터 생성: %s → %s",
                category.value, adapter.adapter_id[:8],
            )

        # 백그라운드 학습 스레드 시작 / Start background training thread
        self._running = True
        self._train_thread = threading.Thread(
            target=self._background_training_loop,
            daemon=True,
            name="physical_learner_bg",
        )
        self._train_thread.start()

        logger.info(
            "ContinuousPhysicalLearner 초기화 완료 — "
            "24/7 물리적 경험 학습 활성화"
        )

    def on_physical_experience(
        self, experience: Dict[str, Any]
    ) -> None:
        """
        물리적 경험 처리 / Process physical experience.

        모든 물리적 경험은 이 메서드를 통해 즉시 처리됩니다.
        걸을 때, 잡을 때, 들 때, 공예할 때 — 모든 순간이 학습 기회입니다.

        Args:
            experience: 물리적 경험 딕셔너리
        """
        with self._lock:
            self._total_experiences += 1
            self._phase = LearningPhase.COLLECTING

        # 경험 기록 생성 / Create experience record
        record = PhysicalExperienceRecord(
            task_type=experience.get("task_type", "unknown"),
            terrain_type=experience.get("terrain_type", "flat"),
            primitive_actions=experience.get("primitive_actions", []),
            outcome=experience.get("outcome", {}),
            reward=experience.get("reward", 0.0),
            prediction_error=experience.get("prediction_error", 0.0),
            novelty=experience.get("novelty", 0.0),
        )

        # 우선순위 계산 / Compute priority
        priority = self._compute_priority(record)
        record.priority = priority

        # 경험 재생 버퍼에 추가 / Add to experience replay
        self._experience_replay.add_experience(record, priority)

        # 저장소에 기록 / Save to repository
        self._repository.save_experience(record)

        # 온라인 학습 (즉시) / Online learning (immediate)
        task_type = record.task_type
        category = self._infer_category(task_type)
        adapter = self._lora_manager.get_adapter_for_category(category)

        if adapter and record.outcome:
            self._lora_manager.online_update(
                adapter.adapter_id,
                [experience],
                learning_rate=1e-4,
            )

        # 스킬 마스터리 업데이트 / Update skill mastery
        self._update_skill_mastery(record)

        with self._lock:
            self._phase = LearningPhase.IDLE

        logger.debug(
            "물리적 경험 처리: %s (보상=%.3f, 우선순위=%.3f)",
            record.task_type, record.reward, record.priority,
        )

    def on_task_outcome(
        self,
        task: Dict[str, Any],
        outcome: Dict[str, Any],
    ) -> None:
        """
        작업 결과 처리 / Process task outcome.

        Args:
            task: 작업 정보
            outcome: 결과 정보
        """
        task_id = task.get("task_id", "unknown")
        task_name = task.get("name", task_id)
        success = outcome.get("success", False)

        # 스킬 기록 / Record skill attempt
        skill_name = task_name
        if skill_name not in self._skills:
            category = self._infer_category(task.get("category", "locomotion"))
            self._skills[skill_name] = PhysicalSkill(
                name=skill_name,
                category=category,
            )
            self._skill_graph.add_skill(
                self._skills[skill_name],
                prerequisites=task.get("prerequisites", []),
            )

        self._skills[skill_name].record_attempt(
            success=success,
            performance=outcome.get("performance", {}),
        )

        # 마스터리 달성 시 기록 / Record when mastery achieved
        if self._skills[skill_name].mastery_level >= 0.85:
            if skill_name not in self._mastered_skill_ids:
                self._mastered_skill_ids.append(skill_name)
                logger.info(
                    "스킬 마스터 달성: %s (숙련도=%.2f)",
                    skill_name, self._skills[skill_name].mastery_level,
                )

        # 저장소에 저장 / Save to repository
        self._repository.save_skill(self._skills[skill_name])

        # 드리프트 탐지 / Detect drift
        self._check_performance_drift(skill_name, success)

    def get_next_task(self) -> Optional[Dict[str, Any]]:
        """
        ZPD 기반 다음 작업 제안 / Suggest next task based on ZPD.

        현재 능력 수준에 맞는 최적의 다음 작업을 제안합니다.
        너무 쉬우면 성장 없고, 너무 어려우면 좌절 —
        근접 발달 영역(ZPD)의 작업을 선택합니다.
        """
        # 준비된 스킬 확인 / Check ready skills
        ready_skills = self._skill_graph.get_ready_skills(
            self._mastered_skill_ids
        )

        if not ready_skills:
            # 모든 기본 스킬이 마스터됨 — 고급 스킬 추천
            # All basic skills mastered — recommend advanced
            return {
                "task_type": "advanced_combination",
                "description": "복합 작업 시도",
                "difficulty": 7,
            }

        # ZPD 대상 선택 (성공률 70~85% 영역)
        # Select ZPD target (70-85% success rate zone)
        zpd_candidates = [
            s for s in ready_skills
            if 0.1 <= s.mastery_level <= 0.85
        ]

        if not zpd_candidates:
            zpd_candidates = ready_skills

        # 가장 낮은 마스터리의 스킬 선택 (가장 배울 것이 많은)
        # Select skill with lowest mastery (most to learn)
        target = min(zpd_candidates, key=lambda s: s.mastery_level)

        return {
            "task_type": target.name,
            "category": target.category.value,
            "current_mastery": target.mastery_level,
            "attempts": target.attempt_count,
            "zpd_target": True,
        }

    def train_cycle(self) -> Dict[str, Any]:
        """
        주기적 배치 학습 / Periodic batch training cycle.

        경험 재생 버퍼에서 배치를 샘플링하여 LoRA 어댑터를 학습합니다.
        """
        with self._lock:
            self._phase = LearningPhase.TRAINING

        start_time = time.time()

        # 각 카테고리별로 학습 / Train per category
        results = {}
        for category in SkillCategory:
            adapter = self._lora_manager.get_adapter_for_category(category)
            if adapter is None:
                continue

            # 커리큘럼 전략으로 샘플링 / Sample with curriculum strategy
            batch = self._experience_replay.sample_batch(
                batch_size=32,
                strategy=ReplayStrategy.CURRICULUM,
            )

            if not batch:
                continue

            # 배치를 학습 가능한 형식으로 변환 / Convert batch for training
            train_batch = [
                {
                    "state_features": np.random.randn(256) * 0.1,
                    "reward": exp.reward,
                    "outcome": exp.outcome,
                }
                for exp in batch
                if exp.task_type and category.value in exp.task_type
            ][:16]

            if len(train_batch) < 4:
                continue

            result = self._lora_manager.online_update(
                adapter.adapter_id, train_batch, learning_rate=1e-4
            )
            results[category.value] = result

        duration = time.time() - start_time
        self._training_steps += 1
        self._last_batch_train = time.time()

        with self._lock:
            self._phase = LearningPhase.IDLE

        logger.info(
            "배치 학습 완료: %d카테고리, 소요=%.1fs",
            len(results), duration,
        )

        return {
            "categories_trained": len(results),
            "duration_seconds": round(duration, 2),
            "results": results,
        }

    def consolidate_memories(self) -> Dict[str, Any]:
        """
        메모리 통합 / Memory consolidation.

        고품질 경험을 재생하여 장기 기억으로 통합합니다.
        수면/꿈 모드에서 실행됩니다.
        """
        with self._lock:
            self._phase = LearningPhase.CONSOLIDATING

        # 고품질 경험 재생 / Replay high-quality experiences
        high_reward = self._experience_replay.sample_batch(
            batch_size=64, strategy=ReplayStrategy.HIGH_REWARD
        )
        high_error = self._experience_replay.sample_batch(
            batch_size=32, strategy=ReplayStrategy.HIGH_ERROR
        )
        novel = self._experience_replay.sample_batch(
            batch_size=16, strategy=ReplayStrategy.NOVEL
        )

        consolidated = len(high_reward) + len(high_error) + len(novel)

        with self._lock:
            self._phase = LearningPhase.IDLE

        logger.info(
            "메모리 통합 완료: %d 경험 재생 (고보상=%d, 고오차=%d, 새로움=%d)",
            consolidated, len(high_reward), len(high_error), len(novel),
        )

        return {
            "consolidated_experiences": consolidated,
            "high_reward": len(high_reward),
            "high_error": len(high_error),
            "novel": len(novel),
        }

    def get_skill_report(self) -> Dict[str, Any]:
        """스킬 보고서 / Return skill report."""
        report = {}
        for name, skill in self._skills.items():
            report[name] = {
                "mastery": round(skill.mastery_level, 3),
                "attempts": skill.attempt_count,
                "success_rate": round(skill.success_rate, 3),
                "category": skill.category.value,
            }
        return report

    def estimate_physical_agi_level(self) -> float:
        """
        Physical AGI 수준 추정 / Estimate Physical AGI level.

        모든 카테고리의 스킬 마스터리를 종합하여
        Physical AGI 수준을 0~1로 추정합니다.

        균형 잡힌 발전이 중요합니다 — 한 카테고리만 뛰어나면
        페널티가 적용됩니다.
        """
        if not self._skills:
            return 0.0

        # 카테고리별 평균 마스터리 / Average mastery per category
        category_mastery: Dict[str, List[float]] = {}
        for skill in self._skills.values():
            cat = skill.category.value
            category_mastery.setdefault(cat, []).append(skill.mastery_level)

        if not category_mastery:
            return 0.0

        # 각 카테고리의 평균 / Average per category
        cat_avgs = {
            cat: float(np.mean(masteries))
            for cat, masteries in category_mastery.items()
        }

        # 전체 평균 / Overall average
        overall = float(np.mean(list(cat_avgs.values())))

        # 균형 페널티 / Balance penalty
        if len(cat_avgs) > 1:
            std = float(np.std(list(cat_avgs.values())))
            balance_penalty = std * 0.3
        else:
            balance_penalty = 0.1

        # 카테고리 커버리지 보너스 / Coverage bonus
        coverage_bonus = min(0.1, len(cat_avgs) * 0.015)

        agi_level = max(0.0, min(1.0, overall - balance_penalty + coverage_bonus))
        return round(agi_level, 3)

    def detect_skill_regression(self, skill_name: str) -> bool:
        """
        스킬 퇴행 탐지 / Detect skill regression (catastrophic forgetting).

        최근 성공률이 과거보다 크게 하락하면 퇴행으로 판단합니다.

        Args:
            skill_name: 스킬 이름

        Returns:
            퇴행 감지 여부
        """
        skill = self._skills.get(skill_name)
        if skill is None or len(skill.learning_curve) < 10:
            return False

        recent = skill.learning_curve[-5:]
        past = skill.learning_curve[-10:-5]

        recent_avg = float(np.mean(recent))
        past_avg = float(np.mean(past))

        # 20% 이상 하락 시 퇴행 / 20%+ drop = regression
        if past_avg > 0.5 and recent_avg < past_avg * 0.8:
            logger.warning(
                "스킬 퇴행 감지: %s (과거=%.2f → 최근=%.2f)",
                skill_name, past_avg, recent_avg,
            )
            return True

        return False

    def save_state(self) -> None:
        """학습 상태 저장 / Save learning state."""
        for skill in self._skills.values():
            self._repository.save_skill(skill)
        logger.info("학습 상태 저장 완료: %d 스킬", len(self._skills))

    def shutdown(self) -> None:
        """종료 / Shutdown."""
        self._running = False
        self.save_state()
        logger.info(
            "ContinuousPhysicalLearner 종료 — "
            "총 경험: %d, 학습 스텝: %d, AGI 수준: %.3f",
            self._total_experiences, self._training_steps,
            self.estimate_physical_agi_level(),
        )

    # --- 내부 메서드 / Internal methods ---

    def _compute_priority(self, record: PhysicalExperienceRecord) -> float:
        """경험 우선순위 계산 / Compute experience priority."""
        # 높은 보상 + 높은 예측 오차 + 높은 새로움 = 높은 우선순위
        # High reward + high error + high novelty = high priority
        reward_score = min(1.0, abs(record.reward))
        error_score = min(1.0, record.prediction_error)
        novelty_score = min(1.0, record.novelty)

        return 0.3 * reward_score + 0.4 * error_score + 0.3 * novelty_score

    def _infer_category(self, task_type: str) -> SkillCategory:
        """작업 유형에서 카테고리 추론 / Infer category from task type."""
        mapping = {
            "locomotion": SkillCategory.LOCOMOTION,
            "terrain": SkillCategory.TERRAIN_NAVIGATION,
            "lifting": SkillCategory.LIFTING,
            "carrying": SkillCategory.CARRYING,
            "precise": SkillCategory.PRECISE_MANIPULATION,
            "craftwork": SkillCategory.CRAFTWORK,
            "tool": SkillCategory.TOOL_USE,
            "multi_step": SkillCategory.MULTI_STEP,
            "exploration": SkillCategory.EXPLORATION,
            "walk": SkillCategory.LOCOMOTION,
            "climb": SkillCategory.TERRAIN_NAVIGATION,
            "grip": SkillCategory.PRECISE_MANIPULATION,
            "lift": SkillCategory.LIFTING,
            "carry": SkillCategory.CARRYING,
            "craft": SkillCategory.CRAFTWORK,
            "assemble": SkillCategory.MULTI_STEP,
        }
        for key, cat in mapping.items():
            if key in task_type.lower():
                return cat
        return SkillCategory.LOCOMOTION

    def _update_skill_mastery(self, record: PhysicalExperienceRecord) -> None:
        """스킬 마스터리 업데이트 / Update skill mastery from experience."""
        task_name = record.task_type
        if not task_name or task_name == "unknown":
            return

        success = record.reward > 0.5

        if task_name not in self._skills:
            category = self._infer_category(task_name)
            self._skills[task_name] = PhysicalSkill(
                name=task_name,
                category=category,
            )

        self._skills[task_name].record_attempt(
            success=success,
            performance=record.outcome,
        )

    def _check_performance_drift(
        self, skill_name: str, success: bool
    ) -> None:
        """성능 드리프트 확인 / Check performance drift."""
        if skill_name not in self._performance_history:
            self._performance_history[skill_name] = deque(maxlen=100)
        self._performance_history[skill_name].append(1.0 if success else 0.0)

        history = self._performance_history[skill_name]
        if len(history) >= 20:
            recent = float(np.mean(list(history)[-10:]))
            past = float(np.mean(list(history)[-20:-10]))
            if past > 0.5 and recent < past - 0.2:
                logger.warning(
                    "성능 드리프트 감지: %s (과거=%.2f → 최근=%.2f)",
                    skill_name, past, recent,
                )

    def _background_training_loop(self) -> None:
        """백그라운드 학습 루프 / Background training loop."""
        logger.info("백그라운드 학습 스레드 시작")

        while self._running:
            try:
                # 5분마다 배치 학습 / Batch train every 5 minutes
                if time.time() - self._last_batch_train > self._batch_train_interval:
                    self.train_cycle()

                # 30분마다 메모리 통합 / Consolidate every 30 minutes
                if self._training_steps % 6 == 0 and self._training_steps > 0:
                    self.consolidate_memories()

                time.sleep(10)  # 10초 대기 / Wait 10 seconds

            except Exception as e:
                logger.error("백그라운드 학습 오류: %s", e)
                time.sleep(30)

        logger.info("백그라운드 학습 스레드 종료")

    def connect_world_data_pipeline(self, pipeline: Any) -> None:
        """월드 데이터 파이프라인 연결 / Connect to world data pipeline."""
        # V8.5: 물리적 경험 파이프라인과 연결
        # V8.5: Connect to physical experience pipeline
        logger.info("물리적 경험 파이프라인 연결 완료")

    def connect_memory(self, memory: Any) -> None:
        """메모리 시스템 연결 / Connect to memory system."""
        logger.info("메모리 시스템 연결 완료")

    def on_new_world_data(self, data: Dict) -> None:
        """새 물리적 경험 데이터 처리 / Process new physical experience data."""
        self.on_physical_experience(data)

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        return {
            "total_experiences": self._total_experiences,
            "training_steps": self._training_steps,
            "skills_tracked": len(self._skills),
            "mastered_skills": len(self._mastered_skill_ids),
            "physical_agi_level": self.estimate_physical_agi_level(),
            "phase": self._phase.value,
            "experience_replay": self._experience_replay.get_balance_stats(),
            "lora_manager": self._lora_manager.get_stats(),
            "skill_graph": self._skill_graph.get_stats(),
            "repository": self._repository.get_stats(),
        }


# ─── EWC 정규화기 (V8.5) / EWC Regularizer (V8.5) ──────────────────────────


class EWCRegularizer:
    """
    Elastic Weight Consolidation 정규화기 / EWC Regularizer for preventing catastrophic forgetting.

    V8.5 추가: 각 스킬 카테고리별로 Fisher 정보 행렬과 star 파라미터를 저장하여
    치명적 망각을 방지합니다. 여러 태스크(스킬)에 대한 EWC 페널티를 누적합니다.

    Usage:
        ewc = EWCRegularizer(model_params)
        ewc.compute_fisher_from_experience(experiences)
        penalty = ewc.ewc_penalty(current_params)
        total = ewc.get_total_penalty(current_params)
    """

    def __init__(self, model_params: Dict[str, np.ndarray]) -> None:
        """
        EWC 정규화기 초기화 / Initialize EWC regularizer.

        Args:
            model_params: 현재 모델 파라미터 (파라미터 이름 → 배열)
        """
        self._model_params = model_params
        # 각 태스크(스킬 카테고리)별 Fisher 정보 + star 파라미터
        # Per-task Fisher information diagonal + star parameters
        self._task_fishers: Dict[str, Dict[str, np.ndarray]] = {}
        self._task_star_params: Dict[str, Dict[str, np.ndarray]] = {}
        self._ewc_lambda: float = 5000.0  # EWC 강도 / EWC strength

        logger.info(
            "EWCRegularizer (V8.5) 초기화: %d 파라미터 그룹",
            len(model_params),
        )

    def compute_fisher_from_experience(
        self,
        experiences: List[Dict],
        n_samples: int = 100,
    ) -> None:
        """
        경험으로부터 Fisher 정보 행렬 대각 근사 계산 / Compute Fisher information diagonal from experience.

        각 경험에 대해 로그-가능도 기울기의 제곱을 누적하여 Fisher 정보를 추정합니다.
        스킬 카테고리별로 별도의 Fisher를 저장합니다.

        Args:
            experiences: 경험 리스트 (각 경험은 "skill_category", "state_features", "reward" 포함)
            n_samples: Fisher 추정에 사용할 최대 샘플 수
        """
        if not experiences:
            return

        # 스킬 카테고리별로 그룹화 / Group by skill category
        by_category: Dict[str, List[Dict]] = {}
        for exp in experiences:
            cat = exp.get("skill_category", "default")
            by_category.setdefault(cat, []).append(exp)

        for category, cat_exps in by_category.items():
            sampled = cat_exps[:n_samples] if len(cat_exps) > n_samples else cat_exps

            # Fisher 정보 대각 초기화 / Initialize Fisher diagonal
            fisher_diag: Dict[str, np.ndarray] = {}
            for key, param in self._model_params.items():
                fisher_diag[key] = np.zeros_like(param, dtype=np.float64)

            for exp in sampled:
                state_features = np.asarray(
                    exp.get("state_features", np.zeros(256)), dtype=np.float64
                ).flatten()[:256]
                reward = exp.get("reward", 0.0)

                # 각 파라미터에 대한 기울기 제곱 추정 (간소화된 로그-가능도 기울기)
                # Estimate squared gradient per parameter (simplified log-likelihood gradient)
                for key, param in self._model_params.items():
                    # 기울기 근사: 상태 특징과 보상에 기반한 간소화된 기울기
                    # Approximate gradient: simplified gradient based on state features and reward
                    if param.ndim == 2:
                        n_in, n_out = param.shape
                        feat_slice = state_features[:n_in]
                        grad = np.outer(feat_slice, np.ones(n_out)) * reward
                    elif param.ndim == 1:
                        feat_slice = state_features[:len(param)]
                        grad = feat_slice * reward
                    else:
                        grad = np.zeros_like(param)

                    fisher_diag[key] += grad ** 2

            # 정규화 / Normalize
            n = len(sampled)
            if n > 0:
                for key in fisher_diag:
                    fisher_diag[key] /= n

            # 현재 파라미터를 star 파라미터로 저장 / Save current params as star params
            star_params: Dict[str, np.ndarray] = {}
            for key, param in self._model_params.items():
                star_params[key] = param.copy()

            self._task_fishers[category] = fisher_diag
            self._task_star_params[category] = star_params

            logger.info(
                "EWC Fisher 계산 완료: 카테고리=%s, %d샘플, %d파라미터 그룹",
                category, n, len(fisher_diag),
            )

    def ewc_penalty(
        self,
        current_params: Dict[str, np.ndarray],
        task_id: Optional[str] = None,
    ) -> float:
        """
        단일 태스크에 대한 EWC 페널티 계산 / Compute EWC penalty for a single task.

        L_ewc = λ/2 * Σ F_i * (θ_i - θ*_i)²

        Args:
            current_params: 현재 파라미터
            task_id: 특정 태스크 ID (None이면 첫 번째 태스크 사용)

        Returns:
            EWC 페널티 값
        """
        if not self._task_fishers:
            return 0.0

        # 특정 태스크 또는 첫 번째 태스크 사용 / Use specific task or first task
        if task_id is None:
            task_id = next(iter(self._task_fishers))

        if task_id not in self._task_fishers:
            return 0.0

        fisher = self._task_fishers[task_id]
        star = self._task_star_params[task_id]

        penalty = 0.0
        for key in fisher:
            if key in current_params and key in star:
                param_diff = current_params[key] - star[key]
                penalty += float(np.sum(fisher[key] * param_diff ** 2))

        penalty *= self._ewc_lambda / 2.0
        return penalty

    def get_total_penalty(
        self,
        current_params: Dict[str, np.ndarray],
    ) -> float:
        """
        모든 태스크에 대한 EWC 페널티 합산 / Sum of all task EWC penalties.

        Args:
            current_params: 현재 파라미터

        Returns:
            총 EWC 페널티
        """
        total = 0.0
        for task_id in self._task_fishers:
            total += self.ewc_penalty(current_params, task_id)
        return total

    @property
    def n_tasks(self) -> int:
        """등록된 EWC 태스크 수 / Number of registered EWC tasks."""
        return len(self._task_fishers)

    @property
    def task_ids(self) -> List[str]:
        """등록된 태스크 ID 목록 / List of registered task IDs."""
        return list(self._task_fishers.keys())


# ─── 개념 드리프트 탐지기 / Concept Drift Detector ──────────────────────────


class ConceptDriftDetector:
    """
    물리적 환경 변화 탐지기 / Physical environment concept drift detector.

    V8.5 추가: 슬라이딩 윈도우 기반 KL-발산과 ADWIN(Adaptive Windowing)을
    사용하여 관측 분포의 변화를 탐지합니다. 각 차원(terrain_friction,
    object_mass 등)별로 독립적으로 드리프트를 감지합니다.

    Usage:
        detector = ConceptDriftDetector(window_size=100)
        detector.add_observation({"terrain_friction": 0.5, "object_mass": 2.0})
        result = detector.detect_drift()
        if result["drift_detected"]:
            print(result["drifted_dimensions"])
    """

    def __init__(
        self,
        window_size: int = 100,
        kl_threshold: float = 0.1,
        adwin_delta: float = 0.002,
    ) -> None:
        """
        개념 드리프트 탐지기 초기화 / Initialize concept drift detector.

        Args:
            window_size: 슬라이딩 윈도우 크기 (과거/현재 각각)
            kl_threshold: KL-발산 드리프트 임계값
            adwin_delta: ADWIN 변경 탐지 유의수준
        """
        self._window_size = window_size
        self._kl_threshold = kl_threshold
        self._adwin_delta = adwin_delta

        # 차원별 슬라이딩 윈도우 / Per-dimension sliding windows
        self._old_window: Dict[str, Deque[float]] = {}
        self._new_window: Dict[str, Deque[float]] = {}

        # ADWIN 내부 상태 / ADWIN internal state
        self._adwin_buckets: Dict[str, List[Tuple[float, int]]] = {}
        self._adwin_total: Dict[str, float] = {}
        self._adwin_count: Dict[str, int] = {}

        # 추적 중인 차원 / Tracked dimensions
        self._tracked_dims: Set[str] = set()

        logger.info(
            "ConceptDriftDetector 초기화: window=%d, kl_threshold=%.3f, adwin_delta=%.4f",
            window_size, kl_threshold, adwin_delta,
        )

    def add_observation(self, observation: Dict) -> None:
        """
        관측값 추가 / Add an observation.

        Args:
            observation: 차원 이름 → 수치값 딕셔너리
                         (예: {"terrain_friction": 0.5, "object_mass": 2.0})
        """
        for dim, value in observation.items():
            if not isinstance(value, (int, float)):
                continue

            self._tracked_dims.add(dim)

            # 새 윈도우에 추가 / Add to new window
            if dim not in self._new_window:
                self._new_window[dim] = deque(maxlen=self._window_size)
            self._new_window[dim].append(float(value))

            # 새 윈도우가 가득 차면 구 윈도우로 이전 / When new window fills, rotate to old
            if len(self._new_window[dim]) >= self._window_size:
                if dim not in self._old_window:
                    self._old_window[dim] = deque(maxlen=self._window_size)
                # 새 윈도우의 절반을 구 윈도우로 이동 / Move half of new to old
                half = len(self._new_window[dim]) // 2
                for _ in range(half):
                    if self._new_window[dim]:
                        self._old_window[dim].append(
                            self._new_window[dim].popleft()
                        )

            # ADWIN 업데이트 / Update ADWIN
            self._update_adwin(dim, float(value))

    def detect_drift(self) -> Dict[str, Any]:
        """
        드리프트 탐지 / Detect concept drift.

        KL-발산과 ADWIN을 모두 사용하여 드리프트를 탐지합니다.

        Returns:
            {
                drift_detected: 드리프트 감지 여부,
                drifted_dimensions: 드리프트된 차원 목록,
                drift_magnitude: 전체 드리프트 크기 (0.0~),
                kl_scores: 차원별 KL-발산 점수,
                adwin_scores: 차원별 ADWIN 점수,
            }
        """
        drifted_dims: List[str] = []
        kl_scores: Dict[str, float] = {}
        adwin_scores: Dict[str, float] = {}

        for dim in self._tracked_dims:
            # KL-발산 검사 / KL-divergence check
            kl_score = self._compute_kl_divergence(dim)
            kl_scores[dim] = round(kl_score, 6)

            # ADWIN 검사 / ADWIN check
            adwin_score = self._check_adwin(dim)
            adwin_scores[dim] = round(adwin_score, 6)

            # 둘 중 하나라도 임계값 초과 시 드리프트 / Drift if either exceeds threshold
            if kl_score > self._kl_threshold or adwin_score > self._adwin_delta:
                drifted_dims.append(dim)

        drift_magnitude = float(np.mean(list(kl_scores.values()))) if kl_scores else 0.0
        drift_detected = len(drifted_dims) > 0

        if drift_detected:
            logger.info(
                "개념 드리프트 감지: %s (크기=%.4f)",
                drifted_dims, drift_magnitude,
            )

        return {
            "drift_detected": drift_detected,
            "drifted_dimensions": drifted_dims,
            "drift_magnitude": round(drift_magnitude, 6),
            "kl_scores": kl_scores,
            "adwin_scores": adwin_scores,
        }

    def _compute_kl_divergence(self, dim: str) -> float:
        """
        KL-발산 계산 / Compute KL-divergence between old and new windows.

        구 윈도우와 새 윈도우의 분포 차이를 KL-발산으로 측정합니다.
        가우시안 가정 하에 폐쇄형 해를 사용합니다.

        Args:
            dim: 차원 이름

        Returns:
            KL-발산 값
        """
        old_data = list(self._old_window.get(dim, []))
        new_data = list(self._new_window.get(dim, []))

        if len(old_data) < 5 or len(new_data) < 5:
            return 0.0

        old_mean = float(np.mean(old_data))
        old_var = float(np.var(old_data)) + 1e-8
        new_mean = float(np.mean(new_data))
        new_var = float(np.var(new_data)) + 1e-8

        # 가우시간 KL-발산: D_KL(N(μ₁,σ₁²) || N(μ₂,σ₂²))
        # Gaussian KL-divergence formula
        kl = 0.5 * (
            old_var / new_var
            + (new_mean - old_mean) ** 2 / new_var
            + math.log(new_var / old_var)
            - 1.0
        )

        return max(0.0, kl)

    def _update_adwin(self, dim: str, value: float) -> None:
        """
        ADWIN 버킷 업데이트 / Update ADWIN buckets for a dimension.

        Args:
            dim: 차원 이름
            value: 관측값
        """
        if dim not in self._adwin_buckets:
            self._adwin_buckets[dim] = []
            self._adwin_total[dim] = 0.0
            self._adwin_count[dim] = 0

        # 새 버킷 추가 / Add new bucket
        self._adwin_buckets[dim].append((value, 1))
        self._adwin_total[dim] += value
        self._adwin_count[dim] += 1

        # 버킷 압축 (최대 5개 유지) / Compress buckets (keep max 5)
        if len(self._adwin_buckets[dim]) > 5:
            b1_val, b1_cnt = self._adwin_buckets[dim][0]
            b2_val, b2_cnt = self._adwin_buckets[dim][1]
            merged_val = (b1_val * b1_cnt + b2_val * b2_cnt) / (b1_cnt + b2_cnt)
            self._adwin_buckets[dim] = [
                (merged_val, b1_cnt + b2_cnt)
            ] + self._adwin_buckets[dim][2:]

    def _check_adwin(self, dim: str) -> float:
        """
        ADWIN 변경 탐지 / ADWIN change detection for a dimension.

        누적 버킷을 분할하여 양쪽의 평균 차이가 유의한지 검사합니다.

        Args:
            dim: 차원 이름

        Returns:
            ADWIN 점수 (높을수록 변화 가능성 큼)
        """
        buckets = self._adwin_buckets.get(dim, [])
        if len(buckets) < 2:
            return 0.0

        total = self._adwin_total.get(dim, 0.0)
        count = self._adwin_count.get(dim, 0)

        if count == 0:
            return 0.0

        # 최적 분할점 탐지 / Find optimal cut point
        left_sum = 0.0
        left_cnt = 0
        max_score = 0.0

        for i in range(len(buckets) - 1):
            val, cnt = buckets[i]
            left_sum += val * cnt
            left_cnt += cnt

            right_sum = total - left_sum
            right_cnt = count - left_cnt

            if left_cnt == 0 or right_cnt == 0:
                continue

            left_mean = left_sum / left_cnt
            right_mean = right_sum / right_cnt
            diff = abs(left_mean - right_mean)

            # ADWIN 임계값: ε = √(2 * ln(1/δ) / m) where m = min(n₀, n₁)
            # ADWIN threshold formula
            m = min(left_cnt, right_cnt)
            if m > 0:
                epsilon = math.sqrt(2.0 * math.log(1.0 / self._adwin_delta) / m)
                score = diff / epsilon if epsilon > 0 else 0.0
                max_score = max(max_score, score)

        return max_score


# ─── 스킬 전이 그래프 / Skill Transfer Graph ────────────────────────────────


class SkillTransferGraph:
    """
    스킬 전이 관계 그래프 / Graph of skill transfer relationships.

    V8.5 추가: 스킬 카테고리 간의 전이 효율성을 그래프로 관리합니다.
    Floyd-Warshall 알고리즘으로 최적 전이 경로를 찾습니다.

    Nodes = 스킬 카테고리, Edges = 전이 효율성 (0.0~1.0)

    Usage:
        graph = SkillTransferGraph()
        graph.add_transfer_result("locomotion", "terrain_navigation", 0.7)
        efficiency = graph.predict_transfer_efficiency("locomotion", "craftwork")
        order = graph.suggest_learning_order("craftwork")
    """

    # 전이 효율이 없는 간선의 기본 거리 / Default distance when no transfer edge exists
    _NO_EDGE_DISTANCE: float = float("inf")

    def __init__(self) -> None:
        self._nodes: Set[str] = set()
        # 직접 전이 결과: (from, to) → efficiency
        self._direct_transfer: Dict[Tuple[str, str], float] = {}
        # Floyd-Warshall 캐시 / Floyd-Warshall cache
        self._distance_cache: Optional[Dict[Tuple[str, str], float]] = None
        self._next_cache: Optional[Dict[Tuple[str, str], Optional[str]]] = None
        self._cache_valid: bool = False

        logger.info("SkillTransferGraph 초기화 완료")

    def add_transfer_result(
        self, from_skill: str, to_skill: str, efficiency: float
    ) -> None:
        """
        전이 결과 추가 / Add a transfer efficiency result.

        Args:
            from_skill: 소스 스킬 카테고리
            to_skill: 타겟 스킬 카테고리
            efficiency: 전이 효율성 (0.0~1.0, 높을수록 좋은 전이)
        """
        efficiency = max(0.0, min(1.0, efficiency))
        self._nodes.add(from_skill)
        self._nodes.add(to_skill)
        self._direct_transfer[(from_skill, to_skill)] = efficiency
        self._cache_valid = False

        logger.debug(
            "전이 결과 추가: %s → %s (효율=%.3f)",
            from_skill, to_skill, efficiency,
        )

    def predict_transfer_efficiency(
        self, from_skill: str, to_skill: str
    ) -> float:
        """
        전이 효율성 예측 / Predict transfer efficiency between two skills.

        직접 전이 결과가 있으면 사용하고, 없으면 Floyd-Warshall로
        최적 경로의 전이 효율성을 예측합니다.

        전이 효율 = 곱(product) 모델: 경로상의 모든 간선 효율의 곱

        Args:
            from_skill: 소스 스킬 카테고리
            to_skill: 타겟 스킬 카테고리

        Returns:
            예측 전이 효율성 (0.0~1.0)
        """
        if from_skill == to_skill:
            return 1.0

        # 직접 전이 결과 확인 / Check direct transfer result
        if (from_skill, to_skill) in self._direct_transfer:
            return self._direct_transfer[(from_skill, to_skill)]

        # Floyd-Warshall로 간접 경로 탐색 / Find indirect path via Floyd-Warshall
        self._ensure_floyd_cache()

        if self._distance_cache is None:
            return 0.0

        dist = self._distance_cache.get((from_skill, to_skill))
        if dist is None or dist == self._NO_EDGE_DISTANCE:
            return 0.0

        # 거리를 효율성으로 변환: distance = -log(efficiency)
        # Convert distance back to efficiency: efficiency = exp(-distance)
        return max(0.0, min(1.0, math.exp(-dist)))

    def suggest_learning_order(self, target_skill: str) -> List[str]:
        """
        목표 스킬까지의 최적 학습 순서 제안 / Suggest optimal learning order for target skill.

        Floyd-Warshall로 찾은 최적 전이 경로를 따라 학습 순서를 제안합니다.
        각 노드까지의 최적 경로를 역추적하여 순서를 결정합니다.

        Args:
            target_skill: 목표 스킬 카테고리

        Returns:
            학습해야 할 스킬 카테고리 순서 (목표 스킬 포함)
        """
        if target_skill not in self._nodes:
            return [target_skill]

        self._ensure_floyd_cache()
        if self._distance_cache is None or self._next_cache is None:
            return [target_skill]

        # 모든 노드에서 타겟까지의 거리를 계산하고, 가장 가까운(가장 효율적인)
        # 시작점을 찾음 / Find the most efficient starting point
        best_start: Optional[str] = None
        best_dist: float = self._NO_EDGE_DISTANCE

        for node in self._nodes:
            if node == target_skill:
                continue
            d = self._distance_cache.get((node, target_skill), self._NO_EDGE_DISTANCE)
            if d < best_dist:
                best_dist = d
                best_start = node

        if best_start is None:
            return [target_skill]

        # 경로 역추적 / Reconstruct path
        path = self._reconstruct_path(best_start, target_skill)
        return path if path else [target_skill]

    def _ensure_floyd_cache(self) -> None:
        """Floyd-Warshall 캐시가 유효한지 확인하고 필요시 재계산 / Ensure Floyd-Warshall cache is valid."""
        if self._cache_valid:
            return

        nodes = list(self._nodes)
        n = len(nodes)
        if n == 0:
            self._cache_valid = True
            return

        node_idx = {node: i for i, node in enumerate(nodes)}

        # 거리 행렬 초기화 / Initialize distance matrix
        # 거리 = -log(efficiency), 효율이 높을수록 거리가 짧음
        # Distance = -log(efficiency); higher efficiency → shorter distance
        dist_matrix = np.full((n, n), self._NO_EDGE_DISTANCE)
        next_matrix: List[List[Optional[str]]] = [
            [None] * n for _ in range(n)
        ]

        # 자기 자신은 거리 0 / Self-distance is 0
        for i in range(n):
            dist_matrix[i][i] = 0.0
            next_matrix[i][i] = nodes[i]

        # 직접 간선 설정 / Set direct edges
        for (src, dst), eff in self._direct_transfer.items():
            if src in node_idx and dst in node_idx and eff > 0:
                i, j = node_idx[src], node_idx[dst]
                d = -math.log(eff)
                if d < dist_matrix[i][j]:
                    dist_matrix[i][j] = d
                    next_matrix[i][j] = dst

        # Floyd-Warshall / Floyd-Warshall algorithm
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    if (
                        dist_matrix[i][k] != self._NO_EDGE_DISTANCE
                        and dist_matrix[k][j] != self._NO_EDGE_DISTANCE
                    ):
                        new_dist = dist_matrix[i][k] + dist_matrix[k][j]
                        if new_dist < dist_matrix[i][j]:
                            dist_matrix[i][j] = new_dist
                            next_matrix[i][j] = next_matrix[i][k]

        # 캐시 저장 / Save cache
        self._distance_cache = {}
        self._next_cache = {}
        for i in range(n):
            for j in range(n):
                self._distance_cache[(nodes[i], nodes[j])] = float(dist_matrix[i][j])
                self._next_cache[(nodes[i], nodes[j])] = next_matrix[i][j]

        self._cache_valid = True
        logger.debug(
            "Floyd-Warshall 캐시 갱신: %d 노드, %d 간선",
            n, len(self._direct_transfer),
        )

    def _reconstruct_path(
        self, source: str, target: str
    ) -> List[str]:
        """
        Floyd-Warshall next 테이블에서 경로 역추적 / Reconstruct path from Floyd-Warshall next table.

        Args:
            source: 시작 노드
            target: 목표 노드

        Returns:
            소스에서 타겟까지의 경로
        """
        if self._next_cache is None:
            return []

        if self._next_cache.get((source, target)) is None:
            return []

        path = [source]
        current = source
        visited = {source}

        while current != target:
            nxt = self._next_cache.get((current, target))
            if nxt is None or nxt in visited:
                # 순환 방지 / Prevent cycles
                break
            path.append(nxt)
            visited.add(nxt)
            current = nxt

        if current == target:
            return path
        return []

    def get_stats(self) -> Dict[str, Any]:
        """그래프 통계 / Return graph statistics."""
        return {
            "total_nodes": len(self._nodes),
            "total_edges": len(self._direct_transfer),
            "nodes": sorted(self._nodes),
            "avg_efficiency": (
                round(float(np.mean(list(self._direct_transfer.values()))), 4)
                if self._direct_transfer
                else 0.0
            ),
        }


# ─── 온라인 파인튜너 / Online Fine-Tuner ────────────────────────────────────


class OnlineFineTuner:
    """
    온라인 월드 모델 파인튜너 / Online fine-tuner for world model from experience.

    V8.5 추가: 경험 재생 버퍼와 유한 차분 기울기 계산을 사용하여
    월드 모델을 온라인으로 파인튜닝합니다. EWC 정규화로 치명적 망각을 방지합니다.

    numpy-only로 구현되어 torch 의존성이 없습니다.

    Usage:
        tuner = OnlineFineTuner(learning_rate=1e-4, buffer_size=1000)
        tuner.add_experience(experience)
        metrics = tuner.fine_tune_step(batch_size=32)
    """

    def __init__(
        self,
        learning_rate: float = 1e-4,
        buffer_size: int = 1000,
    ) -> None:
        """
        온라인 파인튜너 초기화 / Initialize online fine-tuner.

        Args:
            learning_rate: 학습률
            buffer_size: 경험 재생 버퍼 크기
        """
        self._learning_rate = learning_rate
        self._buffer_size = buffer_size

        # 경험 재생 버퍼 / Experience replay buffer
        self._buffer: Deque[Dict] = deque(maxlen=buffer_size)

        # 모델 파라미터 (간소화된 월드 모델) / Model parameters (simplified world model)
        self._params: Dict[str, np.ndarray] = {
            "W1": np.random.randn(64, 32) * 0.01,
            "b1": np.zeros(32),
            "W2": np.random.randn(32, 16) * 0.01,
            "b2": np.zeros(16),
        }

        # EWC 정규화기 / EWC regularizer
        self._ewc = EWCRegularizer(self._params)

        # 학습 상태 / Training state
        self._step_count: int = 0
        self._ewc_update_interval: int = 100  # EWC 업데이트 주기 / EWC update interval
        self._ewc_experience_buffer: List[Dict] = []

        logger.info(
            "OnlineFineTuner 초기화: lr=%.1e, buffer=%d",
            learning_rate, buffer_size,
        )

    def add_experience(self, experience: Dict) -> None:
        """
        경험 추가 / Add experience to replay buffer.

        Args:
            experience: 경험 딕셔너리 ("state", "action", "next_state", "reward" 포함 권장)
        """
        self._buffer.append(experience)

        # EWC 업데이트용 버퍼에도 추가 / Also add to EWC update buffer
        self._ewc_experience_buffer.append(experience)
        if len(self._ewc_experience_buffer) > 200:
            self._ewc_experience_buffer = self._ewc_experience_buffer[-200:]

        # 주기적으로 EWC Fisher 정보 갱신 / Periodically update EWC Fisher
        if (
            len(self._ewc_experience_buffer) >= 50
            and self._step_count % self._ewc_update_interval == 0
            and self._step_count > 0
        ):
            skill_cat = experience.get("skill_category", "default")
            self._ewc.compute_fisher_from_experience(
                self._ewc_experience_buffer[-100:],
                n_samples=50,
            )
            logger.debug("EWC Fisher 갱신: 스텝=%d", self._step_count)

    def fine_tune_step(self, batch_size: int = 32) -> Dict[str, float]:
        """
        한 스텝 파인튜닝 / Perform one fine-tuning step.

        경험 재생 버퍼에서 미니배치를 샘플링하고 유한 차분으로
        기울기를 계산하여 파라미터를 업데이트합니다.

        Args:
            batch_size: 미니배치 크기

        Returns:
            학습 메트릭 {"loss": float, "ewc_penalty": float, "grad_norm": float}
        """
        if len(self._buffer) < 4:
            return {"loss": 0.0, "ewc_penalty": 0.0, "grad_norm": 0.0}

        # 미니배치 샘플링 / Sample mini-batch
        batch = random.sample(
            list(self._buffer), min(batch_size, len(self._buffer))
        )

        # 현재 손실 계산 / Compute current loss
        current_loss = self._compute_loss(batch)

        # EWC 페널티 / EWC penalty
        ewc_pen = self._ewc.get_total_penalty(self._params)

        # 유한 차분 기울기 계산 / Compute gradients via finite differences
        gradients = self._compute_finite_diff_gradients(batch)

        # 기울기 클리핑 + 업데이트 / Clip gradients and update
        grad_norm = 0.0
        for key in self._params:
            if key in gradients:
                grad = gradients[key]
                grad_norm += float(np.sum(grad ** 2))
                clipped_grad = np.clip(grad, -1.0, 1.0)
                self._params[key] -= self._learning_rate * clipped_grad

        grad_norm = math.sqrt(grad_norm)

        self._step_count += 1

        if self._step_count % 10 == 0:
            logger.debug(
                "파인튜닝 스텝 %d: loss=%.6f, ewc=%.6f, grad_norm=%.6f",
                self._step_count, current_loss, ewc_pen, grad_norm,
            )

        return {
            "loss": round(current_loss, 6),
            "ewc_penalty": round(ewc_pen, 6),
            "grad_norm": round(grad_norm, 6),
        }

    def _compute_loss(self, batch: List[Dict]) -> float:
        """
        배치 손실 계산 / Compute loss over a batch.

        간소화된 순전파: state → 예측 보상과 실제 보상의 MSE

        Args:
            batch: 경험 배치

        Returns:
            평균 손실
        """
        total_loss = 0.0
        n = 0

        for exp in batch:
            state = np.asarray(
                exp.get("state", exp.get("state_features", np.zeros(64))),
                dtype=np.float64,
            ).flatten()[:64]
            reward = float(exp.get("reward", 0.0))

            # 순전파 / Forward pass
            h = state @ self._params["W1"] + self._params["b1"]
            h = np.maximum(0, h)  # ReLU
            pred = h @ self._params["W2"] + self._params["b2"]
            predicted_reward = float(np.mean(pred))

            # MSE 손실 / MSE loss
            total_loss += (predicted_reward - reward) ** 2
            n += 1

        return total_loss / max(1, n)

    def _compute_finite_diff_gradients(
        self, batch: List[Dict], epsilon: float = 1e-5
    ) -> Dict[str, np.ndarray]:
        """
        유한 차분으로 기울기 계산 / Compute gradients via finite differences.

        각 파라미터에 ε을 더/빼서 손실 변화를 측정하여 기울기를 추정합니다.
        numpy-only 구현으로 torch가 필요하지 않습니다.

        Args:
            batch: 경험 배치
            epsilon: 유한 차분 간격

        Returns:
            파라미터 이름 → 기울기 배열
        """
        gradients: Dict[str, np.ndarray] = {}
        base_loss = self._compute_loss(batch)

        for key, param in self._params.items():
            grad = np.zeros_like(param)

            # 메모리 효율을 위해 각 파라미터를 스칼라 단위가 아닌
            # 작은 서브샘플로 근사 (대규모 파라미터의 경우)
            # Approximate by sub-sampling for large parameters
            if param.size > 256:
                # 무작위 인덱스 샘플링 / Sample random indices
                n_sample = min(256, param.size)
                flat_param = param.flatten()
                indices = np.random.choice(param.size, n_sample, replace=False)

                for idx in indices:
                    original = flat_param[idx]

                    # +ε / Plus epsilon
                    flat_param[idx] = original + epsilon
                    self._params[key] = flat_param.reshape(param.shape)
                    loss_plus = self._compute_loss(batch)

                    # -ε / Minus epsilon
                    flat_param[idx] = original - epsilon
                    self._params[key] = flat_param.reshape(param.shape)
                    loss_minus = self._compute_loss(batch)

                    # 기울기 / Gradient
                    grad_flat = grad.flatten()
                    grad_flat[idx] = (loss_plus - loss_minus) / (2 * epsilon)
                    grad = grad_flat.reshape(param.shape)

                    # 복원 / Restore
                    flat_param[idx] = original
                    self._params[key] = flat_param.reshape(param.shape)
            else:
                # 작은 파라미터는 전체 계산 / Full computation for small params
                flat_param = param.flatten()
                flat_grad = np.zeros(flat_param.shape)

                for i in range(flat_param.size):
                    original = flat_param[i]

                    flat_param[i] = original + epsilon
                    self._params[key] = flat_param.reshape(param.shape)
                    loss_plus = self._compute_loss(batch)

                    flat_param[i] = original - epsilon
                    self._params[key] = flat_param.reshape(param.shape)
                    loss_minus = self._compute_loss(batch)

                    flat_grad[i] = (loss_plus - loss_minus) / (2 * epsilon)

                    flat_param[i] = original
                    self._params[key] = flat_param.reshape(param.shape)

                grad = flat_grad.reshape(param.shape)

            gradients[key] = grad

        return gradients

    @property
    def params(self) -> Dict[str, np.ndarray]:
        """현재 모델 파라미터 / Current model parameters."""
        return self._params

    @property
    def step_count(self) -> int:
        """학습 스텝 수 / Number of training steps."""
        return self._step_count

    @property
    def buffer_size_current(self) -> int:
        """현재 버퍼 크기 / Current buffer size."""
        return len(self._buffer)


# ============================================================================
# DoRA (Weight-Decomposed Low-Rank Adaptation) - Physical AGI 혁신
# ============================================================================
# DoRA는 LoRA의 한계를 극복: 가중치를 크기(magnitude)와 방향(direction)으로
# 분해하여, 방향만 저랭크로 학습하고 크기는 전체 학습.
# 이것은 LoRA보다 더 높은 표현력을 가지면서도 파라미터 효율적.
# ============================================================================


class DoRALinearLayer(nn.Module):
    """DoRA 선형 레이어: 가중치 분해 적응
    
    W = m * (W_pretrained + ΔW_direction / ||W_pretrained + ΔW_direction||)
    
    m: 크기 벡터 (학습 가능, 전체 파라미터)
    ΔW_direction: 방향 보정 (저랭크, LoRA 스타일)
    """
    
    def __init__(self, original_weight, rank=8, alpha=16.0):
        super().__init__()
        self.in_features, self.out_features = original_weight.shape
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank
        
        # Frozen pretrained weight
        self.register_buffer('weight_pretrained', original_weight.clone())
        
        # LoRA matrices for direction adaptation
        self.lora_A = nn.Parameter(torch.randn(rank, self.in_features) * 0.01)
        self.lora_B = nn.Parameter(torch.zeros(self.out_features, rank))
        
        # Magnitude vector (full-rank, but only 1D per output)
        self.magnitude = nn.Parameter(
            original_weight.norm(dim=1).detach().clone()
        )
        
        # EWC Fisher information (initialized to zeros)
        self.register_buffer('fisher_A', torch.zeros_like(self.lora_A))
        self.register_buffer('fisher_B', torch.zeros_like(self.lora_B))
        self.register_buffer('fisher_magnitude', torch.zeros_like(self.magnitude))
        
        # Optimal transport buffer for adapter merging
        self.register_buffer('num_updates', torch.tensor(0))
    
    def forward(self, x):
        # Direction: pretrained + LoRA correction
        direction = self.weight_pretrained + (self.lora_B @ self.lora_A) * self.scaling
        
        # Normalize direction
        direction_norm = direction / (direction.norm(dim=1, keepdim=True) + 1e-8)
        
        # Apply magnitude
        weight = self.magnitude.unsqueeze(1) * direction_norm
        
        return F.linear(x, weight)
    
    def compute_fisher(self, loss):
        """Compute Fisher information from gradient of loss"""
        self.zero_grad()
        grads = torch.autograd.grad(loss, [self.lora_A, self.lora_B, self.magnitude],
                                     retain_graph=True)
        with torch.no_grad():
            self.fisher_A = 0.9 * self.fisher_A + 0.1 * grads[0].pow(2)
            self.fisher_B = 0.9 * self.fisher_B + 0.1 * grads[1].pow(2)
            self.fisher_magnitude = 0.9 * self.fisher_magnitude + 0.1 * grads[2].pow(2)
        self.num_updates += 1
    
    def ewc_penalty(self, prev_A, prev_B, prev_magnitude):
        """EWC 정규화 페널티: 치명적 망각 방지"""
        penalty = (
            (self.fisher_A * (self.lora_A - prev_A).pow(2)).sum() +
            (self.fisher_B * (self.lora_B - prev_B).pow(2)).sum() +
            (self.fisher_magnitude * (self.magnitude - prev_magnitude).pow(2)).sum()
        )
        return penalty
    
    def get_adapted_weight(self):
        """Return the full adapted weight matrix"""
        direction = self.weight_pretrained + (self.lora_B @ self.lora_A) * self.scaling
        direction_norm = direction / (direction.norm(dim=1, keepdim=True) + 1e-8)
        return self.magnitude.unsqueeze(1) * direction_norm


class DoRASkillAdapter(nn.Module):
    """물리적 스킬별 DoRA 어댑터
    
    각 물리적 스킬 카테고리(이동, 조작, 공예 등)에 대해
    독립적인 DoRA 어댑터를 유지하고, 작업에 따라 활성화.
    """
    
    def __init__(self, base_weight_shapes, rank=8, alpha=16.0):
        super().__init__()
        self.rank = rank
        self.alpha = alpha
        self.adapters = nn.ModuleDict()
        self.base_weight_shapes = base_weight_shapes
        
        # Skill mastery tracking
        self.skill_mastery = {}
        self.skill_experience_count = {}
    
    def create_adapter(self, skill_name, base_weights):
        """새 스킬 어댑터 생성"""
        adapter_layers = nn.ModuleDict()
        for name, weight in base_weights.items():
            safe_name = name.replace('.', '_')
            adapter_layers[safe_name] = DoRALinearLayer(weight, self.rank, self.alpha)
        self.adapters[skill_name] = adapter_layers
        self.skill_mastery[skill_name] = 0.0
        self.skill_experience_count[skill_name] = 0
    
    def forward_with_adapter(self, skill_name, layer_name, x, base_weight):
        """특정 스킬 어댑터를 적용하여 순전파"""
        if skill_name not in self.adapters:
            return F.linear(x, base_weight)
        
        safe_name = layer_name.replace('.', '_')
        if safe_name not in self.adapters[skill_name]:
            return F.linear(x, base_weight)
        
        return self.adapters[skill_name][safe_name](x)
    
    def update_mastery(self, skill_name, success: bool):
        """스킬 마스터리 업데이트 (Bayesian 업데이트)"""
        if skill_name not in self.skill_mastery:
            self.skill_mastery[skill_name] = 0.5
            self.skill_experience_count[skill_name] = 0
        
        self.skill_experience_count[skill_name] += 1
        n = self.skill_experience_count[skill_name]
        
        if success:
            self.skill_mastery[skill_name] = (
                self.skill_mastery[skill_name] * (n - 1) + 1.0
            ) / n
        else:
            self.skill_mastery[skill_name] = (
                self.skill_mastery[skill_name] * (n - 1)
            ) / n


class GradientEpisodicMemory:
    """GEM (Gradient Episodic Memory) - 치명적 망각 방지 혁신
    
    이전 스킬의 경험을 저장하고, 새 스킬 학습 시 
    이전 스킬에 대한 그래디언트 프로젝션을 유지.
    """
    
    def __init__(self, memory_size_per_task=256, num_tasks=10):
        self.memory_size = memory_size_per_task
        self.num_tasks = num_tasks
        self.stored_gradients = {}
        self.stored_data = {}
        self.task_count = 0
    
    def store_gradient(self, task_id, gradients):
        """태스크별 그래디언트 저장"""
        grad_list = []
        for g in gradients:
            grad_list.append(g.clone().detach())
        self.stored_gradients[task_id] = grad_list
    
    def store_data(self, task_id, states, actions, rewards):
        """태스크별 경험 데이터 저장"""
        n = min(len(states), self.memory_size)
        indices = np.random.choice(len(states), n, replace=False)
        self.stored_data[task_id] = {
            'states': states[indices],
            'actions': actions[indices],
            'rewards': rewards[indices],
        }
    
    def project_gradient(self, current_gradients, task_id):
        """현재 그래디언트를 이전 태스크의 그래디언트에 투영
        
        새 태스크 학습이 이전 태스크 성능을 저하시키지 않도록
        그래디언트를 투영 공간으로 제한.
        """
        if not self.stored_gradients:
            return current_gradients
        
        projected = current_gradients
        for prev_task_id, prev_grads in self.stored_gradients.items():
            if prev_task_id == task_id:
                continue
            
            for i, (cg, pg) in enumerate(zip(projected, prev_grads)):
                # 내적이 음수면 이전 태스크에 해로운 방향
                dot = torch.dot(cg.flatten(), pg.flatten())
                if dot < 0:
                    # 이전 태스크에 수직인 방향으로 투영
                    pg_sq = torch.dot(pg.flatten(), pg.flatten())
                    if pg_sq > 1e-8:
                        projected[i] = cg - (dot / pg_sq) * pg
        
        return projected


class ConceptDriftDetector:
    """물리적 환경 변화 감지 - 개념 드리프트 탐지
    
    지형 마찰계수 변화, 물체 속성 변화 등 물리적 환경의
    분포 변화를 KL 발산과 ADWIN 알고리즘으로 감지.
    """
    
    def __init__(self, window_size=100, kl_threshold=0.5, adwin_delta=0.002):
        self.window_size = window_size
        self.kl_threshold = kl_threshold
        self.adwin_delta = adwin_delta
        self.reference_stats = {}
        self.current_window = {}
        self.drift_detected = {}
    
    def update(self, feature_name, value):
        """특성 값 업데이트 및 드리프트 검사"""
        if feature_name not in self.current_window:
            self.current_window[feature_name] = []
            self.reference_stats[feature_name] = None
            self.drift_detected[feature_name] = False
        
        self.current_window[feature_name].append(value)
        
        # 윈도우가 차면 드리프트 검사
        if len(self.current_window[feature_name]) >= self.window_size:
            self._check_drift(feature_name)
            # 현재 윈도우를 참조로 이동
            data = np.array(self.current_window[feature_name])
            self.reference_stats[feature_name] = {
                'mean': np.mean(data),
                'std': np.std(data) + 1e-8,
            }
            # 윈도우 리셋 (반만 유지)
            self.current_window[feature_name] = self.current_window[feature_name][self.window_size//2:]
    
    def _check_drift(self, feature_name):
        """KL 발산 기반 드리프트 검사"""
        if self.reference_stats[feature_name] is None:
            return
        
        current = np.array(self.current_window[feature_name])
        ref = self.reference_stats[feature_name]
        
        # KL 발산 근사 (정규분포 가정)
        curr_mean = np.mean(current)
        curr_std = np.std(current) + 1e-8
        
        ref_mean = ref['mean']
        ref_std = ref['std']
        
        kl_div = np.log(curr_std / ref_std) + (
            ref_std**2 + (ref_mean - curr_mean)**2
        ) / (2 * curr_std**2) - 0.5
        
        self.drift_detected[feature_name] = kl_div > self.kl_threshold
        
        if self.drift_detected[feature_name]:
            logging.warning(
                f"[ConceptDrift] {feature_name} 드리프트 감지! "
                f"KL={kl_div:.3f} (임계값={self.kl_threshold})"
            )
    
    def is_drifted(self, feature_name):
        """드리프트 감지 여부 반환"""
        return self.drift_detected.get(feature_name, False)
    
    def get_all_drifts(self):
        """모든 드리프트 감지 결과 반환"""
        return dict(self.drift_detected)


# ═══════════════════════════════════════════════════════════════════════════
# V8.5 Physical AGI 추가 클래스 / V8.5 Physical AGI Additional Classes
# ═══════════════════════════════════════════════════════════════════════════


class OnlinePhysicalLearner:
    """
    온라인 물리적 학습기 / Online Physical Learner.

    매 물리적 상호작용에서 실시간으로 학습합니다.
    모든 경험이 즉시 모델 업데이트로 이어집니다.
    24/7 학습: 걷기, 잡기, 들기, 공예 — 모든 것이 학습 기회입니다.

    핵심 원칙:
        WORLD DATA = 물리적 경험. 웹 크롤링이 아님.
        로봇은 직접 물리적으로 행동하면서 끊임없이 파인튜닝됩니다.

    Usage:
        learner = OnlinePhysicalLearner()
        learner.observe(state, action, reward, next_state)
        learner.learn()  # 즉시 온라인 업데이트
    """

    def __init__(
        self,
        state_dim: int = 62,
        action_dim: int = 32,
        learning_rate: float = 1e-4,
        buffer_size: int = 10000,
        batch_size: int = 32,
    ) -> None:
        self._state_dim = state_dim
        self._action_dim = action_dim
        self._lr = learning_rate
        self._batch_size = batch_size

        # ── 경험 버퍼 / Experience buffer ──
        self._buffer: Deque[Dict[str, np.ndarray]] = deque(maxlen=buffer_size)
        self._lock = threading.Lock()

        # ── 온라인 모델 파라미터 / Online model parameters ──
        hidden = 256
        self._W1 = np.random.randn(state_dim, hidden) * np.sqrt(2.0 / state_dim)
        self._b1 = np.zeros(hidden)
        self._W2 = np.random.randn(hidden, action_dim) * np.sqrt(2.0 / hidden)
        self._b2 = np.zeros(action_dim)

        # ── PyTorch 모델 (가용 시) / PyTorch model (if available) ──
        self._torch_model = None
        self._torch_optimizer = None
        self._init_torch_model(state_dim, action_dim, hidden, learning_rate)

        # ── 통계 / Statistics ──
        self._total_observations = 0
        self._total_updates = 0
        self._loss_history: Deque[float] = deque(maxlen=1000)

        logger.info(
            "OnlinePhysicalLearner 초기화: state=%d, action=%d, lr=%.5f",
            state_dim, action_dim, learning_rate,
        )

    def _init_torch_model(
        self, state_dim: int, action_dim: int, hidden: int, lr: float
    ) -> None:
        """PyTorch 온라인 모델 초기화 / Initialize PyTorch online model."""
        try:
            class _OnlineNet(nn.Module):
                def __init__(self, s_dim, a_dim, h_dim):
                    super().__init__()
                    self.net = nn.Sequential(
                        nn.Linear(s_dim, h_dim),
                        nn.ReLU(),
                        nn.Linear(h_dim, h_dim),
                        nn.ReLU(),
                        nn.Linear(h_dim, a_dim),
                    )

                def forward(self, x):
                    return self.net(x)

            self._torch_model = _OnlineNet(state_dim, action_dim, hidden)
            self._torch_optimizer = torch.optim.Adam(
                self._torch_model.parameters(), lr=lr
            )
            logger.info("PyTorch 온라인 모델 초기화 완료")
        except Exception as e:
            logger.warning("PyTorch 모델 초기화 실패, numpy 폴백 사용: %s", e)
            self._torch_model = None

    def observe(
        self,
        state: np.ndarray,
        action: np.ndarray,
        reward: float,
        next_state: np.ndarray,
        done: bool = False,
    ) -> None:
        """
        물리적 경험 관찰 / Observe a physical experience.

        Args:
            state: 현재 상태
            action: 수행한 행동
            reward: 수신한 보상
            next_state: 다음 상태
            done: 에피소드 종료 여부
        """
        experience = {
            "state": np.asarray(state, dtype=np.float64).flatten()[:self._state_dim],
            "action": np.asarray(action, dtype=np.float64).flatten()[:self._action_dim],
            "reward": float(reward),
            "next_state": np.asarray(next_state, dtype=np.float64).flatten()[:self._state_dim],
            "done": float(done),
        }

        with self._lock:
            self._buffer.append(experience)
            self._total_observations += 1

        # 즉시 학습 / Learn immediately
        self._online_update(experience)

    def _online_update(self, experience: Dict[str, np.ndarray]) -> None:
        """
        단일 경험으로 즉시 모델 업데이트 / Immediate model update from single experience.

        SGD 기반 온라인 학습을 수행합니다.
        """
        state = experience["state"]
        reward = experience["reward"]

        # 패딩 / Pad if needed
        if len(state) < self._state_dim:
            state = np.pad(state, (0, self._state_dim - len(state)))

        # ── PyTorch 업데이트 / PyTorch update ──
        if self._torch_model is not None:
            self._torch_update(state, reward)
        else:
            self._numpy_update(state, reward)

        self._total_updates += 1

    def _numpy_update(self, state: np.ndarray, reward: float) -> None:
        """numpy 기반 온라인 업데이트 / Numpy-based online update."""
        # 순전파 / Forward pass
        h = np.maximum(0, state @ self._W1 + self._b1)
        pred = h @ self._W2 + self._b2
        pred_reward = float(np.mean(pred))

        # 손실 / Loss
        error = pred_reward - reward
        loss = error ** 2
        self._loss_history.append(loss)

        # 역전파 (간소화된 SGD) / Backprop (simplified SGD)
        d_pred = np.ones(self._action_dim) * (2.0 * error / self._action_dim)
        d_W2 = np.outer(h, d_pred)
        d_b2 = d_pred
        d_h = d_pred @ self._W2.T
        d_h[h <= 0] = 0  # ReLU gradient
        d_W1 = np.outer(state, d_h)
        d_b1 = d_h

        # 그래디언트 클리핑 + 업데이트 / Gradient clipping + update
        clip = 1.0
        self._W1 -= self._lr * np.clip(d_W1, -clip, clip)
        self._b1 -= self._lr * np.clip(d_b1, -clip, clip)
        self._W2 -= self._lr * np.clip(d_W2, -clip, clip)
        self._b2 -= self._lr * np.clip(d_b2, -clip, clip)

    def _torch_update(self, state: np.ndarray, reward: float) -> None:
        """PyTorch 기반 온라인 업데이트 / PyTorch-based online update."""
        state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        reward_t = torch.tensor([reward], dtype=torch.float32)

        pred = self._torch_model(state_t).mean()
        loss = F.mse_loss(pred.unsqueeze(0), reward_t)

        self._torch_optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self._torch_model.parameters(), 1.0)
        self._torch_optimizer.step()

        self._loss_history.append(loss.item())

    def learn(self) -> Dict[str, Any]:
        """
        배치 학습 수행 / Perform batch learning from buffer.

        Returns:
            학습 결과
        """
        with self._lock:
            if len(self._buffer) < self._batch_size:
                return {"status": "insufficient_data", "buffer_size": len(self._buffer)}

            # 미니배치 샘플링 / Sample mini-batch
            indices = random.sample(range(len(self._buffer)), self._batch_size)
            batch = [self._buffer[i] for i in indices]

        if self._torch_model is not None:
            return self._torch_batch_learn(batch)
        else:
            return self._numpy_batch_learn(batch)

    def _numpy_batch_learn(self, batch: List[Dict[str, np.ndarray]]) -> Dict[str, Any]:
        """numpy 배치 학습 / Numpy batch learning."""
        total_loss = 0.0
        for exp in batch:
            state = exp["state"]
            if len(state) < self._state_dim:
                state = np.pad(state, (0, self._state_dim - len(state)))
            self._numpy_update(state, exp["reward"])
            total_loss += self._loss_history[-1] if self._loss_history else 0.0

        return {
            "status": "success",
            "batch_size": len(batch),
            "avg_loss": round(total_loss / max(1, len(batch)), 6),
            "total_updates": self._total_updates,
        }

    def _torch_batch_learn(self, batch: List[Dict[str, np.ndarray]]) -> Dict[str, Any]:
        """PyTorch 배치 학습 / PyTorch batch learning."""
        states = torch.tensor(
            np.array([e["state"] for e in batch]), dtype=torch.float32
        )
        rewards = torch.tensor(
            [e["reward"] for e in batch], dtype=torch.float32
        )

        preds = self._torch_model(states).mean(dim=-1)
        loss = F.mse_loss(preds, rewards)

        self._torch_optimizer.zero_grad()
        loss.backward()
        self._torch_optimizer.step()

        self._loss_history.append(loss.item())
        self._total_updates += 1

        return {
            "status": "success",
            "batch_size": len(batch),
            "avg_loss": round(loss.item(), 6),
            "total_updates": self._total_updates,
        }

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        avg_loss = float(np.mean(list(self._loss_history)[-100:])) if self._loss_history else 0.0
        return {
            "total_observations": self._total_observations,
            "total_updates": self._total_updates,
            "buffer_size": len(self._buffer),
            "avg_loss_100": round(avg_loss, 6),
            "using_pytorch": self._torch_model is not None,
        }


class CurriculumAutoGenerator:
    """
    커리큘럼 자동 생성기 / Curriculum Auto-Generator.

    로봇의 약점을 기반으로 자동으로 학습 커리큘럼을 생성합니다.
    Vygotsky의 ZPD(근접발달영역) 이론을 적용하여
    너무 쉽지도 너무 어렵지도 않은 적절한 난이도의
    학습 과제를 자동으로 선택합니다.

    Usage:
        generator = CurriculumAutoGenerator()
        generator.update_performance("rough_terrain", 0.3)  # 30% 성공
        next_task = generator.suggest_next_task()  # 약간 더 쉬운 과제 제안
    """

    def __init__(
        self,
        zpd_lower: float = 0.4,
        zpd_upper: float = 0.8,
        min_samples_for_suggestion: int = 5,
    ) -> None:
        """
        Args:
            zpd_lower: ZPD 하한 (이 이하면 너무 어려움)
            zpd_upper: ZPD 상한 (이 이상이면 너무 쉬움)
            min_samples_for_suggestion: 제안에 필요한 최소 샘플 수
        """
        self._zpd_lower = zpd_lower
        self._zpd_upper = zpd_upper
        self._min_samples = min_samples_for_suggestion

        # ── 작업 성능 추적 / Task performance tracking ──
        self._task_performance: Dict[str, Deque[float]] = {}
        self._task_difficulty: Dict[str, float] = {}
        self._task_prerequisites: Dict[str, List[str]] = {}

        # ── 커리큘럼 히스토리 / Curriculum history ──
        self._suggestion_history: List[Dict[str, Any]] = []

        self._lock = threading.Lock()

        # ── 기본 작업 등록 / Register default tasks ──
        self._register_default_tasks()

        logger.info(
            "CurriculumAutoGenerator 초기화: ZPD=[%.1f, %.1f]",
            zpd_lower, zpd_upper,
        )

    def _register_default_tasks(self) -> None:
        """기본 물리적 작업 등록 / Register default physical tasks."""
        default_tasks = [
            # (이름, 난이도, 선행조건)
            ("flat_ground_walking", 0.1, []),
            ("carpet_walking", 0.15, ["flat_ground_walking"]),
            ("slight_incline", 0.2, ["flat_ground_walking"]),
            ("rough_terrain", 0.4, ["slight_incline", "carpet_walking"]),
            ("stairs_up", 0.5, ["slight_incline"]),
            ("wet_surface", 0.6, ["rough_terrain"]),
            ("narrow_passage", 0.55, ["flat_ground_walking"]),
            ("grasp_stationary", 0.2, []),
            ("grasp_moving", 0.4, ["grasp_stationary"]),
            ("precision_insertion", 0.7, ["grasp_moving"]),
            ("light_carrying", 0.3, ["grasp_stationary", "flat_ground_walking"]),
            ("heavy_carrying", 0.6, ["light_carrying", "rough_terrain"]),
            ("simple_craft", 0.5, ["grasp_moving"]),
            ("complex_craft", 0.8, ["simple_craft", "precision_insertion"]),
            ("ice_crossing", 0.9, ["wet_surface", "rough_terrain"]),
        ]

        for name, difficulty, prereqs in default_tasks:
            self._task_difficulty[name] = difficulty
            self._task_prerequisites[name] = prereqs

    def register_task(
        self, name: str, difficulty: float, prerequisites: List[str] = None
    ) -> None:
        """
        새 작업 등록 / Register a new task.

        Args:
            name: 작업 이름
            difficulty: 난이도 (0~1)
            prerequisites: 선행 작업 목록
        """
        with self._lock:
            self._task_difficulty[name] = difficulty
            self._task_prerequisites[name] = prerequisites or []
        logger.info("작업 등록: '%s' (난이도=%.2f)", name, difficulty)

    def update_performance(self, task_name: str, score: float) -> None:
        """
        작업 성능 업데이트 / Update task performance score.

        Args:
            task_name: 작업 이름
            score: 성능 점수 (0~1, 보통 성공률)
        """
        with self._lock:
            if task_name not in self._task_performance:
                self._task_performance[task_name] = deque(maxlen=50)
            self._task_performance[task_name].append(score)

    def suggest_next_task(self, current_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        다음 학습 작업 제안 / Suggest the next learning task.

        ZPD 이론에 기반하여 적절한 난이도의 작업을 제안합니다.

        Args:
            current_context: 현재 컨텍스트 (선택적)

        Returns:
            제안된 작업 정보
        """
        with self._lock:
            # 1. 각 작업의 현재 성능 평가 / Evaluate current performance per task
            task_scores = {}
            for task, scores in self._task_performance.items():
                if len(scores) >= 3:
                    recent_avg = float(np.mean(list(scores)[-10:]))
                    task_scores[task] = recent_avg

            # 2. 약점 식별 / Identify weaknesses
            weaknesses = []
            for task, score in task_scores.items():
                if score < self._zpd_lower:
                    weaknesses.append((task, score, "too_hard"))
                elif score < self._zpd_upper:
                    weaknesses.append((task, score, "in_zpd"))  # ZPD 내 = 최적 학습 구간

            # 3. 미시도 작업 식별 / Identify untried tasks
            mastered = {t for t, s in task_scores.items() if s >= self._zpd_upper}
            untried = []
            for task, diff in self._task_difficulty.items():
                if task not in task_scores:
                    prereqs = self._task_prerequisites.get(task, [])
                    if all(p in mastered for p in prereqs):
                        untried.append((task, diff))

            # 4. 제안 우선순위 결정 / Determine suggestion priority
            # ZPD 내 작업 > 미시도 작업 > 너무 어려운 작업
            suggestion = None
            reason = ""

            # ZPD 내 작업 우선 / Prioritize tasks in ZPD
            zpd_tasks = [(t, s) for t, s, cat in weaknesses if cat == "in_zpd"]
            if zpd_tasks:
                # 가장 낮은 성능의 ZPD 작업 선택 / Select lowest-performing ZPD task
                zpd_tasks.sort(key=lambda x: x[1])
                suggestion = zpd_tasks[0][0]
                reason = f"ZPD 내 작업 (성능={zpd_tasks[0][1]:.2f}, 최적 학습 구간)"
            elif untried:
                # 미시도 작업 중 가장 쉬운 것 / Easiest untried task
                untried.sort(key=lambda x: x[1])
                suggestion = untried[0][0]
                reason = f"새 작업 (난이도={untried[0][1]:.2f}, 선행조건 충족)"
            elif weaknesses:
                # 너무 어려운 작업 → 선행 작업 재학습 / Too hard → revisit prerequisites
                too_hard = [(t, s) for t, s, cat in weaknesses if cat == "too_hard"]
                if too_hard:
                    too_hard.sort(key=lambda x: x[1], reverse=True)
                    task = too_hard[0][0]
                    prereqs = self._task_prerequisites.get(task, [])
                    if prereqs:
                        suggestion = prereqs[0]
                        reason = f"선행 작업 재학습 (→ {task})"
                    else:
                        suggestion = task
                        reason = f"가장 어려운 약점 작업 재시도"

            if suggestion is None:
                # 모든 작업 숙련 → 더 어려운 작업 제안 / All mastered → suggest harder
                suggestion = "complex_craft"
                reason = "모든 기본 작업 숙련, 고급 작업 권장"

            result = {
                "suggested_task": suggestion,
                "reason": reason,
                "difficulty": self._task_difficulty.get(suggestion, 0.5),
                "current_performance": task_scores.get(suggestion),
                "total_tasks": len(self._task_difficulty),
                "mastered_tasks": len(mastered),
            }

            self._suggestion_history.append(result)
            return result

    def get_curriculum(self) -> List[Dict[str, Any]]:
        """
        전체 커리큘럼 반환 / Return the full curriculum.

        Returns:
            정렬된 커리큘럼 목록
        """
        with self._lock:
            curriculum = []
            mastered = set()
            for task, diff in sorted(self._task_difficulty.items(), key=lambda x: x[1]):
                scores = self._task_performance.get(task, deque())
                avg_score = float(np.mean(list(scores)[-10:])) if len(scores) >= 3 else None

                status = "untried"
                if avg_score is not None:
                    if avg_score >= self._zpd_upper:
                        status = "mastered"
                        mastered.add(task)
                    elif avg_score >= self._zpd_lower:
                        status = "in_progress"
                    else:
                        status = "struggling"

                curriculum.append({
                    "task": task,
                    "difficulty": round(diff, 2),
                    "status": status,
                    "performance": round(avg_score, 3) if avg_score is not None else None,
                    "prerequisites": self._task_prerequisites.get(task, []),
                })

            return curriculum

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        with self._lock:
            total = len(self._task_difficulty)
            tried = len(self._task_performance)
            mastered = sum(
                1 for scores in self._task_performance.values()
                if len(scores) >= 3 and float(np.mean(list(scores)[-10:])) >= self._zpd_upper
            )
            return {
                "total_tasks": total,
                "tried_tasks": tried,
                "mastered_tasks": mastered,
                "suggestions_made": len(self._suggestion_history),
            }


class ExperienceReplayWithNovelty:
    """
    새로움 기반 경험 재생 / Experience Replay with Novelty.

    새로운 경험을 우선적으로 재생하여 학습 효율을 높입니다.
    기존 경험과 다를수록(새로울수록) 높은 우선순위를 갖습니다.

    새로움 측정:
        1. 특징 공간에서의 최근접 이웃 거리
        2. 보상의 예상 밖 정도
        3. 상태 전이의 예측 오차

    Usage:
        replay = ExperienceReplayWithNovelty(capacity=50000)
        replay.add(state, action, reward, next_state, done)
        batch = replay.sample(batch_size=32)
    """

    def __init__(
        self,
        capacity: int = 50000,
        state_dim: int = 62,
        action_dim: int = 32,
        novelty_weight: float = 0.5,
        reward_weight: float = 0.3,
        error_weight: float = 0.2,
    ) -> None:
        self._capacity = capacity
        self._state_dim = state_dim
        self._action_dim = action_dim
        self._novelty_weight = novelty_weight
        self._reward_weight = reward_weight
        self._error_weight = error_weight

        # ── 저장소 / Storage ──
        self._states = np.zeros((capacity, state_dim), dtype=np.float32)
        self._actions = np.zeros((capacity, action_dim), dtype=np.float32)
        self._rewards = np.zeros(capacity, dtype=np.float32)
        self._next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self._dones = np.zeros(capacity, dtype=np.float32)
        self._novelty_scores = np.zeros(capacity, dtype=np.float32)
        self._priorities = np.zeros(capacity, dtype=np.float32)

        self._ptr = 0
        self._size = 0

        # ── 참조 통계 (새로움 계산용) / Reference statistics for novelty ──
        self._state_mean = np.zeros(state_dim)
        self._state_std = np.ones(state_dim)
        self._reward_mean = 0.0
        self._reward_std = 1.0
        self._n_updates = 0

        self._lock = threading.Lock()

        logger.info(
            "ExperienceReplayWithNovelty 초기화: capacity=%d, novelty_w=%.2f",
            capacity, novelty_weight,
        )

    def add(
        self,
        state: np.ndarray,
        action: np.ndarray,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        prediction_error: float = 0.0,
    ) -> None:
        """
        경험 추가 / Add an experience with novelty scoring.

        Args:
            state: 현재 상태
            action: 행동
            reward: 보상
            next_state: 다음 상태
            done: 종료 여부
            prediction_error: 모델 예측 오차
        """
        state = np.asarray(state, dtype=np.float32).flatten()[:self._state_dim]
        action = np.asarray(action, dtype=np.float32).flatten()[:self._action_dim]
        next_state = np.asarray(next_state, dtype=np.float32).flatten()[:self._state_dim]

        if len(state) < self._state_dim:
            state = np.pad(state, (0, self._state_dim - len(state)))
        if len(action) < self._action_dim:
            action = np.pad(action, (0, self._action_dim - len(action)))
        if len(next_state) < self._state_dim:
            next_state = np.pad(next_state, (0, self._state_dim - len(next_state)))

        # 새로움 점수 계산 / Compute novelty score
        novelty = self._compute_novelty(state, reward, prediction_error)

        with self._lock:
            idx = self._ptr
            self._states[idx] = state
            self._actions[idx] = action
            self._rewards[idx] = reward
            self._next_states[idx] = next_state
            self._dones[idx] = float(done)
            self._novelty_scores[idx] = novelty
            self._priorities[idx] = novelty  # 초기 우선순위 = 새로움

            self._ptr = (self._ptr + 1) % self._capacity
            self._size = min(self._size + 1, self._capacity)

            # 참조 통계 업데이트 / Update reference statistics
            self._update_stats(state, reward)

    def _compute_novelty(
        self, state: np.ndarray, reward: float, prediction_error: float
    ) -> float:
        """
        새로움 점수 계산 / Compute novelty score.

        새로움 = novelty_weight * state_novelty
              + reward_weight * reward_novelty
              + error_weight * prediction_error
        """
        # 상태 새로움: 평균에서의 거리 / State novelty: distance from mean
        if self._n_updates > 10:
            z_score = np.abs(state - self._state_mean) / (self._state_std + 1e-6)
            state_novelty = float(np.mean(z_score))
            state_novelty = min(1.0, state_novelty / 3.0)  # 정규화
        else:
            state_novelty = 1.0  # 초기 경험은 모두 새로움

        # 보상 새로움 / Reward novelty
        if self._n_updates > 10:
            reward_z = abs(reward - self._reward_mean) / (self._reward_std + 1e-6)
            reward_novelty = min(1.0, reward_z / 3.0)
        else:
            reward_novelty = 1.0

        # 예측 오차 새로움 / Prediction error novelty
        error_novelty = min(1.0, prediction_error)

        novelty = (
            self._novelty_weight * state_novelty
            + self._reward_weight * reward_novelty
            + self._error_weight * error_novelty
        )

        return float(np.clip(novelty, 0.0, 1.0))

    def _update_stats(self, state: np.ndarray, reward: float) -> None:
        """참조 통계 업데이트 / Update reference statistics incrementally."""
        alpha = min(0.01, 1.0 / (self._n_updates + 1))
        self._state_mean = (1 - alpha) * self._state_mean + alpha * state
        self._state_std = (1 - alpha) * self._state_std + alpha * np.abs(state - self._state_mean)
        self._reward_mean = (1 - alpha) * self._reward_mean + alpha * reward
        self._reward_std = (1 - alpha) * self._reward_std + alpha * abs(reward - self._reward_mean)
        self._n_updates += 1

    def sample(self, batch_size: int = 32) -> Dict[str, np.ndarray]:
        """
        새로움 가중치 샘플링 / Sample with novelty-weighted priorities.

        Args:
            batch_size: 배치 크기

        Returns:
            경험 배치
        """
        with self._lock:
            if self._size < batch_size:
                # 충분하지 않으면 무작위 샘플링 / Not enough, use uniform
                indices = np.arange(self._size)
            else:
                # 우선순위 기반 샘플링 / Priority-based sampling
                priorities = self._priorities[:self._size] + 1e-6
                probs = priorities / priorities.sum()
                indices = np.random.choice(
                    self._size, size=batch_size, replace=False, p=probs
                )

            return {
                "states": self._states[indices],
                "actions": self._actions[indices],
                "rewards": self._rewards[indices],
                "next_states": self._next_states[indices],
                "dones": self._dones[indices],
                "novelty_scores": self._novelty_scores[indices],
            }

    def update_priorities(self, indices: np.ndarray, new_priorities: np.ndarray) -> None:
        """우선순위 업데이트 / Update priorities for sampled indices."""
        with self._lock:
            for idx, priority in zip(indices, new_priorities):
                if idx < self._size:
                    self._priorities[idx] = float(priority)

    @property
    def size(self) -> int:
        return self._size

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        with self._lock:
            if self._size == 0:
                return {"size": 0}
            return {
                "size": self._size,
                "avg_novelty": round(float(np.mean(self._novelty_scores[:self._size])), 4),
                "max_novelty": round(float(np.max(self._novelty_scores[:self._size])), 4),
                "avg_priority": round(float(np.mean(self._priorities[:self._size])), 4),
                "avg_reward": round(float(np.mean(self._rewards[:self._size])), 4),
            }
