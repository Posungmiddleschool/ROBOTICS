#!/usr/bin/env python3
"""
rlhf_reward.py - RLHF Reward Model from Human Feedback
인간 피드백 기반 RLHF 보상 모델

Bradley-Terry model for learning reward from pairwise comparisons,
combined with task reward for safe and aligned robot behavior.
쌍대 비교로부터 보상을 학습하는 Bradley-Terry 모델,
작업 보상과 결합하여 안전하고 정렬된 로봇 행동 보장.
"""

import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple, Dict

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    nn = object

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# ─── Constants / 상수 ────────────────────────────────────────────────
DB_PATH = "rlhf_feedback.db"
STATE_DIM = 48            # robot state dimension / 로봇 상태 차원
ACTION_DIM = 16           # action dimension / 행동 차원
HIDDEN_DIM_1 = 128
HIDDEN_DIM_2 = 64
INITIAL_ALPHA = 1.0       # initial task reward weight / 초기 작업 보상 가중치
MIN_ALPHA = 0.3           # minimum task reward weight / 최소 작업 보상 가중치
ALPHA_DECAY = 0.995       # alpha decay per feedback batch / 피드백 배치당 alpha 감쇠
DP_EPSILON = 0.1          # differential privacy noise scale / 차분 프라이버시 노이즈 규모
BATCH_SIZE = 32
LEARNING_RATE = 1e-4
MAX_TRAINING_STEPS = 2000


# ─── Enums / 열거형 ──────────────────────────────────────────────────
class FeedbackType(Enum):
    """인간 피드백 유형 / Types of human feedback."""
    GOOD = "good"
    BAD = "bad"
    NEUTRAL = "neutral"


# ─── Data Classes / 데이터 클래스 ─────────────────────────────────────
@dataclass
class HumanFeedback:
    """단일 인간 피드백 기록 / A single human feedback record."""
    state: np.ndarray          # robot state at time of feedback / 피드백 시점 로봇 상태
    action: np.ndarray         # action taken / 수행된 행동
    context: str               # contextual description / 문맥 설명
    feedback_type: FeedbackType
    timestamp: float = field(default_factory=time.time)
    confidence: float = 1.0    # annotator confidence / 주석자 신뢰도


@dataclass
class PairwiseComparison:
    """두 행동 간 선호 비교 / Pairwise preference comparison between two actions."""
    state: np.ndarray
    action_a: np.ndarray
    action_b: np.ndarray
    preference: int            # 1 if a preferred, -1 if b preferred, 0 if equal
    timestamp: float = field(default_factory=time.time)


# ─── HumanFeedbackStore / 인간 피드백 저장소 ─────────────────────────
class HumanFeedbackStore:
    """
    SQLite 기반 인간 피드백 저장소 (스레드 안전)
    SQLite-backed, thread-safe store for human feedback.
    Records: action, context, feedback_type, timestamp.
    기록: 행동, 문맥, 피드백 유형, 타임스탬프.
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._ensure_schema()

    def _ensure_schema(self):
        """데이터베이스 스키마 초기화 / Initialize database schema."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                state BLOB NOT NULL,
                action BLOB NOT NULL,
                context TEXT NOT NULL,
                feedback_type TEXT NOT NULL,
                confidence REAL DEFAULT 1.0,
                timestamp REAL NOT NULL
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS comparisons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                state BLOB NOT NULL,
                action_a BLOB NOT NULL,
                action_b BLOB NOT NULL,
                preference INTEGER NOT NULL,
                timestamp REAL NOT NULL
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_fb_type ON feedback(feedback_type)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_fb_time ON feedback(timestamp)")
        self._conn.commit()
        logger.info("HumanFeedbackStore 스키마 초기화 완료 / Schema initialized")

    def store_feedback(self, feedback: HumanFeedback) -> int:
        """인간 피드백 저장 / Store a human feedback entry."""
        state_blob = feedback.state.astype(np.float32).tobytes()
        action_blob = feedback.action.astype(np.float32).tobytes()
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO feedback (state, action, context, feedback_type, confidence, timestamp) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (state_blob, action_blob, feedback.context,
                 feedback.feedback_type.value, feedback.confidence, feedback.timestamp)
            )
            row_id = cursor.lastrowid
            self._conn.commit()
        logger.debug(f"피드백 저장: id={row_id}, type={feedback.feedback_type.value} / "
                      f"Feedback stored: id={row_id}")
        return row_id

    def store_comparison(self, comp: PairwiseComparison) -> int:
        """쌍대 비교 저장 / Store a pairwise comparison."""
        state_blob = comp.state.astype(np.float32).tobytes()
        action_a_blob = comp.action_a.astype(np.float32).tobytes()
        action_b_blob = comp.action_b.astype(np.float32).tobytes()
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO comparisons (state, action_a, action_b, preference, timestamp) "
                "VALUES (?, ?, ?, ?, ?)",
                (state_blob, action_a_blob, action_b_blob, comp.preference, comp.timestamp)
            )
            row_id = cursor.lastrowid
            self._conn.commit()
        return row_id

    def get_all_comparisons(self) -> List[PairwiseComparison]:
        """모든 쌍대 비교 로드 / Load all pairwise comparisons."""
        rows = self._conn.execute("SELECT state, action_a, action_b, preference, timestamp "
                                  "FROM comparisons").fetchall()

        comparisons = []
        for row in rows:
            state = np.frombuffer(row[0], dtype=np.float32)
            action_a = np.frombuffer(row[1], dtype=np.float32)
            action_b = np.frombuffer(row[2], dtype=np.float32)
            comparisons.append(PairwiseComparison(
                state=state, action_a=action_a, action_b=action_b,
                preference=row[3], timestamp=row[4]
            ))
        return comparisons

    def get_feedback_count(self) -> int:
        """저장된 피드백 수 반환 / Return count of stored feedback."""
        count = self._conn.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
        return count

    def get_comparison_count(self) -> int:
        """저장된 비교 수 반환 / Return count of stored comparisons."""
        count = self._conn.execute("SELECT COUNT(*) FROM comparisons").fetchone()[0]
        return count


# ─── BradleyTerryModel / 브래들리-테리 모델 ───────────────────────────
if HAS_TORCH:
    class BradleyTerryModel(nn.Module):
        """
        쌍대 비교로부터 보상을 학습하는 Bradley-Terry 모델
        Learns reward from pairwise comparisons using Bradley-Terry model.
        reward(state, action) → scalar
        2-layer FC network: (state+action) → 128 → 64 → 1
        P(a preferred over b) = sigmoid(r(a) - r(b))
        """

        def __init__(self, state_dim: int = STATE_DIM, action_dim: int = ACTION_DIM):
            super().__init__()
            input_dim = state_dim + action_dim
            self.reward_net = nn.Sequential(
                nn.Linear(input_dim, HIDDEN_DIM_1),
                nn.ReLU(),
                nn.LayerNorm(HIDDEN_DIM_1),
                nn.Dropout(0.1),
                nn.Linear(HIDDEN_DIM_1, HIDDEN_DIM_2),
                nn.ReLU(),
                nn.LayerNorm(HIDDEN_DIM_2),
                nn.Linear(HIDDEN_DIM_2, 1)
            )
            self._init_weights()
            logger.info(f"BradleyTerryModel 초기화: input_dim={input_dim} / Initialized")

        def _init_weights(self):
            """가중치 초기화 / Initialize weights."""
            for module in self.reward_net:
                if isinstance(module, nn.Linear):
                    nn.init.orthogonal_(module.weight, gain=0.01)
                    nn.init.zeros_(module.bias)

        def forward(self, state: "torch.Tensor",
                    action: "torch.Tensor") -> "torch.Tensor":
            """
            보상 스칼라 계산 / Compute reward scalar.
            Args:
                state: (batch, state_dim)
                action: (batch, action_dim)
            Returns:
                reward: (batch, 1)
            """
            x = torch.cat([state, action], dim=-1)
            return self.reward_net(x)

        def predict_preference(self, state: "torch.Tensor",
                               action_a: "torch.Tensor",
                               action_b: "torch.Tensor") -> "torch.Tensor":
            """
            P(a preferred over b) = sigmoid(r(a) - r(b))
            a가 b보다 선호될 확률 계산 / Compute probability that a is preferred over b.
            """
            r_a = self.forward(state, action_a)
            r_b = self.forward(state, action_b)
            return torch.sigmoid(r_a - r_b)


# ─── RLHFRewardModel / RLHF 보상 모델 ────────────────────────────────
class RLHFRewardModel:
    """
    학습된 보상과 작업 보상의 가중 결합 / Weighted combination of learned and task reward.
    alpha * task_reward + (1-alpha) * human_reward
    alpha starts at 1.0, decreases as more feedback collected.
    alpha는 1.0에서 시작, 피드백이 많아질수록 감소.
    Active learning: suggests actions for human feedback where uncertainty is high.
    능동 학습: 불확실성이 높은 행동에 대해 인간 피드백 제안.
    """

    def __init__(self, state_dim: int = STATE_DIM, action_dim: int = ACTION_DIM,
                 db_path: str = DB_PATH):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.alpha = INITIAL_ALPHA
        self.feedback_store = HumanFeedbackStore(db_path)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu") if HAS_TORCH else None
        self.model: Optional[BradleyTerryModel] = None
        self._lock = threading.Lock()
        self._training_count = 0

        if HAS_TORCH:
            self.model = BradleyTerryModel(state_dim, action_dim).to(self.device)
        else:
            logger.warning("PyTorch 미설치 — RLHFRewardModel 제한 모드 / Limited mode")

    def train_on_comparisons(self, comparisons: Optional[List[PairwiseComparison]] = None,
                             max_steps: int = MAX_TRAINING_STEPS) -> List[float]:
        """
        쌍대 비교 데이터로 보상 모델 훈련 / Train reward model on pairwise comparisons.
        Args:
            comparisons: 비교 목록 (None이면 DB에서 로드) / Comparison list (loads from DB if None)
            max_steps: 최대 훈련 단계 / Maximum training steps
        Returns:
            losses: 단계별 손실 / Per-step losses
        """
        if not HAS_TORCH or self.model is None:
            logger.error("PyTorch 필요 / PyTorch required")
            return []

        if comparisons is None:
            comparisons = self.feedback_store.get_all_comparisons()

        if len(comparisons) < 2:
            logger.warning("비교 데이터 부족 / Insufficient comparison data")
            return []

        optimizer = torch.optim.AdamW(self.model.parameters(), lr=LEARNING_RATE, weight_decay=0.01)
        self.model.train()
        losses = []

        for step in range(max_steps):
            # 미니배치 샘플링 / Sample mini-batch
            indices = np.random.choice(len(comparisons), size=min(BATCH_SIZE, len(comparisons)),
                                       replace=True)
            batch = [comparisons[i] for i in indices]

            states = torch.FloatTensor(np.array([c.state for c in batch])).to(self.device)
            actions_a = torch.FloatTensor(np.array([c.action_a for c in batch])).to(self.device)
            actions_b = torch.FloatTensor(np.array([c.action_b for c in batch])).to(self.device)

            # preference: 1 if a preferred, -1 if b preferred / 선호도 라벨
            prefs = torch.FloatTensor([c.preference for c in batch]).unsqueeze(-1).to(self.device)

            # Bradley-Terry 확률 계산 / Compute BT probabilities
            prob_a = self.model.predict_preference(states, actions_a, actions_b)

            # 손실: 이진 교차 엔트로피 / Loss: binary cross-entropy
            # preference > 0 → a preferred, preference < 0 → b preferred
            targets = (prefs > 0).float()
            loss = F.binary_cross_entropy(prob_a, targets)

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            optimizer.step()

            losses.append(loss.item())

            if (step + 1) % 200 == 0:
                avg_loss = np.mean(losses[-200:])
                logger.info(f"[RLHF 훈련] step {step+1}/{max_steps} loss={avg_loss:.4f}")

        # alpha 감쇠: 피드백이 많아질수록 인간 보상 가중치 증가 / Decay alpha
        self.alpha = max(MIN_ALPHA, self.alpha * ALPHA_DECAY)
        self._training_count += 1
        logger.info(f"훈련 완료: alpha={self.alpha:.3f}, steps={max_steps} / "
                     f"Training complete")
        return losses

    def reward(self, state: np.ndarray, action: np.ndarray,
               task_reward: float = 0.0) -> float:
        """
        결합 보상 계산 / Compute combined reward.
        alpha * task_reward + (1-alpha) * human_reward
        """
        human_reward = self._compute_human_reward(state, action)
        combined = self.alpha * task_reward + (1.0 - self.alpha) * human_reward
        return float(combined)

    def _compute_human_reward(self, state: np.ndarray, action: np.ndarray) -> float:
        """인간 보상 모델로부터 보상 계산 / Compute reward from human reward model."""
        if not HAS_TORCH or self.model is None:
            return 0.0

        self.model.eval()
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action_t = torch.FloatTensor(action).unsqueeze(0).to(self.device)
            r = self.model(state_t, action_t)
            # 차분 프라이버시 노이즈 추가 / Add DP noise for privacy
            noise = torch.randn_like(r) * DP_EPSILON
            r = r + noise
        return float(r.cpu().item())

    def get_uncertainty(self, state: np.ndarray, action: np.ndarray,
                        num_samples: int = 10) -> float:
        """
        보상 예측의 불확실성 추정 (MC Dropout) / Estimate prediction uncertainty via MC Dropout.
        불확실성이 높은 행동 → 인간 피드백 필요 / High uncertainty → needs human feedback.
        """
        if not HAS_TORCH or self.model is None:
            return 1.0

        # MC Dropout: 여러 번 순전파 / Multiple forward passes with dropout
        self.model.train()  # dropout 활성화 / Enable dropout
        rewards = []
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action_t = torch.FloatTensor(action).unsqueeze(0).to(self.device)
            for _ in range(num_samples):
                r = self.model(state_t, action_t)
                rewards.append(r.cpu().item())
        self.model.eval()
        return float(np.std(rewards))

    def get_stats(self) -> Dict[str, object]:
        """현재 상태 통계 반환 / Return current state statistics."""
        return {
            "alpha": self.alpha,
            "feedback_count": self.feedback_store.get_feedback_count(),
            "comparison_count": self.feedback_store.get_comparison_count(),
            "training_count": self._training_count,
        }


# ─── FeedbackCollector / 피드백 수집기 ────────────────────────────────
class FeedbackCollector:
    """
    인간 피드백 수집 인터페이스 / Interface for collecting human feedback.
    rank_actions: ranks candidate actions by preference.
    get_uncertain_actions: identifies actions needing feedback.
    rank_actions: 후보 행동을 선호도로 정렬.
    get_uncertain_actions: 피드백이 필요한 행동 식별.
    """

    def __init__(self, reward_model: RLHFRewardModel):
        self.reward_model = reward_model
        self._pending_actions: List[Dict] = []
        logger.info("FeedbackCollector 초기화 / Initialized")

    def rank_actions(self, actions: List[np.ndarray],
                     state: np.ndarray, context: str = "") -> List[Tuple[int, float]]:
        """
        후보 행동을 예상 보상으로 정렬 / Rank candidate actions by estimated reward.
        Args:
            actions: 후보 행동 목록 / List of candidate actions
            state: 현재 상태 / Current state
            context: 문맥 설명 / Contextual description
        Returns:
            ranked: (action_index, reward) 정렬 목록 / Sorted list of (index, reward)
        """
        scored = []
        for i, action in enumerate(actions):
            r = self.reward_model._compute_human_reward(state, action)
            scored.append((i, r))

        # 보상 내림차순 정렬 / Sort by reward descending
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored

    def get_uncertain_actions(self, candidates: List[Tuple[np.ndarray, np.ndarray]],
                              k: int = 5) -> List[Tuple[int, float]]:
        """
        불확실성이 가장 높은 k개 행동 반환 / Return k actions with highest uncertainty.
        능동 학습: 불확실한 행동에 대해 인간 피드백 요청 / Active learning: request feedback
        Args:
            candidates: (state, action) 튜플 목록 / List of (state, action) tuples
            k: 반환할 행동 수 / Number of actions to return
        Returns:
            uncertain: (index, uncertainty) 정렬 목록 / Sorted list of (index, uncertainty)
        """
        uncertainties = []
        for i, (state, action) in enumerate(candidates):
            unc = self.reward_model.get_uncertainty(state, action)
            uncertainties.append((i, unc))

        # 불확실성 내림차순 정렬 / Sort by uncertainty descending
        uncertainties.sort(key=lambda x: x[1], reverse=True)
        top_k = uncertainties[:k]
        return top_k

    def submit_feedback(self, state: np.ndarray, action: np.ndarray,
                        feedback_type: FeedbackType, context: str = "",
                        confidence: float = 1.0) -> int:
        """
        인간 피드백 제출 / Submit human feedback for a state-action pair.
        """
        fb = HumanFeedback(
            state=state, action=action, context=context,
            feedback_type=feedback_type, confidence=confidence
        )
        return self.reward_model.feedback_store.store_feedback(fb)

    def submit_pairwise(self, state: np.ndarray, action_a: np.ndarray,
                        action_b: np.ndarray, prefer_a: bool) -> int:
        """
        쌍대 선호도 제출 / Submit pairwise preference.
        """
        comp = PairwiseComparison(
            state=state, action_a=action_a, action_b=action_b,
            preference=1 if prefer_a else -1
        )
        return self.reward_model.feedback_store.store_comparison(comp)

    def generate_comparison_pairs(self, state: np.ndarray,
                                  actions: List[np.ndarray],
                                  n_pairs: int = 5) -> List[Tuple[int, int]]:
        """
        비교할 행동 쌍 생성 (불확실성 기반) / Generate action pairs for comparison (uncertainty-based).
        가장 불확실한 행동 쌍 우선 선택 / Prioritize most uncertain action pairs.
        """
        candidates = [(state, a) for a in actions]
        uncertain = self.get_uncertain_actions(candidates, k=min(n_pairs * 2, len(actions)))
        uncertain_indices = [idx for idx, _ in uncertain]

        # 불확실한 행동 간 쌍 생성 / Create pairs among uncertain actions
        pairs = []
        for i in range(0, len(uncertain_indices) - 1, 2):
            pairs.append((uncertain_indices[i], uncertain_indices[i + 1]))

        return pairs[:n_pairs]


# ─── Module-level demo / 모듈 레벨 데모 ──────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    if not HAS_TORCH:
        logger.error("PyTorch 설치 필요 / PyTorch required")
    else:
        # 데모: RLHF 보상 모델 훈련 / Demo: train RLHF reward model
        reward_model = RLHFRewardModel(state_dim=STATE_DIM, action_dim=ACTION_DIM,
                                       db_path=":memory:")

        # 가상 쌍대 비교 생성 / Generate synthetic pairwise comparisons
        comparisons = []
        for _ in range(100):
            state = np.random.randn(STATE_DIM).astype(np.float32)
            action_a = np.random.randn(ACTION_DIM).astype(np.float32)
            action_b = np.random.randn(ACTION_DIM).astype(np.float32)
            # a가 더 나은지 무작위 결정 / Randomly decide if a is better
            pref = 1 if np.random.rand() > 0.5 else -1
            comparisons.append(PairwiseComparison(
                state=state, action_a=action_a, action_b=action_b, preference=pref
            ))

        losses = reward_model.train_on_comparisons(comparisons, max_steps=200)
        logger.info(f"훈련 손실: {losses[-5:]} / Training losses (last 5)")

        # 보상 계산 데모 / Reward computation demo
        state = np.random.randn(STATE_DIM).astype(np.float32)
        action = np.random.randn(ACTION_DIM).astype(np.float32)
        r = reward_model.reward(state, action, task_reward=0.5)
        logger.info(f"결합 보상: {r:.4f} / Combined reward")

        # FeedbackCollector 데모 / FeedbackCollector demo
        collector = FeedbackCollector(reward_model)
        actions = [np.random.randn(ACTION_DIM).astype(np.float32) for _ in range(10)]
        ranked = collector.rank_actions(actions, state)
        logger.info(f"행동 순위 (상위 3): {ranked[:3]} / Top 3 ranked actions")

        uncertain = collector.get_uncertain_actions(
            [(state, a) for a in actions], k=3
        )
        logger.info(f"불확실한 행동: {uncertain} / Uncertain actions")

        logger.info("rlhf_reward.py 데모 완료 / Demo complete")
