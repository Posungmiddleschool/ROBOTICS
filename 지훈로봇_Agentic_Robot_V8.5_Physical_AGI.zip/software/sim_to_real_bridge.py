#!/usr/bin/env python3
"""
sim_to_real_bridge.py — V8.5 Sim-to-Real Domain Adaptation Bridge
지훈 로봇 물리적 AGI — V8.5 시뮬레이션-실제 환경 적응 브릿지

The reality gap is the fundamental challenge in robotics: models trained in
simulation fail in the real world due to unmodeled friction, sensor noise,
latency, and material properties. This module bridges that gap.

현실 갭은 로봇공학의 근본적 과제입니다: 시뮬레이션에서 학습된 모델은
모델링되지 않은 마찰, 센서 노이즈, 지연, 재료 특성으로 인해 실제
환경에서 실패합니다. 이 모듈은 그 갭을 연결합니다.

Components / 구성요소:
  1. DomainGapEstimator  — 시뮬-실제 분포 거리 측정 (MMD)
  2. DomainAdapter       — 시뮬 학습 모델을 실제 환경에 적응
  3. RealityMonitor      — 실제 환경 성능 드리프트 모니터링

Key Algorithms / 핵심 알고리즘:
  - MMD (Maximum Mean Discrepancy): 분포 거리 측정
  - Progressive Domain Adaptation: 점진적 도메인 적응
  - Performance Drift Detection: 성능 저하 조기 감지

Hardware: Dual Jetson Orin NX 16GB
AI Model: Gemma 4 E4B Q4_K_M
Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple, Union

import numpy as np

# ─── PyTorch 선택적 임포트 / Optional PyTorch Import ─────────────────────────

TORCH_AVAILABLE = False
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.utils.data import DataLoader, Dataset
    TORCH_AVAILABLE = True
except ImportError:
    torch = None
    nn = None
    F = None
    DataLoader = None
    Dataset = None

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.sim_to_real_bridge")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 상수 / Constants ────────────────────────────────────────────────────────

STATE_DIM = 62
EPS = 1e-8
MMD_KERNEL_BANDWIDTH = 1.0  # RBF 커널 대역폭 / RBF kernel bandwidth
DRIFT_WINDOW = 50            # 드리프트 탐지 윈도우 / Drift detection window
DRIFT_THRESHOLD = 0.15       # 드리프트 탐지 임계값 / Drift detection threshold
FINE_TUNE_LR = 1e-4          # 파인튜닝 학습률 / Fine-tuning learning rate
ADAPTATION_STEPS = 5         # 점진적 적응 단계 수 / Progressive adaptation steps


class AdaptationPhase(str, Enum):
    """적응 단계 / Adaptation phases."""
    SIM_ONLY = "sim_only"
    MIXED_75_25 = "mixed_75_25"
    MIXED_50_50 = "mixed_50_50"
    MIXED_25_75 = "mixed_25_75"
    REAL_ONLY = "real_only"
    DEPLOYED = "deployed"


class DriftType(str, Enum):
    """드리프트 유형 / Drift types."""
    GRADUAL = "gradual"        # 점진적 변화 / Gradual change
    SUDDEN = "sudden"          # 급격한 변화 / Sudden change
    CYCLICAL = "cyclical"      # 주기적 변화 / Cyclical change
    SENSOR_DEGRADATION = "sensor_degradation"  # 센서 열화 / Sensor degradation
    MECHANICAL_WEAR = "mechanical_wear"          # 기계적 마모 / Mechanical wear
    ENVIRONMENT_CHANGE = "environment_change"    # 환경 변화 / Environment change


# ─── 데이터 클래스 / Data Classes ────────────────────────────────────────────


@dataclass
class DomainMetrics:
    """
    도메인 메트릭 / Domain metrics.

    시뮬레이션과 실제 환경 간의 성능 차이를 기록합니다.

    Attributes:
        metric_id: 메트릭 식별자
        sim_performance: 시뮬레이션 성능 (0~1)
        real_performance: 실제 환경 성능 (0~1)
        domain_gap: 도메인 갭 (MMD)
        failure_modes: 실패 모드 목록
        timestamp: 기록 시각
    """
    metric_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    sim_performance: float = 0.0
    real_performance: float = 0.0
    domain_gap: float = 0.0
    failure_modes: List[str] = field(default_factory=list)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class AdaptationRecord:
    """
    적응 기록 / Adaptation record.

    도메인 적응 과정의 각 단계를 기록합니다.
    """
    record_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    phase: str = AdaptationPhase.SIM_ONLY.value
    sim_ratio: float = 1.0
    real_ratio: float = 0.0
    validation_score: float = 0.0
    domain_gap: float = 0.0
    steps_completed: int = 0
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ─── SQLite 저장소 / SQLite Repository ───────────────────────────────────────


class Sim2RealRepository:
    """
    Sim-to-Real 적응 기록 저장소 / Sim-to-Real adaptation record repository.

    SQLite에 적응 과정의 모든 메트릭을 영속화합니다.
    """

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS domain_metrics (
        metric_id TEXT PRIMARY KEY,
        sim_performance REAL,
        real_performance REAL,
        domain_gap REAL,
        failure_modes_json TEXT,
        timestamp TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_dm_gap ON domain_metrics(domain_gap);

    CREATE TABLE IF NOT EXISTS adaptation_history (
        record_id TEXT PRIMARY KEY,
        phase TEXT NOT NULL,
        sim_ratio REAL,
        real_ratio REAL,
        validation_score REAL,
        domain_gap REAL,
        steps_completed INTEGER DEFAULT 0,
        timestamp TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_ah_phase ON adaptation_history(phase);

    CREATE TABLE IF NOT EXISTS drift_events (
        event_id TEXT PRIMARY KEY,
        drift_type TEXT NOT NULL,
        severity REAL DEFAULT 0.0,
        baseline_score REAL,
        current_score REAL,
        suggested_action_json TEXT,
        timestamp TEXT NOT NULL
    );
    """

    def __init__(self, db_path: Union[str, Path] = "sim2real.db") -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(
                str(self._db_path), check_same_thread=False
            )
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript(self.SCHEMA)
        conn.commit()

    def save_metrics(self, metrics: DomainMetrics) -> bool:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT OR REPLACE INTO domain_metrics
                (metric_id, sim_performance, real_performance, domain_gap,
                 failure_modes_json, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    metrics.metric_id, metrics.sim_performance,
                    metrics.real_performance, metrics.domain_gap,
                    json.dumps(metrics.failure_modes), metrics.timestamp,
                ),
            )
            conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error("메트릭 저장 실패: %s", e)
            return False

    def save_adaptation(self, record: AdaptationRecord) -> bool:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT OR REPLACE INTO adaptation_history
                (record_id, phase, sim_ratio, real_ratio, validation_score,
                 domain_gap, steps_completed, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    record.record_id, record.phase, record.sim_ratio,
                    record.real_ratio, record.validation_score,
                    record.domain_gap, record.steps_completed, record.timestamp,
                ),
            )
            conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error("적응 기록 저장 실패: %s", e)
            return False

    def save_drift_event(
        self, drift_type: str, severity: float,
        baseline: float, current: float,
        suggested_action: Dict[str, Any],
    ) -> bool:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT INTO drift_events
                (event_id, drift_type, severity, baseline_score,
                 current_score, suggested_action_json, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    uuid.uuid4().hex[:12], drift_type, severity,
                    baseline, current, json.dumps(suggested_action),
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
            conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error("드리프트 이벤트 저장 실패: %s", e)
            return False


# ─── 도메인 갭 추정기 / Domain Gap Estimator ────────────────────────────────


class DomainGapEstimator:
    """
    시뮬-실제 도메인 갭 추정기 / Sim-to-Real domain gap estimator.

    MMD (Maximum Mean Discrepancy)를 사용하여 시뮬레이션과
    실제 데이터의 분포 거리를 측정합니다. 또한 시뮬레이션에서는
    성공하지만 실제 환경에서는 실패하는 패턴을 식별합니다.

    MMD = ||1/n Σ k(x_sim, ·) - 1/m Σ k(x_real, ·)||²

    Usage:
        estimator = DomainGapEstimator()
        gap = estimator.compute_distribution_distance(sim_data, real_data)
        failures = estimator.identify_failure_modes(sim_results, real_results)
    """

    def __init__(
        self,
        kernel_bandwidth: float = MMD_KERNEL_BANDWIDTH,
    ) -> None:
        self._bandwidth = kernel_bandwidth
        self._history: List[DomainMetrics] = []
        self._lock = threading.Lock()
        logger.info(
            "DomainGapEstimator 초기화: 대역폭=%.2f", kernel_bandwidth
        )

    def _rbf_kernel(
        self, x: np.ndarray, y: np.ndarray
    ) -> np.ndarray:
        """
        RBF (가우시안) 커널 계산 / Compute RBF (Gaussian) kernel.

        k(x, y) = exp(-||x - y||² / (2σ²))

        Args:
            x: 첫 번째 샘플 세트 [n, d]
            y: 두 번째 샘플 세트 [m, d]

        Returns:
            np.ndarray: 커널 행렬 [n, m]
        """
        x = np.asarray(x, dtype=np.float64)
        y = np.asarray(y, dtype=np.float64)

        # 차원 맞추기 / Match dimensions
        min_dim = min(x.shape[-1], y.shape[-1]) if x.ndim > 1 and y.ndim > 1 else 1
        if x.ndim > 1:
            x = x[:, :min_dim]
        if y.ndim > 1:
            y = y[:, :min_dim]

        if x.ndim == 1:
            x = x.reshape(-1, 1)
        if y.ndim == 1:
            y = y.reshape(-1, 1)

        # ||x - y||² = ||x||² + ||y||² - 2 x·y^T
        xx = np.sum(x ** 2, axis=1, keepdims=True)
        yy = np.sum(y ** 2, axis=1, keepdims=True)
        xy = x @ y.T

        dist_sq = xx + yy.T - 2 * xy
        dist_sq = np.maximum(dist_sq, 0.0)  # 수치 안정성

        gamma = 1.0 / (2.0 * self._bandwidth ** 2)
        return np.exp(-gamma * dist_sq)

    def compute_distribution_distance(
        self,
        sim_data: Union[np.ndarray, List[np.ndarray]],
        real_data: Union[np.ndarray, List[np.ndarray]],
    ) -> float:
        """
        MMD (Maximum Mean Discrepancy) 계산 / Compute MMD.

        시뮬레이션과 실제 데이터의 분포 거리를 측정합니다.
        MMD = 0이면 두 분포가 동일하고, 클수록 차이가 큽니다.

        Args:
            sim_data: 시뮬레이션 데이터 (상태 벡터 목록)
            real_data: 실제 환경 데이터 (상태 벡터 목록)

        Returns:
            float: MMD 값 (0 이상, 작을수록 유사)
        """
        sim_arr = np.asarray(sim_data, dtype=np.float64)
        real_arr = np.asarray(real_data, dtype=np.float64)

        if sim_arr.ndim == 1:
            sim_arr = sim_arr.reshape(-1, 1)
        if real_arr.ndim == 1:
            real_arr = real_arr.reshape(-1, 1)

        n = sim_arr.shape[0]
        m = real_arr.shape[0]

        if n == 0 or m == 0:
            return float("inf")

        # MMD² = E[k(X,X')] + E[k(Y,Y')] - 2E[k(X,Y)]
        k_xx = self._rbf_kernel(sim_arr, sim_arr)
        k_yy = self._rbf_kernel(real_arr, real_arr)
        k_xy = self._rbf_kernel(sim_arr, real_arr)

        # 대각 제외 평균 / Mean excluding diagonal
        mmd_xx = (np.sum(k_xx) - np.trace(k_xx)) / max(n * (n - 1), 1)
        mmd_yy = (np.sum(k_yy) - np.trace(k_yy)) / max(m * (m - 1), 1)
        mmd_xy = np.mean(k_xy)

        mmd_sq = mmd_xx + mmd_yy - 2 * mmd_xy
        mmd = math.sqrt(max(mmd_sq, 0.0))

        logger.debug("MMD 계산: %.4f (sim=%d, real=%d)", mmd, n, m)
        return float(mmd)

    def identify_failure_modes(
        self,
        sim_results: List[Dict[str, Any]],
        real_results: List[Dict[str, Any]],
    ) -> List[str]:
        """
        실패 모드 식별 / Identify failure modes.

        시뮬레이션에서는 성공하지만 실제 환경에서는 실패하는
        패턴을 분석하여 실패 모드를 식별합니다.

        Args:
            sim_results: 시뮬레이션 결과 목록
            real_results: 실제 환경 결과 목록

        Returns:
            List[str]: 식별된 실패 모드 목록
        """
        failure_modes: List[str] = []

        # 시뮬 성공률 vs 실제 성공률 / Sim vs real success rate
        sim_success_rate = np.mean([
            r.get("success", 0.0) for r in sim_results
        ]) if sim_results else 0.0
        real_success_rate = np.mean([
            r.get("success", 0.0) for r in real_results
        ]) if real_results else 0.0

        success_gap = sim_success_rate - real_success_rate
        if success_gap > 0.3:
            failure_modes.append("large_success_gap")

        # 카테고리별 실패 분석 / Per-category failure analysis
        sim_by_category: Dict[str, List[float]] = {}
        real_by_category: Dict[str, List[float]] = {}

        for r in sim_results:
            cat = r.get("category", "default")
            sim_by_category.setdefault(cat, []).append(r.get("success", 0.0))

        for r in real_results:
            cat = r.get("category", "default")
            real_by_category.setdefault(cat, []).append(r.get("success", 0.0))

        for cat in set(list(sim_by_category.keys()) + list(real_by_category.keys())):
            sim_avg = np.mean(sim_by_category.get(cat, [0.0]))
            real_avg = np.mean(real_by_category.get(cat, [0.0]))
            if sim_avg - real_avg > 0.2:
                failure_modes.append(f"category_{cat}_gap")

        # 특정 조건에서의 실패 / Failures under specific conditions
        terrain_failures = 0
        for r in real_results:
            if not r.get("success", False):
                terrain = r.get("terrain", "flat")
                if terrain in ("slope", "gravel", "wet"):
                    terrain_failures += 1

        if terrain_failures > len(real_results) * 0.3:
            failure_modes.append("terrain_sensitivity")

        # 파지력 불일치 / Grip force mismatch
        grip_failures = sum(
            1 for r in real_results
            if r.get("task_type") == "grip" and not r.get("success", False)
        )
        if grip_failures > len(real_results) * 0.2:
            failure_modes.append("grip_force_mismatch")

        # 속도 불일치 / Velocity mismatch
        sim_speeds = [r.get("execution_speed", 1.0) for r in sim_results]
        real_speeds = [r.get("execution_speed", 1.0) for r in real_results]
        if sim_speeds and real_speeds:
            speed_ratio = np.mean(real_speeds) / max(np.mean(sim_speeds), EPS)
            if speed_ratio < 0.7:
                failure_modes.append("execution_speed_mismatch")

        logger.info(
            "실패 모드 식별: %d개 (%s)",
            len(failure_modes), ", ".join(failure_modes),
        )
        return failure_modes

    def estimate_gap(self, metrics: DomainMetrics) -> DomainMetrics:
        """
        도메인 갭 추정 및 기록 / Estimate and record domain gap.

        Args:
            metrics: 측정된 메트릭

        Returns:
            DomainMetrics: 갭 정보가 추가된 메트릭
        """
        metrics.domain_gap = abs(
            metrics.sim_performance - metrics.real_performance
        )
        with self._lock:
            self._history.append(metrics)
        return metrics


# ─── 도메인 어댑터 / Domain Adapter ─────────────────────────────────────────


class DomainAdapter:
    """
    시뮬-실제 도메인 적응기 / Sim-to-Real domain adapter.

    시뮬레이션에서 학습된 모델을 실제 환경에 적응시킵니다.
    점진적 도메인 적응(Progressive Domain Adaptation)을 통해
    시뮬 → 혼합 → 실제 환경으로 단계적으로 전이합니다.

    Usage:
        adapter = DomainAdapter()
        adapted = adapter.fine_tune_on_real(model, real_data, n_steps=100)
        adapter.progressive_domain_adaptation(model, sim_loader, real_loader)
    """

    def __init__(
        self,
        repository: Optional[Sim2RealRepository] = None,
        gap_estimator: Optional[DomainGapEstimator] = None,
    ) -> None:
        self._repository = repository or Sim2RealRepository()
        self._gap_estimator = gap_estimator or DomainGapEstimator()
        self._current_phase = AdaptationPhase.SIM_ONLY
        self._adaptation_history: List[AdaptationRecord] = []
        self._lock = threading.Lock()

        logger.info("DomainAdapter 초기화")

    def fine_tune_on_real(
        self,
        model: Any,
        real_data: List[Dict[str, Any]],
        n_steps: int = 100,
        learning_rate: float = FINE_TUNE_LR,
    ) -> Any:
        """
        실제 데이터로 파인튜닝 / Fine-tune on real data.

        시뮬레이션에서 학습된 모델을 실제 환경 데이터로 파인튜닝합니다.
        작은 학습률을 사용하여 기존 지식을 보존합니다.

        Args:
            model: 학습된 모델 (PyTorch 모델 또는 numpy 기반)
            real_data: 실제 환경 데이터
            n_steps: 파인튜닝 스텝 수
            learning_rate: 학습률

        Returns:
            적응된 모델
        """
        if not real_data:
            logger.warning("실제 데이터 없음 → 모델 그대로 반환")
            return model

        if TORCH_AVAILABLE and model is not None and isinstance(model, nn.Module):
            return self._finetune_torch(model, real_data, n_steps, learning_rate)
        else:
            return self._finetune_numpy(model, real_data, n_steps, learning_rate)

    def _finetune_torch(
        self,
        model: nn.Module,
        real_data: List[Dict[str, Any]],
        n_steps: int,
        lr: float,
    ) -> nn.Module:
        """
        PyTorch 모델 파인튜닝 / Fine-tune PyTorch model.

        실제 환경 데이터로 모델을 파인튜닝합니다.
        낮은 학습률과 작은 배치로 기존 지식을 보존합니다.
        """
        optimizer = torch.optim.Adam(
            model.parameters(), lr=lr, weight_decay=1e-5
        )

        model.train()
        total_loss = 0.0
        steps_done = 0

        for step in range(n_steps):
            # 미니배치 샘플링 / Mini-batch sampling
            indices = np.random.choice(len(real_data), size=min(32, len(real_data)))
            batch = [real_data[i] for i in indices]

            try:
                states = torch.tensor(
                    np.array([d.get("state", np.zeros(STATE_DIM)) for d in batch]),
                    dtype=torch.float32,
                )
                targets = torch.tensor(
                    np.array([d.get("action", np.zeros(16)) for d in batch]),
                    dtype=torch.float32,
                )

                optimizer.zero_grad()
                outputs = model(states)
                loss = F.mse_loss(outputs, targets)

                # 보존 정규화: 파라미터 변화 제한 / Conservation regularization
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()

                total_loss += loss.item()
                steps_done += 1
            except Exception as e:
                logger.warning("파인튜닝 스텝 오류: %s", e)
                continue

        avg_loss = total_loss / max(steps_done, 1)
        logger.info(
            "PyTorch 파인튜닝 완료: %d/%d 스텝, 평균 손실=%.4f",
            steps_done, n_steps, avg_loss,
        )

        # 기록 저장 / Save record
        record = AdaptationRecord(
            phase=AdaptationPhase.REAL_ONLY.value,
            sim_ratio=0.0,
            real_ratio=1.0,
            validation_score=max(0.0, 1.0 - avg_loss),
            steps_completed=steps_done,
        )
        self._repository.save_adaptation(record)

        return model

    def _finetune_numpy(
        self,
        model: Any,
        real_data: List[Dict[str, Any]],
        n_steps: int,
        lr: float,
    ) -> Any:
        """
        Numpy 기반 파인튜닝 — 실제 그래디언트 계산 / Numpy-based fine-tuning with actual gradient computation.

        모델이 학습 가능한 가중치 딕셔너리를 가진다고 가정합니다.
        가중치가 {"layer_name": np.ndarray} 형태인 경우 수동 그래디언트 하강을 수행합니다.
        """
        if model is None:
            return model

        steps_done = 0
        total_loss = 0.0

        # ── 모델의 학습 가능한 가중치 추출 / Extract learnable weights ──
        weights: Optional[Dict[str, np.ndarray]] = None
        if hasattr(model, "weights") and isinstance(model.weights, dict):
            weights = model.weights
        elif hasattr(model, "get_weights") and callable(model.get_weights):
            try:
                w = model.get_weights()
                if isinstance(w, dict):
                    weights = w
            except Exception:
                pass
        elif isinstance(model, dict) and all(isinstance(v, np.ndarray) for v in model.values()):
            weights = model

        # ── 모델에 online_update 메서드가 있으면 우선 사용 ──
        if hasattr(model, "online_update"):
            for step in range(min(n_steps, len(real_data))):
                data_point = real_data[step % len(real_data)]
                model.online_update([data_point], learning_rate=lr)
                steps_done += 1
            logger.info("Numpy 파인튜닝 (online_update): %d 스텝 완료", steps_done)
            return model

        # ── 모델에 predict 메서드가 있으면 그래디언트 계산 / Compute gradients if model has predict ──
        if weights is not None and hasattr(model, "predict"):
            for step in range(min(n_steps, len(real_data))):
                data_point = real_data[step % len(real_data)]
                state = np.asarray(data_point.get("state", np.zeros(STATE_DIM)), dtype=np.float64).flatten()
                target = np.asarray(data_point.get("action", np.zeros(16)), dtype=np.float64).flatten()

                try:
                    # 순전체 / Forward pass
                    prediction = np.asarray(model.predict(state), dtype=np.float64).flatten()
                    min_len = min(len(prediction), len(target))
                    if min_len == 0:
                        continue

                    # 손실 = MSE / Loss = MSE
                    error = prediction[:min_len] - target[:min_len]
                    loss = float(np.mean(error ** 2))
                    total_loss += loss

                    # 그래디언트 계산 (수치 미분) / Compute gradients via numerical differentiation
                    for layer_name, layer_weights in weights.items():
                        grad = np.zeros_like(layer_weights)
                        eps = 1e-5  # 수치 미분 스텝 / Numerical diff step

                        # 샘플링으로 계산량 제한 (최대 100개 파라미터) / Limit computation
                        flat_w = layer_weights.flatten()
                        n_params = min(len(flat_w), 100)
                        indices = np.random.choice(len(flat_w), n_params, replace=False)

                        for idx in indices:
                            orig_val = flat_w[idx]

                            # f(w + eps)
                            flat_w[idx] = orig_val + eps
                            weights[layer_name] = flat_w.reshape(layer_weights.shape)
                            pred_plus = np.asarray(model.predict(state), dtype=np.float64).flatten()
                            loss_plus = float(np.mean((pred_plus[:min_len] - target[:min_len]) ** 2))

                            # f(w - eps)
                            flat_w[idx] = orig_val - eps
                            weights[layer_name] = flat_w.reshape(layer_weights.shape)
                            pred_minus = np.asarray(model.predict(state), dtype=np.float64).flatten()
                            loss_minus = float(np.mean((pred_minus[:min_len] - target[:min_len]) ** 2))

                            # 그래디언트 / Gradient
                            grad_flat = (loss_plus - loss_minus) / (2 * eps)
                            grad_flattened = grad.flatten()
                            grad_flattened[idx] = grad_flat
                            grad = grad_flattened.reshape(layer_weights.shape)

                            # 원래 값 복원 / Restore original value
                            flat_w[idx] = orig_val

                        weights[layer_name] = flat_w.reshape(layer_weights.shape)

                        # 가중치 업데이트: w = w - lr * grad / Weight update
                        weights[layer_name] -= lr * grad

                    steps_done += 1
                except Exception as e:
                    logger.debug("파인튜닝 스텝 %d 오류: %s", step, e)
                    continue

            avg_loss = total_loss / max(steps_done, 1)
            logger.info(
                "Numpy 파인튜닝 (그래디언트): %d/%d 스텝, 평균 손실=%.4f",
                steps_done, n_steps, avg_loss,
            )
            return model

        # ── 폴백: online_update도 predict도 없음 / Fallback ──
        logger.warning(
            "Numpy 파인튜닝: 모델에 online_update/predict/weights 미지원 — %d 스텝 건너뜀",
            n_steps,
        )
        return model

    def progressive_domain_adaptation(
        self,
        model: Any,
        sim_loader: Any,
        real_loader: Any,
        n_epochs: int = 5,
    ) -> Dict[str, Any]:
        """
        점진적 도메인 적응 / Progressive domain adaptation.

        시뮬레이션 데이터에서 실제 환경 데이터로 점진적으로 전이합니다.
        혼합 비율을 75:25 → 50:50 → 25:75로 변경하며 학습합니다.

        Args:
            model: 학습된 모델
            sim_loader: 시뮬레이션 데이터 로더
            real_loader: 실제 환경 데이터 로더
            n_epochs: 단계별 에포크 수

        Returns:
            Dict: 적응 결과 메트릭
        """
        phases = [
            (AdaptationPhase.MIXED_75_25, 0.75, 0.25),
            (AdaptationPhase.MIXED_50_50, 0.50, 0.50),
            (AdaptationPhase.MIXED_25_75, 0.25, 0.75),
        ]

        results = {
            "phases_completed": 0,
            "final_gap": 0.0,
            "final_score": 0.0,
        }

        for phase, sim_ratio, real_ratio in phases:
            logger.info(
                "적응 단계: %s (시뮬=%.0f%%, 실제=%.0f%%)",
                phase.value, sim_ratio * 100, real_ratio * 100,
            )

            # 혼합 배치 생성 / Create mixed batches
            mixed_data = self._create_mixed_data(
                sim_loader, real_loader, sim_ratio, real_ratio, n_batches=20
            )

            # 파인튜닝 / Fine-tune
            model = self.fine_tune_on_real(model, mixed_data, n_steps=n_epochs * 20)

            # 검증 / Validate
            record = AdaptationRecord(
                phase=phase.value,
                sim_ratio=sim_ratio,
                real_ratio=real_ratio,
                steps_completed=n_epochs * 20,
            )
            self._repository.save_adaptation(record)

            with self._lock:
                self._adaptation_history.append(record)
                self._current_phase = phase

            results["phases_completed"] += 1

        logger.info(
            "점진적 도메인 적응 완료: %d단계",
            results["phases_completed"],
        )
        return results

    def _create_mixed_data(
        self,
        sim_loader: Any,
        real_loader: Any,
        sim_ratio: float,
        real_ratio: float,
        n_batches: int = 20,
    ) -> List[Dict[str, Any]]:
        """
        시뮬/실제 혼합 데이터 생성 / Create mixed sim/real data.

        Args:
            sim_loader: 시뮬레이션 데이터 (list, tuple, DataLoader, or iterable)
            real_loader: 실제 환경 데이터 (list, tuple, DataLoader, or iterable)
            sim_ratio: 시뮬레이션 비율
            real_ratio: 실제 환경 비율
            n_batches: 배치 수

        Returns:
            List[Dict]: 혼합 데이터 목록
        """
        mixed: List[Dict[str, Any]] = []

        # ── 입력 데이터를 리스트로 변환 / Convert input data to lists ──
        # DataLoader, list, tuple, generator, any iterable 지원
        def _to_list(loader: Any) -> List[Any]:
            if loader is None:
                return []
            if isinstance(loader, (list, tuple)):
                return list(loader)
            # PyTorch DataLoader 지원 / Support PyTorch DataLoader
            if TORCH_AVAILABLE and DataLoader is not None and isinstance(loader, DataLoader):
                try:
                    return [item for batch in loader for item in (
                        batch if isinstance(batch, (list, tuple)) else [batch]
                    )]
                except Exception as e:
                    logger.warning("DataLoader 변환 오류: %s", e)
                    return []
            # 일반 iterable (generator 등) / Generic iterable
            if hasattr(loader, "__iter__"):
                try:
                    return list(loader)
                except Exception as e:
                    logger.warning("iterable 변환 오류: %s", e)
                    return []
            logger.warning(
                "지원하지 않는 로더 타입: %s — 빈 리스트 사용",
                type(loader).__name__,
            )
            return []

        sim_data = _to_list(sim_loader)
        real_data = _to_list(real_loader)

        if not sim_data and not real_data:
            logger.warning(
                "시뮬/실제 데이터 모두 비어있음 — 혼합 데이터 생성 불가 "
                "(sim=%d, real=%d)", len(sim_data), len(real_data),
            )
            return mixed

        for _ in range(n_batches):
            n_sim = int(32 * sim_ratio)
            n_real = 32 - n_sim

            for _ in range(n_sim):
                if sim_data:
                    item = sim_data[np.random.randint(len(sim_data))]
                    # PyTorch 텐서 → dict 변환 / Convert tensors to dict
                    if not isinstance(item, dict):
                        if TORCH_AVAILABLE and isinstance(item, torch.Tensor):
                            item = {"state": item.detach().cpu().numpy()}
                        elif isinstance(item, (list, tuple)):
                            item = {"state": np.asarray(item)}
                        else:
                            item = {"state": np.asarray(item)}
                    item["domain"] = "sim"
                    mixed.append(item)

            for _ in range(n_real):
                if real_data:
                    item = real_data[np.random.randint(len(real_data))]
                    if not isinstance(item, dict):
                        if TORCH_AVAILABLE and isinstance(item, torch.Tensor):
                            item = {"state": item.detach().cpu().numpy()}
                        elif isinstance(item, (list, tuple)):
                            item = {"state": np.asarray(item)}
                        else:
                            item = {"state": np.asarray(item)}
                    item["domain"] = "real"
                    mixed.append(item)

        logger.debug(
            "혼합 데이터 생성: %d개 (시뮬=%d, 실제=%d)",
            len(mixed), int(len(mixed) * sim_ratio) if mixed else 0,
            int(len(mixed) * real_ratio) if mixed else 0,
        )
        return mixed

    def get_current_phase(self) -> str:
        """현재 적응 단계 반환 / Return current adaptation phase."""
        return self._current_phase.value


# ─── 실제 환경 모니터 / Reality Monitor ─────────────────────────────────────


class RealityMonitor:
    """
    실제 환경 성능 드리프트 모니터 / Real-world performance drift monitor.

    배포된 모델의 실제 환경 성능을 지속적으로 모니터링하고,
    성능 저하를 조기에 감지하여 적응을 제안합니다.

    드리프트 유형 / Drift types:
    - GRADUAL: 마모, 열화로 인한 점진적 저하
    - SUDDEN: 손상, 환경 급변으로 인한 급격한 저하
    - SENSOR_DEGRADATION: 센서 정확도 저하
    - MECHANICAL_WEAR: 기계적 마모

    Usage:
        monitor = RealityMonitor(baseline_metrics)
        if monitor.detect_performance_drop(current_metrics):
            suggestion = monitor.suggest_adaptation(drop_type)
    """

    def __init__(
        self,
        baseline: Optional[Dict[str, float]] = None,
        window_size: int = DRIFT_WINDOW,
        threshold: float = DRIFT_THRESHOLD,
        repository: Optional[Sim2RealRepository] = None,
    ) -> None:
        self._baseline = baseline or {"success_rate": 0.8, "avg_reward": 0.5}
        self._window_size = window_size
        self._threshold = threshold
        self._repository = repository or Sim2RealRepository()

        # 슬라이딩 윈도우 / Sliding window
        self._metric_history: Dict[str, Deque[float]] = {
            key: deque(maxlen=window_size) for key in self._baseline
        }

        # 드리프트 상태 / Drift state
        self._detected_drifts: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

        logger.info(
            "RealityMonitor 초기화: 기준=%s, 윈도우=%d, 임계값=%.2f",
            {k: round(v, 2) for k, v in self._baseline.items()},
            window_size, threshold,
        )

    def update(self, current_metrics: Dict[str, float]) -> Dict[str, Any]:
        """
        현재 메트릭 업데이트 / Update with current metrics.

        Args:
            current_metrics: 현재 성능 메트릭

        Returns:
            Dict: 업데이트 결과 (드리프트 감지 여부 등)
        """
        with self._lock:
            for key, value in current_metrics.items():
                if key in self._metric_history:
                    self._metric_history[key].append(float(value))

        # 드리프트 감지 / Detect drift
        drift_detected = self.detect_performance_drop(current_metrics)

        return {
            "drift_detected": drift_detected,
            "current_metrics": current_metrics,
            "baseline": self._baseline,
        }

    def detect_performance_drop(
        self,
        current_metrics: Dict[str, float],
    ) -> bool:
        """
        성능 저하 감지 / Detect performance drop.

        현재 메트릭이 베이스라인에서 통계적으로 유의하게
        벗어났는지 확인합니다.

        Args:
            current_metrics: 현재 성능 메트릭

        Returns:
            bool: 성능 저하 감지 여부
        """
        any_drop = False

        for key, baseline_val in self._baseline.items():
            current_val = current_metrics.get(key, baseline_val)
            history = self._metric_history.get(key, deque())

            if len(history) < 5:
                continue

            # 이동 평균 / Moving average
            recent_avg = float(np.mean(list(history)[-10:]))

            # 베이스라인 대비 하락 / Drop relative to baseline
            relative_drop = (baseline_val - recent_avg) / max(abs(baseline_val), EPS)

            if relative_drop > self._threshold:
                any_drop = True

                # 드리프트 유형 분류 / Classify drift type
                drift_type = self._classify_drift(key, history)

                drift_event = {
                    "metric": key,
                    "drift_type": drift_type,
                    "baseline": baseline_val,
                    "current_avg": recent_avg,
                    "relative_drop": float(relative_drop),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

                with self._lock:
                    self._detected_drifts.append(drift_event)

                # 저장소에 기록 / Record in repository
                self._repository.save_drift_event(
                    drift_type=drift_type,
                    severity=float(relative_drop),
                    baseline=baseline_val,
                    current=recent_avg,
                    suggested_action=self.suggest_adaptation(drift_type),
                )

                logger.warning(
                    "성능 저하 감지: %s (%s) — 기준=%.3f, 현재=%.3f, 하락=%.1f%%",
                    key, drift_type, baseline_val, recent_avg,
                    relative_drop * 100,
                )

        return any_drop

    def _classify_drift(
        self, metric_key: str, history: Deque[float]
    ) -> str:
        """
        드리프트 유형 분류 / Classify drift type.

        메트릭 변화 패턴을 분석하여 드리프트 유형을 분류합니다.

        Args:
            metric_key: 메트릭 키
            history: 메트릭 히스토리

        Returns:
            str: 드리프트 유형
        """
        hist_list = list(history)
        if len(hist_list) < 10:
            return DriftType.GRADUAL.value

        # 급격한 변화 탐지 / Detect sudden change
        diffs = np.abs(np.diff(hist_list))
        max_diff = float(np.max(diffs))
        avg_diff = float(np.mean(diffs))

        if max_diff > avg_diff * 5.0:
            return DriftType.SUDDEN.value

        # 센서 특화 메트릭 / Sensor-specific metrics
        if "sensor" in metric_key or "noise" in metric_key:
            return DriftType.SENSOR_DEGRADATION.value

        # 기계적 마모 의심 / Suspect mechanical wear
        if "torque" in metric_key or "force" in metric_key or "position" in metric_key:
            return DriftType.MECHANICAL_WEAR.value

        # 점진적 변화 / Gradual change
        first_half = float(np.mean(hist_list[:len(hist_list) // 2]))
        second_half = float(np.mean(hist_list[len(hist_list) // 2:]))
        if abs(first_half - second_half) > avg_diff * 2:
            return DriftType.ENVIRONMENT_CHANGE.value

        return DriftType.GRADUAL.value

    def suggest_adaptation(self, drop_type: str) -> Dict[str, Any]:
        """
        적응 제안 / Suggest adaptation.

        감지된 드리프트 유형과 현재 메트릭 상태를 기반으로
        동적으로 적응 전략을 생성합니다. 더 이상 하드코딩된 제안이 아닙니다.

        Args:
            drop_type: 드리프트 유형

        Returns:
            Dict: 적응 제안 (전략, 파라미터 등)
        """
        # ── 기본 전략 템플릿 / Base strategy templates ──
        strategy_templates: Dict[str, Dict[str, Any]] = {
            DriftType.GRADUAL.value: {
                "strategy": "incremental_retraining",
                "description": "점진적 재학습 / Incremental retraining",
                "korean_description": "최근 실제 데이터로 점진적 재학습",
                "parameters": {
                    "n_steps": 50,
                    "learning_rate": 5e-5,
                    "data_window": 200,
                },
                "priority": "medium",
            },
            DriftType.SUDDEN.value: {
                "strategy": "emergency_rollback",
                "description": "긴급 롤백 / Emergency rollback",
                "korean_description": "이전 안정 버전으로 롤백 후 재학습",
                "parameters": {
                    "rollback_to": "last_stable",
                    "n_steps": 100,
                    "learning_rate": 1e-4,
                },
                "priority": "critical",
            },
            DriftType.SENSOR_DEGRADATION.value: {
                "strategy": "sensor_recalibration",
                "description": "센서 재보정 / Sensor recalibration",
                "korean_description": "센서 바이어스 재추정 및 보정",
                "parameters": {
                    "calibration_samples": 50,
                    "noise_augmentation": 0.05,
                },
                "priority": "high",
            },
            DriftType.MECHANICAL_WEAR.value: {
                "strategy": "model_recalibration",
                "description": "모델 재보정 / Model recalibration",
                "korean_description": "마모된 하드웨어에 맞춰 모델 재보정",
                "parameters": {
                    "n_steps": 200,
                    "learning_rate": 1e-4,
                    "domain_adaptation": True,
                },
                "priority": "high",
            },
            DriftType.ENVIRONMENT_CHANGE.value: {
                "strategy": "domain_adaptation",
                "description": "도메인 적응 / Domain adaptation",
                "korean_description": "새 환경에 대한 도메인 적응 수행",
                "parameters": {
                    "n_steps": 100,
                    "progressive": True,
                    "curriculum_reset": True,
                },
                "priority": "medium",
            },
        }

        suggestion = dict(strategy_templates.get(
            drop_type, strategy_templates[DriftType.GRADUAL.value]
        ))

        # ── 동적 파라미터 조정 / Dynamic parameter adjustment ──
        # 드리프트 심각도에 따라 파라미터를 동적으로 조정합니다.
        with self._lock:
            # 최근 드리프트 이벤트에서 심각도 추출 / Extract severity from recent drifts
            recent_drifts = [d for d in self._detected_drifts if d.get("drift_type") == drop_type]
            if recent_drifts:
                latest = recent_drifts[-1]
                severity = latest.get("relative_drop", 0.0)
                current_avg = latest.get("current_avg", 0.0)
                baseline_val = latest.get("baseline", 0.0)

                # 심각도에 따른 학습률 스케일링 / Scale learning rate by severity
                if "parameters" in suggestion:
                    params = suggestion["parameters"]
                    base_lr = params.get("learning_rate", 5e-5)
                    base_steps = params.get("n_steps", 50)

                    # 심각도가 높을수록 더 공격적으로 학습 / Higher severity → more aggressive
                    severity_factor = float(np.clip(severity / 0.15, 0.5, 3.0))
                    params["learning_rate"] = base_lr * severity_factor
                    params["n_steps"] = int(base_steps * severity_factor)

                    # 현재 성능이 극히 낮으면 우선순위 상향 / Raise priority if very low
                    if current_avg < baseline_val * 0.5:
                        suggestion["priority"] = "critical"
                    elif current_avg < baseline_val * 0.7:
                        suggestion["priority"] = "high"

                    # 데이터 윈도우 조정 / Adjust data window based on history length
                    for key in self._metric_history:
                        history = self._metric_history[key]
                        if len(history) >= 10:
                            params["data_window"] = min(len(history), 500)
                            break

                    # 점진적 드리프트의 경우 점진적 복구 / Gradual drift → gradual recovery
                    if drop_type == DriftType.GRADUAL.value:
                        params["learning_rate"] = min(params["learning_rate"], 1e-4)
                        params["n_steps"] = min(params["n_steps"], 100)

                    # 급격한 드리프트의 경우 빠른 복구 / Sudden drift → rapid recovery
                    if drop_type == DriftType.SUDDEN.value:
                        params["n_steps"] = max(params["n_steps"], 150)

                    suggestion["severity"] = float(severity)
                    suggestion["severity_factor"] = float(severity_factor)

                # 여러 메트릭이 동시에 저하되면 복합 전략 제안 / Compound strategy if multiple metrics drop
                dropping_metrics = sum(
                    1 for key, hist in self._metric_history.items()
                    if len(hist) >= 5 and float(np.mean(list(hist)[-5:])) < self._baseline.get(key, 1.0) * 0.8
                )
                if dropping_metrics >= 2:
                    suggestion["compound_adaptation"] = True
                    suggestion["strategy"] += "+compound_reevaluation"
                    suggestion["parameters"]["full_recalibration"] = True

        logger.info(
            "적응 제안: %s (%s, 심각도=%.2f)",
            suggestion["strategy"], suggestion.get("korean_description", ""),
            suggestion.get("severity", 0.0),
        )

        return suggestion

    def get_drift_history(self) -> List[Dict[str, Any]]:
        """드리프트 이력 반환 / Return drift history."""
        with self._lock:
            return list(self._detected_drifts)

    def update_baseline(self, new_baseline: Dict[str, float]) -> None:
        """
        베이스라인 업데이트 / Update baseline.

        적응이 완료된 후 새로운 베이스라인을 설정합니다.

        Args:
            new_baseline: 새 베이스라인 메트릭
        """
        self._baseline.update(new_baseline)
        logger.info("베이스라인 업데이트: %s", new_baseline)


# ============================================================================
# Sim-to-Real Transfer Pipeline — Physical AGI 훈련데이터 부족 해결 핵심
# ============================================================================
# 문제: 물리적 AGI는 실제 경험이 부족함 (1시간 ≈ 1000 경험)
# 해결: 시뮬레이션에서 수백만 경험을 생성하고 현실로 전이
# 혁신:
# 1. 도메인 랜덤화 (Domain Randomization) — 시뮬 갭 해소
# 2. Progressive Net — 시뮬→리얼 전이 시 치명적 망각 방지
# 3. 적대적 적응 (Adversarial Adaptation) — 시뮬/리얼 분포 정렬
# 4. 물리적 일관성 검증 — 시뮬 경험의 현실성 보장
# ============================================================================


class DomainRandomizer:
    """도메인 랜덤화 — 시뮬레이션과 현실의 갭을 해소
    
    시뮬레이션 파라미터를 넓게 무작위화하여,
    현실의 다양한 조건에서도 작동하는 강건한 정책 학습.
    """
    
    def __init__(self, randomization_ranges=None):
        self.ranges = randomization_ranges or {
            # 물리 파라미터
            'friction_coefficient': (0.1, 1.5),
            'mass_multiplier': (0.5, 2.0),
            'gravity': (8.0, 11.0),
            'damping': (0.01, 0.3),
            
            # 센서 노이즈
            'imu_noise_std': (0.001, 0.05),
            'force_sensor_noise_std': (0.01, 0.5),
            'tactile_noise_std': (0.005, 0.1),
            'camera_noise_std': (0.0, 0.02),
            
            # 지연
            'action_delay_ms': (0, 50),
            'observation_delay_ms': (0, 30),
            
            # 액추에이터
            'torque_noise_std': (0.0, 0.1),
            'position_error_std': (0.0, 0.05),
        }
        
        self.current_params = {}
        self.randomization_history = []
    
    def randomize(self):
        """새로운 도메인 파라미터 샘플링"""
        self.current_params = {}
        for param, (low, high) in self.ranges.items():
            self.current_params[param] = np.random.uniform(low, high)
        
        self.randomization_history.append(dict(self.current_params))
        return dict(self.current_params)
    
    def apply_to_observation(self, observation):
        """관측에 노이즈 적용"""
        noisy = observation.copy()
        
        if isinstance(noisy, np.ndarray) and noisy.ndim >= 1:
            # IMU 노이즈
            if len(noisy) >= 6:
                imu_noise_std = self.current_params.get('imu_noise_std', 0.01)
                noisy[:6] += np.random.randn(6) * imu_noise_std
            
            # 힘 센서 노이즈
            if len(noisy) >= 30:
                force_noise_std = self.current_params.get('force_sensor_noise_std', 0.1)
                noisy[18:30] += np.random.randn(12) * force_noise_std
            
            # 촉각 노이즈
            if len(noisy) >= 42:
                tactile_noise_std = self.current_params.get('tactile_noise_std', 0.05)
                noisy[30:42] += np.random.randn(12) * tactile_noise_std
        
        return noisy
    
    def apply_to_action(self, action):
        """행동에 지연 및 노이즈 적용"""
        noisy = action.copy()
        
        torque_noise = self.current_params.get('torque_noise_std', 0.05)
        if isinstance(noisy, np.ndarray):
            noisy += np.random.randn(*noisy.shape) * torque_noise
        
        return noisy


if TORCH_AVAILABLE:

    class ProgressiveNetTransfer(nn.Module):
        """Progressive Neural Network — 시뮬→리얼 전이 시 치명적 망각 방지
        
        시뮬에서 학습한 네트워크를 동결하고,
        리얼 경험으로 새 열(column)을 추가하여 학습.
        기존 지식은 보존하면서 새 환경에 적응.
        """
        
        def __init__(self, sim_model, real_input_dim=62, hidden_dim=256):
            super().__init__()
            self.sim_model = sim_model
            self.sim_model.eval()  # 동결
            
            # 리얼 열(column)
            self.real_column = nn.Sequential(
                nn.Linear(real_input_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, hidden_dim // 2),
            )
            
            # 시뮬 열 → 리언 열 연결 (lateral connections)
            self.lateral_connections = nn.ModuleList()
            
            self.adaptation_count = 0
        
        def add_lateral_connection(self, sim_layer_dim):
            """시뮬 열의 특정 레이어에서 리얼 열로 연결 추가"""
            self.lateral_connections.append(
                nn.Linear(sim_layer_dim, self.real_column[-1].out_features)
            )
        
        def forward(self, real_input):
            """리얼 입력 → 시뮬 지식 + 리언 적응 결합"""
            # 시뮬 모델에서 특징 추출 (동결)
            with torch.no_grad():
                sim_features = self._extract_sim_features(real_input)
            
            # 리얼 열 순전파
            real_features = self.real_column(real_input)
            
            # 측면 연결 적용
            combined = real_features
            for i, lateral in enumerate(self.lateral_connections):
                if i < len(sim_features):
                    combined = combined + lateral(sim_features[i].detach())
            
            return combined
        
        def _extract_sim_features(self, x):
            """시뮬 모델에서 중간 특징 추출"""
            features = []
            current = x
            for layer in self.sim_model:
                current = layer(current)
                if isinstance(layer, (nn.GELU, nn.ReLU)):
                    features.append(current)
            return features


    class AdversarialSimRealAdapter(nn.Module):
        """적대적 시뮬-리얼 적응 (GAN 스타일)
        
        도메인 판별자(domain discriminator)가 시뮬/리얼을 구별하지 못하게
        특징 추출기를 학습 → 시뮬과 리얼의 특징 분포가 정렬됨.
        """
        
        def __init__(self, feature_dim=256, hidden_dim=128, lambda_adv=0.1):
            super().__init__()
            self.lambda_adv = lambda_adv
            
            # 도메인 판별자
            self.domain_discriminator = nn.Sequential(
                nn.Linear(feature_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, hidden_dim // 2),
                nn.GELU(),
                nn.Linear(hidden_dim // 2, 1),
                nn.Sigmoid(),
            )
            
            # 그래디언트 반전 층 (Gradient Reversal Layer)
            self.grl = GradientReversalLayer()
        
        def forward(self, features, domain_label):
            """적대적 적응 손실
            
            Args:
                features: 특징 [batch, feature_dim]
                domain_label: 0=sim, 1=real
            """
            # 그래디언트 반전
            reversed_features = self.grl(features)
            
            # 도메인 예측
            domain_pred = self.domain_discriminator(reversed_features)
            
            # 도메인 분류 손실
            domain_labels = torch.FloatTensor([domain_label] * features.shape[0]).to(features.device)
            domain_loss = F.binary_cross_entropy(domain_pred.squeeze(), domain_labels)
            
            return self.lambda_adv * domain_loss


    class GradientReversalLayer(torch.autograd.Function):
        """그래디언트 반전 층: 순전파는 항등, 역전파는 부호 반전"""
        
        @staticmethod
        def forward(ctx, x):
            return x.clone()
        
        @staticmethod
        def backward(ctx, grad_output):
            return -grad_output

else:
    # PyTorch 미설치 시 스텁 클래스 / Stub classes when PyTorch is unavailable
    class ProgressiveNetTransfer:
        """스텁: PyTorch 미설치 / Stub for when PyTorch is not installed."""
        pass

    class AdversarialSimRealAdapter:
        """스텁: PyTorch 미설치 / Stub for when PyTorch is not installed."""
        pass

    class GradientReversalLayer:
        """스텁: PyTorch 미설치 / Stub for when PyTorch is not installed."""
        pass


class PhysicsConsistencyValidator:
    """물리적 일관성 검증기
    
    시뮬레이션에서 생성된 경험이 물리 법칙을 위반하지 않는지 검증.
    위반된 경험은 학습에서 제외하여 시뮬→리얼 전이 품질 보장.
    """
    
    def __init__(self, max_acceleration=50.0, max_angular_velocity=10.0,
                 max_force=100.0, energy_conservation_tol=0.3):
        self.max_acceleration = max_acceleration
        self.max_angular_velocity = max_angular_velocity
        self.max_force = max_force
        self.energy_tol = energy_conservation_tol
    
    def validate_experience(self, state_prev, action, state_next):
        """경험의 물리적 일관성 검증
        
        Returns:
            dict: is_valid, violation_type, violation_severity
        """
        violations = []
        
        if isinstance(state_prev, torch.Tensor):
            state_prev = state_prev.detach().cpu().numpy()
        if isinstance(state_next, torch.Tensor):
            state_next = state_next.detach().cpu().numpy()
        if isinstance(action, torch.Tensor):
            action = action.detach().cpu().numpy()
        
        state_prev = np.atleast_1d(state_prev)
        state_next = np.atleast_1d(state_next)
        action = np.atleast_1d(action)
        
        # 1. 가속도 검사
        if len(state_prev) >= 3 and len(state_next) >= 3:
            delta_v = state_next[:3] - state_prev[:3]
            if np.max(np.abs(delta_v)) > self.max_acceleration:
                violations.append({
                    'type': 'excessive_acceleration',
                    'value': np.max(np.abs(delta_v)),
                    'limit': self.max_acceleration,
                })
        
        # 2. 각속도 검사
        if len(state_prev) >= 6 and len(state_next) >= 6:
            delta_omega = state_next[3:6] - state_prev[3:6]
            if np.max(np.abs(delta_omega)) > self.max_angular_velocity:
                violations.append({
                    'type': 'excessive_angular_velocity',
                    'value': np.max(np.abs(delta_omega)),
                    'limit': self.max_angular_velocity,
                })
        
        # 3. 힘 검사
        if len(action) >= 6:
            if np.max(np.abs(action[:6])) > self.max_force:
                violations.append({
                    'type': 'excessive_force',
                    'value': np.max(np.abs(action[:6])),
                    'limit': self.max_force,
                })
        
        # 4. 에너지 보존 검사 (근사)
        if len(state_prev) >= 3 and len(state_next) >= 3:
            ke_prev = np.sum(state_prev[:3] ** 2)
            ke_next = np.sum(state_next[:3] ** 2)
            work_done = np.sum(action[:3] * (state_next[:3] - state_prev[:3])) if len(action) >= 3 else 0
            
            energy_change = ke_next - ke_prev - work_done
            if abs(energy_change) > self.energy_tol * max(abs(ke_prev), 1.0):
                violations.append({
                    'type': 'energy_non_conservation',
                    'value': abs(energy_change),
                    'limit': self.energy_tol * max(abs(ke_prev), 1.0),
                })
        
        is_valid = len(violations) == 0
        severity = max(v.get('value', 0) / max(v.get('limit', 1), 1e-8) for v in violations) if violations else 0
        
        return {
            'is_valid': is_valid,
            'violations': violations,
            'severity': severity,
        }


# ─── 모듈 진입점 / Module Entry Point ───────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("=" * 60)
    print("Sim-to-Real 브릿지 테스트 / Sim-to-Real Bridge Test")
    print("=" * 60)

    # 도메인 갭 추정기 테스트 / Domain gap estimator test
    estimator = DomainGapEstimator()

    # 가상 데이터 생성 / Generate dummy data
    rng = np.random.RandomState(42)
    sim_data = rng.randn(50, STATE_DIM).astype(np.float32) * 0.5 + 0.5
    real_data = rng.randn(50, STATE_DIM).astype(np.float32) * 0.8 + 0.3

    mmd = estimator.compute_distribution_distance(sim_data, real_data)
    print(f"\nMMD (시뮬 vs 실제): {mmd:.4f}")

    # 실패 모드 식별 / Identify failure modes
    sim_results = [
        {"success": True, "category": "locomotion", "terrain": "flat"},
        {"success": True, "category": "grip", "terrain": "flat"},
        {"success": True, "category": "locomotion", "terrain": "slope"},
    ]
    real_results = [
        {"success": True, "category": "locomotion", "terrain": "flat"},
        {"success": False, "category": "grip", "terrain": "flat"},
        {"success": False, "category": "locomotion", "terrain": "slope"},
    ]

    failures = estimator.identify_failure_modes(sim_results, real_results)
    print(f"실패 모드: {failures}")

    # 실제 환경 모니터 테스트 / Reality monitor test
    print("\n실제 환경 모니터 테스트 / Reality Monitor Test")
    monitor = RealityMonitor(
        baseline={"success_rate": 0.85, "avg_reward": 0.6},
        window_size=20,
    )

    for i in range(30):
        # 점진적 저하 시뮬레이션 / Simulate gradual degradation
        success_rate = 0.85 - i * 0.01
        result = monitor.update({
            "success_rate": success_rate,
            "avg_reward": 0.6 - i * 0.005,
        })
        if result["drift_detected"]:
            print(f"  스텝 {i}: 드리프트 감지! → {result['current_metrics']}")

    # 적응 제안 / Suggest adaptation
    for drift in monitor.get_drift_history()[-2:]:
        suggestion = monitor.suggest_adaptation(drift["drift_type"])
        print(f"  제안: {suggestion['strategy']} ({suggestion['priority']})")

    print("\n모든 테스트 완료 / All tests completed.")
