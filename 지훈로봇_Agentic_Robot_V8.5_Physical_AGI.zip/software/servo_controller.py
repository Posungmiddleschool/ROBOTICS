#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — 서보 PWM 제어기 (Servo PWM Controller)
======================================================

Jetson#2 GPIO PWM → MG996R ×3 (50Hz, 500~2500μs)
핀 매핑: GPIO_18=핑거좌, GPIO_22=핑거우, GPIO_23=손목요

V8.5 변경사항 / V8.5 Changes from V8.5:
  - 서보 지터 감지 (Servo jitter detection)
  - PWM 신호 무결성 모니터링 (PWM signal integrity monitoring)
  - 서보 스톨 감지 개선 (Improved servo stall detection)
  - 서보 열 보호 (Thermal protection for servos)

아키텍처 / Architecture:
  - Jetson Orin NX GPIO PWM 출력 (50Hz 주기)
  - MG996R 서보 ×3: 핑거 좌/우 + 손목 요 회전
  - 각도 정확도: <2° 오차
  - 부드러운 동작: 최소저크 보간 + 속도 제어

MG996R 사양 / MG996R Specifications:
  - 실제 치수: 40.5×20×38mm (V6에서 수정 완료)
  - 토크: 11 kg·cm (6V)
  - 속도: 0.17초/60° (6V)
  - PWM: 50Hz, 500~2500μs 펄스폭
  - 동작 각도: 0°~180°
  - 동작 온도: -10°C ~ 60°C

V8.5 Adaptive AGI 추가사항 / V8.5 Adaptive AGI Additions:
  - AdaptivePIDController: 부하·작업 맥락 기반 PID 게인 자동 조정
  - CompliantControl: 인간 안전 상호작용을 위한 순응 제어 모드
  - ImpedanceControl: 정밀 힘 제어 (공작·요리 등)

작성일: 2026-05-19
버전: V8.5.5-AGI
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V84.ServoController")

# ============================================================================
# 상수 정의 (Constants)
# ============================================================================

# MG996R 서보 파라미터 / MG996R servo parameters
SERVO_MODEL: str = "MG996R"
SERVO_DIMENSIONS_MM: Tuple[float, float, float] = (40.5, 20.0, 38.0)  # V6 수정값
SERVO_TORQUE_KGCM: float = 11.0       # 6V 기준 토크
SERVO_SPEED_S_PER_60DEG: float = 0.17 # 6V 기준 속도

# PWM 파라미터 / PWM parameters
PWM_FREQ_HZ: int = 50                 # 표준 서보 PWM 주파수
PWM_PERIOD_US: int = 20000            # 50Hz = 20ms 주기
PULSE_MIN_US: int = 500               # 최소 펄스폭 (0° 위치)
PULSE_MAX_US: int = 2500              # 최대 펄스폭 (180° 위치)
PULSE_NEUTRAL_US: int = 1500          # 중립 펄스폭 (90° 위치)

# 각도 범위 / Angle range
ANGLE_MIN_DEG: float = 0.0
ANGLE_MAX_DEG: float = 180.0
ANGLE_NEUTRAL_DEG: float = 90.0

# 정확도 / Accuracy
ANGLE_TOLERANCE_DEG: float = 2.0      # 허용 각도 오차

# 기본 핀 매핑 / Default pin mapping
DEFAULT_PIN_MAP: Dict[str, int] = {
    "finger_left": 18,    # GPIO_18
    "finger_right": 22,   # GPIO_22
    "wrist_yaw": 23,      # GPIO_23
}

# 동작 속도 / Motion speed
DEFAULT_SPEED_DEG_S: float = 90.0     # 기본 이동 속도
MIN_SPEED_DEG_S: float = 10.0         # 최소 속도
MAX_SPEED_DEG_S: float = 360.0        # 최대 속도
INTERPOLATION_DT: float = 0.02        # 보간 간격 (50Hz)

# ── V8.5 추가 상수 / V8.5 Added Constants ──

# 지터 감지 / Jitter detection
JITTER_WINDOW_SIZE: int = 20           # 지터 분석 윈도우 (샘플 수)
JITTER_THRESHOLD_DEG: float = 1.5      # 지터 임계값 (°)
JITTER_FREQUENCY_THRESHOLD_HZ: float = 5.0  # 지터 주파수 임계값

# PWM 신호 무결성 / PWM signal integrity
PWM_DUTY_MIN_PCT: float = 2.5         # 최소 듀티사이클 (%)
PWM_DUTY_MAX_PCT: float = 12.5        # 최대 듀티사이클 (%)
PWM_GLITCH_THRESHOLD_US: float = 50.0  # PWM 글리치 임계값 (μs)
PWM_SIGNAL_LOSS_TIMEOUT_S: float = 0.5 # PWM 신호 손실 타임아웃

# 스톨 감지 개선 / Improved stall detection
STALL_CURRENT_THRESHOLD_MA: float = 800.0  # 스톨 전류 임계값 (mA)
STALL_POSITION_HOLD_S: float = 0.3         # 스톨 판정 유지 시간 (초)
STALL_RETRY_COUNT: int = 3                  # 스톨 시 재시도 횟수
STALL_COOLDOWN_S: float = 1.0              # 스톨 후 쿨다운 (초)

# 열 보호 / Thermal protection
SERVO_TEMP_WARNING_C: float = 55.0     # 온도 경고 (°C)
SERVO_TEMP_CRITICAL_C: float = 65.0    # 온도 위험 (°C)
SERVO_TEMP_DERATE_START_C: float = 50.0  # 출력 제한 시작 온도
SERVO_TEMP_SHUTDOWN_C: float = 70.0    # 강제 셧다운 온도
THERMAL_MONITOR_INTERVAL_S: float = 1.0 # 온도 모니터링 주기

# ── V8.5 Adaptive AGI 상수 / V8.5 Adaptive AGI Constants ──

# 적응형 PID / Adaptive PID
ADAPTIVE_PID_LEARNING_RATE: float = 0.01    # 게인 조정 학습률
ADAPTIVE_PID_GAIN_MIN: float = 0.1          # 최소 PID 게인
ADAPTIVE_PID_GAIN_MAX: float = 10.0         # 최대 PID 게인
ADAPTIVE_PID_LOAD_WINDOW: int = 50          # 부하 추정 윈도우 (샘플 수)
ADAPTIVE_PID_ADJUST_INTERVAL_S: float = 0.1 # 게인 조정 주기 (초)

# 순응 제어 / Compliant control
COMPLIANT_MAX_FORCE_N: float = 5.0          # 인간 상호작용 최대 허용 힘 (N)
COMPLIANT_SPRING_K: float = 0.5             # 순응 스프링 계수 (N/°)
COMPLIANT_DAMPING_B: float = 0.2            # 순응 댐핑 계수 (N·s/°)
COMPLIANT_BACKDRIVE_THRESHOLD_N: float = 1.0 # 백드라이브 인식 임계값 (N)

# 임피던스 제어 / Impedance control
IMPEDANCE_STIFFNESS_DEFAULT: float = 2.0    # 기본 강성 (N/°)
IMPEDANCE_DAMPING_DEFAULT: float = 0.5      # 기본 댐핑 (N·s/°)
IMPEDANCE_INERTIA_DEFAULT: float = 0.1      # 기본 관성 (N·s²/°)
IMPEDANCE_FORCE_LIMIT_N: float = 8.0        # 최대 허용 힘 (N)
IMPEDANCE_POSITION_GAIN: float = 3.0        # 위치 게인
IMPEDANCE_FORCE_RESOLUTION_N: float = 0.1   # 힘 분해능 (N)


# ============================================================================
# 열거형 (Enumerations)
# ============================================================================

class ServoState(Enum):
    """서보 상태 / Servo state"""
    DISABLED = "disabled"       # 비활성화 (PWM 출력 없음)
    IDLE = "idle"               # 대기 (현재 각도 유지)
    MOVING = "moving"           # 이동 중 (보간 동작)
    HOLDING = "holding"         # 위치 유지 (토크 인가)
    FAULT = "fault"             # 오류
    THERMAL_DERATE = "thermal_derate"  # V8.5: 열 제한 모드
    THERMAL_SHUTDOWN = "thermal_shutdown"  # V8.5: 열 셧다운
    STALL_DETECTED = "stall_detected"  # V8.5: 스톨 감지


class JitterSeverity(Enum):
    """V8.5: 지터 심각도 / Jitter severity"""
    NONE = "none"
    MINOR = "minor"       # < 2° 지터
    MODERATE = "moderate" # 2~5° 지터
    SEVERE = "severe"     # > 5° 지터


class ServoControlMode(Enum):
    """V8.5 AGI: 서보 제어 모드 / Servo control mode"""
    POSITION = "position"         # 위치 제어 (기본)
    VELOCITY = "velocity"         # 속도 제어
    COMPLIANT = "compliant"       # 순응 제어 (인간 상호작용)
    IMPEDANCE = "impedance"       # 임피던스 제어 (정밀 힘 제어)
    ADAPTIVE_PID = "adaptive_pid" # 적응형 PID 제어


class TaskContext(Enum):
    """V8.5 AGI: 작업 맥락 / Task context — AI 추론 결과에 따라 자동 선택"""
    IDLE = "idle"                     # 대기
    PRECISE_POSITIONING = "precise"   # 정밀 위치 결정 (조립, 교정)
    FAST_MOVEMENT = "fast"            # 빠른 이동 (이동, 회피)
    HUMAN_INTERACTION = "human"       # 인간 상호작용 (악수, 전달)
    FORCE_CONTROLLED = "force"        # 힘 제어 (요리, 공작, 조립)
    HEAVY_LOAD = "heavy"              # 고부하 (무거운 물체 들기)
    DELICATE = "delicate"             # 섬세 (깨지기 쉬운 물체)


# ============================================================================
# 데이터 클래스 (Data Classes)
# ============================================================================

@dataclass
class ServoChannel:
    """서보 채널 상태 / Servo channel state"""
    name: str = ""
    gpio_pin: int = 0
    current_angle_deg: float = ANGLE_NEUTRAL_DEG
    target_angle_deg: float = ANGLE_NEUTRAL_DEG
    pulse_width_us: float = PULSE_NEUTRAL_US
    speed_deg_s: float = DEFAULT_SPEED_DEG_S
    state: ServoState = ServoState.DISABLED
    min_angle_deg: float = ANGLE_MIN_DEG
    max_angle_deg: float = ANGLE_MAX_DEG
    offset_deg: float = 0.0      # 영점 보정값 / Zero-point offset
    last_update: float = field(default_factory=time.monotonic)
    # V8.5 추가 필드
    estimated_temp_c: float = 25.0   # 추정 온도
    thermal_derate_factor: float = 1.0  # 열 제한 계수 (0~1)
    stall_counter: int = 0           # 스톨 재시도 카운터
    last_stall_time: float = 0.0     # 마지막 스톨 감지 시간
    total_move_time_s: float = 0.0   # 누적 이동 시간 (온도 추정용)


@dataclass
class ServoDiagnostics:
    """서보 진단 정보 / Servo diagnostics"""
    channel: str = ""
    gpio_pin: int = 0
    current_angle_deg: float = 0.0
    target_angle_deg: float = 0.0
    angle_error_deg: float = 0.0
    pulse_width_us: float = 0.0
    state: ServoState = ServoState.DISABLED
    is_within_tolerance: bool = True
    # V8.5 추가 진단 필드
    jitter_severity: JitterSeverity = JitterSeverity.NONE
    jitter_amplitude_deg: float = 0.0
    pwm_integrity_ok: bool = True
    estimated_temp_c: float = 25.0
    thermal_derate_factor: float = 1.0
    stall_detected: bool = False
    stall_retry_remaining: int = STALL_RETRY_COUNT


@dataclass
class AdaptivePIDGains:
    """V8.5 AGI: 적응형 PID 게인 상태 / Adaptive PID gain state"""
    kp: float = 2.0               # 비례 게인
    ki: float = 0.5               # 적분 게인
    kd: float = 0.1               # 미분 게인
    estimated_load: float = 0.0   # 추정 부하 (0~1)
    task_context: TaskContext = TaskContext.IDLE
    last_adjust_time: float = 0.0
    gain_adjustment_count: int = 0


@dataclass
class CompliantState:
    """V8.5 AGI: 순응 제어 상태 / Compliant control state"""
    is_active: bool = False
    external_force_n: float = 0.0     # 외부 힘 (N)
    spring_displacement_deg: float = 0.0  # 스프링 변위 (°)
    virtual_position_deg: float = 90.0    # 가상 목표 위치 (°)
    max_force_n: float = COMPLIANT_MAX_FORCE_N
    spring_k: float = COMPLIANT_SPRING_K
    damping_b: float = COMPLIANT_DAMPING_B


@dataclass
class ImpedanceState:
    """V8.5 AGI: 임피던스 제어 상태 / Impedance control state"""
    is_active: bool = False
    stiffness: float = IMPEDANCE_STIFFNESS_DEFAULT   # 강성 (N/°)
    damping: float = IMPEDANCE_DAMPING_DEFAULT        # 댐핑 (N·s/°)
    inertia: float = IMPEDANCE_INERTIA_DEFAULT        # 관성 (N·s²/°)
    desired_force_n: float = 0.0       # 목표 힘 (N)
    measured_force_n: float = 0.0      # 측정 힘 (N)
    force_error_n: float = 0.0         # 힘 오차 (N)
    equilibrium_position_deg: float = 90.0  # 평형 위치 (°)
    force_integral: float = 0.0        # 힘 적분항
    force_derivative: float = 0.0      # 힘 미분항


# ============================================================================
# V8.5 서보 지터 감지기 (Servo Jitter Detector)
# ============================================================================

class ServoJitterDetector:
    """
    V8.5: 서보 지터 감지기 / Servo Jitter Detector.

    일정 시간 윈도우 내 각도 변화 패턴을 분석하여
    지터(빠른 미세 진동)를 감지하고 심각도를 분류.

    감지 원리:
    1. 최근 N개 샘플의 각도 변화(Δ)를 분석
    2. 방향 변화 횟수가 임계값 초과 → 지터 판정
    3. 진폭(최대-최소)으로 심각도 분류
    """

    def __init__(
        self,
        window_size: int = JITTER_WINDOW_SIZE,
        amplitude_threshold_deg: float = JITTER_THRESHOLD_DEG,
    ) -> None:
        self._window_size = window_size
        self._amplitude_threshold = amplitude_threshold_deg
        self._angle_history: Dict[str, deque] = {}
        self._jitter_severity: Dict[str, JitterSeverity] = {}
        self._jitter_amplitude: Dict[str, float] = {}

    def update(self, channel_name: str, angle_deg: float) -> JitterSeverity:
        """
        각도 샘플 업데이트 및 지터 분석 / Update angle sample and analyze jitter.

        Args:
            channel_name: 채널 이름
            angle_deg: 현재 각도

        Returns:
            지터 심각도
        """
        if channel_name not in self._angle_history:
            self._angle_history[channel_name] = deque(maxlen=self._window_size)
            self._jitter_severity[channel_name] = JitterSeverity.NONE
            self._jitter_amplitude[channel_name] = 0.0

        self._angle_history[channel_name].append(angle_deg)

        history = self._angle_history[channel_name]
        if len(history) < 5:
            return JitterSeverity.NONE

        # 진폭 계산 / Calculate amplitude
        angles = list(history)
        amplitude = max(angles) - min(angles)
        self._jitter_amplitude[channel_name] = amplitude

        # 방향 변화 횟수 카운트 / Count direction changes
        direction_changes = 0
        for i in range(2, len(angles)):
            delta_prev = angles[i - 1] - angles[i - 2]
            delta_curr = angles[i] - angles[i - 1]
            if delta_prev * delta_curr < 0:  # 방향 반전
                direction_changes += 1

        # 지터 판정 / Determine jitter
        # 방향 변화 비율이 높고 진폭이 임계값 이상이면 지터
        direction_change_rate = direction_changes / max(len(angles) - 2, 1)

        if amplitude > 5.0 and direction_change_rate > 0.4:
            severity = JitterSeverity.SEVERE
        elif amplitude > 2.0 and direction_change_rate > 0.3:
            severity = JitterSeverity.MODERATE
        elif amplitude > self._amplitude_threshold and direction_change_rate > 0.2:
            severity = JitterSeverity.MINOR
        else:
            severity = JitterSeverity.NONE

        self._jitter_severity[channel_name] = severity

        if severity != JitterSeverity.NONE:
            logger.warning(
                "서보 지터 감지 — %s: 심각도=%s, 진폭=%.2f°, 방향변화율=%.1f%%",
                channel_name, severity.value, amplitude,
                direction_change_rate * 100,
            )

        return severity

    def get_jitter_info(self, channel_name: str) -> Tuple[JitterSeverity, float]:
        """지터 정보 조회 / Get jitter info."""
        return (
            self._jitter_severity.get(channel_name, JitterSeverity.NONE),
            self._jitter_amplitude.get(channel_name, 0.0),
        )


# ============================================================================
# V8.5 PWM 신호 무결성 모니터 (PWM Signal Integrity Monitor)
# ============================================================================

class PWMSignalMonitor:
    """
    V8.5: PWM 신호 무결성 모니터 / PWM Signal Integrity Monitor.

    PWM 듀티사이클 범위 검증, 글리치 감지,
    신호 손실 탐지 기능 제공.

    검증 항목:
    1. 듀티사이클이 유효 범위 내인지 확인 (2.5~12.5%)
    2. 펄스폭 급변(글리치) 감지
    3. 신호 업데이트 주기 확인 (타임아웃 감지)
    """

    def __init__(
        self,
        glitch_threshold_us: float = PWM_GLITCH_THRESHOLD_US,
        loss_timeout_s: float = PWM_SIGNAL_LOSS_TIMEOUT_S,
    ) -> None:
        self._glitch_threshold = glitch_threshold_us
        self._loss_timeout = loss_timeout_s
        self._last_pulse_width: Dict[str, float] = {}
        self._last_update_time: Dict[str, float] = {}
        self._glitch_count: Dict[str, int] = {}
        self._integrity_ok: Dict[str, bool] = {}

    def check_pulse(
        self, channel_name: str, pulse_width_us: float, duty_cycle_pct: float,
    ) -> bool:
        """
        PWM 신호 무결성 검사 / Check PWM signal integrity.

        Args:
            channel_name: 채널 이름
            pulse_width_us: 펄스폭 (μs)
            duty_cycle_pct: 듀티사이클 (%)

        Returns:
            무결성 통과 여부
        """
        now = time.monotonic()
        integrity_ok = True

        # 1. 듀티사이클 범위 확인 / Verify duty cycle range
        if not (PWM_DUTY_MIN_PCT - 0.5 <= duty_cycle_pct <= PWM_DUTY_MAX_PCT + 0.5):
            logger.warning(
                "PWM 듀티사이클 범위 이탈 — %s: %.2f%% (유효: %.1f~%.1f%%)",
                channel_name, duty_cycle_pct, PWM_DUTY_MIN_PCT, PWM_DUTY_MAX_PCT,
            )
            integrity_ok = False

        # 2. 펄스폭 글리치 감지 / Detect pulse width glitch
        prev_pw = self._last_pulse_width.get(channel_name)
        if prev_pw is not None:
            delta = abs(pulse_width_us - prev_pw)
            if delta > self._glitch_threshold and prev_pw > 0:
                self._glitch_count[channel_name] = self._glitch_count.get(channel_name, 0) + 1
                logger.debug(
                    "PWM 글리치 감지 — %s: Δ=%.1fμs (임계값: %.1fμs)",
                    channel_name, delta, self._glitch_threshold,
                )
                # 단일 글리치는 무결성 실패로 간주하지 않음
                # 누적 글리치가 많으면 실패
                if self._glitch_count[channel_name] > 10:
                    integrity_ok = False

        # 3. 신호 손실 확인 / Check for signal loss
        prev_time = self._last_update_time.get(channel_name)
        if prev_time is not None:
            elapsed = now - prev_time
            if elapsed > self._loss_timeout:
                logger.error(
                    "PWM 신호 손실 — %s: %.1f초 간 업데이트 없음",
                    channel_name, elapsed,
                )
                integrity_ok = False

        self._last_pulse_width[channel_name] = pulse_width_us
        self._last_update_time[channel_name] = now
        self._integrity_ok[channel_name] = integrity_ok

        return integrity_ok

    def is_signal_ok(self, channel_name: str) -> bool:
        """PWM 신호 상태 조회 / Get PWM signal status."""
        return self._integrity_ok.get(channel_name, True)

    def get_glitch_count(self, channel_name: str) -> int:
        """글리치 횟수 조회 / Get glitch count."""
        return self._glitch_count.get(channel_name, 0)

    def reset(self, channel_name: Optional[str] = None) -> None:
        """모니터 리셋 / Reset monitor."""
        if channel_name:
            self._last_pulse_width.pop(channel_name, None)
            self._last_update_time.pop(channel_name, None)
            self._glitch_count[channel_name] = 0
            self._integrity_ok[channel_name] = True
        else:
            self._last_pulse_width.clear()
            self._last_update_time.clear()
            self._glitch_count.clear()
            self._integrity_ok.clear()


# ============================================================================
# V8.5 서보 열 보호 관리자 (Servo Thermal Protection Manager)
# ============================================================================

class ServoThermalManager:
    """
    V8.5: 서보 열 보호 관리자 / Servo Thermal Protection Manager.

    서보 모터의 온도를 추정(간접 측정)하고
    과열 시 출력을 제한하거나 셧다운.

    온도 추정 방법:
    - 이동 시간과 부하에 비례하여 열 발생 추정
    - 냉각은 자연 냉각 모델 적용
    - 실제 서보에 온도 센서가 없으므로 간접 추정

    열 보호 동작:
    - 50°C 이상: 출력 제한 시작 (derating)
    - 55°C 이상: 경고 로그
    - 65°C 이상: 위험, 속도 제한 강화
    - 70°C 이상: 강제 셧다운
    """

    def __init__(self) -> None:
        self._temps: Dict[str, float] = {}           # 추정 온도
        self._derate_factors: Dict[str, float] = {}   # 제한 계수
        self._shutdown: Dict[str, bool] = {}          # 셧다운 여부
        self._ambient_temp: float = 25.0              # 실온 (°C)
        self._thermal_resistance: float = 10.0        # 열저항 (°C/W) 추정
        self._cooling_coefficient: float = 0.02       # 냉각 계수 (1/s)
        self._heating_rate: float = 3.0               # 이동 시 발열률 (°C/s)
        self._last_update: Dict[str, float] = {}

    def update_thermal(
        self, channel_name: str, is_moving: bool, load_factor: float = 0.5,
    ) -> Tuple[float, float, bool]:
        """
        열 상태 업데이트 / Update thermal state.

        Args:
            channel_name: 채널 이름
            is_moving: 현재 이동 중인지
            load_factor: 부하 계수 (0~1)

        Returns:
            (추정온도, 제한계수, 셧다운여부) 튜플
        """
        now = time.monotonic()

        if channel_name not in self._temps:
            self._temps[channel_name] = self._ambient_temp
            self._derate_factors[channel_name] = 1.0
            self._shutdown[channel_name] = False
            self._last_update[channel_name] = now
            return self._ambient_temp, 1.0, False

        dt = now - self._last_update[channel_name]
        self._last_update[channel_name] = now

        current_temp = self._temps[channel_name]

        # 발열 / Heating
        if is_moving:
            heat_increase = self._heating_rate * load_factor * dt
            current_temp += heat_increase

        # 냉각 / Cooling (Newton's law of cooling)
        cooling = self._cooling_coefficient * (current_temp - self._ambient_temp) * dt
        current_temp -= cooling

        # 실온 이하로 내려가지 않음 / Don't go below ambient
        current_temp = max(self._ambient_temp, current_temp)

        self._temps[channel_name] = current_temp

        # 제한 계수 계산 / Calculate derating factor
        derate = 1.0
        if current_temp >= SERVO_TEMP_SHUTDOWN_C:
            derate = 0.0
            self._shutdown[channel_name] = True
            logger.critical(
                "서보 열 셧다운 — %s: %.1f°C (임계: %.1f°C)",
                channel_name, current_temp, SERVO_TEMP_SHUTDOWN_C,
            )
        elif current_temp >= SERVO_TEMP_CRITICAL_C:
            derate = 0.2
            logger.warning(
                "서보 과열 위험 — %s: %.1f°C (위험: %.1f°C)",
                channel_name, current_temp, SERVO_TEMP_CRITICAL_C,
            )
        elif current_temp >= SERVO_TEMP_WARNING_C:
            derate = 0.5
            logger.warning(
                "서보 과열 경고 — %s: %.1f°C (경고: %.1f°C)",
                channel_name, current_temp, SERVO_TEMP_WARNING_C,
            )
        elif current_temp >= SERVO_TEMP_DERATE_START_C:
            # 선형 제한 / Linear derating
            derate = 1.0 - 0.5 * (
                (current_temp - SERVO_TEMP_DERATE_START_C)
                / (SERVO_TEMP_WARNING_C - SERVO_TEMP_DERATE_START_C)
            )

        self._derate_factors[channel_name] = derate

        # 셧다운 상태에서 온도가 안전 범위로 내려가면 해제
        if self._shutdown[channel_name] and current_temp < SERVO_TEMP_DERATE_START_C:
            self._shutdown[channel_name] = False
            logger.info("서보 열 셧다운 해제 — %s: %.1f°C", channel_name, current_temp)

        return current_temp, derate, self._shutdown[channel_name]

    def get_temperature(self, channel_name: str) -> float:
        """추정 온도 조회 / Get estimated temperature."""
        return self._temps.get(channel_name, self._ambient_temp)

    def get_derate_factor(self, channel_name: str) -> float:
        """제한 계수 조회 / Get derating factor."""
        return self._derate_factors.get(channel_name, 1.0)

    def is_shutdown(self, channel_name: str) -> bool:
        """셧다운 상태 조회 / Get shutdown status."""
        return self._shutdown.get(channel_name, False)


# ============================================================================
# V8.5 AGI: 적응형 PID 제어기 (Adaptive PID Controller)
# ============================================================================

class AdaptivePIDController:
    """
    V8.5 AGI: 적응형 PID 제어기 / Adaptive PID Controller.

    부하와 작업 맥락에 따라 PID 게인을 자동 조정.
    AI 추론 결과(작업 맥락)를 반영하여 최적 게인 선택.

    적응 전략:
    1. 부하 추정: 위치 오차 시계열로 부하 추정
    2. 작업 맥락 매핑: 각 맥락에 맞는 기본 게인 프리셋
    3. MRAC (Model Reference Adaptive Control) 기반 미세 조정
    4. 오차 응답 기반 게인 보정: 오버슈트/언더슈트 감지 시 게인 조정

    사용 예:
    - 정밀 조립: Kp 낮춤, Kd 높임 → 오버슈트 방지
    - 고부하 이동: Kp 높임 → 정상상태 오차 감소
    - 섬세 조작: Kp 낮춤, Ki 낮춤 → 부드러운 접근
    """

    # 작업 맥락별 기본 PID 프리셋 / Task context PID presets
    CONTEXT_PRESETS: Dict[TaskContext, Dict[str, float]] = {
        TaskContext.IDLE: {"kp": 1.0, "ki": 0.1, "kd": 0.05},
        TaskContext.PRECISE_POSITIONING: {"kp": 1.5, "ki": 0.3, "kd": 0.4},
        TaskContext.FAST_MOVEMENT: {"kp": 4.0, "ki": 0.8, "kd": 0.1},
        TaskContext.HUMAN_INTERACTION: {"kp": 0.8, "ki": 0.05, "kd": 0.3},
        TaskContext.FORCE_CONTROLLED: {"kp": 1.2, "ki": 0.2, "kd": 0.5},
        TaskContext.HEAVY_LOAD: {"kp": 5.0, "ki": 1.0, "kd": 0.2},
        TaskContext.DELICATE: {"kp": 0.6, "ki": 0.02, "kd": 0.6},
    }

    def __init__(self) -> None:
        self._gains: Dict[str, AdaptivePIDGains] = {}
        self._error_history: Dict[str, deque] = {}
        self._load_history: Dict[str, deque] = {}

    def register_channel(self, channel_name: str) -> None:
        """채널 등록 / Register channel for adaptive control."""
        if channel_name not in self._gains:
            self._gains[channel_name] = AdaptivePIDGains()
            self._error_history[channel_name] = deque(maxlen=ADAPTIVE_PID_LOAD_WINDOW)
            self._load_history[channel_name] = deque(maxlen=ADAPTIVE_PID_LOAD_WINDOW)

    def set_task_context(self, channel_name: str, context: TaskContext) -> AdaptivePIDGains:
        """
        작업 맥락 설정 및 프리셋 적용 / Set task context and apply preset.

        AI 추론 결과에 따라 작업 맥락이 설정되면,
        해당 맥락에 최적화된 PID 게인 프리셋을 적용.

        Args:
            channel_name: 채널 이름
            context: 작업 맥락

        Returns:
            업데이트된 PID 게인
        """
        if channel_name not in self._gains:
            self.register_channel(channel_name)

        gains = self._gains[channel_name]
        gains.task_context = context

        # 프리셋 적용 / Apply preset
        preset = self.CONTEXT_PRESETS.get(context, self.CONTEXT_PRESETS[TaskContext.IDLE])
        gains.kp = preset["kp"]
        gains.ki = preset["ki"]
        gains.kd = preset["kd"]
        gains.gain_adjustment_count += 1

        logger.info(
            "적응형 PID 프리셋 적용 — %s: 맥락=%s, Kp=%.2f, Ki=%.2f, Kd=%.2f",
            channel_name, context.value, gains.kp, gains.ki, gains.kd,
        )
        return gains

    def update(
        self,
        channel_name: str,
        position_error_deg: float,
        velocity_deg_s: float,
        dt: float,
    ) -> AdaptivePIDGains:
        """
        적응형 PID 업데이트 / Update adaptive PID.

        위치 오차와 속도 피드백을 기반으로:
        1. 부하 추정
        2. 오버슈트/언더슈트 감지
        3. 게인 미세 조정

        Args:
            channel_name: 채널 이름
            position_error_deg: 위치 오차 (°)
            velocity_deg_s: 현재 속도 (°/s)
            dt: 시간 간격 (초)

        Returns:
            업데이트된 PID 게인
        """
        if channel_name not in self._gains:
            self.register_channel(channel_name)

        gains = self._gains[channel_name]
        now = time.monotonic()

        # 오차 이력 기록 / Record error history
        self._error_history[channel_name].append(position_error_deg)

        # 1. 부하 추정 / Estimate load
        gains.estimated_load = self._estimate_load(channel_name, position_error_deg, velocity_deg_s)

        # 2. 게인 조정 주기 확인 / Check adjustment interval
        if now - gains.last_adjust_time < ADAPTIVE_PID_ADJUST_INTERVAL_S:
            return gains
        gains.last_adjust_time = now

        # 3. 오버슈트 감지 및 게인 조정 / Detect overshoot and adjust gains
        error_history = list(self._error_history[channel_name])
        if len(error_history) >= 10:
            self._adjust_gains_from_response(gains, error_history)

        return gains

    def _estimate_load(self, channel_name: str, error: float, velocity: float) -> float:
        """
        부하 추정 / Estimate load from error and velocity.

        위치 오차가 크고 속도가 낮으면 고부하로 판단.
        부하 계수: 0 (무부하) ~ 1 (최대 부하)
        """
        # 정상상태 오차가 크면 부하가 높은 것
        load_from_error = min(1.0, abs(error) / 30.0)
        # 속도가 목표 대비 낮으면 부하가 높은 것
        load_from_velocity = min(1.0, max(0.0, 1.0 - abs(velocity) / 60.0))

        # 가중 평균 / Weighted average
        estimated_load = 0.6 * load_from_error + 0.4 * load_from_velocity

        self._load_history[channel_name].append(estimated_load)

        # 이동 평균으로 안정화 / Moving average for stability
        load_list = list(self._load_history[channel_name])
        if len(load_list) >= 5:
            estimated_load = sum(load_list[-5:]) / 5.0

        return max(0.0, min(1.0, estimated_load))

    def _adjust_gains_from_response(
        self, gains: AdaptivePIDGains, error_history: List[float],
    ) -> None:
        """
        오차 응답 기반 게인 조정 / Adjust gains based on error response.

        오버슈트 감지: Kp 감소, Kd 증가
        언더슈트(수렴 지연): Kp 증가, Ki 증가
        진동: Kd 증가, Ki 감소
        """
        recent = error_history[-10:]

        # 오버슈트 감지: 오차가 0을 교차하면 오버슈트
        zero_crossings = 0
        for i in range(1, len(recent)):
            if recent[i - 1] * recent[i] < 0:
                zero_crossings += 1

        # 오차 감소율 / Error reduction rate
        if abs(recent[0]) > 0.01:
            reduction_rate = abs(recent[-1]) / abs(recent[0])
        else:
            reduction_rate = 1.0

        lr = ADAPTIVE_PID_LEARNING_RATE

        if zero_crossings >= 3:
            # 진동 발생 → Kd 증가, Ki 감소
            gains.kd = min(ADAPTIVE_PID_GAIN_MAX, gains.kd * (1.0 + lr * 2.0))
            gains.ki = max(ADAPTIVE_PID_GAIN_MIN, gains.ki * (1.0 - lr))
            logger.debug(
                "적응형 PID: 진동 감지 → Kd↑ Ki↓ (채널 맥락=%s)", gains.task_context.value,
            )
        elif zero_crossings >= 1:
            # 오버슈트 → Kp 감소, Kd 증가
            gains.kp = max(ADAPTIVE_PID_GAIN_MIN, gains.kp * (1.0 - lr))
            gains.kd = min(ADAPTIVE_PID_GAIN_MAX, gains.kd * (1.0 + lr))
            logger.debug("적응형 PID: 오버슈트 → Kp↓ Kd↑")
        elif reduction_rate > 0.8:
            # 수렴 지연 → Kp 증가, Ki 증가
            gains.kp = min(ADAPTIVE_PID_GAIN_MAX, gains.kp * (1.0 + lr))
            gains.ki = min(ADAPTIVE_PID_GAIN_MAX, gains.ki * (1.0 + lr * 0.5))
            logger.debug("적응형 PID: 수렴 지연 → Kp↑ Ki↑")

        # 부하에 따른 추가 조정 / Additional adjustment based on load
        if gains.estimated_load > 0.7:
            # 고부하: Kp 증가로 정상상태 오차 감소
            gains.kp = min(ADAPTIVE_PID_GAIN_MAX, gains.kp * (1.0 + lr * 0.5))
        elif gains.estimated_load < 0.2:
            # 저부하: Kp 감소로 오버슈트 방지
            gains.kp = max(ADAPTIVE_PID_GAIN_MIN, gains.kp * (1.0 - lr * 0.3))

        gains.gain_adjustment_count += 1

    def get_gains(self, channel_name: str) -> AdaptivePIDGains:
        """현재 PID 게인 조회 / Get current PID gains."""
        return self._gains.get(channel_name, AdaptivePIDGains())


# ============================================================================
# V8.5 AGI: 순응 제어기 (Compliant Controller)
# ============================================================================

class CompliantController:
    """
    V8.5 AGI: 순응 제어기 / Compliant Controller.

    인간과의 안전한 상호작용을 위한 순응 제어 모드.
    외부 힘이 감지되면 서보가 밀려나가는 것을 허용하여
    인간에게 부상을 입히지 않음.

    제어 모델:
    - 스프링-댐퍼 가상 모델: F = K·Δx + B·Δv
    - 외부 힘이 임계값 초과 시 위치 목표를 포기하고 힘에 순응
    - 힘이 제거되면 원래 위치로 천천히 복귀

    사용 시나리오:
    - 악수 (handshake)
    - 물체 전달 (handover)
    - 인간 작업 공간 내 이동
    - 신체 접촉이 예상되는 상황
    """

    def __init__(self) -> None:
        self._states: Dict[str, CompliantState] = {}
        self._prev_velocity: Dict[str, float] = {}

    def register_channel(self, channel_name: str) -> None:
        """채널 등록 / Register channel for compliant control."""
        if channel_name not in self._states:
            self._states[channel_name] = CompliantState()
            self._prev_velocity[channel_name] = 0.0

    def activate(self, channel_name: str, current_position_deg: float) -> CompliantState:
        """
        순응 제어 활성화 / Activate compliant control.

        Args:
            channel_name: 채널 이름
            current_position_deg: 현재 각도 (가상 목표로 설정)

        Returns:
            순응 제어 상태
        """
        if channel_name not in self._states:
            self.register_channel(channel_name)

        state = self._states[channel_name]
        state.is_active = True
        state.virtual_position_deg = current_position_deg
        state.spring_displacement_deg = 0.0

        logger.info(
            "순응 제어 활성화 — %s: 가상목표=%.1f°", channel_name, current_position_deg,
        )
        return state

    def deactivate(self, channel_name: str) -> None:
        """순응 제어 비활성화 / Deactivate compliant control."""
        if channel_name in self._states:
            self._states[channel_name].is_active = False
            logger.info("순응 제어 비활성화 — %s", channel_name)

    def compute(
        self,
        channel_name: str,
        current_position_deg: float,
        external_force_n: float,
        dt: float,
    ) -> Optional[float]:
        """
        순응 제어 계산 / Compute compliant control output.

        스프링-댐퍼 모델:
          Δx = F_ext / K (스프링 변위)
          목표위치 = 가상목표 - Δx (외부 힘 방향으로 물러남)

        Args:
            channel_name: 채널 이름
            current_position_deg: 현재 각도
            external_force_n: 외부 힘 (N)
            dt: 시간 간격 (초)

        Returns:
            목표 각도 (°) 또는 None (비활성 상태)
        """
        if channel_name not in self._states:
            return None

        state = self._states[channel_name]
        if not state.is_active:
            return None

        state.external_force_n = external_force_n

        # 백드라이브 임계값 이하의 힘은 무시 / Ignore forces below threshold
        if abs(external_force_n) < COMPLIANT_BACKDRIVE_THRESHOLD_N:
            external_force_n = 0.0

        # 최대 힘 클램핑 / Clamp max force
        external_force_n = max(-state.max_force_n,
                               min(state.max_force_n, external_force_n))

        # 스프링 변위 계산 / Calculate spring displacement
        # Δx = F / K (힘이 클수록 더 많이 물러남)
        target_displacement = external_force_n / state.spring_k

        # 댐핑 적용 (부드러운 반응) / Apply damping for smooth response
        velocity = (current_position_deg - state.virtual_position_deg) / max(dt, 0.001)
        damping_force = state.damping_b * velocity
        damped_displacement = target_displacement - damping_force / state.spring_k

        # 스프링 변위를 EMA 필터로 부드럽게 / Smooth spring displacement with EMA
        alpha = 0.3
        state.spring_displacement_deg = (
            alpha * damped_displacement +
            (1 - alpha) * state.spring_displacement_deg
        )

        # 목표 위치 = 가상 목표 - 변위 / Target = virtual target - displacement
        target_position = state.virtual_position_deg - state.spring_displacement_deg

        # 힘이 없으면 원래 위치로 천천히 복귀 / Slowly return to original when force removed
        if abs(external_force_n) < COMPLIANT_BACKDRIVE_THRESHOLD_N:
            return_rate = 0.05  # 천천히 복귀
            state.spring_displacement_deg *= (1.0 - return_rate)
            target_position = state.virtual_position_deg - state.spring_displacement_deg

        return target_position

    def get_state(self, channel_name: str) -> Optional[CompliantState]:
        """순응 제어 상태 조회 / Get compliant control state."""
        return self._states.get(channel_name)


# ============================================================================
# V8.5 AGI: 임피던스 제어기 (Impedance Controller)
# ============================================================================

class ImpedanceController:
    """
    V8.5 AGI: 임피던스 제어기 / Impedance Controller.

    정밀한 힘 제어가 필요한 작업(요리, 공작, 조립)을 위한
    임피던스 제어 구현.

    임피던스 제어 모델:
      M·ẍ + B·ẋ + K·(x - x_eq) = F_desired

    여기서:
      M: 관성 (inertia), B: 댐핑, K: 강성 (stiffness)
      x_eq: 평형 위치, F_desired: 목표 힘

    특징:
    - 강성 조절: 강성↑→위치 정밀도↑, 강성↓→힘 순응도↑
    - 댐핑 조절: 댐핑↑→안정성↑, 댐핑↓→반응속도↑
    - 요리: 낮은 강성 (음식을 누르지 않게)
    - 공작: 중간 강성 (도구를 확실히 잡으면서 힘 조절)
    """

    # 작업별 임피던스 프리셋 / Task-specific impedance presets
    IMPEDANCE_PRESETS: Dict[str, Dict[str, float]] = {
        "cooking_stir": {"stiffness": 0.5, "damping": 0.8, "inertia": 0.05},
        "cooking_flip": {"stiffness": 1.0, "damping": 0.5, "inertia": 0.08},
        "crafting_light": {"stiffness": 1.5, "damping": 0.6, "inertia": 0.1},
        "crafting_heavy": {"stiffness": 3.0, "damping": 0.8, "inertia": 0.15},
        "assembly_insert": {"stiffness": 2.0, "damping": 1.0, "inertia": 0.1},
        "assembly_press": {"stiffness": 4.0, "damping": 1.2, "inertia": 0.2},
        "polishing": {"stiffness": 0.8, "damping": 1.5, "inertia": 0.1},
        "cleaning": {"stiffness": 0.3, "damping": 0.4, "inertia": 0.05},
    }

    def __init__(self) -> None:
        self._states: Dict[str, ImpedanceState] = {}
        self._prev_force_error: Dict[str, float] = {}

    def register_channel(self, channel_name: str) -> None:
        """채널 등록 / Register channel for impedance control."""
        if channel_name not in self._states:
            self._states[channel_name] = ImpedanceState()
            self._prev_force_error[channel_name] = 0.0

    def activate(
        self,
        channel_name: str,
        equilibrium_position_deg: float,
        desired_force_n: float = 0.0,
        preset: Optional[str] = None,
    ) -> ImpedanceState:
        """
        임피던스 제어 활성화 / Activate impedance control.

        Args:
            channel_name: 채널 이름
            equilibrium_position_deg: 평형 위치 (°)
            desired_force_n: 목표 힘 (N), 0이면 위치 기준
            preset: 작업 프리셋 이름

        Returns:
            임피던스 제어 상태
        """
        if channel_name not in self._states:
            self.register_channel(channel_name)

        state = self._states[channel_name]
        state.is_active = True
        state.equilibrium_position_deg = equilibrium_position_deg
        state.desired_force_n = desired_force_n
        state.force_integral = 0.0
        state.force_derivative = 0.0

        # 프리셋 적용 / Apply preset
        if preset and preset in self.IMPEDANCE_PRESETS:
            p = self.IMPEDANCE_PRESETS[preset]
            state.stiffness = p["stiffness"]
            state.damping = p["damping"]
            state.inertia = p["inertia"]
            logger.info(
                "임피던스 프리셋 적용 — %s: %s (K=%.1f, B=%.1f, M=%.2f)",
                channel_name, preset, state.stiffness, state.damping, state.inertia,
            )

        logger.info(
            "임피던스 제어 활성화 — %s: 평형=%.1f°, 목표힘=%.1fN",
            channel_name, equilibrium_position_deg, desired_force_n,
        )
        return state

    def deactivate(self, channel_name: str) -> None:
        """임피던스 제어 비활성화 / Deactivate impedance control."""
        if channel_name in self._states:
            self._states[channel_name].is_active = False
            logger.info("임피던스 제어 비활성화 — %s", channel_name)

    def compute(
        self,
        channel_name: str,
        current_position_deg: float,
        measured_force_n: float,
        dt: float,
    ) -> Optional[float]:
        """
        임피던스 제어 계산 / Compute impedance control output.

        M·ẍ + B·ẋ + K·(x - x_eq) = F_desired
        → 목표 위치 = x_eq + (F_desired - F_measured) / K

        힘 제어 모드 (desired_force > 0):
          위치를 조정하여 목표 힘 달성
        위치 기반 모드 (desired_force == 0):
          평형 위치로 복귀하되 외력에 순응

        Args:
            channel_name: 채널 이름
            current_position_deg: 현재 각도
            measured_force_n: 측정 힘 (N)
            dt: 시간 간격 (초)

        Returns:
            목표 각도 (°) 또는 None (비활성)
        """
        if channel_name not in self._states:
            return None

        state = self._states[channel_name]
        if not state.is_active:
            return None

        state.measured_force_n = measured_force_n
        force_error = state.desired_force_n - measured_force_n
        state.force_error_n = force_error

        # 힘 PID 제어 / Force PID control
        state.force_integral += force_error * dt
        state.force_integral = max(-10.0, min(10.0, state.force_integral))

        prev_error = self._prev_force_error.get(channel_name, 0.0)
        state.force_derivative = (force_error - prev_error) / max(dt, 0.001)
        self._prev_force_error[channel_name] = force_error

        # 힘 제어 출력 → 위치 오프셋 / Force control output → position offset
        force_output = (
            IMPEDANCE_POSITION_GAIN * force_error +
            0.5 * state.force_integral +
            0.3 * state.force_derivative
        )

        # 임피던스 모델 적용 / Apply impedance model
        # 위치 편차 = 힘 / 강성 (낮은 강성 → 더 많이 움직임)
        position_offset = force_output / max(state.stiffness, 0.01)

        # 댐핑 적용 (속도에 비례하는 저항) / Apply damping
        velocity = 0.0
        position_diff = current_position_deg - state.equilibrium_position_deg
        damping_force = state.damping * velocity
        position_offset -= damping_force / max(state.stiffness, 0.01)

        # 힘 제한 / Force limiting
        if abs(measured_force_n + force_error) > IMPEDANCE_FORCE_LIMIT_N:
            position_offset *= 0.5  # 위험 시 이동량 감소
            logger.warning(
                "임피던스 힘 제한 — %s: 측정=%.1fN, 제한=%.1fN",
                channel_name, measured_force_n, IMPEDANCE_FORCE_LIMIT_N,
            )

        # 목표 위치 계산 / Calculate target position
        target_position = state.equilibrium_position_deg + position_offset

        return target_position

    def set_impedance(
        self,
        channel_name: str,
        stiffness: Optional[float] = None,
        damping: Optional[float] = None,
        inertia: Optional[float] = None,
    ) -> None:
        """
        임피던스 파라미터 실시간 조정 / Adjust impedance parameters in real-time.

        작업 중 AI 추론에 의해 강성/댐핑/관성을 동적으로 변경.
        """
        if channel_name not in self._states:
            return

        state = self._states[channel_name]
        if stiffness is not None:
            state.stiffness = max(0.1, min(20.0, stiffness))
        if damping is not None:
            state.damping = max(0.05, min(5.0, damping))
        if inertia is not None:
            state.inertia = max(0.01, min(1.0, inertia))

    def get_state(self, channel_name: str) -> Optional[ImpedanceState]:
        """임피던스 제어 상태 조회 / Get impedance control state."""
        return self._states.get(channel_name)


# ============================================================================
# ServoController 클래스 (V8.5 AGI)
# ============================================================================

class ServoController:
    """
    서보 PWM 제어기 V8.5 AGI / Servo PWM Controller V8.5 AGI.

    Jetson#2 GPIO PWM으로 MG996R 서보 ×3 제어.
    부드러운 동작을 위한 최소저크 보간 지원.

    V8.5 AGI 신규 기능:
    - 적응형 PID 제어 (AdaptivePIDController)
    - 순응 제어 모드 (CompliantController)
    - 임피던스 제어 (ImpedanceController)
    - 작업 맥락 기반 자동 제어 모드 전환

    V8.5 기존 기능:
    - 서보 지터 감지 (ServoJitterDetector)
    - PWM 신호 무결성 모니터링 (PWMSignalMonitor)
    - 개선된 스톨 감지 (재시도 로직 + 쿨다운)
    - 열 보호 (ServoThermalManager)

    Usage:
        ctrl = ServoController()
        ctrl.register_channel("finger_left", 18)
        ctrl.set_angle("finger_left", 45.0)          # 45°로 이동
        ctrl.set_task_context("finger_left", TaskContext.HUMAN_INTERACTION)
        ctrl.activate_compliant("finger_left")         # 순응 제어 활성화
        ctrl.activate_impedance("finger_left", 45.0, preset="cooking_stir")
        ctrl.disable("finger_left")                   # PWM 출력 정지
    """

    def __init__(
        self,
        pwm_freq_hz: int = PWM_FREQ_HZ,
        simulation_mode: bool = False,
    ):
        """
        서보 제어기 초기화 / Initialize servo controller.

        Args:
            pwm_freq_hz: PWM 주파수 (Hz), 기본 50Hz
            simulation_mode: 시뮬레이션 모드
        """
        self._pwm_freq = pwm_freq_hz
        self._simulation = simulation_mode
        self._lock = threading.Lock()

        # 채널 레지스트리 / Channel registry
        self._channels: Dict[str, ServoChannel] = {}

        # GPIO/PWM 핸들 / GPIO/PWM handles
        self._gpio_initialized: bool = False
        self._pwm_handles: Dict[str, Any] = {}

        # 보간 스레드 / Interpolation thread
        self._running: bool = False
        self._interp_thread: Optional[threading.Thread] = None

        # V8.5: 지터 감지기 / V8.5: Jitter detector
        self._jitter_detector = ServoJitterDetector()

        # V8.5: PWM 신호 모니터 / V8.5: PWM signal monitor
        self._pwm_monitor = PWMSignalMonitor()

        # V8.5: 열 보호 관리자 / V8.5: Thermal manager
        self._thermal_manager = ServoThermalManager()

        # V8.5 AGI: 적응형 PID 제어기 / V8.5 AGI: Adaptive PID controller
        self._adaptive_pid = AdaptivePIDController()

        # V8.5 AGI: 순응 제어기 / V8.5 AGI: Compliant controller
        self._compliant_ctrl = CompliantController()

        # V8.5 AGI: 임피던스 제어기 / V8.5 AGI: Impedance controller
        self._impedance_ctrl = ImpedanceController()

        # V8.5 AGI: 현재 제어 모드 / V8.5 AGI: Current control mode
        self._control_modes: Dict[str, ServoControlMode] = {}

        # V8.5 AGI: 외부 힘 피드백 (촉각 센서에서 제공) / External force feedback
        self._external_force_n: Dict[str, float] = {}

        # GPIO 초기화 / Initialize GPIO
        self._init_gpio()

        logger.info("ServoController V8.5 AGI 초기화 완료 / Init complete "
                     f"(freq={pwm_freq_hz}Hz, sim={simulation_mode})")

    def _init_gpio(self) -> None:
        """GPIO PWM 초기화 / Initialize GPIO PWM."""
        if self._simulation:
            logger.info("ServoController: 시뮬레이션 모드 / Simulation mode")
            return

        try:
            import Jetson.GPIO as GPIO
            GPIO.setmode(GPIO.BOARD)
            self._gpio_mod = GPIO
            self._gpio_initialized = True
            logger.info("Jetson GPIO 초기화 성공 / GPIO init success")
        except ImportError:
            try:
                import RPi.GPIO as GPIO
                GPIO.setmode(GPIO.BCM)
                self._gpio_mod = GPIO
                self._gpio_initialized = True
                logger.info("RPi.GPIO 초기화 성공 (fallback)")
            except ImportError:
                logger.warning("GPIO 라이브러리 없음 — 시뮬레이션 모드")
                self._simulation = True

    # ── 채널 관리 / Channel Management ──

    def register_channel(
        self,
        name: str,
        gpio_pin: int,
        min_angle_deg: float = ANGLE_MIN_DEG,
        max_angle_deg: float = ANGLE_MAX_DEG,
        offset_deg: float = 0.0,
    ) -> bool:
        """
        서보 채널 등록 / Register a servo channel.

        Args:
            name: 채널 이름 (예: "finger_left")
            gpio_pin: GPIO 핀 번호
            min_angle_deg: 최소 각도 (°)
            max_angle_deg: 최대 각도 (°)
            offset_deg: 영점 보정 (°)

        Returns:
            등록 성공 여부
        """
        with self._lock:
            channel = ServoChannel(
                name=name,
                gpio_pin=gpio_pin,
                min_angle_deg=min_angle_deg,
                max_angle_deg=max_angle_deg,
                offset_deg=offset_deg,
                current_angle_deg=ANGLE_NEUTRAL_DEG,
                target_angle_deg=ANGLE_NEUTRAL_DEG,
                state=ServoState.DISABLED,
            )
            self._channels[name] = channel

        # GPIO PWM 설정 / Setup GPIO PWM
        if self._gpio_initialized and not self._simulation:
            try:
                self._gpio_mod.setup(gpio_pin, self._gpio_mod.OUT)
                pwm = self._gpio_mod.PWM(gpio_pin, self._pwm_freq)
                # 중립 위치로 시작 / Start at neutral position
                duty_cycle = self._angle_to_duty(ANGLE_NEUTRAL_DEG)
                pwm.start(duty_cycle)
                self._pwm_handles[name] = pwm
                channel.state = ServoState.IDLE
            except Exception as e:
                logger.warning(f"GPIO PWM 설정 실패 ({name}): {e}")

        # 보간 스레드 시작 (첫 채널 등록 시) / Start interpolation thread
        if not self._running:
            self._running = True
            self._interp_thread = threading.Thread(
                target=self._interpolation_loop, daemon=True,
                name="ServoInterpolation"
            )
            self._interp_thread.start()

        logger.info(f"서보 채널 등록: {name} (GPIO={gpio_pin})")
        return True

    def register_default_channels(self) -> None:
        """기본 채널 3개 등록 / Register default 3 channels."""
        for name, pin in DEFAULT_PIN_MAP.items():
            if name not in self._channels:
                self.register_channel(name, pin)

    # ── 각도 제어 / Angle Control ──

    def set_angle(self, name: str, angle_deg: float,
                  speed_deg_s: Optional[float] = None) -> bool:
        """
        서보 각도 설정 / Set servo angle.

        최소저크 보간으로 부드럽게 목표 각도로 이동.
        V8.5: 열 제한 적용, 스톨 쿨다운 확인.

        Args:
            name: 채널 이름
            angle_deg: 목표 각도 (°)
            speed_deg_s: 이동 속도 (°/s), None이면 기본값

        Returns:
            명령 성공 여부
        """
        with self._lock:
            if name not in self._channels:
                logger.error(f"알 수 없는 서보 채널: {name}")
                return False

            channel = self._channels[name]

            # V8.5: 열 셧다운 시 명령 거부 / Reject if thermal shutdown
            if self._thermal_manager.is_shutdown(name):
                logger.error(f"서보 열 셧다운 — {name}: 명령 거부")
                return False

            # V8.5: 스톨 쿨다운 중이면 명령 거부 / Reject if in stall cooldown
            if channel.state == ServoState.STALL_DETECTED:
                elapsed = time.monotonic() - channel.last_stall_time
                if elapsed < STALL_COOLDOWN_S:
                    logger.warning(
                        f"스톨 쿨다운 중 — {name}: %.1f초 남음",
                        STALL_COOLDOWN_S - elapsed,
                    )
                    return False
                else:
                    # 쿨다운 완료 → IDLE로 복귀
                    channel.state = ServoState.IDLE

            # 오프셋 적용 / Apply offset
            effective_angle = angle_deg + channel.offset_deg

            # 각도 범위 클램핑 / Clamp angle range
            effective_angle = max(channel.min_angle_deg,
                                  min(channel.max_angle_deg, effective_angle))

            # V8.5: 열 제한 적용 — 속도 감소 / Apply thermal derating
            derate = self._thermal_manager.get_derate_factor(name)
            effective_speed = (speed_deg_s or DEFAULT_SPEED_DEG_S) * derate
            if derate < 1.0:
                logger.info(
                    "열 제한 적용 — %s: 속도 %.1f→%.1f°/s (계수: %.2f)",
                    name, speed_deg_s or DEFAULT_SPEED_DEG_S, effective_speed, derate,
                )

            channel.target_angle_deg = effective_angle
            channel.speed_deg_s = effective_speed
            channel.state = ServoState.MOVING

            # 즉시 이동 (시뮬레이션 또는 속도 무시) / Immediate move
            if self._simulation:
                channel.current_angle_deg = effective_angle
                channel.pulse_width_us = self._angle_to_pulse(effective_angle)
                channel.state = ServoState.HOLDING
                channel.last_update = time.monotonic()

        return True

    def set_pulse_width(self, name: str, pulse_width_us: float) -> bool:
        """
        서보 펄스폭 직접 설정 / Set servo pulse width directly.

        각도 변환 없이 직접 펄스폭 지정.
        세밀한 조정이나 교정 시 사용.

        Args:
            name: 채널 이름
            pulse_width_us: 펄스폭 (μs), 500~2500

        Returns:
            명령 성공 여부
        """
        with self._lock:
            if name not in self._channels:
                return False

            # V8.5: 열 셧다운 시 거부 / Reject if thermal shutdown
            if self._thermal_manager.is_shutdown(name):
                logger.error(f"서보 열 셧다운 — {name}: 펄스폭 설정 거부")
                return False

            channel = self._channels[name]
            pulse_width_us = max(PULSE_MIN_US, min(PULSE_MAX_US, pulse_width_us))

            channel.pulse_width_us = pulse_width_us
            channel.current_angle_deg = self._pulse_to_angle(pulse_width_us)
            channel.target_angle_deg = channel.current_angle_deg
            channel.state = ServoState.HOLDING
            channel.last_update = time.monotonic()

            # PWM 출력 업데이트 / Update PWM output
            self._update_pwm(name)

        return True

    def get_angle(self, name: str) -> Optional[float]:
        """
        현재 서보 각도 조회 / Get current servo angle.

        Args:
            name: 채널 이름

        Returns:
            현재 각도 (°) 또는 None (채널 없음)
        """
        with self._lock:
            if name not in self._channels:
                return None
            return self._channels[name].current_angle_deg

    # ── 속도 제어 / Speed Control ──

    def set_speed(self, speed_deg_s: float, name: Optional[str] = None) -> None:
        """
        서보 이동 속도 설정 / Set servo movement speed.

        Args:
            speed_deg_s: 이동 속도 (°/s)
            name: 채널 이름, None이면 전체 채널
        """
        speed_deg_s = max(MIN_SPEED_DEG_S, min(MAX_SPEED_DEG_S, speed_deg_s))

        with self._lock:
            if name:
                if name in self._channels:
                    # V8.5: 열 제한 적용
                    derate = self._thermal_manager.get_derate_factor(name)
                    self._channels[name].speed_deg_s = speed_deg_s * derate
            else:
                for ch in self._channels.values():
                    derate = self._thermal_manager.get_derate_factor(ch.name)
                    ch.speed_deg_s = speed_deg_s * derate

    # ── V8.5: 스톨 감지 개선 / V8.5: Improved Stall Detection ──

    def _check_stall_v84(self, name: str, channel: ServoChannel) -> None:
        """
        V8.5: 개선된 스톨 감지 / Improved stall detection.

        대기 중(HOLDING) 상태에서 목표 각도와 현재 각도 차이가
        일정 시간 이상 유지되면 스톨로 판정.
        재시도 로직과 쿨다운 적용.
        """
        if channel.state != ServoState.HOLDING:
            return

        error = abs(channel.target_angle_deg - channel.current_angle_deg)
        if error > ANGLE_TOLERANCE_DEG * 2:
            # 스톨 의심 — 각도 오차가 큰데 이동하지 않음
            if channel.stall_counter < STALL_RETRY_COUNT:
                channel.stall_counter += 1
                channel.last_stall_time = time.monotonic()
                logger.warning(
                    "서보 스톨 의심 — %s: 오차=%.2f° (재시도 %d/%d)",
                    name, error, channel.stall_counter, STALL_RETRY_COUNT,
                )
                # 재시도: 목표 각도로 다시 명령
                channel.state = ServoState.MOVING
            else:
                # 최대 재시도 초과 → 스톨 상태
                channel.state = ServoState.STALL_DETECTED
                channel.last_stall_time = time.monotonic()
                logger.error(
                    "서보 스톨 감지 — %s: 오차=%.2f° (재시도 초과)",
                    name, error,
                )
        else:
            # 정상 — 스톨 카운터 리셋
            if channel.stall_counter > 0:
                channel.stall_counter = 0

    # ── 보간 루프 / Interpolation Loop ──

    def _interpolation_loop(self) -> None:
        """
        서보 보간 루프 V8.5 AGI / Servo interpolation loop V8.5 AGI.

        50Hz로 실행되며, 각 채널의 현재 각도를 목표 각도로
        최소저크 보간하며 부드럽게 이동.
        V8.5 AGI: 순응 제어, 임피던스 제어, 적응형 PID 통합.
        """
        logger.info("서보 보간 루프 V8.5 AGI 시작 / Interpolation loop started")

        while self._running:
            with self._lock:
                for name, channel in self._channels.items():
                    is_moving = channel.state == ServoState.MOVING
                    control_mode = self._control_modes.get(name, ServoControlMode.POSITION)

                    # ── V8.5 AGI: 순응 제어 모드 ──
                    if control_mode == ServoControlMode.COMPLIANT:
                        ext_force = self._external_force_n.get(name, 0.0)
                        target = self._compliant_ctrl.compute(
                            name, channel.current_angle_deg, ext_force, INTERPOLATION_DT,
                        )
                        if target is not None:
                            channel.target_angle_deg = target
                            diff = target - channel.current_angle_deg
                            step = min(abs(diff), DEFAULT_SPEED_DEG_S * INTERPOLATION_DT)
                            channel.current_angle_deg += step * (1.0 if diff > 0 else -1.0)
                            channel.pulse_width_us = self._angle_to_pulse(channel.current_angle_deg)
                            self._update_pwm(name)

                    # ── V8.5 AGI: 임피던스 제어 모드 ──
                    elif control_mode == ServoControlMode.IMPEDANCE:
                        ext_force = self._external_force_n.get(name, 0.0)
                        target = self._impedance_ctrl.compute(
                            name, channel.current_angle_deg, ext_force, INTERPOLATION_DT,
                        )
                        if target is not None:
                            channel.target_angle_deg = target
                            diff = target - channel.current_angle_deg
                            step = min(abs(diff), DEFAULT_SPEED_DEG_S * INTERPOLATION_DT)
                            channel.current_angle_deg += step * (1.0 if diff > 0 else -1.0)
                            channel.pulse_width_us = self._angle_to_pulse(channel.current_angle_deg)
                            self._update_pwm(name)

                    # ── V8.5 AGI: 적응형 PID 모드 / 표준 위치 제어 ──
                    else:
                        if is_moving:
                            # 현재 → 목표 거리 / Distance to target
                            diff = channel.target_angle_deg - channel.current_angle_deg

                            if abs(diff) < 0.1:
                                # 목표 도달 / Target reached
                                channel.current_angle_deg = channel.target_angle_deg
                                channel.state = ServoState.HOLDING
                                channel.stall_counter = 0
                            else:
                                # 속도 기반 이동 / Move based on speed
                                max_step = channel.speed_deg_s * INTERPOLATION_DT
                                step = min(abs(diff), max_step)
                                direction = 1.0 if diff > 0 else -1.0
                                channel.current_angle_deg += step * direction

                            # 펄스폭 업데이트 / Update pulse width
                            channel.pulse_width_us = self._angle_to_pulse(
                                channel.current_angle_deg
                            )
                            channel.last_update = time.monotonic()

                            # PWM 출력 / PWM output
                            self._update_pwm(name)

                            # V8.5 AGI: 적응형 PID 업데이트
                            if control_mode == ServoControlMode.ADAPTIVE_PID:
                                error = channel.target_angle_deg - channel.current_angle_deg
                                self._adaptive_pid.update(
                                    name, error, channel.speed_deg_s, INTERPOLATION_DT,
                                )

                        elif channel.state == ServoState.HOLDING:
                            # V8.5: 홀딩 중 스톨 감지
                            self._check_stall_v84(name, channel)

                    # V8.5: 지터 감지 / Jitter detection
                    self._jitter_detector.update(name, channel.current_angle_deg)

                    # V8.5: PWM 신호 무결성 검사 / PWM signal integrity check
                    duty = self._angle_to_duty(channel.current_angle_deg)
                    self._pwm_monitor.check_pulse(name, channel.pulse_width_us, duty)

                    # V8.5: 열 관리 업데이트 / Thermal management update
                    load = 0.3 if channel.state == ServoState.HOLDING else (
                        0.8 if is_moving else 0.1
                    )
                    temp, derate, shutdown = self._thermal_manager.update_thermal(
                        name, is_moving or channel.state == ServoState.HOLDING, load
                    )
                    channel.estimated_temp_c = temp
                    channel.thermal_derate_factor = derate

                    if shutdown:
                        channel.state = ServoState.THERMAL_SHUTDOWN
                    elif derate < 1.0 and channel.state not in (
                        ServoState.DISABLED, ServoState.FAULT,
                        ServoState.STALL_DETECTED,
                    ):
                        channel.state = ServoState.THERMAL_DERATE

            time.sleep(INTERPOLATION_DT)

        logger.info("서보 보간 루프 종료 / Interpolation loop stopped")

    # ── PWM 출력 / PWM Output ──

    def _update_pwm(self, name: str) -> None:
        """PWM 듀티사이클 업데이트 / Update PWM duty cycle."""
        if self._simulation or not self._gpio_initialized:
            return

        channel = self._channels.get(name)
        if not channel or channel.state == ServoState.DISABLED:
            return

        if name in self._pwm_handles:
            try:
                duty_cycle = self._angle_to_duty(channel.current_angle_deg)
                self._pwm_handles[name].ChangeDutyCycle(duty_cycle)
            except Exception as e:
                logger.debug(f"PWM 업데이트 실패 ({name}): {e}")

    def _angle_to_duty(self, angle_deg: float) -> float:
        """
        각도 → PWM 듀티사이클 변환 / Convert angle to PWM duty cycle.

        Args:
            angle_deg: 각도 (0°~180°)

        Returns:
            듀티사이클 (%), 2.5~12.5%
        """
        pulse_us = self._angle_to_pulse(angle_deg)
        return (pulse_us / PWM_PERIOD_US) * 100.0

    @staticmethod
    def _angle_to_pulse(angle_deg: float) -> float:
        """
        각도 → 펄스폭 변환 / Convert angle to pulse width.

        선형 매핑: 0°=500μs, 180°=2500μs

        Args:
            angle_deg: 각도 (0°~180°)

        Returns:
            펄스폭 (μs)
        """
        angle_deg = max(ANGLE_MIN_DEG, min(ANGLE_MAX_DEG, angle_deg))
        return PULSE_MIN_US + (angle_deg / ANGLE_MAX_DEG) * (PULSE_MAX_US - PULSE_MIN_US)

    @staticmethod
    def _pulse_to_angle(pulse_us: float) -> float:
        """
        펄스폭 → 각도 변환 / Convert pulse width to angle.

        Args:
            pulse_us: 펄스폭 (μs)

        Returns:
            각도 (°)
        """
        pulse_us = max(PULSE_MIN_US, min(PULSE_MAX_US, pulse_us))
        return ((pulse_us - PULSE_MIN_US) / (PULSE_MAX_US - PULSE_MIN_US)) * ANGLE_MAX_DEG

    # ── V8.5 AGI: 작업 맥락 및 제어 모드 ──

    def set_task_context(self, name: str, context: TaskContext) -> AdaptivePIDGains:
        """
        V8.5 AGI: 작업 맥락 설정 / Set task context.

        AI 추론 결과에 따라 작업 맥락을 설정하면,
        적응형 PID 게인이 자동 조정되고
        필요시 제어 모드도 자동 전환.

        자동 모드 전환 규칙:
        - HUMAN_INTERACTION → 순응 제어 자동 활성화
        - FORCE_CONTROLLED → 임피던스 제어 자동 활성화
        - 기타 → 위치 제어 모드 (적응형 PID 적용)

        Args:
            name: 채널 이름
            context: 작업 맥락

        Returns:
            업데이트된 PID 게인
        """
        # 적응형 PID 프리셋 적용
        gains = self._adaptive_pid.set_task_context(name, context)

        # 작업 맥락에 따른 자동 모드 전환
        if context == TaskContext.HUMAN_INTERACTION:
            current = self.get_angle(name) or ANGLE_NEUTRAL_DEG
            self.activate_compliant(name, current)
        elif context == TaskContext.FORCE_CONTROLLED:
            current = self.get_angle(name) or ANGLE_NEUTRAL_DEG
            self.activate_impedance(name, current)
        else:
            # 순응/임피던스 비활성화 → 위치 제어로 복귀
            self.deactivate_compliant(name)
            self.deactivate_impedance(name)
            self._control_modes[name] = ServoControlMode.ADAPTIVE_PID

        return gains

    def get_control_mode(self, name: str) -> ServoControlMode:
        """현재 제어 모드 조회 / Get current control mode."""
        return self._control_modes.get(name, ServoControlMode.POSITION)

    # ── V8.5 AGI: 순응 제어 ──

    def activate_compliant(self, name: str, current_position_deg: Optional[float] = None) -> bool:
        """
        V8.5 AGI: 순응 제어 활성화 / Activate compliant control.

        인간과의 안전한 상호작용 모드. 외부 힘에 순응.

        Args:
            name: 채널 이름
            current_position_deg: 현재 각도 (None이면 자동)

        Returns:
            성공 여부
        """
        if name not in self._channels:
            return False

        pos = current_position_deg or self.get_angle(name) or ANGLE_NEUTRAL_DEG
        self._compliant_ctrl.activate(name, pos)
        self._control_modes[name] = ServoControlMode.COMPLIANT
        logger.info("순응 제어 활성화 — %s", name)
        return True

    def deactivate_compliant(self, name: str) -> None:
        """V8.5 AGI: 순응 제어 비활성화 / Deactivate compliant control."""
        self._compliant_ctrl.deactivate(name)
        if self._control_modes.get(name) == ServoControlMode.COMPLIANT:
            self._control_modes[name] = ServoControlMode.POSITION

    # ── V8.5 AGI: 임피던스 제어 ──

    def activate_impedance(
        self,
        name: str,
        equilibrium_position_deg: float,
        desired_force_n: float = 0.0,
        preset: Optional[str] = None,
    ) -> bool:
        """
        V8.5 AGI: 임피던스 제어 활성화 / Activate impedance control.

        정밀 힘 제어 모드. 요리, 공작, 조립 등.

        Args:
            name: 채널 이름
            equilibrium_position_deg: 평형 위치 (°)
            desired_force_n: 목표 힘 (N)
            preset: 작업 프리셋 (예: "cooking_stir", "crafting_light")

        Returns:
            성공 여부
        """
        if name not in self._channels:
            return False

        self._impedance_ctrl.activate(name, equilibrium_position_deg, desired_force_n, preset)
        self._control_modes[name] = ServoControlMode.IMPEDANCE
        logger.info("임피던스 제어 활성화 — %s (프리셋=%s)", name, preset)
        return True

    def deactivate_impedance(self, name: str) -> None:
        """V8.5 AGI: 임피던스 제어 비활성화 / Deactivate impedance control."""
        self._impedance_ctrl.deactivate(name)
        if self._control_modes.get(name) == ServoControlMode.IMPEDANCE:
            self._control_modes[name] = ServoControlMode.POSITION

    def set_external_force(self, name: str, force_n: float) -> None:
        """
        V8.5 AGI: 외부 힘 설정 (촉각 센서에서 호출) / Set external force.

        촉각 피드백 시스템에서 감지한 외부 힘을 서보 제어기에 전달.
        순응 제어 및 임피던스 제어에서 사용.

        Args:
            name: 채널 이름
            force_n: 외부 힘 (N)
        """
        self._external_force_n[name] = force_n

    # ── 채널 제어 / Channel Control ──

    def disable(self, name: str) -> bool:
        """
        서보 채널 비활성화 / Disable servo channel.

        PWM 출력 정지, 서보 토크 해제.

        Args:
            name: 채널 이름

        Returns:
            비활성화 성공 여부
        """
        with self._lock:
            if name not in self._channels:
                return False

            channel = self._channels[name]
            channel.state = ServoState.DISABLED

            if name in self._pwm_handles and not self._simulation:
                try:
                    self._pwm_handles[name].stop()
                except Exception:
                    pass

        logger.info(f"서보 비활성화: {name}")
        return True

    def enable(self, name: str) -> bool:
        """
        서보 채널 활성화 / Enable servo channel.

        PWM 출력 재시작, 현재 각도 유지.
        V8.5: 열 셧다운 상태에서는 활성화 거부.

        Args:
            name: 채널 이름

        Returns:
            활성화 성공 여부
        """
        # V8.5: 열 셧다운 확인
        if self._thermal_manager.is_shutdown(name):
            logger.error(f"서보 열 셧다운 — {name}: 활성화 거부")
            return False

        with self._lock:
            if name not in self._channels:
                return False

            channel = self._channels[name]
            channel.state = ServoState.IDLE

            if name in self._pwm_handles and not self._simulation:
                try:
                    duty = self._angle_to_duty(channel.current_angle_deg)
                    self._pwm_handles[name].start(duty)
                except Exception:
                    pass

        logger.info(f"서보 활성화: {name}")
        return True

    # ── 진단 / Diagnostics ──

    def get_diagnostics(self, name: Optional[str] = None) -> Any:
        """
        서보 진단 정보 조회 / Get servo diagnostics.

        V8.5: 지터, PWM 무결성, 열 상태 포함.

        Args:
            name: 채널 이름, None이면 전체

        Returns:
            ServoDiagnostics 또는 Dict[str, ServoDiagnostics]
        """
        with self._lock:
            if name:
                if name not in self._channels:
                    return None
                ch = self._channels[name]

                # V8.5: 지터 정보 조회
                jitter_sev, jitter_amp = self._jitter_detector.get_jitter_info(name)

                # V8.5: PWM 무결성 조회
                pwm_ok = self._pwm_monitor.is_signal_ok(name)

                return ServoDiagnostics(
                    channel=ch.name,
                    gpio_pin=ch.gpio_pin,
                    current_angle_deg=round(ch.current_angle_deg, 2),
                    target_angle_deg=round(ch.target_angle_deg, 2),
                    angle_error_deg=round(
                        abs(ch.target_angle_deg - ch.current_angle_deg), 2
                    ),
                    pulse_width_us=round(ch.pulse_width_us, 1),
                    state=ch.state,
                    is_within_tolerance=abs(
                        ch.target_angle_deg - ch.current_angle_deg
                    ) < ANGLE_TOLERANCE_DEG,
                    jitter_severity=jitter_sev,
                    jitter_amplitude_deg=round(jitter_amp, 3),
                    pwm_integrity_ok=pwm_ok,
                    estimated_temp_c=round(ch.estimated_temp_c, 1),
                    thermal_derate_factor=round(ch.thermal_derate_factor, 3),
                    stall_detected=ch.state == ServoState.STALL_DETECTED,
                    stall_retry_remaining=STALL_RETRY_COUNT - ch.stall_counter,
                )
            else:
                return {
                    n: self.get_diagnostics(n) for n in self._channels
                }

    # ── V8.5: 지터 완화 / V8.5: Jitter Mitigation ──

    def apply_jitter_filter(self, name: str) -> bool:
        """
        V8.5: 지터 완화 필터 적용 / Apply jitter mitigation filter.

        지터가 감지된 채널의 속도를 낮추어 진동을 줄임.

        Args:
            name: 채널 이름

        Returns:
            적용 성공 여부
        """
        jitter_sev, _ = self._jitter_detector.get_jitter_info(name)

        if jitter_sev == JitterSeverity.NONE:
            return True

        with self._lock:
            if name not in self._channels:
                return False

            channel = self._channels[name]

            if jitter_sev == JitterSeverity.SEVERE:
                # 심각한 지터: 속도를 30%로 제한
                channel.speed_deg_s = DEFAULT_SPEED_DEG_S * 0.3
                logger.warning("지터 완화 — %s: 속도 30%%로 제한", name)
            elif jitter_sev == JitterSeverity.MODERATE:
                # 중간 지터: 속도를 60%로 제한
                channel.speed_deg_s = DEFAULT_SPEED_DEG_S * 0.6
                logger.info("지터 완화 — %s: 속도 60%%로 제한", name)
            elif jitter_sev == JitterSeverity.MINOR:
                # 경미한 지터: 속도를 80%로 제한
                channel.speed_deg_s = DEFAULT_SPEED_DEG_S * 0.8
                logger.debug("지터 완화 — %s: 속도 80%%로 제한", name)

        return True

    # ── 정리 / Cleanup ──

    def close(self) -> None:
        """서보 제어기 종료 / Close servo controller."""
        self._running = False

        # 모든 채널 비활성화 / Disable all channels
        for name in list(self._channels.keys()):
            self.disable(name)

        # PWM 핸들 정리 / Cleanup PWM handles
        for name, pwm in self._pwm_handles.items():
            try:
                pwm.stop()
            except Exception:
                pass
        self._pwm_handles.clear()

        # GPIO 정리 / Cleanup GPIO
        if self._gpio_initialized and not self._simulation:
            try:
                self._gpio_mod.cleanup()
            except Exception:
                pass

        # 보간 스레드 종료 대기 / Wait for interpolation thread
        if self._interp_thread and self._interp_thread.is_alive():
            self._interp_thread.join(timeout=1.0)

        logger.info("ServoController V8.5 종료 / Shutdown complete")
