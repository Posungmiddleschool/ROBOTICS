#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 메카넘 휠 컨트롤러 (Mecanum Wheel Controller)
============================================================

4x 80mm 알루미늄 메카넘 휠 + 2204 BLDC 1500KV 모터
SimpleFOC Mini 드라이버 (I2C 주소 0x10-0x13)
전방향 이동: 전진/후진/좌우/제자리회전

V8.5 변경사항 / V8.5 Changes from V8.5:
  - 휠 슬립 감지 (Wheel slip detection)
  - 오크메트리 드리프트 보상 (Odometry drift compensation)
  - 키네마틱 검증 (Kinematic verification)
  - 모터 전류 균형 (Motor current balancing across wheels)

역학 공식 (롤러각 45°):
  v_wheel = (1/r) × [v_x ± v_y ± (l_x + l_y) × ω]

속도 제한:
  - 전진/후진: 1.0 m/s
  - 횡이동: 0.5 m/s
  - 제자리 회전: 180°/s

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("JihunRobot.V84.MecanumWheel")


# ============================================================================
# 열거형 및 상수
# ============================================================================

class WheelPosition(Enum):
    """휠 위치 식별"""
    FRONT_LEFT = "front_left"
    FRONT_RIGHT = "front_right"
    REAR_LEFT = "rear_left"
    REAR_RIGHT = "rear_right"


class MovementState(Enum):
    """이동 상태"""
    IDLE = "idle"
    MOVING = "moving"
    EMERGENCY_STOP = "emergency_stop"
    FAULT = "fault"


# I2C 주소 매핑
WHEEL_I2C_ADDRESSES: Dict[WheelPosition, int] = {
    WheelPosition.FRONT_LEFT: 0x10,
    WheelPosition.FRONT_RIGHT: 0x11,
    WheelPosition.REAR_LEFT: 0x12,
    WheelPosition.REAR_RIGHT: 0x13,
}

# 속도 제한 (m/s, rad/s)
MAX_FORWARD_SPEED = 1.0
MAX_LATERAL_SPEED = 0.5
MAX_ROTATION_SPEED = math.pi

# 가속도 제한 (m/s², rad/s²)
MAX_LINEAR_ACCEL = 0.5
MAX_ANGULAR_ACCEL = math.pi

# V8.5: 슬립 감지 상수
SLIP_SPEED_RATIO_THRESHOLD = 1.5    # 휠 속도 비율 임계값
SLIP_TORQUE_ANOMALY_THRESHOLD = 0.4 # 토크 이상 임계값 (정규화)
SLIP_WINDOW_SIZE = 10                # 슬립 판정 윈도우
SLIP_COMPENSATION_GAIN = 0.3         # 슬립 보상 게인

# V8.5: 오크메트리 드리프트 보상 상수
DRIFT_COMPENSATION_ALPHA = 0.98      # EKF 보정 계수
DRIFT_MAX_CORRECTION = 0.05          # 최대 보정량 (m)
DRIFT_IMU_WEIGHT = 0.7               # IMU 신뢰도 가중치

# V8.5: 키네마틱 검증 상수
KINEMATIC_TOLERANCE = 0.1            # 역/정키네마틱 일치 오차 허용치
KINEMATIC_CHECK_INTERVAL = 10        # 검증 주기 (샘플)

# V8.5: 전류 균형 상수
CURRENT_BALANCE_THRESHOLD_A = 0.5    # 전류 불균형 임계값 (A)
CURRENT_BALANCE_GAIN = 0.1           # 전류 균형 게인
CURRENT_MAX_PER_WHEEL_A = 2.5        # 휠당 최대 전류 (DRV8313 한계)


# ============================================================================
# 데이터 클래스
# ============================================================================

@dataclass
class MecanumWheelParams:
    """메카넘 휠 물리 파라미터"""
    wheel_radius_m: float = 0.04
    wheelbase_m: float = 0.250
    track_width_m: float = 0.200
    roller_angle_rad: float = math.pi / 4
    max_rpm: int = 6000


@dataclass
class WheelSpeeds:
    """4휠 개별 속도 (rad/s)"""
    front_left: float = 0.0
    front_right: float = 0.0
    rear_left: float = 0.0
    rear_right: float = 0.0

    def to_list(self) -> List[float]:
        return [self.front_left, self.front_right, self.rear_left, self.rear_right]

    def to_dict(self) -> Dict[WheelPosition, float]:
        return {
            WheelPosition.FRONT_LEFT: self.front_left,
            WheelPosition.FRONT_RIGHT: self.front_right,
            WheelPosition.REAR_LEFT: self.rear_left,
            WheelPosition.REAR_RIGHT: self.rear_right,
        }

    def validate(self, max_speed: float) -> bool:
        return all(abs(s) <= max_speed for s in self.to_list())


@dataclass
class RobotVelocity:
    """로봇 목표 속도"""
    vx: float = 0.0
    vy: float = 0.0
    omega: float = 0.0

    def clamp(self) -> "RobotVelocity":
        return RobotVelocity(
            vx=max(-MAX_FORWARD_SPEED, min(MAX_FORWARD_SPEED, self.vx)),
            vy=max(-MAX_LATERAL_SPEED, min(MAX_LATERAL_SPEED, self.vy)),
            omega=max(-MAX_ROTATION_SPEED, min(MAX_ROTATION_SPEED, self.omega)),
        )


# V8.5: 슬립 상태 데이터
@dataclass
class WheelSlipState:
    """V8.5: 휠 슬립 상태"""
    position: WheelPosition = WheelPosition.FRONT_LEFT
    is_slipping: bool = False
    slip_ratio: float = 0.0       # 슬립 비율 (0=정상, 1=완전 슬립)
    speed_anomaly: float = 0.0    # 속도 이상도
    torque_anomaly: float = 0.0   # 토크 이상도
    compensation_factor: float = 1.0  # 보상 계수
    consecutive_slip_count: int = 0


# V8.5: 전류 균형 상태
@dataclass
class CurrentBalanceState:
    """V8.5: 휠 전류 균형 상태"""
    currents_a: Dict[WheelPosition, float] = field(default_factory=lambda: {
        WheelPosition.FRONT_LEFT: 0.0,
        WheelPosition.FRONT_RIGHT: 0.0,
        WheelPosition.REAR_LEFT: 0.0,
        WheelPosition.REAR_RIGHT: 0.0,
    })
    is_balanced: bool = True
    max_imbalance_a: float = 0.0
    balance_adjustments: Dict[WheelPosition, float] = field(default_factory=lambda: {
        WheelPosition.FRONT_LEFT: 1.0,
        WheelPosition.FRONT_RIGHT: 1.0,
        WheelPosition.REAR_LEFT: 1.0,
        WheelPosition.REAR_RIGHT: 1.0,
    })


# ============================================================================
# 메카넘 휠 컨트롤러 V8.5
# ============================================================================

class MecanumWheelController:
    """
    메카넘 휠 컨트롤러 V8.5 — 4휠 전방향 이동 제어

    V8.5 신규 기능:
    - 휠 슬립 감지 및 보상
    - 오크메트리 드리프트 보상
    - 키네마틱 검증 (역/정 변환 일치 확인)
    - 모터 전류 균형 제어

    역학:
      역키네마틱스 (cmd_vel → 휠 속도):
        v_FL = (1/r) × [vx - vy - (lx + ly) × ω]
        v_FR = (1/r) × [vx + vy + (lx + ly) × ω]
        v_RL = (1/r) × [vx + vy - (lx + ly) × ω]
        v_RR = (1/r) × [vx - vy + (lx + ly) × ω]

      정키네마틱스 (휠 속도 → cmd_vel):
        vx = (r/4) × (v_FL + v_FR + v_RL + v_RR)
        vy = (r/4) × (-v_FL + v_FR + v_RL - v_RR)
        ω = (r/4(lx+ly)) × (-v_FL + v_FR - v_RL + v_RR)
    """

    def __init__(
        self,
        params: Optional[MecanumWheelParams] = None,
        simplefoc_controller: Optional[object] = None,
    ) -> None:
        self._params = params or MecanumWheelParams()
        self._simplefoc = simplefoc_controller
        self._state = MovementState.IDLE
        self._current_velocity = RobotVelocity()
        self._current_wheel_speeds = WheelSpeeds()
        self._last_update_time: float = time.monotonic()
        self._emergency = False

        # 사전 계산: 역학 상수
        r = self._params.wheel_radius_m
        lx = self._params.wheelbase_m
        ly = self._params.track_width_m
        self._inv_radius = 1.0 / r
        self._sum_lx_ly = lx + ly
        self._kinematic_denom = 4.0 * (lx + ly) * r

        # V8.5: 슬립 감지 상태
        self._slip_states: Dict[WheelPosition, WheelSlipState] = {
            pos: WheelSlipState(position=pos) for pos in WheelPosition
        }
        self._slip_history: Dict[WheelPosition, deque] = {
            pos: deque(maxlen=SLIP_WINDOW_SIZE) for pos in WheelPosition
        }

        # V8.5: 전류 균형 상태
        self._current_balance = CurrentBalanceState()

        # V8.5: 키네마틱 검증 카운터
        self._kinematic_check_counter = 0
        self._kinematic_errors = 0

        # V8.5: 오크메트리 드리프트 보상
        self._drift_offset = RobotVelocity()
        self._drift_correction_active = False

        logger.info(
            "메카넘 휠 V8.5 컨트롤러 초기화 — 반지름: %.3fm, 휠베이스: %.3fm, "
            "트랙: %.3fm, 롤러각: %.1f°",
            r, lx, ly, math.degrees(self._params.roller_angle_rad),
        )

    # ========================================================================
    # 공개 메서드 — 이동 명령
    # ========================================================================

    def move_forward(self, speed: float = 0.5) -> None:
        speed = min(abs(speed), MAX_FORWARD_SPEED)
        self._execute_movement(RobotVelocity(vx=speed, vy=0.0, omega=0.0))
        logger.info("전진 이동 — 속도: %.2f m/s", speed)

    def move_backward(self, speed: float = 0.5) -> None:
        speed = min(abs(speed), MAX_FORWARD_SPEED)
        self._execute_movement(RobotVelocity(vx=-speed, vy=0.0, omega=0.0))
        logger.info("후진 이동 — 속도: %.2f m/s", speed)

    def move_lateral(self, speed: float = 0.3) -> None:
        speed = max(-MAX_LATERAL_SPEED, min(MAX_LATERAL_SPEED, speed))
        self._execute_movement(RobotVelocity(vx=0.0, vy=speed, omega=0.0))
        logger.info("횡이동 — 속도: %.2f m/s (%s)", abs(speed), "좌" if speed > 0 else "우")

    def rotate_in_place(self, angular_speed: float = 1.0) -> None:
        angular_speed = max(-MAX_ROTATION_SPEED, min(MAX_ROTATION_SPEED, angular_speed))
        self._execute_movement(RobotVelocity(vx=0.0, vy=0.0, omega=angular_speed))
        logger.info(
            "제자리 회전 — 속도: %.2f rad/s (%.1f°/s, %s)",
            angular_speed, math.degrees(angular_speed),
            "반시계" if angular_speed > 0 else "시계",
        )

    def stop(self) -> None:
        self._execute_movement(RobotVelocity(vx=0.0, vy=0.0, omega=0.0))
        self._state = MovementState.IDLE
        logger.info("휠 정지")

    def emergency_stop(self) -> None:
        self._emergency = True
        self._state = MovementState.EMERGENCY_STOP
        self._current_velocity = RobotVelocity()
        self._current_wheel_speeds = WheelSpeeds()

        if self._simplefoc is not None:
            for position in WheelPosition:
                try:
                    self._simplefoc.set_velocity(WHEEL_I2C_ADDRESSES[position], 0.0)
                except Exception as e:
                    logger.error("긴급 정지 중 %s 통신 실패: %s", position.value, e)

        logger.warning("⚠️ 긴급 정지 실행 — 모든 휠 즉시 정지")

    def release_emergency(self) -> None:
        self._emergency = False
        self._state = MovementState.IDLE
        logger.info("긴급 정지 해제")

    # ========================================================================
    # 공개 메서드 — 역학 계산
    # ========================================================================

    def inverse_kinematics(self, velocity: RobotVelocity) -> WheelSpeeds:
        """역키네마틱스: 로봇 속도 → 4휠 속도 변환"""
        clamped = velocity.clamp()
        r_inv = self._inv_radius
        l_sum = self._sum_lx_ly

        fl = r_inv * (clamped.vx - clamped.vy - l_sum * clamped.omega)
        fr = r_inv * (clamped.vx + clamped.vy + l_sum * clamped.omega)
        rl = r_inv * (clamped.vx + clamped.vy - l_sum * clamped.omega)
        rr = r_inv * (clamped.vx - clamped.vy + l_sum * clamped.omega)

        speeds = WheelSpeeds(front_left=fl, front_right=fr, rear_left=rl, rear_right=rr)

        max_wheel_speed = self._params.max_rpm * 2.0 * math.pi / 60.0
        if not speeds.validate(max_wheel_speed):
            logger.warning("휠 속도 한계 초과 — 스케일 다운 필요")
            speeds = self._scale_wheel_speeds(speeds, max_wheel_speed)

        # V8.5: 슬립 보상 적용
        speeds = self._apply_slip_compensation(speeds)

        # V8.5: 전류 균형 적용
        speeds = self._apply_current_balancing(speeds)

        return speeds

    def forward_kinematics(self, speeds: WheelSpeeds) -> RobotVelocity:
        """정키네마틱스: 4휠 속도 → 로봇 속도 복원"""
        r = self._params.wheel_radius_m
        denom = self._kinematic_denom

        vx = (r / 4.0) * (speeds.front_left + speeds.front_right +
                           speeds.rear_left + speeds.rear_right)
        vy = (r / 4.0) * (-speeds.front_left + speeds.front_right +
                           speeds.rear_left - speeds.rear_right)
        omega = (r / denom) * (-speeds.front_left + speeds.front_right -
                                speeds.rear_left + speeds.rear_right)

        return RobotVelocity(vx=vx, vy=vy, omega=omega)

    # ========================================================================
    # V8.5: 휠 슬립 감지 및 보상
    # ========================================================================

    def detect_wheel_slip(
        self,
        commanded_speeds: WheelSpeeds,
        actual_speeds: WheelSpeeds,
        motor_currents_a: Optional[Dict[WheelPosition, float]] = None,
    ) -> Dict[WheelPosition, WheelSlipState]:
        """
        V8.5: 휠 슬립 감지 / Detect wheel slip.

        슬립 판정 기준:
        1. 명령 속도 대비 실제 속도 편차
        2. 모터 전류 이상 (높은 전류 + 낮은 속도 = 슬립)
        3. 휠 간 속도 비율 이상

        Args:
            commanded_speeds: 명령 휠 속도
            actual_speeds: 실제 측정 휠 속도
            motor_currents_a: 모터 전류 (선택)

        Returns:
            휠별 슬립 상태
        """
        for pos in WheelPosition:
            cmd = commanded_speeds.to_dict()[pos]
            actual = actual_speeds.to_dict()[pos]
            slip_state = self._slip_states[pos]

            # 1. 속도 이상도 계산
            if abs(cmd) > 0.1:
                speed_ratio = abs(actual) / abs(cmd)
                speed_anomaly = abs(1.0 - speed_ratio)
            else:
                speed_ratio = 1.0
                speed_anomaly = 0.0

            slip_state.speed_anomaly = speed_anomaly

            # 2. 전류 이상도 (전류 제공 시)
            if motor_currents_a and pos in motor_currents_a:
                current = motor_currents_a[pos]
                # 정상: 속도에 비례하는 전류
                # 슬립: 속도 낮은데 전류 높음
                expected_current = abs(cmd) * 0.05  # 대략적 추정
                torque_anomaly = 0.0
                if expected_current > 0.01:
                    torque_anomaly = abs(current - expected_current) / max(expected_current, 0.1)
                slip_state.torque_anomaly = min(torque_anomaly, 2.0)

            # 3. 슬립 비율 계산
            if abs(cmd) > 0.1:
                slip_state.slip_ratio = max(0.0, 1.0 - abs(actual / cmd))
            else:
                slip_state.slip_ratio = 0.0

            # 4. 슬립 판정
            is_slipping = (
                speed_anomaly > SLIP_TORQUE_ANOMALY_THRESHOLD or
                slip_state.slip_ratio > 0.3 or
                (speed_ratio > SLIP_SPEED_RATIO_THRESHOLD and abs(cmd) > 0.5)
            )

            # 연속 슬립 카운트
            self._slip_history[pos].append(is_slipping)
            recent = list(self._slip_history[pos])
            slip_count = sum(1 for x in recent if x)

            if is_slipping:
                slip_state.consecutive_slip_count += 1
            else:
                slip_state.consecutive_slip_count = max(0, slip_state.consecutive_slip_count - 1)

            # 연속 3회 이상 슬립 → 슬립 확정
            slip_state.is_slipping = slip_state.consecutive_slip_count >= 3

            if slip_state.is_slipping:
                logger.warning(
                    "휠 슬립 감지 — %s: 비율=%.2f, 속도이상=%.2f, 연속=%d",
                    pos.value, slip_state.slip_ratio, speed_anomaly,
                    slip_state.consecutive_slip_count,
                )
                # 보상 계수 계산 (슬립 시 속도 감소)
                slip_state.compensation_factor = max(0.5, 1.0 - SLIP_COMPENSATION_GAIN * slip_state.slip_ratio)
            else:
                slip_state.compensation_factor = min(1.0, slip_state.compensation_factor + 0.05)

        return dict(self._slip_states)

    def _apply_slip_compensation(self, speeds: WheelSpeeds) -> WheelSpeeds:
        """V8.5: 슬립 보상 적용 / Apply slip compensation to wheel speeds."""
        compensated = WheelSpeeds()
        speed_dict = speeds.to_dict()

        compensated.front_left = speed_dict[WheelPosition.FRONT_LEFT] * self._slip_states[WheelPosition.FRONT_LEFT].compensation_factor
        compensated.front_right = speed_dict[WheelPosition.FRONT_RIGHT] * self._slip_states[WheelPosition.FRONT_RIGHT].compensation_factor
        compensated.rear_left = speed_dict[WheelPosition.REAR_LEFT] * self._slip_states[WheelPosition.REAR_LEFT].compensation_factor
        compensated.rear_right = speed_dict[WheelPosition.REAR_RIGHT] * self._slip_states[WheelPosition.REAR_RIGHT].compensation_factor

        return compensated

    # ========================================================================
    # V8.5: 오크메트리 드리프트 보상
    # ========================================================================

    def compensate_odometry_drift(
        self,
        wheel_odometry: RobotVelocity,
        imu_velocity: Optional[RobotVelocity] = None,
    ) -> RobotVelocity:
        """
        V8.5: 오크메트리 드리프트 보상 / Compensate odometry drift.

        휠 오크메트리와 IMU 측정값을 융합하여
        드리프트 오차를 보상.

        Args:
            wheel_odometry: 휠 오크메트리 속도
            imu_velocity: IMU 측정 속도 (선택)

        Returns:
            보상된 속도
        """
        if imu_velocity is None:
            # IMU 없으면 드리프프 보상 불가
            return wheel_odometry

        # IMU와 휠 오크메트리 차이 = 드리프트 추정
        drift_vx = wheel_odometry.vx - imu_velocity.vx
        drift_vy = wheel_odometry.vy - imu_velocity.vy
        drift_omega = wheel_odometry.omega - imu_velocity.omega

        # 드리프트 오프셋 업데이트 (저역통과필터)
        alpha = DRIFT_COMPENSATION_ALPHA
        self._drift_offset.vx = alpha * self._drift_offset.vx + (1 - alpha) * drift_vx
        self._drift_offset.vy = alpha * self._drift_offset.vy + (1 - alpha) * drift_vy
        self._drift_offset.omega = alpha * self._drift_offset.omega + (1 - alpha) * drift_omega

        # 최대 보정량 제한
        self._drift_offset.vx = max(-DRIFT_MAX_CORRECTION, min(DRIFT_MAX_CORRECTION, self._drift_offset.vx))
        self._drift_offset.vy = max(-DRIFT_MAX_CORRECTION, min(DRIFT_MAX_CORRECTION, self._drift_offset.vy))

        # 보상된 속도 = IMU 가중치 * IMU + (1-IMU가중치) * (휠 - 드리프트)
        imu_w = DRIFT_IMU_WEIGHT
        compensated = RobotVelocity(
            vx=imu_w * imu_velocity.vx + (1 - imu_w) * (wheel_odometry.vx - self._drift_offset.vx),
            vy=imu_w * imu_velocity.vy + (1 - imu_w) * (wheel_odometry.vy - self._drift_offset.vy),
            omega=imu_w * imu_velocity.omega + (1 - imu_w) * (wheel_odometry.omega - self._drift_offset.omega),
        )

        self._drift_correction_active = True
        return compensated

    # ========================================================================
    # V8.5: 키네마틱 검증
    # ========================================================================

    def verify_kinematics(self, commanded: RobotVelocity) -> bool:
        """
        V8.5: 키네마틱 검증 / Verify kinematic consistency.

        역키네마틱스 → 정키네마틱스 왕복 변환 후
        원래 속도와 일치하는지 확인.
        불일치 시 설정 오류 또는 계산 버그 가능성.

        Args:
            commanded: 명령 로봇 속도

        Returns:
            검증 통과 여부
        """
        # 역키네마틱스
        wheel_speeds = self.inverse_kinematics(commanded)

        # 정키네마틱스 (보상 없이 순수 계산)
        r = self._params.wheel_radius_m
        denom = self._kinematic_denom
        reconstructed = RobotVelocity(
            vx=(r / 4.0) * (wheel_speeds.front_left + wheel_speeds.front_right +
                             wheel_speeds.rear_left + wheel_speeds.rear_right),
            vy=(r / 4.0) * (-wheel_speeds.front_left + wheel_speeds.front_right +
                             wheel_speeds.rear_left - wheel_speeds.rear_right),
            omega=(r / denom) * (-wheel_speeds.front_left + wheel_speeds.front_right -
                                  wheel_speeds.rear_left + wheel_speeds.rear_right),
        )

        # 오차 계산
        error_vx = abs(commanded.vx - reconstructed.vx)
        error_vy = abs(commanded.vy - reconstructed.vy)
        error_omega = abs(commanded.omega - reconstructed.omega)

        is_valid = (
            error_vx < KINEMATIC_TOLERANCE and
            error_vy < KINEMATIC_TOLERANCE and
            error_omega < KINEMATIC_TOLERANCE
        )

        self._kinematic_check_counter += 1

        if not is_valid:
            self._kinematic_errors += 1
            logger.warning(
                "키네마틱 검증 실패 — 오차: vx=%.4f, vy=%.4f, ω=%.4f",
                error_vx, error_vy, error_omega,
            )

        return is_valid

    # ========================================================================
    # V8.5: 모터 전류 균형
    # ========================================================================

    def balance_motor_currents(
        self,
        motor_currents_a: Dict[WheelPosition, float],
    ) -> CurrentBalanceState:
        """
        V8.5: 모터 전류 균형 / Balance motor currents across wheels.

        4개 휠 모터의 전류를 모니터링하고
        불균형 시 속도 보정으로 균형 유지.

        Args:
            motor_currents_a: 휠별 모터 전류 (A)

        Returns:
            CurrentBalanceState 균형 상태
        """
        self._current_balance.currents_a = dict(motor_currents_a)

        currents = list(motor_currents_a.values())
        mean_current = sum(currents) / len(currents) if currents else 0.0

        # 불균형 계산
        max_imbalance = 0.0
        for pos, current in motor_currents_a.items():
            imbalance = abs(current - mean_current)
            max_imbalance = max(max_imbalance, imbalance)

            # 균형 조정 계수 계산
            if mean_current > 0.01:
                ratio = current / mean_current
                if ratio > 1.0 + CURRENT_BALANCE_THRESHOLD_A:
                    # 과전류 → 속도 감소
                    adjustment = 1.0 - CURRENT_BALANCE_GAIN * (ratio - 1.0)
                elif ratio < 1.0 - CURRENT_BALANCE_THRESHOLD_A:
                    # 저전류 → 속도 증가
                    adjustment = 1.0 + CURRENT_BALANCE_GAIN * (1.0 - ratio)
                else:
                    adjustment = 1.0
                self._current_balance.balance_adjustments[pos] = max(0.5, min(1.5, adjustment))
            else:
                self._current_balance.balance_adjustments[pos] = 1.0

        self._current_balance.max_imbalance_a = max_imbalance
        self._current_balance.is_balanced = max_imbalance < CURRENT_BALANCE_THRESHOLD_A

        if not self._current_balance.is_balanced:
            logger.info(
                "전류 불균형 감지 — 최대 편차: %.2fA (임계: %.2fA)",
                max_imbalance, CURRENT_BALANCE_THRESHOLD_A,
            )

        return self._current_balance

    def _apply_current_balancing(self, speeds: WheelSpeeds) -> WheelSpeeds:
        """V8.5: 전류 균형 보정 적용 / Apply current balancing to wheel speeds."""
        balanced = WheelSpeeds()
        speed_dict = speeds.to_dict()

        balanced.front_left = speed_dict[WheelPosition.FRONT_LEFT] * self._current_balance.balance_adjustments[WheelPosition.FRONT_LEFT]
        balanced.front_right = speed_dict[WheelPosition.FRONT_RIGHT] * self._current_balance.balance_adjustments[WheelPosition.FRONT_RIGHT]
        balanced.rear_left = speed_dict[WheelPosition.REAR_LEFT] * self._current_balance.balance_adjustments[WheelPosition.REAR_LEFT]
        balanced.rear_right = speed_dict[WheelPosition.REAR_RIGHT] * self._current_balance.balance_adjustments[WheelPosition.REAR_RIGHT]

        return balanced

    # ========================================================================
    # 공개 메서드 — 상태 조회
    # ========================================================================

    @property
    def state(self) -> MovementState:
        return self._state

    @property
    def current_velocity(self) -> RobotVelocity:
        return self._current_velocity

    @property
    def current_wheel_speeds(self) -> WheelSpeeds:
        return self._current_wheel_speeds

    @property
    def is_emergency(self) -> bool:
        return self._emergency

    def get_wheel_rpm(self, position: WheelPosition) -> float:
        speed_rad_s = self._current_wheel_speeds.to_dict()[position]
        return speed_rad_s * 60.0 / (2.0 * math.pi)

    # V8.5: 슬립 상태 조회
    def get_slip_states(self) -> Dict[WheelPosition, WheelSlipState]:
        """V8.5: 휠 슬립 상태 조회 / Get wheel slip states."""
        return dict(self._slip_states)

    # V8.5: 드리프트 상태 조회
    def get_drift_state(self) -> Dict[str, float]:
        """V8.5: 오크메트리 드리프트 상태 조회 / Get odometry drift state."""
        return {
            "drift_vx": self._drift_offset.vx,
            "drift_vy": self._drift_offset.vy,
            "drift_omega": self._drift_offset.omega,
            "correction_active": self._drift_correction_active,
        }

    # V8.5: 키네마틱 검증 결과
    def get_kinematic_health(self) -> Dict[str, Any]:
        """V8.5: 키네마틱 건전성 조회 / Get kinematic health."""
        error_rate = (
            self._kinematic_errors / self._kinematic_check_counter * 100
            if self._kinematic_check_counter > 0 else 0.0
        )
        return {
            "checks_performed": self._kinematic_check_counter,
            "errors": self._kinematic_errors,
            "error_rate_pct": round(error_rate, 2),
        }

    # V8.5: 전류 균형 상태 조회
    def get_current_balance(self) -> CurrentBalanceState:
        """V8.5: 전류 균형 상태 조회 / Get current balance state."""
        return self._current_balance

    # ========================================================================
    # 내부 메서드
    # ========================================================================

    def _execute_movement(self, target: RobotVelocity) -> None:
        if self._emergency:
            logger.warning("긴급 정지 상태 — 이동 명령 무시")
            return

        now = time.monotonic()
        dt = now - self._last_update_time
        self._last_update_time = now

        if dt > 0.0 and self._current_velocity != RobotVelocity():
            target = self._apply_acceleration_limit(
                self._current_velocity, target, dt
            )

        wheel_speeds = self.inverse_kinematics(target)

        # V8.5: 주기적 키네마틱 검증
        self._kinematic_check_counter += 1
        if self._kinematic_check_counter % KINEMATIC_CHECK_INTERVAL == 0:
            self.verify_kinematics(target)

        if self._simplefoc is not None:
            self._send_wheel_commands(wheel_speeds)

        self._current_velocity = target
        self._current_wheel_speeds = wheel_speeds
        self._state = MovementState.MOVING

    def _apply_acceleration_limit(
        self, current: RobotVelocity, target: RobotVelocity, dt: float,
    ) -> RobotVelocity:
        max_dvx = MAX_LINEAR_ACCEL * dt
        max_dvy = MAX_LINEAR_ACCEL * dt
        max_domega = MAX_ANGULAR_ACCEL * dt

        vx = self._clamp_delta(current.vx, target.vx, max_dvx)
        vy = self._clamp_delta(current.vy, target.vy, max_dvy)
        omega = self._clamp_delta(current.omega, target.omega, max_domega)

        return RobotVelocity(vx=vx, vy=vy, omega=omega)

    @staticmethod
    def _clamp_delta(current: float, target: float, max_delta: float) -> float:
        delta = target - current
        if abs(delta) <= max_delta:
            return target
        return current + math.copysign(max_delta, delta)

    def _scale_wheel_speeds(self, speeds: WheelSpeeds, max_speed: float) -> WheelSpeeds:
        speed_list = speeds.to_list()
        max_abs = max(abs(s) for s in speed_list)
        if max_abs <= max_speed:
            return speeds

        scale = max_speed / max_abs
        logger.warning(
            "휠 속도 스케일 다운 — 비율: %.2f", scale,
        )
        return WheelSpeeds(
            front_left=speeds.front_left * scale,
            front_right=speeds.front_right * scale,
            rear_left=speeds.rear_left * scale,
            rear_right=speeds.rear_right * scale,
        )

    def _send_wheel_commands(self, speeds: WheelSpeeds) -> None:
        speed_map = speeds.to_dict()
        for position, speed in speed_map.items():
            i2c_addr = WHEEL_I2C_ADDRESSES[position]
            try:
                self._simplefoc.set_velocity(i2c_addr, speed)
            except Exception as e:
                logger.error(
                    "휠 속도 전송 실패 — %s (0x%02X): %s",
                    position.value, i2c_addr, e,
                )
                self._state = MovementState.FAULT


# ============================================================================
# Impedance Control + Odometry Integration — V8.5 확장
# ============================================================================

class WheelOdometryEstimator:
    """휠 오크메트리 + IMU 융합 위치 추정기 V8.5

    V8.5: 드리프트 보상 강화, 슬립 감지 통합.
    """

    def __init__(self, wheel_radius_m=0.05, wheel_base_m=0.2,
                 gear_ratio=30.0, encoder_ppr=1000):
        self.wheel_radius = wheel_radius_m
        self.wheel_base = wheel_base_m
        self.gear_ratio = gear_ratio
        self.encoder_ppr = encoder_ppr

        # 상태 추정
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.vx = 0.0
        self.vy = 0.0
        self.omega = 0.0

        # 이전 엔코더 값
        self.prev_encoder = [0, 0, 0, 0]
        self.initialized = False

        # IMU 융합 (EKF)
        self.ekf_P = np.eye(6) * 0.01
        self.ekf_Q = np.eye(6) * 0.001
        self.ekf_R_wheel = np.eye(3) * 0.01
        self.ekf_R_imu = np.eye(3) * 0.005

        # 슬립 감지
        self.slip_threshold = 0.3
        self.slip_detected = [False, False, False, False]

        # V8.5: 드리프트 보상 누적값
        self._drift_x = 0.0
        self._drift_y = 0.0
        self._drift_theta = 0.0

    def update(self, encoder_counts, imu_accel=None, imu_gyro=None, dt=0.01):
        if not self.initialized:
            self.prev_encoder = list(encoder_counts)
            self.initialized = True
            return

        wheel_speeds = []
        for i in range(4):
            delta = encoder_counts[i] - self.prev_encoder[i]
            speed_rads = (delta / self.encoder_ppr) * 2 * np.pi / dt / self.gear_ratio
            wheel_speeds.append(speed_rads)

        self.prev_encoder = list(encoder_counts)

        self._detect_slip(wheel_speeds)

        if not any(self.slip_detected):
            self._inverse_kinematics(wheel_speeds)
        else:
            if imu_accel is not None and imu_gyro is not None:
                self._imu_update(imu_accel, imu_gyro, dt)

        if imu_accel is not None and imu_gyro is not None:
            self._ekf_fusion(wheel_speeds, imu_accel, imu_gyro, dt)

        # 위치 적분
        self.x += self.vx * np.cos(self.theta) * dt - self.vy * np.sin(self.theta) * dt
        self.y += self.vx * np.sin(self.theta) * dt + self.vy * np.cos(self.theta) * dt
        self.theta += self.omega * dt
        self.theta = (self.theta + np.pi) % (2 * np.pi) - np.pi

    def _inverse_kinematics(self, wheel_speeds):
        r = self.wheel_radius
        L = self.wheel_base
        self.vx = r / 4 * (wheel_speeds[0] + wheel_speeds[1] + wheel_speeds[2] + wheel_speeds[3])
        self.vy = r / 4 * (-wheel_speeds[0] + wheel_speeds[1] + wheel_speeds[2] - wheel_speeds[3])
        self.omega = r / (4 * L) * (-wheel_speeds[0] + wheel_speeds[1] - wheel_speeds[2] + wheel_speeds[3])

    def _imu_update(self, accel, gyro, dt):
        self.vx += accel[0] * dt
        self.vy += accel[1] * dt
        self.omega = gyro[2]

    def _detect_slip(self, wheel_speeds):
        mean_speed = np.mean(wheel_speeds)
        if abs(mean_speed) < 0.01:
            self.slip_detected = [False] * 4
            return
        for i, speed in enumerate(wheel_speeds):
            deviation = abs(speed - mean_speed) / max(abs(mean_speed), 0.01)
            self.slip_detected[i] = deviation > self.slip_threshold

    def _ekf_fusion(self, wheel_speeds, imu_accel, imu_gyro, dt):
        state = np.array([self.vx, self.vy, self.omega, self.x, self.y, self.theta])
        z_wheel = np.array([self.vx, self.vy, self.omega])
        innovation = z_wheel - state[:3]
        S = self.ekf_P[:3, :3] + self.ekf_R_wheel
        K = self.ekf_P[:3, :3] @ np.linalg.inv(S)
        state = state + np.concatenate([K @ innovation, np.zeros(3)])
        self.ekf_P = (np.eye(6) - K @ np.eye(6)[:3, :]) @ self.ekf_P
        self.vx, self.vy, self.omega = state[:3]

    @property
    def pose(self):
        return {'x': self.x, 'y': self.y, 'theta': self.theta}

    @property
    def velocity(self):
        return {'vx': self.vx, 'vy': self.vy, 'omega': self.omega}

    @property
    def any_slip(self):
        return any(self.slip_detected)


class ImpedanceController:
    """임피던스 제어기 — 안전한 인간-로봇 물리적 상호작용

    F = K * (x_d - x) + D * (dx_d - dx)
    """

    def __init__(self, stiffness=50.0, damping=10.0,
                 max_force_n=20.0, safety_force_n=50.0):
        self.stiffness = stiffness
        self.damping = damping
        self.max_force = max_force_n
        self.safety_force = safety_force_n
        self.target_x = 0.0
        self.target_y = 0.0
        self.target_vx = 0.0
        self.target_vy = 0.0
        self.external_force_x = 0.0
        self.external_force_y = 0.0

    def compute_impedance_force(self, current_x, current_y,
                                current_vx, current_vy):
        dx = self.target_x - current_x
        dy = self.target_y - current_y
        dvx = self.target_vx - current_vx
        dvy = self.target_vy - current_vy
        fx = self.stiffness * dx + self.damping * dvx + self.external_force_x
        fy = self.stiffness * dy + self.damping * dvy + self.external_force_y
        force_magnitude = np.sqrt(fx**2 + fy**2)
        if force_magnitude > self.max_force:
            scale = self.max_force / force_magnitude
            fx *= scale
            fy *= scale
        if force_magnitude > self.safety_force:
            logging.warning(f"[ImpedanceCtrl] 안전 힘 초과: {force_magnitude:.1f}N")
            return 0.0, 0.0
        return float(fx), float(fy)

    def set_target(self, x, y, vx=0, vy=0):
        self.target_x = x
        self.target_y = y
        self.target_vx = vx
        self.target_vy = vy

    def update_external_force(self, fx, fy):
        self.external_force_x = fx
        self.external_force_y = fy

    @property
    def compliance_level(self):
        return 1.0 / (1.0 + self.stiffness / 50.0)
