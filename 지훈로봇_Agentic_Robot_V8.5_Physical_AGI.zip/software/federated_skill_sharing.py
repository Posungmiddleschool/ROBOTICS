#!/usr/bin/env python3
"""
federated_skill_sharing.py - Federated Learning for Multi-Robot Skill Sharing
멀티로봇 스킬 공유를 위한 연합학습 모듈

Enables multiple robots to share learned skills via federated averaging,
with differential privacy and robust aggregation for non-IID data.
차분 프라이버시와 비독립동등분포(non-IID) 데이터를 위한 강건 집계로
여러 로봇이 학습된 스킬을 연합 평균을 통해 공유.
"""

import gzip
import hashlib
import json
import logging
import pickle
import sqlite3
import struct
import threading
import time
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple

import numpy as np

try:
    import torch
    import torch.nn as nn
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# ─── Constants / 상수 ────────────────────────────────────────────────
DB_PATH = "federated_skills.db"
DP_EPSILON = 1.0               # differential privacy ε / 차분 프라이버시 ε
DP_DELTA = 1e-5                 # differential privacy δ / 차분 프라이버시 δ
DP_CLIP_NORM = 1.0              # gradient clip norm for DP / DP용 그래디언트 클립 노름
MAX_GRADIENT_SIZE = 100000      # max elements in gradient vector / 그래디언트 벡터 최대 원소 수
COMPRESSION_LEVEL = 6           # gzip compression level / gzip 압축 수준
PROXIMAL_TERM = 0.01            # FedProx proximal term μ / FedProx 근접 항 μ
TRIM_RATIO = 0.1               # trimmed mean ratio (trim 10% each side) / 양쪽 10% 절삭
ROBOT_ID = "robot_default"      # default robot identifier / 기본 로봇 식별자
MIN_CLIENTS_FOR_AGGREGATION = 2 # 최소 집계 클라이언트 수 / Minimum clients for aggregation
BANDWIDTH_ESTIMATE_MBPS = 10.0  # estimated network bandwidth / 예상 네트워크 대역폭


# ─── SkillGradient / 스킬 그래디언트 ──────────────────────────────────
@dataclass
class SkillGradient:
    """
    직렬화 가능한 스킬 업데이트 (로봇 간 공유 가능)
    Serialized skill update that can be shared between robots.
    """
    skill_id: str                            # unique skill identifier / 고유 스킬 식별자
    gradient_vector: np.ndarray              # flattened gradient / 평탄화된 그래디언트
    performance_metrics: Dict[str, float]    # task performance / 작업 성능
    source_robot_id: str                     # originating robot / 출처 로봇
    timestamp: float = field(default_factory=time.time)
    version: int = 1                         # protocol version / 프로토콜 버전
    num_samples: int = 0                     # samples used to compute gradient / 그래디언트 계산에 사용된 샘플 수

    @property
    def size_bytes(self) -> int:
        """그래디언트 벡터의 바이트 크기 / Byte size of gradient vector."""
        return self.gradient_vector.nbytes

    @property
    def checksum(self) -> str:
        """그래디언트 무결성 체크섬 / Gradient integrity checksum."""
        return hashlib.sha256(self.gradient_vector.tobytes()).hexdigest()[:16]


# ─── FederatedAggregator / 연합 집계기 ───────────────────────────────
class FederatedAggregator:
    """
    여러 로봇의 스킬 업데이트를 집계 / Aggregates skill updates from multiple robots.
    - fed_avg: Federated Averaging (McMahan et al.) / 연합 평균
    - fed_prox: FedProx with proximal term / 근접 항 포함 FedProx
    - Robust aggregation: trimmed mean for non-IID data / 비IID 데이터용 절삭 평균
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._ensure_schema()
        self._aggregation_history: List[Dict] = []
        logger.info("FederatedAggregator 초기화 / Initialized")

    def _ensure_schema(self):
        """데이터베이스 스키마 보장 / Ensure database schema."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS skill_gradients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                skill_id TEXT NOT NULL,
                gradient BLOB NOT NULL,
                source_robot TEXT NOT NULL,
                num_samples INTEGER DEFAULT 0,
                performance TEXT DEFAULT '{}',
                timestamp REAL NOT NULL,
                checksum TEXT NOT NULL
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_skill ON skill_gradients(skill_id)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_robot ON skill_gradients(source_robot)")
        self._conn.commit()

    def store_gradient(self, gradient: SkillGradient) -> int:
        """스킬 그래디언트 저장 / Store a skill gradient."""
        blob = gradient.gradient_vector.astype(np.float32).tobytes()
        perf_json = json.dumps(gradient.performance_metrics)
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO skill_gradients "
                "(skill_id, gradient, source_robot, num_samples, performance, timestamp, checksum) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (gradient.skill_id, blob, gradient.source_robot,
                 gradient.num_samples, perf_json, gradient.timestamp, gradient.checksum)
            )
            row_id = cursor.lastrowid
            self._conn.commit()
        return row_id

    def get_gradients(self, skill_id: str) -> List[SkillGradient]:
        """특정 스킬의 모든 그래디언트 로드 / Load all gradients for a skill."""
        rows = self._conn.execute(
            "SELECT gradient, source_robot, num_samples, performance, timestamp, checksum "
            "FROM skill_gradients WHERE skill_id=?", (skill_id,)
        ).fetchall()

        gradients = []
        for row in rows:
            grad_vec = np.frombuffer(row[0], dtype=np.float32).copy()
            perf = json.loads(row[3])
            gradients.append(SkillGradient(
                skill_id=skill_id, gradient_vector=grad_vec,
                source_robot_id=row[1], num_samples=row[2],
                performance_metrics=perf, timestamp=row[4]
            ))
        return gradients

    def fed_avg(self, gradients: List[SkillGradient]) -> Optional[SkillGradient]:
        """
        연합 평균 (FedAvg): 가중 평균으로 그래디언트 집계 / Federated Averaging: weighted average.
        가중치 = 각 클라이언트의 샘플 수 / Weight = number of samples per client.
        """
        if len(gradients) < MIN_CLIENTS_FOR_AGGREGATION:
            logger.warning(f"집계 불가: {len(gradients)} 클라이언트 (최소 {MIN_CLIENTS_FOR_AGGREGATION}) / "
                           f"Cannot aggregate: too few clients")
            return None

        # 샘플 수 기반 가중치 / Sample-count based weights
        total_samples = sum(g.num_samples for g in gradients)
        if total_samples == 0:
            # 샘플 수 미상 시 균등 가중치 / Equal weights if sample counts unknown
            weights = [1.0 / len(gradients)] * len(gradients)
        else:
            weights = [g.num_samples / total_samples for g in gradients]

        # 가중 평균 / Weighted average
        grad_dim = gradients[0].gradient_vector.shape[0]
        aggregated = np.zeros(grad_dim, dtype=np.float64)
        for g, w in zip(gradients, weights):
            aggregated += w * g.gradient_vector.astype(np.float64)

        # 최고 성능 메트릭 선택 / Select best performance metrics
        best_perf = max(gradients, key=lambda g: g.performance_metrics.get("accuracy", 0.0))
        result = SkillGradient(
            skill_id=gradients[0].skill_id,
            gradient_vector=aggregated.astype(np.float32),
            performance_metrics=best_perf.performance_metrics,
            source_robot_id="aggregated",
            num_samples=total_samples,
        )

        self._record_aggregation("fed_avg", gradients, result)
        logger.info(f"FedAvg 완료: skill={result.skill_id}, {len(gradients)} 클라이언트, "
                     f"samples={total_samples} / FedAvg complete")
        return result

    def fed_prox(self, gradients: List[SkillGradient],
                 proximal_term: float = PROXIMAL_TERM) -> Optional[SkillGradient]:
        """
        FedProx: 근접 항이 포함된 연합 집계 / Federated aggregation with proximal term.
        FedAvg + μ/2 * ||w - w_global||² 정규화 / FedAvg + μ/2 * ||w - w_global||² regularization.
        non-IID 데이터에서 수렴 향상 / Improves convergence on non-IID data.
        """
        fed_avg_result = self.fed_avg(gradients)
        if fed_avg_result is None:
            return None

        # 근접 정규화: 글로벌 평균에서 너무 멀어지는 것 방지
        # Proximal regularization: prevent drifting too far from global average
        global_center = fed_avg_result.gradient_vector.copy()
        proximal_penalty = np.zeros_like(global_center)

        for g in gradients:
            diff = g.gradient_vector - global_center
            # μ * (w_i - w_global) 방향으로 정규화 / Regularize toward global
            proximal_penalty += diff

        proximal_penalty *= proximal_term / len(gradients)
        fed_avg_result.gradient_vector = (fed_avg_result.gradient_vector - proximal_penalty).astype(np.float32)

        self._record_aggregation("fed_prox", gradients, fed_avg_result)
        logger.info(f"FedProx 완료: μ={proximal_term} / FedProx complete")
        return fed_avg_result

    def trimmed_mean(self, gradients: List[SkillGradient],
                     trim_ratio: float = TRIM_RATIO) -> Optional[SkillGradient]:
        """
        절삭 평균: non-IID 데이터를 위한 강건 집계 / Trimmed mean: robust aggregation for non-IID.
        이상치 그래디언트를 양쪽에서 trim_ratio만큼 제거 후 평균.
        Trim outlier gradients by trim_ratio on each side, then average.
        """
        if len(gradients) < MIN_CLIENTS_FOR_AGGREGATION + 2:
            return self.fed_avg(gradients)

        grad_dim = gradients[0].gradient_vector.shape[0]
        # 모든 그래디언트를 스택 / Stack all gradients
        grad_matrix = np.stack([g.gradient_vector for g in gradients])  # (num_clients, grad_dim)

        # 각 차원별로 정렬 후 절삭 / Sort and trim per dimension
        sorted_matrix = np.sort(grad_matrix, axis=0)
        n_trim = max(1, int(len(gradients) * trim_ratio))
        trimmed = sorted_matrix[n_trim:-n_trim] if n_trim < len(gradients) - n_trim else sorted_matrix

        aggregated = np.mean(trimmed, axis=0).astype(np.float32)

        best_perf = max(gradients, key=lambda g: g.performance_metrics.get("accuracy", 0.0))
        result = SkillGradient(
            skill_id=gradients[0].skill_id,
            gradient_vector=aggregated,
            performance_metrics=best_perf.performance_metrics,
            source_robot_id="aggregated_trimmed",
            num_samples=sum(g.num_samples for g in gradients),
        )

        self._record_aggregation("trimmed_mean", gradients, result)
        logger.info(f"절삭 평균 완료: trim_ratio={trim_ratio} / Trimmed mean complete")
        return result

    def _record_aggregation(self, method: str, inputs: List[SkillGradient],
                            result: SkillGradient):
        """집계 기록 / Record aggregation in history."""
        self._aggregation_history.append({
            "method": method,
            "num_inputs": len(inputs),
            "skill_id": result.skill_id,
            "timestamp": time.time(),
            "result_checksum": result.checksum,
        })

    def get_aggregation_history(self) -> List[Dict]:
        """집계 이력 반환 / Return aggregation history."""
        return self._aggregation_history.copy()


# ─── SkillSharingClient / 스킬 공유 클라이언트 ────────────────────────
class SkillSharingClient:
    """
    다른 로봇과 스킬을 공유하는 클라이언트 / Client for sharing skills with other robots.
    - prepare_update: 로컬 스킬에서 그래디언트 업데이트 준비 / Prepare gradient update from local skill
    - apply_received_update: 수신된 업데이트 적용 / Apply received update
    - 차분 프라이버시 노이즈 추가 (ε=1.0) / Add DP noise (ε=1.0)
    """

    def __init__(self, robot_id: str = ROBOT_ID,
                 aggregator: Optional[FederatedAggregator] = None,
                 dp_epsilon: float = DP_EPSILON):
        self.robot_id = robot_id
        self.aggregator = aggregator or FederatedAggregator()
        self.dp_epsilon = dp_epsilon
        self._local_skills: Dict[str, np.ndarray] = {}  # skill_id → parameters
        self._received_updates: List[SkillGradient] = []
        self._lock = threading.Lock()
        logger.info(f"SkillSharingClient 초기화: robot={self.robot_id} / Initialized")

    def register_skill(self, skill_id: str, parameters: np.ndarray):
        """로컬 스킬 등록 / Register a local skill with its parameters."""
        self._local_skills[skill_id] = parameters.copy()
        logger.info(f"스킬 등록: {skill_id}, params={parameters.shape} / Skill registered")

    def prepare_update(self, skill_id: str,
                       performance_metrics: Optional[Dict[str, float]] = None) -> Optional[SkillGradient]:
        """
        로컬 스킬에서 그래디언트 업데이트 준비 / Prepare gradient update from local skill.
        차분 프라이버시 노이즈 추가 / Add differential privacy noise.
        """
        if skill_id not in self._local_skills:
            logger.warning(f"스킬 미등록: {skill_id} / Skill not registered")
            return None

        params = self._local_skills[skill_id].copy()

        # 그래디언트 크기 제한 / Limit gradient size
        if params.size > MAX_GRADIENT_SIZE:
            logger.warning(f"그래디언트 크기 초과: {params.size} > {MAX_GRADIENT_SIZE} / "
                           f"Gradient too large")
            # 무작위 샘플링으로 축소 / Downsample via random selection
            indices = np.random.choice(params.size, MAX_GRADIENT_SIZE, replace=False)
            params = params.flatten()[indices]

        flat_params = params.flatten().astype(np.float32)

        # 그래디언트 클리핑 (DP) / Gradient clipping for DP
        grad_norm = np.linalg.norm(flat_params)
        if grad_norm > DP_CLIP_NORM:
            flat_params = flat_params * (DP_CLIP_NORM / grad_norm)

        # 차분 프라이버시 가우시안 노이즈 추가 / Add DP Gaussian noise
        sensitivity = DP_CLIP_NORM
        noise_scale = sensitivity * np.sqrt(2 * np.log(1.25 / DP_DELTA)) / self.dp_epsilon
        noise = np.random.normal(0, noise_scale, size=flat_params.shape).astype(np.float32)
        noisy_params = flat_params + noise

        gradient = SkillGradient(
            skill_id=skill_id,
            gradient_vector=noisy_params,
            performance_metrics=performance_metrics or {},
            source_robot_id=self.robot_id,
            num_samples=len(flat_params),
        )

        # 집계기에 저장 / Store in aggregator
        self.aggregator.store_gradient(gradient)
        logger.info(f"업데이트 준비 완료: {skill_id}, norm={grad_norm:.3f}, "
                     f"ε={self.dp_epsilon} / Update prepared")
        return gradient

    def apply_received_update(self, update: SkillGradient,
                              learning_rate: float = 0.01) -> bool:
        """
        수신된 업데이트를 로컬 스킬에 적용 / Apply received update to local skill.
        로컬 파라미터에 그래디언트 업데이트 반영 / Reflect gradient update on local parameters.
        """
        if update.skill_id not in self._local_skills:
            logger.warning(f"수신 업데이트 스킬 미등록: {update.skill_id} / "
                           f"Received update for unregistered skill")
            return False

        local_params = self._local_skills[update.skill_id]
        grad = update.gradient_vector

        # 크기 불일치 시 리사이즈 / Resize if dimensions mismatch
        if grad.size != local_params.size:
            # 업샘플링 또는 다운샘플링 / Upsample or downsample
            indices = np.linspace(0, grad.size - 1, local_params.size).astype(int)
            grad = grad[indices]

        # SGD 스타일 업데이트 / SGD-style update
        updated = local_params.flatten() - learning_rate * grad
        self._local_skills[update.skill_id] = updated.reshape(local_params.shape)

        with self._lock:
            self._received_updates.append(update)

        logger.info(f"업데이트 적용: {update.skill_id}, from={update.source_robot_id}, "
                     f"lr={learning_rate} / Update applied")
        return True

    def get_local_skill(self, skill_id: str) -> Optional[np.ndarray]:
        """로컬 스킬 파라미터 반환 / Return local skill parameters."""
        return self._local_skills.get(skill_id)

    def get_sharing_stats(self) -> Dict[str, object]:
        """공유 통계 반환 / Return sharing statistics."""
        return {
            "robot_id": self.robot_id,
            "registered_skills": list(self._local_skills.keys()),
            "received_updates": len(self._received_updates),
            "dp_epsilon": self.dp_epsilon,
        }


# ─── CommunicationProtocol / 통신 프로토콜 ───────────────────────────
class CommunicationProtocol:
    """
    스킬 공유를 위한 gRPC 유사 메시지 프로토콜 / gRPC-like message protocol for skill sharing.
    직렬화/역직렬화, 대역폭 추정, 압축 지원.
    Serialize/deserialize, bandwidth estimation, compression support.
    """

    # 메시지 타입 / Message types
    MSG_GRADIENT = 0x01
    MSG_ACK = 0x02
    MSG_REQUEST = 0x03
    MSG_HEARTBEAT = 0x04

    def __init__(self, compression_level: int = COMPRESSION_LEVEL):
        self.compression_level = compression_level
        self._bytes_sent = 0
        self._bytes_received = 0
        self._messages_sent = 0
        self._messages_received = 0
        self._lock = threading.Lock()
        logger.info("CommunicationProtocol 초기화 / Initialized")

    def serialize_update(self, update: SkillGradient) -> bytes:
        """
        스킬 그래디언트를 바이트로 직렬화 (압축 포함)
        Serialize skill gradient to bytes with compression.
        """
        header = {
            "skill_id": update.skill_id,
            "source_robot_id": update.source_robot_id,
            "performance_metrics": update.performance_metrics,
            "timestamp": update.timestamp,
            "version": update.version,
            "num_samples": update.num_samples,
        }
        header_bytes = json.dumps(header).encode("utf-8")
        header_len = len(header_bytes)

        grad_bytes = update.gradient_vector.astype(np.float32).tobytes()
        grad_len = len(grad_bytes)

        # 메시지 포맷: [type(1)] [header_len(4)] [grad_len(4)] [header] [gradient]
        msg_type = struct.pack("B", self.MSG_GRADIENT)
        hl = struct.pack("!I", header_len)
        gl = struct.pack("!I", grad_len)
        raw_message = msg_type + hl + gl + header_bytes + grad_bytes

        # gzip 압축 / Compress with gzip
        compressed = gzip.compress(raw_message, compresslevel=self.compression_level)

        with self._lock:
            self._bytes_sent += len(compressed)
            self._messages_sent += 1

        logger.debug(f"직렬화: {len(raw_message)} → {len(compressed)} 바이트 "
                      f"({1 - len(compressed)/max(1,len(raw_message)):.1%} 압축) / "
                      f"Serialized")
        return compressed

    def deserialize_update(self, data: bytes) -> Optional[SkillGradient]:
        """
        바이트에서 스킬 그래디언트 역직렬화 / Deserialize skill gradient from bytes.
        """
        try:
            # gzip 압축 해제 / Decompress
            raw_message = gzip.decompress(data)

            with self._lock:
                self._bytes_received += len(data)
                self._messages_received += 1

            # 헤더 파싱 / Parse header
            offset = 0
            msg_type = struct.unpack("B", raw_message[offset:offset+1])[0]
            offset += 1

            if msg_type != self.MSG_GRADIENT:
                logger.warning(f"알 수 없는 메시지 타입: {msg_type} / Unknown message type")
                return None

            header_len = struct.unpack("!I", raw_message[offset:offset+4])[0]
            offset += 4
            grad_len = struct.unpack("!I", raw_message[offset:offset+4])[0]
            offset += 4

            header_bytes = raw_message[offset:offset+header_len]
            offset += header_len
            header = json.loads(header_bytes.decode("utf-8"))

            grad_bytes = raw_message[offset:offset+grad_len]
            gradient_vector = np.frombuffer(grad_bytes, dtype=np.float32).copy()

            update = SkillGradient(
                skill_id=header["skill_id"],
                gradient_vector=gradient_vector,
                performance_metrics=header.get("performance_metrics", {}),
                source_robot_id=header["source_robot_id"],
                timestamp=header.get("timestamp", time.time()),
                version=header.get("version", 1),
                num_samples=header.get("num_samples", 0),
            )

            # 체크섬 검증 / Verify checksum
            expected_checksum = hashlib.sha256(gradient_vector.tobytes()).hexdigest()[:16]
            logger.debug(f"역직렬화 완료: {update.skill_id}, checksum={expected_checksum} / "
                          f"Deserialized")
            return update

        except Exception as e:
            logger.error(f"역직렬화 실패: {e} / Deserialization failed")
            return None

    def estimate_transfer_time(self, data_size_bytes: int) -> float:
        """
        전송 시간 추정 (초) / Estimate transfer time in seconds.
        대역폭 추정치 기반 / Based on bandwidth estimate.
        """
        mbps = BANDWIDTH_ESTIMATE_MBPS
        bytes_per_sec = mbps * 1e6 / 8  # MB/s
        return data_size_bytes / max(1, bytes_per_sec)

    def create_ack(self, skill_id: str, success: bool) -> bytes:
        """ACK 메시지 생성 / Create acknowledgment message."""
        payload = json.dumps({"skill_id": skill_id, "success": success}).encode("utf-8")
        msg = struct.pack("B", self.MSG_ACK) + struct.pack("!I", len(payload)) + payload
        compressed = gzip.compress(msg, compresslevel=self.compression_level)
        return compressed

    def create_request(self, skill_ids: List[str]) -> bytes:
        """스킬 요청 메시지 생성 / Create skill request message."""
        payload = json.dumps({"requested_skills": skill_ids}).encode("utf-8")
        msg = struct.pack("B", self.MSG_REQUEST) + struct.pack("!I", len(payload)) + payload
        compressed = gzip.compress(msg, compresslevel=self.compression_level)
        return compressed

    def get_stats(self) -> Dict[str, object]:
        """통신 통계 반환 / Return communication statistics."""
        with self._lock:
            return {
                "bytes_sent": self._bytes_sent,
                "bytes_received": self._bytes_received,
                "messages_sent": self._messages_sent,
                "messages_received": self._messages_received,
                "avg_msg_size_sent": (self._bytes_sent / max(1, self._messages_sent)),
                "avg_msg_size_received": (self._bytes_received / max(1, self._messages_received)),
                "compression_level": self.compression_level,
                "bandwidth_mbps": BANDWIDTH_ESTIMATE_MBPS,
            }


# ─── Module-level demo / 모듈 레벨 데모 ──────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    # 연합 집계 데모 / Federated aggregation demo
    aggregator = FederatedAggregator(db_path=":memory:")

    # 3개 로봇에서 온 그래디언트 생성 / Generate gradients from 3 robots
    skill_id = "grasping_skill_v1"
    gradients = []
    for i in range(3):
        grad = SkillGradient(
            skill_id=skill_id,
            gradient_vector=np.random.randn(1000).astype(np.float32),
            performance_metrics={"accuracy": 0.7 + 0.1 * i, "loss": 0.5 - 0.05 * i},
            source_robot_id=f"robot_{i}",
            num_samples=100 * (i + 1),
        )
        gradients.append(grad)
        aggregator.store_gradient(grad)

    # FedAvg / 연합 평균
    avg_result = aggregator.fed_avg(gradients)
    if avg_result:
        logger.info(f"FedAvg: checksum={avg_result.checksum}, samples={avg_result.num_samples}")

    # FedProx / 근접 연합
    prox_result = aggregator.fed_prox(gradients, proximal_term=0.01)
    if prox_result:
        logger.info(f"FedProx: checksum={prox_result.checksum}")

    # Trimmed Mean / 절삭 평균
    # 이상치 추가 / Add outliers
    outlier_grad = SkillGradient(
        skill_id=skill_id,
        gradient_vector=np.random.randn(1000).astype(np.float32) * 10,  # 큰 노이즈 / Large noise
        performance_metrics={"accuracy": 0.1, "loss": 2.0},
        source_robot_id="robot_faulty",
        num_samples=10,
    )
    all_grads = gradients + [outlier_grad]
    trimmed_result = aggregator.trimmed_mean(all_grads)
    if trimmed_result:
        logger.info(f"TrimmedMean: checksum={trimmed_result.checksum}")

    # 클라이언트 데모 / Client demo
    client = SkillSharingClient("robot_alpha", aggregator)
    client.register_skill(skill_id, np.random.randn(1000).astype(np.float32))
    update = client.prepare_update(skill_id, {"accuracy": 0.85})
    if update:
        logger.info(f"준비된 업데이트: size={update.size_bytes} bytes, ε={DP_EPSILON}")

    # 통신 프로토콜 데모 / Communication protocol demo
    protocol = CommunicationProtocol()
    if update:
        serialized = protocol.serialize_update(update)
        deserialized = protocol.deserialize_update(serialized)
        if deserialized:
            logger.info(f"직렬화/역직렬화 성공: {deserialized.skill_id} / "
                         f"Serialization roundtrip OK")
            transfer_time = protocol.estimate_transfer_time(len(serialized))
            logger.info(f"예상 전송 시간: {transfer_time*1000:.1f}ms / "
                         f"Estimated transfer time")

    stats = protocol.get_stats()
    logger.info(f"통신 통계: {stats} / Communication stats")
    logger.info("federated_skill_sharing.py 데모 완료 / Demo complete")
