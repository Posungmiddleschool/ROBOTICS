#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — 카메라 마운트 제어 (Camera Mount Control)
=========================================================

OAK-D Pro → MG996R 서보 틸트 ±45° + 엄지스크류 수동 조절
USB-C 케이블 출구: 6mm×3mm 슬롯 (V6 추가)

아키텍처 / Architecture:
  - OAK-D Pro: 90×25×23mm (V6 수정 치수)
  - MG996R 서보: 틸트 제어 ±45° 범위
  - 엄지스크류: 수동 미세 조절 (도구 불필요)
  - USB-C 케이블: 6mm×3mm 슬롯 통과
  - 추적 모드: 감지된 물체 자동 추적

물리 파라미터 / Physical Parameters:
  - OAK-D Pro 치수: 90×25×23mm
  - 틸트 범위: -45° ~ +45°
  - 팬 (수동): 360° 엄지스크류 조절
  - 진동 허용: 틸트 각도 유지 시 흔들림 없음

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V8.5.CameraMount")

# ============================================================================
# 상수 정의 (Constants)
# ============================================================================

# OAK-D Pro 카메라 파라미터 / OAK-D Pro camera parameters
OAKD_MODEL: str = "OAK-D Pro"
OAKD_DIMENSIONS_MM: Tuple[float, float, float] = (90.0, 25.0, 23.0)  # V6 수정
OAKD_USB_CABLE_SLOT_MM: Tuple[float, float] = (6.0, 3.0)             # V6 추가
OAKD_WEIGHT_G: float = 65.0           # 카메라 무게 / Camera weight

# 틸트 범위 / Tilt range
TILT_MIN_DEG: float = -45.0           # 최대 하향 / Max downward tilt
TILT_MAX_DEG: float = 45.0            # 최대 상향 / Max upward tilt
TILT_NEUTRAL_DEG: float = 0.0         # 중립 (수평) / Neutral (horizontal)
TILT_SPEED_DEFAULT_DEG_S: float = 45.0  # 기본 틸트 속도
TILT_SPEED_FAST_DEG_S: float = 90.0     # 빠른 틸트 속도
TILT_SPEED_TRACKING_DEG_S: float = 30.0 # 추적 모드 속도

# 진동 댐핑 / Vibration damping
VIBRATION_THRESHOLD_DEG: float = 0.5   # 진동 감지 임계값
DAMPING_SETTLE_TIME_S: float = 0.3     # 댐핑 안정 시간

# 추적 모드 / Tracking mode
TRACKING_UPDATE_HZ: float = 10.0       # 추적 업데이트 주파수
TRACKING_DEADZONE_PX: int = 50         # 추적 데드존 (픽셀)
TRACKING_SMOOTH_ALPHA: float = 0.3     # 추적 스무딩 계수

# 서보 핀 / Servo pin
TILT_SERVO_PIN: int = 24               # GPIO_24 (카메라 틸트 서보)
TILT_SERVO_NAME: str = "camera_tilt"

# 안전 / Safety
TILT_OVERTRAVEL_MARGIN_DEG: float = 2.0  # 과이동 마진
MAX_CONTINUOUS_TILT_TIME_S: float = 30.0  # 연속 틸트 최대 시간


# ============================================================================
# 열거형 (Enumerations)
# ============================================================================

class MountState(Enum):
    """마운트 상태 / Mount state"""
    IDLE = "idle"               # 대기 (현재 각도 유지)
    TILTING = "tilting"         # 틸트 이동 중
    STABILIZING = "stabilizing" # 진동 안정화 중
    TRACKING = "tracking"       # 물체 추적 중
    MANUAL = "manual"           # 수동 조절 모드 (엄지스크류)
    FAULT = "fault"             # 오류


class TrackingStatus(Enum):
    """추적 상태 / Tracking status"""
    INACTIVE = "inactive"        # 비활성
    SEARCHING = "searching"      # 물체 탐색 중
    LOCKED = "locked"           # 물체 잠금
    LOST = "lost"               # 물체 상실
    OUT_OF_RANGE = "out_of_range"  # 범위 밖


# ============================================================================
# 데이터 클래스 (Data Classes)
# ============================================================================

@dataclass
class CameraMountState:
    """카메라 마운트 상태 데이터 / Camera mount state data"""
    tilt_angle_deg: float = TILT_NEUTRAL_DEG
    pan_angle_deg: float = 0.0          # 수동 팬 (엄지스크류)
    mount_state: MountState = MountState.IDLE
    tracking_status: TrackingStatus = TrackingStatus.INACTIVE
    tracking_target: Optional[str] = None   # 추적 중인 물체명
    vibration_deg: float = 0.0          # 현재 진동량
    is_stable: bool = True              # 진동 안정 여부
    timestamp: float = field(default_factory=time.monotonic)


@dataclass
class TrackingTarget:
    """추적 대상 정보 / Tracking target information"""
    label: str = ""                     # 물체 레이블
    bbox_center_x: float = 0.0          # 바운딩박스 중심 X (px)
    bbox_center_y: float = 0.0          # 바운딩박스 중심 Y (px)
    confidence: float = 0.0             # 탐지 신뢰도
    depth_mm: float = 0.0              # 깊이 (mm)
    frame_width: int = 640              # 프레임 너비
    frame_height: int = 400             # 프레임 높이
    timestamp: float = field(default_factory=time.monotonic)


# ============================================================================
# CameraMount 클래스
# ============================================================================

class CameraMount:
    """
    카메라 마운트 제어 클래스 / Camera Mount Control Class.

    OAK-D Pro 카메라의 틸트 서보 제어 및 물체 추적 모드 지원.

    Features:
    - MG996R 서보 틸트 ±45° 제어
    - 엄지스크류 수동 팬 조절 (기록만)
    - 진동 댐핑: 틸트 후 안정화 대기
    - 추적 모드: 감지된 물체를 프레임 중앙에 유지
    - OAK-D Pro 실제 치수 반영 (90×25×23mm)

    Usage:
        mount = CameraMount()
        mount.set_tilt_angle(30.0)           # 30° 상향
        mount.set_pan(15.0)                  # 팬 기록 (수동 조절)
        mount.stabilize()                    # 진동 안정화 대기
        mount.start_tracking("red_cup")      # 빨간 컵 추적 시작
        mount.stop_tracking()                # 추적 중지
    """

    def __init__(
        self,
        simulation_mode: bool = True,
        servo_controller: Optional[Any] = None,
    ):
        """
        카메라 마운트 초기화 / Initialize camera mount.

        Args:
            simulation_mode: 시뮬레이션 모드
            servo_controller: ServoController 인스턴스 (선택적)
        """
        self._simulation = simulation_mode
        self._servo_ctrl = servo_controller
        self._lock = threading.Lock()

        # 마운트 상태 / Mount state
        self._state = CameraMountState()
        self._current_tilt: float = TILT_NEUTRAL_DEG
        self._current_pan: float = 0.0

        # 진동 댐핑 / Vibration damping
        self._tilt_history: List[float] = []
        self._last_tilt_time: float = 0.0

        # 추적 모드 / Tracking mode
        self._tracking_enabled: bool = False
        self._tracking_target_label: Optional[str] = None
        self._tracking_thread: Optional[threading.Thread] = None
        self._tracking_running: bool = False
        self._detection_callback: Optional[Callable] = None
        self._latest_target: Optional[TrackingTarget] = None
        self._tilt_command_callback: Optional[Callable] = None

        # 서보 컨트롤러 초기화 / Initialize servo controller
        if self._servo_ctrl is None:
            self._init_servo()

        logger.info("CameraMount 초기화 완료 / Init complete "
                     f"(OAK-D Pro {OAKD_DIMENSIONS_MM}, sim={simulation_mode})")

    def _init_servo(self) -> None:
        """서보 컨트롤러 지연 초기화 / Lazy-init servo controller."""
        try:
            from .servo_controller import ServoController
            self._servo_ctrl = ServoController(simulation_mode=self._simulation)
            self._servo_ctrl.register_channel(
                TILT_SERVO_NAME, TILT_SERVO_PIN,
                min_angle_deg=TILT_MIN_DEG + 90,   # 서보 0°=틸트 -45°
                max_angle_deg=TILT_MAX_DEG + 90,    # 서보 180°=틸트 +45°
            )
        except (ImportError, Exception) as e:
            logger.warning(f"서보 컨트롤러 초기화 실패: {e}")
            self._simulation = True

    # ── 틸트 제어 / Tilt Control ──

    def set_tilt_angle(self, angle_deg: float,
                       speed_deg_s: Optional[float] = None) -> bool:
        """
        틸트 각도 설정 / Set tilt angle.

        카메라 상하 각도 조정.
        -45°(하향) ~ +45°(상향) 범위.

        Args:
            angle_deg: 틸트 각도 (°), 음수=하향, 양수=상향
            speed_deg_s: 이동 속도 (°/s)

        Returns:
            명령 성공 여부
        """
        # 각도 범위 클램핑 / Clamp angle range
        angle_deg = max(TILT_MIN_DEG, min(TILT_MAX_DEG, angle_deg))

        with self._lock:
            self._current_tilt = angle_deg
            self._state.tilt_angle_deg = angle_deg
            self._state.mount_state = MountState.TILTING
            self._last_tilt_time = time.monotonic()

            # 서보 명령 전송 / Send servo command
            # 틸트 각도 → 서보 각도 변환: tilt -45° → servo 45°, tilt 0° → servo 90°
            servo_angle = angle_deg + 90.0
            if self._servo_ctrl:
                self._servo_ctrl.set_angle(
                    TILT_SERVO_NAME, servo_angle,
                    speed_deg_s=speed_deg_s or TILT_SPEED_DEFAULT_DEG_S
                )

            # 틸트 히스토리 기록 (진동 감지용) / Record tilt history
            self._tilt_history.append(angle_deg)
            if len(self._tilt_history) > 100:
                self._tilt_history = self._tilt_history[-50:]

            logger.debug(f"카메라 틸트 설정: {angle_deg:.1f}°")
            return True

    def get_tilt(self) -> float:
        """
        현재 틸트 각도 조회 / Get current tilt angle.

        Returns:
            틸트 각도 (°)
        """
        with self._lock:
            return self._state.tilt_angle_deg

    # ── 팬 제어 (수동) / Pan Control (Manual) ──

    def set_pan(self, angle_deg: float) -> bool:
        """
        팬 각도 기록 / Record pan angle.

        팬은 엄지스크류로 수동 조절됨.
        이 메서드는 현재 팬 각도를 기록만 함.

        Args:
            angle_deg: 팬 각도 (°)

        Returns:
            기록 성공 여부
        """
        with self._lock:
            self._current_pan = angle_deg
            self._state.pan_angle_deg = angle_deg
            self._state.mount_state = MountState.MANUAL

        logger.debug(f"카메라 팬 기록: {angle_deg:.1f}° (수동 조절)")
        return True

    # ── 진동 안정화 / Vibration Stabilization ──

    def stabilize(self, timeout_s: float = 1.0) -> bool:
        """
        진동 안정화 대기 / Wait for vibration stabilization.

        틸트 이동 후 진동이 잠잠해질 때까지 대기.
        안정화 후 HOLDING 상태로 전환.

        Args:
            timeout_s: 최대 대기 시간 (초)

        Returns:
            안정화 성공 여부 (True=안정, False=타임아웃)
        """
        self._state.mount_state = MountState.STABILIZING
        start_time = time.monotonic()

        # 진동 댐핑 대기 / Wait for vibration damping
        while time.monotonic() - start_time < timeout_s:
            # 최근 틸트 변화량 확인 / Check recent tilt changes
            if len(self._tilt_history) >= 2:
                recent_change = abs(
                    self._tilt_history[-1] - self._tilt_history[-2]
                )
                self._state.vibration_deg = recent_change
                self._state.is_stable = recent_change < VIBRATION_THRESHOLD_DEG

                if self._state.is_stable:
                    self._state.mount_state = MountState.IDLE
                    logger.debug("카메라 안정화 완료 / Stabilized")
                    return True

            time.sleep(0.05)

        # 타임아웃 / Timeout
        self._state.is_stable = True  # 강제 안정
        self._state.mount_state = MountState.IDLE
        logger.debug("안정화 타임아웃 — 강제 안정 / Force stabilized")
        return False

    # ── 추적 모드 / Tracking Mode ──

    def start_tracking(self, target_label: Optional[str] = None) -> bool:
        """
        물체 추적 모드 시작 / Start object tracking mode.

        감지된 물체를 프레임 중앙에 유지하도록 틸트 자동 조정.

        Args:
            target_label: 추적할 물체 레이블 (None=첫 감지 물체)

        Returns:
            추적 시작 성공 여부
        """
        if self._tracking_enabled:
            return True

        self._tracking_enabled = True
        self._tracking_target_label = target_label
        self._tracking_running = True
        self._state.mount_state = MountState.TRACKING
        self._state.tracking_status = TrackingStatus.SEARCHING

        # 추적 스레드 시작 / Start tracking thread
        self._tracking_thread = threading.Thread(
            target=self._tracking_loop, daemon=True,
            name="CameraTracking"
        )
        self._tracking_thread.start()

        logger.info(f"추적 모드 시작 / Tracking started: "
                     f"target={target_label or 'auto'}")
        return True

    def stop_tracking(self) -> bool:
        """
        물체 추적 모드 중지 / Stop object tracking mode.

        Returns:
            중지 성공 여부
        """
        self._tracking_enabled = False
        self._tracking_running = False
        self._state.tracking_status = TrackingStatus.INACTIVE
        self._state.tracking_target = None

        if self._state.mount_state == MountState.TRACKING:
            self._state.mount_state = MountState.IDLE

        logger.info("추적 모드 중지 / Tracking stopped")
        return True

    def _tracking_loop(self) -> None:
        """물체 추적 루프 / Object tracking loop."""
        dt = 1.0 / TRACKING_UPDATE_HZ

        while self._tracking_running:
            try:
                # 감지 결과 획득 / Get detection result
                target = self._get_latest_target()
                if target is None:
                    self._state.tracking_status = TrackingStatus.SEARCHING
                    time.sleep(dt)
                    continue

                # 레이블 필터링 / Filter by label
                if (self._tracking_target_label and
                        target.label != self._tracking_target_label):
                    self._state.tracking_status = TrackingStatus.SEARCHING
                    time.sleep(dt)
                    continue

                # 프레임 중앙에서 벗어난 정도 계산 / Calculate offset from frame center
                center_x = target.frame_width / 2.0
                center_y = target.frame_height / 2.0
                offset_y = target.bbox_center_y - center_y

                # 데드존 내면 무시 / Ignore if within deadzone
                if abs(offset_y) < TRACKING_DEADZONE_PX:
                    self._state.tracking_status = TrackingStatus.LOCKED
                    self._state.tracking_target = target.label
                    time.sleep(dt)
                    continue

                # 오프셋 → 틸트 각도 보정 / Offset → tilt angle correction
                # 픽셀 오프셋을 각도로 근사 변환
                fov_vertical_deg = 55.0  # OAK-D Pro 수직 FOV
                pixel_per_deg = target.frame_height / fov_vertical_deg
                tilt_correction = offset_y / pixel_per_deg * TRACKING_SMOOTH_ALPHA

                # 틸트 각도 업데이트 / Update tilt angle
                new_tilt = self._current_tilt + tilt_correction
                new_tilt = max(TILT_MIN_DEG, min(TILT_MAX_DEG, new_tilt))
                self.set_tilt_angle(new_tilt, speed_deg_s=TILT_SPEED_TRACKING_DEG_S)

                self._state.tracking_status = TrackingStatus.LOCKED
                self._state.tracking_target = target.label

            except Exception as e:
                logger.error(f"추적 루프 오류: {e}")
                self._state.tracking_status = TrackingStatus.LOST

            time.sleep(dt)

    def _get_latest_target(self) -> Optional[TrackingTarget]:
        """최신 감지 대상 획득 / Get latest detected target."""
        # 실제 구현에서는 YOLO-World 검출 결과 수신
        # 실제 구현은 visual_servoing.py와 연동
        return self._latest_target

    def update_tracking_target(self, target: TrackingTarget) -> None:
        """
        추적 대상 업데이트 / Update tracking target.

        YOLO-World 또는 Visual Servoing에서 호출.

        Args:
            target: TrackingTarget 인스턴스
        """
        self._latest_target = target

    # ── 상태 조회 / State Query ──

    def get_state(self) -> CameraMountState:
        """
        마운트 상태 조회 / Get mount state.

        Returns:
            CameraMountState 전체 상태
        """
        with self._lock:
            self._state.timestamp = time.monotonic()
            return self._state

    def get_tilt_diagnostics(self) -> Dict[str, Any]:
        """
        틸트 진단 정보 / Get tilt diagnostics.

        Returns:
            진단 딕셔너리
        """
        state = self.get_state()
        return {
            "current_tilt_deg": round(state.tilt_angle_deg, 2),
            "current_pan_deg": round(state.pan_angle_deg, 2),
            "mount_state": state.mount_state.value,
            "tracking_status": state.tracking_status.value,
            "tracking_target": state.tracking_target,
            "is_stable": state.is_stable,
            "vibration_deg": round(state.vibration_deg, 3),
            "oakd_dimensions_mm": list(OAKD_DIMENSIONS_MM),
            "usb_cable_slot_mm": list(OAKD_USB_CABLE_SLOT_MM),
        }

    # ── 정리 / Cleanup ──

    def close(self) -> None:
        """카메라 마운트 종료 / Close camera mount."""
        self.stop_tracking()

        # 틸트를 중립으로 복귀 / Return tilt to neutral
        self.set_tilt_angle(TILT_NEUTRAL_DEG)

        # 서보 비활성화 / Disable servo
        if self._servo_ctrl and not isinstance(self._servo_ctrl, type(None)):
            self._servo_ctrl.disable(TILT_SERVO_NAME)

        logger.info("CameraMount 종료 / Shutdown complete")
