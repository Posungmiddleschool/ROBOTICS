#!/usr/bin/env python3
"""
multi_robot.py — 다중 로봇 메시 네트워크 모듈
================================================

지훈 로봇 V8.5 Physical AGI — 멀티로봇 협력 메시 네트워크

핵심 아키텍처:
  - UDP 멀티캐스트: 피어 자동 발견 (Discovery)
  - TCP: 신뢰성 메시지 전달 (Reliable Message Passing)
  - 하트비트 모니터링: 피어 생존 감시 및 자동 제거
  - 작업 경매 프로토콜: Task Auction (LEADER → FOLLOWER/WORKER 분배)
  - 연합 학습 조정: Federated Learning Round 오케스트레이션
  - 네트워크 장애 복구: 자동 재연결, 메시 재구성

프로토콜 스택:
  ┌─────────────────────────────────────┐
  │  Federated Learning Coordination    │
  ├─────────────────────────────────────┤
  │  Task Auction Protocol              │
  ├─────────────────────────────────────┤
  │  Reliable Message Passing (TCP)     │
  ├─────────────────────────────────────┤
  │  Peer Discovery (UDP Multicast)     │
  └─────────────────────────────────────┘

작성일: 2026-05-22
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import hashlib
import json
import logging
import pickle
import queue
import socket
import struct
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ============================================================================
# 상수 / Constants
# ============================================================================

# UDP 멀티캐스트 (피어 발견)
MULTICAST_GROUP = "239.255.0.100"
MULTICAST_PORT = 19883
DISCOVERY_INTERVAL_S = 2.0           # 발견 브로드캐스트 주기
DISCOVERY_TIMEOUT_S = 10.0           # 피어 타임아웃

# TCP 메시지 전달
TCP_PORT = 19884
TCP_BACKLOG = 8
TCP_RECV_BUF = 65536
MESSAGE_MAX_SIZE = 10 * 1024 * 1024  # 10MB

# 하트비트
HEARTBEAT_INTERVAL_S = 1.0           # 하트비트 전송 주기
HEARTBEAT_TIMEOUT_S = 5.0            # 하트비트 수신 타임아웃
PEER_LIVENESS_THRESHOLD = 3          # 연속 누락 허용 횟수

# 작업 경매
AUCTION_TIMEOUT_S = 5.0              # 경매 입찰 대기 시간
MAX_TASK_RETRIES = 3                 # 작업 최대 재시도 횟수

# 연합 학습
FED_ROUND_TIMEOUT_S = 60.0           # 연합 학습 라운드 타임아웃
FED_MIN_CLIENTS = 2                  # 최소 집계 클라이언트 수
FED_AGGREGATION_METHOD = "fed_avg"   # 기본 집계 방식

# 메시 프로토콜 버전
PROTOCOL_VERSION = 1


# ============================================================================
# 열거형 / Enums
# ============================================================================

class RobotRole(Enum):
    """로봇 역할 — 메시 네트워크 내 역할 분담"""
    LEADER = "leader"         # 작업 분배, 연합 학습 조정, 메시 관리
    FOLLOWER = "follower"     # 리더 지시 수행, 작업 실행
    SCOUT = "scout"           # 환경 정찰, 미지 영역 탐색
    WORKER = "worker"         # 물리적 작업 수행 (파지, 이동, 조립)
    RELAY = "relay"           # 통신 중계, 메시 홉 확장


class MessageType(IntEnum):
    """메시 프로토콜 메시지 타입"""
    DISCOVERY_ANNOUNCE = 0x01
    DISCOVERY_RESPONSE = 0x02
    HEARTBEAT = 0x03
    HEARTBEAT_ACK = 0x04
    TASK_ANNOUNCE = 0x10
    TASK_BID = 0x11
    TASK_ASSIGN = 0x12
    TASK_RESULT = 0x13
    TASK_RETRY = 0x14
    MESSAGE_UNICAST = 0x20
    MESSAGE_BROADCAST = 0x21
    FED_ROUND_START = 0x30
    FED_GRADIENT_SUBMIT = 0x31
    FED_AGGREGATED_MODEL = 0x32
    FED_ROUND_COMPLETE = 0x33
    ROLE_CHANGE = 0x40
    MESH_RECONFIG = 0x41
    EMERGENCY_STOP = 0xF0


class TaskStatus(IntEnum):
    """작업 상태"""
    PENDING = 0
    AUCTIONING = 1
    ASSIGNED = 2
    IN_PROGRESS = 3
    COMPLETED = 4
    FAILED = 5
    TIMEOUT = 6


class MeshState(Enum):
    """메시 네트워크 상태"""
    INITIALIZING = "initializing"
    DISCOVERING = "discovering"
    ACTIVE = "active"
    DEGRADED = "degraded"
    ISOLATED = "isolated"
    SHUTTING_DOWN = "shutting_down"


# ============================================================================
# 데이터 클래스 / Data Classes
# ============================================================================

@dataclass
class PeerInfo:
    """피어 로봇 정보"""
    robot_id: str
    role: RobotRole = RobotRole.FOLLOWER
    ip_address: str = ""
    tcp_port: int = TCP_PORT
    capabilities: Dict[str, Any] = field(default_factory=dict)
    last_heartbeat: float = 0.0
    missed_heartbeats: int = 0
    is_alive: bool = True
    latency_ms: float = 0.0
    load_factor: float = 0.0          # 0.0~1.0 현재 부하
    battery_soc: float = 1.0          # 0.0~1.0 배터리 잔량

    @property
    def fitness_score(self) -> float:
        """작업 할당 적합도 (높을수록 적합) — 부하↓ 배터리↑ 지연↓"""
        return max(0.0, (1.0 - self.load_factor) * self.battery_soc
                   * max(0.1, 1.0 - self.latency_ms / 1000.0))


@dataclass
class MeshMessage:
    """메시 프로토콜 메시지"""
    msg_type: MessageType
    sender_id: str
    timestamp: float = field(default_factory=time.time)
    msg_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    payload: Dict[str, Any] = field(default_factory=dict)
    target_id: Optional[str] = None   # None = broadcast

    def serialize(self) -> bytes:
        """메시지 직렬화 — [버전(1)][타입(1)][길이(4)][JSON 페이로드]"""
        data = {
            "msg_type": int(self.msg_type),
            "sender_id": self.sender_id,
            "timestamp": self.timestamp,
            "msg_id": self.msg_id,
            "payload": self.payload,
            "target_id": self.target_id,
        }
        json_bytes = json.dumps(data, default=str).encode("utf-8")
        header = struct.pack("!BBI", PROTOCOL_VERSION, int(self.msg_type), len(json_bytes))
        return header + json_bytes

    @classmethod
    def deserialize(cls, data: bytes) -> Optional["MeshMessage"]:
        """메시지 역직렬화"""
        try:
            if len(data) < 6:
                return None
            version, msg_type_val, length = struct.unpack("!BBI", data[:6])
            if version != PROTOCOL_VERSION:
                logger.warning("프로토콜 버전 불일치: %d != %d", version, PROTOCOL_VERSION)
                return None
            json_bytes = data[6:6 + length]
            if len(json_bytes) < length:
                return None
            d = json.loads(json_bytes.decode("utf-8"))
            return cls(
                msg_type=MessageType(d["msg_type"]),
                sender_id=d["sender_id"],
                timestamp=d.get("timestamp", 0.0),
                msg_id=d.get("msg_id", ""),
                payload=d.get("payload", {}),
                target_id=d.get("target_id"),
            )
        except (struct.error, json.JSONDecodeError, ValueError, KeyError) as e:
            logger.warning("메시지 역직렬화 실패: %s", e)
            return None


@dataclass
class AuctionTask:
    """경매 작업"""
    task_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    task_type: str = ""
    description: str = ""
    priority: int = 5                 # 1(최고)~10(최저)
    required_capabilities: List[str] = field(default_factory=list)
    parameters: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    assigned_to: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    created_at: float = field(default_factory=time.time)
    deadline: float = 0.0
    retry_count: int = 0

    def __post_init__(self):
        if self.deadline == 0.0:
            self.deadline = self.created_at + AUCTION_TIMEOUT_S * 3


@dataclass
class FederatedRound:
    """연합 학습 라운드"""
    round_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    round_number: int = 0
    skill_id: str = ""
    model_checksum: str = ""
    gradients: Dict[str, Any] = field(default_factory=dict)  # robot_id → gradient data
    started_at: float = field(default_factory=time.time)
    completed_at: float = 0.0
    min_clients: int = FED_MIN_CLIENTS
    timeout: float = FED_ROUND_TIMEOUT_S
    status: str = "pending"           # pending, collecting, aggregating, completed, failed


# ============================================================================
# UDP 멀티캐스트 발견 엔진
# ============================================================================

class DiscoveryEngine:
    """
    UDP 멀티캐스트 기반 피어 자동 발견

    동작:
      1. 주기적으로 MULTICAST_GROUP에 자신의 정보 브로드캐스트
      2. 다른 로봇의 발견 메시지 수신 시 피어 테이블 갱신
      3. DISCOVERY_TIMEOUT_S 동안 하트비트 없는 피어는 제거
    """

    def __init__(self, robot_id: str, role: RobotRole, tcp_port: int = TCP_PORT,
                 capabilities: Optional[Dict[str, Any]] = None):
        self._robot_id = robot_id
        self._role = role
        self._tcp_port = tcp_port
        self._capabilities = capabilities or {}
        self._peers: Dict[str, PeerInfo] = {}
        self._lock = threading.Lock()
        self._running = False
        self._send_sock: Optional[socket.socket] = None
        self._recv_sock: Optional[socket.socket] = None
        self._threads: List[threading.Thread] = []

    def start(self) -> bool:
        """발견 엔진 시작 — 송수신 소켓 생성 + 스레드 시작"""
        try:
            # 송신 소켓 (멀티캐스트 전송)
            self._send_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            self._send_sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            self._send_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            # 수신 소켓 (멀티캐스트 수신)
            self._recv_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            self._recv_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._recv_sock.bind(("", MULTICAST_PORT))

            # 멀티캐스트 그룹 가입
            mreq = struct.pack("4s4s",
                                socket.inet_aton(MULTICAST_GROUP),
                                socket.inet_aton("0.0.0.0"))
            self._recv_sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            self._recv_sock.settimeout(1.0)

            self._running = True

            # 발견 브로드캐스트 스레드
            t_send = threading.Thread(target=self._broadcast_loop, daemon=True,
                                      name="Discovery-Broadcast")
            t_send.start()
            self._threads.append(t_send)

            # 발견 수신 스레드
            t_recv = threading.Thread(target=self._receive_loop, daemon=True,
                                      name="Discovery-Receive")
            t_recv.start()
            self._threads.append(t_recv)

            # 피어 타임아웃 감시 스레드
            t_watch = threading.Thread(target=self._peer_watchdog_loop, daemon=True,
                                       name="Discovery-Watchdog")
            t_watch.start()
            self._threads.append(t_watch)

            logger.info("DiscoveryEngine 시작 — 멀티캐스트 %s:%d",
                        MULTICAST_GROUP, MULTICAST_PORT)
            return True

        except Exception as e:
            logger.error("DiscoveryEngine 시작 실패: %s", e)
            self.stop()
            return False

    def stop(self):
        """발견 엔진 정지"""
        self._running = False
        for sock in (self._send_sock, self._recv_sock):
            if sock:
                try:
                    sock.close()
                except OSError:
                    pass
        self._send_sock = None
        self._recv_sock = None
        logger.info("DiscoveryEngine 정지")

    def get_peers(self) -> Dict[str, PeerInfo]:
        """현재 피어 테이블 반환"""
        with self._lock:
            return {k: PeerInfo(**{f: getattr(v, f) for f in v.__dataclass_fields__})
                    for k, v in self._peers.items()}

    def update_role(self, role: RobotRole):
        """자신의 역할 변경"""
        self._role = role

    def _build_announce_payload(self) -> Dict[str, Any]:
        """발견 브로드캐스트 페이로드 생성"""
        return {
            "robot_id": self._robot_id,
            "role": self._role.value,
            "tcp_port": self._tcp_port,
            "capabilities": self._capabilities,
            "load_factor": 0.0,
            "battery_soc": 1.0,
        }

    def _broadcast_loop(self):
        """주기적 발견 브로드캐스트"""
        while self._running:
            try:
                msg = MeshMessage(
                    msg_type=MessageType.DISCOVERY_ANNOUNCE,
                    sender_id=self._robot_id,
                    payload=self._build_announce_payload(),
                )
                data = msg.serialize()
                self._send_sock.sendto(data, (MULTICAST_GROUP, MULTICAST_PORT))
            except Exception as e:
                if self._running:
                    logger.warning("발견 브로드캐스트 전송 오류: %s", e)
            time.sleep(DISCOVERY_INTERVAL_S)

    def _receive_loop(self):
        """발견 메시지 수신"""
        while self._running:
            try:
                data, addr = self._recv_sock.recvfrom(8192)
                msg = MeshMessage.deserialize(data)
                if msg is None:
                    continue
                if msg.msg_type == MessageType.DISCOVERY_ANNOUNCE:
                    self._handle_announce(msg, addr)
                elif msg.msg_type == MessageType.DISCOVERY_RESPONSE:
                    self._handle_announce(msg, addr)
            except socket.timeout:
                continue
            except OSError:
                if self._running:
                    logger.warning("발견 수신 소켓 오류")
                break
            except Exception as e:
                if self._running:
                    logger.warning("발견 수신 오류: %s", e)

    def _handle_announce(self, msg: MeshMessage, addr: Tuple):
        """발견 메시지 처리 — 피어 테이블 갱신"""
        payload = msg.payload
        rid = payload.get("robot_id", "")
        if not rid or rid == self._robot_id:
            return

        with self._lock:
            if rid in self._peers:
                # 기존 피어 정보 갱신
                peer = self._peers[rid]
                peer.role = RobotRole(payload.get("role", "follower"))
                peer.ip_address = addr[0]
                peer.tcp_port = payload.get("tcp_port", TCP_PORT)
                peer.last_heartbeat = time.time()
                peer.missed_heartbeats = 0
                peer.is_alive = True
                peer.capabilities = payload.get("capabilities", {})
                peer.load_factor = payload.get("load_factor", 0.0)
                peer.battery_soc = payload.get("battery_soc", 1.0)
            else:
                # 새 피어 등록
                peer = PeerInfo(
                    robot_id=rid,
                    role=RobotRole(payload.get("role", "follower")),
                    ip_address=addr[0],
                    tcp_port=payload.get("tcp_port", TCP_PORT),
                    capabilities=payload.get("capabilities", {}),
                    last_heartbeat=time.time(),
                    missed_heartbeats=0,
                    is_alive=True,
                    load_factor=payload.get("load_factor", 0.0),
                    battery_soc=payload.get("battery_soc", 1.0),
                )
                self._peers[rid] = peer
                logger.info("새 피어 발견: %s (역할=%s, IP=%s)",
                            rid, peer.role.value, peer.ip_address)

    def _peer_watchdog_loop(self):
        """피어 타임아웃 감시 — DISCOVERY_TIMEOUT_S 초과 시 제거"""
        while self._running:
            now = time.time()
            with self._lock:
                dead_peers = []
                for rid, peer in self._peers.items():
                    elapsed = now - peer.last_heartbeat
                    if elapsed > DISCOVERY_TIMEOUT_S:
                        peer.missed_heartbeats += 1
                        if peer.missed_heartbeats > PEER_LIVENESS_THRESHOLD:
                            peer.is_alive = False
                            dead_peers.append(rid)
                            logger.warning("피어 타임아웃: %s (%.1f초 누락)", rid, elapsed)
                    else:
                        peer.missed_heartbeats = 0
                        peer.is_alive = True

                for rid in dead_peers:
                    del self._peers[rid]
                    logger.info("피어 제거: %s", rid)

            time.sleep(DISCOVERY_INTERVAL_S)

    @property
    def peer_count(self) -> int:
        with self._lock:
            return sum(1 for p in self._peers.values() if p.is_alive)


# ============================================================================
# TCP 메시지 전달 엔진
# ============================================================================

class MessageEngine:
    """
    TCP 기반 신뢰성 메시지 전달

    기능:
      - 유니캐스트: 특정 피어에게 직접 전송
      - 브로드캐스트: 모든 피어에게 전송
      - 수신 서버: 다른 로봇의 연결 수락
      - 재시도: 전송 실패 시 자동 재시도
    """

    def __init__(self, robot_id: str, port: int = TCP_PORT):
        self._robot_id = robot_id
        self._port = port
        self._running = False
        self._server_sock: Optional[socket.socket] = None
        self._incoming_queue: queue.Queue = queue.Queue(maxsize=1000)
        self._message_handlers: Dict[MessageType, List[Callable]] = {}
        self._send_lock = threading.Lock()
        self._threads: List[threading.Thread] = []
        self._stats = {"sent": 0, "received": 0, "failed": 0, "retried": 0}

    def start(self) -> bool:
        """메시지 엔진 시작 — TCP 서버 리슨 + 수신 스레드"""
        try:
            self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_sock.bind(("0.0.0.0", self._port))
            self._server_sock.listen(TCP_BACKLOG)
            self._server_sock.settimeout(1.0)
            self._running = True

            # 연결 수락 스레드
            t_accept = threading.Thread(target=self._accept_loop, daemon=True,
                                        name="MessageEngine-Accept")
            t_accept.start()
            self._threads.append(t_accept)

            # 수신 처리 스레드
            t_dispatch = threading.Thread(target=self._dispatch_loop, daemon=True,
                                         name="MessageEngine-Dispatch")
            t_dispatch.start()
            self._threads.append(t_dispatch)

            logger.info("MessageEngine 시작 — TCP 포트 %d", self._port)
            return True

        except Exception as e:
            logger.error("MessageEngine 시작 실패: %s", e)
            self.stop()
            return False

    def stop(self):
        """메시지 엔진 정지"""
        self._running = False
        if self._server_sock:
            try:
                self._server_sock.close()
            except OSError:
                pass
            self._server_sock = None
        logger.info("MessageEngine 정지")

    def register_handler(self, msg_type: MessageType, handler: Callable[[MeshMessage], None]):
        """메시지 타입별 핸들러 등록"""
        if msg_type not in self._message_handlers:
            self._message_handlers[msg_type] = []
        self._message_handlers[msg_type].append(handler)

    def send_unicast(self, target_ip: str, target_port: int,
                     message: MeshMessage, max_retries: int = 3) -> bool:
        """특정 피어에게 TCP 메시지 전송"""
        data = message.serialize()
        for attempt in range(max_retries):
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5.0)
                sock.connect((target_ip, target_port))
                # 프레임: [총길이(4)][데이터]
                frame = struct.pack("!I", len(data)) + data
                sock.sendall(frame)
                with self._send_lock:
                    self._stats["sent"] += 1
                logger.debug("유니캐스트 전송: %s → %s:%d (type=%s)",
                             message.msg_id, target_ip, target_port,
                             message.msg_type.name)
                return True
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.debug("전송 재시도 %d/%d: %s", attempt + 1, max_retries, e)
                    with self._send_lock:
                        self._stats["retried"] += 1
                    time.sleep(0.5 * (attempt + 1))
                else:
                    logger.warning("유니캐스트 전송 실패: %s:%d — %s",
                                   target_ip, target_port, e)
                    with self._send_lock:
                        self._stats["failed"] += 1
            finally:
                if sock:
                    try:
                        sock.close()
                    except OSError:
                        pass
        return False

    def send_broadcast(self, peers: Dict[str, PeerInfo], message: MeshMessage) -> int:
        """모든 활성 피어에게 메시지 전송 — 성공 수 반환"""
        success = 0
        for peer in peers.values():
            if not peer.is_alive or not peer.ip_address:
                continue
            if self.send_unicast(peer.ip_address, peer.tcp_port, message, max_retries=1):
                success += 1
        return success

    def _accept_loop(self):
        """TCP 연결 수락 루프"""
        while self._running:
            try:
                conn, addr = self._server_sock.accept()
                t = threading.Thread(target=self._handle_connection,
                                     args=(conn, addr), daemon=True)
                t.start()
            except socket.timeout:
                continue
            except OSError:
                if self._running:
                    logger.warning("TCP 수락 오류")
                break

    def _handle_connection(self, conn: socket.socket, addr: Tuple):
        """개별 TCP 연결 처리 — 메시지 수신"""
        try:
            conn.settimeout(10.0)
            # 프레임 헤더 읽기: [총길이(4)]
            header = self._recv_exact(conn, 4)
            if not header:
                return
            total_len = struct.unpack("!I", header)[0]
            if total_len > MESSAGE_MAX_SIZE:
                logger.warning("과대 메시지 수신: %d bytes from %s", total_len, addr)
                return
            data = self._recv_exact(conn, total_len)
            if not data:
                return
            msg = MeshMessage.deserialize(data)
            if msg:
                self._incoming_queue.put(msg)
                with self._send_lock:
                    self._stats["received"] += 1
        except Exception as e:
            logger.debug("TCP 연결 처리 오류 (%s): %s", addr, e)
        finally:
            try:
                conn.close()
            except OSError:
                pass

    @staticmethod
    def _recv_exact(conn: socket.socket, n: int) -> Optional[bytes]:
        """정확히 n 바이트 수신"""
        buf = bytearray()
        while len(buf) < n:
            chunk = conn.recv(min(n - len(buf), TCP_RECV_BUF))
            if not chunk:
                return None
            buf.extend(chunk)
        return bytes(buf)

    def _dispatch_loop(self):
        """수신 메시지 디스패치 루프"""
        while self._running:
            try:
                msg = self._incoming_queue.get(timeout=1.0)
                # 자신이 보낸 메시지는 무시
                if msg.sender_id == self._robot_id:
                    continue
                # 타겟 필터링 (유니캐스트)
                if msg.target_id and msg.target_id != self._robot_id:
                    continue
                # 등록된 핸들러 호출
                handlers = self._message_handlers.get(msg.msg_type, [])
                for handler in handlers:
                    try:
                        handler(msg)
                    except Exception as e:
                        logger.error("메시지 핸들러 오류 (type=%s): %s",
                                     msg.msg_type.name, e)
            except queue.Empty:
                continue

    @property
    def stats(self) -> Dict[str, int]:
        with self._send_lock:
            return dict(self._stats)


# ============================================================================
# 하트비트 모니터
# ============================================================================

class HeartbeatMonitor:
    """
    하트비트 송수신 및 지연 측정

    - 주기적 하트비트 전송 (HEARTBEAT_INTERVAL_S)
    - 피어별 하트비트 수신 추적
    - 왕복 지연시간(RTT) 측정
    - 임계 초과 시 피어 사망 선언
    """

    def __init__(self, robot_id: str, message_engine: MessageEngine,
                 peers_ref: Dict[str, PeerInfo]):
        self._robot_id = robot_id
        self._engine = message_engine
        self._peers_ref = peers_ref   # 외부 피어 테이블 참조
        self._running = False
        self._pending_pings: Dict[str, float] = {}   # msg_id → send_timestamp
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None

        # 하트비트 응답 핸들러 등록
        self._engine.register_handler(MessageType.HEARTBEAT, self._on_heartbeat)
        self._engine.register_handler(MessageType.HEARTBEAT_ACK, self._on_heartbeat_ack)

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._heartbeat_loop, daemon=True,
                                        name="HeartbeatMonitor")
        self._thread.start()
        logger.info("HeartbeatMonitor 시작 (주기=%.1fs)", HEARTBEAT_INTERVAL_S)

    def stop(self):
        self._running = False
        logger.info("HeartbeatMonitor 정지")

    def _heartbeat_loop(self):
        """주기적 하트비트 전송 + 타임아웃 감시"""
        while self._running:
            try:
                # 모든 활성 피어에게 하트비트 전송
                msg = MeshMessage(
                    msg_type=MessageType.HEARTBEAT,
                    sender_id=self._robot_id,
                    payload={"ts": time.time()},
                )
                for peer in self._peers_ref.values():
                    if not peer.is_alive or not peer.ip_address:
                        continue
                    self._engine.send_unicast(
                        peer.ip_address, peer.tcp_port, msg, max_retries=1
                    )
                    with self._lock:
                        self._pending_pings[msg.msg_id] = time.time()

                # 타임아웃 피어 감시
                now = time.time()
                for peer in self._peers_ref.values():
                    if peer.is_alive and (now - peer.last_heartbeat) > HEARTBEAT_TIMEOUT_S:
                        peer.missed_heartbeats += 1
                        if peer.missed_heartbeats > PEER_LIVENESS_THRESHOLD:
                            peer.is_alive = False
                            logger.warning("피어 하트비트 타임아웃: %s", peer.robot_id)

            except Exception as e:
                if self._running:
                    logger.warning("하트비트 루프 오류: %s", e)
            time.sleep(HEARTBEAT_INTERVAL_S)

    def _on_heartbeat(self, msg: MeshMessage):
        """수신된 하트비트에 ACK 응답"""
        ack = MeshMessage(
            msg_type=MessageType.HEARTBEAT_ACK,
            sender_id=self._robot_id,
            target_id=msg.sender_id,
            payload={"original_msg_id": msg.msg_id, "ts": msg.payload.get("ts", 0)},
        )
        peer = self._peers_ref.get(msg.sender_id)
        if peer and peer.ip_address:
            self._engine.send_unicast(peer.ip_address, peer.tcp_port, ack, max_retries=1)
            peer.last_heartbeat = time.time()
            peer.missed_heartbeats = 0
            peer.is_alive = True

    def _on_heartbeat_ack(self, msg: MeshMessage):
        """하트비트 ACK 수신 — RTT 계산"""
        original_ts = msg.payload.get("ts", 0)
        if original_ts > 0:
            rtt_ms = (time.time() - original_ts) * 1000.0
            peer = self._peers_ref.get(msg.sender_id)
            if peer:
                # 지수 이동 평균으로 RTT 업데이트
                alpha = 0.3
                peer.latency_ms = alpha * rtt_ms + (1 - alpha) * peer.latency_ms
                peer.last_heartbeat = time.time()
                peer.missed_heartbeats = 0
                peer.is_alive = True


# ============================================================================
# 작업 경매 프로토콜
# ============================================================================

class TaskAuctionProtocol:
    """
    작업 경매 프로토콜 — 리더가 작업을 공개하고 워커가 입찰

    흐름:
      1. LEADER → TASK_ANNOUNCE (모든 피어에게)
      2. WORKER/FOLLOWER → TASK_BID (LEADER에게)
      3. LEADER → TASK_ASSIGN (최적 입찰자에게)
      4. ASSIGNEE → TASK_RESULT (완료 후 LEADER에게)
      5. 실패 시 TASK_RETRY (재경매)
    """

    def __init__(self, robot_id: str, role: RobotRole,
                 message_engine: MessageEngine,
                 peers_ref: Dict[str, PeerInfo]):
        self._robot_id = robot_id
        self._role = role
        self._engine = message_engine
        self._peers_ref = peers_ref
        self._lock = threading.Lock()
        self._pending_tasks: Dict[str, AuctionTask] = {}        # task_id → AuctionTask
        self._bids: Dict[str, List[Dict[str, Any]]] = {}        # task_id → [bids]
        self._assigned_tasks: Dict[str, AuctionTask] = {}        # 내가 수행 중인 작업
        self._completed_results: Dict[str, Dict[str, Any]] = {}  # task_id → result
        self._task_counter = 0

        # 핸들러 등록
        self._engine.register_handler(MessageType.TASK_ANNOUNCE, self._on_task_announce)
        self._engine.register_handler(MessageType.TASK_BID, self._on_task_bid)
        self._engine.register_handler(MessageType.TASK_ASSIGN, self._on_task_assign)
        self._engine.register_handler(MessageType.TASK_RESULT, self._on_task_result)
        self._engine.register_handler(MessageType.TASK_RETRY, self._on_task_retry)

        # 작업 실행 콜백
        self._task_executor: Optional[Callable[[AuctionTask], Dict[str, Any]]] = None

    def set_task_executor(self, executor: Callable[[AuctionTask], Dict[str, Any]]):
        """작업 실행 콜백 설정"""
        self._task_executor = executor

    def announce_task(self, task: AuctionTask) -> bool:
        """작업 경매 공지 (LEADER만)"""
        if self._role != RobotRole.LEADER:
            logger.warning("비리더 역할은 작업 공지 불가: %s", self._role.value)
            return False

        with self._lock:
            self._pending_tasks[task.task_id] = task
            self._bids[task.task_id] = []

        msg = MeshMessage(
            msg_type=MessageType.TASK_ANNOUNCE,
            sender_id=self._robot_id,
            payload={
                "task_id": task.task_id,
                "task_type": task.task_type,
                "description": task.description,
                "priority": task.priority,
                "required_capabilities": task.required_capabilities,
                "parameters": task.parameters,
                "deadline": task.deadline,
            },
        )
        count = self._engine.send_broadcast(self._peers_ref, msg)
        logger.info("작업 경매 공지: %s (타입=%s, 입찰자=%d)", task.task_id, task.task_type, count)
        return count > 0

    def _on_task_announce(self, msg: MeshMessage):
        """작업 공지 수신 — 입찰 여부 결정"""
        if self._role not in (RobotRole.WORKER, RobotRole.FOLLOWER, RobotRole.SCOUT):
            return

        payload = msg.payload
        required = payload.get("required_capabilities", [])
        my_caps = self._get_my_capabilities()

        # 역량 확인
        can_perform = all(cap in my_caps for cap in required)
        if not can_perform:
            return

        # 입찰 가격 계산 (낮을수록 좋음)
        bid_price = self._calculate_bid_price(payload)

        task = AuctionTask(
            task_id=payload["task_id"],
            task_type=payload.get("task_type", ""),
            description=payload.get("description", ""),
            priority=payload.get("priority", 5),
            required_capabilities=required,
            parameters=payload.get("parameters", {}),
            deadline=payload.get("deadline", 0),
        )
        with self._lock:
            self._assigned_tasks[task.task_id] = task

        # 리더에게 입찰 전송
        bid_msg = MeshMessage(
            msg_type=MessageType.TASK_BID,
            sender_id=self._robot_id,
            target_id=msg.sender_id,
            payload={
                "task_id": task.task_id,
                "bid_price": bid_price,
                "capabilities": my_caps,
            },
        )
        leader = self._find_leader()
        if leader and leader.ip_address:
            self._engine.send_unicast(leader.ip_address, leader.tcp_port, bid_msg)

    def _on_task_bid(self, msg: MeshMessage):
        """입찰 수신 (LEADER만)"""
        if self._role != RobotRole.LEADER:
            return
        task_id = msg.payload.get("task_id", "")
        with self._lock:
            if task_id not in self._bids:
                return
            self._bids[task_id].append({
                "robot_id": msg.sender_id,
                "bid_price": msg.payload.get("bid_price", float("inf")),
                "capabilities": msg.payload.get("capabilities", {}),
                "timestamp": time.time(),
            })

        # 입찰 대기 후 최적 입찰자 선택
        task = self._pending_tasks.get(task_id)
        if task and task.status == TaskStatus.AUCTIONING:
            self._try_assign_task(task_id)

    def _try_assign_task(self, task_id: str):
        """최적 입찰자에게 작업 할당"""
        with self._lock:
            bids = self._bids.get(task_id, [])
            task = self._pending_tasks.get(task_id)
            if not bids or not task:
                return

            # 입찰가 오름차순 정렬
            sorted_bids = sorted(bids, key=lambda b: b["bid_price"])
            winner = sorted_bids[0]

            task.status = TaskStatus.ASSIGNED
            task.assigned_to = winner["robot_id"]

        # 할당 메시지 전송
        assign_msg = MeshMessage(
            msg_type=MessageType.TASK_ASSIGN,
            sender_id=self._robot_id,
            target_id=winner["robot_id"],
            payload={
                "task_id": task_id,
                "task_type": task.task_type,
                "parameters": task.parameters,
                "deadline": task.deadline,
            },
        )
        peer = self._peers_ref.get(winner["robot_id"])
        if peer and peer.ip_address:
            self._engine.send_unicast(peer.ip_address, peer.tcp_port, assign_msg)
            logger.info("작업 할당: %s → %s (입찰가=%.2f)", task_id, winner["robot_id"],
                        winner["bid_price"])

    def _on_task_assign(self, msg: MeshMessage):
        """작업 할당 수신 — 실행 시작"""
        task_id = msg.payload.get("task_id", "")
        with self._lock:
            task = self._assigned_tasks.get(task_id)
            if not task:
                task = AuctionTask(
                    task_id=task_id,
                    task_type=msg.payload.get("task_type", ""),
                    parameters=msg.payload.get("parameters", {}),
                    deadline=msg.payload.get("deadline", 0),
                )
                self._assigned_tasks[task_id] = task

            task.status = TaskStatus.IN_PROGRESS

        # 작업 실행 (비동기)
        if self._task_executor:
            try:
                result = self._task_executor(task)
                self._submit_task_result(task, result)
            except Exception as e:
                logger.error("작업 실행 오류 (%s): %s", task_id, e)
                self._submit_task_result(task, {"success": False, "error": str(e)})
        else:
            self._submit_task_result(task, {"success": True, "note": "no_executor"})

    def _submit_task_result(self, task: AuctionTask, result: Dict[str, Any]):
        """작업 결과 전송"""
        task.status = TaskStatus.COMPLETED if result.get("success", False) else TaskStatus.FAILED
        task.result = result

        result_msg = MeshMessage(
            msg_type=MessageType.TASK_RESULT,
            sender_id=self._robot_id,
            target_id=self._find_leader_id(),
            payload={
                "task_id": task.task_id,
                "success": result.get("success", False),
                "result": result,
            },
        )
        leader = self._find_leader()
        if leader and leader.ip_address:
            self._engine.send_unicast(leader.ip_address, leader.tcp_port, result_msg)

    def _on_task_result(self, msg: MeshMessage):
        """작업 결과 수신 (LEADER만)"""
        task_id = msg.payload.get("task_id", "")
        success = msg.payload.get("success", False)
        with self._lock:
            task = self._pending_tasks.get(task_id)
            if task:
                task.result = msg.payload.get("result", {})
                task.status = TaskStatus.COMPLETED if success else TaskStatus.FAILED
                self._completed_results[task_id] = msg.payload

            # 실패 시 재시도
            if not success and task and task.retry_count < MAX_TASK_RETRIES:
                task.retry_count += 1
                task.status = TaskStatus.PENDING
                task.assigned_to = None
                logger.info("작업 재경매: %s (재시도 %d/%d)", task_id,
                            task.retry_count, MAX_TASK_RETRIES)
                self.announce_task(task)

    def _on_task_retry(self, msg: MeshMessage):
        """재시도 요청 수신"""
        task_id = msg.payload.get("task_id", "")
        logger.info("작업 재시도 요청: %s", task_id)

    def _calculate_bid_price(self, task_payload: Dict[str, Any]) -> float:
        """입찰 가격 계산 — 부하, 배터리, 우선순위 고려"""
        base = task_payload.get("priority", 5)
        load = self._get_my_load()
        battery = self._get_my_battery()
        price = base * (1.0 + load) / max(0.1, battery)
        return price

    def _get_my_capabilities(self) -> List[str]:
        return ["locomotion", "grasping", "sensing"]

    def _get_my_load(self) -> float:
        with self._lock:
            return min(1.0, len(self._assigned_tasks) / 5.0)

    def _get_my_battery(self) -> float:
        return 1.0

    def _find_leader(self) -> Optional[PeerInfo]:
        for peer in self._peers_ref.values():
            if peer.role == RobotRole.LEADER and peer.is_alive:
                return peer
        return None

    def _find_leader_id(self) -> Optional[str]:
        leader = self._find_leader()
        return leader.robot_id if leader else None

    def get_pending_tasks(self) -> List[AuctionTask]:
        with self._lock:
            return [t for t in self._pending_tasks.values()
                    if t.status in (TaskStatus.PENDING, TaskStatus.AUCTIONING)]

    def get_completed_results(self) -> Dict[str, Dict[str, Any]]:
        with self._lock:
            return dict(self._completed_results)


# ============================================================================
# 연합 학습 조정기
# ============================================================================

class FederatedCoordinator:
    """
    연합 학습 라운드 조정 — LEADER가 주도

    흐름:
      1. LEADER → FED_ROUND_START (모든 피어에게)
      2. WORKER → FED_GRADIENT_SUBMIT (LEADER에게)
      3. LEADER: 집계 (FedAvg / Trimmed Mean)
      4. LEADER → FED_AGGREGATED_MODEL (모든 피어에게)
      5. LEADER → FED_ROUND_COMPLETE
    """

    def __init__(self, robot_id: str, role: RobotRole,
                 message_engine: MessageEngine,
                 peers_ref: Dict[str, PeerInfo]):
        self._robot_id = robot_id
        self._role = role
        self._engine = message_engine
        self._peers_ref = peers_ref
        self._lock = threading.Lock()
        self._current_round: Optional[FederatedRound] = None
        self._round_history: List[FederatedRound] = []
        self._local_gradient: Optional[Dict[str, Any]] = None
        self._gradient_callback: Optional[Callable[[], Dict[str, Any]]] = None

        # 핸들러 등록
        self._engine.register_handler(MessageType.FED_ROUND_START, self._on_round_start)
        self._engine.register_handler(MessageType.FED_GRADIENT_SUBMIT, self._on_gradient_submit)
        self._engine.register_handler(MessageType.FED_AGGREGATED_MODEL, self._on_aggregated_model)

    def set_gradient_callback(self, callback: Callable[[], Dict[str, Any]]):
        """로컬 그래디언트 생성 콜백 설정"""
        self._gradient_callback = callback

    def start_round(self, skill_id: str, min_clients: int = FED_MIN_CLIENTS,
                    timeout: float = FED_ROUND_TIMEOUT_S) -> Optional[str]:
        """연합 학습 라운드 시작 (LEADER만)"""
        if self._role != RobotRole.LEADER:
            logger.warning("비리더는 연합 라운드 시작 불가")
            return None

        alive_count = sum(1 for p in self._peers_ref.values() if p.is_alive)
        if alive_count < min_clients:
            logger.warning("연합 라운드 시작 불가: 피어 %d < 최소 %d", alive_count, min_clients)
            return None

        round_num = len(self._round_history) + 1
        fed_round = FederatedRound(
            round_number=round_num,
            skill_id=skill_id,
            min_clients=min_clients,
            timeout=timeout,
            status="collecting",
        )
        with self._lock:
            self._current_round = fed_round

        # 라운드 시작 메시지 브로드캐스트
        msg = MeshMessage(
            msg_type=MessageType.FED_ROUND_START,
            sender_id=self._robot_id,
            payload={
                "round_id": fed_round.round_id,
                "round_number": round_num,
                "skill_id": skill_id,
                "timeout": timeout,
            },
        )
        self._engine.send_broadcast(self._peers_ref, msg)
        logger.info("연합 학습 라운드 시작: #%d (skill=%s, 피어=%d)",
                     round_num, skill_id, alive_count)
        return fed_round.round_id

    def _on_round_start(self, msg: MeshMessage):
        """연합 라운드 시작 수신 — 로컬 그래디언트 계산 후 제출"""
        round_id = msg.payload.get("round_id", "")
        skill_id = msg.payload.get("skill_id", "")

        gradient_data = {}
        if self._gradient_callback:
            try:
                gradient_data = self._gradient_callback()
            except Exception as e:
                logger.error("그래디언트 콜백 오류: %s", e)

        # 리더에게 그래디언트 제출
        submit_msg = MeshMessage(
            msg_type=MessageType.FED_GRADIENT_SUBMIT,
            sender_id=self._robot_id,
            target_id=msg.sender_id,
            payload={
                "round_id": round_id,
                "skill_id": skill_id,
                "gradient": gradient_data,
                "num_samples": gradient_data.get("num_samples", 0),
            },
        )
        leader = self._find_leader()
        if leader and leader.ip_address:
            self._engine.send_unicast(leader.ip_address, leader.tcp_port, submit_msg)
            logger.info("그래디언트 제출: round=%s, skill=%s", round_id, skill_id)

    def _on_gradient_submit(self, msg: MeshMessage):
        """그래디언트 제출 수신 (LEADER만)"""
        with self._lock:
            if not self._current_round:
                return
            if msg.payload.get("round_id") != self._current_round.round_id:
                return

            self._current_round.gradients[msg.sender_id] = msg.payload.get("gradient", {})
            received = len(self._current_round.gradients)

        logger.debug("그래디언트 수신: %s (%d/%d)", msg.sender_id,
                     received, self._current_round.min_clients)

        # 최소 클라이언트 수 충족 시 집계
        if received >= self._current_round.min_clients:
            self._aggregate_and_distribute()

    def _aggregate_and_distribute(self):
        """그래디언트 집계 및 결과 분배"""
        with self._lock:
            if not self._current_round:
                return
            fed_round = self._current_round
            fed_round.status = "aggregating"

        # 간단한 FedAvg 집계 (실제 구현은 federated_skill_sharing 모듈과 연동)
        try:
            aggregated = self._fed_avg_aggregate(fed_round.gradients)
            fed_round.status = "completed"
            fed_round.completed_at = time.time()

            # 집계 결과 브로드캐스트
            msg = MeshMessage(
                msg_type=MessageType.FED_AGGREGATED_MODEL,
                sender_id=self._robot_id,
                payload={
                    "round_id": fed_round.round_id,
                    "skill_id": fed_round.skill_id,
                    "aggregated": aggregated,
                    "num_clients": len(fed_round.gradients),
                },
            )
            self._engine.send_broadcast(self._peers_ref, msg)

            with self._lock:
                self._round_history.append(fed_round)
                self._current_round = None

            logger.info("연합 학습 라운드 완료: #%d (클라이언트=%d)",
                        fed_round.round_number, len(fed_round.gradients))

        except Exception as e:
            logger.error("연합 집계 오류: %s", e)
            with self._lock:
                if self._current_round:
                    self._current_round.status = "failed"

    def _fed_avg_aggregate(self, gradients: Dict[str, Any]) -> Dict[str, Any]:
        """FedAvg 집계 — 평균 가중치 계산"""
        if not gradients:
            return {}

        # 그래디언트 벡터 평균 (간단 구현)
        # 실제로는 numpy/torch 텐서 연산
        total_samples = sum(g.get("num_samples", 1) for g in gradients.values())
        avg_data = {
            "num_clients": len(gradients),
            "total_samples": total_samples,
            "method": "fed_avg",
        }
        return avg_data

    def _on_aggregated_model(self, msg: MeshMessage):
        """집계 모델 수신 — 로컬 모델 업데이트"""
        logger.info("집계 모델 수신: round=%s, skill=%s, 클라이언트=%d",
                     msg.payload.get("round_id", ""),
                     msg.payload.get("skill_id", ""),
                     msg.payload.get("num_clients", 0))

    def _find_leader(self) -> Optional[PeerInfo]:
        for peer in self._peers_ref.values():
            if peer.role == RobotRole.LEADER and peer.is_alive:
                return peer
        return None

    def get_round_history(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [{"round_number": r.round_number,
                     "skill_id": r.skill_id,
                     "num_clients": len(r.gradients),
                     "status": r.status}
                    for r in self._round_history]


# ============================================================================
# 메인 클래스: MultiRobotMesh
# ============================================================================

class MultiRobotMesh:
    """
    다중 로봇 메시 네트워크 — 협력 로봇 시스템의 통신 백본

    아키텍처:
      ┌─ DiscoveryEngine (UDP 멀티캐스트) ──────── 피어 자동 발견
      ├─ MessageEngine (TCP) ────────────────────── 신뢰성 메시지
      ├─ HeartbeatMonitor ───────────────────────── 생존 감시
      ├─ TaskAuctionProtocol ────────────────────── 작업 분배
      └─ FederatedCoordinator ───────────────────── 연합 학습

    사용:
      mesh = MultiRobotMesh()
      if mesh.initialize():
          mesh.run()  # 블로킹 — 메인 루프에서 주기적 호출 권장

      # 작업 분배 (LEADER)
      mesh.distribute_task("exploration", {"area": "room_3"})

      # 메시지 전송
      mesh.send_message("robot_002", {"type": "command", "action": "stop"})

      # 연합 학습
      mesh.start_federated_round("grasping_skill")
    """

    def __init__(self, robot_id: Optional[str] = None,
                 role: RobotRole = RobotRole.FOLLOWER,
                 tcp_port: int = TCP_PORT,
                 capabilities: Optional[Dict[str, Any]] = None):
        # 로봇 식별
        self._robot_id = robot_id or self._generate_robot_id()
        self._role = role
        self._tcp_port = tcp_port
        self._capabilities = capabilities or {
            "locomotion": True,
            "grasping": True,
            "sensing": True,
            "computation": True,
        }

        # 내부 상태
        self._state = MeshState.INITIALIZING
        self._initialized = False
        self._running = False
        self._lock = threading.RLock()   # 재진입 가능 락 (스레드 안전)
        self._start_time = 0.0

        # 피어 테이블 (모든 하위 엔진이 공유 참조)
        self._peers: Dict[str, PeerInfo] = {}

        # 하위 엔진 (초기화 시 생성)
        self._discovery: Optional[DiscoveryEngine] = None
        self._messenger: Optional[MessageEngine] = None
        self._heartbeat: Optional[HeartbeatMonitor] = None
        self._auction: Optional[TaskAuctionProtocol] = None
        self._federated: Optional[FederatedCoordinator] = None

        # 메시지 핸들러 (사용자 등록)
        self._message_callbacks: List[Callable[[MeshMessage], None]] = []

        # 통계
        self._stats = {
            "messages_sent": 0,
            "messages_received": 0,
            "tasks_distributed": 0,
            "tasks_completed": 0,
            "federated_rounds": 0,
            "peers_discovered": 0,
            "network_failures": 0,
            "recoveries": 0,
        }

        logger.info("MultiRobotMesh 생성: id=%s, role=%s", self._robot_id, self._role.value)

    # ======================================================================
    # 초기화 / Initialization
    # ======================================================================

    def initialize(self) -> bool:
        """
        메시 네트워크 전체 초기화

        Returns:
            bool: 초기화 성공 여부
        """
        with self._lock:
            if self._initialized:
                logger.warning("MultiRobotMesh 이미 초기화됨")
                return True

            logger.info("=== 다중 로봇 메시 네트워크 초기화 ===")
            logger.info("  로봇 ID: %s", self._robot_id)
            logger.info("  역할: %s", self._role.value)
            logger.info("  TCP 포트: %d", self._tcp_port)
            self._start_time = time.time()

            try:
                # 1. 피어 발견 엔진
                self._discovery = DiscoveryEngine(
                    robot_id=self._robot_id,
                    role=self._role,
                    tcp_port=self._tcp_port,
                    capabilities=self._capabilities,
                )

                # 2. 메시지 전달 엔진
                self._messenger = MessageEngine(
                    robot_id=self._robot_id,
                    port=self._tcp_port,
                )

                # 3. 하트비트 모니터
                self._heartbeat = HeartbeatMonitor(
                    robot_id=self._robot_id,
                    message_engine=self._messenger,
                    peers_ref=self._peers,
                )

                # 4. 작업 경매 프로토콜
                self._auction = TaskAuctionProtocol(
                    robot_id=self._robot_id,
                    role=self._role,
                    message_engine=self._messenger,
                    peers_ref=self._peers,
                )

                # 5. 연합 학습 조정기
                self._federated = FederatedCoordinator(
                    robot_id=self._robot_id,
                    role=self._role,
                    message_engine=self._messenger,
                    peers_ref=self._peers,
                )

                # 6. 사용자 메시지 핸들러 등록
                self._messenger.register_handler(
                    MessageType.MESSAGE_UNICAST, self._on_user_message
                )
                self._messenger.register_handler(
                    MessageType.MESSAGE_BROADCAST, self._on_user_message
                )

                # 7. 비상 정지 핸들러
                self._messenger.register_handler(
                    MessageType.EMERGENCY_STOP, self._on_emergency_stop
                )

                # 8. 역할 변경 핸들러
                self._messenger.register_handler(
                    MessageType.ROLE_CHANGE, self._on_role_change
                )

                # 9. 엔진 순차 시작
                if not self._messenger.start():
                    logger.error("MessageEngine 시작 실패")
                    self._state = MeshState.ISOLATED
                    return False

                if not self._discovery.start():
                    logger.warning("DiscoveryEngine 시작 실패 — 피어 발견 불가 (비치명적)")
                    self._state = MeshState.ISOLATED
                else:
                    self._state = MeshState.DISCOVERING

                self._heartbeat.start()

                self._initialized = True
                self._state = MeshState.ACTIVE if self._discovery.peer_count > 0 \
                    else MeshState.DISCOVERING

                elapsed = time.time() - self._start_time
                logger.info("=== 메시 네트워크 초기화 완료 (%.2f초) ===", elapsed)
                logger.info("  상태: %s", self._state.value)
                return True

            except Exception as e:
                logger.error("메시 네트워크 초기화 실패: %s", e)
                self._state = MeshState.ISOLATED
                self._shutdown_internal()
                return False

    def shutdown(self):
        """메시 네트워크 종료"""
        with self._lock:
            if not self._initialized:
                return
            self._state = MeshState.SHUTTING_DOWN
            self._running = False
            self._shutdown_internal()
            self._initialized = False
            logger.info("MultiRobotMesh 종료 완료")

    def _shutdown_internal(self):
        """내부 종료 처리"""
        if self._heartbeat:
            self._heartbeat.stop()
        if self._discovery:
            self._discovery.stop()
        if self._messenger:
            self._messenger.stop()

    # ======================================================================
    # 공개 API — 메시지 전달
    # ======================================================================

    def send_message(self, target_id: str, payload: Dict[str, Any]) -> bool:
        """
        특정 피어에게 메시지 전송 (유니캐스트)

        Args:
            target_id: 대상 로봇 ID
            payload: 메시지 내용

        Returns:
            전송 성공 여부
        """
        if not self._initialized:
            logger.warning("메시 네트워크 미초기화 — 메시지 전송 불가")
            return False

        peer = self._peers.get(target_id)
        if not peer or not peer.is_alive:
            logger.warning("피어 미발견 또는 비활성: %s", target_id)
            return False

        msg = MeshMessage(
            msg_type=MessageType.MESSAGE_UNICAST,
            sender_id=self._robot_id,
            target_id=target_id,
            payload=payload,
        )
        result = self._messenger.send_unicast(peer.ip_address, peer.tcp_port, msg)
        with self._lock:
            self._stats["messages_sent"] += 1 if result else 0
        return result

    def broadcast_message(self, payload: Dict[str, Any]) -> int:
        """
        모든 활성 피어에게 메시지 전송 (브로드캐스트)

        Args:
            payload: 메시지 내용

        Returns:
            성공적으로 전송된 피어 수
        """
        if not self._initialized:
            return 0

        msg = MeshMessage(
            msg_type=MessageType.MESSAGE_BROADCAST,
            sender_id=self._robot_id,
            payload=payload,
        )
        count = self._messenger.send_broadcast(self._peers, msg)
        with self._lock:
            self._stats["messages_sent"] += count
        return count

    def register_message_callback(self, callback: Callable[[MeshMessage], None]):
        """메시지 수신 콜백 등록"""
        self._message_callbacks.append(callback)

    def _on_user_message(self, msg: MeshMessage):
        """사용자 메시지 수신 처리"""
        with self._lock:
            self._stats["messages_received"] += 1
        for cb in self._message_callbacks:
            try:
                cb(msg)
            except Exception as e:
                logger.error("메시지 콜백 오류: %s", e)

    # ======================================================================
    # 공개 API — 작업 분배
    # ======================================================================

    def distribute_task(self, task_type: str, parameters: Dict[str, Any],
                        priority: int = 5, required_capabilities: Optional[List[str]] = None,
                        description: str = "") -> Optional[str]:
        """
        작업 경매 공지 (LEADER 전용)

        Args:
            task_type: 작업 타입 (예: "exploration", "grasping", "transport")
            parameters: 작업 매개변수
            priority: 우선순위 (1=최고, 10=최저)
            required_capabilities: 필요 역량 목록
            description: 작업 설명

        Returns:
            작업 ID (경매 실패 시 None)
        """
        if not self._initialized or not self._auction:
            return None

        task = AuctionTask(
            task_type=task_type,
            description=description,
            priority=priority,
            required_capabilities=required_capabilities or [],
            parameters=parameters,
        )

        if self._auction.announce_task(task):
            with self._lock:
                self._stats["tasks_distributed"] += 1
            return task.task_id
        return None

    def set_task_executor(self, executor: Callable[[AuctionTask], Dict[str, Any]]):
        """작업 실행 콜백 설정"""
        if self._auction:
            self._auction.set_task_executor(executor)

    def get_task_results(self) -> Dict[str, Dict[str, Any]]:
        """완료된 작업 결과 반환"""
        if self._auction:
            return self._auction.get_completed_results()
        return {}

    # ======================================================================
    # 공개 API — 연합 학습
    # ======================================================================

    def start_federated_round(self, skill_id: str,
                              min_clients: int = FED_MIN_CLIENTS,
                              timeout: float = FED_ROUND_TIMEOUT_S) -> Optional[str]:
        """
        연합 학습 라운드 시작 (LEADER 전용)

        Args:
            skill_id: 학습할 스킬 ID
            min_clients: 최소 참여 클라이언트 수
            timeout: 라운드 타임아웃 (초)

        Returns:
            라운드 ID (시작 실패 시 None)
        """
        if not self._initialized or not self._federated:
            return None

        round_id = self._federated.start_round(skill_id, min_clients, timeout)
        if round_id:
            with self._lock:
                self._stats["federated_rounds"] += 1
        return round_id

    def set_gradient_callback(self, callback: Callable[[], Dict[str, Any]]):
        """로컬 그래디언트 생성 콜백 설정"""
        if self._federated:
            self._federated.set_gradient_callback(callback)

    def get_federated_history(self) -> List[Dict[str, Any]]:
        """연합 학습 이력 반환"""
        if self._federated:
            return self._federated.get_round_history()
        return []

    # ======================================================================
    # 공개 API — 피어 관리
    # ======================================================================

    def get_peers(self) -> Dict[str, PeerInfo]:
        """현재 피어 테이블 반환"""
        if self._discovery:
            return self._discovery.get_peers()
        return {}

    def get_peer_count(self) -> int:
        """활성 피어 수 반환"""
        if self._discovery:
            return self._discovery.peer_count
        return 0

    def get_role(self) -> RobotRole:
        """현재 역할 반환"""
        return self._role

    def set_role(self, role: RobotRole):
        """역할 변경"""
        with self._lock:
            self._role = role
            if self._discovery:
                self._discovery.update_role(role)
            if self._auction:
                self._auction._role = role
            if self._federated:
                self._federated._role = role
        logger.info("역할 변경: %s", role.value)

    def get_robot_id(self) -> str:
        """로봇 ID 반환"""
        return self._robot_id

    # ======================================================================
    # 공개 API — 네트워크 상태
    # ======================================================================

    def get_state(self) -> MeshState:
        """메시 네트워크 상태 반환"""
        return self._state

    def get_stats(self) -> Dict[str, Any]:
        """네트워크 통계 반환"""
        stats = dict(self._stats)
        stats["robot_id"] = self._robot_id
        stats["role"] = self._role.value
        stats["state"] = self._state.value
        stats["peer_count"] = self.get_peer_count()
        stats["uptime_s"] = time.time() - self._start_time if self._start_time else 0

        if self._messenger:
            stats["transport"] = self._messenger.stats
        return stats

    def check_health(self) -> Dict[str, Any]:
        """
        네트워크 건강 진단

        Returns:
            건강 상태 딕셔너리
        """
        health = {
            "state": self._state.value,
            "initialized": self._initialized,
            "peer_count": self.get_peer_count(),
            "discovery_ok": self._discovery is not None,
            "messenger_ok": self._messenger is not None,
            "heartbeat_ok": self._heartbeat is not None,
            "auction_ok": self._auction is not None,
            "federated_ok": self._federated is not None,
            "issues": [],
        }

        if self._state == MeshState.ISOLATED:
            health["issues"].append("네트워크 고립 — 피어 발견 불가")
        if self._state == MeshState.DEGRADED:
            health["issues"].append("네트워크 저하 — 일부 피어 손실")
        if self.get_peer_count() == 0 and self._state != MeshState.INITIALIZING:
            health["issues"].append("활성 피어 없음")

        health["healthy"] = (self._state in (MeshState.ACTIVE, MeshState.DISCOVERING)
                             and self._initialized)
        return health

    # ======================================================================
    # 내부 이벤트 핸들러
    # ======================================================================

    def _on_emergency_stop(self, msg: MeshMessage):
        """비상 정지 수신"""
        logger.critical("!!! 비상 정지 수신: %s !!!", msg.sender_id)
        self._state = MeshState.ISOLATED

    def _on_role_change(self, msg: MeshMessage):
        """역할 변경 명령 수신"""
        new_role_str = msg.payload.get("new_role", "")
        try:
            new_role = RobotRole(new_role_str)
            self.set_role(new_role)
            logger.info("역할 변경 명령 수행: %s → %s", self._robot_id, new_role.value)
        except ValueError:
            logger.warning("알 수 없는 역할: %s", new_role_str)

    # ======================================================================
    # 유틸리티
    # ======================================================================

    @staticmethod
    def _generate_robot_id() -> str:
        """고유 로봇 ID 생성"""
        hostname = socket.gethostname()
        uid = uuid.uuid4().hex[:8]
        return f"jihun_{hostname}_{uid}"

    def __repr__(self) -> str:
        return (f"MultiRobotMesh(id={self._robot_id}, role={self._role.value}, "
                f"state={self._state.value}, peers={self.get_peer_count()})")


# ============================================================================
# 모듈 진입점 (단독 테스트)
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    print("=" * 60)
    print("지훈 로봇 V8.5 — 다중 로봇 메시 네트워크 테스트")
    print("=" * 60)

    # 리더 로봇 생성
    leader = MultiRobotMesh(
        robot_id="jihun_leader_01",
        role=RobotRole.LEADER,
        capabilities={"locomotion": True, "grasping": True, "sensing": True,
                      "computation": True, "coordination": True},
    )

    if leader.initialize():
        print(f"  리더 초기화 성공: {leader}")
        print(f"  건강 상태: {leader.check_health()}")

        # 5초간 피어 발견 대기
        print("\n  5초간 피어 발견 대기...")
        time.sleep(5)

        # 작업 분배 테스트
        task_id = leader.distribute_task(
            task_type="area_scan",
            parameters={"area": "room_3", "resolution": "high"},
            priority=3,
            required_capabilities=["sensing", "locomotion"],
            description="3번 방 영역 스캔",
        )
        if task_id:
            print(f"  작업 분배 성공: {task_id}")
        else:
            print("  작업 분배 실패 (피어 없음 — 정상)")

        # 연합 학습 테스트
        round_id = leader.start_federated_round("grasping_skill_v1")
        if round_id:
            print(f"  연합 학습 라운드 시작: {round_id}")
        else:
            print("  연합 학습 라운드 시작 실패 (피어 부족 — 정상)")

        # 브로드캐스트 테스트
        sent = leader.broadcast_message({"type": "test", "msg": "hello_mesh"})
        print(f"  브로드캐스트 전송: {sent} 피어")

        # 통계 출력
        stats = leader.get_stats()
        print(f"\n  통계: {json.dumps(stats, indent=2, default=str)}")

        leader.shutdown()
        print("\n  리더 종료 완료")
    else:
        print("  리더 초기화 실패!")

    print("\n테스트 완료.")
