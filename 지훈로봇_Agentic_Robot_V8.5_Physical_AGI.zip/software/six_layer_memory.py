#!/usr/bin/env python3
"""
지훈 로봇 V8.5 - 6층 기억 시스템 (Six-Layer Memory System)
========================================================

V7의 4층 기억 시스템을 6층으로 확장한 아키텍처.
지속적 세계 데이터 학습과 자기진화를 지원합니다.

Layer 1: 작업기억 (Working Memory)      - deque, 최근 50개 상호작용, 휘발성
Layer 2: 일화기억 (Episodic Memory)     - SQLite, 대화/행동/관찰 기록, 90일 보존
Layer 3: 의미기억 (Semantic Memory)      - LanceDB, 임베딩 벡터, 의미 검색
Layer 4: 절차기억 (Procedural Memory)    - 스킬 라이브러리
Layer 5: 세계지식 (World Knowledge)      - NEW: 증류된 세계 사실, 최대 50,000개
Layer 6: 혁신기억 (Innovation Memory)    - NEW: 새로운 조합, 창의적 해결책, 최대 5,000개

TODO 25-32: 6층 기억 시스템 구현

핵심 기능:
  - store(): 자동 계층 결정 저장
  - recall(): 전층 검색 (인과 추론 + 세계지식 보강)
  - consolidate(): 층 간 연속 통합 (시간 기반 → 이벤트 기반)
  - 교차 모달 연관 (시각↔촉각↔청각)
  - 지식 그래프 통합 (Layer 5)
  - 인과 추론 통합 (recall 보강)
  - simulate_outcome(): 과거 경험 기반 행동 결과 예측
  - 하위 호환: FourLayerMemory = SixLayerMemory

하드웨어: Dual Jetson Orin NX 16GB
AI 모델: Gemma 4 E4B Q4_K_M

Author: 지훈 로봇 V8.5 개발팀
Created: 2025
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("jihun_v84.six_layer_memory")
logger.setLevel(logging.DEBUG)


# ──────────────────────────────────────────────
#  열거형 (Enumerations)
# ──────────────────────────────────────────────

class MemoryLayer(Enum):
    """기억 층 열거형 / Memory layer enumeration"""
    WORKING = "working"                      # Layer 1: 작업기억
    EPISODIC = "episodic"                    # Layer 2: 일화기억
    SEMANTIC = "semantic"                    # Layer 3: 의미기억
    PROCEDURAL = "procedural"                # Layer 4: 절차기억
    WORLD_KNOWLEDGE = "world_knowledge"      # Layer 5: 세계지식 (V8.5 NEW)
    INNOVATION = "innovation"                # Layer 6: 혁신기억 (V8.5 NEW)


class MemoryModality(Enum):
    """감각 모달리티 / Sensory modality for cross-modal associations"""
    VISUAL = "visual"
    AUDITORY = "auditory"
    TACTILE = "tactile"
    PROPRIOCEPTIVE = "proprioceptive"
    LINGUISTIC = "linguistic"
    CONCEPTUAL = "conceptual"


class MemoryPriority(Enum):
    """기억 저장 우선순위 / Memory storage priority"""
    LOW = 0
    MEDIUM = 1
    HIGH = 2
    CRITICAL = 3
    INNOVATIVE = 4


# ──────────────────────────────────────────────
#  상수 / Constants
# ──────────────────────────────────────────────

WORKING_MEMORY_CAPACITY = 50
EPISODIC_RETENTION_DAYS = 90
WORLD_KNOWLEDGE_MAX = 50_000
INNOVATION_MEMORY_MAX = 5_000
CONSOLIDATION_INTERVAL_S = 600.0  # V8: 10분 (V7의 1시간 → 더 자주)
CROSS_MODAL_DECAY = 0.95


# ──────────────────────────────────────────────
#  데이터 클래스 (Data Classes)
# ──────────────────────────────────────────────

@dataclass
class MemoryItem:
    """
    기억 항목 데이터 클래스 / Memory item data class.
    모든 층의 기억 항목이 공유하는 기본 구조입니다.

    V8.5 추가 필드:
      - causal_context: 인과 맥락 (원인-결과 관계)
      - emotional_context: 감성 맥락 (감정 상태)
      - modal_associations: 교차 모달 연관
      - novelty_score: 참신함 점수 (0~1)
      - world_knowledge_links: 세계지식 링크
    """
    item_id: str = field(default_factory=lambda: f"mem_{uuid.uuid4().hex[:12]}")
    content: Any = None
    layer: MemoryLayer = MemoryLayer.WORKING
    priority: MemoryPriority = MemoryPriority.MEDIUM
    timestamp: float = field(default_factory=time.time)
    importance: float = 0.5
    access_count: int = 0
    last_accessed: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    embedding: Optional[np.ndarray] = None
    # V8.5 신규 필드 / V8.5 new fields
    causal_context: Optional[Dict[str, Any]] = None
    emotional_context: Optional[Dict[str, Any]] = None
    modal_associations: List[Dict[str, Any]] = field(default_factory=list)
    novelty_score: float = 0.0
    world_knowledge_links: List[str] = field(default_factory=list)

    def touch(self) -> None:
        """접근 기록 업데이트 / Update access record"""
        self.access_count += 1
        self.last_accessed = time.time()

    @property
    def age_days(self) -> float:
        """경과 일수 / Age in days"""
        return (time.time() - self.timestamp) / 86400.0


@dataclass
class RecallResult:
    """회상 결과 / Recall result"""
    items: List[MemoryItem] = field(default_factory=list)
    total_count: int = 0
    query: str = ""
    layers_searched: List[MemoryLayer] = field(default_factory=list)
    elapsed_ms: float = 0.0
    causal_chain_used: bool = False
    world_knowledge_enriched: bool = False

    @property
    def best_match(self) -> Optional[MemoryItem]:
        """가장 관련성 높은 항목 / Best matching item"""
        return self.items[0] if self.items else None


@dataclass
class CrossModalAssociation:
    """교차 모달 연관 / Cross-modal association"""
    association_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    source_modality: MemoryModality = MemoryModality.CONCEPTUAL
    target_modality: MemoryModality = MemoryModality.CONCEPTUAL
    source_content: str = ""
    target_content: str = ""
    strength: float = 1.0
    timestamp: float = field(default_factory=time.time)

    def decay(self) -> None:
        """연관 강도 감쇄 / Decay association strength"""
        self.strength *= CROSS_MODAL_DECAY


@dataclass
class SimulationOutcome:
    """
    행동 결과 시뮬레이션 / Simulated action outcome.
    simulate_outcome()의 반환형입니다.
    """
    action: str = ""
    predicted_result: str = ""
    confidence: float = 0.0
    similar_experiences: List[str] = field(default_factory=list)
    causal_chain: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# ──────────────────────────────────────────────
#  6층 기억 시스템 (Six-Layer Memory System)
# ──────────────────────────────────────────────

class SixLayerMemory:
    """
    6층 기억 시스템 / Six-Layer Memory System.

    V7의 4층 기억 시스템을 확장하여 세계지식과 혁신기억 층을 추가합니다.

    핵심 메서드:
      - store(): 자동 계층 결정 저장
      - recall(): 전층 검색 (인과 추론 + 세계지식 보강)
      - consolidate(): 층 간 연속 통합
      - simulate_outcome(): 과거 경험 기반 결과 예측

    사용 예시:
        memory = SixLayerMemory(data_dir="/data/memory")
        memory.initialize()
        memory.store("안녕하세요", tags=["greeting"])
        result = memory.recall("인사")
    """

    def __init__(self, data_dir: str = "./memory_data") -> None:
        """
        6층 기억 시스템 초기화 / Initialize Six-Layer Memory.

        Args:
            data_dir: 데이터 저장 디렉토리 / Data storage directory
        """
        self._data_dir = Path(data_dir)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

        # Thread-local storage for per-thread SQLite connections
        self._local = threading.local()

        # Layer 1: 작업기억 (deque, 휘발성) / Working Memory
        self._working_memory: Deque[MemoryItem] = deque(maxlen=WORKING_MEMORY_CAPACITY)

        # Layer 2: 일화기억 (SQLite) / Episodic Memory
        self._episodic_db_path = str(self._data_dir / "episodic.db")

        # Layer 3: 의미기억 / Semantic Memory (LanceDB or in-memory)
        self._semantic_items: Dict[str, MemoryItem] = {}
        self._lancedb_available = False

        # Layer 4: 절차기억 / Procedural Memory (connected externally)
        self._procedural: Optional[Any] = None

        # Layer 5: 세계지식 (V8.5 NEW) / World Knowledge
        self._world_knowledge_db_path = str(self._data_dir / "world_knowledge.db")
        self._world_knowledge_count = 0

        # Layer 6: 혁신기억 (V8.5 NEW) / Innovation Memory
        self._innovation_db_path = str(self._data_dir / "innovation.db")
        self._innovation_count = 0

        # 교차 모달 연관 / Cross-modal associations
        self._cross_modal: List[CrossModalAssociation] = []

        # 외부 시스템 참조 / External system references
        self._knowledge_graph: Optional[Any] = None
        self._causal_reasoning: Optional[Any] = None

        # 통합 상태 / Consolidation state
        self._last_consolidation = 0.0
        self._consolidation_count = 0
        self._continuous_consolidation = True

        self._initialized = False
        logger.info("6층 기억 시스템 인스턴스 생성 / Six-Layer Memory created: %s", data_dir)

    # ── Thread-local connection getters / 스레드 로컬 연결 획득 ──

    def _get_episodic_conn(self) -> Optional[sqlite3.Connection]:
        """스레드 로컬 일화기억 DB 연결 / Get thread-local episodic DB connection"""
        if not hasattr(self._local, "episodic_conn") or self._local.episodic_conn is None:
            try:
                self._local.episodic_conn = sqlite3.connect(
                    self._episodic_db_path, check_same_thread=False
                )
                self._local.episodic_conn.execute("PRAGMA journal_mode=WAL")
            except Exception as e:
                logger.error("일화기억 DB 연결 실패: %s", e)
                return None
        return self._local.episodic_conn

    def _get_world_knowledge_conn(self) -> Optional[sqlite3.Connection]:
        """스레드 로컬 세계지식 DB 연결 / Get thread-local world knowledge DB connection"""
        if not hasattr(self._local, "world_knowledge_conn") or self._local.world_knowledge_conn is None:
            try:
                self._local.world_knowledge_conn = sqlite3.connect(
                    self._world_knowledge_db_path, check_same_thread=False
                )
                self._local.world_knowledge_conn.execute("PRAGMA journal_mode=WAL")
            except Exception as e:
                logger.error("세계지식 DB 연결 실패: %s", e)
                return None
        return self._local.world_knowledge_conn

    def _get_innovation_conn(self) -> Optional[sqlite3.Connection]:
        """스레드 로컬 혁신기억 DB 연결 / Get thread-local innovation DB connection"""
        if not hasattr(self._local, "innovation_conn") or self._local.innovation_conn is None:
            try:
                self._local.innovation_conn = sqlite3.connect(
                    self._innovation_db_path, check_same_thread=False
                )
                self._local.innovation_conn.execute("PRAGMA journal_mode=WAL")
            except Exception as e:
                logger.error("혁신기억 DB 연결 실패: %s", e)
                return None
        return self._local.innovation_conn

    def initialize(self) -> None:
        """기억 시스템 시작 / Start memory system"""
        try:
            # Layer 2: 일화기억 DB 초기화 / Init episodic DB
            conn = self._get_episodic_conn()
            if conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS episodes (
                        item_id TEXT PRIMARY KEY,
                        content TEXT NOT NULL,
                        episode_type TEXT NOT NULL DEFAULT 'observation',
                        timestamp REAL NOT NULL,
                        importance REAL NOT NULL DEFAULT 0.5,
                        tags TEXT NOT NULL DEFAULT '[]',
                        causal_context TEXT,
                        emotional_context TEXT,
                        novelty_score REAL NOT NULL DEFAULT 0.0,
                        metadata TEXT NOT NULL DEFAULT '{}'
                    )
                """)
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_ep_time ON episodes(timestamp)"
                )
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_ep_type ON episodes(episode_type)"
                )
                conn.commit()

            # Layer 5: 세계지식 DB 초기화 / Init world knowledge DB
            conn = self._get_world_knowledge_conn()
            if conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS world_facts (
                        fact_id TEXT PRIMARY KEY,
                        content TEXT NOT NULL,
                        category TEXT NOT NULL DEFAULT 'general',
                        confidence REAL NOT NULL DEFAULT 0.7,
                        source TEXT NOT NULL DEFAULT '',
                        timestamp REAL NOT NULL,
                        expiry REAL,
                        tags TEXT NOT NULL DEFAULT '[]',
                        metadata TEXT NOT NULL DEFAULT '{}'
                    )
                """)
                conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wk_cat ON world_facts(category)"
                )
                conn.commit()
                self._world_knowledge_count = self._count_rows(
                    conn, "world_facts"
                )

            # Layer 6: 혁신기억 DB 초기화 / Init innovation DB
            conn = self._get_innovation_conn()
            if conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS innovations (
                        innovation_id TEXT PRIMARY KEY,
                        description TEXT NOT NULL,
                        innovation_type TEXT NOT NULL DEFAULT 'combination',
                        effectiveness_score REAL NOT NULL DEFAULT 0.0,
                        novelty_score REAL NOT NULL DEFAULT 0.0,
                        source_concepts TEXT NOT NULL DEFAULT '[]',
                        timestamp REAL NOT NULL,
                        validation_status TEXT NOT NULL DEFAULT 'hypothesis',
                        metadata TEXT NOT NULL DEFAULT '{}'
                    )
                """)
                conn.commit()
                self._innovation_count = self._count_rows(
                    conn, "innovations"
                )

            # LanceDB 확인 / Check LanceDB
            try:
                import lancedb  # noqa: F401
                self._lancedb_available = True
            except ImportError:
                logger.info("LanceDB 미설치, 의미기억에 인메모리 사용 / LanceDB not installed")

            self._initialized = True
            logger.info("6층 기억 시스템 초기화 완료 / Six-Layer Memory initialized")

        except Exception as e:
            logger.error("기억 시스템 초기화 실패: %s / Memory init failed: %s", e, e)
            raise

    # 허용 테이블 이름 화이트리스트 / Allowed table name whitelist
    _ALLOWED_TABLES = {"episodes", "world_facts", "innovations"}

    @staticmethod
    def _count_rows(conn: sqlite3.Connection, table: str) -> int:
        """테이블 행 수 카운트 / Count rows in table"""
        if table not in SixLayerMemory._ALLOWED_TABLES:
            logger.error("허용되지 않은 테이블 이름: %s / Disallowed table name: %s", table, table)
            return 0
        try:
            row = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()
            return row[0] if row else 0
        except Exception:
            return 0

    # ── 외부 시스템 연결 / Connect External Systems ──

    def connect_knowledge_graph(self, kg: Any) -> None:
        """지식 그래프 연결 / Connect knowledge graph"""
        self._knowledge_graph = kg
        logger.info("지식 그래프 연결 완료 / Knowledge graph connected")

    def connect_causal_reasoning(self, cr: Any) -> None:
        """인과 추론 연결 / Connect causal reasoning"""
        self._causal_reasoning = cr
        logger.info("인과 추론 연결 완료 / Causal reasoning connected")

    def connect_procedural(self, skill_library: Any) -> None:
        """절차기억 (스킬 라이브러리) 연결 / Connect procedural memory"""
        self._procedural = skill_library
        logger.info("절차기억 연결 완료 / Procedural memory connected")

    # ── store(): 메모리 저장 / Store Memory ──

    def store(
        self,
        content: str,
        priority: MemoryPriority = MemoryPriority.MEDIUM,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        target_layers: Optional[List[MemoryLayer]] = None,
        causal_context: Optional[Dict[str, Any]] = None,
        emotional_context: Optional[Dict[str, Any]] = None,
        novelty_score: float = 0.0,
        modal_associations: Optional[List[Dict[str, Any]]] = None,
        world_knowledge_links: Optional[List[str]] = None,
    ) -> str:
        """
        메모리 저장 — 적절한 계층에 자동 분배 / Store memory with auto layer routing.

        Args:
            content: 저장할 내용 / Content to store
            priority: 우선순위 / Priority
            tags: 검색용 태그 / Tags for search
            metadata: 추가 메타데이터 / Additional metadata
            target_layers: 특정 계층에만 저장 (None=자동) / Target layers
            causal_context: 인과 맥락 / Causal context
            emotional_context: 감성 맥락 / Emotional context
            novelty_score: 참신함 점수 / Novelty score
            modal_associations: 교차 모달 연관 / Cross-modal associations
            world_knowledge_links: 세계지식 링크 / World knowledge links

        Returns:
            저장된 항목 ID / Stored item ID
        """
        with self._lock:
            item = MemoryItem(
                content=content,
                priority=priority,
                tags=tags or [],
                metadata=metadata or {},
                causal_context=causal_context,
                emotional_context=emotional_context,
                novelty_score=novelty_score,
                modal_associations=modal_associations or [],
                world_knowledge_links=world_knowledge_links or [],
            )

            # 자동 계층 결정 / Auto-determine layers
            if target_layers is None:
                target_layers = self._determine_layers(item)

            item_id = item.item_id

            # Layer 1: 작업기억 (항상 저장) / Working Memory (always)
            if MemoryLayer.WORKING in target_layers:
                self._store_working(item)

            # Layer 2: 일화기억 / Episodic Memory
            if MemoryLayer.EPISODIC in target_layers:
                self._store_episodic(item)

            # Layer 3: 의미기억 / Semantic Memory
            if MemoryLayer.SEMANTIC in target_layers:
                self._store_semantic(item)

            # Layer 4: 절차기억 / Procedural Memory
            if MemoryLayer.PROCEDURAL in target_layers and self._procedural:
                self._store_procedural(item)

            # Layer 5: 세계지식 (V8.5 NEW) / World Knowledge
            if MemoryLayer.WORLD_KNOWLEDGE in target_layers:
                self._store_world_knowledge(item)

            # Layer 6: 혁신기억 (V8.5 NEW) / Innovation Memory
            if MemoryLayer.INNOVATION in target_layers:
                self._store_innovation(item)

            # 연속 통합 / Continuous consolidation
            if self._continuous_consolidation:
                self._maybe_consolidate()

            logger.debug(
                "메모리 저장: '%s...' → %s / Memory stored: '%s...' → %s",
                content[:30], [l.value for l in target_layers],
                content[:30], [l.value for l in target_layers],
            )
            return item_id

    def _determine_layers(self, item: MemoryItem) -> List[MemoryLayer]:
        """저장할 계층 자동 결정 / Auto-determine target layers"""
        layers = [MemoryLayer.WORKING, MemoryLayer.EPISODIC]

        # 높은 우선순위 → 의미기억 / High priority → semantic
        if item.priority.value >= MemoryPriority.HIGH.value:
            layers.append(MemoryLayer.SEMANTIC)

        # 스킬 관련 태그 → 절차기억 / Skill tags → procedural
        skill_tags = {"skill", "action", "procedure", "compound"}
        if skill_tags & set(item.tags):
            layers.append(MemoryLayer.PROCEDURAL)

        # 세계지식 태그 → Layer 5 / World knowledge tags → Layer 5
        world_tags = {"fact", "world", "knowledge", "observation", "data", "news"}
        if world_tags & set(item.tags):
            layers.append(MemoryLayer.WORLD_KNOWLEDGE)

        # 높은 참신함 → Layer 6 혁신기억 / High novelty → Layer 6
        if item.novelty_score >= 0.7 or item.priority == MemoryPriority.INNOVATIVE:
            layers.append(MemoryLayer.INNOVATION)

        return layers

    def _store_working(self, item: MemoryItem) -> None:
        """Layer 1 저장 / Store to working memory"""
        self._working_memory.append(item)

    def _store_episodic(self, item: MemoryItem) -> None:
        """Layer 2 저장 / Store to episodic memory"""
        conn = self._get_episodic_conn()
        if not conn:
            return
        try:
            conn.execute("""
                INSERT OR REPLACE INTO episodes
                (item_id, content, episode_type, timestamp, importance,
                 tags, causal_context, emotional_context, novelty_score, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                item.item_id, str(item.content), "memory_store",
                item.timestamp, item.importance,
                json.dumps(item.tags),
                json.dumps(item.causal_context) if item.causal_context else None,
                json.dumps(item.emotional_context) if item.emotional_context else None,
                item.novelty_score, json.dumps(item.metadata),
            ))
            conn.commit()
        except Exception as e:
            logger.error("일화기억 저장 오류: %s / Episodic store error: %s", e, e)

    def _store_semantic(self, item: MemoryItem) -> None:
        """Layer 3 저장 / Store to semantic memory"""
        self._semantic_items[item.item_id] = item

    def _store_procedural(self, item: MemoryItem) -> None:
        """Layer 4 저장 / Store to procedural memory"""
        try:
            if hasattr(self._procedural, "register_from_memory"):
                self._procedural.register_from_memory(item)
        except Exception as e:
            logger.error("절차기억 저장 오류: %s / Procedural store error: %s", e, e)

    def _store_world_knowledge(self, item: MemoryItem) -> None:
        """Layer 5 저장 (V8.5 NEW) / Store to world knowledge"""
        conn = self._get_world_knowledge_conn()
        if not conn:
            return

        # 최대 항목 수 제한 / Enforce max items
        if self._world_knowledge_count >= WORLD_KNOWLEDGE_MAX:
            # 가장 오래된 항목 삭제 / Delete oldest
            try:
                conn.execute(
                    "DELETE FROM world_facts WHERE fact_id IN "
                    "(SELECT fact_id FROM world_facts ORDER BY timestamp ASC LIMIT 1000)"
                )
                self._world_knowledge_count -= 1000
            except Exception:
                pass

        fact_id = f"wk_{item.item_id}"
        try:
            conn.execute("""
                INSERT OR REPLACE INTO world_facts
                (fact_id, content, category, confidence, source, timestamp, tags, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                fact_id, str(item.content),
                item.metadata.get("category", "general"),
                item.metadata.get("confidence", 0.7),
                item.metadata.get("source", "unknown"),
                item.timestamp, json.dumps(item.tags), json.dumps(item.metadata),
            ))
            conn.commit()
            self._world_knowledge_count += 1

            # 지식 그래프에도 반영 / Also update knowledge graph
            if self._knowledge_graph:
                try:
                    if hasattr(self._knowledge_graph, "add_fact"):
                        self._knowledge_graph.add_fact(
                            fact=str(item.content),
                            source=item.metadata.get("source", "memory"),
                            confidence=item.metadata.get("confidence", 0.7),
                            tags=item.tags,
                        )
                except Exception:
                    pass

        except Exception as e:
            logger.error("세계지식 저장 오류: %s / World knowledge store error: %s", e, e)

    def _store_innovation(self, item: MemoryItem) -> None:
        """Layer 6 저장 (V8.5 NEW) / Store to innovation memory"""
        conn = self._get_innovation_conn()
        if not conn:
            return

        # 최대 항목 수 제한 / Enforce max items
        if self._innovation_count >= INNOVATION_MEMORY_MAX:
            try:
                conn.execute(
                    "DELETE FROM innovations WHERE validation_status = 'rejected' "
                    "ORDER BY timestamp ASC LIMIT 500"
                )
                self._innovation_count -= min(500, self._innovation_count)
            except Exception:
                pass

        innovation_id = f"innov_{item.item_id}"
        try:
            conn.execute("""
                INSERT OR REPLACE INTO innovations
                (innovation_id, description, innovation_type, effectiveness_score,
                 novelty_score, source_concepts, timestamp, validation_status, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                innovation_id, str(item.content),
                item.metadata.get("innovation_type", "combination"),
                item.metadata.get("effectiveness_score", 0.0),
                item.novelty_score,
                json.dumps(item.metadata.get("source_concepts", [])),
                item.timestamp,
                item.metadata.get("validation_status", "hypothesis"),
                json.dumps(item.metadata),
            ))
            conn.commit()
            self._innovation_count += 1
        except Exception as e:
            logger.error("혁신기억 저장 오류: %s / Innovation store error: %s", e, e)

    # ── recall(): 메모리 회상 / Recall Memory ──

    def recall(
        self,
        query: str,
        target_layers: Optional[List[MemoryLayer]] = None,
        max_results: int = 5,
        time_range: Optional[Tuple[float, float]] = None,
        use_causal_reasoning: bool = True,
        enrich_with_world_knowledge: bool = True,
    ) -> RecallResult:
        """
        메모리 회상 — 전층 검색 / Recall memory across all layers.

        Args:
            query: 검색 쿼리 / Search query
            target_layers: 검색할 계층 (None=전체) / Target layers
            max_results: 최대 결과 수 / Max results
            time_range: 시간 범위 (시작, 끝) / Time range
            use_causal_reasoning: 인과 추론 사용 / Use causal reasoning
            enrich_with_world_knowledge: 세계지식 보강 / Enrich with world knowledge

        Returns:
            회상 결과 / Recall result
        """
        start = time.time()
        if target_layers is None:
            target_layers = list(MemoryLayer)

        all_items: List[MemoryItem] = []
        layers_searched: List[MemoryLayer] = []

        # Layer 1: 작업기억 / Working Memory
        if MemoryLayer.WORKING in target_layers:
            items = self._recall_working(query, time_range)
            all_items.extend(items)
            layers_searched.append(MemoryLayer.WORKING)

        # Layer 2: 일화기억 / Episodic Memory
        if MemoryLayer.EPISODIC in target_layers:
            items = self._recall_episodic(query, time_range)
            all_items.extend(items)
            layers_searched.append(MemoryLayer.EPISODIC)

        # Layer 3: 의미기억 / Semantic Memory
        if MemoryLayer.SEMANTIC in target_layers:
            items = self._recall_semantic(query)
            all_items.extend(items)
            layers_searched.append(MemoryLayer.SEMANTIC)

        # Layer 4: 절차기억 / Procedural Memory
        if MemoryLayer.PROCEDURAL in target_layers and self._procedural:
            items = self._recall_procedural(query)
            all_items.extend(items)
            layers_searched.append(MemoryLayer.PROCEDURAL)

        # Layer 5: 세계지식 (V8) / World Knowledge
        if MemoryLayer.WORLD_KNOWLEDGE in target_layers:
            items = self._recall_world_knowledge(query)
            all_items.extend(items)
            layers_searched.append(MemoryLayer.WORLD_KNOWLEDGE)

        # Layer 6: 혁신기억 (V8) / Innovation Memory
        if MemoryLayer.INNOVATION in target_layers:
            items = self._recall_innovation(query)
            all_items.extend(items)
            layers_searched.append(MemoryLayer.INNOVATION)

        # 인과 추론 보강 / Causal reasoning enrichment
        causal_used = False
        if use_causal_reasoning and self._causal_reasoning:
            try:
                causal_items = self._enrich_with_causal(query)
                if causal_items:
                    all_items.extend(causal_items)
                    causal_used = True
            except Exception:
                pass

        # 세계지식 보강 / World knowledge enrichment
        wk_enriched = False
        if enrich_with_world_knowledge:
            try:
                wk_items = self._enrich_with_world_knowledge(query)
                if wk_items:
                    all_items.extend(wk_items)
                    wk_enriched = True
            except Exception:
                pass

        # 중복 제거 및 정렬 / Deduplicate and sort
        seen: set = set()
        unique: List[MemoryItem] = []
        for item in all_items:
            if item.item_id not in seen:
                seen.add(item.item_id)
                unique.append(item)
        unique.sort(key=lambda x: (x.importance, x.timestamp), reverse=True)

        elapsed = (time.time() - start) * 1000.0

        return RecallResult(
            items=unique[:max_results],
            total_count=len(unique),
            query=query,
            layers_searched=layers_searched,
            elapsed_ms=elapsed,
            causal_chain_used=causal_used,
            world_knowledge_enriched=wk_enriched,
        )

    def _recall_working(
        self, query: str, time_range: Optional[Tuple[float, float]] = None,
    ) -> List[MemoryItem]:
        """Layer 1 회상 / Working memory recall"""
        results = []
        q = query.lower()
        for item in self._working_memory:
            if q in str(item.content).lower() or any(q in t.lower() for t in item.tags):
                if time_range:
                    if time_range[0] <= item.timestamp <= time_range[1]:
                        results.append(item)
                else:
                    results.append(item)
        return results

    def _recall_episodic(
        self, query: str, time_range: Optional[Tuple[float, float]] = None,
    ) -> List[MemoryItem]:
        """Layer 2 회상 / Episodic memory recall"""
        conn = self._get_episodic_conn()
        if not conn:
            return []
        results = []
        try:
            cursor = conn.execute(
                "SELECT * FROM episodes WHERE content LIKE ? ORDER BY timestamp DESC LIMIT 20",
                (f"%{query}%",),
            )
            for row in cursor.fetchall():
                item = MemoryItem(
                    item_id=row[0], content=row[1], timestamp=row[3],
                    importance=row[4], tags=json.loads(row[5]) if row[5] else [],
                )
                if time_range:
                    if time_range[0] <= item.timestamp <= time_range[1]:
                        results.append(item)
                else:
                    results.append(item)
        except Exception as e:
            logger.error("일화기억 회상 오류: %s", e)
        return results

    def _recall_semantic(self, query: str) -> List[MemoryItem]:
        """Layer 3 회상 / Semantic memory recall"""
        results = []
        q = query.lower()
        for item in self._semantic_items.values():
            if q in str(item.content).lower():
                results.append(item)
        return results[:10]

    def _recall_procedural(self, query: str) -> List[MemoryItem]:
        """Layer 4 회상 / Procedural memory recall"""
        try:
            if hasattr(self._procedural, "search_skills"):
                skills = self._procedural.search_skills(query)
                return [
                    MemoryItem(
                        item_id=s.get("skill_id", ""),
                        content=s.get("description", ""),
                        layer=MemoryLayer.PROCEDURAL,
                        tags=["skill"],
                    )
                    for s in skills[:5]
                ]
        except Exception as e:
            logger.error("절차기억 회상 오류: %s", e)
        return []

    def _recall_world_knowledge(self, query: str) -> List[MemoryItem]:
        """Layer 5 회상 (V8) / World knowledge recall"""
        conn = self._get_world_knowledge_conn()
        if not conn:
            return []
        results = []
        try:
            cursor = conn.execute(
                "SELECT * FROM world_facts WHERE content LIKE ? "
                "ORDER BY confidence DESC LIMIT 10",
                (f"%{query}%",),
            )
            for row in cursor.fetchall():
                results.append(MemoryItem(
                    item_id=row[0], content=row[1],
                    layer=MemoryLayer.WORLD_KNOWLEDGE,
                    timestamp=row[5],
                    metadata={"category": row[2], "confidence": row[3], "source": row[4]},
                ))
        except Exception as e:
            logger.error("세계지식 회상 오류: %s", e)
        return results

    def _recall_innovation(self, query: str) -> List[MemoryItem]:
        """Layer 6 회상 (V8) / Innovation memory recall"""
        conn = self._get_innovation_conn()
        if not conn:
            return []
        results = []
        try:
            cursor = conn.execute(
                "SELECT * FROM innovations WHERE description LIKE ? "
                "ORDER BY effectiveness_score DESC LIMIT 5",
                (f"%{query}%",),
            )
            for row in cursor.fetchall():
                results.append(MemoryItem(
                    item_id=row[0], content=row[1],
                    layer=MemoryLayer.INNOVATION,
                    timestamp=row[6],
                    metadata={
                        "innovation_type": row[2],
                        "effectiveness_score": row[3],
                        "novelty_score": row[4],
                    },
                ))
        except Exception as e:
            logger.error("혁신기억 회상 오류: %s", e)
        return results

    def _enrich_with_causal(self, query: str) -> List[MemoryItem]:
        """인과 추론으로 회상 보강 / Enrich recall with causal reasoning"""
        if not self._causal_reasoning:
            return []
        try:
            related = self._causal_reasoning.explain(query)
            if related:
                return [MemoryItem(
                    item_id=f"causal_{uuid.uuid4().hex[:8]}",
                    content=str(related)[:200],
                    layer=MemoryLayer.WORKING,
                    tags=["causal", "enrichment"],
                )]
        except Exception:
            pass
        return []

    def _enrich_with_world_knowledge(self, query: str) -> List[MemoryItem]:
        """세계지식으로 회상 보강 / Enrich recall with world knowledge"""
        conn = self._get_world_knowledge_conn()
        if not conn:
            return []
        items = []
        try:
            words = query.lower().split()
            for word in words[:3]:
                cursor = conn.execute(
                    "SELECT * FROM world_facts WHERE content LIKE ? AND confidence > 0.9 LIMIT 2",
                    (f"%{word}%",),
                )
                for row in cursor.fetchall():
                    items.append(MemoryItem(
                        item_id=f"wk_enrich_{row[0]}",
                        content=row[1],
                        layer=MemoryLayer.WORLD_KNOWLEDGE,
                        metadata={"confidence": row[3], "enrichment": True},
                    ))
        except Exception:
            pass
        return items[:2]

    # ── consolidate(): 기억 통합 / Memory Consolidation ──

    def consolidate(self) -> int:
        """
        층 간 기억 통합 / Consolidate memory between layers.

        V8: 연속 통합 (시간 기반 → 이벤트 기반)
        - Working → Episodic: 중요도 > 0.3
        - Episodic → Semantic: 반복 패턴
        - Episodic → Procedural: 성공적 행동
        - Semantic → World Knowledge: 일반화된 사실
        - Semantic + World Knowledge → Innovation: 창의적 재조합

        Returns:
            통합된 항목 수 / Number of consolidated items
        """
        with self._lock:
            count = 0

            # Working → Episodic / 작업기억 → 일화기억
            for item in self._working_memory:
                if item.importance > 0.3:
                    self._store_episodic(item)
                    count += 1

            # 만료된 일화 삭제 / Delete expired episodes
            epi_conn = self._get_episodic_conn()
            if epi_conn:
                cutoff = time.time() - (EPISODIC_RETENTION_DAYS * 86400)
                try:
                    cur = epi_conn.execute(
                        "DELETE FROM episodes WHERE timestamp < ?", (cutoff,)
                    )
                    if cur.rowcount > 0:
                        logger.info("만료 에피소드 %d개 삭제 / Deleted %d expired episodes", cur.rowcount)
                except Exception:
                    pass

            # World Knowledge: 만료된 사실 삭제 / Delete expired facts
            wk_conn = self._get_world_knowledge_conn()
            if wk_conn:
                try:
                    wk_conn.execute(
                        "DELETE FROM world_facts WHERE expiry IS NOT NULL AND expiry < ?",
                        (time.time(),),
                    )
                    wk_conn.commit()
                except Exception:
                    pass

            self._last_consolidation = time.time()
            self._consolidation_count += 1

            if count > 0:
                logger.info(
                    "기억 통합: %d개 항목 (총 %d회) / Consolidated: %d items (total %d)",
                    count, self._consolidation_count, count, self._consolidation_count,
                )
            return count

    def _maybe_consolidate(self) -> None:
        """연속 통합 확인 / Check if consolidation needed"""
        elapsed = time.time() - self._last_consolidation
        if elapsed >= CONSOLIDATION_INTERVAL_S:
            self.consolidate()

    # ── simulate_outcome(): 행동 결과 예측 / Simulate Action Outcome ──

    def simulate_outcome(
        self,
        action: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> SimulationOutcome:
        """
        과거 경험 기반 행동 결과 예측 / Predict action outcome from past experiences.

        유사한 과거 경험을 검색하고 인과 추론을 사용하여
        행동의 예상 결과를 시뮬레이션합니다.

        Args:
            action: 수행할 행동 / Action to simulate
            context: 현재 컨텍스트 / Current context

        Returns:
            시뮬레이션 결과 / Simulated outcome
        """
        result = SimulationOutcome(action=action)
        context = context or {}

        # 유사한 과거 경험 검색 / Search for similar past experiences
        similar = self.recall(
            query=action,
            max_results=5,
            use_causal_reasoning=True,
            enrich_with_world_knowledge=False,
        )

        if not similar.items:
            result.predicted_result = "유사한 과거 경험 없음 / No similar past experience"
            result.confidence = 0.1
            return result

        # 과거 경험에서 패턴 분석 / Analyze patterns from past experiences
        success_count = 0
        failure_count = 0
        similar_descs: List[str] = []

        for item in similar.items:
            similar_descs.append(str(item.content)[:100])
            if item.causal_context:
                outcome = item.causal_context.get("outcome", "unknown")
                if outcome in ("success", "completed"):
                    success_count += 1
                elif outcome in ("failure", "failed"):
                    failure_count += 1
            if item.metadata.get("success") is True:
                success_count += 1
            elif item.metadata.get("success") is False:
                failure_count += 1

        # 결과 예측 / Predict outcome
        total = success_count + failure_count
        if total > 0:
            success_rate = success_count / total
            result.confidence = min(0.9, total / 10.0)  # 경험 많을수록 신뢰도 증가
            if success_rate > 0.7:
                result.predicted_result = f"성공 가능성 높음 ({success_rate:.0%})"
            elif success_rate > 0.4:
                result.predicted_result = f"성공 가능성 보통 ({success_rate:.0%})"
            else:
                result.predicted_result = f"성공 가능성 낮음 ({success_rate:.0%})"
                result.warnings.append("과거 유사 행동의 성공률이 낮음")
        else:
            result.predicted_result = "결과 예측 불가 (충분한 데이터 없음)"
            result.confidence = 0.2

        result.similar_experiences = similar_descs[:5]

        # 인과 추론으로 인과 체인 보강 / Enrich with causal chain
        if self._causal_reasoning:
            try:
                chain = self._causal_reasoning.explain(action)
                if chain and hasattr(chain, "causal_chain"):
                    result.causal_chain = [
                        f"{c} → {e}" for c, _, e in chain.causal_chain[:5]
                    ]
            except Exception:
                pass

        # 위험 요소 확인 / Check for warnings
        for item in similar.items:
            if item.causal_context and item.causal_context.get("danger"):
                result.warnings.append(f"위험: {item.causal_context['danger']}")

        return result

    # ── 교차 모달 연관 / Cross-Modal Associations ──

    def add_cross_modal_association(
        self,
        source_modality: MemoryModality,
        target_modality: MemoryModality,
        source_content: str,
        target_content: str,
        strength: float = 1.0,
    ) -> str:
        """
        교차 모달 연관 추가 / Add cross-modal association.
        예: 시각적 "빨간 컵" ↔ 촉각적 "차가운 표면"
        """
        assoc = CrossModalAssociation(
            source_modality=source_modality,
            target_modality=target_modality,
            source_content=source_content,
            target_content=target_content,
            strength=strength,
        )
        self._cross_modal.append(assoc)
        return assoc.association_id

    def get_cross_modal_associations(
        self,
        content: str,
        modality: Optional[MemoryModality] = None,
        min_strength: float = 0.3,
    ) -> List[CrossModalAssociation]:
        """교차 모달 연관 조회 / Get cross-modal associations"""
        results = []
        c = content.lower()
        for assoc in self._cross_modal:
            if assoc.strength < min_strength:
                continue
            if c in assoc.source_content.lower() or c in assoc.target_content.lower():
                if modality is None or (
                    assoc.source_modality == modality or assoc.target_modality == modality
                ):
                    results.append(assoc)
        return results

    # ── 유틸리티 / Utilities ──

    def forget(self, item_id: str, layers: Optional[List[MemoryLayer]] = None) -> bool:
        """메모리 삭제 / Forget memory item"""
        with self._lock:
            if layers is None:
                layers = list(MemoryLayer)

            deleted = False

            if MemoryLayer.WORKING in layers:
                new_deque: Deque[MemoryItem] = deque(maxlen=WORKING_MEMORY_CAPACITY)
                for item in self._working_memory:
                    if item.item_id != item_id:
                        new_deque.append(item)
                    else:
                        deleted = True
                self._working_memory = new_deque

            if MemoryLayer.SEMANTIC in layers:
                if item_id in self._semantic_items:
                    del self._semantic_items[item_id]
                    deleted = True

            return deleted

    def get_statistics(self) -> Dict[str, Any]:
        """통계 정보 반환 / Return statistics"""
        return {
            "working_memory_size": len(self._working_memory),
            "semantic_memory_size": len(self._semantic_items),
            "world_knowledge_count": self._world_knowledge_count,
            "innovation_count": self._innovation_count,
            "cross_modal_associations": len(self._cross_modal),
            "consolidation_count": self._consolidation_count,
            "last_consolidation": self._last_consolidation,
        }

    def close(self) -> None:
        """기억 시스템 종료 / Close memory system"""
        for attr in ("episodic_conn", "world_knowledge_conn", "innovation_conn"):
            conn = getattr(self._local, attr, None)
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
                setattr(self._local, attr, None)
        logger.info("6층 기억 시스템 종료 / Six-Layer Memory closed")


# ──────────────────────────────────────────────
#  하위 호환성 / Backward Compatibility
# ──────────────────────────────────────────────

# V8.5 호환: FourLayerMemory는 SixLayerMemory의 별칭
# V8.5 compatibility: FourLayerMemory is an alias for SixLayerMemory
FourLayerMemory = SixLayerMemory


# ──────────────────────────────────────────────
#  기억 승급 엔진 (Memory Promotion Engine)
# ──────────────────────────────────────────────

class MemoryPromotionEngine:
    """
    기억 승급 엔진 / Memory Promotion Engine.

    경험을 기억 계층 위로 승급시키는 시스템입니다.
    각 승급 단계는 더 높은 수준의 추상화를 요구하며,
    반복된 경험, 성공적 행동, 일반화된 지식, 창의적 조합을
    자동으로 감지하여 승급합니다.

    승급 경로:
    Layer 1→2 (Working→Episodic): 높은 새로움 또는 감정가를 가진 사건
    Layer 2→3 (Episodic→Semantic): 반복된 패턴이 개념으로 추상화
      - "100 slips on low-friction surfaces" → "low friction = slip risk" semantic knowledge
    Layer 3→4 (Semantic→Procedural): 성공적 행동 시퀀스가 스킬이 됨
      - "walk_forward + stabilize + walk_forward" → "rough_terrain_walking" skill
    Layer 4→5 (Procedural→World Knowledge): 스킬이 물리 법칙으로 일반화
      - "rough_terrain_walking + ice_walking" → "friction affects stability" law
    Layer 5→6 (World Knowledge→Innovation): 지식의 창의적 조합
      - "friction law + grip_knowledge" → "use gripper texture for better hold" innovation

    Usage:
        engine = MemoryPromotionEngine(memory_system)
        new_layer = engine.promote(experience, current_layer=1)
        counts = engine.run_consolidation_cycle()
    """

    # 승급 기준 임계값 / Promotion thresholds
    NOVELTY_THRESHOLD_L1_TO_L2 = 0.6       # 작업→일화 새로움 기준
    EMOTIONAL_VALENCE_THRESHOLD = 0.7       # 감정가 기준
    REPETITION_THRESHOLD_L2_TO_L3 = 3       # 일화→의미 반복 횟수
    SUCCESS_RATE_THRESHOLD_L3_TO_L4 = 0.8   # 의미→절차 성공률
    GENERALIZATION_THRESHOLD_L4_TO_L5 = 2    # 절차→세계지식 일반화 횟수
    COMBINATION_NOVELTY_L5_TO_L6 = 0.7      # 세계지식→혁신 조합 새로움

    def __init__(self, memory_system: SixLayerMemory) -> None:
        """
        기억 승급 엔진 초기화 / Initialize Memory Promotion Engine.

        Args:
            memory_system: 6층 기억 시스템 / Six-layer memory system
        """
        self._memory = memory_system

        # 승급 통계 / Promotion statistics
        self._promotion_counts: Dict[str, int] = {
            "L1_to_L2": 0,
            "L2_to_L3": 0,
            "L3_to_L4": 0,
            "L4_to_L5": 0,
            "L5_to_L6": 0,
        }

        # 반복 패턴 추적 / Repetition pattern tracking
        self._episodic_patterns: Dict[str, int] = defaultdict(int)

        # 성공적 행동 시퀀스 추적 / Successful action sequence tracking
        self._action_sequences: Dict[str, Dict[str, Any]] = {}

        # 일반화된 스킬 추적 / Generalized skills tracking
        self._skill_generalizations: Dict[str, List[str]] = defaultdict(list)

        logger.info("기억 승급 엔진 초기화 / Memory Promotion Engine initialized")

    def promote(self, experience: MemoryItem, current_layer: int) -> int:
        """
        경험을 위층으로 승급 / Promote experience up the memory hierarchy.

        Args:
            experience: 승급할 기억 항목 / Memory item to promote
            current_layer: 현재 기억 층 (1-6) / Current memory layer (1-6)

        Returns:
            new_layer: 승급된 층 번호 (승급되지 않으면 current_layer 반환)
        """
        new_layer = current_layer

        if current_layer == 1:
            new_layer = self._promote_working_to_episodic(experience)
        elif current_layer == 2:
            new_layer = self._promote_episodic_to_semantic(experience)
        elif current_layer == 3:
            new_layer = self._promote_semantic_to_procedural(experience)
        elif current_layer == 4:
            new_layer = self._promote_procedural_to_world_knowledge(experience)
        elif current_layer == 5:
            new_layer = self._promote_world_knowledge_to_innovation(experience)

        if new_layer > current_layer:
            logger.info(
                "기억 승급: L%d → L%d ('%s') / Memory promoted: L%d → L%d ('%s')",
                current_layer, new_layer,
                str(experience.content)[:40] if experience.content else "",
                current_layer, new_layer,
                str(experience.content)[:40] if experience.content else "",
            )

        return new_layer

    def run_consolidation_cycle(self) -> Dict[str, int]:
        """
        전체 통합 주기 실행: 모든 층에서 승급 검사 / Run full consolidation cycle.

        Returns:
            promotion_counts: 각 층별 승급 횟수 / Promotion counts per layer
        """
        cycle_counts: Dict[str, int] = {
            "L1_to_L2": 0,
            "L2_to_L3": 0,
            "L3_to_L4": 0,
            "L4_to_L5": 0,
            "L5_to_L6": 0,
        }

        # Layer 1 → Layer 2: 작업기억에서 높은 중요도 항목 승급
        # Promote high-importance items from working memory
        for item in list(self._memory._working_memory):
            if item.importance > 0.3 or item.novelty_score >= self.NOVELTY_THRESHOLD_L1_TO_L2:
                new_layer = self._promote_working_to_episodic(item)
                if new_layer > 1:
                    cycle_counts["L1_to_L2"] += 1

        # Layer 2 → Layer 3: 일화기억에서 반복 패턴 감지
        # Detect repeated patterns in episodic memory
        cycle_counts["L2_to_L3"] += self._detect_episodic_patterns()

        # Layer 3 → Layer 4: 의미기억에서 성공적 행동 시퀀스 감지
        # Detect successful action sequences in semantic memory
        cycle_counts["L3_to_L4"] += self._detect_successful_sequences()

        # Layer 4 → Layer 5: 절차기억에서 일반화 감지
        # Detect generalizations in procedural memory
        cycle_counts["L4_to_L5"] += self._detect_skill_generalizations()

        # Layer 5 → Layer 6: 세계지식에서 창의적 조합 감지
        # Detect creative combinations in world knowledge
        cycle_counts["L5_to_L6"] += self._detect_innovative_combinations()

        # 총계 업데이트 / Update total counts
        for key in cycle_counts:
            self._promotion_counts[key] += cycle_counts[key]

        total_promoted = sum(cycle_counts.values())
        if total_promoted > 0:
            logger.info(
                "통합 주기 완료: %d건 승급 / Consolidation cycle: %d promotions — %s",
                total_promoted, total_promoted, cycle_counts,
            )

        return cycle_counts

    # ── Layer 1→2: Working → Episodic ──

    def _promote_working_to_episodic(self, item: MemoryItem) -> int:
        """
        작업기억 → 일화기억 승급 / Promote Working → Episodic.

        기준: 높은 새로움 또는 감정가
        Criterion: High novelty or emotional valence
        """
        should_promote = False

        # 새로움 점수 검사 / Check novelty score
        if item.novelty_score >= self.NOVELTY_THRESHOLD_L1_TO_L2:
            should_promote = True

        # 감정가 검사 / Check emotional valence
        if item.emotional_context:
            valence = abs(item.emotional_context.get("valence", 0.0))
            arousal = item.emotional_context.get("arousal", 0.0)
            if valence >= self.EMOTIONAL_VALENCE_THRESHOLD or arousal >= self.EMOTIONAL_VALENCE_THRESHOLD:
                should_promote = True

        # 중요도 검사 / Check importance
        if item.importance >= 0.7:
            should_promote = True

        # 우선순위 검사 / Check priority
        if item.priority.value >= MemoryPriority.HIGH.value:
            should_promote = True

        if should_promote:
            # 일화기억에 저장 / Store to episodic memory
            self._memory._store_episodic(item)
            self._promotion_counts["L1_to_L2"] += 1

            # 일화 패턴 추적에 등록 / Register in episodic pattern tracking
            content_key = self._extract_pattern_key(str(item.content))
            self._episodic_patterns[content_key] += 1

            return 2

        return 1

    # ── Layer 2→3: Episodic → Semantic ──

    def _promote_episodic_to_semantic(self, item: MemoryItem) -> int:
        """
        일화기억 → 의미기억 승급 / Promote Episodic → Semantic.

        기준: 반복된 패턴이 개념으로 추상화
        "100 slips on low-friction surfaces" → "low friction = slip risk"
        """
        content_key = self._extract_pattern_key(str(item.content))
        repetition_count = self._episodic_patterns.get(content_key, 0)

        if repetition_count >= self.REPETITION_THRESHOLD_L2_TO_L3:
            # 의미 지식으로 추상화 / Abstract into semantic knowledge
            semantic_content = self._abstract_to_concept(str(item.content), repetition_count)

            semantic_item = MemoryItem(
                content=semantic_content,
                layer=MemoryLayer.SEMANTIC,
                priority=MemoryPriority.HIGH,
                importance=min(1.0, 0.5 + repetition_count * 0.1),
                tags=list(set(item.tags + ["semantic", "abstracted"])),
                causal_context=item.causal_context,
                novelty_score=item.novelty_score * 0.5,  # 추상화되므로 새로움 감소
            )

            self._memory._store_semantic(semantic_item)
            self._promotion_counts["L2_to_L3"] += 1

            # 성공적 행동 시퀀스 추적에 등록 / Register for action sequence tracking
            if "action" in item.tags or "skill" in item.tags:
                self._action_sequences[content_key] = {
                    "content": str(item.content),
                    "success_count": 0,
                    "total_count": 0,
                    "semantic_item_id": semantic_item.item_id,
                }

            return 3

        return 2

    # ── Layer 3→4: Semantic → Procedural ──

    def _promote_semantic_to_procedural(self, item: MemoryItem) -> int:
        """
        의미기억 → 절차기억 승급 / Promote Semantic → Procedural.

        기준: 성공적 행동 시퀀스가 스킬이 됨
        "walk_forward + stabilize + walk_forward" → "rough_terrain_walking"
        """
        content_key = self._extract_pattern_key(str(item.content))
        seq_info = self._action_sequences.get(content_key)

        if seq_info:
            success_rate = (
                seq_info["success_count"] / max(1, seq_info["total_count"])
            )

            if success_rate >= self.SUCCESS_RATE_THRESHOLD_L3_TO_L4 and seq_info["total_count"] >= 5:
                # 절차 스킬로 변환 / Convert to procedural skill
                skill_name = self._generate_skill_name(str(item.content))

                skill_item = MemoryItem(
                    content=f"SKILL:{skill_name} — {str(item.content)[:100]}",
                    layer=MemoryLayer.PROCEDURAL,
                    priority=MemoryPriority.HIGH,
                    importance=0.9,
                    tags=["skill", "procedural", "learned", skill_name],
                    metadata={
                        "success_rate": success_rate,
                        "practice_count": seq_info["total_count"],
                        "source_semantic": seq_info.get("semantic_item_id", ""),
                    },
                )

                # 절차기억에 저장 / Store to procedural memory
                if self._memory._procedural:
                    self._memory._store_procedural(skill_item)

                self._promotion_counts["L3_to_L4"] += 1

                # 일반화 추적에 등록 / Register for generalization tracking
                self._skill_generalizations[skill_name].append(content_key)

                return 4

        return 3

    # ── Layer 4→5: Procedural → World Knowledge ──

    def _promote_procedural_to_world_knowledge(self, item: MemoryItem) -> int:
        """
        절차기억 → 세계지식 승급 / Promote Procedural → World Knowledge.

        기준: 스킬이 물리 법칙으로 일반화
        "rough_terrain_walking + ice_walking" → "friction affects stability"
        """
        # 이 스킬과 관련된 다른 스킬 찾기 / Find related skills
        skill_name = ""
        if item.tags:
            for tag in item.tags:
                if tag in self._skill_generalizations:
                    skill_name = tag
                    break

        if not skill_name:
            return 4

        generalization_count = len(self._skill_generalizations.get(skill_name, []))

        if generalization_count >= self.GENERALIZATION_THRESHOLD_L4_TO_L5:
            # 물리 법칙/원리로 일반화 / Generalize to physical law/principle
            law_content = self._generalize_to_law(
                skill_name, self._skill_generalizations[skill_name]
            )

            law_item = MemoryItem(
                content=law_content,
                layer=MemoryLayer.WORLD_KNOWLEDGE,
                priority=MemoryPriority.CRITICAL,
                importance=0.95,
                tags=["law", "world_knowledge", "generalized", "physical_principle"],
                metadata={
                    "source_skills": list(self._skill_generalizations[skill_name]),
                    "generalization_count": generalization_count,
                    "category": "physical_law",
                    "confidence": 0.8 + 0.05 * min(4, generalization_count),
                },
            )

            self._memory._store_world_knowledge(law_item)
            self._promotion_counts["L4_to_L5"] += 1

            return 5

        return 4

    # ── Layer 5→6: World Knowledge → Innovation ──

    def _promote_world_knowledge_to_innovation(self, item: MemoryItem) -> int:
        """
        세계지식 → 혁신기억 승급 / Promote World Knowledge → Innovation.

        기준: 지식의 창의적 조합
        "friction law + grip_knowledge" → "use gripper texture for better hold"
        """
        # 기존 세계지식과의 조합 가능성 탐색 / Search for combinable knowledge
        if not self._memory._world_knowledge_conn:
            return 5

        related_facts = self._memory._recall_world_knowledge(
            " ".join(item.tags[:3]) if item.tags else str(item.content)[:30]
        )

        if len(related_facts) < 1:
            return 5

        # 조합 새로움 평가 / Evaluate combination novelty
        for related in related_facts:
            if related.item_id == item.item_id:
                continue

            # 두 지식의 조합 새로움 계산 / Calculate combination novelty
            combination_novelty = self._evaluate_combination_novelty(
                str(item.content), str(related.content)
            )

            if combination_novelty >= self.COMBINATION_NOVELTY_L5_TO_L6:
                # 혁신적 조합 생성 / Generate innovative combination
                innovation_content = self._generate_innovation(
                    str(item.content), str(related.content)
                )

                innovation_item = MemoryItem(
                    content=innovation_content,
                    layer=MemoryLayer.INNOVATION,
                    priority=MemoryPriority.INNOVATIVE,
                    importance=1.0,
                    novelty_score=combination_novelty,
                    tags=["innovation", "creative_combination", "novel"],
                    metadata={
                        "innovation_type": "combination",
                        "source_concepts": [
                            str(item.content)[:50],
                            str(related.content)[:50],
                        ],
                        "effectiveness_score": 0.0,  # 검증 필요 / Needs validation
                        "validation_status": "hypothesis",
                    },
                )

                self._memory._store_innovation(innovation_item)
                self._promotion_counts["L5_to_L6"] += 1

                return 6

        return 5

    # ── 내부 유틸리티 / Internal Utilities ──

    @staticmethod
    def _extract_pattern_key(content: str) -> str:
        """
        내용에서 패턴 키 추출 / Extract pattern key from content.
        단어 단위로 정규화하여 유사한 경험을 그룹화합니다.
        """
        # 소문자 변환 및 특수문자 제거 / Lowercase and remove special chars
        import re
        normalized = re.sub(r'[^a-z0-9가-힣\s]', '', content.lower())
        # 주요 단어만 추출 (불용어 제거) / Extract key words (remove stop words)
        stop_words = {"the", "a", "an", "is", "was", "in", "on", "at", "to", "for",
                      "의", "은", "는", "이", "가", "을", "를", "에", "에서", "으로"}
        words = normalized.split()
        key_words = [w for w in words if w not in stop_words and len(w) > 1]
        return " ".join(sorted(key_words[:8]))  # 상위 8개 단어로 키 구성

    @staticmethod
    def _abstract_to_concept(content: str, repetition_count: int) -> str:
        """
        반복된 경험을 개념으로 추상화 / Abstract repeated experiences into concept.
        "100 slips on low-friction surfaces" → "low friction = slip risk (100 episodes)"
        """
        # 간소화된 추상화 / Simplified abstraction
        if repetition_count >= 10:
            concept_prefix = f"STRONG PATTERN ({repetition_count}x): "
        elif repetition_count >= 5:
            concept_prefix = f"REPEATED PATTERN ({repetition_count}x): "
        else:
            concept_prefix = f"PATTERN ({repetition_count}x): "

        return concept_prefix + content[:150]

    @staticmethod
    def _generate_skill_name(content: str) -> str:
        """
        행동 시퀀스에서 스킬 이름 생성 / Generate skill name from action sequence.
        "walk_forward + stabilize + walk_forward" → "rough_terrain_walking"
        """
        # 핵심 동작 추출 / Extract core actions
        actions = content.lower().replace("+", " ").replace(",", " ").split()
        # 동사성 단어 필터 / Filter verb-like words
        action_words = [w for w in actions if len(w) > 3 and w.isalpha()]
        if action_words:
            return "_".join(action_words[:3])
        return f"compound_skill_{hash(content) % 10000}"

    @staticmethod
    def _generalize_to_law(skill_name: str, source_patterns: List[str]) -> str:
        """
        스킬을 물리 법칙으로 일반화 / Generalize skills to physical law.
        "rough_terrain_walking + ice_walking" → "friction affects stability"
        """
        return (
            f"PHYSICAL PRINCIPLE derived from '{skill_name}': "
            f"Based on {len(source_patterns)} skill patterns — "
            f"Generalized law of interaction. "
            f"Source: {skill_name} across multiple contexts."
        )

    @staticmethod
    def _evaluate_combination_novelty(content_a: str, content_b: str) -> float:
        """
        두 지식 조합의 새로움 평가 / Evaluate novelty of combining two knowledge items.
        """
        # 단어 겹침이 적을수록 새로운 조합 / Less overlap = more novel combination
        words_a = set(content_a.lower().split())
        words_b = set(content_b.lower().split())

        if not words_a or not words_b:
            return 0.0

        overlap = len(words_a & words_b)
        union = len(words_a | words_b)

        if union == 0:
            return 0.0

        # Jaccard 거리 = 새로움 지표 / Jaccard distance = novelty indicator
        jaccard_distance = 1.0 - (overlap / union)

        # 두 지식이 다를수록 조합이 새로움 / More different = more novel combination
        novelty = jaccard_distance * 0.8 + 0.2  # 기본 새로움 보장

        return min(1.0, novelty)

    @staticmethod
    def _generate_innovation(content_a: str, content_b: str) -> str:
        """
        두 지식의 창의적 조합 생성 / Generate creative combination of two knowledge items.
        "friction law + grip_knowledge" → "use gripper texture for better hold"
        """
        # 간소화된 혁신 생성 / Simplified innovation generation
        return (
            f"INNOVATION: Creative combination of [{content_a[:60]}...] "
            f"and [{content_b[:60]}...] — "
            f"Novel application: Apply principles from both domains "
            f"to create a new approach. Hypothesis: combining these insights "
            f"could yield improved performance or new capability."
        )

    def _detect_episodic_patterns(self) -> int:
        """일화기억에서 반복 패턴 감지 및 승급 / Detect and promote repeated episodic patterns."""
        promoted = 0
        for pattern_key, count in list(self._episodic_patterns.items()):
            if count >= self.REPETITION_THRESHOLD_L2_TO_L3:
                # 이미 의미기억에 있는지 확인 / Check if already in semantic memory
                existing = self._memory._recall_semantic(pattern_key[:20])
                if not existing:
                    # 의미기억으로 승급 / Promote to semantic
                    semantic_content = self._abstract_to_concept(pattern_key, count)
                    item = MemoryItem(
                        content=semantic_content,
                        layer=MemoryLayer.SEMANTIC,
                        priority=MemoryPriority.HIGH,
                        importance=min(1.0, 0.5 + count * 0.1),
                        tags=["semantic", "abstracted", "episodic_origin"],
                    )
                    self._memory._store_semantic(item)
                    promoted += 1
                    self._promotion_counts["L2_to_L3"] += 1
        return promoted

    def _detect_successful_sequences(self) -> int:
        """성공적 행동 시퀀스 감지 및 승급 / Detect and promote successful action sequences."""
        promoted = 0
        for seq_key, seq_info in list(self._action_sequences.items()):
            total = seq_info["total_count"]
            if total < 5:
                continue
            success_rate = seq_info["success_count"] / max(1, total)
            if success_rate >= self.SUCCESS_RATE_THRESHOLD_L3_TO_L4:
                if self._memory._procedural:
                    skill_name = self._generate_skill_name(seq_info["content"])
                    skill_item = MemoryItem(
                        content=f"SKILL:{skill_name} — {seq_info['content'][:100]}",
                        layer=MemoryLayer.PROCEDURAL,
                        priority=MemoryPriority.HIGH,
                        importance=0.9,
                        tags=["skill", "procedural", "learned"],
                        metadata={"success_rate": success_rate},
                    )
                    self._memory._store_procedural(skill_item)
                    promoted += 1
                    self._promotion_counts["L3_to_L4"] += 1
        return promoted

    def _detect_skill_generalizations(self) -> int:
        """스킬 일반화 감지 및 승급 / Detect and promote skill generalizations."""
        promoted = 0
        for skill_name, patterns in list(self._skill_generalizations.items()):
            if len(patterns) >= self.GENERALIZATION_THRESHOLD_L4_TO_L5:
                law_content = self._generalize_to_law(skill_name, patterns)
                law_item = MemoryItem(
                    content=law_content,
                    layer=MemoryLayer.WORLD_KNOWLEDGE,
                    priority=MemoryPriority.CRITICAL,
                    importance=0.95,
                    tags=["law", "world_knowledge", "generalized"],
                    metadata={"source_skills": patterns, "category": "physical_law"},
                )
                self._memory._store_world_knowledge(law_item)
                promoted += 1
                self._promotion_counts["L4_to_L5"] += 1
        return promoted

    def _detect_innovative_combinations(self) -> int:
        """창의적 조합 감지 및 승급 / Detect and promote innovative combinations."""
        promoted = 0
        # 세계지식에서 서로 다른 항목 간 조합 새로움 평가
        # Evaluate combination novelty between different world knowledge items
        if not self._memory._world_knowledge_conn:
            return 0

        try:
            cursor = self._memory._world_knowledge_conn.execute(
                "SELECT fact_id, content, category FROM world_facts "
                "WHERE confidence > 0.8 ORDER BY timestamp DESC LIMIT 20"
            )
            facts = cursor.fetchall()
        except Exception:
            return 0

        for i in range(len(facts)):
            for j in range(i + 1, min(len(facts), i + 5)):
                fact_a_content = facts[i][1]
                fact_b_content = facts[j][1]
                category_a = facts[i][2]
                category_b = facts[j][2]

                # 다른 카테고리의 지식 조합이 더 혁신적 / Cross-category = more innovative
                novelty = self._evaluate_combination_novelty(fact_a_content, fact_b_content)
                if category_a != category_b:
                    novelty += 0.15  # 다른 영역 조합 보너스 / Cross-domain bonus

                if novelty >= self.COMBINATION_NOVELTY_L5_TO_L6:
                    innovation_content = self._generate_innovation(fact_a_content, fact_b_content)
                    innovation_item = MemoryItem(
                        content=innovation_content,
                        layer=MemoryLayer.INNOVATION,
                        priority=MemoryPriority.INNOVATIVE,
                        importance=1.0,
                        novelty_score=novelty,
                        tags=["innovation", "creative_combination"],
                        metadata={
                            "innovation_type": "combination",
                            "source_concepts": [fact_a_content[:50], fact_b_content[:50]],
                            "effectiveness_score": 0.0,
                            "validation_status": "hypothesis",
                        },
                    )
                    self._memory._store_innovation(innovation_item)
                    promoted += 1
                    self._promotion_counts["L5_to_L6"] += 1

        return promoted
