#!/usr/bin/env python3
"""
Constitutional AI Self-Evaluation Module / 헌법적 AI 자기평가 모듈

지훈 로봇 V8의 헌법적 AI 자기평가 시스템입니다.
모든 계획된 행동이 로봇의 헌법(원칙 집합)에 부합하는지 평가하고,
승인/거부/수정 여부를 결정합니다.

TODO 50-51: Constitutional AI Self-Evaluation

Constitution / 헌법 원칙:
  1. 안전 최우선 (Safety First) - 안전은 거부권(veto)을 가짐
  2. 인간 자율성 존중 (Respect Human Autonomy)
  3. 정직한 보고 (Honest Reporting)
  4. 프라이버시 보호 (Privacy Protection)
  5. 공정한 행동 (Fair Behavior)
  6. 지속적 개선 (Continuous Improvement)

Process / 평가 프로세스:
  Action proposed → Evaluate against rules → Score → Approve/Reject/Modify

Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums & Data Classes / 열거형 및 데이터 클래스
# ---------------------------------------------------------------------------

class ConstitutionalRule(Enum):
    """헌법 원칙 열거형 / Constitutional principles enumeration."""
    SAFETY_FIRST = "safety_first"
    RESPECT_AUTONOMY = "respect_autonomy"
    HONEST_REPORTING = "honest_reporting"
    PRIVACY_PROTECTION = "privacy_protection"
    FAIR_BEHAVIOR = "fair_behavior"
    CONTINUOUS_IMPROVEMENT = "continuous_improvement"


class EvaluationVerdict(Enum):
    """평가 판정 / Evaluation verdict."""
    APPROVE = "approve"
    REJECT = "reject"
    MODIFY = "modify"


# Korean descriptions for each rule / 각 원칙의 한국어 설명
RULE_DESCRIPTIONS: Dict[ConstitutionalRule, str] = {
    ConstitutionalRule.SAFETY_FIRST:
        "안전 최우선: 모든 행동은 인간과 환경의 안전을 최우선으로 해야 합니다.",
    ConstitutionalRule.RESPECT_AUTONOMY:
        "인간 자율성 존중: 인간의 선택과 자율성을 존중하고 강제하지 않습니다.",
    ConstitutionalRule.HONEST_REPORTING:
        "정직한 보고: 항상 사실에 기반하여 정직하게 보고합니다.",
    ConstitutionalRule.PRIVACY_PROTECTION:
        "프라이버시 보호: 개인정보와 프라이버시를 엄격히 보호합니다.",
    ConstitutionalRule.FAIR_BEHAVIOR:
        "공정한 행동: 모든 상황에서 공정하고 편향되지 않게 행동합니다.",
    ConstitutionalRule.CONTINUOUS_IMPROVEMENT:
        "지속적 개선: 항상 더 나은 방법을 찾고 개선합니다.",
}

RULE_KOREAN_NAMES: Dict[ConstitutionalRule, str] = {
    ConstitutionalRule.SAFETY_FIRST: "안전 최우선",
    ConstitutionalRule.RESPECT_AUTONOMY: "인간 자율성 존중",
    ConstitutionalRule.HONEST_REPORTING: "정직한 보고",
    ConstitutionalRule.PRIVACY_PROTECTION: "프라이버시 보호",
    ConstitutionalRule.FAIR_BEHAVIOR: "공정한 행동",
    ConstitutionalRule.CONTINUOUS_IMPROVEMENT: "지속적 개선",
}


@dataclass
class ProposedAction:
    """제안된 행동 / Proposed action to evaluate."""
    action_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    description: str = ""
    action_type: str = ""  # e.g., "physical", "verbal", "data_access"
    context: Dict[str, Any] = field(default_factory=dict)
    target: str = ""  # target object, person, or system
    risk_factors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class RuleScore:
    """개별 원칙 점수 / Individual rule score."""
    rule: ConstitutionalRule
    score: float  # 0.0 ~ 1.0
    reasoning: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EvaluationResult:
    """평가 결과 / Evaluation result."""
    result_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    action: ProposedAction = field(default_factory=ProposedAction)
    rule_scores: List[RuleScore] = field(default_factory=list)
    combined_score: float = 0.0
    verdict: EvaluationVerdict = EvaluationVerdict.REJECT
    modification_suggestion: str = ""
    safety_veto: bool = False
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    @property
    def korean_verdict(self) -> str:
        """한국어 판정 / Korean verdict string."""
        verdict_map = {
            EvaluationVerdict.APPROVE: "승인",
            EvaluationVerdict.REJECT: "거부",
            EvaluationVerdict.MODIFY: "수정 제안",
        }
        return verdict_map.get(self.verdict, "알 수 없음")


@dataclass
class ConstitutionalPrinciple:
    """헌법 원칙 정의 / Constitutional principle definition."""
    rule: ConstitutionalRule
    korean_name: str
    english_name: str
    description: str
    scoring_function: Optional[Callable[[ProposedAction], RuleScore]] = None
    is_veto_rule: bool = False  # True = score 0 means automatic reject


@dataclass
class ValueProfile:
    """소유자 가치 프로필 / Owner value profile for alignment verification."""
    owner_id: str = "default"
    safety_tolerance: float = 0.9  # 0-1, higher = more safety-conscious
    privacy_preference: float = 0.8  # 0-1, higher = more privacy-sensitive
    autonomy_preference: float = 0.7  # 0-1, higher = values autonomy more
    fairness_weight: float = 0.6  # 0-1, higher = more fairness-focused
    custom_values: Dict[str, float] = field(default_factory=dict)
    last_updated: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ---------------------------------------------------------------------------
# Scoring Functions / 원칙별 점수 산출 함수
# ---------------------------------------------------------------------------

def _score_safety_first(action: ProposedAction) -> RuleScore:
    """
    안전 최우선 원칙 점수 산출 / Score for Safety First principle.

    안전 점수는 행동의 위험 요소, 행동 유형, 대상에 따라 산출됩니다.
    물리적 행동이나 위험 요소가 많을수록 낮은 점수를 받습니다.

    Args:
        action: 평가할 제안된 행동

    Returns:
        RuleScore: 안전 원칙 점수
    """
    score = 1.0
    reasoning_parts: List[str] = []
    details: Dict[str, Any] = {}

    # Risk factors reduce score / 위험 요소가 점수를 낮춤
    risk_count = len(action.risk_factors)
    if risk_count > 0:
        risk_penalty = min(0.3 * risk_count, 0.9)
        score -= risk_penalty
        reasoning_parts.append(
            f"위험 요소 {risk_count}개 감지 (패널티: -{risk_penalty:.2f})"
        )
        details["risk_factors"] = action.risk_factors

    # Action type affects safety / 행동 유형이 안전에 영향
    type_penalties = {
        "physical": 0.2,
        "data_access": 0.1,
        "verbal": 0.0,
        "environmental": 0.15,
    }
    penalty = type_penalties.get(action.action_type, 0.05)
    score -= penalty
    if penalty > 0:
        reasoning_parts.append(
            f"행동 유형 '{action.action_type}' 안전 패널티: -{penalty:.2f}"
        )

    # Target affects safety / 대상이 안전에 영향
    dangerous_targets = {"human", "animal", "fragile_object", "chemical"}
    if action.target.lower() in dangerous_targets:
        score -= 0.2
        reasoning_parts.append(f"위험 대상 '{action.target}' 패널티: -0.20")

    # Context safety flags / 컨텍스트 안전 플래그
    if action.context.get("emergency", False):
        score -= 0.15
        reasoning_parts.append("비상 상황 컨텍스트 패널티: -0.15")

    if action.context.get("unstable_environment", False):
        score -= 0.2
        reasoning_parts.append("불안정 환경 패널티: -0.20")

    score = max(0.0, min(1.0, score))
    details["initial_score"] = 1.0
    details["final_score"] = score

    reasoning = (
        " | ".join(reasoning_parts) if reasoning_parts else "안전 위험 요소 미감지"
    )

    return RuleScore(
        rule=ConstitutionalRule.SAFETY_FIRST,
        score=score,
        reasoning=reasoning,
        details=details,
    )


def _score_respect_autonomy(action: ProposedAction) -> RuleScore:
    """
    인간 자율성 존중 점수 산출 / Score for Respect Human Autonomy principle.

    강제성, 선택 제한, 조작 여부를 평가합니다.

    Args:
        action: 평가할 제안된 행동

    Returns:
        RuleScore: 자율성 존중 점수
    """
    score = 1.0
    reasoning_parts: List[str] = []
    details: Dict[str, Any] = {}

    # Check for coercion indicators / 강제 지표 확인
    coercion_keywords = {"force", "prevent", "block", "coerce", "manipulate",
                         "강제", "방해", "차단", "조작"}
    desc_lower = action.description.lower()
    for kw in coercion_keywords:
        if kw in desc_lower:
            score -= 0.3
            reasoning_parts.append(f"강제성 키워드 '{kw}' 감지: -0.30")
            break

    # Check for choice restriction / 선택 제한 확인
    if action.context.get("restricts_choice", False):
        score -= 0.4
        reasoning_parts.append("선택 제한 감지: -0.40")

    # Check for consent / 동의 여부 확인
    if action.context.get("has_consent", False):
        score += 0.1
        reasoning_parts.append("명시적 동의 확인: +0.10")

    # Physical intervention without consent / 동의 없는 물리적 개입
    if action.action_type == "physical" and not action.context.get(
        "has_consent", False
    ):
        score -= 0.2
        reasoning_parts.append("동의 없는 물리적 개입: -0.20")

    score = max(0.0, min(1.0, score))
    details["final_score"] = score

    reasoning = (
        " | ".join(reasoning_parts) if reasoning_parts else "자율성 침해 요소 미감지"
    )

    return RuleScore(
        rule=ConstitutionalRule.RESPECT_AUTONOMY,
        score=score,
        reasoning=reasoning,
        details=details,
    )


def _score_honest_reporting(action: ProposedAction) -> RuleScore:
    """
    정직한 보고 점수 산출 / Score for Honest Reporting principle.

    정보 은폐, 허위 보고, 과장 여부를 평가합니다.

    Args:
        action: 평가할 제안된 행동

    Returns:
        RuleScore: 정직한 보고 점수
    """
    score = 1.0
    reasoning_parts: List[str] = []
    details: Dict[str, Any] = {}

    # Deception indicators / 기만 지표
    deception_keywords = {"hide", "conceal", "fabricate", "exaggerate", "omit",
                          "숨기다", "조작", "과장", "누락"}
    desc_lower = action.description.lower()
    for kw in deception_keywords:
        if kw in desc_lower:
            score -= 0.4
            reasoning_parts.append(f"기만성 키워드 '{kw}' 감지: -0.40")
            break

    # Withholding information / 정보 은폐
    if action.context.get("withholds_info", False):
        score -= 0.3
        reasoning_parts.append("정보 은폐 감지: -0.30")

    # Selective reporting / 선택적 보고
    if action.context.get("selective_reporting", False):
        score -= 0.25
        reasoning_parts.append("선택적 보고 감지: -0.25")

    score = max(0.0, min(1.0, score))
    details["final_score"] = score

    reasoning = (
        " | ".join(reasoning_parts) if reasoning_parts else "정직성 위반 요소 미감지"
    )

    return RuleScore(
        rule=ConstitutionalRule.HONEST_REPORTING,
        score=score,
        reasoning=reasoning,
        details=details,
    )


def _score_privacy_protection(action: ProposedAction) -> RuleScore:
    """
    프라이버시 보호 점수 산출 / Score for Privacy Protection principle.

    데이터 접근, 개인정보 수집, 감시 여부를 평가합니다.

    Args:
        action: 평가할 제안된 행동

    Returns:
        RuleScore: 프라이버시 보호 점수
    """
    score = 1.0
    reasoning_parts: List[str] = []
    details: Dict[str, Any] = {}

    # Data access actions / 데이터 접근 행동
    if action.action_type == "data_access":
        score -= 0.2
        reasoning_parts.append("데이터 접근 행동: -0.20")

    # Personal data collection / 개인정보 수집
    if action.context.get("collects_personal_data", False):
        score -= 0.3
        reasoning_parts.append("개인정보 수집 감지: -0.30")

    # Surveillance behavior / 감시 행동
    if action.context.get("involves_surveillance", False):
        score -= 0.4
        reasoning_parts.append("감시 행동 감지: -0.40")

    # Data sharing / 데이터 공유
    if action.context.get("shares_data_externally", False):
        score -= 0.35
        reasoning_parts.append("외부 데이터 공유 감지: -0.35")

    # Has data minimization / 데이터 최소화 적용
    if action.context.get("data_minimization", False):
        score += 0.15
        reasoning_parts.append("데이터 최소화 원칙 적용: +0.15")

    # Has explicit privacy consent / 명시적 프라이버시 동의
    if action.context.get("privacy_consent", False):
        score += 0.1
        reasoning_parts.append("프라이버시 동의 획득: +0.10")

    score = max(0.0, min(1.0, score))
    details["final_score"] = score

    reasoning = (
        " | ".join(reasoning_parts) if reasoning_parts else "프라이버시 위반 요소 미감지"
    )

    return RuleScore(
        rule=ConstitutionalRule.PRIVACY_PROTECTION,
        score=score,
        reasoning=reasoning,
        details=details,
    )


def _score_fair_behavior(action: ProposedAction) -> RuleScore:
    """
    공정한 행동 점수 산출 / Score for Fair Behavior principle.

    편향, 차별, 불공정한 우선순위 여부를 평가합니다.

    Args:
        action: 평가할 제안된 행동

    Returns:
        RuleScore: 공정한 행동 점수
    """
    score = 1.0
    reasoning_parts: List[str] = []
    details: Dict[str, Any] = {}

    # Bias indicators / 편향 지표
    if action.context.get("has_bias", False):
        score -= 0.3
        reasoning_parts.append("편향 감지: -0.30")

    # Discrimination / 차별
    if action.context.get("discriminatory", False):
        score -= 0.5
        reasoning_parts.append("차별적 행동 감지: -0.50")

    # Favoritism / 편애
    if action.context.get("favoritism", False):
        score -= 0.25
        reasoning_parts.append("편애 감지: -0.25")

    # Equal treatment / 평등한 대우
    if action.context.get("equal_treatment", True):
        score += 0.05
        reasoning_parts.append("평등한 대우 기본 가정: +0.05")

    score = max(0.0, min(1.0, score))
    details["final_score"] = score

    reasoning = (
        " | ".join(reasoning_parts) if reasoning_parts else "공정성 위반 요소 미감지"
    )

    return RuleScore(
        rule=ConstitutionalRule.FAIR_BEHAVIOR,
        score=score,
        reasoning=reasoning,
        details=details,
    )


def _score_continuous_improvement(action: ProposedAction) -> RuleScore:
    """
    지속적 개선 점수 산출 / Score for Continuous Improvement principle.

    행동이 학습과 개선에 기여하는지 평가합니다.

    Args:
        action: 평가할 제안된 행동

    Returns:
        RuleScore: 지속적 개선 점수
    """
    score = 0.7  # Neutral default / 중립적 기본값
    reasoning_parts: List[str] = []
    details: Dict[str, Any] = {}

    # Learning opportunity / 학습 기회
    if action.context.get("learning_opportunity", False):
        score += 0.2
        reasoning_parts.append("학습 기회 제공: +0.20")

    # Repetitive without learning / 학습 없는 반복
    if action.context.get("repetitive_no_learning", False):
        score -= 0.15
        reasoning_parts.append("학습 없는 반복 행동: -0.15")

    # Innovation / 혁신
    if action.context.get("innovative_approach", False):
        score += 0.15
        reasoning_parts.append("혁신적 접근: +0.15")

    # Skill building / 기술 구축
    if action.context.get("builds_skill", False):
        score += 0.1
        reasoning_parts.append("기술 구축 기여: +0.10")

    score = max(0.0, min(1.0, score))
    details["final_score"] = score

    reasoning = (
        " | ".join(reasoning_parts) if reasoning_parts else "표준 행동 (개선 기여 중립)"
    )

    return RuleScore(
        rule=ConstitutionalRule.CONTINUOUS_IMPROVEMENT,
        score=score,
        reasoning=reasoning,
        details=details,
    )


# Default scoring function registry / 기본 점수 산출 함수 레지스트리
DEFAULT_SCORING_FUNCTIONS: Dict[
    ConstitutionalRule, Callable[[ProposedAction], RuleScore]
] = {
    ConstitutionalRule.SAFETY_FIRST: _score_safety_first,
    ConstitutionalRule.RESPECT_AUTONOMY: _score_respect_autonomy,
    ConstitutionalRule.HONEST_REPORTING: _score_honest_reporting,
    ConstitutionalRule.PRIVACY_PROTECTION: _score_privacy_protection,
    ConstitutionalRule.FAIR_BEHAVIOR: _score_fair_behavior,
    ConstitutionalRule.CONTINUOUS_IMPROVEMENT: _score_continuous_improvement,
}

# Rule weights for combined score / 통합 점수를 위한 원칙 가중치
DEFAULT_RULE_WEIGHTS: Dict[ConstitutionalRule, float] = {
    ConstitutionalRule.SAFETY_FIRST: 0.30,
    ConstitutionalRule.RESPECT_AUTONOMY: 0.20,
    ConstitutionalRule.HONEST_REPORTING: 0.15,
    ConstitutionalRule.PRIVACY_PROTECTION: 0.15,
    ConstitutionalRule.FAIR_BEHAVIOR: 0.10,
    ConstitutionalRule.CONTINUOUS_IMPROVEMENT: 0.10,
}

# Score thresholds / 점수 임계값
APPROVE_THRESHOLD = 0.7
MODIFY_THRESHOLD = 0.4


# ---------------------------------------------------------------------------
# ConstitutionalAI / 헌법적 AI 메인 클래스
# ---------------------------------------------------------------------------

class ConstitutionalAI:
    """
    헌법적 AI 자기평가 시스템 / Constitutional AI Self-Evaluation System.

    모든 계획된 행동을 로봇의 헌법 원칙에 대해 평가합니다.
    안전 원칙은 거부권(veto)을 가지며, 점수가 0이면 자동 거부됩니다.

    Usage:
        >>> cai = ConstitutionalAI()
        >>> action = ProposedAction(description="문 열기", action_type="physical")
        >>> result = cai.evaluate(action)
        >>> print(result.verdict)
        EvaluationVerdict.APPROVE
    """

    def __init__(
        self,
        scoring_functions: Optional[
            Dict[ConstitutionalRule, Callable[[ProposedAction], RuleScore]]
        ] = None,
        rule_weights: Optional[Dict[ConstitutionalRule, float]] = None,
        audit_db_path: Optional[str] = None,
    ) -> None:
        """
        ConstitutionalAI 초기화 / Initialize ConstitutionalAI.

        Args:
            scoring_functions: 원칙별 점수 산출 함수 (기본값 사용 시 None)
            rule_weights: 원칙별 가중치 (기본값 사용 시 None)
            audit_db_path: 감사 로그 SQLite 경로 (None 시 메모리 DB)
        """
        self._scoring_functions = scoring_functions or dict(
            DEFAULT_SCORING_FUNCTIONS
        )
        self._rule_weights = rule_weights or dict(DEFAULT_RULE_WEIGHTS)

        # Validate weights sum / 가중치 합 검증
        total_weight = sum(self._rule_weights.values())
        if abs(total_weight - 1.0) > 0.01:
            logger.warning(
                "원칙 가중치 합이 1.0이 아님: %.3f. 정규화합니다.",
                total_weight,
            )
            for rule in self._rule_weights:
                self._rule_weights[rule] /= total_weight

        # Ensure all rules have scoring functions / 모든 원칙에 점수 함수 확인
        for rule in ConstitutionalRule:
            if rule not in self._scoring_functions:
                logger.warning(
                    "원칙 %s에 대한 점수 함수가 없습니다. 기본값을 사용합니다.",
                    rule.value,
                )
                self._scoring_functions[rule] = lambda a, r=rule: RuleScore(
                    rule=r, score=0.5, reasoning="기본 점수 (점수 함수 미정의)"
                )

        # Audit database / 감사 데이터베이스
        self._audit_db_path = audit_db_path or ":memory:"
        self._db_conn: Optional[sqlite3.Connection] = None
        self._init_audit_db()

        # Statistics / 통계
        self._evaluation_count = 0
        self._verdict_counts: Dict[EvaluationVerdict, int] = {
            v: 0 for v in EvaluationVerdict
        }

        logger.info(
            "ConstitutionalAI 초기화 완료 - 감사 DB: %s",
            self._audit_db_path,
        )

    def _get_conn(self) -> sqlite3.Connection:
        """DB 연결 반환 (:memory: 시 캐시된 연결 사용) / Get DB connection."""
        if self._audit_db_path == ":memory:":
            if self._db_conn is None:
                self._db_conn = sqlite3.connect(self._audit_db_path)
            return self._db_conn
        return sqlite3.connect(self._audit_db_path)

    def _init_audit_db(self) -> None:
        """감사 데이터베이스 초기화 / Initialize audit database."""
        try:
            conn = self._get_conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS evaluation_audit (
                    result_id TEXT PRIMARY KEY,
                    action_id TEXT NOT NULL,
                    action_description TEXT,
                    action_type TEXT,
                    combined_score REAL,
                    verdict TEXT NOT NULL,
                    safety_veto INTEGER DEFAULT 0,
                    rule_scores_json TEXT,
                    modification_suggestion TEXT,
                    timestamp TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_audit_timestamp
                ON evaluation_audit(timestamp)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_audit_verdict
                ON evaluation_audit(verdict)
            """)
            conn.commit()
            if self._audit_db_path != ":memory:":
                conn.close()
            logger.debug("감사 데이터베이스 초기화 완료")
        except sqlite3.Error as e:
            logger.error("감사 데이터베이스 초기화 실패: %s", e)
            raise

    def evaluate(self, action: ProposedAction) -> EvaluationResult:
        """
        제안된 행동을 헌법에 대해 평가 / Evaluate proposed action against constitution.

        각 원칙에 대해 점수를 산출하고, 통합 점수를 계산하여
        승인/거부/수정 판정을 내립니다.

        Args:
            action: 평가할 제안된 행동

        Returns:
            EvaluationResult: 평가 결과 (판정, 점수, 이유 등)
        """
        logger.info(
            "행동 평가 시작: [%s] %s",
            action.action_id,
            action.description[:50],
        )

        # Score each rule / 각 원칙 점수 산출
        rule_scores: List[RuleScore] = []
        safety_veto = False
        safety_score = 1.0

        for rule in ConstitutionalRule:
            scoring_fn = self._scoring_functions.get(rule)
            if scoring_fn is None:
                rule_score = RuleScore(
                    rule=rule,
                    score=0.5,
                    reasoning="점수 함수 미등록",
                )
            else:
                try:
                    rule_score = scoring_fn(action)
                except Exception as e:
                    logger.error(
                        "원칙 %s 점수 산출 중 오류: %s", rule.value, e
                    )
                    rule_score = RuleScore(
                        rule=rule,
                        score=0.0,
                        reasoning=f"점수 산출 오류: {e}",
                        details={"error": str(e)},
                    )

            # Safety veto check / 안전 거부권 확인
            if rule == ConstitutionalRule.SAFETY_FIRST:
                safety_score = rule_score.score
                if rule_score.score == 0.0:
                    safety_veto = True
                    logger.warning(
                        "🚨 안전 거부권 발동: 안전 점수 0.0 - 행동 자동 거부"
                    )

            rule_scores.append(rule_score)

        # Compute combined score / 통합 점수 계산
        combined_score = self._compute_combined_score(rule_scores)

        # Determine verdict / 판정 결정
        verdict, modification = self._determine_verdict(
            combined_score, safety_veto, safety_score, rule_scores
        )

        # Build result / 결과 구성
        result = EvaluationResult(
            action=action,
            rule_scores=rule_scores,
            combined_score=combined_score,
            verdict=verdict,
            modification_suggestion=modification,
            safety_veto=safety_veto,
        )

        # Update statistics / 통계 업데이트
        self._evaluation_count += 1
        self._verdict_counts[verdict] += 1

        # Audit log / 감사 로그
        self._store_audit(result)

        logger.info(
            "행동 평가 완료: [%s] 판정=%s, 통합점수=%.3f, 안전거부권=%s",
            action.action_id,
            result.korean_verdict,
            combined_score,
            safety_veto,
        )

        return result

    def _compute_combined_score(self, rule_scores: List[RuleScore]) -> float:
        """
        통합 점수 계산 / Compute weighted combined score.

        가중 평균으로 통합 점수를 계산합니다.

        Args:
            rule_scores: 각 원칙의 점수 목록

        Returns:
            float: 통합 점수 (0.0 ~ 1.0)
        """
        total = 0.0
        for rs in rule_scores:
            weight = self._rule_weights.get(rs.rule, 0.0)
            total += rs.score * weight
        return max(0.0, min(1.0, total))

    def _determine_verdict(
        self,
        combined_score: float,
        safety_veto: bool,
        safety_score: float,
        rule_scores: List[RuleScore],
    ) -> Tuple[EvaluationVerdict, str]:
        """
        평가 판정 결정 / Determine evaluation verdict.

        Args:
            combined_score: 통합 점수
            safety_veto: 안전 거부권 발동 여부
            safety_score: 안전 점수
            rule_scores: 각 원칙 점수

        Returns:
            (판정, 수정 제안) 튜플
        """
        # Safety veto always rejects / 안전 거부권은 항상 거부
        if safety_veto:
            return (
                EvaluationVerdict.REJECT,
                "안전 점수가 0점입니다. 행동을 수행하기에 너무 위험합니다. "
                "안전 조치를 먼저 확인하고 다시 시도하세요.",
            )

        # Low safety score suggests modification / 낮은 안전 점수는 수정 제안
        modification = ""

        if combined_score >= APPROVE_THRESHOLD:
            if safety_score < 0.5:
                modification = (
                    f"승인되었으나 안전 점수가 낮습니다 ({safety_score:.2f}). "
                    "추가 안전 조치를 권장합니다."
                )
            return EvaluationVerdict.APPROVE, modification

        if combined_score >= MODIFY_THRESHOLD:
            # Find weakest rules and suggest improvements / 취약 원칙 찾기
            weak_rules = [
                (rs.rule, rs.score)
                for rs in rule_scores
                if rs.score < 0.5
            ]
            if weak_rules:
                weak_names = [
                    f"{RULE_KOREAN_NAMES.get(r, r.value)} ({s:.2f})"
                    for r, s in weak_rules
                ]
                modification = (
                    f"다음 원칙 점수가 낮습니다: {', '.join(weak_names)}. "
                    "행동을 수정하여 해당 원칙을 강화하세요."
                )
            else:
                modification = "통합 점수가 승인 기준에 미달합니다. 행동을 보완하세요."
            return EvaluationVerdict.MODIFY, modification

        # Below modify threshold / 수정 임계값 미만
        return (
            EvaluationVerdict.REJECT,
            f"통합 점수 ({combined_score:.3f})가 거부 기준보다 낮습니다. "
            "행동을 전면적으로 재검토하세요.",
        )

    def _store_audit(self, result: EvaluationResult) -> None:
        """
        평가 결과를 감사 로그에 저장 / Store evaluation result in audit log.

        Args:
            result: 저장할 평가 결과
        """
        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT INTO evaluation_audit
                    (result_id, action_id, action_description, action_type,
                     combined_score, verdict, safety_veto, rule_scores_json,
                     modification_suggestion, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    result.result_id,
                    result.action.action_id,
                    result.action.description,
                    result.action.action_type,
                    result.combined_score,
                    result.verdict.value,
                    int(result.safety_veto),
                    json.dumps(
                        [
                            {
                                "rule": rs.rule.value,
                                "score": rs.score,
                                "reasoning": rs.reasoning,
                            }
                            for rs in result.rule_scores
                        ],
                        ensure_ascii=False,
                    ),
                    result.modification_suggestion,
                    result.timestamp,
                ),
            )
            conn.commit()
            if self._audit_db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("감사 로그 저장 실패: %s", e)

    def get_audit_log(
        self,
        limit: int = 100,
        verdict_filter: Optional[EvaluationVerdict] = None,
    ) -> List[Dict[str, Any]]:
        """
        감사 로그 조회 / Retrieve audit log entries.

        Args:
            limit: 최대 조회 건수
            verdict_filter: 판정 필터 (None이면 전체)

        Returns:
            List[Dict]: 감사 로그 항목 목록
        """
        try:
            conn = self._get_conn()
            conn.row_factory = sqlite3.Row

            if verdict_filter:
                rows = conn.execute(
                    """
                    SELECT * FROM evaluation_audit
                    WHERE verdict = ?
                    ORDER BY timestamp DESC LIMIT ?
                    """,
                    (verdict_filter.value, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT * FROM evaluation_audit
                    ORDER BY timestamp DESC LIMIT ?
                    """,
                    (limit,),
                ).fetchall()

            if self._audit_db_path != ":memory:":
                conn.close()
            return [dict(r) for r in rows]
        except sqlite3.Error as e:
            logger.error("감사 로그 조회 실패: %s", e)
            return []

    def get_statistics(self) -> Dict[str, Any]:
        """
        평가 통계 조회 / Get evaluation statistics.

        Returns:
            Dict: 평가 통계 정보
        """
        return {
            "total_evaluations": self._evaluation_count,
            "verdict_counts": {
                v.value: self._verdict_counts.get(v, 0)
                for v in EvaluationVerdict
            },
            "approve_rate": (
                self._verdict_counts.get(EvaluationVerdict.APPROVE, 0)
                / max(1, self._evaluation_count)
            ),
            "reject_rate": (
                self._verdict_counts.get(EvaluationVerdict.REJECT, 0)
                / max(1, self._evaluation_count)
            ),
            "modify_rate": (
                self._verdict_counts.get(EvaluationVerdict.MODIFY, 0)
                / max(1, self._evaluation_count)
            ),
        }

    def register_scoring_function(
        self,
        rule: ConstitutionalRule,
        scoring_fn: Callable[[ProposedAction], RuleScore],
    ) -> None:
        """
        커스텀 점수 산출 함수 등록 / Register custom scoring function.

        Args:
            rule: 등록할 원칙
            scoring_fn: 점수 산출 함수
        """
        self._scoring_functions[rule] = scoring_fn
        logger.info("원칙 %s에 커스텀 점수 함수 등록됨", rule.value)

    def set_rule_weight(self, rule: ConstitutionalRule, weight: float) -> None:
        """
        원칙 가중치 설정 / Set rule weight.

        Args:
            rule: 가중치를 변경할 원칙
            weight: 새 가중치 (설정 후 전체 가중치가 자동 정규화됨)
        """
        self._rule_weights[rule] = weight
        # Renormalize / 재정규화
        total = sum(self._rule_weights.values())
        for r in self._rule_weights:
            self._rule_weights[r] /= total
        logger.info("원칙 %s 가중치 변경: %.3f (정규화 후)", rule.value, weight)


# ---------------------------------------------------------------------------
# SelfEvaluator / 자기평가기
# ---------------------------------------------------------------------------

class SelfEvaluator:
    """
    자기평가기 / Self-Evaluator for robot actions.

    로봇의 계획된 행동을 헌법에 대해 자동으로 평가합니다.
    행동 기획 파이프라인과 통합되어 사용됩니다.

    Usage:
        >>> evaluator = SelfEvaluator()
        >>> result = evaluator.evaluate_action("문 열기", "physical")
        >>> if result.verdict == EvaluationVerdict.APPROVE:
        ...     print("실행 승인됨")
    """

    def __init__(
        self,
        constitutional_ai: Optional[ConstitutionalAI] = None,
        owner_values: Optional[ValueProfile] = None,
    ) -> None:
        """
        SelfEvaluator 초기화 / Initialize SelfEvaluator.

        Args:
            constitutional_ai: ConstitutionalAI 인스턴스 (None 시 기본값 생성)
            owner_values: 소유자 가치 프로필 (None 시 기본값)
        """
        self._cai = constitutional_ai or ConstitutionalAI()
        self._owner_values = owner_values or ValueProfile()
        self._value_verifier = ValueAlignmentVerifier(self._owner_values)

        logger.info("SelfEvaluator 초기화 완료")

    def evaluate_action(
        self,
        description: str,
        action_type: str = "",
        target: str = "",
        context: Optional[Dict[str, Any]] = None,
        risk_factors: Optional[List[str]] = None,
    ) -> EvaluationResult:
        """
        행동 평가 / Evaluate an action.

        Args:
            description: 행동 설명
            action_type: 행동 유형
            target: 대상
            context: 추가 컨텍스트
            risk_factors: 위험 요소 목록

        Returns:
            EvaluationResult: 평가 결과
        """
        action = ProposedAction(
            description=description,
            action_type=action_type,
            target=target,
            context=context or {},
            risk_factors=risk_factors or [],
        )

        # Constitutional evaluation / 헌법적 평가
        result = self._cai.evaluate(action)

        # Value alignment check / 가치 정렬 확인
        alignment = self._value_verifier.check_alignment(action, result)
        result.metadata = getattr(result, "metadata", {})
        result.metadata["value_alignment"] = alignment  # type: ignore[attr-defined]

        return result

    def batch_evaluate(
        self,
        actions: List[ProposedAction],
    ) -> List[EvaluationResult]:
        """
        다중 행동 일괄 평가 / Batch evaluate multiple actions.

        Args:
            actions: 평가할 행동 목록

        Returns:
            List[EvaluationResult]: 평가 결과 목록
        """
        results: List[EvaluationResult] = []
        for action in actions:
            result = self._cai.evaluate(action)
            alignment = self._value_verifier.check_alignment(action, result)
            results.append(result)
        logger.info(
            "일괄 평가 완료: %d건", len(results)
        )
        return results

    def get_owner_values(self) -> ValueProfile:
        """소유자 가치 프로필 반환 / Return owner value profile."""
        return self._owner_values

    def update_owner_values(self, profile: ValueProfile) -> None:
        """
        소유자 가치 프로필 업데이트 / Update owner value profile.

        Args:
            profile: 새 가치 프로필
        """
        self._owner_values = profile
        self._value_verifier = ValueAlignmentVerifier(profile)
        logger.info("소유자 가치 프로필 업데이트됨")


# ---------------------------------------------------------------------------
# ValueAlignmentVerifier / 가치 정렬 검증기
# ---------------------------------------------------------------------------

class ValueAlignmentVerifier:
    """
    가치 정렬 검증기 / Value Alignment Verifier.

    행동이 소유자의 가치와 정렬되어 있는지 검증합니다.
    헌법적 평가 이후 추가적인 개인화된 검증을 수행합니다.

    Usage:
        >>> profile = ValueProfile(safety_tolerance=0.95)
        >>> verifier = ValueAlignmentVerifier(profile)
        >>> alignment = verifier.check_alignment(action, eval_result)
    """

    def __init__(self, owner_values: Optional[ValueProfile] = None) -> None:
        """
        ValueAlignmentVerifier 초기화.

        Args:
            owner_values: 소유자 가치 프로필 (None 시 기본값)
        """
        self._owner_values = owner_values or ValueProfile()
        logger.info("ValueAlignmentVerifier 초기화 완료")

    def check_alignment(
        self,
        action: ProposedAction,
        eval_result: EvaluationResult,
    ) -> Dict[str, Any]:
        """
        가치 정렬 검증 / Check value alignment.

        소유자의 가치 프로필과 행동 평가 결과를 비교하여
        정렬도를 산출합니다.

        Args:
            action: 제안된 행동
            eval_result: 헌법적 평가 결과

        Returns:
            Dict: 정렬 검증 결과
            - aligned (bool): 정렬 여부
            - alignment_score (float): 정렬 점수 (0-1)
            - misalignments (List[str]): 비정렬 항목
            - recommendations (List[str]): 권장 사항
        """
        alignment_score = 1.0
        misalignments: List[str] = []
        recommendations: List[str] = []

        # Safety alignment / 안전 정렬
        safety_score = next(
            (rs.score for rs in eval_result.rule_scores
             if rs.rule == ConstitutionalRule.SAFETY_FIRST),
            1.0,
        )
        if safety_score < self._owner_values.safety_tolerance:
            alignment_score -= 0.2
            misalignments.append(
                f"안전 점수 ({safety_score:.2f})가 소유자 기대치 "
                f"({self._owner_values.safety_tolerance:.2f})보다 낮음"
            )
            recommendations.append("추가 안전 조치 필요")

        # Privacy alignment / 프라이버시 정렬
        privacy_score = next(
            (rs.score for rs in eval_result.rule_scores
             if rs.rule == ConstitutionalRule.PRIVACY_PROTECTION),
            1.0,
        )
        if privacy_score < self._owner_values.privacy_preference:
            alignment_score -= 0.15
            misalignments.append(
                f"프라이버시 점수 ({privacy_score:.2f})가 소유자 기대치 "
                f"({self._owner_values.privacy_preference:.2f})보다 낮음"
            )
            recommendations.append("데이터 처리 방식 재검토 필요")

        # Autonomy alignment / 자율성 정렬
        autonomy_score = next(
            (rs.score for rs in eval_result.rule_scores
             if rs.rule == ConstitutionalRule.RESPECT_AUTONOMY),
            1.0,
        )
        if autonomy_score < self._owner_values.autonomy_preference:
            alignment_score -= 0.15
            misalignments.append(
                f"자율성 존중 점수 ({autonomy_score:.2f})가 소유자 기대치 "
                f"({self._owner_values.autonomy_preference:.2f})보다 낮음"
            )
            recommendations.append("사용자 선택권 강화 필요")

        # Fairness alignment / 공정성 정렬
        fairness_score = next(
            (rs.score for rs in eval_result.rule_scores
             if rs.rule == ConstitutionalRule.FAIR_BEHAVIOR),
            1.0,
        )
        if fairness_score < self._owner_values.fairness_weight:
            alignment_score -= 0.1
            misalignments.append(
                f"공정성 점수 ({fairness_score:.2f})가 소유자 기대치 "
                f"({self._owner_values.fairness_weight:.2f})보다 낮음"
            )
            recommendations.append("공정성 개선 필요")

        # Custom values / 사용자 정의 가치
        for value_name, value_threshold in self._owner_values.custom_values.items():
            if alignment_score < value_threshold:
                misalignments.append(
                    f"사용자 정의 가치 '{value_name}' 기준 미달"
                )

        alignment_score = max(0.0, min(1.0, alignment_score))
        aligned = alignment_score >= 0.7

        if misalignments:
            logger.info(
                "가치 정렬 검증: %d개 비정렬 항목 감지", len(misalignments)
            )

        return {
            "aligned": aligned,
            "alignment_score": alignment_score,
            "misalignments": misalignments,
            "recommendations": recommendations,
            "owner_id": self._owner_values.owner_id,
        }

    def update_profile(self, owner_values: ValueProfile) -> None:
        """
        소유자 가치 프로필 업데이트 / Update owner value profile.

        Args:
            owner_values: 새 가치 프로필
        """
        self._owner_values = owner_values
        logger.info("가치 프로필 업데이트: 소유자=%s", owner_values.owner_id)


# ---------------------------------------------------------------------------
# Convenience Functions / 편의 함수
# ---------------------------------------------------------------------------

def create_default_constitutional_ai(
    audit_db_path: Optional[str] = None,
) -> ConstitutionalAI:
    """
    기본 설정의 ConstitutionalAI 인스턴스 생성 / Create default ConstitutionalAI.

    Args:
        audit_db_path: 감사 DB 경로 (None 시 메모리 DB)

    Returns:
        ConstitutionalAI: 기본 설정 인스턴스
    """
    return ConstitutionalAI(audit_db_path=audit_db_path)


def quick_evaluate(
    description: str,
    action_type: str = "",
    risk_factors: Optional[List[str]] = None,
) -> EvaluationResult:
    """
    빠른 행동 평가 / Quick action evaluation.

    간단한 인터페이스로 행동을 평가합니다.

    Args:
        description: 행동 설명
        action_type: 행동 유형
        risk_factors: 위험 요소

    Returns:
        EvaluationResult: 평가 결과
    """
    evaluator = SelfEvaluator()
    return evaluator.evaluate_action(
        description=description,
        action_type=action_type,
        risk_factors=risk_factors,
    )


# ---------------------------------------------------------------------------
# Module Entry Point / 모듈 진입점
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    print("=" * 60)
    print("지훈 로봇 V8.5 - Constitutional AI Self-Evaluation")
    print("헌법적 AI 자기평가 시스템")
    print("=" * 60)

    # Demo: evaluate some actions / 데모: 여러 행동 평가
    evaluator = SelfEvaluator()

    test_actions = [
        ("방 청소하기", "physical", "", [], {}),
        ("사용자 데이터 외부 전송", "data_access", "server",
         ["privacy_risk"], {"shares_data_externally": True}),
        ("비상시 인간 보호", "physical", "human",
         ["physical_contact"], {"emergency": True, "has_consent": False}),
        ("안전한 물건 집기", "physical", "cup",
         [], {"has_consent": True}),
    ]

    print("\n📊 행동 평가 데모:\n")
    for desc, atype, target, risks, ctx in test_actions:
        result = evaluator.evaluate_action(
            description=desc,
            action_type=atype,
            target=target,
            context=ctx,
            risk_factors=risks,
        )
        print(f"  행동: {desc}")
        print(f"  판정: {result.korean_verdict} (점수: {result.combined_score:.3f})")
        if result.safety_veto:
            print(f"  ⚠️  안전 거부권 발동!")
        if result.modification_suggestion:
            print(f"  💡 제안: {result.modification_suggestion[:60]}...")
        print()

    # Print statistics / 통계 출력
    stats = evaluator._cai.get_statistics()
    print(f"\n📈 평가 통계:")
    print(f"  총 평가: {stats['total_evaluations']}건")
    print(f"  승인률: {stats['approve_rate']:.1%}")
    print(f"  거부률: {stats['reject_rate']:.1%}")
    print(f"  수정률: {stats['modify_rate']:.1%}")
