#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — MKS XDRIVE Mini CAN 컨트롤러 (XDrive Controller)
================================================================

CAN 2.0B 1Mbps → MKS XDRIVE Mini ×4 (다리 관절 제어)

V8.5 변경사항 / V8.5 Changes from V8.5:
  - CAN 버스 오류 복구 (CAN bus error recovery)
  - 모터 드라이버 건전성 모니터링 (Motor driver health monitoring)
  - 위치 제어 정확도 검증 (Position control accuracy verification)

CAN ID 매핑:
  명령 ID: 0x201(좌다리피치), 0x202(우다리피치),
            0x203(좌다리승강), 0x204(우다리승강)
  응답 ID: 0x301-0x304
  긴급정지: 0x500
  하트비트: 0x501

8바이트 CAN 프레임 포맷:
  [목표위치 2B][목표속도 2B][토크제한 2B][제어모드 1B][예비 1B]

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import struct
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V84.XDrive")


# ============================================================================
# 상수 및 열거형
# ============================================================================

CAN_BAUDRATE_KBPS = 1000
CAN_FRAME_DLC = 8

# V8.5: CAN 버스 오류 복구 상수
CAN_MAX_RETRIES = 3
CAN_RECOVERY_DELAY_MS = 50
CAN_BUS_OFF_RECOVERY_MS = 200
CAN_ERROR_WINDOW_SIZE = 100
CAN_CONSECUTIVE_ERROR_LIMIT = 5

# V8.5: 드라이버 건전성 상수
DRIVER_HEALTH_TIMEOUT_MS = 500      # 응답 타임아웃 (ms)
DRIVER_TEMP_WARNING_C = 70          # 온도 경고
DRIVER_TEMP_CRITICAL_C = 85         # 온도 위험
DRIVER_MAX_ERROR_COUNT = 50         # 최대 에러 카운트
DRIVER_HEALTH_WINDOW = 50           # 건전성 평가 윈도우

# V8.5: 위치 정확도 검증 상수
POSITION_ACCURACY_TOLERANCE = 5     # 위치 오차 허용치 (raw unit)
POSITION_SETTLING_TIME_MS = 200     # 위치 안정화 시간 (ms)
POSITION_VERIFICATION_DELAY_MS = 50 # 검증 지연 (ms)


class XDriveControlMode(IntEnum):
    """XDRIVE 제어 모드"""
    POSITION = 0x01
    VELOCITY = 0x02
    TORQUE = 0x03
    POSITION_VELOCITY = 0x04
    IDLE = 0x00


class JointID(Enum):
    """관절 식별자"""
    LEFT_LEG_PITCH = "left_leg_pitch"
    RIGHT_LEG_PITCH = "right_leg_pitch"
    LEFT_LEG_LIFT = "left_leg_lift"
    RIGHT_LEG_LIFT = "right_leg_lift"


class DriverHealthStatus(Enum):
    """V8.5: 드라이버 건전성 상태"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"         # 성능 저하
    WARNING = "warning"           # 경고
    CRITICAL = "critical"         # 위험
    OFFLINE = "offline"           # 통신 불가


# CAN ID 매핑
JOINT_CAN_IDS: Dict[JointID, int] = {
    JointID.LEFT_LEG_PITCH: 0x201,
    JointID.RIGHT_LEG_PITCH: 0x202,
    JointID.LEFT_LEG_LIFT: 0x203,
    JointID.RIGHT_LEG_LIFT: 0x204,
}

JOINT_RESPONSE_IDS: Dict[JointID, int] = {
    JointID.LEFT_LEG_PITCH: 0x301,
    JointID.RIGHT_LEG_PITCH: 0x302,
    JointID.LEFT_LEG_LIFT: 0x303,
    JointID.RIGHT_LEG_LIFT: 0x304,
}

CAN_ID_EMERGENCY_STOP = 0x500
CAN_ID_HEARTBEAT = 0x501

MAX_TORQUE_LIMIT = 1000
DEFAULT_TORQUE_LIMIT = 500
HEARTBEAT_PERIOD_S = 0.1


# ============================================================================
# 데이터 클래스
# ============================================================================

@dataclass
class CANFrame:
    """CAN 2.0B 프레임"""
    can_id: int
    data: bytes
    is_extended: bool = False
    timestamp: float = 0.0
    is_error_frame: bool = False   # V8.5: 에러 프레임 플래그

    def __post_init__(self) -> None:
        if len(self.data) > CAN_FRAME_DLC:
            raise ValueError(f"CAN 데이터 최대 {CAN_FRAME_DLC}바이트, 입력: {len(self.data)}")


@dataclass
class XDriveCommand:
    """XDRIVE 명령"""
    target_position: int = 0
    target_velocity: int = 0
    torque_limit: int = DEFAULT_TORQUE_LIMIT
    control_mode: XDriveControlMode = XDriveControlMode.POSITION
    reserved: int = 0

    def to_bytes(self) -> bytes:
        return struct.pack(
            ">hhHBB",
            self.target_position,
            self.target_velocity,
            self.torque_limit,
            self.control_mode,
            self.reserved,
        )


@dataclass
class XDriveFeedback:
    """XDRIVE 피드백 데이터"""
    joint_id: JointID
    position: int = 0
    velocity: int = 0
    torque: int = 0
    temperature: int = 0
    error_code: int = 0
    timestamp: float = 0.0

    @classmethod
    def from_can_frame(cls, joint_id: JointID, frame: CANFrame) -> "XDriveFeedback":
        if len(frame.data) < 8:
            raise ValueError(f"응답 프레임은 8바이트 이상 필요, 입력: {len(frame.data)}")
        pos, vel, torque = struct.unpack(">hhH", frame.data[0:6])
        temp = frame.data[6]
        error = frame.data[7]
        return cls(
            joint_id=joint_id,
            position=pos,
            velocity=vel,
            torque=torque,
            temperature=temp,
            error_code=error,
            timestamp=frame.timestamp,
        )


# V8.5: 드라이버 건전성 데이터
@dataclass
class DriverHealthData:
    """V8.5: 모터 드라이버 건전성 데이터"""
    joint_id: JointID = JointID.LEFT_LEG_PITCH
    status: DriverHealthStatus = DriverHealthStatus.OFFLINE
    temperature_c: float = 25.0
    error_count: int = 0
    last_response_time: float = 0.0
    response_latency_ms: float = 0.0
    consecutive_timeouts: int = 0
    comm_success_rate: float = 1.0
    last_error_code: int = 0


# V8.5: 위치 정확도 데이터
@dataclass
class PositionAccuracyData:
    """V8.5: 위치 제어 정확도 데이터"""
    joint_id: JointID = JointID.LEFT_LEG_PITCH
    target_position: int = 0
    actual_position: int = 0
    position_error: int = 0
    is_within_tolerance: bool = True
    settling_time_ms: float = 0.0
    verification_passed: bool = True


@dataclass
class JointState:
    """관절 상태 관리"""
    joint_id: JointID
    can_id: int
    response_id: int
    mode: XDriveControlMode = XDriveControlMode.IDLE
    command: XDriveCommand = field(default_factory=XDriveCommand)
    feedback: Optional[XDriveFeedback] = None
    last_command_time: float = 0.0
    last_feedback_time: float = 0.0
    error_count: int = 0
    is_online: bool = False
    # V8.5 추가
    driver_health: DriverHealthData = field(default_factory=DriverHealthData)
    position_accuracy: PositionAccuracyData = field(default_factory=PositionAccuracyData)
    can_errors: int = 0


# ============================================================================
# V8.5: CAN 버스 오류 복구 관리자
# ============================================================================

class CANBusErrorRecovery:
    """
    V8.5: CAN 버스 오류 복구 관리자 / CAN bus error recovery manager.

    오류 감지 → 재시도 → 버스 리셋 → 복구.
    """

    def __init__(self) -> None:
        self._error_counts: Dict[JointID, int] = {}
        self._consecutive_errors: Dict[JointID, int] = {}
        self._recovery_attempts: Dict[JointID, int] = {}
        self._error_history: deque = deque(maxlen=CAN_ERROR_WINDOW_SIZE)
        self._bus_reset_count: int = 0

    def record_error(self, joint_id: JointID) -> None:
        """CAN 오류 기록"""
        self._error_counts[joint_id] = self._error_counts.get(joint_id, 0) + 1
        self._consecutive_errors[joint_id] = self._consecutive_errors.get(joint_id, 0) + 1
        self._error_history.append(False)

        if self._consecutive_errors[joint_id] >= CAN_CONSECUTIVE_ERROR_LIMIT:
            logger.warning(
                "CAN 연속 오류 한계 초과 — %s: %d회",
                joint_id.value, self._consecutive_errors[joint_id],
            )

    def record_success(self, joint_id: JointID) -> None:
        """CAN 성공 기록"""
        self._consecutive_errors[joint_id] = 0
        self._error_history.append(True)

    def should_retry(self, joint_id: JointID) -> bool:
        """재시도 가능 여부"""
        attempts = self._recovery_attempts.get(joint_id, 0)
        return attempts < CAN_MAX_RETRIES

    def get_retry_delay_ms(self, joint_id: JointID) -> float:
        """재시도 대기 시간 (지수 백오프)"""
        attempts = self._recovery_attempts.get(joint_id, 0)
        delay = CAN_RECOVERY_DELAY_MS * (2 ** attempts)
        return min(delay, 500.0)

    def increment_retry(self, joint_id: JointID) -> None:
        """재시도 카운트 증가"""
        self._recovery_attempts[joint_id] = self._recovery_attempts.get(joint_id, 0) + 1

    def reset_retry(self, joint_id: JointID) -> None:
        """재시도 카운트 리셋"""
        self._recovery_attempts[joint_id] = 0

    def get_error_rate(self) -> float:
        """오류율 계산"""
        if not self._error_history:
            return 0.0
        total = len(self._error_history)
        errors = sum(1 for x in self._error_history if not x)
        return errors / total

    @property
    def bus_reset_count(self) -> int:
        return self._bus_reset_count


# ============================================================================
# XDRIVE 컨트롤러 V8.5
# ============================================================================

class XDriveController:
    """
    MKS XDRIVE Mini CAN 2.0B 컨트롤러 V8.5

    V8.5 신규 기능:
    - CAN 버스 오류 복구 (재시도 + 버스 리셋)
    - 모터 드라이버 건전성 모니터링
    - 위치 제어 정확도 검증
    """

    def __init__(self, can_interface: str = "can0") -> None:
        self._can_interface = can_interface
        self._can_bus: Optional[object] = None
        self._joints: Dict[JointID, JointState] = {}
        self._running = False
        self._emergency_active = False
        self._last_heartbeat_time: float = 0.0
        self._feedback_callbacks: List[Callable[[XDriveFeedback], None]] = []

        # V8.5: CAN 오류 복구
        self._error_recovery = CANBusErrorRecovery()

        # 관절 상태 초기화
        for joint_id in JointID:
            state = JointState(
                joint_id=joint_id,
                can_id=JOINT_CAN_IDS[joint_id],
                response_id=JOINT_RESPONSE_IDS[joint_id],
            )
            state.driver_health.joint_id = joint_id
            state.position_accuracy.joint_id = joint_id
            self._joints[joint_id] = state

        logger.info(
            "XDRIVE V8.5 컨트롤러 초기화 — CAN 인터페이스: %s, 관절 %d개",
            can_interface, len(self._joints),
        )

    # ========================================================================
    # 초기화 및 연결
    # ========================================================================

    def connect(self) -> bool:
        """CAN 버스 연결"""
        try:
            import can
            self._can_bus = can.Bus(
                interface="socketcan",
                channel=self._can_interface,
                bitrate=CAN_BAUDRATE_KBPS * 1000,
            )
            logger.info("CAN 버스 연결 성공 — %s @ %dkbps", self._can_interface, CAN_BAUDRATE_KBPS)
            return True
        except ImportError:
            logger.error("python-can 패키지 미설치 — pip install python-can")
            return False
        except Exception as e:
            logger.error("CAN 버스 연결 실패: %s", e)
            return False

    def disconnect(self) -> None:
        """CAN 버스 연결 해제"""
        if self._can_bus is not None:
            try:
                self._can_bus.shutdown()
            except Exception:
                pass
            self._can_bus = None
        self._running = False
        logger.info("XDRIVE V8.5 연결 해제")

    # ========================================================================
    # 제어 명령 (V8.5: 재시도 로직 포함)
    # ========================================================================

    def set_position(
        self,
        joint_id: JointID,
        position: int,
        velocity: int = 0,
        torque_limit: int = DEFAULT_TORQUE_LIMIT,
    ) -> None:
        """
        위치 제어 명령 전송

        V8.5: CAN 오류 시 재시도, 위치 정확도 검증.
        """
        if self._emergency_active:
            logger.warning("긴급 정지 상태 — 명령 무시")
            return

        # V8.5: 드라이버 건전성 확인
        health = self._joints[joint_id].driver_health
        if health.status == DriverHealthStatus.OFFLINE:
            logger.warning("드라이버 오프라인 — %s: 명령 무시", joint_id.value)
            return

        torque_limit = min(torque_limit, MAX_TORQUE_LIMIT)

        command = XDriveCommand(
            target_position=position,
            target_velocity=velocity,
            torque_limit=torque_limit,
            control_mode=XDriveControlMode.POSITION,
        )
        self._send_command_with_retry(joint_id, command)

        # V8.5: 위치 정확도 검증 스케줄
        self._joints[joint_id].position_accuracy.target_position = position

    def set_velocity(
        self,
        joint_id: JointID,
        velocity: int,
        torque_limit: int = DEFAULT_TORQUE_LIMIT,
    ) -> None:
        """속도 제어 명령 전송"""
        if self._emergency_active:
            logger.warning("긴급 정지 상태 — 명령 무시")
            return

        command = XDriveCommand(
            target_velocity=velocity,
            torque_limit=torque_limit,
            control_mode=XDriveControlMode.VELOCITY,
        )
        self._send_command_with_retry(joint_id, command)

    def set_torque_limit(self, joint_id: JointID, torque_limit: int) -> None:
        """토크 제한 설정"""
        torque_limit = min(max(0, torque_limit), MAX_TORQUE_LIMIT)
        state = self._joints[joint_id]
        state.command.torque_limit = torque_limit
        self._send_command_with_retry(joint_id, state.command)
        logger.info("토크 제한 설정 — %s: %d", joint_id.value, torque_limit)

    def read_encoder(self, joint_id: JointID) -> Optional[int]:
        """엔코더 위치 읽기"""
        state = self._joints[joint_id]
        if state.feedback is not None:
            return state.feedback.position
        return None

    def emergency_stop(self) -> None:
        """긴급 정지 — CAN ID 0x500 브로드캐스트"""
        self._emergency_active = True
        try:
            self._send_can_frame(CAN_ID_EMERGENCY_STOP, b"\x01\x00\x00\x00\x00\x00\x00\x00")
            logger.warning("⚠️ XDRIVE 긴급 정지 — CAN ID 0x%03X 브로드캐스트", CAN_ID_EMERGENCY_STOP)
        except Exception as e:
            logger.error("긴급 정지 전송 실패: %s", e)
        for joint_id, state in self._joints.items():
            state.mode = XDriveControlMode.IDLE

    def release_emergency(self) -> None:
        """긴급 정지 해제"""
        self._emergency_active = False
        try:
            self._send_can_frame(CAN_ID_EMERGENCY_STOP, b"\x00\x00\x00\x00\x00\x00\x00\x00")
            logger.info("XDRIVE 긴급 정지 해제")
        except Exception as e:
            logger.error("긴급 정지 해제 전송 실패: %s", e)

    # ========================================================================
    # 하트비트 및 피드백 수신
    # ========================================================================

    def send_heartbeat(self) -> None:
        """하트비트 전송 (CAN ID: 0x501)"""
        now = time.monotonic()
        if now - self._last_heartbeat_time < HEARTBEAT_PERIOD_S:
            return
        try:
            uptime_ms = int(now * 1000) & 0xFFFFFFFF
            data = struct.pack(">BIxxx", 0x01, uptime_ms)
            self._send_can_frame(CAN_ID_HEARTBEAT, data)
            self._last_heartbeat_time = now
        except Exception as e:
            logger.error("하트비트 전송 실패: %s", e)

    def process_feedback(self, timeout_ms: int = 10) -> int:
        """
        CAN 피드백 수신 및 처리

        V8.5: 에러 프레임 처리, 건전성 업데이트.
        """
        if self._can_bus is None:
            return 0

        processed = 0
        try:
            import can
            msg = self._can_bus.recv(timeout=timeout_ms / 1000.0)
            if msg is not None:
                # V8.5: 에러 프레임 감지
                is_error = msg.is_error_frame if hasattr(msg, 'is_error_frame') else False
                frame = CANFrame(
                    can_id=msg.arbitration_id,
                    data=bytes(msg.data),
                    timestamp=time.monotonic(),
                    is_error_frame=is_error,
                )

                if is_error_frame:
                    self._handle_can_error_frame(frame)
                else:
                    self._handle_can_frame(frame)

                processed = 1
        except Exception as e:
            logger.error("CAN 수신 오류: %s", e)

        return processed

    def register_feedback_callback(
        self, callback: Callable[[XDriveFeedback], None]
    ) -> None:
        self._feedback_callbacks.append(callback)

    # ========================================================================
    # V8.5: CAN 버스 오류 복구
    # ========================================================================

    def _send_command_with_retry(self, joint_id: JointID, command: XDriveCommand) -> None:
        """
        V8.5: 재시도가 포함된 CAN 명령 전송 / Send CAN command with retry.
        """
        for attempt in range(CAN_MAX_RETRIES + 1):
            try:
                self._send_command(joint_id, command)
                self._error_recovery.record_success(joint_id)
                self._error_recovery.reset_retry(joint_id)
                return
            except Exception as e:
                self._error_recovery.record_error(joint_id)
                logger.warning(
                    "CAN 명령 전송 실패 (시도 %d/%d) — %s: %s",
                    attempt + 1, CAN_MAX_RETRIES + 1, joint_id.value, e,
                )
                if attempt < CAN_MAX_RETRIES:
                    delay = self._error_recovery.get_retry_delay_ms(joint_id)
                    time.sleep(delay / 1000.0)
                    self._error_recovery.increment_retry(joint_id)

        logger.error("CAN 명령 전송 최종 실패 — %s", joint_id.value)

    def _handle_can_error_frame(self, frame: CANFrame) -> None:
        """
        V8.5: CAN 에러 프레임 처리 / Handle CAN error frame.

        에러 프레임 수신 시:
        1. 오류 유형 분석
        2. 해당 관절 상태 업데이트
        3. 필요 시 복구 동작
        """
        error_id = frame.can_id

        logger.error(
            "CAN 에러 프레임 수신 — ID: 0x%03X, 데이터: %s",
            error_id, frame.data.hex(),
        )

        # 에러 프레임이 특정 관절과 관련된 경우
        for joint_id, resp_id in JOINT_RESPONSE_IDS.items():
            if error_id == resp_id:
                state = self._joints[joint_id]
                state.can_errors += 1
                state.driver_health.error_count += 1
                self._error_recovery.record_error(joint_id)
                break

    # ========================================================================
    # V8.5: 모터 드라이버 건전성 모니터링
    # ========================================================================

    def update_driver_health(self, joint_id: JointID) -> DriverHealthData:
        """
        V8.5: 드라이버 건전성 업데이트 / Update driver health.

        평가 항목:
        1. 통신 응답 시간
        2. 온도 상태
        3. 에러 코드 누적
        4. 연속 타임아웃
        """
        state = self._joints[joint_id]
        health = state.driver_health
        now = time.monotonic()

        # 1. 응답 시간 확인
        if state.last_feedback_time > 0:
            latency = (now - state.last_feedback_time) * 1000
            health.response_latency_ms = latency
            if latency > DRIVER_HEALTH_TIMEOUT_MS:
                health.consecutive_timeouts += 1
            else:
                health.consecutive_timeouts = 0

        # 2. 온도 확인
        if state.feedback is not None:
            health.temperature_c = state.feedback.temperature
            if state.feedback.temperature >= DRIVER_TEMP_CRITICAL_C:
                logger.critical(
                    "드라이버 과열 위험 — %s: %d°C",
                    joint_id.value, state.feedback.temperature,
                )
            elif state.feedback.temperature >= DRIVER_TEMP_WARNING_C:
                logger.warning(
                    "드라이버 과열 경고 — %s: %d°C",
                    joint_id.value, state.feedback.temperature,
                )

        # 3. 에러 코드
        if state.feedback is not None:
            health.last_error_code = state.feedback.error_code

        # 4. 건전성 상태 판정
        if health.consecutive_timeouts >= 5:
            health.status = DriverHealthStatus.OFFLINE
        elif health.error_count >= DRIVER_MAX_ERROR_COUNT:
            health.status = DriverHealthStatus.CRITICAL
        elif health.temperature_c >= DRIVER_TEMP_CRITICAL_C:
            health.status = DriverHealthStatus.CRITICAL
        elif (health.temperature_c >= DRIVER_TEMP_WARNING_C or
              health.error_count >= DRIVER_MAX_ERROR_COUNT // 2):
            health.status = DriverHealthStatus.WARNING
        elif health.error_count > 0 or health.consecutive_timeouts > 0:
            health.status = DriverHealthStatus.DEGRADED
        else:
            health.status = DriverHealthStatus.HEALTHY

        health.last_response_time = now
        return health

    def get_driver_health(self, joint_id: JointID) -> DriverHealthData:
        """V8.5: 드라이버 건전성 조회 / Get driver health."""
        return self.update_driver_health(joint_id)

    def get_all_driver_health(self) -> Dict[JointID, DriverHealthData]:
        """V8.5: 모든 드라이버 건전성 조회."""
        result = {}
        for joint_id in self._joints:
            result[joint_id] = self.update_driver_health(joint_id)
        return result

    # ========================================================================
    # V8.5: 위치 제어 정확도 검증
    # ========================================================================

    def verify_position_accuracy(self, joint_id: JointID) -> PositionAccuracyData:
        """
        V8.5: 위치 제어 정확도 검증 / Verify position control accuracy.

        명령 위치와 실제 위치를 비교하여
        위치 제어 성능을 검증.
        """
        state = self._joints[joint_id]
        accuracy = state.position_accuracy

        if state.feedback is None:
            accuracy.verification_passed = False
            return accuracy

        target = state.command.target_position
        actual = state.feedback.position

        accuracy.target_position = target
        accuracy.actual_position = actual
        accuracy.position_error = abs(target - actual)
        accuracy.is_within_tolerance = accuracy.position_error <= POSITION_ACCURACY_TOLERANCE

        # 안정화 시간 추정
        if accuracy.position_error > POSITION_ACCURACY_TOLERANCE:
            accuracy.verification_passed = False
            logger.warning(
                "위치 정확도 검증 실패 — %s: 오차=%d (허용: %d)",
                joint_id.value, accuracy.position_error, POSITION_ACCURACY_TOLERANCE,
            )
        else:
            accuracy.verification_passed = True

        return accuracy

    def get_position_accuracy(self, joint_id: JointID) -> PositionAccuracyData:
        """V8.5: 위치 정확도 조회."""
        return self.verify_position_accuracy(joint_id)

    def get_all_position_accuracy(self) -> Dict[JointID, PositionAccuracyData]:
        """V8.5: 모든 관절 위치 정확도 조회."""
        return {jid: self.verify_position_accuracy(jid) for jid in self._joints}

    # ========================================================================
    # 상태 조회
    # ========================================================================

    def get_joint_state(self, joint_id: JointID) -> Optional[JointState]:
        return self._joints.get(joint_id)

    def get_all_joint_states(self) -> Dict[JointID, JointState]:
        return dict(self._joints)

    @property
    def is_emergency(self) -> bool:
        return self._emergency_active

    # ========================================================================
    # 내부 통신 메서드
    # ========================================================================

    def _send_command(self, joint_id: JointID, command: XDriveCommand) -> None:
        """CAN 명령 프레임 전송"""
        state = self._joints[joint_id]
        state.command = command
        state.mode = command.control_mode
        state.last_command_time = time.monotonic()

        data = command.to_bytes()
        self._send_can_frame(state.can_id, data)

        logger.debug(
            "CAN 명령 전송 — %s (0x%03X): pos=%d, vel=%d, torque=%d, mode=%s",
            joint_id.value, state.can_id,
            command.target_position, command.target_velocity,
            command.torque_limit, command.control_mode.name,
        )

    def _send_can_frame(self, can_id: int, data: bytes) -> None:
        """CAN 프레임 저수준 전송"""
        if self._can_bus is None:
            raise IOError("CAN 버스 미연결")

        import can
        msg = can.Message(
            arbitration_id=can_id,
            data=data[:CAN_FRAME_DLC],
            is_extended_id=False,
        )
        self._can_bus.send(msg)

    def _handle_can_frame(self, frame: CANFrame) -> None:
        """수신 CAN 프레임 처리"""
        for joint_id, resp_id in JOINT_RESPONSE_IDS.items():
            if frame.can_id == resp_id:
                try:
                    feedback = XDriveFeedback.from_can_frame(joint_id, frame)
                    state = self._joints[joint_id]
                    state.feedback = feedback
                    state.last_feedback_time = frame.timestamp
                    state.is_online = True
                    state.driver_health.consecutive_timeouts = 0

                    if feedback.error_code != 0:
                        state.error_count += 1
                        state.driver_health.error_count += 1
                        logger.warning(
                            "XDRIVE 에러 — %s: 코드 0x%02X (누적: %d)",
                            joint_id.value, feedback.error_code, state.error_count,
                        )

                    if feedback.temperature > 70:
                        logger.warning(
                            "과온도 — %s: %d°C", joint_id.value, feedback.temperature
                        )

                    for cb in self._feedback_callbacks:
                        try:
                            cb(feedback)
                        except Exception as e:
                            logger.error("피드백 콜백 오류: %s", e)

                    # V8.5: 위치 정확도 자동 검증
                    if state.mode == XDriveControlMode.POSITION:
                        self.verify_position_accuracy(joint_id)

                except Exception as e:
                    logger.error("피드백 파싱 실패 (0x%03X): %s", frame.can_id, e)
                break
