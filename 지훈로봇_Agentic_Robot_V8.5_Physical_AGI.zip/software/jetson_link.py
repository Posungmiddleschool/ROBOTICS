#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TODO 2: Jetson 간 이더넷 1Gbps 직결 통신
===========================================================

RJ45 크로스케이블 (Auto MDI-X) 직결, 정적 IP 설정
  - Jetson #1 (대뇌): 192.168.1.1
  - Jetson #2 (소뇌): 192.168.1.2

검증 기준:
  - ping < 0.5ms
  - iperf3 > 900Mbps

프로토콜:
  - ROS2 DDS (Fast-RTPS) — 주 통신
  - UART 115200bps — 백업 통신 (이더넷 장애 시 자동 전환)

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from hardware.config import (
    ComputeConfig,
    JihunRobotV7Config,
)

logger = logging.getLogger("jihun.v84.jetson_link")

# ============================================================================
# 상수
# ============================================================================

ETHERNET_INTERFACE = "eth0"
IP_JETSON_1 = "192.168.1.1"
IP_JETSON_2 = "192.168.1.2"
SUBNET_MASK = "255.255.255.0"
SUBNET_PREFIX = 24

# 성능 기준
PING_MAX_MS = 0.5          # 최대 핑 지연
IPERF3_MIN_MBPS = 900      # 최소 대역폭

# UART 백업 설정
UART_DEVICE = "/dev/ttyTHS1"
UART_BAUDRATE = 115200
UART_TIMEOUT_S = 5.0

# DDS 설정
DDS_PROFILE = "fast_rtps"
FAST_RTPS_XML = """<?xml version="1.0" encoding="UTF-8" ?>
<dds>
    <profiles xmlns="http://www.eprosima.com/XMLSchemas/fastRTPS_Profiles">
        <transport_descriptors>
            <transport_descriptor>
                <transport_id>udp_transport</transport_id>
                <type>UDPv4</type>
                <sendBufferSize>1048576</sendBufferSize>
                <receiveBufferSize>4194304</receiveBufferSize>
            </transport_descriptor>
        </transport_descriptors>
        <participant profile_name="jihun_participant" is_default_profile="true">
            <rtps>
                <useBuiltinTransports>false</useBuiltinTransports>
                <userTransports>
                    <transport_id>udp_transport</transport_id>
                </userTransports>
                <builtinTransports max_msg_size="65536"/>
            </rtps>
        </participant>
    </profiles>
</dds>
"""

CONFIG_DIR = Path("/opt/jihun")


@dataclass
class EthernetStatus:
    """이더넷 연결 상태"""
    interface: str = ETHERNET_INTERFACE
    is_up: bool = False
    ip_address: str = ""
    speed_mbps: int = 0
    duplex: str = ""
    link_detected: bool = False
    rx_bytes: int = 0
    tx_bytes: int = 0


@dataclass
class UARTStatus:
    """UART 백업 링크 상태"""
    device: str = UART_DEVICE
    is_open: bool = False
    baudrate: int = UART_BAUDRATE
    bytes_sent: int = 0
    bytes_received: int = 0
    last_heartbeat_s: float = 0.0


@dataclass
class LinkTestResult:
    """링크 테스트 결과"""
    ping_ms: float = -1.0
    ping_ok: bool = False
    iperf3_mbps: float = -1.0
    iperf3_ok: bool = False
    uart_ok: bool = False
    dds_ok: bool = False
    errors: List[str] = field(default_factory=list)


class JetsonLink:
    """
    TODO 2: Jetson 간 이더넷 1Gbps 직결 통신

    기능:
      - 이더넷 정적 IP 설정 (192.168.1.1 / 192.168.1.2)
      - 연결 테스트 (ping < 0.5ms, iperf3 > 900Mbps)
      - ROS2 DDS (Fast-RTPS) 설정
      - UART 백업 링크 설정
      - 이더넷 장애 시 UART 자동 전환 (Failover)
    """

    def __init__(self, config: Optional[JihunRobotV7Config] = None):
        self.config = config or JihunRobotV7Config()
        self.compute = self.config.compute
        self._eth_status = EthernetStatus()
        self._uart_status = UARTStatus()
        self._failover_active = False
        self._uart_serial = None

    # ========================================================================
    # 공용 메서드
    # ========================================================================

    def setup(self) -> bool:
        """전체 Jetson 간 통신 설정"""
        logger.info("=== Jetson 간 이더넷 직결 통신 설정 ===")

        # 1. 이더넷 직결 설정
        if not self.setup_ethernet_direct():
            logger.error("이더넷 직결 설정 실패")
            return False

        # 2. 연결 테스트
        test = self.test_connectivity()
        if not test.ping_ok:
            logger.error(f"ping 테스트 실패: {test.ping_ms:.2f}ms > {PING_MAX_MS}ms")
            return False

        if not test.iperf3_ok:
            logger.warning(f"iperf3 대역폭 부족: {test.iperf3_mbps:.0f}Mbps < {IPERF3_MIN_MBPS}Mbps")

        # 3. DDS 설정
        self.setup_dds()

        # 4. UART 백업 설정
        self.setup_uart_backup()

        logger.info("=== Jetson 간 통신 설정 완료 ===")
        return True

    def verify(self) -> bool:
        """현재 통신 상태 검증"""
        test = self.test_connectivity()
        return test.ping_ok

    # ========================================================================
    # TODO 2-1: 이더넷 직결 설정
    # ========================================================================

    def setup_ethernet_direct(self) -> bool:
        """
        이더넷 직결 정적 IP 설정

        Auto MDI-X 지원으로 크로스케이블 불필요 (일반 랜케이블 가능)
        Jetson #1: 192.168.1.1/24
        Jetson #2: 192.168.1.2/24
        """
        logger.info("이더넷 직결 설정 중...")

        # Jetson ID 확인
        jetson_id = self._detect_local_jetson_id()
        if jetson_id not in (1, 2):
            logger.error("Jetson ID 미확인 — IP 설정 불가")
            return False

        local_ip = IP_JETSON_1 if jetson_id == 1 else IP_JETSON_2
        remote_ip = IP_JETSON_2 if jetson_id == 1 else IP_JETSON_1

        logger.info(f"  Jetson #{jetson_id}: {local_ip} → 상대: {remote_ip}")

        # 1. 인터페이스 활성화
        if not self._bring_up_interface():
            return False

        # 2. 정적 IP 설정
        if not self._set_static_ip(local_ip):
            return False

        # 3. 네트워크 매니저 설정 저장 (재부팅 시 유지)
        self._save_nm_connection(jetson_id, local_ip)

        # 4. MTU 최적화 (ROS2 대용량 메시지용)
        self._set_mtu(9000)  # Jumbo Frame

        logger.info(f"  ✓ 이더넷 직결 설정 완료: {local_ip}/{SUBNET_PREFIX}")
        return True

    def _detect_local_jetson_id(self) -> int:
        """로컬 Jetson ID 감지"""
        id_path = Path("/opt/jihun/jetson_id")
        if id_path.exists():
            try:
                return int(id_path.read_text().strip())
            except (ValueError, IOError):
                pass
        return 0

    def _bring_up_interface(self) -> bool:
        """이더넷 인터페이스 활성화"""
        try:
            result = subprocess.run(
                ["sudo", "ip", "link", "set", ETHERNET_INTERFACE, "up"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                logger.info(f"  ✓ {ETHERNET_INTERFACE} 인터페이스 활성화")
                return True
            else:
                logger.error(f"  ✗ 인터페이스 활성화 실패: {result.stderr}")
                return False
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.error(f"  ✗ ip 명령 실행 불가: {e}")
            return False

    def _set_static_ip(self, ip_address: str) -> bool:
        """정적 IP 주소 설정"""
        try:
            # 기존 IP 제거
            subprocess.run(
                ["sudo", "ip", "addr", "flush", "dev", ETHERNET_INTERFACE],
                capture_output=True, text=True, timeout=10,
            )

            # 새 IP 설정
            cidr = f"{ip_address}/{SUBNET_PREFIX}"
            result = subprocess.run(
                ["sudo", "ip", "addr", "add", cidr, "dev", ETHERNET_INTERFACE],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                logger.info(f"  ✓ 정적 IP 설정: {cidr}")
                self._eth_status.ip_address = ip_address
                return True
            else:
                logger.error(f"  ✗ IP 설정 실패: {result.stderr}")
                return False
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.error(f"  ✗ IP 설정 불가: {e}")
            return False

    def _set_mtu(self, mtu: int) -> bool:
        """MTU 설정 (Jumbo Frame 지원 시)"""
        try:
            result = subprocess.run(
                ["sudo", "ip", "link", "set", ETHERNET_INTERFACE, "mtu", str(mtu)],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                logger.info(f"  ✓ MTU 설정: {mtu}")
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        logger.warning(f"  ⚠ MTU {mtu} 설정 실패 — 표준 MTU 사용")
        return False

    def _save_nm_connection(self, jetson_id: int, ip_address: str) -> bool:
        """NetworkManager 연결 프로파일 저장 (재부팅 시 자동 연결)"""
        conn_name = "jihun-jetson-link"
        try:
            # 기존 연결 삭제
            subprocess.run(
                ["sudo", "nmcli", "connection", "delete", conn_name],
                capture_output=True, text=True, timeout=10,
            )

            # 새 연결 생성
            result = subprocess.run([
                "sudo", "nmcli", "connection", "add",
                "type", "ethernet",
                "ifname", ETHERNET_INTERFACE,
                "con-name", conn_name,
                "ipv4.method", "manual",
                "ipv4.addresses", f"{ip_address}/{SUBNET_PREFIX}",
                "connection.autoconnect", "true",
            ], capture_output=True, text=True, timeout=10)

            if result.returncode == 0:
                logger.info(f"  ✓ NetworkManager 프로파일 저장: {conn_name}")
                return True
            else:
                logger.warning(f"  ⚠ nmcli 저장 실패: {result.stderr}")
                return False
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.warning(f"  ⚠ NetworkManager 설정 불가: {e}")
            return False

    # ========================================================================
    # TODO 2-2: 연결 테스트
    # ========================================================================

    def test_connectivity(self) -> LinkTestResult:
        """
        이더넷 직결 연결 테스트

        검증 기준:
          - ping < 0.5ms (직결이므로 마이크로초 단위여야 함)
          - iperf3 > 900Mbps (1Gbps 이더넷)
        """
        result = LinkTestResult()

        jetson_id = self._detect_local_jetson_id()
        if jetson_id not in (1, 2):
            result.errors.append("Jetson ID 미확인")
            return result

        remote_ip = IP_JETSON_2 if jetson_id == 1 else IP_JETSON_1

        # 1. ping 테스트
        result.ping_ms = self._run_ping_test(remote_ip)
        result.ping_ok = 0 < result.ping_ms < PING_MAX_MS
        if result.ping_ok:
            logger.info(f"  ✓ ping {remote_ip}: {result.ping_ms:.3f}ms < {PING_MAX_MS}ms")
        else:
            logger.warning(f"  ✗ ping {remote_ip}: {result.ping_ms:.3f}ms")

        # 2. iperf3 대역폭 테스트
        result.iperf3_mbps = self._run_iperf3_test(remote_ip)
        result.iperf3_ok = result.iperf3_mbps > IPERF3_MIN_MBPS
        if result.iperf3_ok:
            logger.info(f"  ✓ iperf3: {result.iperf3_mbps:.0f}Mbps > {IPERF3_MIN_MBPS}Mbps")
        else:
            logger.warning(f"  ⚠ iperf3: {result.iperf3_mbps:.0f}Mbps")

        # 3. 이더넷 상태 업데이트
        self._update_ethernet_status()

        return result

    def _run_ping_test(self, target_ip: str, count: int = 10) -> float:
        """ping 테스트 — 평균 왕복 시간(ms) 반환"""
        try:
            result = subprocess.run(
                ["ping", "-c", str(count), "-i", "0.1", target_ip],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                # "rtt min/avg/max/mdev = 0.015/0.023/0.045/0.008 ms"
                for line in result.stdout.splitlines():
                    if "rtt" in line and "=" in line:
                        parts = line.split("=")[-1].strip()
                        avg = parts.split("/")[1]
                        return float(avg)
            return -1.0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return -1.0

    def _run_iperf3_test(self, target_ip: str, duration: int = 5) -> float:
        """iperf3 대역폭 테스트 — Mbps 반환"""
        try:
            # iperf3 클라이언트 모드로 상대방 서버에 연결
            result = subprocess.run(
                ["iperf3", "-c", target_ip, "-t", str(duration), "-J"],
                capture_output=True, text=True, timeout=duration + 10,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                summary = data.get("end", {}).get("sum_sent", {})
                bps = summary.get("bits_per_second", 0)
                return bps / 1_000_000  # bps → Mbps
        except (FileNotFoundError, json.JSONDecodeError, subprocess.TimeoutExpired):
            pass

        logger.warning("  iperf3 테스트 불가 — iperf3 서버가 원격 Jetson에서 실행 중인지 확인")
        return -1.0

    def _update_ethernet_status(self) -> EthernetStatus:
        """이더넷 인터페이스 상태 업데이트"""
        status = EthernetStatus()

        try:
            # ip addr로 상태 조회
            result = subprocess.run(
                ["ip", "-j", "addr", "show", ETHERNET_INTERFACE],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                if data:
                    iface = data[0]
                    status.is_up = iface.get("operstate") == "UP"
                    for addr_info in iface.get("addr_info", []):
                        if addr_info.get("family") == "inet":
                            status.ip_address = addr_info.get("local", "")
                            break
        except (FileNotFoundError, json.JSONDecodeError, subprocess.TimeoutExpired):
            pass

        try:
            # ethtool로 속도/이중화 조회
            result = subprocess.run(
                ["ethtool", ETHERNET_INTERFACE],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if "Speed:" in line:
                        status.speed_mbps = int(line.split(":")[1].strip().replace("Mb/s", ""))
                    elif "Duplex:" in line:
                        status.duplex = line.split(":")[1].strip()
                    elif "Link detected:" in line:
                        status.link_detected = "yes" in line.lower()
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        self._eth_status = status
        return status

    # ========================================================================
    # TODO 2-3: ROS2 DDS 설정
    # ========================================================================

    def setup_dds(self) -> bool:
        """
        ROS2 DDS (Fast-RTPS) 설정

        최적화:
          - 송신 버퍼 1MB, 수신 버퍼 4MB
          - UDPv4 전용 (공유 메모리 불필요 — 직결)
          - 대용량 메시지 지원 (비전 이미지 전송)
        """
        logger.info("ROS2 DDS (Fast-RTPS) 설정 중...")

        # 1. Fast-RTPS XML 프로파일 작성
        dds_config_path = CONFIG_DIR / "fast_rtps_profile.xml"
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            dds_config_path.write_text(FAST_RTPS_XML)
            logger.info(f"  ✓ Fast-RTPS 프로파일: {dds_config_path}")
        except IOError as e:
            logger.error(f"  ✗ DDS 프로파일 저장 실패: {e}")
            return False

        # 2. 환경 변수 설정
        env_vars = {
            "FASTRTPS_DEFAULT_PROFILES_FILE": str(dds_config_path),
            "RMW_IMPLEMENTATION": "rmw_fastrtps_cpp",
            "ROS_DOMAIN_ID": str(self.compute.ros2_domain_id),
            "ROS_AUTOMATIC_DISCOVERY_RANGE": "SUBNET",
        }

        env_path = CONFIG_DIR / "dds_env.sh"
        try:
            lines = [f'export {k}="{v}"' for k, v in env_vars.items()]
            env_path.write_text("\n".join(lines) + "\n")
            logger.info(f"  ✓ DDS 환경 변수: {env_path}")
        except IOError as e:
            logger.warning(f"  ⚠ DDS 환경 변수 저장 실패: {e}")

        # 3. 멀티캐스트 비전 스트림 설정
        self._setup_vision_multicast()

        logger.info("  ✓ DDS 설정 완료")
        return True

    def _setup_vision_multicast(self) -> None:
        """비전 스트림 UDP 멀티캐스트 설정"""
        # 비전 이미지는 직결 이더넷으로 고속 전송
        # Jetson #1 → Jetson #2 로 객체 탐지 결과 전송
        multicast_config = {
            "vision_stream_ip": "239.255.0.1",
            "vision_stream_port": 50051,
            "vision_stream_fps": 30,
            "vision_stream_codec": "jpeg",
            "vision_stream_quality": 80,
        }

        config_path = CONFIG_DIR / "vision_multicast.json"
        try:
            config_path.write_text(json.dumps(multicast_config, indent=2))
            logger.info(f"  ✓ 비전 멀티캐스트 설정: {config_path}")
        except IOError as e:
            logger.warning(f"  ⚠ 비전 멀티캐스트 설정 실패: {e}")

    # ========================================================================
    # TODO 2-4: UART 백업 링크
    # ========================================================================

    def setup_uart_backup(self) -> bool:
        """
        UART 115200bps 백업 링크 설정

        Jetson #2 ↔ Jetson #1 UART 직결
        이더넷 장애 시 자동 전환용 하트비트 채널
        """
        logger.info("UART 백업 링크 설정 중...")

        try:
            import serial
            self._uart_serial = serial.Serial(
                port=UART_DEVICE,
                baudrate=UART_BAUDRATE,
                timeout=1.0,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
            )
            self._uart_status.is_open = True
            logger.info(
                f"  ✓ UART 백업 열림: {UART_DEVICE} @ {UART_BAUDRATE}bps"
            )
            return True
        except ImportError:
            logger.warning("  ⚠ pyserial 미설치 — UART 백업 비활성화")
            logger.warning("    설치: pip install pyserial")
            return False
        except Exception as e:
            logger.warning(f"  ⚠ UART 열기 실패: {e}")
            logger.warning(f"    장치 확인: ls -la {UART_DEVICE}")
            return False

    def _uart_send(self, data: bytes) -> bool:
        """UART로 데이터 전송"""
        if self._uart_serial and self._uart_status.is_open:
            try:
                self._uart_serial.write(data)
                self._uart_status.bytes_sent += len(data)
                return True
            except Exception as e:
                logger.error(f"UART 전송 실패: {e}")
                self._uart_status.is_open = False
        return False

    def _uart_receive(self, timeout: float = 1.0) -> Optional[bytes]:
        """UART에서 데이터 수신"""
        if self._uart_serial and self._uart_status.is_open:
            try:
                self._uart_serial.timeout = timeout
                data = self._uart_serial.read(256)
                if data:
                    self._uart_status.bytes_received += len(data)
                    return data
            except Exception as e:
                logger.error(f"UART 수신 실패: {e}")
                self._uart_status.is_open = False
        return None

    # ========================================================================
    # TODO 2-5: 이더넷 장애 시 UART 자동 전환 (Failover)
    # ========================================================================

    def failover_to_uart(self) -> bool:
        """
        이더넷 장애 시 UART로 자동 전환

        전환 조건:
          - ping 3회 연속 실패
          - 또는 DDS heartbeat 5초 이상 누락

        UART 모드:
          - 긴급 명령만 전송 (정지, 상태 보고)
          - 대역폭 제한 (115200bps ≈ 14KB/s)
        """
        logger.warning("이더넷 장애 감지 — UART 백업으로 전환 중...")

        if not self._uart_status.is_open:
            if not self.setup_uart_backup():
                logger.error("UART 백업도 불가 — 통신 완전 단절!")
                return False

        self._failover_active = True

        # UART로 긴급 상태 메시지 전송
        emergency_msg = b"FAILOVER:ETHERNET_DOWN\n"
        if self._uart_send(emergency_msg):
            logger.info("  ✓ UART로 장애 알림 전송 완료")
        else:
            logger.error("  ✗ UART 전송 실패")
            return False

        # 이더넷 복구 감시 스레드 시작
        logger.info("  UART 백업 모드 활성화 — 이더넷 복구 대기 중...")
        return True

    def check_ethernet_recovery(self) -> bool:
        """이더넷 복구 확인"""
        jetson_id = self._detect_local_jetson_id()
        if jetson_id not in (1, 2):
            return False

        remote_ip = IP_JETSON_2 if jetson_id == 1 else IP_JETSON_1
        ping_ms = self._run_ping_test(remote_ip, count=3)

        if 0 < ping_ms < PING_MAX_MS:
            logger.info(f"이더넷 복구 감지: ping {ping_ms:.3f}ms")
            self._failover_active = False
            return True
        return False

    @property
    def is_failover_active(self) -> bool:
        """현재 UART 백업 모드 여부"""
        return self._failover_active

    @property
    def active_link(self) -> str:
        """현재 활성 링크 (ethernet / uart)"""
        return "uart" if self._failover_active else "ethernet"

    # ========================================================================
    # 하트비트 모니터링
    # ========================================================================

    def send_heartbeat(self) -> bool:
        """하트비트 메시지 전송 (이더넷 + UART 동시)"""
        import struct
        import time as _time

        timestamp = _time.time()
        # 하트비트 패킷: [0xAA, 0x55, timestamp(8bytes double)]
        hb_data = struct.pack("!B Bd", 0xAA, 0x55, timestamp)

        # 이더넷으로 전송 (ROS2 토픽)
        eth_ok = not self._failover_active

        # UART로도 항상 전송
        uart_ok = self._uart_send(hb_data)

        if uart_ok:
            self._uart_status.last_heartbeat_s = timestamp

        return eth_ok or uart_ok

    def get_link_stats(self) -> Dict:
        """링크 통계 정보 반환"""
        return {
            "ethernet": {
                "interface": self._eth_status.interface,
                "is_up": self._eth_status.is_up,
                "ip_address": self._eth_status.ip_address,
                "speed_mbps": self._eth_status.speed_mbps,
                "duplex": self._eth_status.duplex,
                "link_detected": self._eth_status.link_detected,
            },
            "uart": {
                "device": self._uart_status.device,
                "is_open": self._uart_status.is_open,
                "baudrate": self._uart_status.baudrate,
                "bytes_sent": self._uart_status.bytes_sent,
                "bytes_received": self._uart_status.bytes_received,
                "last_heartbeat_s": self._uart_status.last_heartbeat_s,
            },
            "failover_active": self._failover_active,
            "active_link": self.active_link,
        }
