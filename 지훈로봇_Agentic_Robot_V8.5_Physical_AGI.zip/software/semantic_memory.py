#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 의미 기억 시스템 / Semantic Memory System
=========================================================

TODO 36: SemanticMemory 클래스 구현

LanceDB 벡터 저장소 — 모든 중요 정보를 임베딩하여 저장
임베딩: sentence-transformers/all-MiniLM-L6-v2 (80MB, 경량)
검색: 코사인 유사도 Top-5, <100ms 응답

검증: "소유자가 좋아하는 음료" 저장 → 회상 정확

버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("jihun.v84.semantic_memory")
logger.setLevel(logging.INFO)


# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

DEFAULT_DB_PATH = Path(
    os.getenv("SEMANTIC_DB_PATH", "/home/jihun/data/memory/semantic.db")
)
DEFAULT_LANCEDB_PATH = Path(
    os.getenv("SEMANTIC_LANCEDB_PATH", "/home/jihun/data/memory/lancedb")
)
EMBEDDING_DIMENSION = 384          # all-MiniLM-L6-v2 출력 차원
SEARCH_TOP_K = 5                   # 기본 검색 결과 수
SEARCH_RESPONSE_TIME_TARGET_MS = 100  # 검색 응답 시간 목표


# ──────────────────────────────────────────────────────────────────────────────
# 데이터 클래스 / Data Classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class SemanticFact:
    """의미 기억 팩트 — 중요 정보 단위"""
    fact_id: str = ""
    content: str = ""
    embedding: Optional[List[float]] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    source: str = ""                # 정보 출처
    confidence: float = 1.0         # 신뢰도 (0~1)
    access_count: int = 0           # 접근 횟수
    last_accessed: float = 0.0

    def __post_init__(self):
        if not self.fact_id:
            self.fact_id = f"fact_{int(self.timestamp * 1000)}"


# ──────────────────────────────────────────────────────────────────────────────
# 임베딩 엔진 (인터페이스) / Embedding Engine Interface
# ──────────────────────────────────────────────────────────────────────────────

class EmbeddingEngine:
    """
    임베딩 엔진 — sentence-transformers/all-MiniLM-L6-v2

    실제 환경: sentence-transformers 라이브러리 사용
    시뮬레이션 환경: 해시 기반 더미 임베딩 생성
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2") -> None:
        self._model_name = model_name
        self._dimension = EMBEDDING_DIMENSION
        self._model = None
        self._initialized = False

    def initialize(self) -> None:
        """임베딩 모델 초기화"""
        try:
            # 실제 환경에서 sentence-transformers 로드 시도
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self._model_name)
            self._initialized = True
            logger.info(
                f"임베딩 모델 로드 완료: {self._model_name} "
                f"(차원={self._dimension})"
            )
        except ImportError:
            logger.warning(
                "sentence-transformers 미설치 — "
                "해시 기반 더미 임베딩 사용"
            )
            self._initialized = False

    def embed(self, text: str) -> List[float]:
        """텍스트를 임베딩 벡터로 변환"""
        if self._model:
            embedding = self._model.encode(text).tolist()
            return embedding

        # 더미 임베딩 — 텍스트 해시 기반 (일관성 보장)
        return self._hash_embed(text)

    def _hash_embed(self, text: str) -> List[float]:
        """해시 기반 더미 임베딩 생성 — 동일 텍스트는 동일 벡터 보장"""
        import hashlib

        vector = [0.0] * self._dimension
        text_bytes = text.encode("utf-8")

        for i in range(self._dimension):
            # 각 차원에 대해 다른 해시 시드 사용
            seed = text_bytes + i.to_bytes(4, "little")
            hash_val = hashlib.sha256(seed).hexdigest()
            # 0~1 범위로 정규화
            vector[i] = int(hash_val[:8], 16) / 0xFFFFFFFF

        # L2 정규화 (코사인 유사도 계산을 위해)
        norm = sum(x * x for x in vector) ** 0.5
        if norm > 0:
            vector = [x / norm for x in vector]

        return vector

    @property
    def dimension(self) -> int:
        return self._dimension


# ──────────────────────────────────────────────────────────────────────────────
# 의미 기억 시스템 / Semantic Memory
# ──────────────────────────────────────────────────────────────────────────────

class SemanticMemory:
    """
    의미 기억 시스템 / Semantic Memory System

    LanceDB 벡터 저장소 기반 — 중요 정보를 임베딩하여 저장 및 검색

    핵심 기능:
    - store_fact(): 중요 정보 저장 (자동 임베딩)
    - search_similar(): 코사인 유사도 기반 의미 검색 (Top-5, <100ms)
    - update_fact(): 기존 팩트 업데이트
    - delete_fact(): 팩트 삭제

    임베딩: sentence-transformers/all-MiniLM-L6-v2 (80MB, 경량)
    검증: "소유자가 좋아하는 음료" 저장 → 정확 회상
    """

    def __init__(
        self,
        db_path: Path = DEFAULT_DB_PATH,
        lancedb_path: Path = DEFAULT_LANCEDB_PATH,
    ) -> None:
        self._db_path = db_path
        self._lancedb_path = lancedb_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)

        self._conn: Optional[sqlite3.Connection] = None
        self._embedding_engine = EmbeddingEngine()
        self._lance_db = None
        self._lance_table = None
        self._lock = threading.RLock()
        self._initialized = False

        # 인메모리 캐시 (빠른 검색용)
        self._fact_cache: Dict[str, SemanticFact] = {}

        logger.info(
            f"의미 기억 초기화: DB={db_path}, LanceDB={lancedb_path}"
        )

    async def initialize(self) -> None:
        """의미 기억 시스템 초기화"""
        # SQLite 초기화 (메타데이터 저장용)
        self._conn = sqlite3.connect(
            str(self._db_path), check_same_thread=False,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._create_tables()

        # 임베딩 엔진 초기화
        self._embedding_engine.initialize()

        # LanceDB 초기화 시도
        self._init_lancedb()

        # 기존 팩트 캐시 로드
        self._load_cache()

        self._initialized = True
        logger.info("의미 기억 시스템 초기화 완료")

    def _create_tables(self) -> None:
        """SQLite 테이블 생성"""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS semantic_facts (
                fact_id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                embedding BLOB,
                tags TEXT DEFAULT '[]',
                metadata TEXT DEFAULT '{}',
                timestamp REAL NOT NULL,
                source TEXT DEFAULT '',
                confidence REAL DEFAULT 1.0,
                access_count INTEGER DEFAULT 0,
                last_accessed REAL DEFAULT 0.0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_fact_timestamp "
            "ON semantic_facts(timestamp)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_fact_source "
            "ON semantic_facts(source)"
        )
        self._conn.commit()

    def _init_lancedb(self) -> None:
        """LanceDB 초기화 — 벡터 검색 엔진"""
        try:
            import lancedb
            self._lance_db = lancedb.connect(str(self._lancedb_path))

            # 기존 테이블 확인
            existing_tables = self._lance_db.table_names()
            if "facts" in existing_tables:
                self._lance_table = self._lance_db.open_table("facts")
                logger.info("LanceDB 기존 테이블 로드 완료")
            else:
                # 빈 테이블 생성
                import pyarrow as pa
                schema = pa.schema([
                    pa.field("fact_id", pa.string()),
                    pa.field("vector", pa.list_(pa.float32(), EMBEDDING_DIMENSION)),
                    pa.field("content", pa.string()),
                    pa.field("tags", pa.string()),
                    pa.field("timestamp", pa.float64()),
                ])
                self._lance_table = self._lance_db.create_table(
                    "facts", schema=schema,
                )
                logger.info("LanceDB 새 테이블 생성 완료")

        except ImportError:
            logger.warning(
                "lancedb 미설치 — SQLite 기반 검색만 사용 "
                "(의미 검색 성능 저하)"
            )
            self._lance_db = None
            self._lance_table = None

    def _load_cache(self) -> None:
        """기존 팩트를 인메모리 캐시에 로드"""
        try:
            cursor = self._conn.execute(
                "SELECT fact_id, content, tags, metadata, timestamp, "
                "source, confidence, access_count, last_accessed "
                "FROM semantic_facts"
            )
            for row in cursor:
                fact = SemanticFact(
                    fact_id=row[0],
                    content=row[1],
                    tags=json.loads(row[2]) if row[2] else [],
                    metadata=json.loads(row[3]) if row[3] else {},
                    timestamp=row[4],
                    source=row[5],
                    confidence=row[6],
                    access_count=row[7],
                    last_accessed=row[8],
                )
                self._fact_cache[fact.fact_id] = fact
            logger.info(f"팩트 캐시 로드: {len(self._fact_cache)}개")
        except Exception as e:
            logger.error(f"캐시 로드 오류: {e}")

    # ──────────────────────────────────────────────────────────────────────
    # store_fact() — 팩트 저장
    # ──────────────────────────────────────────────────────────────────────

    def store_fact(
        self,
        fact: str,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        source: str = "",
        confidence: float = 1.0,
    ) -> str:
        """
        중요 정보 팩트 저장 — 자동 임베딩 생성

        검증: "소유자가 좋아하는 음료는 커피" 저장 → 정확 회상

        Args:
            fact: 저장할 팩트 텍스트
            tags: 검색용 태그
            metadata: 추가 메타데이터
            source: 정보 출처
            confidence: 신뢰도 (0~1)

        Returns:
            저장된 팩트 ID
        """
        with self._lock:
            timestamp = time.time()
            fact_id = f"fact_{int(timestamp * 1000)}"

            # 임베딩 생성
            embedding = self._embedding_engine.embed(fact)

            semantic_fact = SemanticFact(
                fact_id=fact_id,
                content=fact,
                embedding=embedding,
                tags=tags or [],
                metadata=metadata or {},
                timestamp=timestamp,
                source=source,
                confidence=confidence,
            )

            # SQLite에 저장
            try:
                import struct
                embedding_blob = struct.pack(
                    f"{len(embedding)}f", *embedding
                ) if embedding else None

                self._conn.execute(
                    """INSERT INTO semantic_facts
                       (fact_id, content, embedding, tags, metadata,
                        timestamp, source, confidence)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        fact_id,
                        fact,
                        embedding_blob,
                        json.dumps(tags or [], ensure_ascii=False),
                        json.dumps(metadata or {}, ensure_ascii=False),
                        timestamp,
                        source,
                        confidence,
                    ),
                )
                self._conn.commit()
            except Exception as e:
                logger.error(f"팩트 SQLite 저장 오류: {e}")

            # LanceDB에 저장
            if self._lance_table:
                try:
                    self._lance_table.add([{
                        "fact_id": fact_id,
                        "vector": embedding,
                        "content": fact,
                        "tags": json.dumps(tags or [], ensure_ascii=False),
                        "timestamp": timestamp,
                    }])
                except Exception as e:
                    logger.error(f"팩트 LanceDB 저장 오류: {e}")

            # 캐시에 저장
            self._fact_cache[fact_id] = semantic_fact

            logger.info(f"팩트 저장: '{fact[:50]}...' (ID: {fact_id})")
            return fact_id

    # ──────────────────────────────────────────────────────────────────────
    # search_similar() — 유사도 검색
    # ──────────────────────────────────────────────────────────────────────

    def search_similar(
        self,
        query: str,
        top_k: int = SEARCH_TOP_K,
        min_similarity: float = 0.3,
    ) -> List[Dict[str, Any]]:
        """
        코사인 유사도 기반 의미 검색 — Top-K 결과, <100ms 목표

        검증: "소유자가 좋아하는 음료" 쿼리 → "커피" 정확 회상

        Args:
            query: 검색 쿼리
            top_k: 반환할 최대 결과 수
            min_similarity: 최소 유사도 임계값

        Returns:
            유사도순 정렬된 결과 리스트
        """
        start_time = time.time()

        with self._lock:
            # 쿼리 임베딩
            query_embedding = self._embedding_engine.embed(query)

            results: List[Dict[str, Any]] = []

            # LanceDB 벡터 검색 시도
            if self._lance_table:
                results = self._search_lancedb(
                    query_embedding, top_k, min_similarity,
                )

            # LanceDB 실패 시 SQLite + 코사인 유사도 계산
            if not results:
                results = self._search_sqlite(
                    query_embedding, top_k, min_similarity,
                )

            # 캐시 기반 보완 검색
            if not results:
                results = self._search_cache(
                    query_embedding, top_k, min_similarity,
                )

            elapsed_ms = (time.time() - start_time) * 1000

            if elapsed_ms > SEARCH_RESPONSE_TIME_TARGET_MS:
                logger.warning(
                    f"의미 검색 응답 시간 초과: {elapsed_ms:.1f}ms "
                    f"(목표: {SEARCH_RESPONSE_TIME_TARGET_MS}ms)"
                )

            # 접근 카운트 업데이트
            for result in results:
                self._update_access_count(result.get("fact_id", ""))

            return results

    def _search_lancedb(
        self,
        query_embedding: List[float],
        top_k: int,
        min_similarity: float,
    ) -> List[Dict[str, Any]]:
        """LanceDB 벡터 검색"""
        try:
            search_results = self._lance_table.search(
                query_embedding
            ).limit(top_k).to_pandas()

            results = []
            for _, row in search_results.iterrows():
                # LanceDB 거리 → 코사인 유사도 변환
                distance = row.get("_distance", 1.0)
                similarity = max(0.0, 1.0 - distance)

                if similarity >= min_similarity:
                    results.append({
                        "fact_id": row.get("fact_id", ""),
                        "content": row.get("content", ""),
                        "similarity": similarity,
                        "tags": json.loads(
                            row.get("tags", "[]")
                        ),
                        "timestamp": row.get("timestamp", 0),
                    })
            return results
        except Exception as e:
            logger.error(f"LanceDB 검색 오류: {e}")
            return []

    def _search_sqlite(
        self,
        query_embedding: List[float],
        top_k: int,
        min_similarity: float,
    ) -> List[Dict[str, Any]]:
        """SQLite 기반 코사인 유사도 검색 (LanceDB 미설치 시)"""
        results = []

        for fact_id, fact in self._fact_cache.items():
            if fact.embedding is None:
                continue

            similarity = self._cosine_similarity(
                query_embedding, fact.embedding,
            )

            if similarity >= min_similarity:
                results.append({
                    "fact_id": fact.fact_id,
                    "content": fact.content,
                    "similarity": similarity,
                    "tags": fact.tags,
                    "timestamp": fact.timestamp,
                    "metadata": fact.metadata,
                })

        # 유사도순 정렬
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:top_k]

    def _search_cache(
        self,
        query_embedding: List[float],
        top_k: int,
        min_similarity: float,
    ) -> List[Dict[str, Any]]:
        """캐시 기반 보완 검색"""
        results = []
        query_lower = ""

        # 임베딩 검색이 실패한 경우 키워드 기반 폴백
        for fact_id, fact in self._fact_cache.items():
            # 간단한 키워드 매칭 점수
            keyword_score = self._keyword_match_score(
                query_lower or "", fact.content,
            )
            if keyword_score > 0:
                results.append({
                    "fact_id": fact.fact_id,
                    "content": fact.content,
                    "similarity": keyword_score,
                    "tags": fact.tags,
                    "timestamp": fact.timestamp,
                })

        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:top_k]

    @staticmethod
    def _cosine_similarity(
        vec_a: List[float], vec_b: List[float],
    ) -> float:
        """코사인 유사도 계산"""
        if len(vec_a) != len(vec_b) or not vec_a:
            return 0.0

        dot_product = sum(a * b for a, b in zip(vec_a, vec_b))
        norm_a = sum(a * a for a in vec_a) ** 0.5
        norm_b = sum(b * b for b in vec_b) ** 0.5

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return dot_product / (norm_a * norm_b)

    @staticmethod
    def _keyword_match_score(query: str, content: str) -> float:
        """키워드 매칭 점수 (폴백용)"""
        if not query or not content:
            return 0.0

        query_words = set(query.lower().split())
        content_words = set(content.lower().split())

        if not query_words:
            return 0.0

        overlap = query_words & content_words
        return len(overlap) / len(query_words)

    # ──────────────────────────────────────────────────────────────────────
    # update_fact() — 팩트 업데이트
    # ──────────────────────────────────────────────────────────────────────

    def update_fact(
        self,
        fact_id: str,
        content: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        confidence: Optional[float] = None,
    ) -> bool:
        """기존 팩트 업데이트 — 내용 변경 시 임베딩 재생성"""
        with self._lock:
            if fact_id not in self._fact_cache:
                logger.warning(f"업데이트 대상 팩트 없음: {fact_id}")
                return False

            fact = self._fact_cache[fact_id]
            updates = []

            if content is not None and content != fact.content:
                # 내용 변경 → 임베딩 재생성
                fact.content = content
                fact.embedding = self._embedding_engine.embed(content)
                updates.append("content")

            if tags is not None:
                fact.tags = tags
                updates.append("tags")

            if metadata is not None:
                fact.metadata = metadata
                updates.append("metadata")

            if confidence is not None:
                fact.confidence = confidence
                updates.append("confidence")

            if not updates:
                return True  # 변경 없음

            # SQLite 업데이트
            try:
                import struct
                embedding_blob = struct.pack(
                    f"{len(fact.embedding)}f", *fact.embedding
                ) if fact.embedding else None

                self._conn.execute(
                    """UPDATE semantic_facts
                       SET content = ?, embedding = ?, tags = ?,
                           metadata = ?, confidence = ?
                       WHERE fact_id = ?""",
                    (
                        fact.content,
                        embedding_blob,
                        json.dumps(fact.tags, ensure_ascii=False),
                        json.dumps(fact.metadata, ensure_ascii=False),
                        fact.confidence,
                        fact_id,
                    ),
                )
                self._conn.commit()
            except Exception as e:
                logger.error(f"팩트 업데이트 오류: {e}")
                return False

            logger.info(f"팩트 업데이트: {fact_id} ({', '.join(updates)})")
            return True

    # ──────────────────────────────────────────────────────────────────────
    # delete_fact() — 팩트 삭제
    # ──────────────────────────────────────────────────────────────────────

    def delete_fact(self, fact_id: str) -> bool:
        """팩트 삭제"""
        with self._lock:
            try:
                self._conn.execute(
                    "DELETE FROM semantic_facts WHERE fact_id = ?",
                    (fact_id,),
                )
                self._conn.commit()

                # 캐시에서도 제거
                self._fact_cache.pop(fact_id, None)

                logger.info(f"팩트 삭제: {fact_id}")
                return True
            except Exception as e:
                logger.error(f"팩트 삭제 오류: {e}")
                return False

    # ──────────────────────────────────────────────────────────────────────
    # 유틸리티 / Utility Methods
    # ──────────────────────────────────────────────────────────────────────

    def _update_access_count(self, fact_id: str) -> None:
        """접근 카운트 업데이트"""
        if not fact_id:
            return
        try:
            self._conn.execute(
                """UPDATE semantic_facts
                   SET access_count = access_count + 1,
                       last_accessed = ?
                   WHERE fact_id = ?""",
                (time.time(), fact_id),
            )
            self._conn.commit()
        except Exception:
            pass

    def get_stats(self) -> Dict[str, Any]:
        """의미 기억 통계 반환"""
        try:
            count = self._conn.execute(
                "SELECT COUNT(*) FROM semantic_facts"
            ).fetchone()[0]
            return {
                "total_facts": count,
                "cached_facts": len(self._fact_cache),
                "lancedb_connected": self._lance_table is not None,
                "embedding_model": self._embedding_engine._model_name,
                "embedding_dimension": self._embedding_engine.dimension,
            }
        except Exception as e:
            return {"error": str(e)}

    def shutdown(self) -> None:
        """의미 기억 시스템 종료"""
        if self._conn:
            self._conn.close()
            self._conn = None
        logger.info("의미 기억 시스템 종료 완료")
