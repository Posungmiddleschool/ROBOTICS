#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 모터 전류 예산 분배 / Motor Current Budget Manager
==================================================================

TODO 45: CurrentBudgetManager 클래스 구현

총 가용 전류 25A → 휠 5A×4=20A + 다리 2.5A×2=5A
CAN 프레임: 토크 제한 필드로 개별 모터 전류 제한
검증: 4휠 동시 5A = 총 20A, BMS 미트리거
LiFePO4 2팩 병렬 30A 연속 → 25A 소프트웨어 제한 = 5A 여유

버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import threading
import time

import numpy as np
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("jihun.v84.current_budget")
logger.setLevel(logging.INFO)


# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

TOTAL_CURRENT_BUDGET_A = 25.0      # 총 가용 전류 (25A)
BMS_HARD_LIMIT_A = 30.0            # BMS 하드웨어 보호 (30A)
CURRENT_MARGIN_A = 5.0             # BMS 여유 전류 (30-25=5A)

# 모터별 기본 할당량
WHEEL_MOTOR_NAMES = [
    "wheel_front_left", "wheel_front_right",
    "wheel_rear_left", "wheel_rear_right",
]
WHEEL_MOTOR_BUDGET_A = 5.0         # 휠당 5A × 4 = 20A

LEG_MOTOR_NAMES = ["leg_left", "leg_right"]
LEG_MOTOR_BUDGET_A = 2.5           # 다리당 2.5A × 2 = 5A

GRIPPER_MOTOR_NAMES = ["gripper_left", "gripper_right", "gripper_wrist"]
GRIPPER_MOTOR_BUDGET_A = 1.0       # 그리퍼 서보당 1A


class MotorGroup(Enum):
    """모터 그룹"""
    WHEEL = "wheel"
    LEG = "leg"
    GRIPPER = "gripper"


@dataclass
class MotorAllocation:
    """개별 모터 전류 할당"""
    motor_name: str = ""
    group: MotorGroup = MotorGroup.WHEEL
    budget_a: float = 0.0          # 할당된 전류 (A)
    requested_a: float = 0.0       # 요청된 전류 (A)
    actual_a: float = 0.0          # 실제 소비 전류 (A)
    can_id: int = 0                # CAN ID (토크 제한용)
    priority: int = 0              # 우선순위 (낮을수록 높음)


# ──────────────────────────────────────────────────────────────────────────────
# 전류 예산 관리자 / Current Budget Manager
# ──────────────────────────────────────────────────────────────────────────────

class CurrentBudgetManager:
    """
    모터 전류 예산 분배 시스템 / Motor Current Budget Manager

    총 가용 전류 25A를 모터 그룹별로 분배:
    - 휠 4개: 5A × 4 = 20A (주행)
    - 다리 2개: 2.5A × 2 = 5A (승강/피치)
    - 그리퍼 3개: 서보 전류 (휠/다리에서 분배)

    CAN 프레임을 통해 개별 모터의 토크 제한 필드 설정

    검증: 4휠 동시 5A = 총 20A, BMS 미트리거
    LiFePO4 2팩 병렬 30A 연속 → 25A 소프트웨어 제한 = 5A 여유
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._allocations: Dict[str, MotorAllocation] = {}

        # 초기 할당 설정
        self._init_default_allocations()

        logger.info(
            f"전류 예산 관리자 초기화: "
            f"총예산={TOTAL_CURRENT_BUDGET_A}A, "
            f"BMS한계={BMS_HARD_LIMIT_A}A"
        )

    def _init_default_allocations(self) -> None:
        """기본 모터 전류 할당 초기화"""
        can_id_base = 0x10

        # 휠 모터 (4개 × 5A = 20A)
        for i, name in enumerate(WHEEL_MOTOR_NAMES):
            self._allocations[name] = MotorAllocation(
                motor_name=name,
                group=MotorGroup.WHEEL,
                budget_a=WHEEL_MOTOR_BUDGET_A,
                can_id=can_id_base + i,
                priority=0,  # 최고 우선순위
            )

        # 다리 모터 (2개 × 2.5A = 5A)
        for i, name in enumerate(LEG_MOTOR_NAMES):
            self._allocations[name] = MotorAllocation(
                motor_name=name,
                group=MotorGroup.LEG,
                budget_a=LEG_MOTOR_BUDGET_A,
                can_id=0x20 + i,
                priority=1,
            )

        # 그리퍼 서보 (3개 × 1A = 3A, 휠 예산에서 차감)
        for i, name in enumerate(GRIPPER_MOTOR_NAMES):
            self._allocations[name] = MotorAllocation(
                motor_name=name,
                group=MotorGroup.GRIPPER,
                budget_a=GRIPPER_MOTOR_BUDGET_A,
                can_id=0x30 + i,
                priority=2,
            )

    # ──────────────────────────────────────────────────────────────────────
    # allocate() — 전체 예산 분배
    # ──────────────────────────────────────────────────────────────────────

    def allocate(
        self,
        custom_budgets: Optional[Dict[str, float]] = None,
    ) -> Dict[str, float]:
        """
        전체 전류 예산 분배 — 모터별 할당량 계산

        Args:
            custom_budgets: 커스텀 할당량 (None=기본값)

        Returns:
            모터별 할당 전류 딕셔너리
        """
        with self._lock:
            if custom_budgets:
                total_custom = sum(custom_budgets.values())
                if total_custom > TOTAL_CURRENT_BUDGET_A:
                    # 비율 조정
                    scale = TOTAL_CURRENT_BUDGET_A / total_custom
                    for name, budget in custom_budgets.items():
                        if name in self._allocations:
                            self._allocations[name].budget_a = (
                                budget * scale
                            )
                else:
                    for name, budget in custom_budgets.items():
                        if name in self._allocations:
                            self._allocations[name].budget_a = budget

            # CAN 프레임으로 토크 제한 전송
            self._send_torque_limits()

            return self.get_budgets()

    # ──────────────────────────────────────────────────────────────────────
    # request_current() — 전류 요청
    # ──────────────────────────────────────────────────────────────────────

    def request_current(
        self,
        motor_name: str,
        requested_a: float,
    ) -> Tuple[bool, float]:
        """
        개별 모터 전류 요청 — 예산 내에서 허용

        Args:
            motor_name: 모터 이름
            requested_a: 요청 전류 (A)

        Returns:
            (허용여부, 허용된 전류)
        """
        with self._lock:
            allocation = self._allocations.get(motor_name)
            if not allocation:
                logger.warning(f"알 수 없는 모터: {motor_name}")
                return False, 0.0

            # 예산 내인지 확인
            if requested_a <= allocation.budget_a:
                allocation.requested_a = requested_a
                allocation.actual_a = requested_a
                return True, requested_a

            # 예산 초과 시 최대 허용량 반환
            logger.warning(
                f"전류 요청 초과: {motor_name} "
                f"요청={requested_a:.1f}A, 할당={allocation.budget_a:.1f}A"
            )
            allocation.requested_a = requested_a
            allocation.actual_a = allocation.budget_a
            return False, allocation.budget_a

    # ──────────────────────────────────────────────────────────────────────
    # release_current() — 전류 해제
    # ──────────────────────────────────────────────────────────────────────

    def release_current(self, motor_name: str) -> bool:
        """
        모터 전류 해제 — 사용하지 않는 전류를 다른 모터에 재분배

        Args:
            motor_name: 모터 이름

        Returns:
            해제 성공 여부
        """
        with self._lock:
            allocation = self._allocations.get(motor_name)
            if not allocation:
                return False

            allocation.requested_a = 0.0
            allocation.actual_a = 0.0

            logger.debug(f"전류 해제: {motor_name}")
            return True

    # ──────────────────────────────────────────────────────────────────────
    # check_budget() — 예산 확인
    # ──────────────────────────────────────────────────────────────────────

    def check_budget(self) -> Dict[str, Any]:
        """
        전체 전류 예산 상태 확인

        Returns:
            예산 상태 정보
        """
        with self._lock:
            total_used = sum(
                a.actual_a for a in self._allocations.values()
            )
            total_budget = sum(
                a.budget_a for a in self._allocations.values()
            )
            remaining = TOTAL_CURRENT_BUDGET_A - total_used

            group_usage = {}
            for group in MotorGroup:
                group_motors = [
                    a for a in self._allocations.values()
                    if a.group == group
                ]
                group_usage[group.value] = {
                    "budget_a": sum(a.budget_a for a in group_motors),
                    "used_a": sum(a.actual_a for a in group_motors),
                    "count": len(group_motors),
                }

            return {
                "total_budget_a": TOTAL_CURRENT_BUDGET_A,
                "total_used_a": total_used,
                "total_remaining_a": remaining,
                "bms_limit_a": BMS_HARD_LIMIT_A,
                "margin_a": CURRENT_MARGIN_A,
                "within_budget": total_used <= TOTAL_CURRENT_BUDGET_A,
                "bms_safe": total_used <= BMS_HARD_LIMIT_A,
                "group_usage": group_usage,
            }

    # ──────────────────────────────────────────────────────────────────────
    # CAN 프레임 토크 제한 전송
    # ──────────────────────────────────────────────────────────────────────

    def _send_torque_limits(self) -> None:
        """
        CAN 프레임으로 개별 모터 토크 제한 전송

        CAN 프레임 구조 (8바이트):
        [모터ID:1] [제어모드:1] [토크제한:2] [속도명령:2] [예비:2]
        토크 제한 필드: mA 단위 (0~10000 = 0~10A)
        """
        for name, allocation in self._allocations.items():
            torque_limit_ma = int(allocation.budget_a * 1000)

            # CAN 프레임 생성
            can_frame = {
                "can_id": allocation.can_id,
                "dlc": 8,
                "data": [
                    allocation.can_id & 0xFF,     # 모터 ID
                    0x02,                          # 제어 모드 (토크)
                    (torque_limit_ma >> 8) & 0xFF, # 토크 상위
                    torque_limit_ma & 0xFF,         # 토크 하위
                    0x00, 0x00,                    # 속도 명령
                    0x00, 0x00,                    # 예비
                ],
            }

            logger.debug(
                f"CAN 토크 제한: {name} → "
                f"{allocation.budget_a:.1f}A (ID: 0x{allocation.can_id:02X})"
            )

    # ──────────────────────────────────────────────────────────────────────
    # 유틸리티 메서드
    # ──────────────────────────────────────────────────────────────────────

    def get_total_current(self) -> float:
        """총 사용 전류 반환"""
        return sum(a.actual_a for a in self._allocations.values())

    def get_budgets(self) -> Dict[str, float]:
        """모터별 할당 전류 반환"""
        return {
            name: alloc.budget_a
            for name, alloc in self._allocations.items()
        }

    def get_motor_info(self, motor_name: str) -> Optional[Dict[str, Any]]:
        """개별 모터 정보 반환"""
        alloc = self._allocations.get(motor_name)
        if not alloc:
            return None
        return {
            "name": alloc.motor_name,
            "group": alloc.group.value,
            "budget_a": alloc.budget_a,
            "requested_a": alloc.requested_a,
            "actual_a": alloc.actual_a,
            "can_id": f"0x{alloc.can_id:02X}",
            "priority": alloc.priority,
        }

    def get_all_motor_info(self) -> List[Dict[str, Any]]:
        """모든 모터 정보 반환"""
        return [
            self.get_motor_info(name)
            for name in self._allocations
        ]

    def get_stats(self) -> Dict[str, Any]:
        """전류 예산 관리 통계"""
        return self.check_budget()

    def shutdown(self) -> None:
        """전류 예산 관리자 종료"""
        logger.info("전류 예산 관리자 종료 완료")


# ============================================================================
# Dynamic Current Budget Rebalancing — 동적 전류 예산 재분배
# ============================================================================
# 기존: 정적 할당 (유휴 모터의 전류를 다른 모터가 사용 불가)
# 개선: 동적 재분배 + 실제 전류 피드백 + 과도 전류 관리
# ============================================================================

class DynamicCurrentBudgetManager:
    """동적 전류 예산 관리자
    
    혁신:
    1. 유휴 모터의 전류를 활성 모터에 재분배
    2. 실제 전류 센서 피드백 (추정값 아님)
    3. 모터 시동 과도 전류(Inrush Current) 관리
    4. 우선순위 기반 선점 (휠 > 다리 > 그리퍼)
    """
    
    TOTAL_BUDGET_A = 25.0  # A 총 전류 예산
    
    # 우선순위 (낮을수록 높음)
    PRIORITY = {
        'wheel': 0,
        'leg': 1,
        'gripper': 2,
    }
    
    # 모터별 명목 전류
    NOMINAL_CURRENT = {
        'wheel_1': 5.0, 'wheel_2': 5.0, 'wheel_3': 5.0, 'wheel_4': 5.0,
        'leg_1': 2.5, 'leg_2': 2.5,
        'gripper_1': 1.0, 'gripper_2': 1.0, 'gripper_3': 1.0,
    }
    
    # 과도 전류 배율 (시동 시)
    INRUSH_MULTIPLIER = 3.0
    INRUSH_DURATION_MS = 200
    
    def __init__(self):
        self._requested = {k: 0.0 for k in self.NOMINAL_CURRENT}
        self._actual = {k: 0.0 for k in self.NOMINAL_CURRENT}
        self._allocated = {k: 0.0 for k in self.NOMINAL_CURRENT}
        self._active = {k: False for k in self.NOMINAL_CURRENT}
        self._inrush_start = {k: 0.0 for k in self.NOMINAL_CURRENT}
        self._lock = threading.Lock()
        self._overload_count = 0
    
    def request_current(self, motor_name, current_a, activate=True):
        """전류 요청"""
        with self._lock:
            if motor_name not in self.NOMINAL_CURRENT:
                return 0.0
            
            self._requested[motor_name] = current_a
            was_active = self._active[motor_name]
            self._active[motor_name] = activate
            
            # 새로 활성화된 모터 → 과도 전류 기록
            if activate and not was_active:
                self._inrush_start[motor_name] = time.time()
            
            # 전체 예산 재계산
            self._rebalance()
            
            return self._allocated.get(motor_name, 0.0)
    
    def update_actual_current(self, motor_name, actual_a):
        """실제 전류 센서 값 업데이트"""
        with self._lock:
            if motor_name in self._actual:
                self._actual[motor_name] = actual_a
    
    def _rebalance(self):
        """동적 전류 재분배"""
        total_requested = sum(
            v for k, v in self._requested.items() if self._active[k]
        )
        
        # 과도 전류 고려
        now = time.time()
        inrush_budget = 0.0
        for k in self._active:
            if self._active[k]:
                dt = (now - self._inrush_start[k]) * 1000  # ms
                if dt < self.INRUSH_DURATION_MS:
                    inrush_budget += (
                        self._requested[k] * self.INRUSH_MULTIPLIER -
                        self._requested[k]
                    )
        
        effective_budget = self.TOTAL_BUDGET_A - inrush_budget * 0.5
        
        if total_requested <= effective_budget:
            # 예산 충분: 요청대로 할당
            for k in self.NOMINAL_CURRENT:
                if self._active[k]:
                    self._allocated[k] = self._requested[k]
                else:
                    self._allocated[k] = 0.0
        else:
            # 예산 부족: 우선순위 기반 할당
            remaining = effective_budget
            for priority_level in sorted(set(self.PRIORITY.values())):
                motors_at_level = [
                    k for k, v in self.PRIORITY.items()
                    if v == priority_level and self._active.get(f'{k}_1', self._active.get(k, False))
                ]
                # 더 정확한 매칭
                motors_at_level = []
                for k in self.NOMINAL_CURRENT:
                    category = k.rsplit('_', 1)[0]
                    if category in self.PRIORITY and self.PRIORITY[category] == priority_level and self._active[k]:
                        motors_at_level.append(k)
                
                if not motors_at_level:
                    continue
                
                level_request = sum(self._requested[k] for k in motors_at_level)
                
                if level_request <= remaining:
                    for k in motors_at_level:
                        self._allocated[k] = self._requested[k]
                    remaining -= level_request
                else:
                    # 비율적 축소
                    scale = remaining / level_request
                    for k in motors_at_level:
                        self._allocated[k] = self._requested[k] * scale
                    remaining = 0
                    self._overload_count += 1
            
            # 비활성 모터
            for k in self.NOMINAL_CURRENT:
                if not self._active[k]:
                    self._allocated[k] = 0.0
    
    def get_allocation(self, motor_name):
        return self._allocated.get(motor_name, 0.0)
    
    def get_all_allocations(self):
        return dict(self._allocated)
    
    @property
    def utilization(self):
        used = sum(self._actual.values())
        return used / self.TOTAL_BUDGET_A if self.TOTAL_BUDGET_A > 0 else 0
    
    @property
    def health(self):
        return {
            'total_budget': self.TOTAL_BUDGET_A,
            'total_requested': sum(v for k, v in self._requested.items() if self._active[k]),
            'total_allocated': sum(self._allocated.values()),
            'total_actual': sum(self._actual.values()),
            'overload_count': self._overload_count,
            'utilization': self.utilization,
        }
