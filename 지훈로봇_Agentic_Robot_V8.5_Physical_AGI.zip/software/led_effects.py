#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — NeoPixel LED 효과 컨트롤러
============================================

ESP32-S3 GPIO 38 → WS2812B NeoPixel ×8 (상태 표시)
모드별 색상 매핑, 애니메이션, 밝기 제어, 저전력 대기

TODO 50: led_effects.py

하드웨어:
  - WS2812B NeoPixel ×8
  - ESP32-S3 GPIO 38 (데이터 핀)
  - 색상 매핑: 대기=파랑, 수동=초록, 자율=노랑, 비상=빨강
  - 대기 모드 LED 10% 밝기 (저전력)

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional, Tuple

# NeoPixel 라이브러리 (실제 환경에서 활성화)
try:
    from neopixel import NeoPixel as _NeoPixel
    from machine import Pin
    NEOPIXEL_AVAILABLE = True
except ImportError:
    NEOPIXEL_AVAILABLE = False

logger = logging.getLogger(__name__)


# ============================================================================
# 열거형 및 상수
# ============================================================================

class LEDMode(Enum):
    """로봇 동작 모드 — LED 색상 매핑"""
    STANDBY = "standby"          # 대기 — 파랑
    MANUAL = "manual"            # 수동 제어 — 초록
    AUTONOMOUS = "autonomous"    # 자율 주행 — 노랑
    EMERGENCY = "emergency"      # 비상 정지 — 빨강
    CHARGING = "charging"        # 충전 중 — 청록
    MAINTENANCE = "maintenance"  # 유지보수 — 보라
    CUSTOM = "custom"            # 사용자 정의


class AnimationPattern(Enum):
    """LED 애니메이션 패턴"""
    SOLID = "solid"              # 고정 색상
    BREATHING = "breathing"      # 호흡 (밝기 서서히 변화)
    BLINKING = "blinking"        # 깜빡임
    RAINBOW = "rainbow"          # 무지개 순환
    CHASING = "chasing"          # 순차 점등
    PULSE = "pulse"              # 펄스 (빠른 호흡)
    WAVE = "wave"                # 파동
    ALTERNATING = "alternating"  # 교대 점등
    FIRE = "fire"                # 불꽃 효과
    CUSTOM = "custom"            # 사용자 정의


# 색상 상수 (R, G, B) — WS2812B는 GRB 포맷
COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_RED = (255, 0, 0)
COLOR_GREEN = (0, 255, 0)
COLOR_BLUE = (0, 0, 255)
COLOR_YELLOW = (255, 255, 0)
COLOR_CYAN = (0, 255, 255)
COLOR_MAGENTA = (255, 0, 255)
COLOR_ORANGE = (255, 165, 0)
COLOR_PURPLE = (128, 0, 128)
COLOR_PINK = (255, 105, 180)
COLOR_TEAL = (0, 128, 128)

# 모드별 기본 색상 매핑
MODE_COLOR_MAP: Dict[LEDMode, Tuple[int, int, int]] = {
    LEDMode.STANDBY: COLOR_BLUE,
    LEDMode.MANUAL: COLOR_GREEN,
    LEDMode.AUTONOMOUS: COLOR_YELLOW,
    LEDMode.EMERGENCY: COLOR_RED,
    LEDMode.CHARGING: COLOR_CYAN,
    LEDMode.MAINTENANCE: COLOR_PURPLE,
    LEDMode.CUSTOM: COLOR_WHITE,
}

# 모드별 기본 애니메이션 매핑
MODE_ANIMATION_MAP: Dict[LEDMode, AnimationPattern] = {
    LEDMode.STANDBY: AnimationPattern.BREATHING,
    LEDMode.MANUAL: AnimationPattern.SOLID,
    LEDMode.AUTONOMOUS: AnimationPattern.CHASING,
    LEDMode.EMERGENCY: AnimationPattern.BLINKING,
    LEDMode.CHARGING: AnimationPattern.PULSE,
    LEDMode.MAINTENANCE: AnimationPattern.ALTERNATING,
    LEDMode.CUSTOM: AnimationPattern.SOLID,
}

# 하드웨어 상수
NUM_PIXELS = 8
NEOPIXEL_PIN = 38
BRIGHTNESS_MAX = 1.0
BRIGHTNESS_STANDBY = 0.1    # 대기 모드 10% 밝기
BRIGHTNESS_DEFAULT = 0.5    # 기본 50% 밝기
BRIGHTNESS_EMERGENCY = 1.0  # 비상 100% 밝기

# 애니메이션 타이밍
ANIMATION_INTERVAL_MS = 50   # 애니메이션 업데이트 간격 (20fps)
BREATHING_PERIOD_MS = 3000   # 호흡 주기
BLINK_INTERVAL_MS = 500      # 깜빡임 간격
CHASE_INTERVAL_MS = 150      # 순차 점등 간격
PULSE_PERIOD_MS = 800        # 펄스 주기


# ============================================================================
# 데이터 클래스
# ============================================================================

@dataclass
class LEDState:
    """개별 LED 상태"""
    color: Tuple[int, int, int] = COLOR_BLACK
    brightness: float = BRIGHTNESS_DEFAULT
    is_on: bool = True


@dataclass
class AnimationConfig:
    """애니메이션 설정"""
    pattern: AnimationPattern = AnimationPattern.SOLID
    speed_ms: float = ANIMATION_INTERVAL_MS
    primary_color: Tuple[int, int, int] = COLOR_WHITE
    secondary_color: Tuple[int, int, int] = COLOR_BLACK
    loop: bool = True
    duration_s: float = 0.0   # 0이면 무한


# ============================================================================
# 색상 유틸리티
# ============================================================================

def rgb_to_grb(color: Tuple[int, int, int]) -> Tuple[int, int, int]:
    """RGB → GRB 변환 (WS2812B 포맷)"""
    return (color[1], color[0], color[2])


def scale_color(
    color: Tuple[int, int, int], brightness: float
) -> Tuple[int, int, int]:
    """밝기 조절된 색상 반환"""
    brightness = max(0.0, min(1.0, brightness))
    return (
        int(color[0] * brightness),
        int(color[1] * brightness),
        int(color[2] * brightness),
    )


def color_wheel(pos: int) -> Tuple[int, int, int]:
    """
    무지개 색상 생성 (0~255)

    Args:
        pos: 색상 위치 (0~255)

    Returns:
        (R, G, B) 튜플
    """
    pos = pos % 256
    if pos < 85:
        return (255 - pos * 3, pos * 3, 0)
    elif pos < 170:
        pos -= 85
        return (0, 255 - pos * 3, pos * 3)
    else:
        pos -= 170
        return (pos * 3, 0, 255 - pos * 3)


def blend_colors(
    c1: Tuple[int, int, int], c2: Tuple[int, int, int], t: float
) -> Tuple[int, int, int]:
    """
    두 색상 보간

    Args:
        c1: 시작 색상
        c2: 끝 색상
        t: 보간 비율 (0.0~1.0)
    """
    t = max(0.0, min(1.0, t))
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t),
    )


# ============================================================================
# 메인 클래스: NeoPixelController
# ============================================================================

class NeoPixelController:
    """
    지훈 로봇 V8.5 — NeoPixel LED 효과 컨트롤러

    ESP32-S3 GPIO 38 → WS2812B ×8 상태 표시
    - 모드 전환 시 즉시 LED 색상 변경
    - 대기 모드 LED 10% 밝기 (저전력)
    - 커스텀 애니메이션 패턴 지원
    - 10종 애니메이션 내장
    """

    def __init__(
        self,
        pin: int = NEOPIXEL_PIN,
        num_pixels: int = NUM_PIXELS,
        default_brightness: float = BRIGHTNESS_DEFAULT,
    ):
        self._pin = pin
        self._num_pixels = num_pixels
        self._default_brightness = default_brightness
        self._current_brightness = default_brightness

        # LED 상태 배열
        self._led_states: List[LEDState] = [
            LEDState() for _ in range(num_pixels)
        ]

        # 현재 모드 및 애니메이션
        self._current_mode = LEDMode.STANDBY
        self._animation_config = AnimationConfig()
        self._animation_running = False
        self._animation_step = 0
        self._animation_start_time = 0.0

        # NeoPixel 하드웨어 제어
        self._pixels = None
        self._initialized = False

        # 렌더링 스레드
        self._running = False
        self._render_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        # 커스텀 애니메이션 콜백
        self._custom_animation_cb: Optional[Callable] = None

        # 모드 전환 콜백
        self._on_mode_change: Optional[Callable[[LEDMode], None]] = None

        logger.info("NeoPixelController 인스턴스 생성 (pin=%d, pixels=%d)", pin, num_pixels)

    # --- 초기화 및 종료 ---

    def initialize(self) -> bool:
        """NeoPixel 초기화"""
        try:
            if NEOPIXEL_AVAILABLE:
                pin_obj = Pin(self._pin, Pin.OUT)
                self._pixels = _NeoPixel(pin_obj, self._num_pixels)
            else:
                logger.warning("neopixel 미사용 — 시뮬레이션 모드")

            self._initialized = True
            # 기본 모드 설정 (대기 = 파랑, 10% 밝기)
            self.set_mode(LEDMode.STANDBY)
            self._start_animation_loop()
            logger.info("NeoPixel 초기화 완료")
            return True
        except Exception as e:
            logger.error("NeoPixel 초기화 실패: %s", e)
            return False

    def shutdown(self) -> None:
        """NeoPixel 종료"""
        logger.info("NeoPixel 종료...")
        self._running = False
        if self._render_thread and self._render_thread.is_alive():
            self._render_thread.join(timeout=1.0)
        self._clear_all()
        logger.info("NeoPixel 종료 완료")

    # --- 색상 제어 ---

    def set_color(
        self,
        color: Tuple[int, int, int],
        pixel: Optional[int] = None,
        brightness: Optional[float] = None,
    ) -> None:
        """
        LED 색상 설정

        Args:
            color: (R, G, B) 색상 튜플
            pixel: LED 인덱스 (None이면 전체)
            brightness: 밝기 (None이면 현재 밝기 유지)
        """
        with self._lock:
            if brightness is not None:
                self._current_brightness = max(0.0, min(1.0, brightness))

            if pixel is not None:
                if 0 <= pixel < self._num_pixels:
                    self._led_states[pixel].color = color
                    self._led_states[pixel].brightness = self._current_brightness
                    self._led_states[pixel].is_on = True
            else:
                for state in self._led_states:
                    state.color = color
                    state.brightness = self._current_brightness
                    state.is_on = True

    def set_brightness(self, brightness: float) -> None:
        """
        전체 밝기 설정

        Args:
            brightness: 밝기 (0.0~1.0)
        """
        brightness = max(0.0, min(1.0, brightness))
        with self._lock:
            self._current_brightness = brightness
            for state in self._led_states:
                state.brightness = brightness

    # --- 모드 제어 ---

    def set_mode(self, mode: LEDMode) -> None:
        """
        동작 모드 설정 — LED 색상 즉시 변경

        Args:
            mode: LED 동작 모드
        """
        with self._lock:
            self._current_mode = mode
            color = MODE_COLOR_MAP.get(mode, COLOR_WHITE)
            pattern = MODE_ANIMATION_MAP.get(mode, AnimationPattern.SOLID)

            # 모드별 밝기 자동 설정
            if mode == LEDMode.STANDBY:
                self._current_brightness = BRIGHTNESS_STANDBY
            elif mode == LEDMode.EMERGENCY:
                self._current_brightness = BRIGHTNESS_EMERGENCY
            else:
                self._current_brightness = BRIGHTNESS_DEFAULT

            # 모든 LED에 색상 적용
            for state in self._led_states:
                state.color = color
                state.brightness = self._current_brightness
                state.is_on = True

            # 애니메이션 설정
            self._animation_config = AnimationConfig(
                pattern=pattern,
                primary_color=color,
            )
            self._animation_step = 0
            self._animation_start_time = time.time()
            self._animation_running = True

        # 모드 전환 콜백
        if self._on_mode_change:
            self._on_mode_change(mode)

        logger.info("LED 모드 변경: %s → 색상=%s, 밝기=%.0f%%",
                     mode.value, color, self._current_brightness * 100)

    # --- 애니메이션 제어 ---

    def animate(
        self,
        pattern: AnimationPattern,
        color: Optional[Tuple[int, int, int]] = None,
        secondary_color: Optional[Tuple[int, int, int]] = None,
        speed_ms: float = ANIMATION_INTERVAL_MS,
        duration_s: float = 0.0,
    ) -> None:
        """
        애니메이션 실행

        Args:
            pattern: 애니메이션 패턴
            color: 주 색상 (None이면 현재 색상)
            secondary_color: 보조 색상
            speed_ms: 애니메이션 속도 (ms)
            duration_s: 지속 시간 (0=무한)
        """
        with self._lock:
            self._animation_config = AnimationConfig(
                pattern=pattern,
                speed_ms=speed_ms,
                primary_color=color or self._led_states[0].color,
                secondary_color=secondary_color or COLOR_BLACK,
                duration_s=duration_s,
            )
            self._animation_step = 0
            self._animation_start_time = time.time()
            self._animation_running = True

        logger.info("애니메이션 시작: %s (속도=%.0fms)", pattern.value, speed_ms)

    def stop_animation(self) -> None:
        """애니메이션 정지 — 현재 색상 유지"""
        with self._lock:
            self._animation_running = False

    def register_custom_animation(
        self, callback: Callable[[int, int], List[Tuple[int, int, int]]]
    ) -> None:
        """
        커스텀 애니메이션 등록

        Args:
            callback: (step, num_pixels) → [(R,G,B), ...] 리스트 반환
        """
        self._custom_animation_cb = callback
        logger.info("커스텀 애니메이션 콜백 등록")

    # --- 내부 애니메이션 렌더링 ---

    def _start_animation_loop(self) -> None:
        """애니메이션 렌더링 루프 시작"""
        self._running = True
        self._render_thread = threading.Thread(
            target=self._animation_loop, daemon=True, name="NeoPixel-Animation"
        )
        self._render_thread.start()

    def _animation_loop(self) -> None:
        """애니메이션 렌더링 루프 (20fps)"""
        while self._running:
            start = time.time()

            with self._lock:
                if self._animation_running:
                    self._render_animation_frame()

            # 실제 LED 하드웨어 갱신
            self._flush_pixels()

            elapsed_ms = (time.time() - start) * 1000
            sleep_ms = max(0, ANIMATION_INTERVAL_MS - elapsed_ms)
            time.sleep(sleep_ms / 1000.0)

    def _render_animation_frame(self) -> None:
        """현재 애니메이션 프레임 렌더링"""
        config = self._animation_config
        step = self._animation_step
        elapsed = time.time() - self._animation_start_time

        # 지속 시간 확인
        if config.duration_s > 0 and elapsed > config.duration_s:
            self._animation_running = False
            return

        pattern = config.pattern
        color1 = config.primary_color
        color2 = config.secondary_color
        n = self._num_pixels

        if pattern == AnimationPattern.SOLID:
            self._set_all_solid(color1)

        elif pattern == AnimationPattern.BREATHING:
            # 사인파 밝기 변화 (호흡)
            phase = (elapsed * 1000 % BREATHING_PERIOD_MS) / BREATHING_PERIOD_MS
            brightness = 0.1 + 0.9 * (0.5 + 0.5 * __import__("math").sin(2 * 3.14159 * phase - 1.5708))
            scaled = scale_color(color1, brightness)
            self._set_all_solid(scaled)

        elif pattern == AnimationPattern.BLINKING:
            is_on = int(elapsed * 1000 / BLINK_INTERVAL_MS) % 2 == 0
            self._set_all_solid(color1 if is_on else COLOR_BLACK)

        elif pattern == AnimationPattern.RAINBOW:
            for i in range(n):
                hue = (step * 2 + i * (256 // n)) % 256
                self._led_states[i].color = color_wheel(hue)
                self._led_states[i].brightness = self._current_brightness
                self._led_states[i].is_on = True

        elif pattern == AnimationPattern.CHASING:
            active = step % n
            for i in range(n):
                if i == active:
                    self._led_states[i].color = color1
                    self._led_states[i].brightness = self._current_brightness
                    self._led_states[i].is_on = True
                else:
                    # 꼬리 효과 (이전 LED 희미하게)
                    dist = (active - i) % n
                    if dist <= 2:
                        tail_brightness = self._current_brightness * (0.3 / dist)
                        self._led_states[i].color = scale_color(color1, tail_brightness)
                        self._led_states[i].brightness = 1.0
                        self._led_states[i].is_on = True
                    else:
                        self._led_states[i].is_on = False

        elif pattern == AnimationPattern.PULSE:
            phase = (elapsed * 1000 % PULSE_PERIOD_MS) / PULSE_PERIOD_MS
            brightness = 0.2 + 0.8 * abs(__import__("math").sin(3.14159 * phase))
            scaled = scale_color(color1, brightness)
            self._set_all_solid(scaled)

        elif pattern == AnimationPattern.WAVE:
            for i in range(n):
                phase = (step * 0.1 + i * 0.5) % (2 * 3.14159)
                brightness = 0.1 + 0.9 * (0.5 + 0.5 * __import__("math").sin(phase))
                self._led_states[i].color = scale_color(color1, brightness)
                self._led_states[i].brightness = 1.0
                self._led_states[i].is_on = True

        elif pattern == AnimationPattern.ALTERNATING:
            is_even = int(elapsed * 1000 / 500) % 2 == 0
            for i in range(n):
                if (i % 2 == 0) == is_even:
                    self._led_states[i].color = color1
                    self._led_states[i].is_on = True
                else:
                    self._led_states[i].color = color2 or COLOR_BLACK
                    self._led_states[i].is_on = color2 != COLOR_BLACK
                self._led_states[i].brightness = self._current_brightness

        elif pattern == AnimationPattern.FIRE:
            # 불꽃 효과 — 난수 기반 색온도 변화
            import random
            for i in range(n):
                r = min(255, random.randint(180, 255))
                g = min(255, random.randint(30, 120))
                b = random.randint(0, 20)
                flicker = random.uniform(0.5, 1.0)
                self._led_states[i].color = scale_color((r, g, b), flicker)
                self._led_states[i].brightness = self._current_brightness
                self._led_states[i].is_on = True

        elif pattern == AnimationPattern.CUSTOM and self._custom_animation_cb:
            colors = self._custom_animation_cb(step, n)
            for i, c in enumerate(colors[:n]):
                self._led_states[i].color = c
                self._led_states[i].brightness = self._current_brightness
                self._led_states[i].is_on = True

        self._animation_step += 1

    def _set_all_solid(self, color: Tuple[int, int, int]) -> None:
        """모든 LED 동일 색상 설정"""
        for state in self._led_states:
            state.color = color
            state.brightness = self._current_brightness
            state.is_on = True

    def _flush_pixels(self) -> None:
        """LED 상태를 하드웨어에 반영"""
        if not self._pixels:
            return
        with self._lock:
            for i, state in enumerate(self._led_states):
                if state.is_on:
                    color = scale_color(state.color, state.brightness)
                    grb = rgb_to_grb(color)
                    self._pixels[i] = grb
                else:
                    self._pixels[i] = (0, 0, 0)
            self._pixels.write()

    def _clear_all(self) -> None:
        """모든 LED 끄기"""
        for state in self._led_states:
            state.is_on = False
            state.color = COLOR_BLACK
        self._flush_pixels()

    # --- 상태 조회 ---

    def get_mode(self) -> LEDMode:
        """현재 모드 반환"""
        return self._current_mode

    def get_brightness(self) -> float:
        """현재 밝기 반환"""
        return self._current_brightness

    def get_led_states(self) -> List[Dict]:
        """LED 상태 목록 반환"""
        with self._lock:
            return [
                {
                    "index": i,
                    "color": s.color,
                    "brightness": s.brightness,
                    "is_on": s.is_on,
                }
                for i, s in enumerate(self._led_states)
            ]

    def get_status(self) -> Dict:
        """시스템 상태 반환"""
        return {
            "mode": self._current_mode.value,
            "brightness": self._current_brightness,
            "animation": self._animation_config.pattern.value,
            "animation_running": self._animation_running,
            "num_pixels": self._num_pixels,
            "initialized": self._initialized,
        }


# ============================================================================
# 메인 진입점 (단독 테스트용)
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    controller = NeoPixelController()
    if controller.initialize():
        print("=== NeoPixel LED 효과 테스트 ===")

        # 모드별 색상 테스트
        for mode in LEDMode:
            print(f"모드: {mode.value}")
            controller.set_mode(mode)
            time.sleep(2.0)

        # 애니메이션 패턴 테스트
        print("\n애니메이션 테스트...")
        for pattern in [AnimationPattern.BREATHING, AnimationPattern.CHASING,
                        AnimationPattern.RAINBOW, AnimationPattern.FIRE]:
            print(f"패턴: {pattern.value}")
            controller.animate(pattern, color=COLOR_GREEN)
            time.sleep(3.0)

        # 밝기 테스트
        print("\n밝기 테스트...")
        for brightness in [0.1, 0.3, 0.5, 0.8, 1.0]:
            controller.set_brightness(brightness)
            print(f"밝기: {brightness:.0%}")
            time.sleep(1.0)

        # 저전력 대기 모드 테스트
        print("\n저전력 대기 모드 테스트...")
        controller.set_mode(LEDMode.STANDBY)
        time.sleep(3.0)

        print(f"\n상태: {controller.get_status()}")
        controller.shutdown()
        print("테스트 완료")
    else:
        print("초기화 실패 — GPIO/NeoPixel 확인 필요")
