#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — Fin Ray 그리퍼 제어 (Fin Ray Gripper Control)
=============================================================

TPU 95A Fin Ray 핑거 ×2 + MG996R 서보 ×3 (핑거×2 + 손목×1)
적응형 파지: 60mm 핑거, 8개 갈비뼈, 2mm 두께

V8.5 변경사항 / V8.5 Changes from V8.5:
  - 파지력 피드백 루프 (Grip force feedback loop)
  - TPU 핑거 피로도 감지 (TPU finger fatigue detection)
  - FSR 패턴 기반 슬립 감지 (Slip detection via FSR pattern)
  - 파지 중 물체 무게 추정 (Object weight estimation during grip)

물리 파라미터 / Physical Parameters:
  - 핑거 길이: 60mm
  - 핑거 폭: 15mm
  - 핑거 두께: 2mm
  - Fin Ray 갈비뼈: 8개
  - 파지 성공률 목표: >90%

작성일: 2026-05-19
버전: V8.5.5-AGI
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V84.FinRayGripper")

# ============================================================================
# 상수 정의 (Constants)
# ============================================================================

FINGER_LENGTH_MM: float = 60.0
FINGER_WIDTH_MM: float = 15.0
FINGER_THICKNESS_MM: float = 2.0
FIN_RAY_RIBS: int = 8
FINGER_MATERIAL: str = "TPU 95A"

SERVO_MODEL: str = "MG996R"
SERVO_COUNT: int = 3
SERVO_TORQUE_KGCM: float = 11.0
SERVO_PWM_FREQ_HZ: int = 50
SERVO_PULSE_MIN_US: int = 500
SERVO_PULSE_MAX_US: int = 2500
SERVO_PULSE_NEUTRAL_US: int = 1500

FINGER_OPEN_ANGLE_DEG: float = 0.0
FINGER_CLOSE_ANGLE_DEG: float = 90.0
WRIST_YAW_MIN_DEG: float = -90.0
WRIST_YAW_MAX_DEG: float = 90.0

MAX_GRASP_FORCE_N: float = 10.0
TARGET_GRASP_FORCE_N: float = 5.0

SERVO_PINS: Dict[str, int] = {
    "finger_left": 18,
    "finger_right": 22,
    "wrist_yaw": 23,
}

DEFAULT_MOVE_SPEED_DEG_S: float = 90.0
FAST_MOVE_SPEED_DEG_S: float = 180.0
SLOW_MOVE_SPEED_DEG_S: float = 30.0

# V8.5: 파지력 피드백 루프 상수
FORCE_FEEDBACK_KP: float = 0.8        # 힘 피드백 비례 게인
FORCE_FEEDBACK_KI: float = 0.05       # 힘 피드백 적분 게인
FORCE_FEEDBACK_KD: float = 0.2        # 힘 피드백 미분 게인
FORCE_FEEDBACK_DT: float = 0.01       # 힘 피드백 루프 주기 (초)
FORCE_FEEDBACK_TOLERANCE_N: float = 0.5  # 힘 오차 허용치 (N)

# V8.5: TPU 피로도 상수
TPU_FATIGUE_CYCLES_WARNING = 50000    # 피로 경고 사이클 수
TPU_FATIGUE_CYCLES_CRITICAL = 100000  # 피로 위험 사이클 수
TPU_FATIGUE_DEFORMATION_WARNING = 15.0  # 영구 변형 경고 (%)
TPU_FATIGUE_DEFORMATION_CRITICAL = 30.0 # 영구 변형 위험 (%)

# V8.5: 슬립 감지 상수
SLIP_FSR_WINDOW_SIZE = 20              # FSR 슬립 감지 윈도우
SLIP_FORCE_VARIANCE_THRESHOLD = 2.0    # 힘 분산 임계값 (N²)
SLIP_DIRECTION_CHANGE_RATE = 0.4       # 방향 변화율 임계값
SLIP_CONFIRMATION_COUNT = 3            # 슬립 확정 카운트

# V8.5: 무게 추정 상수
WEIGHT_ESTIMATION_GRAVITY = 9.81       # 중력가속도 (m/s²)
WEIGHT_ESTIMATION_ALPHA = 0.3          # EMA 필터 계수
WEIGHT_ESTIMATION_MIN_FORCE_N = 0.5    # 최소 감지 힘

# V8.5 AGI: 적응형 파지 상수 / V8.5 AGI: Adaptive grip constants
ADAPTIVE_GRIP_FORCE_MIN_N = 0.5       # 최소 파지력 (깨지기 쉬운 물체)
ADAPTIVE_GRIP_FORCE_MAX_N = 8.0        # 최대 파지력 (단단한 물체)
ADAPTIVE_GRIP_FORCE_STEP_N = 0.2       # 힘 조정 스텝 (N)
ADAPTIVE_GRIP_SLIP_RESPONSE_N = 1.0    # 슬립 감지 시 힘 증가량 (N)
ADAPTIVE_GRIP_CONVERGENCE_N = 0.3      # 수렴 판정 오차 (N)

# V8.5 AGI: 물체 속성 추정 상수 / V8.5 AGI: Object property estimation constants
OBJ_WEIGHT_LIGHT_KG = 0.1             # 가벼운 물체 기준 (kg)
OBJ_WEIGHT_MEDIUM_KG = 0.5            # 중간 무게 기준 (kg)
OBJ_WEIGHT_HEAVY_KG = 2.0             # 무거운 물체 기준 (kg)
OBJ_FRAGILITY_FORCE_THRESHOLD_N = 3.0 # 깨지기 쉬운 물체 힘 임계값 (N)
OBJ_SLIP_RESISTANCE_LOW = 0.3         # 미끄러움 기준 (마찰계수 추정)
OBJ_SLIP_RESISTANCE_HIGH = 0.7        # 미끄럼 저항 높음 기준

# V8.5 AGI: 부드러운 릴리즈 상수 / V8.5 AGI: Gentle release constants
GENTLE_RELEASE_SPEED_DEG_S = 15.0     # 부드러운 릴리즈 속도 (°/s)
GENTLE_RELEASE_FORCE_THRESHOLD_N = 1.0 # 릴리즈 완료 힘 임계값 (N)
GENTLE_RELEASE_PAUSE_N = 2.0          # 일시정지 힘 (N)
GENTLE_RELEASE_STEP_DEG = 2.0         # 릴리즈 각도 스텝 (°)


# ============================================================================
# 열거형 (Enumerations)
# ============================================================================

class GripperState(Enum):
    OPEN = "open"
    CLOSING = "closing"
    HOLDING = "holding"
    RELEASING = "releasing"
    FAULT = "fault"


class GraspPhase(Enum):
    APPROACH = "approach"
    CONTACT = "contact"
    SECURE = "secure"
    LIFT = "lift"
    RELEASE = "release"


class SlipState(Enum):
    """V8.5: 슬립 상태"""
    NO_SLIP = "no_slip"
    SLIP_DETECTED = "slip_detected"
    SLIP_CONFIRMED = "slip_confirmed"


class FatigueLevel(Enum):
    """V8.5: TPU 피로도 레벨"""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"


# V8.5 AGI: 물체 속성 열거형 / V8.5 AGI: Object property enumerations
class ObjectFragility(Enum):
    """V8.5 AGI: 물체 깨지기 쉬움 정도 / Object fragility level"""
    ROBUST = "robust"           # 단단한 (금속, 나무)
    NORMAL = "normal"           # 보통 (플라스틱)
    FRAGILE = "fragile"         # 깨지기 쉬운 (유리, 세라믹)
    VERY_FRAGILE = "very_fragile"  # 매우 깨지기 쉬운 (계란, 종이컵)

class ObjectSlipperiness(Enum):
    """V8.5 AGI: 물체 미끄러움 정도 / Object slipperiness"""
    HIGH_GRIP = "high_grip"     # 미끄럽지 않음 (고무, 실리콘)
    NORMAL = "normal"           # 보통 (플라스틱, 나무)
    SLIPPERY = "slippery"       # 미끄러움 (유리, 금속)
    VERY_SLIPPERY = "very_slippery"  # 매우 미끄러움 (젖은 표면, 기름침)


# ============================================================================
# V8.5 데이터 클래스
# ============================================================================

@dataclass
class FinRayFingerState:
    """단일 Fin Ray 핑거 상태"""
    angle_deg: float = 0.0
    target_angle_deg: float = 0.0
    contact_force_n: float = 0.0
    deformation_mm: float = 0.0
    is_contact: bool = False
    # V8.5 추가
    force_history: deque = field(default_factory=lambda: deque(maxlen=SLIP_FSR_WINDOW_SIZE))
    permanent_deformation_pct: float = 0.0  # 영구 변형률 (%)


@dataclass
class GripForceFeedbackState:
    """V8.5: 파지력 피드백 루프 상태"""
    target_force_n: float = TARGET_GRASP_FORCE_N
    current_force_n: float = 0.0
    error: float = 0.0
    integral: float = 0.0
    derivative: float = 0.0
    output_angle_correction: float = 0.0
    is_converged: bool = False
    is_active: bool = False


@dataclass
class TPUFatigueData:
    """V8.5: TPU 핑거 피로도 데이터"""
    finger_name: str = ""
    grasp_cycle_count: int = 0
    fatigue_level: FatigueLevel = FatigueLevel.HEALTHY
    estimated_permanent_deformation_pct: float = 0.0
    max_deformation_seen_mm: float = 0.0
    needs_replacement: bool = False


@dataclass
class SlipDetectionData:
    """V8.5: 슬립 감지 데이터"""
    state: SlipState = SlipState.NO_SLIP
    force_variance: float = 0.0
    direction_change_rate: float = 0.0
    confirmation_count: int = 0
    last_slip_time: float = 0.0
    slip_count_total: int = 0


@dataclass
class WeightEstimationData:
    """V8.5: 물체 무게 추정 데이터"""
    estimated_weight_kg: float = 0.0
    confidence: float = 0.0   # 0~1
    raw_force_n: float = 0.0
    is_estimating: bool = False
    last_update: float = 0.0


@dataclass
class ObjectProperties:
    """V8.5 AGI: 물체 속성 추정 데이터 / Estimated object properties."""
    weight_kg: float = 0.0
    fragility: ObjectFragility = ObjectFragility.NORMAL
    slipperiness: ObjectSlipperiness = ObjectSlipperiness.NORMAL
    estimated_friction_coeff: float = 0.5
    recommended_grip_force_n: float = TARGET_GRASP_FORCE_N
    confidence: float = 0.0   # 추정 신뢰도 0~1
    last_update: float = 0.0

    @property
    def is_fragile(self) -> bool:
        """깨지기 쉬운 물체인지 여부 / Whether object is fragile."""
        return self.fragility in (ObjectFragility.FRAGILE, ObjectFragility.VERY_FRAGILE)

    @property
    def is_slippery(self) -> bool:
        """미끄러운 물체인지 여부 / Whether object is slippery."""
        return self.slipperiness in (ObjectSlipperiness.SLIPPERY, ObjectSlipperiness.VERY_SLIPPERY)


@dataclass
class AdaptiveGripState:
    """V8.5 AGI: 적응형 파지 상태 / Adaptive grip control state."""
    is_active: bool = False
    target_force_n: float = TARGET_GRASP_FORCE_N
    current_force_n: float = 0.0
    min_force_n: float = ADAPTIVE_GRIP_FORCE_MIN_N
    max_force_n: float = ADAPTIVE_GRIP_FORCE_MAX_N
    last_adjustment_time: float = 0.0
    adjustment_count: int = 0
    is_converged: bool = False


@dataclass
class GentleReleaseState:
    """V8.5 AGI: 부드러운 릴리즈 상태 / Gentle release state."""
    is_active: bool = False
    current_phase: str = "idle"   # idle, pausing, releasing, done
    current_force_n: float = 0.0
    release_angle_deg: float = FINGER_OPEN_ANGLE_DEG
    step_count: int = 0


@dataclass
class GripperStateData:
    """그리퍼 전체 상태 데이터"""
    state: GripperState = GripperState.OPEN
    finger_left: FinRayFingerState = field(default_factory=FinRayFingerState)
    finger_right: FinRayFingerState = field(default_factory=FinRayFingerState)
    wrist_yaw_deg: float = 0.0
    grasp_force_n: float = 0.0
    grasp_phase: GraspPhase = GraspPhase.APPROACH
    held_object: Optional[str] = None
    timestamp: float = field(default_factory=time.monotonic)
    # V8.5 추가
    force_feedback: GripForceFeedbackState = field(default_factory=GripForceFeedbackState)
    slip_data: SlipDetectionData = field(default_factory=SlipDetectionData)
    weight_data: WeightEstimationData = field(default_factory=WeightEstimationData)
    # V8.5 AGI 추가
    object_properties: ObjectProperties = field(default_factory=ObjectProperties)
    adaptive_grip: AdaptiveGripState = field(default_factory=AdaptiveGripState)
    gentle_release: GentleReleaseState = field(default_factory=GentleReleaseState)

    @property
    def total_force(self) -> float:
        return self.finger_left.contact_force_n + self.finger_right.contact_force_n

    @property
    def is_grasping(self) -> bool:
        return self.state == GripperState.HOLDING


# ============================================================================
# FinRayGripper V8.5
# ============================================================================

class FinRayGripper:
    """
    Fin Ray 적응형 그리퍼 V8.5

    V8.5 신규 기능:
    - 파지력 피드백 루프: PID 제어로 정밀한 파지력 유지
    - TPU 핑거 피로도 감지: 파지 사이클 기반 피로 추적
    - FSR 패턴 슬립 감지: 힘 분산 및 방향 변화로 슬립 감지
    - 물체 무게 추정: 파지력 기반 무게 추정
    """

    def __init__(
        self,
        simulation_mode: bool = True,
        tactile_feedback: Optional[Any] = None,
    ):
        self._simulation = simulation_mode
        self._tactile = tactile_feedback
        self._servo_ctrl: Optional[Any] = None
        self._lock = threading.Lock()

        self._state_data = GripperStateData()
        self._finger_left_angle: float = FINGER_OPEN_ANGLE_DEG
        self._finger_right_angle: float = FINGER_OPEN_ANGLE_DEG
        self._wrist_yaw: float = 0.0

        self._move_speed: float = DEFAULT_MOVE_SPEED_DEG_S
        self._target_left: float = FINGER_OPEN_ANGLE_DEG
        self._target_right: float = FINGER_OPEN_ANGLE_DEG
        self._target_wrist: float = 0.0
        self._moving: bool = False
        self._move_thread: Optional[threading.Thread] = None

        self._grasp_count: int = 0
        self._grasp_success: int = 0
        self._grasp_failure: int = 0

        # V8.5: TPU 피로도 데이터
        self._fatigue_data: Dict[str, TPUFatigueData] = {
            "finger_left": TPUFatigueData(finger_name="finger_left"),
            "finger_right": TPUFatigueData(finger_name="finger_right"),
        }

        # V8.5: 힘 피드백 스레드
        self._force_feedback_running: bool = False
        self._force_feedback_thread: Optional[threading.Thread] = None

        # V8.5: 무게 추정 상태
        self._prev_force_n: float = 0.0

        self._servo_initialized: bool = False

        logger.info("FinRayGripper V8.5 초기화 완료 "
                     f"(simulation={simulation_mode})")

    def _ensure_servo(self) -> None:
        if self._servo_initialized:
            return
        try:
            from .servo_controller import ServoController
            self._servo_ctrl = ServoController(simulation_mode=self._simulation)
            for name, pin in SERVO_PINS.items():
                self._servo_ctrl.register_channel(name, pin)
            self._servo_initialized = True
        except (ImportError, Exception) as e:
            logger.warning(f"서보 컨트롤러 초기화 실패, 시뮬레이션: {e}")
            self._simulation = True

    # ── 기본 동작 / Basic Actions ──

    def open(self, speed: Optional[float] = None) -> bool:
        with self._lock:
            if self._state_data.state == GripperState.FAULT:
                return False

            # V8.5: 힘 피드백 비활성화
            self._stop_force_feedback()

            self._state_data.state = GripperState.RELEASING
            self._target_left = FINGER_OPEN_ANGLE_DEG
            self._target_right = FINGER_OPEN_ANGLE_DEG
            self._move_speed = speed or DEFAULT_MOVE_SPEED_DEG_S

            self._ensure_servo()
            if self._servo_ctrl:
                self._servo_ctrl.set_angle("finger_left", FINGER_OPEN_ANGLE_DEG)
                self._servo_ctrl.set_angle("finger_right", FINGER_OPEN_ANGLE_DEG)

            self._execute_motion()

            self._finger_left_angle = FINGER_OPEN_ANGLE_DEG
            self._finger_right_angle = FINGER_OPEN_ANGLE_DEG
            self._state_data.state = GripperState.OPEN
            self._state_data.grasp_phase = GraspPhase.RELEASE
            self._state_data.held_object = None

            # V8.5: 무게 추정 초기화
            self._state_data.weight_data.is_estimating = False

            logger.info("그리퍼 열림 / Gripper opened")
            return True

    def close(self, target_force: float = TARGET_GRASP_FORCE_N,
              speed: Optional[float] = None) -> bool:
        with self._lock:
            if self._state_data.state == GripperState.FAULT:
                return False

            self._state_data.state = GripperState.CLOSING
            self._state_data.grasp_phase = GraspPhase.APPROACH
            self._target_left = FINGER_CLOSE_ANGLE_DEG
            self._target_right = FINGER_CLOSE_ANGLE_DEG
            self._move_speed = speed or SLOW_MOVE_SPEED_DEG_S

            # V8.5: 힘 피드백 목표 설정
            self._state_data.force_feedback.target_force_n = target_force
            self._state_data.force_feedback.is_active = True

            self._ensure_servo()
            if self._servo_ctrl:
                self._servo_ctrl.set_angle("finger_left", FINGER_CLOSE_ANGLE_DEG)
                self._servo_ctrl.set_angle("finger_right", FINGER_CLOSE_ANGLE_DEG)

            if self._tactile and not self._simulation:
                self._wait_for_grasp(target_force)
            else:
                self._finger_left_angle = FINGER_CLOSE_ANGLE_DEG * 0.7
                self._finger_right_angle = FINGER_CLOSE_ANGLE_DEG * 0.7
                self._state_data.grasp_force_n = target_force

            self._state_data.state = GripperState.HOLDING
            self._state_data.grasp_phase = GraspPhase.SECURE
            self._grasp_count += 1

            # V8.5: 피로도 카운트 증가
            self._increment_fatigue_cycles()

            # V8.5: 무게 추정 시작
            self._start_weight_estimation()

            # V8.5: 힘 피드백 루프 시작
            self._start_force_feedback()

            logger.info(f"그리퍼 닫힘 (force={self._state_data.grasp_force_n:.1f}N)")
            return True

    def _wait_for_grasp(self, target_force: float) -> None:
        start_time = time.monotonic()
        timeout = 5.0

        while time.monotonic() - start_time < timeout:
            if self._tactile:
                force = self._tactile.read_force("combined")
                self._state_data.grasp_force_n = force

                if force > MAX_GRASP_FORCE_N:
                    logger.warning(f"파지력 과부하 {force:.1f}N — 자동 릴리즈")
                    self.open()
                    self._state_data.state = GripperState.FAULT
                    self._grasp_failure += 1
                    return

                if force >= target_force * 0.9:
                    self._grasp_success += 1
                    return

            time.sleep(0.01)

        logger.warning("파지 타임아웃 — 부분 파지 상태")
        self._grasp_failure += 1

    def _execute_motion(self) -> None:
        if self._servo_ctrl:
            self._servo_ctrl.set_speed(self._move_speed)

    # ── 각도 제어 / Angle Control ──

    def set_finger_angle(self, angle_deg: float,
                         speed: Optional[float] = None) -> bool:
        angle_deg = max(FINGER_OPEN_ANGLE_DEG,
                        min(FINGER_CLOSE_ANGLE_DEG, angle_deg))

        with self._lock:
            self._target_left = angle_deg
            self._target_right = angle_deg
            self._finger_left_angle = angle_deg
            self._finger_right_angle = angle_deg
            self._move_speed = speed or DEFAULT_MOVE_SPEED_DEG_S

            self._ensure_servo()
            if self._servo_ctrl:
                self._servo_ctrl.set_angle("finger_left", angle_deg)
                self._servo_ctrl.set_angle("finger_right", angle_deg)

            if angle_deg <= FINGER_OPEN_ANGLE_DEG + 1.0:
                self._state_data.state = GripperState.OPEN
            elif angle_deg >= FINGER_CLOSE_ANGLE_DEG - 1.0:
                self._state_data.state = GripperState.HOLDING
            else:
                self._state_data.state = GripperState.CLOSING

            return True

    def set_wrist_yaw(self, yaw_deg: float,
                      speed: Optional[float] = None) -> bool:
        yaw_deg = max(WRIST_YAW_MIN_DEG, min(WRIST_YAW_MAX_DEG, yaw_deg))

        with self._lock:
            self._target_wrist = yaw_deg
            self._wrist_yaw = yaw_deg
            self._state_data.wrist_yaw_deg = yaw_deg

            self._ensure_servo()
            if self._servo_ctrl:
                self._servo_ctrl.set_angle("wrist_yaw", yaw_deg)

            return True

    # ── 상태 조회 / State Query ──

    def get_state(self) -> GripperStateData:
        with self._lock:
            if self._tactile:
                self._state_data.finger_left.contact_force_n = \
                    self._tactile.read_force("finger_left")
                self._state_data.finger_right.contact_force_n = \
                    self._tactile.read_force("finger_right")
                self._state_data.grasp_force_n = \
                    self._tactile.read_force("combined")

            self._state_data.finger_left.angle_deg = self._finger_left_angle
            self._state_data.finger_right.angle_deg = self._finger_right_angle
            self._state_data.finger_left.is_contact = \
                self._state_data.finger_left.contact_force_n > 1.0
            self._state_data.finger_right.is_contact = \
                self._state_data.finger_right.contact_force_n > 1.0

            self._state_data.finger_left.deformation_mm = \
                self._finger_left_angle / FINGER_CLOSE_ANGLE_DEG * FINGER_LENGTH_MM * 0.3
            self._state_data.finger_right.deformation_mm = \
                self._finger_right_angle / FINGER_CLOSE_ANGLE_DEG * FINGER_LENGTH_MM * 0.3

            # V8.5: 슬립 감지 업데이트
            if self._state_data.is_grasping:
                self._update_slip_detection()

            self._state_data.timestamp = time.monotonic()
            return self._state_data

    # ── 파지 품질 / Grasp Quality ──

    def get_grasp_quality(self) -> Dict[str, Any]:
        state = self.get_state()
        left_f = state.finger_left.contact_force_n
        right_f = state.finger_right.contact_force_n
        total_f = state.total_force

        if total_f > 0.1:
            balance = 1.0 - abs(left_f - right_f) / total_f
        else:
            balance = 0.0

        stability = min(total_f / TARGET_GRASP_FORCE_N, 1.0) * balance

        success_rate = (self._grasp_success / self._grasp_count * 100
                        if self._grasp_count > 0 else 0.0)

        # V8.5: 슬립 상태 포함
        is_slipping = state.slip_data.state == SlipState.SLIP_CONFIRMED

        return {
            "stability": round(stability, 3),
            "force_balance": round(balance, 3),
            "total_force_n": round(total_f, 2),
            "left_force_n": round(left_f, 2),
            "right_force_n": round(right_f, 2),
            "success_rate_pct": round(success_rate, 1),
            "grasp_count": self._grasp_count,
            "is_secure": stability > 0.6 and total_f > 2.0 and not is_slipping,
            "is_slipping": is_slipping,
            "estimated_weight_kg": round(state.weight_data.estimated_weight_kg, 3),
        }

    # ── V8.5: 파지력 피드백 루프 ──

    def _start_force_feedback(self) -> None:
        """V8.5: 파지력 피드백 루프 시작."""
        if self._force_feedback_running:
            return

        self._force_feedback_running = True
        self._state_data.force_feedback.is_active = True
        self._state_data.force_feedback.integral = 0.0
        self._force_feedback_thread = threading.Thread(
            target=self._force_feedback_loop, daemon=True,
            name="ForceFeedback_Loop",
        )
        self._force_feedback_thread.start()

    def _stop_force_feedback(self) -> None:
        """V8.5: 파지력 피드백 루프 중지."""
        self._force_feedback_running = False
        self._state_data.force_feedback.is_active = False
        if self._force_feedback_thread and self._force_feedback_thread.is_alive():
            self._force_feedback_thread.join(timeout=1.0)

    def _force_feedback_loop(self) -> None:
        """V8.5: 파지력 PID 피드백 루프."""
        fb = self._state_data.force_feedback
        prev_error = 0.0

        while self._force_feedback_running and self._state_data.is_grasping:
            try:
                current_force = self._state_data.grasp_force_n
                if self._tactile:
                    current_force = self._tactile.read_force("combined")

                fb.current_force_n = current_force
                error = fb.target_force_n - current_force
                fb.error = error

                # PID 계산
                fb.integral += error * FORCE_FEEDBACK_DT
                fb.integral = max(-5.0, min(5.0, fb.integral))  # 안티와인드업
                fb.derivative = (error - prev_error) / FORCE_FEEDBACK_DT
                prev_error = error

                output = (FORCE_FEEDBACK_KP * error +
                          FORCE_FEEDBACK_KI * fb.integral +
                          FORCE_FEEDBACK_KD * fb.derivative)
                fb.output_angle_correction = output

                # 수렴 판정
                fb.is_converged = abs(error) < FORCE_FEEDBACK_TOLERANCE_N

                # 서보 각도 미세 조정 (파지력 유지)
                if abs(output) > 0.1 and not fb.is_converged:
                    adjustment = output * 0.5  # 각도 보정량
                    new_left = max(FINGER_OPEN_ANGLE_DEG,
                                   min(FINGER_CLOSE_ANGLE_DEG,
                                       self._finger_left_angle + adjustment))
                    new_right = max(FINGER_OPEN_ANGLE_DEG,
                                    min(FINGER_CLOSE_ANGLE_DEG,
                                        self._finger_right_angle + adjustment))
                    self._finger_left_angle = new_left
                    self._finger_right_angle = new_right

                    if self._servo_ctrl:
                        self._servo_ctrl.set_angle("finger_left", new_left)
                        self._servo_ctrl.set_angle("finger_right", new_right)

            except Exception as e:
                logger.error(f"힘 피드백 루프 오류: {e}")

            time.sleep(FORCE_FEEDBACK_DT)

    # ── V8.5: TPU 핑거 피로도 감지 ──

    def _increment_fatigue_cycles(self) -> None:
        """V8.5: 파지 사이클당 피로도 증가."""
        for name, data in self._fatigue_data.items():
            data.grasp_cycle_count += 1

            # 영구 변형 추정 (사이클당 미세 증가)
            deformation_increment = 0.001  # 사이클당 0.001% 추정
            data.estimated_permanent_deformation_pct += deformation_increment

            # 피로도 레벨 판정
            if (data.grasp_cycle_count >= TPU_FATIGUE_CYCLES_CRITICAL or
                    data.estimated_permanent_deformation_pct >= TPU_FATIGUE_DEFORMATION_CRITICAL):
                data.fatigue_level = FatigueLevel.CRITICAL
                data.needs_replacement = True
                logger.warning(
                    "TPU 핑거 피로 위험 — %s: %d사이클, 변형률 %.2f%%",
                    name, data.grasp_cycle_count,
                    data.estimated_permanent_deformation_pct,
                )
            elif (data.grasp_cycle_count >= TPU_FATIGUE_CYCLES_WARNING or
                  data.estimated_permanent_deformation_pct >= TPU_FATIGUE_DEFORMATION_WARNING):
                data.fatigue_level = FatigueLevel.WARNING
                logger.info(
                    "TPU 핑거 피로 경고 — %s: %d사이클, 변형률 %.2f%%",
                    name, data.grasp_cycle_count,
                    data.estimated_permanent_deformation_pct,
                )

    def get_fatigue_data(self) -> Dict[str, TPUFatigueData]:
        """V8.5: TPU 피로도 데이터 조회."""
        return dict(self._fatigue_data)

    # ── V8.5: FSR 패턴 슬립 감지 ──

    def _update_slip_detection(self) -> SlipDetectionData:
        """
        V8.5: FSR 패턴 기반 슬립 감지 / Slip detection via FSR pattern.

        핑거 힘 시계열의 분산과 방향 변화율로 슬립 감지.
        슬립 시: 힘이 빠르게 변동하며 방향이 자주 바뀜.
        """
        slip = self._state_data.slip_data

        # 힘 이력 업데이트
        left_f = self._state_data.finger_left.contact_force_n
        right_f = self._state_data.finger_right.contact_force_n

        self._state_data.finger_left.force_history.append(left_f)
        self._state_data.finger_right.force_history.append(right_f)

        # 힘 분산 계산
        left_history = list(self._state_data.finger_left.force_history)
        right_history = list(self._state_data.finger_right.force_history)

        if len(left_history) >= 5:
            left_mean = sum(left_history) / len(left_history)
            left_var = sum((f - left_mean) ** 2 for f in left_history) / len(left_history)

            right_mean = sum(right_history) / len(right_history)
            right_var = sum((f - right_mean) ** 2 for f in right_history) / len(right_history)

            avg_var = (left_var + right_var) / 2.0
            slip.force_variance = avg_var

            # 방향 변화율 계산
            combined = [(left_history[i] + right_history[i]) / 2.0 for i in range(len(left_history))]
            dir_changes = 0
            for i in range(2, len(combined)):
                d_prev = combined[i - 1] - combined[i - 2]
                d_curr = combined[i] - combined[i - 1]
                if d_prev * d_curr < 0:
                    dir_changes += 1

            slip.direction_change_rate = dir_changes / max(len(combined) - 2, 1)

            # 슬립 판정
            is_slip_indicated = (
                avg_var > SLIP_FORCE_VARIANCE_THRESHOLD or
                slip.direction_change_rate > SLIP_DIRECTION_CHANGE_RATE
            )

            if is_slip_indicated:
                slip.confirmation_count += 1
                if slip.confirmation_count >= SLIP_CONFIRMATION_COUNT:
                    slip.state = SlipState.SLIP_CONFIRMED
                    slip.last_slip_time = time.monotonic()
                    slip.slip_count_total += 1
                    logger.warning(
                        "물체 슬립 감지! 분산=%.2fN², 방향변화율=%.2f",
                        avg_var, slip.direction_change_rate,
                    )
                else:
                    slip.state = SlipState.SLIP_DETECTED
            else:
                slip.confirmation_count = max(0, slip.confirmation_count - 1)
                if slip.confirmation_count == 0:
                    slip.state = SlipState.NO_SLIP

        return slip

    def get_slip_data(self) -> SlipDetectionData:
        """V8.5: 슬립 감지 데이터 조회."""
        return self._state_data.slip_data

    # ── V8.5: 물체 무게 추정 ──

    def _start_weight_estimation(self) -> None:
        """V8.5: 무게 추정 시작."""
        self._state_data.weight_data.is_estimating = True
        self._state_data.weight_data.last_update = time.monotonic()

    def estimate_object_weight(self) -> WeightEstimationData:
        """
        V8.5: 파지 중 물체 무게 추정 / Estimate object weight during grip.

        파지력이 물체 무게에 비례한다고 가정.
        정지 파지 시 수직 방향 힘 ≈ 물체 무게 × 중력.
        """
        weight_data = self._state_data.weight_data

        if not self._state_data.is_grasping:
            weight_data.is_estimating = False
            return weight_data

        total_force = self._state_data.grasp_force_n

        # 마찰계수 추정 (TPU 95A vs 일반 물체: ≈0.5~0.8)
        friction_coefficient = 0.6

        # 물체 무게 = 파지력 × 마찰계수 / 중력가속도
        if total_force > WEIGHT_ESTIMATION_MIN_FORCE_N:
            raw_weight = (total_force * friction_coefficient) / WEIGHT_ESTIMATION_GRAVITY

            # EMA 필터로 부드럽게
            alpha = WEIGHT_ESTIMATION_ALPHA
            weight_data.estimated_weight_kg = (
                alpha * raw_weight +
                (1 - alpha) * weight_data.estimated_weight_kg
            )

            # 신뢰도: 힘이 클수록 신뢰도 높음
            weight_data.confidence = min(1.0, total_force / TARGET_GRASP_FORCE_N)
        else:
            weight_data.confidence = 0.0

        weight_data.raw_force_n = total_force
        weight_data.last_update = time.monotonic()

        return weight_data

    def get_weight_estimation(self) -> WeightEstimationData:
        """V8.5: 무게 추정 결과 조회."""
        return self.estimate_object_weight()

    # ── V8.5 AGI: 적응형 파지 제어 (Adaptive Grip Controller) ──

    def start_adaptive_grip(self, initial_force_n: float = TARGET_GRASP_FORCE_N) -> bool:
        """
        V8.5 AGI: 적응형 파지 시작 / Start adaptive grip control.

        물체 속성(무게, 깨지기 쉬움, 미끄러움)에 따라
        파지력을 자동으로 조정.

        적응 로직:
        1. 초기 파지력으로 파지 시도
        2. 슬립 감지 시 힘 증가
        3. 과도한 힘 감지 시 힘 감소
        4. 물체 속성 추정 결과 반영

        Args:
            initial_force_n: 초기 목표 파지력 (N)

        Returns:
            성공 여부
        """
        with self._lock:
            if self._state_data.state == GripperState.FAULT:
                return False

            self._state_data.adaptive_grip.is_active = True
            self._state_data.adaptive_grip.target_force_n = initial_force_n
            self._state_data.adaptive_grip.is_converged = False
            self._state_data.adaptive_grip.adjustment_count = 0

            logger.info(
                "적응형 파지 시작 — 초기힘=%.1fN", initial_force_n,
            )
        return True

    def update_adaptive_grip(self) -> AdaptiveGripState:
        """
        V8.5 AGI: 적응형 파지 업데이트 / Update adaptive grip.

        현재 힘, 슬립 상태, 물체 속성을 기반으로
        목표 파지력을 자동 조정.

        Returns:
            적응형 파지 상태
        """
        grip = self._state_data.adaptive_grip
        if not grip.is_active or not self._state_data.is_grasping:
            return grip

        now = time.monotonic()
        current_force = self._state_data.grasp_force_n
        grip.current_force_n = current_force

        # 물체 속성 기반 파지력 범위 조정 / Adjust force range based on object properties
        props = self._state_data.object_properties
        if props.is_fragile:
            grip.max_force_n = min(grip.max_force_n, OBJ_FRAGILITY_FORCE_THRESHOLD_N)
        if props.is_slippery:
            grip.min_force_n = max(grip.min_force_n, TARGET_GRASP_FORCE_N * 0.8)

        # 슬립 감지 시 힘 증가 / Increase force on slip detection
        slip = self._state_data.slip_data
        if slip.state == SlipState.SLIP_CONFIRMED:
            grip.target_force_n = min(
                grip.max_force_n,
                grip.target_force_n + ADAPTIVE_GRIP_SLIP_RESPONSE_N,
            )
            logger.info(
                "적응형 파지: 슬립 감지 → 힘 증가 %.1f→%.1fN",
                grip.target_force_n - ADAPTIVE_GRIP_SLIP_RESPONSE_N,
                grip.target_force_n,
            )

        # 과도한 힘 감지 시 감소 / Decrease force if excessive
        if current_force > grip.target_force_n * 1.5:
            grip.target_force_n = max(
                grip.min_force_n,
                grip.target_force_n - ADAPTIVE_GRIP_FORCE_STEP_N,
            )

        # 수렴 판정 / Check convergence
        error = abs(grip.target_force_n - current_force)
        grip.is_converged = error < ADAPTIVE_GRIP_CONVERGENCE_N

        grip.last_adjustment_time = now
        grip.adjustment_count += 1

        # 힘 피드백 목표 업데이트 / Update force feedback target
        self._state_data.force_feedback.target_force_n = grip.target_force_n

        return grip

    # ── V8.5 AGI: 물체 속성 추정기 (Object Property Estimator) ──

    def estimate_object_properties(self) -> ObjectProperties:
        """
        V8.5 AGI: 물체 속성 추정 / Estimate object properties from tactile feedback.

        촉각 피드백(힘, 슬립, 질감)을 기반으로 물체의
        무게, 깨지기 쉬움, 미끄러움을 추정.

        추정 방법:
        1. 무게: 파지력과 마찰계수로부터 추정
        2. 깨지기 쉬움: 힘-변형 곡선 기반 (작은 힘에 큰 변형 → 깨지기 쉬움)
        3. 미끄러움: 슬립 발생 빈도 기반

        Returns:
            추정된 물체 속성
        """
        props = self._state_data.object_properties
        if not self._state_data.is_grasping:
            props.confidence = 0.0
            return props

        # 1. 무게 추정 / Estimate weight
        weight_data = self._state_data.weight_data
        props.weight_kg = weight_data.estimated_weight_kg

        # 2. 깨지기 쉬움 추정 / Estimate fragility
        # 힘이 낮은데 슬립이 발생하지 않으면 단단함
        # 힘이 낮은데 슬립이 발생하면 미끄러움
        # 변형에 비해 힘이 낮으면 깨지기 쉬움 (부드러운 재질)
        left_deform = self._state_data.finger_left.deformation_mm
        right_deform = self._state_data.finger_right.deformation_mm
        avg_deform = (left_deform + right_deform) / 2.0
        current_force = self._state_data.grasp_force_n

        # 힘 대비 변형률로 깨지기 쉬움 판정 / Judge fragility by deformation/force ratio
        if current_force > 0.5:
            deform_ratio = avg_deform / current_force
            if deform_ratio > 5.0:  # 쉽게 변형됨
                props.fragility = ObjectFragility.VERY_FRAGILE
            elif deform_ratio > 2.0:
                props.fragility = ObjectFragility.FRAGILE
            elif deform_ratio > 0.8:
                props.fragility = ObjectFragility.NORMAL
            else:
                props.fragility = ObjectFragility.ROBUST

        # 3. 미끄러움 추정 / Estimate slipperiness
        slip = self._state_data.slip_data
        slip_rate = slip.slip_count_total / max(1, self._grasp_count)
        if slip_rate > 0.5:
            props.slipperiness = ObjectSlipperiness.VERY_SLIPPERY
            props.estimated_friction_coeff = 0.2
        elif slip_rate > 0.2:
            props.slipperiness = ObjectSlipperiness.SLIPPERY
            props.estimated_friction_coeff = 0.4
        elif slip_rate > 0.05:
            props.slipperiness = ObjectSlipperiness.NORMAL
            props.estimated_friction_coeff = 0.6
        else:
            props.slipperiness = ObjectSlipperiness.HIGH_GRIP
            props.estimated_friction_coeff = 0.8

        # 4. 추천 파지력 계산 / Calculate recommended grip force
        # F_grip = m*g / (μ * n) + safety_margin
        weight = max(props.weight_kg, 0.05)  # 최소 50g
        mu = props.estimated_friction_coeff
        n_fingers = 2
        safety_margin = 1.5 if props.is_fragile else 2.0

        required_force = (weight * WEIGHT_ESTIMATION_GRAVITY) / (mu * n_fingers) * safety_margin
        props.recommended_grip_force_n = max(
            ADAPTIVE_GRIP_FORCE_MIN_N,
            min(ADAPTIVE_GRIP_FORCE_MAX_N, required_force),
        )

        # 깨지기 쉬운 물체는 힘 제한 / Limit force for fragile objects
        if props.is_fragile:
            props.recommended_grip_force_n = min(
                props.recommended_grip_force_n,
                OBJ_FRAGILITY_FORCE_THRESHOLD_N,
            )

        # 5. 신뢰도 계산 / Calculate confidence
        samples = len(self._state_data.finger_left.force_history)
        props.confidence = min(1.0, samples / 30.0)
        props.last_update = time.monotonic()

        return props

    def get_object_properties(self) -> ObjectProperties:
        """V8.5 AGI: 물체 속성 조회 / Get estimated object properties."""
        return self.estimate_object_properties()

    # ── V8.5 AGI: 부드러운 릴리즈 (Gentle Release) ──

    def gentle_release(self) -> bool:
        """
        V8.5 AGI: 부드러운 릴리즈 실행 / Perform gentle release for delicate objects.

        깨지기 쉬운 물체를 놓을 때 천천히 힘을 감소시켜
        물체가 손상되지 않게 놓음.

        릴리즈 단계:
        1. pausing: 현재 힘에서 일시정지
        2. releasing: 힘을 단계적으로 감소
        3. done: 힘이 임계값 이하가 되면 완전 개방

        Returns:
            성공 여부
        """
        with self._lock:
            if self._state_data.state != GripperState.HOLDING:
                return False

            release = self._state_data.gentle_release
            release.is_active = True
            release.current_phase = "pausing"
            release.current_force_n = self._state_data.grasp_force_n
            release.release_angle_deg = self._finger_left_angle
            release.step_count = 0

            # 적응형 파지 중지
            self._state_data.adaptive_grip.is_active = False

            logger.info("부드러운 릴리즈 시작 — 현재힘=%.1fN", release.current_force_n)

        # 별도 스레드에서 부드러운 릴리즈 실행
        release_thread = threading.Thread(
            target=self._gentle_release_loop, daemon=True,
            name="GentleRelease",
        )
        release_thread.start()
        return True

    def _gentle_release_loop(self) -> None:
        """V8.5 AGI: 부드러운 릴리즈 루프 / Gentle release loop."""
        release = self._state_data.gentle_release
        self._state_data.state = GripperState.RELEASING

        while release.is_active and release.current_phase != "done":
            current_force = self._state_data.grasp_force_n
            release.current_force_n = current_force

            if release.current_phase == "pausing":
                # 잠시 대기 후 릴리즈 시작
                time.sleep(0.3)
                release.current_phase = "releasing"

            elif release.current_phase == "releasing":
                # 각도를 조금씩 열기 / Open angle slightly
                release.release_angle_deg -= GENTLE_RELEASE_STEP_DEG
                release.step_count += 1

                # 서보 각도 설정
                new_angle = max(FINGER_OPEN_ANGLE_DEG, release.release_angle_deg)
                self._finger_left_angle = new_angle
                self._finger_right_angle = new_angle

                if self._servo_ctrl:
                    self._servo_ctrl.set_angle("finger_left", new_angle)
                    self._servo_ctrl.set_angle("finger_right", new_angle)

                # 힘이 임계값 이하면 완료 / Complete when force below threshold
                if current_force < GENTLE_RELEASE_FORCE_THRESHOLD_N:
                    release.current_phase = "done"
                    logger.info("부드러운 릴리즈 완료 — %d스텝, 최종힘=%.1fN",
                                release.step_count, current_force)
                elif current_force > GENTLE_RELEASE_PAUSE_N:
                    # 힘이 여전히 크면 잠시 대기 / Pause if force still high
                    time.sleep(0.1)

            time.sleep(0.05)  # 20Hz

        # 완전 개방 / Full open
        release.is_active = False
        self.open(speed=GENTLE_RELEASE_SPEED_DEG_S)

    # ── 안전 / Safety ──

    def emergency_release(self) -> bool:
        logger.warning("비상 릴리즈 실행 / Emergency release activated")

        # V8.5: 힘 피드백 중지
        self._stop_force_feedback()

        if self._servo_ctrl:
            for name in SERVO_PINS:
                self._servo_ctrl.disable(name)

        self._finger_left_angle = FINGER_OPEN_ANGLE_DEG
        self._finger_right_angle = FINGER_OPEN_ANGLE_DEG
        self._state_data.state = GripperState.OPEN
        self._state_data.grasp_force_n = 0.0
        self._state_data.held_object = None
        self._grasp_failure += 1

        return True

    def reset_fault(self) -> bool:
        if self._state_data.state != GripperState.FAULT:
            return True

        self._state_data.state = GripperState.OPEN
        self._finger_left_angle = FINGER_OPEN_ANGLE_DEG
        self._finger_right_angle = FINGER_OPEN_ANGLE_DEG
        self._wrist_yaw = 0.0

        self._ensure_servo()
        if self._servo_ctrl:
            for name in SERVO_PINS:
                self._servo_ctrl.set_angle(name, 0.0)

        logger.info("그리퍼 오류 리셋")
        return True

    # ── 정리 / Cleanup ──

    def close_connection(self) -> None:
        self._stop_force_feedback()
        self.emergency_release()
        if self._servo_ctrl:
            self._servo_ctrl.close()
        logger.info("FinRayGripper V8.5 종료")

    # ── 속성 / Properties ──

    @property
    def is_grasping(self) -> bool:
        return self._state_data.state == GripperState.HOLDING

    @property
    def success_rate(self) -> float:
        if self._grasp_count == 0:
            return 0.0
        return self._grasp_success / self._grasp_count * 100.0

    @property
    def finger_angles(self) -> Tuple[float, float]:
        return (self._finger_left_angle, self._finger_right_angle)

    @property
    def wrist_yaw(self) -> float:
        return self._wrist_yaw
