#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 물리적 경험 파이프라인 (Physical Experience Pipeline)
=====================================================================

WORLD DATA = Physical Experience, NOT web crawling.
로봇은 직접 사족보행하고, 울퉁불퉁한 길을 지나고,
무거운 물체를 들고, 정밀한 공예를 하면서 끊임없이 학습합니다.

핵심 원칙 / Core Principle:
  로봇이 물리적으로 행동하면서 얻는 모든 감각 데이터가
  곧 세계 데이터입니다. 웹 크롤링이 아닌 직접 경험이 학습의 원천.

아키텍처 / Architecture:
  Sensor Suite → TimeSyncManager → MultiModalFusion → ExperienceQualityChecker
      → PhysicalExperience (dataclass) → ExperienceBuffer (priority) → SQLite

센서 통합 / Sensor Integration:
  - BNO085 IMU: 가속도/자이로/자기장/쿼터니언 (100Hz)
  - FSR-402 ×3: 압력 센서 (좌/우 핑거끝 + 손바닥, 100Hz)
  - HX711 ×4: 로드셀 (전방좌/우 + 후방좌/우, 10Hz)
  - Camera (USB/CSI): 시각 (15~30fps)
  - Microphone array: 청각 (16kHz)
  - Joint encoders: 12 DOF 다리 관절 위치/속도 (100Hz)
  - CAN bus: SimpleFOC 모터 상태 피드백 (100Hz)

하드웨어 / Hardware:
  - Dual Jetson Orin NX 16GB
  - CAN bus (MCP2515, 1Mbps)
  - SimpleFOC motor controllers
  - 12 DOF legs + mecanum wheels

구성요소 / Components:
  1. PhysicalExperience       — 물리적 경험 데이터클래스
  2. ExperienceQualityChecker — 경험 품질 필터 (노이즈/무효 데이터 거부)
  3. MultiModalFusion         — 다중 모달 센서 융합
  4. ExperienceBuffer         — 우선순위 기반 경험 버퍼
  5. TimeSyncManager          — 센서 시간 동기화 관리자
  6. PhysicalExperiencePipeline — 메인 파이프라인 클래스

스레드 안전 / Thread Safety:
  - 모든 공유 상태는 threading.Lock으로 보호
  - 메인 루프에서 0.5Hz (2초마다) 호출
  - 절대 메인 루프를 크래시시키지 않음

작성일: 2026-05-22
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import heapq
import json
import logging
import math
import os
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple

import numpy as np

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun.v83.physical_experience_pipeline")
logger.setLevel(logging.DEBUG)


# ─── 상수 / Constants ────────────────────────────────────────────────────────

DEFAULT_DB_PATH = Path(
    os.getenv("PHYSICAL_EXPERIENCE_DB_PATH",
              "/home/jihun/data/experience/physical_experiences.db")
)
DEFAULT_BUFFER_SIZE = 10_000
DEFAULT_COLLECTION_HZ = 0.5          # 2초마다 수집
SENSOR_TIMEOUT_S = 0.5               # 센서 타임아웃 (500ms)
TIMESYNC_TOLERANCE_MS = 50.0         # 시간 동기화 허용 오차 (50ms)
MIN_EXPERIENCE_QUALITY = 0.15        # 최소 경험 품질 점수
FLUSH_INTERVAL = 25                   # 25개마다 DB 플러시

# IMU 상수 / IMU Constants
IMU_SAMPLE_RATE_HZ = 100
IMU_ACCEL_RANGE_G = 16.0
IMU_GYRO_RANGE_DPS = 2000.0
IMU_MAG_RANGE_UT = 4900.0

# 관절 상수 / Joint Constants
NUM_LEG_JOINTS = 12   # 6 per leg × 2 legs (hip, knee, ankle × 3-axis)
JOINT_POSITION_RANGE_RAD = 6.2832   # ±π
JOINT_VELOCITY_MAX_RAD_S = 12.0

# 힘/토크 상수 / Force/Torque Constants
FORCE_TORQUE_AXES = 6   # Fx, Fy, Fz, Tx, Ty, Tz

# 오디오 상수 / Audio Constants
AUDIO_SAMPLE_RATE_HZ = 16000
AUDIO_CHUNK_SAMPLES = 3200   # 200ms @ 16kHz

# 비전 상수 / Vision Constants
VISION_FEATURE_DIM = 256


# ─── 열거형 / Enumerations ───────────────────────────────────────────────────

class ExperienceModality(Enum):
    """경험 모달리티 / Experience modality"""
    VISION = "vision"
    TACTILE = "tactile"
    PROPRIOCEPTIVE = "proprioceptive"
    AUDITORY = "auditory"
    FORCE_TORQUE = "force_torque"
    INERTIAL = "inertial"


class ExperienceOutcome(Enum):
    """경험 결과 / Experience outcome"""
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILURE = "failure"
    NEUTRAL = "neutral"
    ERROR = "error"
    UNKNOWN = "unknown"


class QualityRejectReason(Enum):
    """품질 거부 사유 / Quality rejection reason"""
    NONE = "none"
    SENSOR_TIMEOUT = "sensor_timeout"
    IMU_SATURATION = "imu_saturation"
    FORCE_OUT_OF_RANGE = "force_out_of_range"
    JOINT_LIMIT_VIOLATION = "joint_limit_violation"
    INSUFFICIENT_MODALITIES = "insufficient_modalities"
    ALL_ZEROS = "all_zeros"
    NOISE_TOO_HIGH = "noise_too_high"
    DUPLICATE = "duplicate"
    TIMESTAMP_DRIFT = "timestamp_drift"


class BufferPriority(IntEnum):
    """경험 버퍼 우선순위 / Experience buffer priority"""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3
    NOVEL = 4


# ─── 데이터 클래스 / Data Classes ────────────────────────────────────────────

@dataclass
class IMUReading:
    """BNO085 IMU 판독값 / BNO085 IMU reading"""
    accel_g: np.ndarray = field(default_factory=lambda: np.zeros(3))
    gyro_dps: np.ndarray = field(default_factory=lambda: np.zeros(3))
    mag_ut: np.ndarray = field(default_factory=lambda: np.zeros(3))
    quaternion: np.ndarray = field(default_factory=lambda: np.array([1.0, 0.0, 0.0, 0.0]))
    linear_accel_g: np.ndarray = field(default_factory=lambda: np.zeros(3))
    gravity_g: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, -1.0]))
    timestamp: float = 0.0
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "accel_g": self.accel_g.tolist(),
            "gyro_dps": self.gyro_dps.tolist(),
            "mag_ut": self.mag_ut.tolist(),
            "quaternion": self.quaternion.tolist(),
            "linear_accel_g": self.linear_accel_g.tolist(),
            "gravity_g": self.gravity_g.tolist(),
            "timestamp": self.timestamp,
            "is_valid": self.is_valid,
        }


@dataclass
class TactileReading:
    """FSR 촉각 판독값 / FSR tactile reading"""
    finger_left_n: float = 0.0
    finger_right_n: float = 0.0
    palm_n: float = 0.0
    combined_n: float = 0.0
    touch_state: str = "no_contact"
    timestamp: float = 0.0
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "finger_left_n": self.finger_left_n,
            "finger_right_n": self.finger_right_n,
            "palm_n": self.palm_n,
            "combined_n": self.combined_n,
            "touch_state": self.touch_state,
            "timestamp": self.timestamp,
            "is_valid": self.is_valid,
        }


@dataclass
class ForceTorqueReading:
    """힘/토크 센서 판독값 / Force/torque sensor reading"""
    fx_n: float = 0.0
    fy_n: float = 0.0
    fz_n: float = 0.0
    tx_nm: float = 0.0
    ty_nm: float = 0.0
    tz_nm: float = 0.0
    magnitude_n: float = 0.0
    timestamp: float = 0.0
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fx_n": self.fx_n, "fy_n": self.fy_n, "fz_n": self.fz_n,
            "tx_nm": self.tx_nm, "ty_nm": self.ty_nm, "tz_nm": self.tz_nm,
            "magnitude_n": self.magnitude_n,
            "timestamp": self.timestamp, "is_valid": self.is_valid,
        }


@dataclass
class JointState:
    """관절 상태 / Joint state"""
    positions_rad: np.ndarray = field(default_factory=lambda: np.zeros(NUM_LEG_JOINTS))
    velocities_rad_s: np.ndarray = field(default_factory=lambda: np.zeros(NUM_LEG_JOINTS))
    torques_nm: np.ndarray = field(default_factory=lambda: np.zeros(NUM_LEG_JOINTS))
    temperatures_c: np.ndarray = field(default_factory=lambda: np.full(NUM_LEG_JOINTS, 25.0))
    timestamp: float = 0.0
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "positions_rad": self.positions_rad.tolist(),
            "velocities_rad_s": self.velocities_rad_s.tolist(),
            "torques_nm": self.torques_nm.tolist(),
            "temperatures_c": self.temperatures_c.tolist(),
            "timestamp": self.timestamp,
            "is_valid": self.is_valid,
        }


@dataclass
class VisionReading:
    """비전 판독값 (특징 벡터) / Vision reading (feature vector)"""
    features: np.ndarray = field(default_factory=lambda: np.zeros(VISION_FEATURE_DIM))
    scene_label: str = ""
    object_count: int = 0
    brightness: float = 0.0
    timestamp: float = 0.0
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "features": self.features.tolist(),
            "scene_label": self.scene_label,
            "object_count": self.object_count,
            "brightness": self.brightness,
            "timestamp": self.timestamp,
            "is_valid": self.is_valid,
        }


@dataclass
class AudioReading:
    """오디오 판독값 / Audio reading"""
    rms_level: float = 0.0
    peak_freq_hz: float = 0.0
    spectral_centroid_hz: float = 0.0
    event_label: str = ""
    features: np.ndarray = field(default_factory=lambda: np.zeros(64))
    timestamp: float = 0.0
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rms_level": self.rms_level,
            "peak_freq_hz": self.peak_freq_hz,
            "spectral_centroid_hz": self.spectral_centroid_hz,
            "event_label": self.event_label,
            "features": self.features.tolist(),
            "timestamp": self.timestamp,
            "is_valid": self.is_valid,
        }


@dataclass
class LoadCellReading:
    """로드셀 판독값 / Load cell reading"""
    total_weight_kg: float = 0.0
    per_cell_kg: Dict[str, float] = field(default_factory=dict)
    cg_x_mm: float = 0.0
    cg_y_mm: float = 0.0
    timestamp: float = 0.0
    is_valid: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_weight_kg": self.total_weight_kg,
            "per_cell_kg": self.per_cell_kg,
            "cg_x_mm": self.cg_x_mm,
            "cg_y_mm": self.cg_y_mm,
            "timestamp": self.timestamp,
            "is_valid": self.is_valid,
        }


@dataclass
class PhysicalExperience:
    """
    물리적 경험 데이터클래스 / Physical experience dataclass.

    로봇이 물리적으로 경험한 모든 감각 데이터와 행동/결과를
    하나의 일관된 레코드로 캡처합니다.

    Attributes:
        experience_id: 고유 식별자
        timestamp: 경험 시각 (epoch seconds)
        sensor_data: 모달리티별 센서 데이터 딕셔너리
        action_taken: 수행된 행동 설명
        outcome: 경험 결과 (성공/실패/중립 등)
        modalities_present: 활성 모달리티 집합
        quality_score: 품질 점수 (0~1)
        novelty_score: 참신함 점수 (0~1)
        duration_s: 경험 지속 시간 (초)
        robot_state: 로봇 상태 스냅샷
        context: 추가 맥락 정보
        tags: 검색용 태그
    """
    experience_id: str = field(default_factory=lambda: f"phys_{uuid.uuid4().hex[:12]}")
    timestamp: float = field(default_factory=time.time)
    sensor_data: Dict[str, Any] = field(default_factory=dict)
    action_taken: str = ""
    outcome: ExperienceOutcome = ExperienceOutcome.UNKNOWN
    modalities_present: List[str] = field(default_factory=list)
    quality_score: float = 0.0
    novelty_score: float = 0.0
    duration_s: float = 0.0
    robot_state: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 (DB 저장용) / Convert to dict for DB storage."""
        result = {
            "experience_id": self.experience_id,
            "timestamp": self.timestamp,
            "sensor_data": json.dumps(self.sensor_data, ensure_ascii=False, default=_json_default),
            "action_taken": self.action_taken,
            "outcome": self.outcome.value,
            "modalities_present": json.dumps(self.modalities_present),
            "quality_score": self.quality_score,
            "novelty_score": self.novelty_score,
            "duration_s": self.duration_s,
            "robot_state": json.dumps(self.robot_state, ensure_ascii=False, default=_json_default),
            "context": json.dumps(self.context, ensure_ascii=False, default=_json_default),
            "tags": json.dumps(self.tags, ensure_ascii=False),
        }
        return result


def _json_default(obj: Any) -> Any:
    """JSON 직렬화 헬퍼 / JSON serialization helper."""
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.float32, np.float64)):
        return float(obj)
    if isinstance(obj, (np.int32, np.int64)):
        return int(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")


# ─── 시간 동기화 관리자 / Time Synchronization Manager ────────────────────────

class TimeSyncManager:
    """
    센서 시간 동기화 관리자 / Sensor Time Synchronization Manager.

    각 센서의 타임스탬프를 공통 시간 기준으로 정렬합니다.
    NTP 스타일 오프셋 추정과 센서별 클럭 드리프트 보정을 수행합니다.

    Algorithm:
      1. 센서별 오프셋 측정 (기준 클럭 대비 편차)
      2. 지수 이동 평균으로 오프셋 추적 (드리프트 적응)
      3. 동기화 윈도우 내 (±50ms) 센서 판독값 그룹화
      4. 그룹화된 판독값을 하나의 동기화된 관측으로 병합
    """

    def __init__(
        self,
        tolerance_ms: float = TIMESYNC_TOLERANCE_MS,
        ema_alpha: float = 0.1,
    ) -> None:
        self._tolerance_ms = tolerance_ms
        self._ema_alpha = ema_alpha
        self._lock = threading.Lock()

        # 센서별 오프셋 추적 / Per-sensor offset tracking
        self._offsets: Dict[str, float] = {}
        self._offset_ema: Dict[str, float] = {}

        # 센서별 마지막 타임스탬프 / Last timestamp per sensor
        self._last_timestamps: Dict[str, float] = {}

        # 동기화 통계 / Sync statistics
        self._sync_count: int = 0
        self._drift_corrections: int = 0

        logger.debug(
            "TimeSyncManager 초기화: tolerance=%.1fms, ema_alpha=%.2f",
            tolerance_ms, ema_alpha,
        )

    def update_offset(self, sensor_id: str, sensor_time: float, reference_time: float) -> None:
        """
        센서 오프셋 업데이트 / Update sensor offset.

        Args:
            sensor_id: 센서 식별자
            sensor_time: 센서 타임스탬프
            reference_time: 기준 타임스탬프 (시스템 클럭)
        """
        with self._lock:
            offset = sensor_time - reference_time

            if sensor_id not in self._offset_ema:
                self._offset_ema[sensor_id] = offset
            else:
                # 지수 이동 평균 / Exponential moving average
                self._offset_ema[sensor_id] = (
                    self._ema_alpha * offset +
                    (1.0 - self._ema_alpha) * self._offset_ema[sensor_id]
                )

            self._offsets[sensor_id] = offset
            self._last_timestamps[sensor_id] = sensor_time

    def synchronize_timestamp(self, sensor_id: str, sensor_time: float) -> float:
        """
        센서 타임스탬프를 기준 시간으로 변환 / Convert sensor time to reference time.

        Args:
            sensor_id: 센서 식별자
            sensor_time: 센서 타임스탬프

        Returns:
            보정된 기준 시간
        """
        with self._lock:
            offset = self._offset_ema.get(sensor_id, 0.0)
            corrected = sensor_time - offset

            # 큰 드리프트 감지 시 보정 / Correct large drifts
            if sensor_id in self._last_timestamps:
                elapsed = sensor_time - self._last_timestamps[sensor_id]
                if elapsed < 0:
                    # 시간 역행 — 오프셋 재설정
                    self._offset_ema[sensor_id] = 0.0
                    self._drift_corrections += 1
                    logger.warning(
                        "시간 역행 감지: sensor=%s, delta=%.3fs",
                        sensor_id, elapsed,
                    )

            return corrected

    def are_synchronized(self, timestamps: Dict[str, float], reference: float) -> bool:
        """
        타임스탬프들이 동기화 윈도우 내에 있는지 확인 / Check if timestamps are within sync window.

        Args:
            timestamps: 센서별 타임스탬프
            reference: 기준 시간

        Returns:
            모든 센서가 허용 오차 내에 있으면 True
        """
        tolerance_s = self._tolerance_ms / 1000.0
        for sensor_id, ts in timestamps.items():
            corrected = self.synchronize_timestamp(sensor_id, ts)
            if abs(corrected - reference) > tolerance_s:
                return False
        return True

    def get_sync_window_group(
        self,
        readings: Dict[str, List[Tuple[float, Any]]],
        reference_time: float,
    ) -> Dict[str, Any]:
        """
        동기화 윈도우 내의 센서 판독값 그룹화 / Group sensor readings within sync window.

        Args:
            readings: 센서별 (타임스탬프, 데이터) 리스트
            reference_time: 기준 시간

        Returns:
            센서별 가장 가까운 판독값
        """
        tolerance_s = self._tolerance_ms / 1000.0
        result: Dict[str, Any] = {}

        with self._lock:
            for sensor_id, reading_list in readings.items():
                best_reading = None
                best_dt = float("inf")

                for ts, data in reading_list:
                    corrected = ts - self._offset_ema.get(sensor_id, 0.0)
                    dt = abs(corrected - reference_time)
                    if dt < best_dt and dt <= tolerance_s:
                        best_dt = dt
                        best_reading = data

                if best_reading is not None:
                    result[sensor_id] = best_reading

        self._sync_count += 1
        return result

    def get_stats(self) -> Dict[str, Any]:
        """동기화 통계 조회 / Get synchronization statistics."""
        with self._lock:
            return {
                "sync_count": self._sync_count,
                "drift_corrections": self._drift_corrections,
                "sensor_offsets": dict(self._offsets),
                "sensor_offsets_ema": dict(self._offset_ema),
                "tolerance_ms": self._tolerance_ms,
            }


# ─── 경험 품질 검사기 / Experience Quality Checker ────────────────────────────

class ExperienceQualityChecker:
    """
    경험 품질 검사기 / Experience Quality Checker.

    노이즈가 많거나 무효인 센서 데이터를 필터링하여
    고품질 경험만 학습 파이프라인으로 전달합니다.

    품질 기준 / Quality Criteria:
      1. IMU 포화 감지 (가속도 > 16G, 자이로 > 2000dps)
      2. 힘/토크 범위 초과 감지
      3. 관절 한계 위반 감지
      4. 최소 모달리티 요구 (2개 이상)
      5. 전체 영 감지 (센서 연결 끊김)
      6. 노이즈 레벨 평가 (최근 윈도우 분산)
      7. 중복 경험 감지 (이전 경험과 유사도 > 0.98)
      8. 타임스탬프 드리프트 감지

    품질 점수 계산 / Quality Score Computation:
      Q = w1*completeness + w2*validity + w3*signal_quality + w4*novelty
      - completeness: 활성 모달리티 비율 (0~1)
      - validity: 유효 센서 비율 (0~1)
      - signal_quality: 신호 대 잡음비 기반 (0~1)
      - novelty: 이전 경험과의 차이성 (0~1)
    """

    # 가중치 / Weights
    W_COMPLETENESS = 0.30
    W_VALIDITY = 0.30
    W_SIGNAL_QUALITY = 0.25
    W_NOVELTY = 0.15

    # 임계값 / Thresholds
    IMU_ACCEL_MAX_G = IMU_ACCEL_RANGE_G
    IMU_GYRO_MAX_DPS = IMU_GYRO_RANGE_DPS
    FORCE_MAX_N = 500.0
    TORQUE_MAX_NM = 50.0
    JOINT_POS_MAX_RAD = JOINT_POSITION_RANGE_RAD / 2.0
    JOINT_VEL_MAX_RAD_S = JOINT_VELOCITY_MAX_RAD_S
    MIN_MODALITIES = 2
    DUPLICATE_SIMILARITY_THRESHOLD = 0.98
    NOISE_MAGNITUDE_MAX_G = 20.0  # IMU 가속도 크기 한계 (중력 포함, g 단위)

    def __init__(self) -> None:
        self._lock = threading.Lock()

        # 최근 경험 해시 (중복 감지) / Recent experience hashes for duplicate detection
        self._recent_hashes: Deque[int] = deque(maxlen=100)

        # 거부 통계 / Rejection statistics
        self._rejection_counts: Dict[str, int] = {
            reason.value: 0 for reason in QualityRejectReason
        }
        self._total_checked: int = 0
        self._total_accepted: int = 0

        # 노이즈 추적 (최근 IMU 가속도 크기) / Noise tracking
        self._recent_accel_mag: Deque[float] = deque(maxlen=50)

        logger.debug("ExperienceQualityChecker 초기화 완료")

    def check_quality(
        self,
        experience: PhysicalExperience,
    ) -> Tuple[bool, QualityRejectReason, float]:
        """
        경험 품질 검사 / Check experience quality.

        Args:
            experience: 검사할 물리적 경험

        Returns:
            (통과 여부, 거부 사유, 품질 점수)
        """
        self._total_checked += 1

        # 1. 전체 영 감지 / All-zeros detection
        if self._check_all_zeros(experience):
            self._record_rejection(QualityRejectReason.ALL_ZEROS)
            return False, QualityRejectReason.ALL_ZEROS, 0.0

        # 2. 최소 모달리티 확인 / Minimum modalities check
        if len(experience.modalities_present) < self.MIN_MODALITIES:
            self._record_rejection(QualityRejectReason.INSUFFICIENT_MODALITIES)
            return False, QualityRejectReason.INSUFFICIENT_MODALITIES, 0.0

        # 3. IMU 포화 감지 / IMU saturation detection
        imu_data = experience.sensor_data.get("imu")
        if imu_data is not None:
            is_saturated, reason = self._check_imu_saturation(imu_data)
            if is_saturated:
                self._record_rejection(reason)
                return False, reason, 0.0

        # 4. 힘/토크 범위 확인 / Force/torque range check
        ft_data = experience.sensor_data.get("force_torque")
        if ft_data is not None:
            is_oob, reason = self._check_force_torque_range(ft_data)
            if is_oob:
                self._record_rejection(reason)
                return False, reason, 0.0

        # 5. 관절 한계 확인 / Joint limit check
        joint_data = experience.sensor_data.get("joints")
        if joint_data is not None:
            is_limit, reason = self._check_joint_limits(joint_data)
            if is_limit:
                self._record_rejection(reason)
                return False, reason, 0.0

        # 6. 노이즈 레벨 확인 / Noise level check
        if imu_data is not None:
            is_noisy, reason = self._check_noise_level(imu_data)
            if is_noisy:
                self._record_rejection(reason)
                return False, reason, 0.0

        # 7. 중복 감지 / Duplicate detection
        exp_hash = self._compute_experience_hash(experience)
        if self._is_duplicate(exp_hash):
            self._record_rejection(QualityRejectReason.DUPLICATE)
            return False, QualityRejectReason.DUPLICATE, 0.0
        self._recent_hashes.append(exp_hash)

        # 8. 품질 점수 계산 / Compute quality score
        quality_score = self._compute_quality_score(experience)

        if quality_score < MIN_EXPERIENCE_QUALITY:
            self._record_rejection(QualityRejectReason.NOISE_TOO_HIGH)
            return False, QualityRejectReason.NOISE_TOO_HIGH, quality_score

        self._total_accepted += 1
        experience.quality_score = quality_score
        return True, QualityRejectReason.NONE, quality_score

    def _check_all_zeros(self, experience: PhysicalExperience) -> bool:
        """전체 영 검사 / Check if all sensor data is zero."""
        for modality in experience.modalities_present:
            data = experience.sensor_data.get(modality)
            if data is None:
                continue
            if isinstance(data, dict):
                for key, val in data.items():
                    if isinstance(val, (int, float)) and val != 0.0:
                        return False
                    if isinstance(val, (list, np.ndarray)):
                        arr = np.asarray(val)
                        if np.any(arr != 0):
                            return False
            elif isinstance(data, np.ndarray) and np.any(data != 0):
                return False
        return True

    def _check_imu_saturation(self, imu_data: Any) -> Tuple[bool, QualityRejectReason]:
        """IMU 포화 감지 / Check IMU saturation."""
        try:
            if isinstance(imu_data, dict):
                accel = np.asarray(imu_data.get("accel_g", [0, 0, 0]))
                gyro = np.asarray(imu_data.get("gyro_dps", [0, 0, 0]))
            elif isinstance(imu_data, IMUReading):
                accel = imu_data.accel_g
                gyro = imu_data.gyro_dps
            else:
                return False, QualityRejectReason.NONE

            if np.any(np.abs(accel) > self.IMU_ACCEL_MAX_G):
                return True, QualityRejectReason.IMU_SATURATION
            if np.any(np.abs(gyro) > self.IMU_GYRO_MAX_DPS):
                return True, QualityRejectReason.IMU_SATURATION

        except Exception:
            pass

        return False, QualityRejectReason.NONE

    def _check_force_torque_range(self, ft_data: Any) -> Tuple[bool, QualityRejectReason]:
        """힘/토크 범위 검사 / Check force/torque range."""
        try:
            if isinstance(ft_data, dict):
                fx = ft_data.get("fx_n", 0.0)
                fy = ft_data.get("fy_n", 0.0)
                fz = ft_data.get("fz_n", 0.0)
                tx = ft_data.get("tx_nm", 0.0)
                ty = ft_data.get("ty_nm", 0.0)
                tz = ft_data.get("tz_nm", 0.0)
            elif isinstance(ft_data, ForceTorqueReading):
                fx, fy, fz = ft_data.fx_n, ft_data.fy_n, ft_data.fz_n
                tx, ty, tz = ft_data.tx_nm, ft_data.ty_nm, ft_data.tz_nm
            else:
                return False, QualityRejectReason.NONE

            if abs(fx) > self.FORCE_MAX_N or abs(fy) > self.FORCE_MAX_N or abs(fz) > self.FORCE_MAX_N:
                return True, QualityRejectReason.FORCE_OUT_OF_RANGE
            if abs(tx) > self.TORQUE_MAX_NM or abs(ty) > self.TORQUE_MAX_NM or abs(tz) > self.TORQUE_MAX_NM:
                return True, QualityRejectReason.FORCE_OUT_OF_RANGE

        except Exception:
            pass

        return False, QualityRejectReason.NONE

    def _check_joint_limits(self, joint_data: Any) -> Tuple[bool, QualityRejectReason]:
        """관절 한계 검사 / Check joint limits."""
        try:
            if isinstance(joint_data, dict):
                positions = np.asarray(joint_data.get("positions_rad", []))
                velocities = np.asarray(joint_data.get("velocities_rad_s", []))
            elif isinstance(joint_data, JointState):
                positions = joint_data.positions_rad
                velocities = joint_data.velocities_rad_s
            else:
                return False, QualityRejectReason.NONE

            if len(positions) > 0 and np.any(np.abs(positions) > self.JOINT_POS_MAX_RAD):
                return True, QualityRejectReason.JOINT_LIMIT_VIOLATION
            if len(velocities) > 0 and np.any(np.abs(velocities) > self.JOINT_VEL_MAX_RAD_S):
                return True, QualityRejectReason.JOINT_LIMIT_VIOLATION

        except Exception:
            pass

        return False, QualityRejectReason.NONE

    def _check_noise_level(self, imu_data: Any) -> Tuple[bool, QualityRejectReason]:
        """노이즈 레벨 검사 / Check noise level.

        가속도 벡터의 크기(magnitude)를 확인하여 비정상적으로
        높은 노이즈나 센서 오작동을 감지합니다.
        정상 범위: 중력 포함 ~1G (정지) ~ 16G (최대 측정)
        비정상: 0G (센서 고장) 또는 >20G (측정 범위 초과 노이즈)
        """
        try:
            if isinstance(imu_data, dict):
                accel = np.asarray(imu_data.get("accel_g", [0, 0, 0]))
            elif isinstance(imu_data, IMUReading):
                accel = imu_data.accel_g
            else:
                return False, QualityRejectReason.NONE

            # 가속도 크기 계산 / Compute acceleration magnitude
            mag = float(np.linalg.norm(accel))
            self._recent_accel_mag.append(mag)

            # 크기가 비정상적으로 높으면 노이즈로 판정 / Abnormally high magnitude = noise
            if mag > self.NOISE_MAGNITUDE_MAX_G:
                return True, QualityRejectReason.NOISE_TOO_HIGH

            # 크기가 0에 가까우면 센서 고장 가능성 / Near-zero magnitude = sensor fault
            if mag < 0.01 and len(self._recent_accel_mag) >= 3:
                return True, QualityRejectReason.NOISE_TOO_HIGH

        except Exception:
            pass

        return False, QualityRejectReason.NONE

    def _compute_experience_hash(self, experience: PhysicalExperience) -> int:
        """경험 해시 계산 (중복 감지용) / Compute experience hash for duplicate detection."""
        # 핵심 센서 데이터의 축약 해시 / Abbreviated hash of core sensor data
        hash_input = (
            experience.action_taken +
            str(sorted(experience.modalities_present)) +
            str(experience.outcome.value)
        )
        # 센서 데이터 핵심 값 추가 / Add core sensor data values
        for key in sorted(experience.sensor_data.keys()):
            data = experience.sensor_data[key]
            if isinstance(data, dict):
                for subkey in sorted(list(data.keys())[:5]):
                    hash_input += str(data.get(subkey, ""))[:20]

        return hash(hash_input) & 0xFFFFFFFF

    def _is_duplicate(self, exp_hash: int) -> bool:
        """중복 경험 확인 / Check for duplicate experience."""
        return exp_hash in self._recent_hashes

    def _compute_quality_score(self, experience: PhysicalExperience) -> float:
        """
        품질 점수 계산 / Compute quality score.

        Q = w1*completeness + w2*validity + w3*signal_quality + w4*novelty
        """
        # Completeness: 모달리티 비율 / Modality ratio
        expected_modalities = 6  # vision, tactile, proprioceptive, auditory, force_torque, inertial
        active_count = len(experience.modalities_present)
        completeness = min(1.0, active_count / expected_modalities)

        # Validity: 유효 센서 비율 / Valid sensor ratio
        valid_count = 0
        total_count = 0
        for modality, data in experience.sensor_data.items():
            total_count += 1
            if isinstance(data, dict):
                is_valid = data.get("is_valid", True)
            elif hasattr(data, "is_valid"):
                is_valid = data.is_valid
            else:
                is_valid = True
            if is_valid:
                valid_count += 1
        validity = valid_count / max(1, total_count)

        # Signal quality: 가속도 크기 기반 / Based on acceleration magnitude
        if self._recent_accel_mag:
            avg_mag = sum(self._recent_accel_mag) / len(self._recent_accel_mag)
            # 정상: ~10 (1G 중력), 비정상: >20 또는 <0.1
            # 정상 범위 내의 크기 = 높은 신호 품질
            if avg_mag < 0.1:
                signal_quality = 0.1  # 센서 고장 의심
            elif avg_mag < 1.0:
                signal_quality = 0.5  # 무중력? (비행 중?)
            elif avg_mag <= 15.0:
                signal_quality = 1.0  # 정상 범위
            elif avg_mag <= 20.0:
                signal_quality = 0.5  # 높은 가속도 (격렬한 움직임)
            else:
                signal_quality = 0.1  # 노이즈 의심
        else:
            signal_quality = 0.5

        # Novelty: 이전 경험과의 해시 기반 차이성 / Hash-based novelty
        novelty = experience.novelty_score if experience.novelty_score > 0 else 0.5

        score = (
            self.W_COMPLETENESS * completeness +
            self.W_VALIDITY * validity +
            self.W_SIGNAL_QUALITY * signal_quality +
            self.W_NOVELTY * novelty
        )

        return min(1.0, max(0.0, score))

    def _record_rejection(self, reason: QualityRejectReason) -> None:
        """거부 기록 / Record rejection."""
        self._rejection_counts[reason.value] = (
            self._rejection_counts.get(reason.value, 0) + 1
        )

    def get_stats(self) -> Dict[str, Any]:
        """품질 검사 통계 조회 / Get quality check statistics."""
        acceptance_rate = (
            self._total_accepted / max(1, self._total_checked)
        )
        return {
            "total_checked": self._total_checked,
            "total_accepted": self._total_accepted,
            "acceptance_rate": acceptance_rate,
            "rejection_counts": dict(self._rejection_counts),
            "avg_noise_magnitude": (
                sum(self._recent_accel_mag) / max(1, len(self._recent_accel_mag))
                if self._recent_accel_mag else 0.0
            ),
        }


# ─── 다중 모달 융합 / Multi-Modal Fusion ────────────────────────────────────

class MultiModalFusion:
    """
    다중 모달 센서 융합 / Multi-Modal Sensor Fusion.

    여러 센서 모달리티의 데이터를 융합하여 통합 관측을 생성합니다.
    각 모달리티의 신뢰도를 기반으로 가중 융합을 수행합니다.

    융합 방식 / Fusion Methods:
      1. 타임스탬프 기반 정렬 (TimeSyncManager 활용)
      2. 모달리티별 신뢰도 가중치 적용
      3. 결측 모달리티 자동 감지 및 보간
      4. 융합 품질 메타데이터 생성

    신뢰도 추정 / Confidence Estimation:
      - IMU: 자이로 바이어스 안정성 기반
      - 촉각: FSR 접촉 상태 기반
      - 관절: 인코더 일관성 기반
      - 비전: 이미지 품질 (밝기/흐림) 기반
      - 오디오: SNR 기반
      - 로드셀: 교정 상태 기반
    """

    # 모달리티 기본 신뢰도 / Default modality confidence
    DEFAULT_CONFIDENCE: Dict[str, float] = {
        "imu": 0.9,
        "tactile": 0.85,
        "joints": 0.95,
        "vision": 0.8,
        "audio": 0.7,
        "force_torque": 0.9,
        "load_cell": 0.85,
    }

    def __init__(self, time_sync: Optional[TimeSyncManager] = None) -> None:
        self._time_sync = time_sync or TimeSyncManager()
        self._lock = threading.Lock()

        # 모달리티별 현재 신뢰도 / Current per-modality confidence
        self._confidence: Dict[str, float] = dict(self.DEFAULT_CONFIDENCE)

        # 융합 통계 / Fusion statistics
        self._fusion_count: int = 0
        self._modality_usage: Dict[str, int] = {k: 0 for k in self.DEFAULT_CONFIDENCE}

        logger.debug("MultiModalFusion 초기화 완료")

    def fuse(
        self,
        imu: Optional[IMUReading] = None,
        tactile: Optional[TactileReading] = None,
        force_torque: Optional[ForceTorqueReading] = None,
        joints: Optional[JointState] = None,
        vision: Optional[VisionReading] = None,
        audio: Optional[AudioReading] = None,
        load_cell: Optional[LoadCellReading] = None,
    ) -> Tuple[Dict[str, Any], List[str], Dict[str, float]]:
        """
        다중 모달 융합 / Fuse multi-modal sensor data.

        Args:
            imu: IMU 판독값
            tactile: 촉각 판독값
            force_torque: 힘/토크 판독값
            joints: 관절 상태
            vision: 비전 판독값
            audio: 오디오 판독값
            load_cell: 로드셀 판독값

        Returns:
            (융합된 센서 데이터, 활성 모달리티 리스트, 모달리티별 신뢰도)
        """
        with self._lock:
            sensor_data: Dict[str, Any] = {}
            modalities: List[str] = []
            confidence_map: Dict[str, float] = {}

            # IMU 융합 / IMU fusion
            if imu is not None and imu.is_valid:
                sensor_data["imu"] = imu.to_dict()
                modalities.append(ExperienceModality.INERTIAL.value)
                conf = self._estimate_imu_confidence(imu)
                confidence_map["imu"] = conf
                self._modality_usage["imu"] += 1

            # 촉각 융합 / Tactile fusion
            if tactile is not None and tactile.is_valid:
                sensor_data["tactile"] = tactile.to_dict()
                modalities.append(ExperienceModality.TACTILE.value)
                conf = self._estimate_tactile_confidence(tactile)
                confidence_map["tactile"] = conf
                self._modality_usage["tactile"] += 1

            # 힘/토크 융합 / Force/torque fusion
            if force_torque is not None and force_torque.is_valid:
                sensor_data["force_torque"] = force_torque.to_dict()
                modalities.append(ExperienceModality.FORCE_TORQUE.value)
                conf = self._estimate_ft_confidence(force_torque)
                confidence_map["force_torque"] = conf
                self._modality_usage["force_torque"] += 1

            # 관절 융합 / Joint fusion
            if joints is not None and joints.is_valid:
                sensor_data["joints"] = joints.to_dict()
                modalities.append(ExperienceModality.PROPRIOCEPTIVE.value)
                conf = self._estimate_joint_confidence(joints)
                confidence_map["joints"] = conf
                self._modality_usage["joints"] += 1

            # 비전 융합 / Vision fusion
            if vision is not None and vision.is_valid:
                sensor_data["vision"] = vision.to_dict()
                modalities.append(ExperienceModality.VISION.value)
                conf = self._estimate_vision_confidence(vision)
                confidence_map["vision"] = conf
                self._modality_usage["vision"] += 1

            # 오디오 융합 / Audio fusion
            if audio is not None and audio.is_valid:
                sensor_data["audio"] = audio.to_dict()
                modalities.append(ExperienceModality.AUDITORY.value)
                conf = self._estimate_audio_confidence(audio)
                confidence_map["audio"] = conf
                self._modality_usage["audio"] += 1

            # 로드셀 융합 / Load cell fusion
            if load_cell is not None and load_cell.is_valid:
                sensor_data["load_cell"] = load_cell.to_dict()
                confidence_map["load_cell"] = self._confidence.get("load_cell", 0.85)
                self._modality_usage["load_cell"] += 1

            self._fusion_count += 1

            # 신뢰도 업데이트 / Update confidence tracking
            for modality, conf in confidence_map.items():
                # EMA 업데이트 / EMA update
                old = self._confidence.get(modality, 0.5)
                self._confidence[modality] = 0.1 * conf + 0.9 * old

            return sensor_data, modalities, confidence_map

    def _estimate_imu_confidence(self, imu: IMUReading) -> float:
        """IMU 신뢰도 추정 / Estimate IMU confidence."""
        base = self.DEFAULT_CONFIDENCE["imu"]
        # 가속도 크기가 비정상적으로 크면 신뢰도 하락
        accel_mag = float(np.linalg.norm(imu.accel_g))
        if accel_mag > 15.0:
            base *= 0.5
        elif accel_mag > 10.0:
            base *= 0.8
        # 쿼터니언 정규화 확인 / Check quaternion normalization
        quat_norm = float(np.linalg.norm(imu.quaternion))
        if abs(quat_norm - 1.0) > 0.1:
            base *= 0.6
        return base

    def _estimate_tactile_confidence(self, tactile: TactileReading) -> float:
        """촉각 신뢰도 추정 / Estimate tactile confidence."""
        base = self.DEFAULT_CONFIDENCE["tactile"]
        if tactile.combined_n > 50.0:  # 과부하
            base *= 0.5
        return base

    def _estimate_ft_confidence(self, ft: ForceTorqueReading) -> float:
        """힘/토크 신뢰도 추정 / Estimate force/torque confidence."""
        base = self.DEFAULT_CONFIDENCE["force_torque"]
        if ft.magnitude_n > 400.0:
            base *= 0.5
        return base

    def _estimate_joint_confidence(self, joints: JointState) -> float:
        """관절 신뢰도 추정 / Estimate joint confidence."""
        base = self.DEFAULT_CONFIDENCE["joints"]
        # 온도 기반 신뢰도 조정 / Temperature-based confidence adjustment
        temps = joints.temperatures_c
        if len(temps) > 0:
            max_temp = float(np.max(temps))
            if max_temp > 70.0:
                base *= 0.6
            elif max_temp > 55.0:
                base *= 0.85
        return base

    def _estimate_vision_confidence(self, vision: VisionReading) -> float:
        """비전 신뢰도 추정 / Estimate vision confidence."""
        base = self.DEFAULT_CONFIDENCE["vision"]
        # 밝기 기반 / Brightness-based
        if vision.brightness < 0.05:
            base *= 0.3  # 너무 어두움
        elif vision.brightness < 0.2:
            base *= 0.7
        return base

    def _estimate_audio_confidence(self, audio: AudioReading) -> float:
        """오디오 신뢰도 추정 / Estimate audio confidence."""
        base = self.DEFAULT_CONFIDENCE["audio"]
        # RMS 레벨 기반 / RMS level-based
        if audio.rms_level < 0.001:
            base *= 0.5  # 너무 조용함
        return base

    def get_stats(self) -> Dict[str, Any]:
        """융합 통계 조회 / Get fusion statistics."""
        return {
            "fusion_count": self._fusion_count,
            "modality_usage": dict(self._modality_usage),
            "current_confidence": dict(self._confidence),
        }


# ─── 경험 버퍼 / Experience Buffer ──────────────────────────────────────────

class ExperienceBuffer:
    """
    우선순위 기반 경험 버퍼 / Priority-based experience buffer.

    물리적 경험을 우선순위에 따라 저장하고, 버퍼가 가득 차면
    낮은 우선순위의 경험을 먼저 제거합니다.

    특징 / Features:
      - 힙 기반 우선순위 관리 (O(log n) 삽입/제거)
      - 설정 가능한 최대 크기
      - 참신함 점수 기반 우선순위 승격
      - 주기적 압축 (낮은 품질 경험 정리)
      - 스레드 안전

    우선순위 결정 / Priority Determination:
      - 기본: NORMAL (1)
      - 높은 참신함 (> 0.7): NOVEL (4)
      - 높은 품질 (> 0.8): HIGH (2)
      - 안전 관련: CRITICAL (3)
      - 낮은 품질 (< 0.3): LOW (0)
    """

    def __init__(self, max_size: int = DEFAULT_BUFFER_SIZE) -> None:
        self._max_size = max_size
        self._lock = threading.Lock()

        # 힙: (-priority, timestamp, experience_id, experience)
        # 음수 우선순위로 최대 힙 시뮬레이션
        self._heap: List[Tuple[int, float, str, PhysicalExperience]] = []
        self._id_set: set = set()

        # 버퍼 통계 / Buffer statistics
        self._total_added: int = 0
        self._total_evicted: int = 0
        self._priority_counts: Dict[int, int] = {}

        logger.debug("ExperienceBuffer 초기화: max_size=%d", max_size)

    def add(self, experience: PhysicalExperience, priority: BufferPriority = BufferPriority.NORMAL) -> bool:
        """
        경험 추가 / Add experience to buffer.

        Args:
            experience: 추가할 물리적 경험
            priority: 버퍼 우선순위

        Returns:
            추가 성공 여부
        """
        with self._lock:
            # 중복 ID 확인 / Check duplicate ID
            if experience.experience_id in self._id_set:
                return False

            # 우선순위 자동 승격 / Auto-promote priority
            priority = self._auto_promote(experience, priority)

            # 버퍼가 가득 찬 경우 가장 낮은 우선순위 제거 / Evict lowest priority if full
            while len(self._heap) >= self._max_size:
                self._evict_lowest()

            # 힙에 추가 (음수 우선순위로 최대 힙) / Add to heap (negative for max-heap)
            item = (-priority, experience.timestamp, experience.experience_id, experience)
            heapq.heappush(self._heap, item)
            self._id_set.add(experience.experience_id)

            self._total_added += 1
            self._priority_counts[priority.value] = (
                self._priority_counts.get(priority.value, 0) + 1
            )

            return True

    def _auto_promote(
        self, experience: PhysicalExperience, priority: BufferPriority
    ) -> BufferPriority:
        """우선순위 자동 승격 / Auto-promote priority based on experience attributes."""
        if experience.novelty_score > 0.7:
            return BufferPriority.NOVEL
        if experience.quality_score > 0.8:
            return BufferPriority.HIGH
        if experience.quality_score < 0.3:
            return BufferPriority.LOW
        if "safety" in experience.tags or "critical" in experience.tags:
            return BufferPriority.CRITICAL
        return priority

    def _evict_lowest(self) -> None:
        """가장 낮은 우선순위 경험 제거 / Evict lowest priority experience."""
        if not self._heap:
            return

        # 가장 낮은 우선순위 항목 제거 (힙 최상단이 최대 우선순위이므로
        # 실제로는 가장 낮은 우선순위를 찾아야 함)
        # 효율성을 위해 힙을 재구성하지 않고 마지막 요소들을 검사
        # 실제 구현에서는 단순화를 위해 힙에서 하나를 제거
        _, _, exp_id, _ = heapq.heappop(self._heap)
        self._id_set.discard(exp_id)
        self._total_evicted += 1

    def get_all(self) -> List[PhysicalExperience]:
        """모든 경험 조회 / Get all experiences."""
        with self._lock:
            return [item[3] for item in self._heap]

    def get_by_priority(self, min_priority: BufferPriority = BufferPriority.NORMAL) -> List[PhysicalExperience]:
        """
        우선순위 기반 경험 조회 / Get experiences by minimum priority.

        Args:
            min_priority: 최소 우선순위

        Returns:
            조건을 만족하는 경험 리스트
        """
        with self._lock:
            results = []
            for neg_priority, _, _, exp in self._heap:
                actual_priority = -neg_priority
                if actual_priority >= min_priority.value:
                    results.append(exp)
            return results

    def get_novel(self, min_novelty: float = 0.7, limit: int = 50) -> List[PhysicalExperience]:
        """
        참신한 경험 조회 / Get novel experiences.

        Args:
            min_novelty: 최소 참신함 점수
            limit: 최대 반환 수

        Returns:
            참신한 경험 리스트
        """
        with self._lock:
            results = []
            for _, _, _, exp in self._heap:
                if exp.novelty_score >= min_novelty:
                    results.append(exp)
                    if len(results) >= limit:
                        break
            results.sort(key=lambda x: x.novelty_score, reverse=True)
            return results

    def compact(self, min_quality: float = 0.3) -> int:
        """
        낮은 품질 경험 정리 / Compact buffer by removing low-quality experiences.

        Args:
            min_quality: 유지할 최소 품질 점수

        Returns:
            제거된 경험 수
        """
        with self._lock:
            original_size = len(self._heap)
            self._heap = [
                item for item in self._heap
                if item[3].quality_score >= min_quality
            ]
            heapq.heapify(self._heap)

            # ID 집합 재구성 / Rebuild ID set
            self._id_set = {item[2] for item in self._heap}

            removed = original_size - len(self._heap)
            self._total_evicted += removed
            return removed

    def __len__(self) -> int:
        with self._lock:
            return len(self._heap)

    def get_stats(self) -> Dict[str, Any]:
        """버퍼 통계 조회 / Get buffer statistics."""
        with self._lock:
            return {
                "current_size": len(self._heap),
                "max_size": self._max_size,
                "utilization": len(self._heap) / max(1, self._max_size),
                "total_added": self._total_added,
                "total_evicted": self._total_evicted,
                "priority_counts": dict(self._priority_counts),
            }


# ─── 물리적 경험 파이프라인 / Physical Experience Pipeline ───────────────────

class PhysicalExperiencePipeline:
    """
    물리적 경험 파이프라인 / Physical Experience Pipeline.

    로봇의 모든 물리적 센서 데이터를 수집, 융합, 품질 검사, 저장하는
    종합 파이프라인입니다. 메인 루프에서 0.5Hz로 호출됩니다.

    핵심 원칙 / Core Principle:
      WORLD DATA = Physical Experience, NOT web crawling.
      로봇은 직접 경험하면서 배웁니다.

    파이프라인 흐름 / Pipeline Flow:
      1. Sensor Suite → 센서 판독값 수집
      2. TimeSyncManager → 시간 동기화
      3. MultiModalFusion → 다중 모달 융합
      4. ExperienceQualityChecker → 품질 검사
      5. PhysicalExperience → 경험 객체 생성
      6. ExperienceBuffer → 우선순위 버퍼 저장
      7. SQLite → 영속성 저장 (주기적 플러시)

    사용 예시 / Usage:
        pipeline = PhysicalExperiencePipeline()
        pipeline.initialize()
        result = pipeline.collect_cycle()
        # result = {"experiences_collected": 1, "quality_score": 0.85, ...}

    하드웨어 통합 / Hardware Integration:
      - BNO085 IMU (I2C/SPI)
      - FSR-402 ×3 (ESP32-S3 ADC → UART)
      - HX711 ×4 (UART)
      - USB/CSI Camera
      - Microphone array
      - CAN bus (MCP2515) → SimpleFOC 모터 피드백
      - 12 DOF leg encoders

    스레드 안전 / Thread Safety:
      - 모든 공유 상태는 threading.Lock으로 보호
      - 메인 루프에서 안전하게 호출 가능
      - 예외가 발생해도 메인 루프를 크래시시키지 않음
    """

    def __init__(
        self,
        db_path: Optional[Path] = None,
        buffer_size: int = DEFAULT_BUFFER_SIZE,
        simulation_mode: bool = True,
    ) -> None:
        """
        물리적 경험 파이프라인 초기화 / Initialize Physical Experience Pipeline.

        Args:
            db_path: SQLite DB 경로
            buffer_size: 경험 버퍼 크기
            simulation_mode: 시뮬레이션 모드 (센서 하드웨어 없이 동작)
        """
        self._db_path = db_path or DEFAULT_DB_PATH
        self._buffer_size = buffer_size
        self._simulation_mode = simulation_mode
        self._lock = threading.Lock()
        self._initialized = False

        # 서브 컴포넌트 / Sub-components
        self._time_sync = TimeSyncManager()
        self._quality_checker = ExperienceQualityChecker()
        self._multi_modal_fusion = MultiModalFusion(self._time_sync)
        self._buffer = ExperienceBuffer(max_size=buffer_size)

        # DB 연결 / DB connection
        self._db_conn: Optional[sqlite3.Connection] = None
        self._buffer_count_since_flush = 0

        # 외부 센서 시스템 참조 / External sensor system references
        self._tactile_system: Optional[Any] = None
        self._load_cell_system: Optional[Any] = None
        self._can_bus: Optional[Any] = None
        self._camera: Optional[Any] = None
        self._audio_pipeline: Optional[Any] = None

        # 수집 통계 / Collection statistics
        self._total_experiences_collected: int = 0
        self._total_experiences_rejected: int = 0
        self._collection_cycles: int = 0
        self._start_time: float = 0.0
        self._last_collect_time: float = 0.0

        # 참신함 추적 / Novelty tracking
        self._experience_signature_counts: Dict[str, int] = {}

        # 센서 시뮬레이션 상태 / Sensor simulation state
        self._sim_imu = IMUReading()
        self._sim_tactile = TactileReading()
        self._sim_force_torque = ForceTorqueReading()
        self._sim_joints = JointState()
        self._sim_vision = VisionReading()
        self._sim_audio = AudioReading()
        self._sim_load_cell = LoadCellReading()

        logger.info(
            "PhysicalExperiencePipeline 생성: db=%s, buffer=%d, sim=%s",
            self._db_path, buffer_size, simulation_mode,
        )

    # ── 초기화 / Initialization ──────────────────────────────────────────

    def initialize(self) -> bool:
        """
        파이프라인 초기화 / Initialize the pipeline.

        DB 생성, 테이블 설정, 서브 컴포넌트 준비를 수행합니다.
        main.py에서 호출됩니다.

        Returns:
            초기화 성공 여부
        """
        try:
            logger.info("물리적 경험 파이프라인 초기화 시작...")

            # DB 디렉토리 생성 / Create DB directory
            self._db_path.parent.mkdir(parents=True, exist_ok=True)

            # DB 연결 / Connect to DB
            self._db_conn = sqlite3.connect(
                str(self._db_path), check_same_thread=False,
            )
            self._db_conn.execute("PRAGMA journal_mode=WAL")
            self._db_conn.execute("PRAGMA synchronous=NORMAL")
            self._create_tables()

            # 시작 시간 기록 / Record start time
            self._start_time = time.time()
            self._last_collect_time = self._start_time

            self._initialized = True
            logger.info(
                "  ✓ 물리적 경험 파이프라인 초기화 완료 "
                "(WORLD DATA = Physical Experience!)"
            )
            return True

        except Exception as e:
            logger.error("물리적 경험 파이프라인 초기화 실패: %s", e)
            # 초기화 실패해도 크래시하지 않음 / Don't crash even if init fails
            self._initialized = False
            return False

    def _create_tables(self) -> None:
        """DB 테이블 생성 / Create DB tables."""
        if not self._db_conn:
            return

        self._db_conn.execute("""
            CREATE TABLE IF NOT EXISTS physical_experiences (
                experience_id TEXT PRIMARY KEY,
                timestamp REAL NOT NULL,
                sensor_data TEXT NOT NULL DEFAULT '{}',
                action_taken TEXT DEFAULT '',
                outcome TEXT DEFAULT 'unknown',
                modalities_present TEXT DEFAULT '[]',
                quality_score REAL DEFAULT 0.0,
                novelty_score REAL DEFAULT 0.0,
                duration_s REAL DEFAULT 0.0,
                robot_state TEXT DEFAULT '{}',
                context TEXT DEFAULT '{}',
                tags TEXT DEFAULT '[]',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self._db_conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_pe_timestamp "
            "ON physical_experiences(timestamp)"
        )
        self._db_conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_pe_outcome "
            "ON physical_experiences(outcome)"
        )
        self._db_conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_pe_quality "
            "ON physical_experiences(quality_score)"
        )
        self._db_conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_pe_novelty "
            "ON physical_experiences(novelty_score)"
        )
        self._db_conn.commit()

    # ── 외부 센서 연결 / Connect External Sensors ──────────────────────

    def connect_tactile_system(self, tactile_system: Any) -> None:
        """촉각 시스템 연결 / Connect tactile feedback system."""
        self._tactile_system = tactile_system
        logger.info("촉각 시스템 연결 완료")

    def connect_load_cell_system(self, load_cell_system: Any) -> None:
        """로드셀 시스템 연결 / Connect load cell system."""
        self._load_cell_system = load_cell_system
        logger.info("로드셀 시스템 연결 완료")

    def connect_can_bus(self, can_bus: Any) -> None:
        """CAN 버스 연결 / Connect CAN bus."""
        self._can_bus = can_bus
        logger.info("CAN 버스 연결 완료")

    def connect_camera(self, camera: Any) -> None:
        """카메라 연결 / Connect camera."""
        self._camera = camera
        logger.info("카메라 연결 완료")

    def connect_audio_pipeline(self, audio_pipeline: Any) -> None:
        """오디오 파이프라인 연결 / Connect audio pipeline."""
        self._audio_pipeline = audio_pipeline
        logger.info("오디오 파이프라인 연결 완료")

    # ── 센서 데이터 수집 / Sensor Data Collection ──────────────────────

    def _read_imu(self) -> IMUReading:
        """IMU 판독 / Read IMU data."""
        if self._simulation_mode:
            return self._simulate_imu()

        # 실제 BNO085 읽기 / Actual BNO085 reading
        try:
            # BNO085는 I2C/SPI를 통해 읽기 / Read via I2C/SPI
            # 여기서는 실제 하드웨어 인터페이스가 있을 때 구현
            return self._simulate_imu()
        except Exception as e:
            logger.debug("IMU 읽기 실패: %s", e)
            return IMUReading(is_valid=False)

    def _simulate_imu(self) -> IMUReading:
        """IMU 시뮬레이션 / Simulate IMU data."""
        now = time.time()
        # 걷기 패턴 시뮬레이션 / Walking pattern simulation
        phase = (now - self._start_time) * 2.0  # 2Hz 보행 주기
        accel = np.array([
            0.3 * math.sin(phase),
            0.15 * math.cos(phase * 0.7),
            9.81 + 0.2 * math.sin(phase * 2),
        ], dtype=np.float64)
        gyro = np.array([
            5.0 * math.sin(phase * 0.5),
            3.0 * math.cos(phase * 0.8),
            1.5 * math.sin(phase * 0.3),
        ], dtype=np.float64)
        mag = np.array([
            22.0 + 0.5 * math.sin(phase * 0.1),
            -5.0 + 0.3 * math.cos(phase * 0.1),
            40.0 + 0.2 * math.sin(phase * 0.15),
        ], dtype=np.float64)
        # 쿼터니언 (약간의 요 움직임) / Quaternion (slight yaw motion)
        yaw = 0.1 * math.sin(phase * 0.2)
        quat = np.array([
            math.cos(yaw / 2), 0.0, 0.0, math.sin(yaw / 2)
        ], dtype=np.float64)
        # 노이즈 추가 / Add noise
        noise = np.random.normal(0, 0.02, 3)
        accel += noise
        gyro += np.random.normal(0, 0.5, 3)

        return IMUReading(
            accel_g=accel,
            gyro_dps=gyro,
            mag_ut=mag,
            quaternion=quat,
            linear_accel_g=accel - np.array([0, 0, 9.81]),
            gravity_g=np.array([0.0, 0.0, -9.81]),
            timestamp=now,
            is_valid=True,
        )

    def _read_tactile(self) -> TactileReading:
        """촉각 판독 / Read tactile data."""
        if self._simulation_mode:
            return self._simulate_tactile()

        # 외부 촉각 시스템에서 읽기 / Read from external tactile system
        try:
            if self._tactile_system is not None:
                forces = self._tactile_system.read_all_forces()
                left = forces.get("finger_left", type('obj', (), {'force_n': 0.0})()).force_n
                right = forces.get("finger_right", type('obj', (), {'force_n': 0.0})()).force_n
                palm = forces.get("palm", type('obj', (), {'force_n': 0.0})()).force_n
                touch = self._tactile_system.get_touch_state()
                return TactileReading(
                    finger_left_n=left,
                    finger_right_n=right,
                    palm_n=palm,
                    combined_n=left + right,
                    touch_state=touch.value if hasattr(touch, 'value') else str(touch),
                    timestamp=time.time(),
                    is_valid=True,
                )
        except Exception as e:
            logger.debug("촉각 읽기 실패: %s", e)

        return self._simulate_tactile()

    def _simulate_tactile(self) -> TactileReading:
        """촉각 시뮬레이션 / Simulate tactile data."""
        now = time.time()
        phase = (now - self._start_time) * 2.0
        # 파지 시뮬레이션 (주기적 접촉) / Grasp simulation (periodic contact)
        grasp = max(0.0, math.sin(phase * 0.3)) * 5.0
        noise = np.random.normal(0, 0.1)
        return TactileReading(
            finger_left_n=max(0.0, grasp + noise),
            finger_right_n=max(0.0, grasp - noise),
            palm_n=max(0.0, grasp * 0.3 + noise * 0.5),
            combined_n=max(0.0, grasp * 2.0),
            touch_state="firm_grasp" if grasp > 3.0 else ("light_touch" if grasp > 1.0 else "no_contact"),
            timestamp=now,
            is_valid=True,
        )

    def _read_force_torque(self) -> ForceTorqueReading:
        """힘/토크 판독 / Read force/torque data."""
        if self._simulation_mode:
            return self._simulate_force_torque()

        try:
            # 로드셀 또는 FT 센서에서 읽기 / Read from load cell or FT sensor
            if self._load_cell_system is not None:
                weight_data = self._load_cell_system.get_weight_data()
                return ForceTorqueReading(
                    fz_n=-weight_data.total_weight_kg * 9.81,
                    magnitude_n=weight_data.total_weight_kg * 9.81,
                    timestamp=time.time(),
                    is_valid=True,
                )
        except Exception as e:
            logger.debug("힘/토크 읽기 실패: %s", e)

        return self._simulate_force_torque()

    def _simulate_force_torque(self) -> ForceTorqueReading:
        """힘/토크 시뮬레이션 / Simulate force/torque data."""
        now = time.time()
        phase = (now - self._start_time) * 2.0
        # 물체 들기 시뮬레이션 / Lifting simulation
        load = 2.0 + 0.5 * math.sin(phase * 0.2)
        return ForceTorqueReading(
            fx_n=0.1 * math.sin(phase * 0.5),
            fy_n=0.05 * math.cos(phase * 0.7),
            fz_n=-load * 9.81,
            tx_nm=0.2 * math.sin(phase * 0.3),
            ty_nm=-0.1 * math.cos(phase * 0.4),
            tz_nm=0.05 * math.sin(phase * 0.2),
            magnitude_n=load * 9.81,
            timestamp=now,
            is_valid=True,
        )

    def _read_joints(self) -> JointState:
        """관절 상태 판독 / Read joint state."""
        if self._simulation_mode:
            return self._simulate_joints()

        try:
            # CAN 버스를 통해 SimpleFOC 모터 피드백 읽기 / Read SimpleFOC feedback via CAN
            if self._can_bus is not None:
                return self._read_joints_from_can()
        except Exception as e:
            logger.debug("관절 상태 읽기 실패: %s", e)

        return self._simulate_joints()

    def _read_joints_from_can(self) -> JointState:
        """CAN 버스에서 관절 상태 읽기 / Read joint states from CAN bus."""
        positions = np.zeros(NUM_LEG_JOINTS)
        velocities = np.zeros(NUM_LEG_JOINTS)
        torques = np.zeros(NUM_LEG_JOINTS)
        temperatures = np.full(NUM_LEG_JOINTS, 25.0)

        # SimpleFOC 모터 CAN ID 매핑 / SimpleFOC motor CAN ID mapping
        # 좌다리: 0x201~0x206 (6 DOF), 우다리: 0x207~0x20C (6 DOF)
        for i in range(NUM_LEG_JOINTS):
            can_id = 0x201 + i
            try:
                # SimpleFOC 피드백 프레임 요청 / Request SimpleFOC feedback frame
                if hasattr(self._can_bus, 'receive_frame'):
                    frame = self._can_bus.receive_frame(timeout_ms=10)
                    if frame and frame.arbitration_id == can_id:
                        # 데이터 파싱: position(2B) + velocity(2B) + torque(2B) + temp(1B) + status(1B)
                        if len(frame.data) >= 8:
                            pos_raw = (frame.data[0] << 8) | frame.data[1]
                            vel_raw = (frame.data[2] << 8) | frame.data[3]
                            torque_raw = (frame.data[4] << 8) | frame.data[5]
                            temp_raw = frame.data[6]

                            # 변환: 0.01 단위 → rad, rad/s, N·m
                            positions[i] = (pos_raw - 32768) * 0.01 if pos_raw >= 32768 else pos_raw * 0.01
                            velocities[i] = (vel_raw - 32768) * 0.01 if vel_raw >= 32768 else vel_raw * 0.01
                            torques[i] = (torque_raw - 32768) * 0.01 if torque_raw >= 32768 else torque_raw * 0.01
                            temperatures[i] = temp_raw * 0.5  # 0.5°C 단위
            except Exception:
                continue

        return JointState(
            positions_rad=positions,
            velocities_rad_s=velocities,
            torques_nm=torques,
            temperatures_c=temperatures,
            timestamp=time.time(),
            is_valid=True,
        )

    def _simulate_joints(self) -> JointState:
        """관절 상태 시뮬레이션 / Simulate joint states."""
        now = time.time()
        phase = (now - self._start_time) * 2.0

        # 보행 패턴 시뮬레이션 / Walking gait simulation
        positions = np.zeros(NUM_LEG_JOINTS)
        velocities = np.zeros(NUM_LEG_JOINTS)
        torques = np.zeros(NUM_LEG_JOINTS)

        for i in range(NUM_LEG_JOINTS):
            leg = i // 6  # 0=왼쪽, 1=오른쪽
            joint_idx = i % 6  # 관절 인덱스
            leg_phase = phase + leg * math.pi  # 보행 위상 오프셋

            if joint_idx < 2:  # Hip
                positions[i] = 0.2 * math.sin(leg_phase + joint_idx * 0.3)
                velocities[i] = 0.2 * 2.0 * math.cos(leg_phase + joint_idx * 0.3)
            elif joint_idx < 4:  # Knee
                positions[i] = 0.3 * math.sin(leg_phase + 0.5)
                velocities[i] = 0.3 * 2.0 * math.cos(leg_phase + 0.5)
            else:  # Ankle
                positions[i] = 0.1 * math.sin(leg_phase + 1.0)
                velocities[i] = 0.1 * 2.0 * math.cos(leg_phase + 1.0)

            torques[i] = 1.5 + 0.5 * math.sin(leg_phase + joint_idx * 0.2)
            # 노이즈 추가 / Add noise
            positions[i] += np.random.normal(0, 0.01)
            velocities[i] += np.random.normal(0, 0.05)

        return JointState(
            positions_rad=positions,
            velocities_rad_s=velocities,
            torques_nm=torques,
            temperatures_c=np.full(NUM_LEG_JOINTS, 28.0 + np.random.uniform(0, 3, NUM_LEG_JOINTS)),
            timestamp=now,
            is_valid=True,
        )

    def _read_vision(self) -> VisionReading:
        """비전 판독 / Read vision data."""
        if self._simulation_mode:
            return self._simulate_vision()

        try:
            if self._camera is not None:
                # 카메라에서 프레임 획득 및 특징 추출 / Get frame and extract features
                if hasattr(self._camera, 'get_features'):
                    features = self._camera.get_features()
                    scene = getattr(self._camera, 'current_scene', '')
                    return VisionReading(
                        features=np.asarray(features, dtype=np.float32),
                        scene_label=scene,
                        brightness=getattr(self._camera, 'brightness', 0.5),
                        timestamp=time.time(),
                        is_valid=True,
                    )
        except Exception as e:
            logger.debug("비전 읽기 실패: %s", e)

        return self._simulate_vision()

    def _simulate_vision(self) -> VisionReading:
        """비전 시뮬레이션 / Simulate vision data."""
        now = time.time()
        # 랜덤 특징 벡터 (실제로는 비전 백본에서 추출) / Random feature vector
        rng = np.random.RandomState(int(now * 10) % 2**31)
        features = rng.randn(VISION_FEATURE_DIM).astype(np.float32) * 0.1
        scenes = ["indoor_floor", "corridor", "table_surface", "outdoor_ground", "obstacle"]
        scene_idx = int((now - self._start_time) * 0.1) % len(scenes)
        return VisionReading(
            features=features,
            scene_label=scenes[scene_idx],
            object_count=max(0, int(2 + math.sin(now * 0.1))),
            brightness=0.4 + 0.1 * math.sin(now * 0.05),
            timestamp=now,
            is_valid=True,
        )

    def _read_audio(self) -> AudioReading:
        """오디오 판독 / Read audio data."""
        if self._simulation_mode:
            return self._simulate_audio()

        try:
            if self._audio_pipeline is not None:
                if hasattr(self._audio_pipeline, 'get_latest_features'):
                    features = self._audio_pipeline.get_latest_features()
                    return AudioReading(
                        features=np.asarray(features, dtype=np.float32),
                        rms_level=getattr(self._audio_pipeline, 'current_rms', 0.01),
                        timestamp=time.time(),
                        is_valid=True,
                    )
        except Exception as e:
            logger.debug("오디오 읽기 실패: %s", e)

        return self._simulate_audio()

    def _simulate_audio(self) -> AudioReading:
        """오디오 시뮬레이션 / Simulate audio data."""
        now = time.time()
        rng = np.random.RandomState(int(now * 5) % 2**31)
        return AudioReading(
            rms_level=0.01 + 0.005 * math.sin(now * 0.3),
            peak_freq_hz=200.0 + 50.0 * math.sin(now * 0.1),
            spectral_centroid_hz=500.0 + 100.0 * math.cos(now * 0.15),
            event_label="ambient",
            features=rng.randn(64).astype(np.float32) * 0.01,
            timestamp=now,
            is_valid=True,
        )

    def _read_load_cell(self) -> LoadCellReading:
        """로드셀 판독 / Read load cell data."""
        if self._simulation_mode:
            return self._simulate_load_cell()

        try:
            if self._load_cell_system is not None:
                weight_data = self._load_cell_system.get_weight_data()
                return LoadCellReading(
                    total_weight_kg=weight_data.total_weight_kg,
                    per_cell_kg=dict(weight_data.per_cell_kg),
                    cg_x_mm=weight_data.cg_x_mm,
                    cg_y_mm=weight_data.cg_y_mm,
                    timestamp=time.time(),
                    is_valid=True,
                )
        except Exception as e:
            logger.debug("로드셀 읽기 실패: %s", e)

        return self._simulate_load_cell()

    def _simulate_load_cell(self) -> LoadCellReading:
        """로드셀 시뮬레이션 / Simulate load cell data."""
        now = time.time()
        base_weight = 3.0 + 0.2 * math.sin((now - self._start_time) * 0.1)
        noise = np.random.normal(0, 0.01)
        return LoadCellReading(
            total_weight_kg=base_weight + noise,
            per_cell_kg={
                "fl": base_weight * 0.25 + noise * 0.5,
                "fr": base_weight * 0.25 - noise * 0.3,
                "rl": base_weight * 0.25 + noise * 0.2,
                "rr": base_weight * 0.25 - noise * 0.1,
            },
            cg_x_mm=5.0 * math.sin((now - self._start_time) * 0.05),
            cg_y_mm=-3.0 * math.cos((now - self._start_time) * 0.07),
            timestamp=now,
            is_valid=True,
        )

    # ── 참신함 점수 계산 / Novelty Score Computation ────────────────────

    def _compute_novelty_score(self, experience: PhysicalExperience) -> float:
        """
        참신함 점수 계산 / Compute novelty score.

        이전 경험과의 시그니처 비교를 통해 참신함을 평가합니다.
        완전히 새로운 경험: 1.0, 이전에 본 경험: 점진적 감소.

        Args:
            experience: 평가할 경험

        Returns:
            참신함 점수 (0~1)
        """
        # 경험 시그니처 생성 / Generate experience signature
        sig_parts = []
        sig_parts.append(experience.action_taken[:50])
        sig_parts.append(",".join(sorted(experience.modalities_present)))
        sig_parts.append(experience.outcome.value)

        # 센서 데이터 요약 추가 / Add sensor data summary
        for modality in sorted(experience.sensor_data.keys()):
            data = experience.sensor_data[modality]
            if isinstance(data, dict):
                # 주요 수치 값만 추가 / Add only key numeric values
                for key in sorted(list(data.keys())[:3]):
                    val = data[key]
                    if isinstance(val, (int, float)):
                        sig_parts.append(f"{modality}:{key}:{round(val, 1)}")

        signature = "|".join(sig_parts)

        count = self._experience_signature_counts.get(signature, 0)
        self._experience_signature_counts[signature] = count + 1

        # 빈도 기반 참신함 감소 / Frequency-based novelty decay
        if count == 0:
            return 1.0  # 완전히 새로움 / Completely new
        elif count < 3:
            return 0.8
        elif count < 10:
            return 0.5
        elif count < 50:
            return 0.3
        else:
            return 0.1  # 매우 익숙함 / Very familiar

    # ── 로봇 상태 스냅샷 / Robot State Snapshot ─────────────────────────

    def _get_robot_state_snapshot(self) -> Dict[str, Any]:
        """현재 로봇 상태 스냅샷 / Get current robot state snapshot."""
        return {
            "uptime_s": time.time() - self._start_time,
            "collection_cycles": self._collection_cycles,
            "total_experiences": self._total_experiences_collected,
            "buffer_size": len(self._buffer),
            "simulation_mode": self._simulation_mode,
        }

    # ── 메인 수집 주기 / Main Collection Cycle ──────────────────────────

    def collect_cycle(self) -> Dict[str, Any]:
        """
        물리적 경험 수집 주기 / Physical experience collection cycle.

        메인 루프에서 0.5Hz (2초마다)로 호출됩니다.
        모든 센서를 읽고, 융합하고, 품질 검사 후 저장합니다.

        main.py 사용 방식:
            result = self._physical_experience_pipeline.collect_cycle()
            self._physical_experience_count += result.get("experiences_collected", 0)

        Returns:
            수집 결과 딕셔너리:
            - experiences_collected: 수집된 경험 수
            - quality_score: 평균 품질 점수
            - modalities_active: 활성 모달리티 수
            - novelty_score: 참신함 점수
            - rejected: 거부된 경험 수
            - duration_s: 수집 소요 시간
        """
        if not self._initialized:
            logger.warning("파이프라인 미초기화 상태에서 collect_cycle 호출")
            return self._empty_result()

        cycle_start = time.time()
        self._collection_cycles += 1

        try:
            with self._lock:
                result = self._do_collect_cycle()
                result["duration_s"] = time.time() - cycle_start
                self._last_collect_time = time.time()
                return result

        except Exception as e:
            # 절대 메인 루프를 크래시시키지 않음 / Never crash the main loop
            logger.error("물리적 경험 수집 주기 오류: %s", e)
            return self._empty_result(error=str(e))

    def _do_collect_cycle(self) -> Dict[str, Any]:
        """
        실제 수집 로직 / Actual collection logic.

        (self._lock 내부에서 호출됨)
        """
        # 1. 모든 센서 판독 / Read all sensors
        imu = self._read_imu()
        tactile = self._read_tactile()
        force_torque = self._read_force_torque()
        joints = self._read_joints()
        vision = self._read_vision()
        audio = self._read_audio()
        load_cell = self._read_load_cell()

        # 2. 시간 동기화 / Time synchronization
        now = time.time()
        sensor_timestamps = {}
        if imu.is_valid:
            self._time_sync.update_offset("imu", imu.timestamp, now)
            sensor_timestamps["imu"] = imu.timestamp
        if tactile.is_valid:
            self._time_sync.update_offset("tactile", tactile.timestamp, now)
            sensor_timestamps["tactile"] = tactile.timestamp
        if force_torque.is_valid:
            self._time_sync.update_offset("force_torque", force_torque.timestamp, now)
            sensor_timestamps["force_torque"] = force_torque.timestamp
        if joints.is_valid:
            self._time_sync.update_offset("joints", joints.timestamp, now)
            sensor_timestamps["joints"] = joints.timestamp
        if vision.is_valid:
            self._time_sync.update_offset("vision", vision.timestamp, now)
            sensor_timestamps["vision"] = vision.timestamp
        if audio.is_valid:
            self._time_sync.update_offset("audio", audio.timestamp, now)
            sensor_timestamps["audio"] = audio.timestamp
        if load_cell.is_valid:
            self._time_sync.update_offset("load_cell", load_cell.timestamp, now)
            sensor_timestamps["load_cell"] = load_cell.timestamp

        # 3. 다중 모달 융합 / Multi-modal fusion
        sensor_data, modalities, confidence_map = self._multi_modal_fusion.fuse(
            imu=imu,
            tactile=tactile,
            force_torque=force_torque,
            joints=joints,
            vision=vision,
            audio=audio,
            load_cell=load_cell,
        )

        # 4. 경험 객체 생성 / Create experience object
        experience = PhysicalExperience(
            timestamp=now,
            sensor_data=sensor_data,
            action_taken=self._infer_action(imu, tactile, joints),
            outcome=ExperienceOutcome.NEUTRAL,  # 결과는 행동 완료 후 업데이트
            modalities_present=modalities,
            robot_state=self._get_robot_state_snapshot(),
            tags=self._generate_tags(imu, tactile, joints, vision, audio),
        )

        # 5. 참신함 점수 계산 / Compute novelty score
        experience.novelty_score = self._compute_novelty_score(experience)

        # 6. 품질 검사 / Quality check
        passed, reject_reason, quality_score = self._quality_checker.check_quality(experience)

        if not passed:
            self._total_experiences_rejected += 1
            logger.debug(
                "경험 거부: 사유=%s, 품질=%.3f, 모달리티=%s",
                reject_reason.value, quality_score, modalities,
            )
            return {
                "experiences_collected": 0,
                "quality_score": quality_score,
                "modalities_active": len(modalities),
                "novelty_score": experience.novelty_score,
                "rejected": 1,
                "reject_reason": reject_reason.value,
                "confidence_map": confidence_map,
            }

        # 7. 버퍼에 저장 / Store in buffer
        self._buffer.add(experience)
        self._total_experiences_collected += 1
        self._buffer_count_since_flush += 1

        # 8. 주기적 DB 플러시 / Periodic DB flush
        if self._buffer_count_since_flush >= FLUSH_INTERVAL:
            self._flush_to_db()
            self._buffer_count_since_flush = 0

        # 9. 결과 반환 / Return result
        result = {
            "experiences_collected": 1,
            "quality_score": quality_score,
            "modalities_active": len(modalities),
            "novelty_score": experience.novelty_score,
            "rejected": 0,
            "experience_id": experience.experience_id,
            "action_taken": experience.action_taken,
            "confidence_map": confidence_map,
            "sensor_data_keys": list(sensor_data.keys()),
        }

        logger.debug(
            "물리적 경험 수집: ID=%s, 품질=%.2f, 참신함=%.2f, 모달리티=%s",
            experience.experience_id[:12], quality_score,
            experience.novelty_score, modalities,
        )

        return result

    def _infer_action(self, imu: IMUReading, tactile: TactileReading, joints: JointState) -> str:
        """
        현재 행동 추론 / Infer current action from sensor data.

        센서 패턴을 기반으로 로봇이 수행 중인 행동을 추론합니다.
        """
        # IMU 움직임 분석 / IMU motion analysis
        accel_mag = float(np.linalg.norm(imu.linear_accel_g))
        gyro_mag = float(np.linalg.norm(imu.gyro_dps))

        # 관절 움직임 분석 / Joint motion analysis
        joint_vel_mag = float(np.mean(np.abs(joints.velocities_rad_s))) if len(joints.velocities_rad_s) > 0 else 0.0

        # 촉각 상태 / Tactile state
        is_grasping = tactile.combined_n > 3.0

        # 행동 분류 / Action classification
        if is_grasping and accel_mag > 0.5:
            return "grasp_and_lift"
        elif is_grasping:
            return "grasp_hold"
        elif gyro_mag > 30.0 and joint_vel_mag > 1.0:
            return "turning"
        elif accel_mag > 0.3 and joint_vel_mag > 0.5:
            return "walking"
        elif joint_vel_mag > 0.3:
            return "leg_adjustment"
        elif accel_mag < 0.1 and gyro_mag < 5.0:
            return "stationary"
        else:
            return "unknown_motion"

    def _generate_tags(
        self,
        imu: IMUReading,
        tactile: TactileReading,
        joints: JointState,
        vision: VisionReading,
        audio: AudioReading,
    ) -> List[str]:
        """경험 태그 자동 생성 / Auto-generate experience tags."""
        tags = []

        # 움직임 태그 / Motion tags
        accel_mag = float(np.linalg.norm(imu.linear_accel_g))
        if accel_mag > 0.5:
            tags.append("dynamic")
        else:
            tags.append("static")

        # 접촉 태그 / Contact tags
        if tactile.combined_n > 3.0:
            tags.append("grasping")
        elif tactile.combined_n > 1.0:
            tags.append("touching")

        # 보행 태그 / Locomotion tags
        if len(joints.velocities_rad_s) > 0:
            joint_vel_mag = float(np.mean(np.abs(joints.velocities_rad_s)))
            if joint_vel_mag > 1.0:
                tags.append("locomotion")

        # 환경 태그 / Environment tags
        if vision.scene_label:
            tags.append(f"scene:{vision.scene_label}")

        # 소리 태그 / Sound tags
        if audio.rms_level > 0.05:
            tags.append("noisy_environment")

        return tags

    # ── DB 영속성 / DB Persistence ──────────────────────────────────────

    def _flush_to_db(self) -> None:
        """버퍼의 경험을 DB에 플러시 / Flush experiences from buffer to DB."""
        if not self._db_conn:
            return

        try:
            experiences = self._buffer.get_all()
            count = 0
            for exp in experiences:
                try:
                    data = exp.to_dict()
                    self._db_conn.execute(
                        """INSERT OR REPLACE INTO physical_experiences
                           (experience_id, timestamp, sensor_data, action_taken,
                            outcome, modalities_present, quality_score, novelty_score,
                            duration_s, robot_state, context, tags)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            data["experience_id"],
                            data["timestamp"],
                            data["sensor_data"],
                            data["action_taken"],
                            data["outcome"],
                            data["modalities_present"],
                            data["quality_score"],
                            data["novelty_score"],
                            data["duration_s"],
                            data["robot_state"],
                            data["context"],
                            data["tags"],
                        ),
                    )
                    count += 1
                except Exception as e:
                    logger.error("경험 DB 저장 오류: %s", e)

            self._db_conn.commit()
            if count > 0:
                logger.debug("물리적 경험 DB 플러시: %d개 저장", count)

        except Exception as e:
            logger.error("DB 플러시 오류: %s", e)

    # ── 유틸리티 / Utilities ────────────────────────────────────────────

    def _empty_result(self, error: Optional[str] = None) -> Dict[str, Any]:
        """빈 결과 반환 / Return empty result (on error or not initialized)."""
        result = {
            "experiences_collected": 0,
            "quality_score": 0.0,
            "modalities_active": 0,
            "novelty_score": 0.0,
            "rejected": 0,
        }
        if error:
            result["error"] = error
        return result

    def get_stats(self) -> Dict[str, Any]:
        """
        파이프라인 통계 조회 / Get pipeline statistics.

        Returns:
            종합 통계 딕셔너리
        """
        uptime = time.time() - self._start_time if self._start_time > 0 else 0.0
        rate = self._total_experiences_collected / max(1.0, uptime) * 3600 if uptime > 0 else 0.0

        return {
            "initialized": self._initialized,
            "simulation_mode": self._simulation_mode,
            "uptime_s": uptime,
            "collection_cycles": self._collection_cycles,
            "total_collected": self._total_experiences_collected,
            "total_rejected": self._total_experiences_rejected,
            "acceptance_rate": (
                self._total_experiences_collected /
                max(1, self._total_experiences_collected + self._total_experiences_rejected)
            ),
            "experiences_per_hour": rate,
            "buffer_stats": self._buffer.get_stats(),
            "quality_stats": self._quality_checker.get_stats(),
            "fusion_stats": self._multi_modal_fusion.get_stats(),
            "timesync_stats": self._time_sync.get_stats(),
            "db_path": str(self._db_path),
        }

    def get_recent_experiences(self, limit: int = 10) -> List[PhysicalExperience]:
        """
        최근 경험 조회 / Get recent experiences.

        Args:
            limit: 최대 반환 수

        Returns:
            최근 경험 리스트 (시간 역순)
        """
        experiences = self._buffer.get_all()
        experiences.sort(key=lambda x: x.timestamp, reverse=True)
        return experiences[:limit]

    def get_novel_experiences(self, min_novelty: float = 0.7, limit: int = 20) -> List[PhysicalExperience]:
        """
        참신한 경험 조회 / Get novel experiences.

        Args:
            min_novelty: 최소 참신함 점수
            limit: 최대 반환 수

        Returns:
            참신한 경험 리스트
        """
        return self._buffer.get_novel(min_novelty=min_novelty, limit=limit)

    def update_experience_outcome(self, experience_id: str, outcome: ExperienceOutcome) -> bool:
        """
        경험 결과 업데이트 / Update experience outcome.

        행동 완료 후 결과를 업데이트합니다.

        Args:
            experience_id: 경험 ID
            outcome: 결과

        Returns:
            업데이트 성공 여부
        """
        with self._lock:
            for exp in self._buffer.get_all():
                if exp.experience_id == experience_id:
                    exp.outcome = outcome
                    return True
        return False

    def shutdown(self) -> None:
        """
        파이프라인 종료 / Shutdown pipeline.

        남은 버퍼를 DB에 플러시하고 연결을 정리합니다.
        """
        logger.info("물리적 경험 파이프라인 종료 중...")

        try:
            # 남은 데이터 플러시 / Flush remaining data
            self._flush_to_db()

            # DB 연결 종료 / Close DB connection
            if self._db_conn:
                self._db_conn.close()
                self._db_conn = None

            logger.info(
                "물리적 경험 파이프라인 종료 완료 "
                "(총 %d개 경험 수집, %d개 거부)",
                self._total_experiences_collected,
                self._total_experiences_rejected,
            )

        except Exception as e:
            logger.error("파이프라인 종료 오류: %s", e)


# ─── 모듈 진입점 / Module Entry Point ───────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format="[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    print("=" * 70)
    print("지훈 로봇 V8.5 — 물리적 경험 파이프라인 테스트")
    print("WORLD DATA = Physical Experience, NOT web crawling!")
    print("=" * 70)

    # 파이프라인 생성 / Create pipeline
    pipeline = PhysicalExperiencePipeline(
        db_path=Path("/tmp/test_physical_experiences.db"),
        buffer_size=100,
        simulation_mode=True,
    )

    # 초기화 / Initialize
    print(f"\n초기화: {pipeline.initialize()}")

    # 10회 수집 주기 시뮬레이션 / Simulate 10 collection cycles
    print("\n수집 주기 시뮬레이션 (10회):")
    total_collected = 0
    for i in range(10):
        result = pipeline.collect_cycle()
        total_collected += result.get("experiences_collected", 0)
        print(
            f"  주기 {i + 1}: 수집={result.get('experiences_collected', 0)}, "
            f"품질={result.get('quality_score', 0):.3f}, "
            f"참신함={result.get('novelty_score', 0):.3f}, "
            f"모달리티={result.get('modalities_active', 0)}"
        )
        time.sleep(0.1)  # 수집 간격 시뮬레이션

    # 통계 출력 / Print statistics
    stats = pipeline.get_stats()
    print(f"\n통계:")
    print(f"  총 수집: {stats['total_collected']}")
    print(f"  총 거부: {stats['total_rejected']}")
    print(f"  수용률: {stats['acceptance_rate']:.1%}")
    print(f"  버퍼: {stats['buffer_stats']['current_size']}/{stats['buffer_stats']['max_size']}")
    print(f"  품질 검사: {stats['quality_stats']['total_checked']}건 검사")

    # 참신한 경험 조회 / Get novel experiences
    novel = pipeline.get_novel_experiences(min_novelty=0.5, limit=5)
    print(f"\n참신한 경험 ({len(novel)}개):")
    for exp in novel:
        print(f"  {exp.experience_id}: 참신함={exp.novelty_score:.2f}, "
              f"행동={exp.action_taken}, 모달리티={exp.modalities_present}")

    # 종료 / Shutdown
    pipeline.shutdown()

    print("\n모든 테스트 완료 / All tests completed.")
