#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — YouTube 지식 추출기 (YouTube Knowledge Extractor)
==================================================================

YouTube 영상에서 로봇이 물리적 지식을 추출합니다.
이것이 바로 대기업이 할 수 없는 혁신입니다:

  - 대기업: 수백만 달러를 들여 데이터 수집 (로봇 100대로 반복 실험)
  - 우리: YouTube에 있는 무한한 인간 행동 영상에서 무료로 학습

일론 머스크의 혁신 원리:
  "기존 방식이 비싸면, 완전히 다른 방식을 찾아라"
  
  - 기존: 로봇으로 데이터 수집 → 비싸고 느림
  - 우리: YouTube 영상에서 학습 → 무료이고 빠름

작성자: 안지훈 (보성중학교 2학년 4반 10번)
버전: V8.5
"""

from __future__ import annotations

import json
import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger("jihun.v85.youtube_knowledge_extractor")
logger.setLevel(logging.DEBUG)


@dataclass
class ExtractedKnowledge:
    """추출된 지식"""
    knowledge_id: str = ""
    source_url: str = ""
    source_type: str = "youtube"       # youtube, vlm_analysis, manual
    domain: str = ""
    action_description: str = ""
    physical_principles: List[str] = field(default_factory=list)
    step_sequence: List[str] = field(default_factory=list)
    objects_involved: List[str] = field(default_factory=list)
    safety_notes: List[str] = field(default_factory=list)
    confidence: float = 0.0
    timestamp: float = field(default_factory=time.time)


class YouTubeKnowledgeExtractor:
    """
    YouTube 영상에서 로봇 지식 추출
    
    작동 원리:
    1. YouTube 영상 URL 입력
    2. VLM(비전 언어 모델)로 영상 프레임 분석
    3. 인간의 행동을 단계별로 추출
    4. 물리적 원리와 안전 규칙을 추론
    5. 로봇 실행 가능한 지식으로 변환
    
    예산: $0 (VLM은 Gemma 4 내장 비전 사용)
    """

    def __init__(
        self,
        gemma4_inference: Optional[Any] = None,
        vla_bridge: Optional[Any] = None,
    ):
        self._gemma4 = gemma4_inference
        self._vla = vla_bridge
        self._knowledge_db: Dict[str, ExtractedKnowledge] = {}
        self._lock = threading.Lock()

        logger.info("YouTubeKnowledgeExtractor V8.5 초기화 완료")

    def extract_from_video_description(
        self,
        video_url: str,
        video_description: str,
        task_domain: str = "general",
    ) -> List[ExtractedKnowledge]:
        """
        영상 설명으로부터 지식 추출
        
        실제로는 VLM으로 프레임을 분석하지만,
        여기서는 영상 설명/자막 텍스트를 기반으로 추출합니다.
        
        Args:
            video_url: YouTube 영상 URL
            video_description: 영상 설명 또는 자막 텍스트
            task_domain: 작업 도메인
            
        Returns:
            추출된 지식 목록
        """
        knowledge_list = []

        # AI 추론으로 영상 내용 분석
        if self._gemma4:
            try:
                analysis_prompt = (
                    f"다음은 로봇이 학습해야 할 영상의 설명입니다:\n\n"
                    f"{video_description[:2000]}\n\n"
                    f"이 영상에서 로봇이 학습할 수 있는 물리적 지식을 추출하세요.\n"
                    f"형식:\n"
                    f"1. 행동 설명: [무엇을 하는가]\n"
                    f"2. 물리적 원리: [어떤 물리적 원리가 적용되는가]\n"
                    f"3. 단계: [1단계, 2단계, ...]\n"
                    f"4. 관련 물체: [어떤 물체가 사용되는가]\n"
                    f"5. 안전 주의: [위험 요소는 무엇인가]"
                )
                result = self._gemma4.generate(analysis_prompt, max_tokens=1024, temperature=0.3)
                
                if result and result.text:
                    knowledge = self._parse_extracted_knowledge(
                        result.text, video_url, task_domain
                    )
                    if knowledge:
                        knowledge_list.append(knowledge)
                        with self._lock:
                            self._knowledge_db[knowledge.knowledge_id] = knowledge
                            
            except Exception as e:
                logger.debug(f"YouTube 지식 추출 실패: {e}")

        # AI 실패 시 기본 추출
        if not knowledge_list:
            knowledge = ExtractedKnowledge(
                source_url=video_url,
                source_type="youtube",
                domain=task_domain,
                action_description=video_description[:200],
                confidence=0.3,
            )
            knowledge_list.append(knowledge)

        logger.info(f"YouTube에서 {len(knowledge_list)}개 지식 추출: {video_url}")
        return knowledge_list

    def _parse_extracted_knowledge(
        self, ai_text: str, source_url: str, domain: str
    ) -> Optional[ExtractedKnowledge]:
        """AI 응답에서 지식 파싱"""
        knowledge = ExtractedKnowledge(
            knowledge_id=f"yt_{int(time.time())}",
            source_url=source_url,
            source_type="youtube",
            domain=domain,
        )

        lines = ai_text.strip().split("\n")
        current_section = ""

        for line in lines:
            line = line.strip()
            if "행동 설명" in line:
                current_section = "action"
                knowledge.action_description = line.split(":", 1)[-1].strip()
            elif "물리적 원리" in line:
                current_section = "principles"
            elif "단계" in line:
                current_section = "steps"
            elif "관련 물체" in line:
                current_section = "objects"
            elif "안전 주의" in line:
                current_section = "safety"
            elif line.startswith("-") or line.startswith("•"):
                item = line.lstrip("-• ").strip()
                if current_section == "principles":
                    knowledge.physical_principles.append(item)
                elif current_section == "steps":
                    knowledge.step_sequence.append(item)
                elif current_section == "objects":
                    knowledge.objects_involved.append(item)
                elif current_section == "safety":
                    knowledge.safety_notes.append(item)

        knowledge.confidence = min(1.0, 0.5 + len(knowledge.step_sequence) * 0.1)
        return knowledge

    def search_and_extract(
        self, task_description: str, max_videos: int = 3
    ) -> List[ExtractedKnowledge]:
        """
        작업 설명으로 관련 YouTube 영상을 검색하고 지식 추출
        
        실제 구현에서는 YouTube Data API를 사용하거나
        웹 검색으로 관련 영상을 찾습니다.
        """
        # 검색 쿼리 생성
        search_queries = [
            f"{task_description} 자막",
            f"{task_description} 요리 영상",
            f"how to {task_description} tutorial",
        ]

        all_knowledge = []

        # AI로 영상 내용 시뮬레이션 (실제 영상 없이도 학습)
        if self._gemma4:
            try:
                sim_prompt = (
                    f"'{task_description}' 작업을 수행하는 방법을 "
                    f"전문가의 시연을 보는 것처럼 상세히 설명하세요.\n"
                    f"로봇이 학습할 수 있는 물리적 지식을 포함하세요.\n"
                    f"안전 주의사항도 포함하세요."
                )
                result = self._gemma4.generate(sim_prompt, max_tokens=1024, temperature=0.5)
                
                if result and result.text:
                    knowledge = self._parse_extracted_knowledge(
                        result.text, f"simulated://{task_description}", "general"
                    )
                    if knowledge:
                        knowledge.source_type = "simulated"
                        all_knowledge.append(knowledge)
            except Exception:
                pass

        return all_knowledge

    def get_knowledge(self, domain: str = "") -> List[ExtractedKnowledge]:
        """저장된 지식 조회"""
        with self._lock:
            if domain:
                return [k for k in self._knowledge_db.values() if k.domain == domain]
            return list(self._knowledge_db.values())

    def get_statistics(self) -> Dict[str, Any]:
        """통계"""
        with self._lock:
            return {
                "total_knowledge": len(self._knowledge_db),
                "domains": list(set(k.domain for k in self._knowledge_db.values())),
            }
