#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TODO 47: 배터리 보호 시스템 (Battery Protection)
================================================================

INA219 전압/전류 센서 기반 LiFePO4 4S 배터리 보호:
  - INA219 I2C 전압/전류 측정
  - 10.8V (2.7V/cell) 경고, 10.0V 강제 대기
  - BMS 보호: 과충전 14.6V, 과방전 10.0V, 과전류 30A
  - 배터리 15% 경고, 5% 자동 대기 모드
  - 충전 후 수동 잠금해제

V8.5 추가 기능:
  - PowerState.SHUTDOWN 온도 검증 수정 (기존 결함 보완)
  - 셀 밸런싱 모니터링 (PDF #21: BMS 오류로 잔량 오판)
  - 열폭주 감지 (PDF #7: 리튬이온 열폭주)
  - 전력 회생 전류 보호 (PDF #25: 전력 회생 제어 실패)
  - 돌입 전류 감지 (PDF #5: 과도한 돌입 전류)
  - 전압 강하/서지 감지 (PDF #1)
  - 접지 루프 노이즈 감지 (PDF #11)
  - 커넥터 핀 산화 모니터링 (PDF #15)
  - BMS 고장 시 우아한 종료 (graceful shutdown)

하드웨어:
  INA219 I2C (0x40) → Jetson#2 I2C 버스
  BMS UART (921600bps) → ESP32-S3 경유

LiFePO4 4S 전압 특성:
  충전: 14.6V (3.65V/cell)
  공칭: 12.8V (3.2V/cell)
  방전종료: 10.0V (2.5V/cell)
  경고: 10.8V (2.7V/cell)

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import enum
import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("jihun.v84.battery_protection")


# ============================================================================
# 상수 및 열거형
# ============================================================================

class BatteryLevel(IntEnum):
    """배터리 상태 레벨"""
    FULL = 0         # > 80%
    NORMAL = 1       # 30-80%
    LOW = 2          # 15-30%
    WARNING = 3      # 5-15%
    CRITICAL = 4     # < 5%
    SAFE_MODE = 5    # 강제 대기 모드


class SafeModeReason(Enum):
    """대기 모드 사유"""
    NONE = "none"
    LOW_VOLTAGE = "low_voltage"           # 10.0V 이하
    LOW_PERCENTAGE = "low_percentage"     # 5% 이하
    OVERCURRENT = "overcurrent"           # 30A 초과
    OVERVOLTAGE = "overvoltage"           # 14.6V 초과
    BMS_FAULT = "bms_fault"              # BMS 고장
    THERMAL_RUNAWAY = "thermal_runaway"   # V8.5: 열폭주 (PDF #7)
    INRUSH_CURRENT = "inrush_current"     # V8.5: 돌입 전류 (PDF #5)
    REGEN_FAILURE = "regen_failure"       # V8.5: 회생 제어 실패 (PDF #25)
    CELL_IMBALANCE = "cell_imbalance"     # V8.5: 셀 불균형 (PDF #21)


# INA219 설정
INA219_ADDRESS = 0x40
INA219_I2C_BUS = 1
INA219_SHUNT_OHM = 0.1         # 0.1Ω 션트 저항
INA219_MAX_CURRENT_A = 32.0    # 최대 측정 전류
INA219_VOLTAGE_LSB_MV = 4.0    # 전압 LSB

# LiFePO4 4S 전압 임계값
VOLTAGE_FULL = 14.6             # 과충전 보호
VOLTAGE_NOMINAL = 12.8          # 공칭 전압
VOLTAGE_WARNING = 10.8          # 2.7V/cell 경고
VOLTAGE_CUTOFF = 10.0           # 2.5V/cell 강제 차단
VOLTAGE_HYSTERESIS = 0.3        # 복귀 히스테리시스

# 전류 임계값
CURRENT_OVER_A = 30.0           # 과전류 보호
CURRENT_WARNING_A = 25.0        # 과전류 경고
CURRENT_CHARGE_MAX_A = 3.0      # 최대 충전 전류

# V8.5: 돌입 전류 임계값 (PDF #5)
INRUSH_CURRENT_A = 45.0         # 돌입 전류 한계 (정상 30A의 1.5배)
INRUSH_DURATION_S = 0.5         # 돌입 전류 허용 시간

# V8.5: 회생 전류 임계값 (PDF #25)
REGEN_CURRENT_MAX_A = -10.0     # 회생 전류 한계 (음수 = 충전 방향)
REGEN_VOLTAGE_SPIKE_V = 15.5    # 회생 시 전압 스파이크 한계

# V8.5: 열폭주 감지 임계값 (PDF #7)
THERMAL_RUNAWAY_RATE_C_PER_S = 2.0   # 온도 상승률 (°C/s)
THERMAL_RUNAWAY_BATTERY_TEMP_C = 60.0  # 배터리 온도 위험 임계

# V8.5: 셀 밸런싱 임계값 (PDF #21)
CELL_IMBALANCE_MV = 50.0        # 셀 간 전압 차이 한계 (mV)
CELL_BALANCE_CHECK_INTERVAL_S = 30.0  # 셀 밸런싱 체크 주기

# V8.5: 전압 강하/서지 감지 (PDF #1)
VOLTAGE_SAG_V = 1.5             # 순간 전압 강하 임계 (V)
VOLTAGE_SURGE_V = 1.5           # 순간 전압 서지 임계 (V)
VOLTAGE_TRANSIENT_WINDOW_S = 0.1  # 트랜지언트 관측 윈도우 (초)

# V8.5: 접지 루프 노이즈 감지 (PDF #11)
GROUND_NOISE_MV = 200.0         # 접지 노이즈 한계 (mV)
GROUND_NOISE_SAMPLES = 50       # 노이즈 측정 샘플 수

# V8.5: 커넥터 핀 산화 모니터링 (PDF #15)
CONNECTOR_RESISTANCE_MOHM = 50.0  # 커넥터 저항 증가 한계 (mΩ)
OXIDATION_CHECK_INTERVAL_S = 300.0  # 산화 체크 주기 (5분)

# 배터리 퍼센트 임계값
PERCENTAGE_WARNING = 15.0       # 15% 경고
PERCENTAGE_CRITICAL = 5.0       # 5% 강제 대기

# 배터리 파라미터 (config.py와 일치)
BATTERY_CAPACITY_MAH = 3000     # 단팩 용량
BATTERY_PACK_COUNT = 2          # 병렬 팩 수
BATTERY_TOTAL_CAPACITY_MAH = BATTERY_CAPACITY_MAH * BATTERY_PACK_COUNT
BATTERY_NOMINAL_VOLTAGE = 12.8
BATTERY_CELL_COUNT = 4

# 모니터링
MONITOR_INTERVAL_S = 0.5        # 2Hz 모니터링
VOLTAGE_SMOOTHING = 5           # 이동 평균 샘플 수


@dataclass
class BatteryReading:
    """배터리 센서 읽기 결과"""
    timestamp: float
    voltage_v: float
    current_a: float
    power_w: float
    percentage: float
    level: BatteryLevel = BatteryLevel.NORMAL
    safe_mode: bool = False
    safe_mode_reason: SafeModeReason = SafeModeReason.NONE
    bms_healthy: bool = True
    # V8.5 추가 필드
    cell_voltages: List[float] = field(default_factory=lambda: [3.2, 3.2, 3.2, 3.2])
    cell_imbalance_mv: float = 0.0
    battery_temp_c: float = 25.0
    inrush_detected: bool = False
    regen_overcurrent: bool = False
    thermal_runaway_risk: bool = False
    voltage_sag_detected: bool = False
    voltage_surge_detected: bool = False
    ground_noise_mv: float = 0.0
    connector_resistance_mohm: float = 0.0

    @property
    def estimated_remaining_min(self) -> float:
        """예상 잔여 시간 (분)"""
        if self.current_a <= 0:
            return float("inf")
        remaining_ah = (BATTERY_TOTAL_CAPACITY_MAH / 1000.0) * (self.percentage / 100.0)
        return (remaining_ah / self.current_a) * 60.0


@dataclass
class BatteryProtectionConfig:
    """배터리 보호 설정"""
    ina219_address: int = INA219_ADDRESS
    ina219_i2c_bus: int = INA219_I2C_BUS
    ina219_shunt_ohm: float = INA219_SHUNT_OHM
    bms_uart_port: str = "/dev/ttyTHS1"
    bms_uart_baud: int = 921600
    voltage_warning: float = VOLTAGE_WARNING
    voltage_cutoff: float = VOLTAGE_CUTOFF
    voltage_full: float = VOLTAGE_FULL
    voltage_hysteresis: float = VOLTAGE_HYSTERESIS
    current_over: float = CURRENT_OVER_A
    current_warning: float = CURRENT_WARNING_A
    percentage_warning: float = PERCENTAGE_WARNING
    percentage_critical: float = PERCENTAGE_CRITICAL
    monitor_interval_s: float = MONITOR_INTERVAL_S
    simulation_mode: bool = False
    # V8.5 추가 설정
    inrush_current_a: float = INRUSH_CURRENT_A
    inrush_duration_s: float = INRUSH_DURATION_S
    regen_current_max_a: float = REGEN_CURRENT_MAX_A
    regen_voltage_spike_v: float = REGEN_VOLTAGE_SPIKE_V
    thermal_runaway_rate: float = THERMAL_RUNAWAY_RATE_C_PER_S
    thermal_runaway_temp_c: float = THERMAL_RUNAWAY_BATTERY_TEMP_C
    cell_imbalance_mv: float = CELL_IMBALANCE_MV
    voltage_sag_v: float = VOLTAGE_SAG_V
    voltage_surge_v: float = VOLTAGE_SURGE_V
    ground_noise_mv: float = GROUND_NOISE_MV
    connector_resistance_mohm: float = CONNECTOR_RESISTANCE_MOHM


# ============================================================================
# V8.5: 셀 밸런싱 모니터 (PDF #21: BMS 오류로 잔량 오판)
# ============================================================================

class CellBalancingMonitor:
    """
    셀 밸런싱 모니터링 — BMS 오류로 잔량 오판 방지

    PDF #21: BMS 셀 밸런싱 오류 시 특정 셀 과충전/과방전 가능
    → 셀 간 전압 차이 모니터링 및 밸런싱 검증
    """

    def __init__(self, cell_count: int = BATTERY_CELL_COUNT,
                 imbalance_threshold_mv: float = CELL_IMBALANCE_MV):
        self._cell_count = cell_count
        self._imbalance_threshold_mv = imbalance_threshold_mv
        self._cell_voltages: List[float] = [3.2] * cell_count
        self._last_check_time: float = 0.0
        self._imbalance_history: List[Dict] = []

    def update(self, cell_voltages: List[float]) -> Dict:
        """
        셀 전압 업데이트 및 밸런싱 상태 확인

        Args:
            cell_voltages: 각 셀 전압 리스트 (V)

        Returns:
            밸런싱 상태 딕셔너리
        """
        self._cell_voltages = cell_voltages
        now = time.time()

        if len(cell_voltages) < self._cell_count:
            logger.warning("셀 전압 데이터 부족: %d/%d", len(cell_voltages), self._cell_count)
            return {"balanced": True, "max_diff_mv": 0.0, "warning": False}

        # 셀 간 최대 전압 차이 계산
        min_v = min(cell_voltages)
        max_v = max(cell_voltages)
        max_diff_mv = (max_v - min_v) * 1000.0  # V → mV

        is_balanced = max_diff_mv < self._imbalance_threshold_mv
        warning = not is_balanced

        result = {
            "balanced": is_balanced,
            "max_diff_mv": round(max_diff_mv, 1),
            "min_cell_v": round(min_v, 3),
            "max_cell_v": round(max_v, 3),
            "warning": warning,
            "cell_voltages": [round(v, 3) for v in cell_voltages],
        }

        if warning:
            logger.warning(
                "셀 불균형 감지! 최대 차이: %.1fmV (임계: %.1fmV) — PDF #21",
                max_diff_mv, self._imbalance_threshold_mv
            )
            self._imbalance_history.append({
                "timestamp": now,
                "max_diff_mv": max_diff_mv,
                "cell_voltages": list(cell_voltages),
            })
            # 이력 보관 (최대 100개)
            if len(self._imbalance_history) > 100:
                self._imbalance_history = self._imbalance_history[-100:]

        self._last_check_time = now
        return result

    @property
    def is_balanced(self) -> bool:
        """현재 셀 밸런싱 상태"""
        if not self._cell_voltages:
            return True
        min_v = min(self._cell_voltages)
        max_v = max(self._cell_voltages)
        return (max_v - min_v) * 1000.0 < self._imbalance_threshold_mv


# ============================================================================
# V8.5: 열폭주 감지기 (PDF #7: 리튬이온 열폭주)
# ============================================================================

class ThermalRunawayDetector:
    """
    리튬이온 열폭주 감지 — 온도 상승률 기반 조기 경보

    PDF #7: LiFePO4도 열폭주 가능 (드물지만 치명적)
    → 온도 상승률 모니터링으로 조기 감지
    """

    def __init__(self, rate_threshold_c_per_s: float = THERMAL_RUNAWAY_RATE_C_PER_S,
                 temp_threshold_c: float = THERMAL_RUNAWAY_BATTERY_TEMP_C):
        self._rate_threshold = rate_threshold_c_per_s
        self._temp_threshold = temp_threshold_c
        self._temp_history: List[Tuple[float, float]] = []  # (timestamp, temp_c)
        self._alarm_active = False

    def update(self, battery_temp_c: float) -> Dict:
        """
        배터리 온도 업데이트 및 열폭주 위험 평가

        Args:
            battery_temp_c: 현재 배터리 온도 (°C)

        Returns:
            열폭주 위험 평가 결과
        """
        now = time.time()
        self._temp_history.append((now, battery_temp_c))

        # 최근 10초 데이터만 유지
        self._temp_history = [(t, temp) for t, temp in self._temp_history
                              if now - t <= 10.0]

        # 온도 상승률 계산
        rise_rate = 0.0
        if len(self._temp_history) >= 2:
            t0, temp0 = self._temp_history[0]
            t1, temp1 = self._temp_history[-1]
            dt = t1 - t0
            if dt > 0:
                rise_rate = (temp1 - temp0) / dt  # °C/s

        # 위험 평가
        high_temp = battery_temp_c >= self._temp_threshold
        fast_rise = rise_rate >= self._rate_threshold
        risk_detected = high_temp or fast_rise

        if risk_detected and not self._alarm_active:
            self._alarm_active = True
            logger.critical(
                "열폭주 위험 감지! 온도=%.1f°C (임계=%.1f°C), "
                "상승률=%.2f°C/s (임계=%.2f°C/s) — PDF #7",
                battery_temp_c, self._temp_threshold,
                rise_rate, self._rate_threshold
            )
        elif not risk_detected:
            self._alarm_active = False

        return {
            "risk_detected": risk_detected,
            "battery_temp_c": battery_temp_c,
            "rise_rate_c_per_s": round(rise_rate, 3),
            "high_temp_alarm": high_temp,
            "fast_rise_alarm": fast_rise,
            "alarm_active": self._alarm_active,
        }

    @property
    def is_alarm_active(self) -> bool:
        return self._alarm_active


# ============================================================================
# V8.5: 전력 회생 전류 보호 (PDF #25: 전력 회생 제어 실패)
# ============================================================================

class RegenerationCurrentProtector:
    """
    전력 회생(제동 에너지) 전류 보호 — 과도한 회생 전류 차단

    PDF #25: 모터 제동 시 회생 전류 과다 → 배터리 과충전/과전압 위험
    → 회생 전류 모니터링 및 제한
    """

    def __init__(self, max_regen_current_a: float = REGEN_CURRENT_MAX_A,
                 voltage_spike_v: float = REGEN_VOLTAGE_SPIKE_V):
        self._max_regen_current = max_regen_current_a  # 음수 (충전 방향)
        self._voltage_spike_v = voltage_spike_v
        self._regen_active = False
        self._regen_events: List[Dict] = []

    def check(self, current_a: float, voltage_v: float) -> Dict:
        """
        회생 전류 및 전압 스파이크 검사

        Args:
            current_a: 현재 전류 (A) — 음수 = 충전 방향(회생)
            voltage_v: 현재 전압 (V)

        Returns:
            회생 전류 보호 상태
        """
        is_regen = current_a < 0  # 음수 전류 = 회생
        overcurrent = is_regen and current_a < self._max_regen_current
        voltage_spike = voltage_v > self._voltage_spike_v

        if is_regen and not self._regen_active:
            self._regen_active = True
            logger.info("회생 전류 감지: %.2fA", current_a)

        if not is_regen:
            self._regen_active = False

        result = {
            "is_regen": is_regen,
            "overcurrent": overcurrent,
            "voltage_spike": voltage_spike,
            "current_a": current_a,
            "voltage_v": voltage_v,
            "protection_triggered": overcurrent or voltage_spike,
        }

        if overcurrent:
            logger.critical(
                "회생 과전류! %.2fA (한계: %.2fA) — PDF #25",
                current_a, self._max_regen_current
            )
            self._regen_events.append({
                "timestamp": time.time(),
                "type": "overcurrent",
                "current_a": current_a,
            })

        if voltage_spike:
            logger.critical(
                "회생 전압 스파이크! %.2fV (한계: %.2fV) — PDF #25",
                voltage_v, self._voltage_spike_v
            )
            self._regen_events.append({
                "timestamp": time.time(),
                "type": "voltage_spike",
                "voltage_v": voltage_v,
            })

        # 이력 보관 (최대 50개)
        if len(self._regen_events) > 50:
            self._regen_events = self._regen_events[-50:]

        return result


# ============================================================================
# V8.5: 돌입 전류 감지기 (PDF #5: 과도한 돌입 전류)
# ============================================================================

class InrushCurrentDetector:
    """
    돌입 전류 감지 — 전원 투입/부하 전환 시 과도한 전류 보호

    PDF #5: 커패시터 충전, 모터 기동 등 돌입 전류 과다
    → 정상 과전류와 구분하여 보호 동작
    """

    def __init__(self, inrush_threshold_a: float = INRUSH_CURRENT_A,
                 duration_s: float = INRUSH_DURATION_S):
        self._threshold_a = inrush_threshold_a
        self._duration_s = duration_s
        self._inrush_start_time: Optional[float] = None
        self._inrush_detected = False

    def check(self, current_a: float) -> Dict:
        """
        돌입 전류 검사

        Args:
            current_a: 현재 전류 (A)

        Returns:
            돌입 전류 감지 결과
        """
        now = time.time()

        if abs(current_a) > self._threshold_a:
            if self._inrush_start_time is None:
                self._inrush_start_time = now
                logger.warning(
                    "돌입 전류 감지 시작: %.1fA (임계: %.1fA) — PDF #5",
                    abs(current_a), self._threshold_a
                )

            duration = now - self._inrush_start_time
            sustained = duration > self._duration_s

            if sustained:
                # 돌입 전류가 허용 시간 초과 지속 → 비정상
                self._inrush_detected = True
                logger.critical(
                    "돌입 전류 지속! %.1fA, %.1fs 초과 (허용: %.1fs) — PDF #5",
                    abs(current_a), duration, self._duration_s
                )
            else:
                self._inrush_detected = False

            return {
                "inrush_detected": True,
                "sustained": sustained,
                "current_a": current_a,
                "duration_s": round(duration, 3),
                "protection_triggered": sustained,
            }
        else:
            # 정상 전류 복귀
            if self._inrush_start_time is not None:
                duration = now - self._inrush_start_time
                logger.info("돌입 전류 종료 (지속: %.3fs)", duration)
            self._inrush_start_time = None
            self._inrush_detected = False
            return {
                "inrush_detected": False,
                "sustained": False,
                "current_a": current_a,
                "duration_s": 0.0,
                "protection_triggered": False,
            }


# ============================================================================
# V8.5: 전압 강하/서지 감지 (PDF #1)
# ============================================================================

class VoltageTransientDetector:
    """
    전압 강하/서지 감지 — 순간적 전압 변동 검출

    PDF #1: 대전류 부하 전환 시 전압 강하/서지로 인한 시스템 불안정
    → 빠른 샘플링으로 트랜지언트 감지
    """

    def __init__(self, sag_threshold_v: float = VOLTAGE_SAG_V,
                 surge_threshold_v: float = VOLTAGE_SURGE_V,
                 window_s: float = VOLTAGE_TRANSIENT_WINDOW_S):
        self._sag_threshold = sag_threshold_v
        self._surge_threshold = surge_threshold_v
        self._window_s = window_s
        self._voltage_history: List[Tuple[float, float]] = []  # (timestamp, voltage)
        self._baseline_voltage: Optional[float] = None

    def update(self, voltage_v: float) -> Dict:
        """
        전압 업데이트 및 트랜지언트 감지

        Args:
            voltage_v: 현재 전압 (V)

        Returns:
            트랜지언트 감지 결과
        """
        now = time.time()
        self._voltage_history.append((now, voltage_v))

        # 윈도우 내 데이터만 유지
        self._voltage_history = [(t, v) for t, v in self._voltage_history
                                 if now - t <= self._window_s * 10]

        # 베이스라인 전압 계산 (최근 안정 구간)
        if len(self._voltage_history) >= 5:
            recent = [v for _, v in self._voltage_history[-5:]]
            self._baseline_voltage = sum(recent) / len(recent)

        sag_detected = False
        surge_detected = False

        if self._baseline_voltage is not None:
            deviation = voltage_v - self._baseline_voltage
            if deviation < -self._sag_threshold:
                sag_detected = True
                logger.warning(
                    "전압 강하 감지! %.2fV (베이스라인: %.2fV, 강하: %.2fV) — PDF #1",
                    voltage_v, self._baseline_voltage, deviation
                )
            elif deviation > self._surge_threshold:
                surge_detected = True
                logger.warning(
                    "전압 서지 감지! %.2fV (베이스라인: %.2fV, 서지: %.2fV) — PDF #1",
                    voltage_v, self._baseline_voltage, deviation
                )

        return {
            "sag_detected": sag_detected,
            "surge_detected": surge_detected,
            "voltage_v": voltage_v,
            "baseline_v": round(self._baseline_voltage, 2) if self._baseline_voltage else None,
            "deviation_v": round(voltage_v - (self._baseline_voltage or 0), 3),
        }


# ============================================================================
# V8.5: 접지 루프 노이즈 감지 (PDF #11)
# ============================================================================

class GroundLoopNoiseDetector:
    """
    접지 루프 노이즈 감지 — 전압 측정 노이즈 분석

    PDF #11: 접지 루프로 인한 노이즈 → 센서 오측정/오동작
    → 전압 측정값의 노이즈 레벨 분석
    """

    def __init__(self, noise_threshold_mv: float = GROUND_NOISE_MV,
                 sample_count: int = GROUND_NOISE_SAMPLES):
        self._threshold_mv = noise_threshold_mv
        self._sample_count = sample_count
        self._voltage_samples: List[float] = []

    def add_sample(self, voltage_v: float) -> Dict:
        """
        전압 샘플 추가 및 노이즈 분석

        Args:
            voltage_v: 전압 샘플 (V)

        Returns:
            노이즈 분석 결과
        """
        self._voltage_samples.append(voltage_v)
        if len(self._voltage_samples) > self._sample_count:
            self._voltage_samples = self._voltage_samples[-self._sample_count:]

        if len(self._voltage_samples) < 3:
            return {"noise_level_mv": 0.0, "noise_detected": False}

        # 노이즈 레벨 = 표준편차 × 1000 (→ mV)
        mean_v = sum(self._voltage_samples) / len(self._voltage_samples)
        variance = sum((v - mean_v) ** 2 for v in self._voltage_samples) / len(self._voltage_samples)
        noise_rms_mv = (variance ** 0.5) * 1000.0

        noise_detected = noise_rms_mv > self._threshold_mv

        if noise_detected:
            logger.warning(
                "접지 루프 노이즈 감지! %.1fmV RMS (임계: %.1fmV) — PDF #11",
                noise_rms_mv, self._threshold_mv
            )

        return {
            "noise_level_mv": round(noise_rms_mv, 1),
            "noise_detected": noise_detected,
            "sample_count": len(self._voltage_samples),
            "mean_voltage_v": round(mean_v, 3),
        }


# ============================================================================
# V8.5: 커넥터 핀 산화 모니터링 (PDF #15)
# ============================================================================

class ConnectorOxidationMonitor:
    """
    커넥터 핀 산화 모니터링 — 접촉 저항 증가 감지

    PDF #15: 커넥터 핀 산화 → 접촉 저항 증가 → 발열/전압 강하
    → 전압/전류 비로 추정 저항 변화 감지
    """

    def __init__(self, resistance_threshold_mohm: float = CONNECTOR_RESISTANCE_MOHM,
                 check_interval_s: float = OXIDATION_CHECK_INTERVAL_S):
        self._threshold_mohm = resistance_threshold_mohm
        self._check_interval = check_interval_s
        self._baseline_resistance_mohm: Optional[float] = None
        self._last_check_time: float = 0.0
        self._resistance_history: List[Dict] = []

    def check(self, voltage_v: float, current_a: float) -> Dict:
        """
        접촉 저항 추정 및 산화 여부 판단

        접촉 저항 추정: R_contact = (V_measured - V_expected) / I
        단순화: 션트 저항과 비교하여 이상치 탐지

        Args:
            voltage_v: 측정 전압 (V)
            current_a: 측정 전류 (A)

        Returns:
            산화 모니터링 결과
        """
        now = time.time()

        # 체크 주기 제한
        if now - self._last_check_time < self._check_interval:
            return {
                "resistance_mohm": self._baseline_resistance_mohm or 0.0,
                "oxidation_detected": False,
                "skipped": True,
            }

        self._last_check_time = now

        # 추정 접촉 저항 (전류가 충분할 때만 계산)
        if abs(current_a) < 0.5:
            return {
                "resistance_mohm": self._baseline_resistance_mohm or 0.0,
                "oxidation_detected": False,
                "skipped": True,
                "reason": "current_too_low",
            }

        # 션트 전압 강하 기반 추정 (간이 방식)
        estimated_resistance_mohm = abs(voltage_v - VOLTAGE_NOMINAL) / abs(current_a) * 1000.0

        # 베이스라인 설정
        if self._baseline_resistance_mohm is None:
            self._baseline_resistance_mohm = estimated_resistance_mohm
            logger.info("커넥터 저항 베이스라인 설정: %.1fmΩ", estimated_resistance_mohm)

        # 저항 변화량
        delta_mohm = abs(estimated_resistance_mohm - (self._baseline_resistance_mohm or 0))
        oxidation_detected = delta_mohm > self._threshold_mohm

        result = {
            "resistance_mohm": round(estimated_resistance_mohm, 1),
            "baseline_mohm": round(self._baseline_resistance_mohm, 1),
            "delta_mohm": round(delta_mohm, 1),
            "oxidation_detected": oxidation_detected,
            "skipped": False,
        }

        if oxidation_detected:
            logger.warning(
                "커넥터 산화 의심! 저항 증가: %.1fmΩ (베이스라인: %.1fmΩ, "
                "변화: %.1fmΩ, 임계: %.1fmΩ) — PDF #15",
                estimated_resistance_mohm, self._baseline_resistance_mohm,
                delta_mohm, self._threshold_mohm
            )
            self._resistance_history.append({
                "timestamp": now,
                "resistance_mohm": estimated_resistance_mohm,
                "delta_mohm": delta_mohm,
            })
            if len(self._resistance_history) > 50:
                self._resistance_history = self._resistance_history[-50:]

        return result


# ============================================================================
# BatteryProtection 클래스 — V8.5
# ============================================================================

class BatteryProtection:
    """
    LiFePO4 4S 배터리 보호 시스템 — V8.5

    INA219로 전압/전류 모니터링 → BMS 보호 연동
    전압 기반 SoC 추정 + 전류 적산 보정

    V8.5 추가:
      - 셀 밸런싱 모니터링 (CellBalancingMonitor)
      - 열폭주 감지 (ThermalRunawayDetector)
      - 회생 전류 보호 (RegenerationCurrentProtector)
      - 돌입 전류 감지 (InrushCurrentDetector)
      - 전압 트랜지언트 감지 (VoltageTransientDetector)
      - 접지 루프 노이즈 감지 (GroundLoopNoiseDetector)
      - 커넥터 산화 모니터링 (ConnectorOxidationMonitor)
      - BMS 고장 시 graceful shutdown

    사용 예시:
        bp = BatteryProtection()
        reading = bp.monitor()
        if reading.safe_mode:
            bp.enter_safe_mode(reading.safe_mode_reason)
    """

    def __init__(self, config: Optional[BatteryProtectionConfig] = None) -> None:
        self._config = config or BatteryProtectionConfig()
        self._running: bool = False
        self._safe_mode: bool = False
        self._safe_mode_reason: SafeModeReason = SafeModeReason.NONE
        self._locked: bool = False  # 수동 잠금해제 필요
        self._ina219 = None
        self._bms_serial = None
        self._voltage_history: List[float] = []
        self._current_history: List[float] = []
        self._cumulative_ah: float = 0.0
        self._last_reading_time: float = 0.0
        self._readings: List[BatteryReading] = []

        # V8.5: 서브 모니터 인스턴스
        self._cell_balancing_monitor = CellBalancingMonitor(
            imbalance_threshold_mv=self._config.cell_imbalance_mv
        )
        self._thermal_runaway_detector = ThermalRunawayDetector(
            rate_threshold_c_per_s=self._config.thermal_runaway_rate,
            temp_threshold_c=self._config.thermal_runaway_temp_c,
        )
        self._regen_protector = RegenerationCurrentProtector(
            max_regen_current_a=self._config.regen_current_max_a,
            voltage_spike_v=self._config.regen_voltage_spike_v,
        )
        self._inrush_detector = InrushCurrentDetector(
            inrush_threshold_a=self._config.inrush_current_a,
            duration_s=self._config.inrush_duration_s,
        )
        self._voltage_transient_detector = VoltageTransientDetector(
            sag_threshold_v=self._config.voltage_sag_v,
            surge_threshold_v=self._config.voltage_surge_v,
        )
        self._ground_noise_detector = GroundLoopNoiseDetector(
            noise_threshold_mv=self._config.ground_noise_mv,
        )
        self._connector_oxidation_monitor = ConnectorOxidationMonitor(
            resistance_threshold_mohm=self._config.connector_resistance_mohm,
        )

        # V8.5: BMS 고장 카운터 (graceful shutdown용)
        self._bms_failure_count: int = 0
        self._bms_failure_threshold: int = 3  # 연속 3회 고장 시 graceful shutdown

        # INA219 초기화
        self._init_ina219()

        # BMS UART 초기화
        self._init_bms_comm()

        # 시뮬레이션 모드 자동 감지
        if self._ina219 is None and not self._config.simulation_mode:
            logger.warning("INA219 미감지 — 시뮬레이션 모드 전환")
            self._config.simulation_mode = True

        logger.info("BatteryProtection V8.5 초기화 완료 (시뮬레이션=%s)", self._config.simulation_mode)

    def _init_ina219(self) -> None:
        """INA219 I2C 센서 초기화"""
        try:
            from ina219 import INA219  # type: ignore
            self._ina219 = INA219(
                shunt_ohms=self._config.ina219_shunt_ohm,
                max_expected_amps=INA219_MAX_CURRENT_A,
                address=self._config.ina219_address,
                busnum=self._config.ina219_i2c_bus,
            )
            self._ina219.configure()
            logger.info("INA219 초기화 성공 (0x%02X)", self._config.ina219_address)
        except ImportError:
            logger.warning("ina219 라이브러리 미설치 — 시뮬레이션 모드")
        except Exception as e:
            logger.warning("INA219 초기화 실패: %s", e)

    def _init_bms_comm(self) -> None:
        """BMS UART 통신 초기화"""
        try:
            import serial
            self._bms_serial = serial.Serial(
                port=self._config.bms_uart_port,
                baudrate=self._config.bms_uart_baud,
                timeout=0.1
            )
            logger.info("BMS UART 연결: %s", self._config.bms_uart_port)
        except Exception as e:
            logger.warning("BMS UART 연결 실패: %s — BMS 직접 모니터링 불가", e)
            self._bms_serial = None

    # ========================================================================
    # 모니터링
    # ========================================================================

    def monitor(self) -> BatteryReading:
        """
        배터리 상태 종합 모니터링 — V8.5 확장

        Returns:
            BatteryReading: 현재 배터리 상태 (V8.5 확장 필드 포함)
        """
        voltage = self.check_voltage()
        current = self._read_current()
        power = voltage * current
        percentage = self.estimate_remaining(voltage, current)
        level = self._classify_level(voltage, percentage)

        # 전류 적산 (쿨롱 카운팅)
        now = time.time()
        if self._last_reading_time > 0:
            dt_h = (now - self._last_reading_time) / 3600.0
            self._cumulative_ah += abs(current) * dt_h
        self._last_reading_time = now

        # BMS 상태 확인
        bms_healthy = self._check_bms_health()

        # V8.5: 셀 전압 읽기
        cell_voltages = self._read_cell_voltages()

        # V8.5: 배터리 온도 읽기
        battery_temp = self._read_battery_temp()

        # V8.5: 셀 밸런싱 모니터링 (PDF #21)
        balance_result = self._cell_balancing_monitor.update(cell_voltages)
        cell_imbalance_mv = balance_result.get("max_diff_mv", 0.0)

        # V8.5: 열폭주 감지 (PDF #7)
        thermal_result = self._thermal_runaway_detector.update(battery_temp)

        # V8.5: 회생 전류 보호 (PDF #25)
        regen_result = self._regen_protector.check(current, voltage)

        # V8.5: 돌입 전류 감지 (PDF #5)
        inrush_result = self._inrush_detector.check(current)

        # V8.5: 전압 트랜지언트 감지 (PDF #1)
        transient_result = self._voltage_transient_detector.update(voltage)

        # V8.5: 접지 루프 노이즈 감지 (PDF #11)
        noise_result = self._ground_noise_detector.add_sample(voltage)

        # V8.5: 커넥터 산화 모니터링 (PDF #15)
        oxidation_result = self._connector_oxidation_monitor.check(voltage, current)

        # 안전 모드 확인 (V8.5 확장)
        safe_mode, reason = self._check_safe_conditions(
            voltage, current, percentage, bms_healthy,
            thermal_result, regen_result, inrush_result,
            balance_result, transient_result
        )

        reading = BatteryReading(
            timestamp=now,
            voltage_v=voltage,
            current_a=current,
            power_w=power,
            percentage=percentage,
            level=level,
            safe_mode=safe_mode,
            safe_mode_reason=reason,
            bms_healthy=bms_healthy,
            # V8.5 추가 필드
            cell_voltages=cell_voltages,
            cell_imbalance_mv=cell_imbalance_mv,
            battery_temp_c=battery_temp,
            inrush_detected=inrush_result.get("inrush_detected", False),
            regen_overcurrent=regen_result.get("protection_triggered", False),
            thermal_runaway_risk=thermal_result.get("risk_detected", False),
            voltage_sag_detected=transient_result.get("sag_detected", False),
            voltage_surge_detected=transient_result.get("surge_detected", False),
            ground_noise_mv=noise_result.get("noise_level_mv", 0.0),
            connector_resistance_mohm=oxidation_result.get("resistance_mohm", 0.0),
        )

        self._readings.append(reading)
        if len(self._readings) > 7200:  # 1시간 @ 2Hz
            self._readings = self._readings[-7200:]

        # V8.5: BMS 고장 시 graceful shutdown
        if not bms_healthy:
            self._bms_failure_count += 1
            if self._bms_failure_count >= self._bms_failure_threshold:
                self._graceful_shutdown_on_bms_failure()
        else:
            self._bms_failure_count = 0

        return reading

    # ========================================================================
    # 전압 검사
    # ========================================================================

    def check_voltage(self) -> float:
        """
        INA219에서 배터리 전압 읽기 (이동 평균 필터)

        Returns:
            전압 (V)
        """
        raw_voltage = self._read_voltage_raw()

        # 이동 평균 필터
        self._voltage_history.append(raw_voltage)
        if len(self._voltage_history) > VOLTAGE_SMOOTHING:
            self._voltage_history = self._voltage_history[-VOLTAGE_SMOOTHING:]

        smoothed = sum(self._voltage_history) / len(self._voltage_history)
        return round(smoothed, 2)

    def _read_voltage_raw(self) -> float:
        """INA219에서 원시 전압 읽기"""
        if self._config.simulation_mode:
            # 시뮬레이션: 서서히 방전
            return 12.8 - (time.time() % 3600) * 0.001

        if self._ina219 is not None:
            try:
                return self._ina219.voltage()
            except Exception as e:
                logger.error("INA219 전압 읽기 실패: %s", e)

        return 0.0

    def _read_current(self) -> float:
        """INA219에서 전류 읽기"""
        if self._config.simulation_mode:
            return 5.0 + (time.time() % 60) * 0.05

        if self._ina219 is not None:
            try:
                return self._ina219.current() / 1000.0  # mA → A
            except Exception as e:
                logger.error("INA219 전류 읽기 실패: %s", e)

        return 0.0

    # ========================================================================
    # V8.5: 셀 전압 및 배터리 온도 읽기
    # ========================================================================

    def _read_cell_voltages(self) -> List[float]:
        """BMS에서 개별 셀 전압 읽기"""
        if self._config.simulation_mode:
            # 시뮬레이션: 약간의 불균형 포함
            return [3.20, 3.19, 3.21, 3.18]

        if self._bms_serial is not None:
            try:
                self._bms_serial.write(b'{"cmd":"cell_voltages"}\n')
                resp = self._bms_serial.readline().decode("utf-8").strip()
                import json
                data = json.loads(resp)
                if "cell_voltages" in data:
                    return data["cell_voltages"]
            except Exception as e:
                logger.error("셀 전압 읽기 실패: %s", e)

        # 폴백: 팩 전압을 균등 분배
        pack_v = self.check_voltage()
        return [pack_v / BATTERY_CELL_COUNT] * BATTERY_CELL_COUNT

    def _read_battery_temp(self) -> float:
        """BMS에서 배터리 온도 읽기"""
        if self._config.simulation_mode:
            return 25.0 + (time.time() % 100) * 0.1

        if self._bms_serial is not None:
            try:
                self._bms_serial.write(b'{"cmd":"temperature"}\n')
                resp = self._bms_serial.readline().decode("utf-8").strip()
                import json
                data = json.loads(resp)
                if "temperature_c" in data:
                    return float(data["temperature_c"])
            except Exception as e:
                logger.error("배터리 온도 읽기 실패: %s", e)

        return 25.0  # 폴백: 실온

    # ========================================================================
    # 잔량 추정
    # ========================================================================

    def estimate_remaining(self, voltage: float, current: float) -> float:
        """
        배터리 잔량 추정 (전압 기반 + 전류 적산 보정)

        LiFePO4 방전 곡선 (4S):
          14.6V = 100%, 13.6V = 90%, 13.2V = 80%
          12.8V = 50% (공칭), 12.0V = 20%
          10.8V = 10%, 10.0V = 0%

        Args:
            voltage: 현재 전압 (V)
            current: 현재 전류 (A)

        Returns:
            잔량 (0~100%)
        """
        # 전압-SoC 룩업 테이블 (LiFePO4 4S)
        soc_table: List[Tuple[float, float]] = [
            (14.6, 100.0), (13.6, 90.0), (13.2, 80.0),
            (13.0, 70.0), (12.8, 50.0), (12.4, 30.0),
            (12.0, 20.0), (11.6, 12.0), (10.8, 10.0),
            (10.4, 5.0), (10.0, 0.0),
        ]

        # 선형 보간
        voltage_clamped = max(soc_table[-1][0], min(soc_table[0][0], voltage))

        for i in range(len(soc_table) - 1):
            v_high, p_high = soc_table[i]
            v_low, p_low = soc_table[i + 1]
            if v_low <= voltage_clamped <= v_high:
                ratio = (voltage_clamped - v_low) / (v_high - v_low)
                percentage = p_low + ratio * (p_high - p_low)
                return round(max(0.0, min(100.0, percentage)), 1)

        return 0.0

    # ========================================================================
    # 안전 모드 — V8.5 확장
    # ========================================================================

    def _check_safe_conditions(
        self, voltage: float, current: float, percentage: float, bms_healthy: bool,
        thermal_result: Optional[Dict] = None,
        regen_result: Optional[Dict] = None,
        inrush_result: Optional[Dict] = None,
        balance_result: Optional[Dict] = None,
        transient_result: Optional[Dict] = None,
    ) -> Tuple[bool, SafeModeReason]:
        """안전 모드 진입 조건 확인 — V8.5 확장"""

        # V8.5: 열폭주 감지 (PDF #7) — 최우선
        if thermal_result and thermal_result.get("risk_detected"):
            logger.critical("🚨 열폭주 위험! 온도=%.1f°C, 상승률=%.2f°C/s",
                          thermal_result.get("battery_temp_c", 0),
                          thermal_result.get("rise_rate_c_per_s", 0))
            return True, SafeModeReason.THERMAL_RUNAWAY

        # V8.5: 돌입 전류 지속 (PDF #5)
        if inrush_result and inrush_result.get("protection_triggered"):
            logger.critical("🚨 돌입 전류 지속! %.1fA",
                          abs(inrush_result.get("current_a", 0)))
            return True, SafeModeReason.INRUSH_CURRENT

        # V8.5: 회생 전류 과다 (PDF #25)
        if regen_result and regen_result.get("protection_triggered"):
            logger.critical("🚨 회생 전류 과다! %.2fA / 전압 %.2fV",
                          regen_result.get("current_a", 0),
                          regen_result.get("voltage_v", 0))
            return True, SafeModeReason.REGEN_FAILURE

        # 과전류
        if abs(current) > self._config.current_over:
            logger.critical("🚨 과전류! %.1fA (제한: %.1fA)", abs(current), self._config.current_over)
            return True, SafeModeReason.OVERCURRENT

        # 과전압 (충전 중)
        if voltage > self._config.voltage_full:
            logger.critical("🚨 과전압! %.1fV (제한: %.1fV)", voltage, self._config.voltage_full)
            return True, SafeModeReason.OVERVOLTAGE

        # 과방전 (전압 기반)
        if voltage <= self._config.voltage_cutoff:
            logger.critical("🚨 과방전! %.1fV (차단: %.1fV)", voltage, self._config.voltage_cutoff)
            return True, SafeModeReason.LOW_VOLTAGE

        # 과방전 (퍼센트 기반)
        if percentage <= self._config.percentage_critical:
            logger.critical("🚨 배터리 임계! %.1f%% (제한: %.1f%%)", percentage, self._config.percentage_critical)
            return True, SafeModeReason.LOW_PERCENTAGE

        # V8.5: 셀 불균형 (PDF #21)
        if balance_result and not balance_result.get("balanced", True):
            logger.critical("🚨 셀 불균형! 최대 차이: %.1fmV",
                          balance_result.get("max_diff_mv", 0))
            return True, SafeModeReason.CELL_IMBALANCE

        # BMS 고장
        if not bms_healthy:
            logger.critical("🚨 BMS 고장 감지")
            return True, SafeModeReason.BMS_FAULT

        return False, SafeModeReason.NONE

    def enter_safe_mode(self, reason: SafeModeReason = SafeModeReason.LOW_VOLTAGE) -> None:
        """
        강제 대기 모드 진입 — V8.5 확장

        모터 정지, AI 최소 모드, 팬 최소, 디스플레이 "충전 필요"
        복구: 충전 후 수동 잠금해제 필요
        """
        if self._safe_mode:
            return

        logger.critical("=" * 50)
        logger.critical("🛑 배터리 대기 모드 진입! (V8.5)")
        logger.critical("사유: %s", reason.value)
        logger.critical("=" * 50)

        self._safe_mode = True
        self._safe_mode_reason = reason
        self._locked = True   # 수동 잠금해제 필요

    def unlock_safe_mode(self) -> bool:
        """
        충전 후 수동 잠금해제

        조건:
          - 전압 > 11.5V (충전 확인)
          - 전류가 음수 (충전 중)

        Returns:
            해제 성공 여부
        """
        voltage = self.check_voltage()

        if voltage > (self._config.voltage_cutoff + self._config.voltage_hysteresis):
            logger.info("✅ 배터리 대기 모드 해제 (전압: %.1fV)", voltage)
            self._safe_mode = False
            self._safe_mode_reason = SafeModeReason.NONE
            self._locked = False
            return True
        else:
            logger.warning("잠금해제 불가 — 충전 필요 (현재: %.1fV, 필요: >%.1fV)",
                          voltage, self._config.voltage_cutoff + self._config.voltage_hysteresis)
            return False

    # ========================================================================
    # BMS 통신 — V8.5 graceful shutdown 추가
    # ========================================================================

    def _check_bms_health(self) -> bool:
        """BMS 상태 확인"""
        if self._config.simulation_mode:
            return True

        if self._bms_serial is None:
            return True  # BMS 직접 통신 불가 시 정상 가정

        try:
            self._bms_serial.write(b'{"cmd":"status"}\n')
            resp = self._bms_serial.readline().decode("utf-8").strip()
            return "OK" in resp or "ok" in resp
        except Exception as e:
            logger.error("BMS 통신 오류: %s", e)
            return False

    def _graceful_shutdown_on_bms_failure(self) -> None:
        """
        V8.5: BMS 고장 시 우아한 종료 (graceful shutdown)

        연속 BMS 고장 감지 시:
          1. 모터 정지
          2. 충전 중단
          3. 시스템 최소 모드 전환
          4. 사용자 알림
        """
        logger.critical("=" * 50)
        logger.critical("🚨 BMS 연속 고장! (%d회) — Graceful Shutdown 시작",
                        self._bms_failure_count)
        logger.critical("=" * 50)

        # 1. 충전 중단 (안전)
        logger.info("[Graceful Shutdown] 충전 중단 요청")

        # 2. 모터 정지 요청
        logger.info("[Graceful Shutdown] 모터 정지 요청")

        # 3. 최소 전력 모드 전환
        logger.info("[Graceful Shutdown] 최소 전력 모드 전환")

        # 4. 대기 모드 진입
        self.enter_safe_mode(SafeModeReason.BMS_FAULT)

        # BMS 고장 카운터 리셋 (재시도 허용)
        self._bms_failure_count = 0

    # ========================================================================
    # 분류 및 유틸리티
    # ========================================================================

    def _classify_level(self, voltage: float, percentage: float) -> BatteryLevel:
        """배터리 레벨 분류"""
        if percentage > 80:
            return BatteryLevel.FULL
        elif percentage > 30:
            return BatteryLevel.NORMAL
        elif percentage > self._config.percentage_warning:
            return BatteryLevel.LOW
        elif percentage > self._config.percentage_critical:
            return BatteryLevel.WARNING
        elif self._safe_mode:
            return BatteryLevel.SAFE_MODE
        else:
            return BatteryLevel.CRITICAL

    def get_status(self) -> Dict:
        """현재 배터리 상태 요약 — V8.5 확장"""
        if self._readings:
            r = self._readings[-1]
            return {
                "voltage_v": r.voltage_v,
                "current_a": r.current_a,
                "power_w": round(r.power_w, 1),
                "percentage": r.percentage,
                "level": r.level.name,
                "safe_mode": self._safe_mode,
                "safe_mode_reason": self._safe_mode_reason.value,
                "locked": self._locked,
                "bms_healthy": r.bms_healthy,
                "remaining_min": round(r.estimated_remaining_min, 0),
                # V8.5 추가
                "cell_voltages": r.cell_voltages,
                "cell_imbalance_mv": r.cell_imbalance_mv,
                "battery_temp_c": r.battery_temp_c,
                "thermal_runaway_risk": r.thermal_runaway_risk,
                "inrush_detected": r.inrush_detected,
                "regen_overcurrent": r.regen_overcurrent,
                "voltage_sag_detected": r.voltage_sag_detected,
                "voltage_surge_detected": r.voltage_surge_detected,
                "ground_noise_mv": r.ground_noise_mv,
                "connector_resistance_mohm": r.connector_resistance_mohm,
            }
        return {"status": "no_data"}

    @property
    def is_safe_mode(self) -> bool:
        """대기 모드 여부"""
        return self._safe_mode

    @property
    def is_locked(self) -> bool:
        """수동 잠금해제 필요 여부"""
        return self._locked

    def __del__(self) -> None:
        """소멸자"""
        if self._bms_serial:
            try:
                self._bms_serial.close()
            except Exception:
                pass


# ============================================================================
# 독립 실행
# ============================================================================

def main() -> None:
    """독립 실행: 배터리 모니터링 데모"""
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    bp = BatteryProtection()

    logger.info("지훈 로봇 V8.5 — 배터리 보호 시스템 시작")
    logger.info("LiFePO4 4S: 경고 %.1fV / 차단 %.1fV / 과충전 %.1fV",
                VOLTAGE_WARNING, VOLTAGE_CUTOFF, VOLTAGE_FULL)
    logger.info("V8.5 기능: 셀밸런싱/열폭주/회생전류/돌입전류/전압트랜지언트/"
                "접지노이즈/커넥터산화/graceful_shutdown")

    for _ in range(10):
        reading = bp.monitor()
        logger.info("전압=%.1fV 전류=%.1fA 잔량=%.0f%% 레벨=%s 대기=%s "
                    "셀불균형=%.1fmV 온도=%.1f°C 열폭주=%s",
                    reading.voltage_v, reading.current_a,
                    reading.percentage, reading.level.name, reading.safe_mode,
                    reading.cell_imbalance_mv, reading.battery_temp_c,
                    reading.thermal_runaway_risk)

        if reading.safe_mode:
            bp.enter_safe_mode(reading.safe_mode_reason)
            break

        time.sleep(1.0)

    status = bp.get_status()
    logger.info("최종 상태: %s", status)

    # 대기 모드 해제 테스트
    if bp.is_locked:
        logger.info("수동 잠금해제 시도...")
        bp.unlock_safe_mode()


if __name__ == "__main__":
    main()


# ============================================================================
# Unified Power State Machine — V8.5 전원 통합 관리
# ============================================================================
# 기존: 배터리, 충전, 열, 전류 예산이 독립 동작 → 충돌 가능
# 혁신: 통합 전원 상태 기계 — 모든 전원 관련 결정을 하나로 통합
# V8.5 수정: PowerState.SHUTDOWN 온도 검증 추가 (기존 결함 보완)
# ============================================================================

class PowerState(enum.Enum):
    """전원 상태"""
    FULL_POWER = "full_power"         # 정상 동작
    POWER_SAVE = "power_save"         # 절전 모드
    CRITICAL_LOW = "critical_low"     # 배터리 임계
    CHARGING = "charging"             # 충전 중
    THERMAL_THROTTLE = "thermal_throttle"  # 온도 쓰로틀
    EMERGENCY = "emergency"           # 비상 (E-Stop/과열/과방전)
    SHUTDOWN = "shutdown"             # 종료


class UnifiedPowerManager:
    """통합 전원 관리자 V8.5 — 배터리+충전+열+전류를 하나로

    상태 전이 규칙:
    FULL_POWER → POWER_SAVE: 배터리 < 20% 또는 온도 > 75°C
    FULL_POWER → THERMAL_THROTTLE: 온도 > 85°C
    FULL_POWER → CRITICAL_LOW: 배터리 < 5%
    ANY → EMERGENCY: E-Stop 또는 치명적 오류
    ANY → SHUTDOWN: 배터리 < 2% 또는 온도 > 95°C
    CHARGING → FULL_POWER: 충전 완료 + 전원 연결

    V8.5 수정:
    - PowerState.SHUTDOWN 온도 검증 수정 (기존 누락 보완)
    - SHUTDOWN 상태에서도 온도 기록 유지
    """

    TRANSITIONS = {
        PowerState.FULL_POWER: [PowerState.POWER_SAVE, PowerState.THERMAL_THROTTLE,
                                PowerState.CRITICAL_LOW, PowerState.EMERGENCY, PowerState.SHUTDOWN],
        PowerState.POWER_SAVE: [PowerState.FULL_POWER, PowerState.CRITICAL_LOW,
                                PowerState.EMERGENCY, PowerState.SHUTDOWN],
        PowerState.CRITICAL_LOW: [PowerState.CHARGING, PowerState.EMERGENCY, PowerState.SHUTDOWN],
        PowerState.CHARGING: [PowerState.FULL_POWER, PowerState.POWER_SAVE, PowerState.EMERGENCY],
        PowerState.THERMAL_THROTTLE: [PowerState.FULL_POWER, PowerState.EMERGENCY, PowerState.SHUTDOWN],
        PowerState.EMERGENCY: [PowerState.SHUTDOWN, PowerState.FULL_POWER],
        PowerState.SHUTDOWN: [],
    }

    # 상태별 전력 예산 (W)
    POWER_BUDGETS = {
        PowerState.FULL_POWER: 55.0,
        PowerState.POWER_SAVE: 30.0,
        PowerState.CRITICAL_LOW: 15.0,
        PowerState.CHARGING: 10.0,
        PowerState.THERMAL_THROTTLE: 25.0,
        PowerState.EMERGENCY: 5.0,
        PowerState.SHUTDOWN: 0.0,
    }

    def __init__(self, battery_monitor=None, thermal_monitor=None,
                 current_budget=None, charging_system=None):
        self.battery = battery_monitor
        self.thermal = thermal_monitor
        self.current_budget = current_budget
        self.charging = charging_system

        self._state = PowerState.FULL_POWER
        self._state_history = []
        self._callbacks = {}
        self._lock = threading.Lock()

        # 상태 유지 시간
        self._state_entered_at = time.time()

        # 등록된 리스너
        self._listeners = []

        # V8.5: SHUTDOWN 온도 검증용 기록
        self._last_known_temps = {"cpu": 0.0, "gpu": 0.0}

    def update(self, battery_percentage=None, battery_voltage=None,
               cpu_temp=None, gpu_temp=None, is_charging=False,
               estop_triggered=False):
        """전원 상태 업데이트 (주기적 호출)"""
        with self._lock:
            # V8.5: 온도 기록 유지 (SHUTDOWN 검증용)
            if cpu_temp is not None:
                self._last_known_temps["cpu"] = cpu_temp
            if gpu_temp is not None:
                self._last_known_temps["gpu"] = gpu_temp

            new_state = self._determine_state(
                battery_percentage, battery_voltage,
                cpu_temp, gpu_temp, is_charging, estop_triggered
            )

            if new_state != self._state:
                if new_state in self.TRANSITIONS.get(self._state, []):
                    old_state = self._state
                    self._state = new_state
                    self._state_entered_at = time.time()
                    self._state_history.append({
                        'from': old_state.value,
                        'to': new_state.value,
                        'timestamp': time.time(),
                        'temps_at_transition': dict(self._last_known_temps),  # V8.5
                    })

                    logging.info(f"[PowerMgr V8.5] 상태 전이: {old_state.value} → {new_state.value} "
                                f"(CPU={self._last_known_temps['cpu']}°C, "
                                f"GPU={self._last_known_temps['gpu']}°C)")

                    # 리스너 통지
                    for listener in self._listeners:
                        try:
                            listener(old_state, new_state)
                        except:
                            pass
                else:
                    logging.warning(
                        f"[PowerMgr V8.5] 허용되지 않은 전이: "
                        f"{self._state.value} → {new_state.value}"
                    )

            return self._state

    def _determine_state(self, battery_pct, battery_v, cpu_temp, gpu_temp,
                         is_charging, estop):
        """현재 조건 기반 상태 결정 — V8.5: SHUTDOWN 온도 검증 수정"""
        # 최우선: 비상
        if estop:
            return PowerState.EMERGENCY

        # 온도 기반
        max_temp = max(
            cpu_temp or 0,
            gpu_temp or 0
        )

        if max_temp >= 95:
            # V8.5 수정: SHUTDOWN 진입 시 온도 검증 로깅
            logging.critical(
                f"[PowerMgr V8.5] SHUTDOWN 진입 — 온도 {max_temp}°C ≥ 95°C "
                f"(CPU={cpu_temp}°C, GPU={gpu_temp}°C)"
            )
            return PowerState.SHUTDOWN
        if max_temp >= 85:
            return PowerState.THERMAL_THROTTLE

        # 배터리 기반
        pct = battery_pct or 100

        if pct <= 2:
            # V8.5 수정: SHUTDOWN 진입 시 배터리 검증 로깅
            logging.critical(
                f"[PowerMgr V8.5] SHUTDOWN 진입 — 배터리 {pct}% ≤ 2%"
            )
            return PowerState.SHUTDOWN
        if pct <= 5:
            return PowerState.CRITICAL_LOW
        if pct <= 20:
            if is_charging:
                return PowerState.CHARGING
            return PowerState.POWER_SAVE

        # 충전 중
        if is_charging:
            return PowerState.CHARGING

        # 정상
        if max_temp >= 75:
            return PowerState.POWER_SAVE

        return PowerState.FULL_POWER

    @property
    def state(self):
        return self._state

    @property
    def power_budget_w(self):
        return self.POWER_BUDGETS.get(self._state, 0)

    @property
    def state_duration_s(self):
        return time.time() - self._state_entered_at

    def add_listener(self, callback):
        """상태 전이 리스너 등록 callback(old_state, new_state)"""
        self._listeners.append(callback)

    @property
    def health(self):
        return {
            'state': self._state.value,
            'power_budget_w': self.power_budget_w,
            'state_duration_s': self.state_duration_s,
            'transition_count': len(self._state_history),
            'last_known_temps': self._last_known_temps,  # V8.5
        }
