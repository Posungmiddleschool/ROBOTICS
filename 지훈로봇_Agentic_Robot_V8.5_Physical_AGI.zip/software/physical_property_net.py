#!/usr/bin/env python3
"""
physical_property_net.py - Multi-Task Network for Physical Object Property Estimation
물리적 객체 속성 추정을 위한 멀티태스크 네트워크

Estimates mass, texture, temperature, deformability, and fragility
from visual, tactile, and force features using multi-task learning
with learned uncertainty weighting (Kendall et al.).
시각, 촉각, 힘 특징으로부터 질량, 질감, 온도, 변형성, 파손성을
학습된 불확실성 가중치(Kendall et al.)를 사용한 멀티태스크 학습으로 추정.
"""

import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple, Dict

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.utils.data import Dataset, DataLoader
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    nn = object
    Dataset = object

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# ─── Constants / 상수 ────────────────────────────────────────────────
DB_PATH = "physical_properties.db"
VISUAL_DIM = 128              # visual feature dimension / 시각 특징 차원
TACTILE_DIM = 64              # tactile feature dimension / 촉각 특징 차원
FORCE_DIM = 32                # force feature dimension / 힘 특징 차원
SHARED_HIDDEN = 256           # shared backbone hidden dim / 공유 백본 은닉 차원
HEAD_HIDDEN = 64              # task head hidden dim / 태스크 헤드 은닉 차원
NUM_TEXTURE_CLASSES = 8       # texture classes / 질감 클래스 수
LEARNING_RATE = 1e-4
BATCH_SIZE = 32
MAX_EPOCHS = 100
PRIOR_WEIGHT = 0.5           # Bayesian prior weight / 베이지안 사전 가중치
MIN_OBSERVATIONS_FOR_CONFIDENCE = 5


# ─── Texture Classes / 질감 클래스 ───────────────────────────────────
class TextureClass(Enum):
    """
    8가지 질감 클래스 / 8 texture classification categories.
    """
    SMOOTH = 0       # 매끄러운 / Smooth
    ROUGH = 1        # 거친 / Rough
    BUMPY = 2        # 울퉁불퉁한 / Bumpy
    STICKY = 3       # 끈적한 / Sticky
    SOFT = 4         # 부드러운 / Soft
    HARD = 5         # 단단한 / Hard
    SLIPPERY = 6     # 미끄러운 / Slippery
    FABRIC = 7       # 직물 / Fabric

    @classmethod
    def name_list(cls) -> List[str]:
        return [t.name.lower() for t in cls]


# ─── Data Classes / 데이터 클래스 ─────────────────────────────────────
@dataclass
class PropertyEstimate:
    """물리적 속성 추정 결과 / Physical property estimation result."""
    mass: float                   # kg
    mass_confidence: float        # 0-1
    texture: TextureClass         # predicted texture class / 예측 질감 클래스
    texture_probs: np.ndarray     # (8,) softmax probabilities / 소프트맥스 확률
    texture_confidence: float     # 0-1
    temperature: float            # °C
    temperature_confidence: float # 0-1
    deformability: float          # 0-1 (0=rigid, 1=very deformable) / 0=강성, 1=매우 변형 가능
    deformability_confidence: float
    fragility: float              # 0-1 (0=robust, 1=very fragile) / 0=튼튼, 1=매우 파손 가능
    fragility_confidence: float
    overall_confidence: float     # 0-1
    num_observations: int = 0     # number of observations used / 사용된 관측 수


@dataclass
class PropertySample:
    """학습용 물리 속성 샘플 / Physical property sample for training."""
    visual_features: np.ndarray     # (128,)
    tactile_features: np.ndarray    # (64,)
    force_features: np.ndarray      # (32,)
    mass: float                     # kg
    texture_label: int              # 0-7
    temperature: float              # °C
    deformability: float            # 0-1
    fragility: float                # 0-1


# ─── PhysicalPropertyNet / 물리 속성 네트워크 ────────────────────────
if HAS_TORCH:
    class PhysicalPropertyNet(nn.Module):
        """
        물리적 객체 속성 추정 멀티태스크 네트워크
        Multi-task network for estimating physical object properties.
        Input: visual_features(128) + tactile_features(64) + force_features(32)
        Shared backbone: FC(224→256→256) + ReLU + BN
        Task heads: mass, texture, temperature, deformability, fragility
        Multi-task loss with learned uncertainty weighting (Kendall et al.).
        학습된 불확실성 가중치 기반 멀티태스크 손실 (Kendall et al.).
        """

        def __init__(self, visual_dim: int = VISUAL_DIM, tactile_dim: int = TACTILE_DIM,
                     force_dim: int = FORCE_DIM, shared_hidden: int = SHARED_HIDDEN,
                     head_hidden: int = HEAD_HIDDEN,
                     num_texture_classes: int = NUM_TEXTURE_CLASSES):
            super().__init__()
            input_dim = visual_dim + tactile_dim + force_dim  # 224

            # 공유 백본 / Shared backbone
            self.shared_backbone = nn.Sequential(
                nn.Linear(input_dim, shared_hidden),
                nn.ReLU(),
                nn.BatchNorm1d(shared_hidden),
                nn.Linear(shared_hidden, shared_hidden),
                nn.ReLU(),
                nn.BatchNorm1d(shared_hidden),
            )

            # 질량 헤드: FC(256→64→1) ReLU → kg / Mass head
            self.mass_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.ReLU(),
                nn.Linear(head_hidden, 1),
                nn.ReLU()  # 질량은 양수 / Mass is positive
            )

            # 질감 헤드: FC(256→64→8) softmax / Texture head
            self.texture_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.ReLU(),
                nn.Linear(head_hidden, num_texture_classes),
            )

            # 온도 헤드: FC(256→64→1) / Temperature head
            self.temperature_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.ReLU(),
                nn.Linear(head_hidden, 1),
            )

            # 변형성 헤드: FC(256→64→1) sigmoid → 0-1 / Deformability head
            self.deformability_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.ReLU(),
                nn.Linear(head_hidden, 1),
                nn.Sigmoid()
            )

            # 파손성 헤드: FC(256→64→1) sigmoid → 0-1 / Fragility head
            self.fragility_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.ReLU(),
                nn.Linear(head_hidden, 1),
                nn.Sigmoid()
            )

            # 학습된 불확실성 로그 분산 (Kendall et al.) / Learned log variance (Kendall et al.)
            # 각 태스크의 손실 가중치를 학습 / Learn loss weight for each task
            self.log_vars = nn.Parameter(torch.zeros(5))  # [mass, texture, temp, deform, fragility]

            self._init_weights()
            total_params = sum(p.numel() for p in self.parameters())
            logger.info(f"PhysicalPropertyNet 초기화: params={total_params:,} / Initialized")

        def _init_weights(self):
            """가중치 초기화 / Initialize weights."""
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)

        def forward(self, visual: "torch.Tensor", tactile: "torch.Tensor",
                    force_feat: "torch.Tensor") -> Dict[str, "torch.Tensor"]:
            """
            순전파 / Forward pass.
            Args:
                visual: (batch, 128) — 시각 특징 / visual features
                tactile: (batch, 64) — 촉각 특징 / tactile features
                force_feat: (batch, 32) — 힘 특징 / force features
            Returns:
                Dict with predictions for each property / 각 속성의 예측값 딕셔너리
            """
            x = torch.cat([visual, tactile, force_feat], dim=-1)  # (batch, 224)
            shared = self.shared_backbone(x)  # (batch, 256)

            mass = self.mass_head(shared)                    # (batch, 1)
            texture_logits = self.texture_head(shared)        # (batch, 8)
            temperature = self.temperature_head(shared)       # (batch, 1)
            deformability = self.deformability_head(shared)   # (batch, 1)
            fragility = self.fragility_head(shared)           # (batch, 1)

            return {
                "mass": mass,
                "texture_logits": texture_logits,
                "temperature": temperature,
                "deformability": deformability,
                "fragility": fragility,
            }

        def compute_loss(self, predictions: Dict[str, "torch.Tensor"],
                         targets: Dict[str, "torch.Tensor"]) -> "torch.Tensor":
            """
            학습된 불확실성 가중치 멀티태스크 손실 / Multi-task loss with learned uncertainty weighting.
            L_total = Σ (1/2σ²) * L_i + log(σ)  (Kendall et al., 2018)
            """
            # 질량 손실 (회귀, MSE) / Mass loss (regression, MSE)
            mass_loss = F.mse_loss(predictions["mass"].squeeze(), targets["mass"])

            # 질감 손실 (분류, CE) / Texture loss (classification, CE)
            texture_loss = F.cross_entropy(predictions["texture_logits"],
                                            targets["texture"].long())

            # 온도 손실 (회귀, MSE) / Temperature loss (regression, MSE)
            temp_loss = F.mse_loss(predictions["temperature"].squeeze(), targets["temperature"])

            # 변형성 손실 (회귀, BCE) / Deformability loss (regression, BCE)
            deform_loss = F.binary_cross_entropy(
                predictions["deformability"].squeeze(), targets["deformability"]
            )

            # 파손성 손실 (회귀, BCE) / Fragility loss (regression, BCE)
            frag_loss = F.binary_cross_entropy(
                predictions["fragility"].squeeze(), targets["fragility"]
            )

            # 학습된 불확실성 가중치 적용 / Apply learned uncertainty weighting
            # L_i = (1/2σ²) * L_i + log(σ)  where log_var = log(σ²)
            precision_mass = torch.exp(-self.log_vars[0])
            precision_texture = torch.exp(-self.log_vars[1])
            precision_temp = torch.exp(-self.log_vars[2])
            precision_deform = torch.exp(-self.log_vars[3])
            precision_frag = torch.exp(-self.log_vars[4])

            total_loss = (
                0.5 * precision_mass * mass_loss + 0.5 * self.log_vars[0] +
                0.5 * precision_texture * texture_loss + 0.5 * self.log_vars[1] +
                0.5 * precision_temp * temp_loss + 0.5 * self.log_vars[2] +
                0.5 * precision_deform * deform_loss + 0.5 * self.log_vars[3] +
                0.5 * precision_frag * frag_loss + 0.5 * self.log_vars[4]
            )

            return total_loss


# ─── PropertyEstimationDataset / 속성 추정 데이터셋 ──────────────────
class PropertyEstimationDataset(Dataset if HAS_TORCH else object):
    """
    물리 속성 추정을 위한 PyTorch Dataset / Dataset for property estimation.
    SQLite에서 시각/촉각/힘 특징과 속성 레이블을 로드.
    Loads visual/tactile/force features and property labels from SQLite.
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._ensure_schema()
        self._indices = self._load_indices()
        logger.info(f"PropertyEstimationDataset: {len(self._indices)} 샘플 / samples")

    def _ensure_schema(self):
        """데이터베이스 스키마 보장 / Ensure database schema."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS property_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                visual BLOB NOT NULL,
                tactile BLOB NOT NULL,
                force_feat BLOB NOT NULL,
                mass REAL NOT NULL,
                texture_label INTEGER NOT NULL,
                temperature REAL NOT NULL,
                deformability REAL NOT NULL,
                fragility REAL NOT NULL,
                timestamp REAL DEFAULT (strftime('%s','now'))
            )
        """)
        self._conn.commit()

    def _load_indices(self) -> List[int]:
        rows = self._conn.execute("SELECT id FROM property_samples").fetchall()
        return [r[0] for r in rows]

    def __len__(self) -> int:
        return len(self._indices)

    def __getitem__(self, idx: int):
        seq_id = self._indices[idx]
        row = self._conn.execute(
            "SELECT visual, tactile, force_feat, mass, texture_label, "
            "temperature, deformability, fragility FROM property_samples WHERE id=?",
            (seq_id,)
        ).fetchone()

        if row is None:
            return self._zero_sample()

        visual = np.frombuffer(row[0], dtype=np.float32).copy()
        tactile = np.frombuffer(row[1], dtype=np.float32).copy()
        force_feat = np.frombuffer(row[2], dtype=np.float32).copy()

        return (
            torch.FloatTensor(visual) if HAS_TORCH else visual,
            torch.FloatTensor(tactile) if HAS_TORCH else tactile,
            torch.FloatTensor(force_feat) if HAS_TORCH else force_feat,
            row[3],   # mass
            row[4],   # texture_label
            row[5],   # temperature
            row[6],   # deformability
            row[7],   # fragility
        )

    def _zero_sample(self):
        """빈 샘플 반환 / Return zero sample."""
        z_v = torch.zeros(VISUAL_DIM) if HAS_TORCH else np.zeros(VISUAL_DIM)
        z_t = torch.zeros(TACTILE_DIM) if HAS_TORCH else np.zeros(TACTILE_DIM)
        z_f = torch.zeros(FORCE_DIM) if HAS_TORCH else np.zeros(FORCE_DIM)
        return (z_v, z_t, z_f, 0.0, 0, 20.0, 0.0, 0.0)

    def add_sample(self, sample: PropertySample) -> int:
        """새 속성 샘플 추가 / Add a new property sample."""
        cursor = self._conn.execute(
            "INSERT INTO property_samples "
            "(visual, tactile, force_feat, mass, texture_label, temperature, deformability, fragility) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (sample.visual_features.astype(np.float32).tobytes(),
             sample.tactile_features.astype(np.float32).tobytes(),
             sample.force_features.astype(np.float32).tobytes(),
             sample.mass, sample.texture_label, sample.temperature,
             sample.deformability, sample.fragility)
        )
        row_id = cursor.lastrowid
        self._conn.commit()
        self._indices.append(row_id)
        return row_id


# ─── PropertyEstimationTrainer / 속성 추정 트레이너 ──────────────────
class PropertyEstimationTrainer:
    """
    멀티태스크 손실 기반 물리 속성 추정 훈련 파이프라인
    Training pipeline for property estimation with multi-task loss.
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu") if HAS_TORCH else None
        self.model: Optional[PhysicalPropertyNet] = None
        self.dataset = PropertyEstimationDataset(db_path)
        self._losses: List[float] = []

        if HAS_TORCH:
            self.model = PhysicalPropertyNet().to(self.device)
        else:
            logger.warning("PyTorch 미설치 — 제한 모드 / Limited mode")

    def train(self, epochs: int = MAX_EPOCHS, batch_size: int = BATCH_SIZE) -> List[float]:
        """
        멀티태스크 손실로 훈련 / Train with multi-task loss.
        """
        if not HAS_TORCH or self.model is None:
            return []
        if len(self.dataset) < batch_size:
            logger.warning("데이터 부족 / Insufficient data")
            return []

        dataloader = DataLoader(self.dataset, batch_size=batch_size,
                                shuffle=True, drop_last=True)
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=LEARNING_RATE, weight_decay=0.01)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

        self.model.train()
        epoch_losses = []

        for epoch in range(epochs):
            epoch_loss = 0.0
            count = 0

            for visual, tactile, force_feat, mass, tex, temp, deform, frag in dataloader:
                visual = visual.to(self.device)
                tactile = tactile.to(self.device)
                force_feat = force_feat.to(self.device)

                predictions = self.model(visual, tactile, force_feat)
                targets = {
                    "mass": mass.float().to(self.device),
                    "texture": tex.long().to(self.device),
                    "temperature": temp.float().to(self.device),
                    "deformability": deform.float().to(self.device),
                    "fragility": frag.float().to(self.device),
                }

                loss = self.model.compute_loss(predictions, targets)

                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                optimizer.step()

                epoch_loss += loss.item()
                count += 1

            scheduler.step()
            avg_loss = epoch_loss / max(1, count)
            epoch_losses.append(avg_loss)
            self._losses.append(avg_loss)

            if (epoch + 1) % 10 == 0:
                # 학습된 불확실성 가중치 로깅 / Log learned uncertainty weights
                log_vars = self.model.log_vars.detach().cpu().numpy()
                logger.info(f"[속성추정/PropEst] epoch {epoch+1}/{epochs} "
                             f"loss={avg_loss:.4f} log_vars={log_vars.round(2)}")

        logger.info("속성 추정 훈련 완료 / Property estimation training complete")
        return epoch_losses

    def predict(self, visual: np.ndarray, tactile: np.ndarray,
                force_feat: np.ndarray) -> Optional[PropertyEstimate]:
        """단일 예측 / Single prediction."""
        if not HAS_TORCH or self.model is None:
            return None

        self.model.eval()
        with torch.no_grad():
            v = torch.FloatTensor(visual).unsqueeze(0).to(self.device)
            t = torch.FloatTensor(tactile).unsqueeze(0).to(self.device)
            f = torch.FloatTensor(force_feat).unsqueeze(0).to(self.device)
            preds = self.model(v, t, f)

            mass = float(preds["mass"].item())
            tex_probs = F.softmax(preds["texture_logits"], dim=-1).cpu().numpy().squeeze()
            tex_class = TextureClass(int(np.argmax(tex_probs)))
            temp = float(preds["temperature"].item())
            deform = float(preds["deformability"].item())
            frag = float(preds["fragility"].item())

        return PropertyEstimate(
            mass=max(0.0, mass),
            mass_confidence=0.5,
            texture=tex_class,
            texture_probs=tex_probs,
            texture_confidence=float(tex_probs.max()),
            temperature=temp,
            temperature_confidence=0.5,
            deformability=np.clip(deform, 0, 1),
            deformability_confidence=0.5,
            fragility=np.clip(frag, 0, 1),
            fragility_confidence=0.5,
            overall_confidence=0.5,
            num_observations=1,
        )

    def save(self, path: str = "property_net.pt"):
        if HAS_TORCH and self.model is not None:
            torch.save(self.model.state_dict(), path)
            logger.info(f"모델 저장: {path} / Model saved")


# ─── OnlinePropertyEstimator / 온라인 속성 추정기 ────────────────────
class OnlinePropertyEstimator:
    """
    조작 중 실시간 물리 속성 추정 / Real-time property estimation during manipulation.
    update_estimate: 새 관측으로 베이지안 업데이트 / Bayesian update with new observation.
    신뢰도는 관측이 많아질수록 증가 / Confidence increases with more observations.
    """

    def __init__(self, trainer: Optional[PropertyEstimationTrainer] = None):
        self.trainer = trainer or PropertyEstimationTrainer()
        self._current_estimate: Optional[PropertyEstimate] = None
        self._observation_count = 0
        self._prior_mass = 0.5       # kg, default prior / 기본 사전
        self._prior_temp = 20.0      # °C, room temperature / 실온 사전
        self._prior_deform = 0.5     # neutral prior / 중립 사전
        self._prior_frag = 0.5       # neutral prior / 중립 사전
        self._texture_votes: Dict[int, int] = {}
        self._lock = threading.Lock()
        logger.info("OnlinePropertyEstimator 초기화 / Initialized")

    def update_estimate(self, visual_feat: np.ndarray, tactile_feat: np.ndarray,
                        force_feat: np.ndarray) -> PropertyEstimate:
        """
        새 관측으로 속성 추정 업데이트 (베이지안) / Update property estimate with new observation (Bayesian).
        사전 추정과 새 관측을 가중 평균으로 결합 / Combine prior and new observation via weighted average.
        """
        new_estimate = self.trainer.predict(visual_feat, tactile_feat, force_feat)

        if new_estimate is None:
            # PyTorch 미사용 시 휴리스틱 추정 / Heuristic estimate when PyTorch unavailable
            new_estimate = PropertyEstimate(
                mass=self._prior_mass, mass_confidence=0.1,
                texture=TextureClass.SMOOTH, texture_probs=np.ones(NUM_TEXTURE_CLASSES) / NUM_TEXTURE_CLASSES,
                texture_confidence=0.125, temperature=self._prior_temp, temperature_confidence=0.1,
                deformability=self._prior_deform, deformability_confidence=0.1,
                fragility=self._prior_frag, fragility_confidence=0.1,
                overall_confidence=0.1, num_observations=self._observation_count
            )

        with self._lock:
            self._observation_count += 1

            if self._current_estimate is None:
                self._current_estimate = new_estimate
                self._current_estimate.num_observations = self._observation_count
                return self._current_estimate

            # 베이지안 업데이트: 가중 평균 / Bayesian update: weighted average
            prior_w = PRIOR_WEIGHT
            obs_w = 1.0 - prior_w

            # 관측 수에 따라 관측 가중치 증가 / Increase observation weight with more observations
            effective_obs_w = min(0.9, obs_w + 0.05 * (self._observation_count - 1))
            effective_prior_w = 1.0 - effective_obs_w

            # 연속 속성 베이지안 업데이트 / Bayesian update for continuous properties
            updated_mass = effective_prior_w * self._current_estimate.mass + effective_obs_w * new_estimate.mass
            updated_temp = effective_prior_w * self._current_estimate.temperature + effective_obs_w * new_estimate.temperature
            updated_deform = effective_prior_w * self._current_estimate.deformability + effective_obs_w * new_estimate.deformability
            updated_frag = effective_prior_w * self._current_estimate.fragility + effective_obs_w * new_estimate.fragility

            # 질감: 투표 누적 / Texture: accumulate votes
            tex_idx = int(np.argmax(new_estimate.texture_probs))
            self._texture_votes[tex_idx] = self._texture_votes.get(tex_idx, 0) + 1
            best_tex = max(self._texture_votes, key=self._texture_votes.get)
            texture_probs = np.zeros(NUM_TEXTURE_CLASSES)
            for k, v in self._texture_votes.items():
                texture_probs[k] = v
            texture_probs = texture_probs / max(1, texture_probs.sum())

            # 신뢰도 업데이트: 관측이 많아질수록 증가 / Confidence increases with observations
            confidence_boost = min(0.9, 0.2 + 0.1 * np.log1p(self._observation_count))
            conf_factor = min(1.0, confidence_boost)

            self._current_estimate = PropertyEstimate(
                mass=max(0.0, updated_mass),
                mass_confidence=conf_factor,
                texture=TextureClass(best_tex),
                texture_probs=texture_probs,
                texture_confidence=float(texture_probs[best_tex]),
                temperature=updated_temp,
                temperature_confidence=conf_factor,
                deformability=np.clip(updated_deform, 0, 1),
                deformability_confidence=conf_factor,
                fragility=np.clip(updated_frag, 0, 1),
                fragility_confidence=conf_factor,
                overall_confidence=conf_factor,
                num_observations=self._observation_count,
            )

        return self._current_estimate

    def get_current_estimate(self) -> Optional[PropertyEstimate]:
        """현재 추정값 반환 / Return current estimate."""
        return self._current_estimate

    def reset(self):
        """추정기 리셋 (새 객체) / Reset estimator (for new object)."""
        with self._lock:
            self._current_estimate = None
            self._observation_count = 0
            self._texture_votes.clear()
        logger.info("속성 추정기 리셋 / Property estimator reset")


# ─── Module-level demo / 모듈 레벨 데모 ──────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    if not HAS_TORCH:
        logger.error("PyTorch 설치 필요 / PyTorch required")
    else:
        # 데모: 가상 속성 데이터로 훈련 / Demo: train with synthetic property data
        trainer = PropertyEstimationTrainer(db_path=":memory:")

        for _ in range(200):
            sample = PropertySample(
                visual_features=np.random.randn(VISUAL_DIM).astype(np.float32),
                tactile_features=np.random.randn(TACTILE_DIM).astype(np.float32),
                force_features=np.random.randn(FORCE_DIM).astype(np.float32),
                mass=np.random.uniform(0.1, 5.0),
                texture_label=np.random.randint(0, NUM_TEXTURE_CLASSES),
                temperature=np.random.uniform(10.0, 80.0),
                deformability=np.random.uniform(0, 1),
                fragility=np.random.uniform(0, 1),
            )
            trainer.dataset.add_sample(sample)

        losses = trainer.train(epochs=20, batch_size=16)
        logger.info(f"훈련 손실 (마지막 3): {losses[-3:]} / Training losses (last 3)")

        # 온라인 추정기 데모 / Online estimator demo
        online = OnlinePropertyEstimator(trainer)
        for i in range(5):
            v = np.random.randn(VISUAL_DIM).astype(np.float32)
            t = np.random.randn(TACTILE_DIM).astype(np.float32)
            f = np.random.randn(FORCE_DIM).astype(np.float32)
            est = online.update_estimate(v, t, f)
            logger.info(f"관측 {i+1}: mass={est.mass:.2f}kg, tex={est.texture.name}, "
                         f"temp={est.temperature:.1f}°C, conf={est.overall_confidence:.2f}")

        logger.info("physical_property_net.py 데모 완료 / Demo complete")
