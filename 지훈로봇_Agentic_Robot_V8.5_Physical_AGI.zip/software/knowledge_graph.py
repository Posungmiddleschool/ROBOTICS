#!/usr/bin/env python3
"""
지훈 로봇 V8.5 - 세계 지식 그래프 (World Knowledge Graph)
========================================================

그래프 구조의 지식 표현 시스템.
엔티티(개체)와 관계(관계)로 구성된 지식 그래프를 통해
세계에 대한 구조적 이해를 제공합니다.

TODO 27: 세계 지식 그래프 구현

노드(Node): entities - objects, concepts, actions, people, locations, properties
엣지(Edge): relationships - is_a, has_property, can_be_used_for, similar_to, causes,
          part_of, located_at

특징:
- SQLite 백업 그래프 저장소 (3 테이블: entities, relations, entity_embeddings)
- SPARQL-유사 쿼리 언어
- 임베딩 기반 퍼지 매칭
- Gemma 4를 활용한 자동 엔티티 추출
- 증분적 세계 데이터 업데이트
- 관계 신뢰도 (0~1)
- 최대 엔티티: 100,000, 최대 관계: 500,000

하드웨어: Dual Jetson Orin NX 16GB
AI 모델: Gemma 4 E4B Q4_K_M

Author: 지훈 로봇 V8.5 개발팀
Created: 2025
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np

logger = logging.getLogger("jihun_v84.knowledge_graph")
logger.setLevel(logging.DEBUG)


# ──────────────────────────────────────────────
#  열거형 (Enumerations)
# ──────────────────────────────────────────────

class EntityType(Enum):
    """엔티티 유형 / Entity type enumeration"""
    OBJECT = "object"
    CONCEPT = "concept"
    ACTION = "action"
    PERSON = "person"
    LOCATION = "location"
    PROPERTY = "property"


class RelationType(Enum):
    """관계 유형 / Relation type enumeration"""
    IS_A = "is_a"
    HAS_PROPERTY = "has_property"
    CAN_BE_USED_FOR = "can_be_used_for"
    SIMILAR_TO = "similar_to"
    CAUSES = "causes"
    PART_OF = "part_of"
    LOCATED_AT = "located_at"


# ──────────────────────────────────────────────
#  데이터 클래스 (Data Classes)
# ──────────────────────────────────────────────

@dataclass
class Entity:
    """지식 그래프 엔티티 / Knowledge graph entity (node)"""
    entity_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    name: str = ""
    entity_type: EntityType = EntityType.CONCEPT
    properties: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[np.ndarray] = None
    confidence: float = 0.8
    source: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    access_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def touch(self) -> None:
        """접근 기록 업데이트 / Update access record"""
        self.access_count += 1
        self.updated_at = time.time()

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary"""
        return {
            "entity_id": self.entity_id,
            "name": self.name,
            "entity_type": self.entity_type.value,
            "properties": self.properties,
            "confidence": self.confidence,
            "source": self.source,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "access_count": self.access_count,
            "metadata": self.metadata,
        }


@dataclass
class Relation:
    """지식 그래프 관계 / Knowledge graph relation (directed edge)"""
    relation_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    source_id: str = ""
    target_id: str = ""
    relation_type: RelationType = RelationType.IS_A
    weight: float = 1.0
    confidence: float = 0.8
    source: str = ""
    created_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary"""
        return {
            "relation_id": self.relation_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relation_type": self.relation_type.value,
            "weight": self.weight,
            "confidence": self.confidence,
            "source": self.source,
            "created_at": self.created_at,
            "metadata": self.metadata,
        }


@dataclass
class QueryResult:
    """쿼리 결과 / Query result"""
    entities: List[Entity] = field(default_factory=list)
    relations: List[Relation] = field(default_factory=list)
    paths: List[List[str]] = field(default_factory=list)
    confidence: float = 0.0
    explanation: str = ""


# ──────────────────────────────────────────────
#  세계 지식 그래프 (World Knowledge Graph)
# ──────────────────────────────────────────────

class WorldKnowledgeGraph:
    """
    세계 지식 그래프 / World Knowledge Graph.
    SQLite 백업 그래프 데이터베이스.

    3 테이블: entities, relations, entity_embeddings
    최대 엔티티: 100,000
    최대 관계: 500,000

    사용 예시:
        kg = WorldKnowledgeGraph(db_path="knowledge.db")
        kg.initialize()

        dog_id = kg.add_entity(Entity(name="개", entity_type=EntityType.OBJECT))
        animal_id = kg.add_entity(Entity(name="동물", entity_type=EntityType.CONCEPT))
        kg.add_relation(Relation(source_id=dog_id, target_id=animal_id,
                                  relation_type=RelationType.IS_A))

        results = kg.query("개 is_a ?")
        path = kg.find_path(dog_id, animal_id)
    """

    MAX_ENTITIES = 100_000
    MAX_RELATIONS = 500_000

    def __init__(self, db_path: str = "world_knowledge_graph.db") -> None:
        """
        세계 지식 그래프 초기화 / Initialize World Knowledge Graph.

        Args:
            db_path: SQLite 데이터베이스 파일 경로 / SQLite database path
        """
        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

        # 인메모리 캐시 / In-memory caches
        self._entities: Dict[str, Entity] = {}
        self._relations: Dict[str, Relation] = {}
        self._name_index: Dict[str, str] = {}          # name.lower() → entity_id
        self._outgoing: Dict[str, List[str]] = defaultdict(list)  # entity_id → [relation_ids]
        self._incoming: Dict[str, List[str]] = defaultdict(list)  # entity_id → [relation_ids]
        self._type_index: Dict[EntityType, List[str]] = defaultdict(list)
        self._relation_type_index: Dict[RelationType, List[str]] = defaultdict(list)

        # LLM 참조 / LLM reference
        self._llm_func: Optional[Any] = None

        self._initialized = False
        logger.info("세계 지식 그래프 인스턴스 생성 / World Knowledge Graph created: %s", db_path)

    def initialize(self) -> None:
        """그래프 데이터베이스 초기화 / Initialize graph database"""
        self._conn = sqlite3.connect(self._db_path)
        self._create_tables()
        self._load_existing_data()
        self._initialized = True
        logger.info(
            "세계 지식 그래프 초기화: %d 엔티티, %d 관계 / "
            "World Knowledge Graph initialized: %d entities, %d relations",
            len(self._entities), len(self._relations),
            len(self._entities), len(self._relations),
        )

    def _create_tables(self) -> None:
        """3개 SQLite 테이블 생성 / Create 3 SQLite tables"""
        assert self._conn is not None
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS entities (
                entity_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                entity_type TEXT NOT NULL DEFAULT 'concept',
                properties TEXT NOT NULL DEFAULT '{}',
                confidence REAL NOT NULL DEFAULT 0.8,
                source TEXT NOT NULL DEFAULT '',
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                access_count INTEGER NOT NULL DEFAULT 0,
                metadata TEXT NOT NULL DEFAULT '{}'
            );

            CREATE TABLE IF NOT EXISTS relations (
                relation_id TEXT PRIMARY KEY,
                source_id TEXT NOT NULL,
                target_id TEXT NOT NULL,
                relation_type TEXT NOT NULL DEFAULT 'is_a',
                weight REAL NOT NULL DEFAULT 1.0,
                confidence REAL NOT NULL DEFAULT 0.8,
                source TEXT NOT NULL DEFAULT '',
                created_at REAL NOT NULL,
                metadata TEXT NOT NULL DEFAULT '{}',
                FOREIGN KEY (source_id) REFERENCES entities(entity_id),
                FOREIGN KEY (target_id) REFERENCES entities(entity_id)
            );

            CREATE TABLE IF NOT EXISTS entity_embeddings (
                entity_id TEXT PRIMARY KEY,
                embedding BLOB NOT NULL,
                model TEXT NOT NULL DEFAULT 'default',
                updated_at REAL NOT NULL,
                FOREIGN KEY (entity_id) REFERENCES entities(entity_id)
            );

            CREATE INDEX IF NOT EXISTS idx_entity_name ON entities(name);
            CREATE INDEX IF NOT EXISTS idx_entity_type ON entities(entity_type);
            CREATE INDEX IF NOT EXISTS idx_relation_source ON relations(source_id);
            CREATE INDEX IF NOT EXISTS idx_relation_target ON relations(target_id);
            CREATE INDEX IF NOT EXISTS idx_relation_type ON relations(relation_type);
        """)
        self._conn.commit()

    def _load_existing_data(self) -> None:
        """기존 데이터 로드 / Load existing data"""
        assert self._conn is not None

        # 엔티티 로드 / Load entities
        cursor = self._conn.execute("SELECT * FROM entities")
        for row in cursor.fetchall():
            entity = Entity(
                entity_id=row[0], name=row[1],
                entity_type=EntityType(row[2]),
                properties=json.loads(row[3]),
                confidence=row[4], source=row[5],
                created_at=row[6], updated_at=row[7],
                access_count=row[8],
                metadata=json.loads(row[9]),
            )
            self._entities[entity.entity_id] = entity
            self._name_index[entity.name.lower()] = entity.entity_id
            self._type_index[entity.entity_type].append(entity.entity_id)

        # 관계 로드 / Load relations
        cursor = self._conn.execute("SELECT * FROM relations")
        for row in cursor.fetchall():
            relation = Relation(
                relation_id=row[0], source_id=row[1], target_id=row[2],
                relation_type=RelationType(row[3]),
                weight=row[4], confidence=row[5], source=row[6],
                created_at=row[7], metadata=json.loads(row[8]),
            )
            self._relations[relation.relation_id] = relation
            self._outgoing[relation.source_id].append(relation.relation_id)
            self._incoming[relation.target_id].append(relation.relation_id)
            self._relation_type_index[relation.relation_type].append(relation.relation_id)

    # ── 엔티티 관리 / Entity Management ──

    def add_entity(self, entity: Entity) -> str:
        """
        엔티티 추가 / Add entity to graph.
        동일 이름이 있으면 속성 병합합니다.

        Args:
            entity: 추가할 엔티티 / Entity to add

        Returns:
            엔티티 ID / Entity ID
        """
        # 최대 엔티티 수 확인 / Check max entities
        if len(self._entities) >= self.MAX_ENTITIES:
            logger.warning("최대 엔티티 수 도달 (%d) / Max entities reached", self.MAX_ENTITIES)
            return ""

        # 동일 이름 확인 / Check for existing entity
        existing_id = self._name_index.get(entity.name.lower())
        if existing_id and existing_id in self._entities:
            existing = self._entities[existing_id]
            existing.properties.update(entity.properties)
            existing.updated_at = time.time()
            if entity.confidence > existing.confidence:
                existing.confidence = entity.confidence
            self._save_entity(existing)
            return existing_id

        # 새 엔티티 추가 / Add new entity
        self._entities[entity.entity_id] = entity
        self._name_index[entity.name.lower()] = entity.entity_id
        self._type_index[entity.entity_type].append(entity.entity_id)
        self._save_entity(entity)

        logger.info(
            "엔티티 추가: %s [%s] / Entity added: %s [%s]",
            entity.name, entity.entity_type.value,
            entity.name, entity.entity_type.value,
        )
        return entity.entity_id

    def _save_entity(self, entity: Entity) -> None:
        """SQLite에 엔티티 저장 / Save entity to SQLite"""
        if not self._conn:
            return
        try:
            self._conn.execute("""
                INSERT OR REPLACE INTO entities
                (entity_id, name, entity_type, properties, confidence, source,
                 created_at, updated_at, access_count, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                entity.entity_id, entity.name, entity.entity_type.value,
                json.dumps(entity.properties, ensure_ascii=False),
                entity.confidence, entity.source,
                entity.created_at, entity.updated_at,
                entity.access_count, json.dumps(entity.metadata, ensure_ascii=False),
            ))
            self._conn.commit()
        except Exception as e:
            logger.error("엔티티 저장 실패: %s / Entity save failed: %s", e, e)

    def get_entity(self, entity_id: str) -> Optional[Entity]:
        """엔티티 ID로 조회 / Get entity by ID"""
        entity = self._entities.get(entity_id)
        if entity:
            entity.touch()
        return entity

    def get_entity_by_name(self, name: str) -> Optional[Entity]:
        """이름으로 엔티티 조회 / Get entity by name"""
        entity_id = self._name_index.get(name.lower())
        if entity_id:
            return self.get_entity(entity_id)
        return None

    # ── 관계 관리 / Relation Management ──

    def add_relation(self, relation: Relation) -> str:
        """
        관계 추가 / Add relation to graph.
        동일한 소스-타겟-유형의 관계가 있으면 가중치를 업데이트합니다.

        Args:
            relation: 추가할 관계 / Relation to add

        Returns:
            관계 ID / Relation ID
        """
        # 엔티티 존재 확인 / Verify entities exist
        if relation.source_id not in self._entities:
            logger.warning("출발 엔티티 없음: %s / Source entity not found: %s",
                           relation.source_id, relation.source_id)
            return ""
        if relation.target_id not in self._entities:
            logger.warning("도착 엔티티 없음: %s / Target entity not found: %s",
                           relation.target_id, relation.target_id)
            return ""

        # 최대 관계 수 확인 / Check max relations
        if len(self._relations) >= self.MAX_RELATIONS:
            logger.warning("최대 관계 수 도달 (%d) / Max relations reached", self.MAX_RELATIONS)
            return ""

        # 중복 관계 확인 / Check for duplicate relation
        for rid in self._outgoing.get(relation.source_id, []):
            existing = self._relations.get(rid)
            if (existing and
                existing.target_id == relation.target_id and
                existing.relation_type == relation.relation_type):
                existing.weight = min(1.0, existing.weight + 0.1)
                existing.confidence = min(1.0, existing.confidence + 0.05)
                self._save_relation(existing)
                return existing.relation_id

        # 새 관계 추가 / Add new relation
        self._relations[relation.relation_id] = relation
        self._outgoing[relation.source_id].append(relation.relation_id)
        self._incoming[relation.target_id].append(relation.relation_id)
        self._relation_type_index[relation.relation_type].append(relation.relation_id)
        self._save_relation(relation)

        logger.info(
            "관계 추가: %s -[%s]-> %s / Relation added: %s -[%s]-> %s",
            relation.source_id[:8], relation.relation_type.value, relation.target_id[:8],
            relation.source_id[:8], relation.relation_type.value, relation.target_id[:8],
        )
        return relation.relation_id

    def _save_relation(self, relation: Relation) -> None:
        """SQLite에 관계 저장 / Save relation to SQLite"""
        if not self._conn:
            return
        try:
            self._conn.execute("""
                INSERT OR REPLACE INTO relations
                (relation_id, source_id, target_id, relation_type, weight,
                 confidence, source, created_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                relation.relation_id, relation.source_id, relation.target_id,
                relation.relation_type.value, relation.weight,
                relation.confidence, relation.source,
                relation.created_at, json.dumps(relation.metadata, ensure_ascii=False),
            ))
            self._conn.commit()
        except Exception as e:
            logger.error("관계 저장 실패: %s / Relation save failed: %s", e, e)

    # ── 쿼리 / Query ──

    def query(self, query_string: str) -> QueryResult:
        """
        SPARQL-유사 쿼리 실행 / Execute SPARQL-like query.

        패턴:
          - "개" → 엔티티 + 관련 정보
          - "개 is_a ?" → 개의 상위 개념
          - "? is_a 동물" → 동물의 하위 개념
          - "개 ? 동물" → 개와 동물 사이 관계

        Args:
            query_string: 쿼리 문자열 / Query string

        Returns:
            쿼리 결과 / Query result
        """
        parts = query_string.strip().split()

        if len(parts) == 1:
            return self._query_entity(parts[0])
        elif len(parts) == 3:
            return self._query_triple(parts[0], parts[1], parts[2])
        else:
            return QueryResult(explanation="지원하지 않는 쿼리 형식 / Unsupported query format")

    def _query_entity(self, name: str) -> QueryResult:
        """단일 엔티티 쿼리 / Query single entity"""
        entity = self.get_entity_by_name(name)
        if not entity:
            similar = self._fuzzy_match_entity(name)
            if similar:
                return QueryResult(
                    entities=[similar],
                    relations=self.get_relations_of(similar.entity_id),
                    confidence=similar.confidence * 0.8,
                    explanation=f"유사 엔티티 반환: {similar.name}",
                )
            return QueryResult(explanation=f"엔티티 없음: {name}")

        relations = self.get_relations_of(entity.entity_id)
        related_entities: List[Entity] = [entity]
        for rel in relations:
            other_id = rel.target_id if rel.source_id == entity.entity_id else rel.source_id
            other = self._entities.get(other_id)
            if other and other not in related_entities:
                related_entities.append(other)

        return QueryResult(
            entities=related_entities,
            relations=relations,
            confidence=entity.confidence,
            explanation=f"'{name}' 관련 {len(relations)}개 관계",
        )

    def _query_triple(self, subject: str, predicate: str, obj: str) -> QueryResult:
        """삼중항 쿼리 / Query triple pattern"""
        results = QueryResult()
        matching_relations: List[Relation] = []
        matching_entities: List[Entity] = []

        subj_is_wildcard = subject == "?"
        pred_is_wildcard = predicate == "?"
        obj_is_wildcard = obj == "?"

        subj_entity = None if subj_is_wildcard else self.get_entity_by_name(subject)
        obj_entity = None if obj_is_wildcard else self.get_entity_by_name(obj)

        pred_type = None
        if not pred_is_wildcard:
            try:
                pred_type = RelationType(predicate)
            except ValueError:
                for rt in RelationType:
                    if predicate.lower() in rt.value.lower():
                        pred_type = rt
                        break

        for relation in self._relations.values():
            if pred_type and relation.relation_type != pred_type:
                continue
            if subj_entity and relation.source_id != subj_entity.entity_id:
                continue
            if obj_entity and relation.target_id != obj_entity.entity_id:
                continue

            matching_relations.append(relation)
            source = self._entities.get(relation.source_id)
            target = self._entities.get(relation.target_id)
            if source and source not in matching_entities:
                matching_entities.append(source)
            if target and target not in matching_entities:
                matching_entities.append(target)

        results.entities = matching_entities
        results.relations = matching_relations
        results.confidence = (
            sum(r.confidence for r in matching_relations) / len(matching_relations)
            if matching_relations else 0.0
        )
        results.explanation = f"{len(matching_relations)}개 관계 발견"
        return results

    # ── 경로 탐색 / Path Finding ──

    def find_path(
        self,
        source_id: str,
        target_id: str,
        max_depth: int = 6,
        relation_types: Optional[List[RelationType]] = None,
    ) -> List[List[str]]:
        """
        두 엔티티 간 경로 탐색 (BFS) / Find paths between two entities.

        Args:
            source_id: 출발 엔티티 ID / Source entity ID
            target_id: 도착 엔티티 ID / Target entity ID
            max_depth: 최대 탐색 깊이 / Max search depth
            relation_types: 허용할 관계 유형 / Allowed relation types

        Returns:
            경로 목록 / List of paths (entity ID lists)
        """
        if source_id not in self._entities or target_id not in self._entities:
            return []
        if source_id == target_id:
            return [[source_id]]

        paths: List[List[str]] = []
        visited: Set[str] = set()
        queue: List[Tuple[str, List[str]]] = [(source_id, [source_id])]

        while queue and len(paths) < 5:
            current_id, path = queue.pop(0)
            if len(path) > max_depth:
                continue
            if current_id in visited and len(path) > 2:
                continue
            visited.add(current_id)

            # 인접 엔티티 / Explore neighbors
            for rid in self._outgoing.get(current_id, []):
                rel = self._relations.get(rid)
                if not rel:
                    continue
                if relation_types and rel.relation_type not in relation_types:
                    continue
                next_id = rel.target_id
                new_path = path + [next_id]
                if next_id == target_id:
                    paths.append(new_path)
                elif next_id not in visited:
                    queue.append((next_id, new_path))

            # 역방향 / Also search incoming
            for rid in self._incoming.get(current_id, []):
                rel = self._relations.get(rid)
                if not rel:
                    continue
                if relation_types and rel.relation_type not in relation_types:
                    continue
                next_id = rel.source_id
                new_path = path + [next_id]
                if next_id == target_id:
                    paths.append(new_path)
                elif next_id not in visited:
                    queue.append((next_id, new_path))

        return paths

    def get_related(
        self,
        entity_id: str,
        max_hops: int = 2,
        relation_types: Optional[List[RelationType]] = None,
        limit: int = 20,
    ) -> List[Entity]:
        """
        관련 엔티티 조회 / Get related entities within N hops.

        Args:
            entity_id: 중심 엔티티 / Center entity ID
            max_hops: 최대 홉 수 / Maximum hops
            relation_types: 관계 유형 필터 / Relation type filter
            limit: 최대 결과 수 / Maximum results

        Returns:
            관련 엔티티 목록 / Related entities
        """
        if entity_id not in self._entities:
            return []

        visited: Set[str] = {entity_id}
        results: List[Entity] = []
        current_hop = {entity_id}

        for _ in range(max_hops):
            next_hop: Set[str] = set()
            for eid in current_hop:
                for rid in self._outgoing.get(eid, []):
                    rel = self._relations.get(rid)
                    if not rel:
                        continue
                    if relation_types and rel.relation_type not in relation_types:
                        continue
                    if rel.target_id not in visited:
                        next_hop.add(rel.target_id)
                        entity = self._entities.get(rel.target_id)
                        if entity:
                            results.append(entity)

                for rid in self._incoming.get(eid, []):
                    rel = self._relations.get(rid)
                    if not rel:
                        continue
                    if relation_types and rel.relation_type not in relation_types:
                        continue
                    if rel.source_id not in visited:
                        next_hop.add(rel.source_id)
                        entity = self._entities.get(rel.source_id)
                        if entity:
                            results.append(entity)

            visited.update(next_hop)
            current_hop = next_hop
            if len(results) >= limit:
                break

        return results[:limit]

    def get_relations_of(
        self,
        entity_id: str,
        relation_type: Optional[RelationType] = None,
        direction: str = "both",
    ) -> List[Relation]:
        """엔티티의 관계 조회 / Get relations of an entity"""
        results: List[Relation] = []
        seen: Set[str] = set()

        if direction in ("outgoing", "both"):
            for rid in self._outgoing.get(entity_id, []):
                rel = self._relations.get(rid)
                if rel and rel.relation_id not in seen:
                    if relation_type is None or rel.relation_type == relation_type:
                        results.append(rel)
                        seen.add(rel.relation_id)

        if direction in ("incoming", "both"):
            for rid in self._incoming.get(entity_id, []):
                rel = self._relations.get(rid)
                if rel and rel.relation_id not in seen:
                    if relation_type is None or rel.relation_type == relation_type:
                        results.append(rel)
                        seen.add(rel.relation_id)

        return results

    # ── 임베딩 / Embeddings ──

    def store_embedding(self, entity_id: str, embedding: np.ndarray, model: str = "default") -> None:
        """엔티티 임베딩 저장 / Store entity embedding"""
        if not self._conn:
            return
        try:
            self._conn.execute("""
                INSERT OR REPLACE INTO entity_embeddings
                (entity_id, embedding, model, updated_at)
                VALUES (?, ?, ?, ?)
            """, (
                entity_id,
                embedding.astype(np.float32).tobytes(),
                model,
                time.time(),
            ))
            self._conn.commit()
            # 인메모리에도 저장 / Also store in memory
            if entity_id in self._entities:
                self._entities[entity_id].embedding = embedding
        except Exception as e:
            logger.error("임베딩 저장 실패: %s / Embedding save failed: %s", e, e)

    def get_embedding(self, entity_id: str) -> Optional[np.ndarray]:
        """엔티티 임베딩 조회 / Get entity embedding"""
        # 인메모리 먼저 확인 / Check in-memory first
        entity = self._entities.get(entity_id)
        if entity and entity.embedding is not None:
            return entity.embedding

        # SQLite에서 로드 / Load from SQLite
        if not self._conn:
            return None
        try:
            row = self._conn.execute(
                "SELECT embedding FROM entity_embeddings WHERE entity_id = ?",
                (entity_id,),
            ).fetchone()
            if row:
                return np.frombuffer(row[0], dtype=np.float32)
        except Exception:
            pass
        return None

    # ── 퍼지 매칭 / Fuzzy Matching ──

    def _fuzzy_match_entity(self, name: str, threshold: float = 0.6) -> Optional[Entity]:
        """임베딩 기반 퍼지 매칭 / Embedding-based fuzzy matching"""
        name_lower = name.lower()

        # 1차: 부분 문자열 / First: substring match
        for entity in self._entities.values():
            if name_lower in entity.name.lower() or entity.name.lower() in name_lower:
                return entity

        # 2차: 속성 매칭 / Second: property match
        for entity in self._entities.values():
            for prop_val in entity.properties.values():
                if name_lower in str(prop_val).lower():
                    return entity

        return None

    # ── 자동 엔티티 추출 / Auto Entity Extraction ──

    async def extract_and_add(
        self,
        text: str,
        source: str = "observation",
        llm_func: Optional[Any] = None,
    ) -> List[str]:
        """
        텍스트에서 엔티티와 관계를 자동 추출 / Auto-extract entities and relations from text.
        Gemma 4를 활용하여 자연어 텍스트에서 구조적 지식을 추출합니다.

        Args:
            text: 입력 텍스트 / Input text
            source: 지식 출처 / Knowledge source
            llm_func: LLM 호출 함수 / LLM call function

        Returns:
            추가된 엔티티 ID 목록 / Added entity IDs
        """
        added_ids: List[str] = []
        llm = llm_func or self._llm_func

        if llm:
            try:
                prompt = (
                    "다음 텍스트에서 엔티티와 관계를 추출하세요.\n"
                    '형식: JSON 배열, 각 항목은 {"entity": 이름, "type": 유형, '
                    '"relations": [{"target": 대상, "relation": 관계유형}]}\n\n'
                    f"텍스트: {text}\n\n"
                    "엔티티 유형: object, concept, action, person, location, property\n"
                    "관계 유형: is_a, has_property, can_be_used_for, similar_to, "
                    "causes, part_of, located_at"
                )
                if hasattr(llm, "generate"):
                    result = llm.generate(prompt, max_tokens=512, temperature=0.3)
                    result_text = result.text if hasattr(result, "text") else str(result)
                elif callable(llm):
                    result_text = str(llm(prompt))
                else:
                    result_text = ""

                extracted = json.loads(result_text)
                if not isinstance(extracted, list):
                    extracted = [extracted]

                for item in extracted:
                    entity_name = item.get("entity", "")
                    if not entity_name:
                        continue
                    try:
                        entity_type = EntityType(item.get("type", "concept"))
                    except ValueError:
                        entity_type = EntityType.CONCEPT

                    entity = Entity(
                        name=entity_name,
                        entity_type=entity_type,
                        source=source,
                    )
                    eid = self.add_entity(entity)
                    if eid:
                        added_ids.append(eid)

                    for rel_info in item.get("relations", []):
                        target_name = rel_info.get("target", "")
                        if not target_name:
                            continue
                        target = self.get_entity_by_name(target_name)
                        if not target:
                            target = Entity(name=target_name, source=source)
                            tid = self.add_entity(target)
                        else:
                            tid = target.entity_id

                        try:
                            rel_type = RelationType(rel_info.get("relation", "is_a"))
                        except ValueError:
                            rel_type = RelationType.IS_A

                        if eid and tid:
                            relation = Relation(
                                source_id=eid, target_id=tid,
                                relation_type=rel_type, source=source,
                            )
                            self.add_relation(relation)

            except (json.JSONDecodeError, Exception) as e:
                logger.warning("LLM 엔티티 추출 실패: %s / LLM extraction failed: %s", e, e)
        else:
            # 간단한 규칙 기반 추출 / Simple rule-based extraction
            words = text.replace(".", " ").replace(",", " ").split()
            for word in words:
                if len(word) > 1 and word[0].isupper():
                    entity = Entity(name=word, source=source)
                    eid = self.add_entity(entity)
                    if eid:
                        added_ids.append(eid)

        logger.info("텍스트에서 %d개 엔티티 추출 / Extracted %d entities from text",
                     len(added_ids), len(added_ids))
        return added_ids

    # ── LLM 연결 / Connect LLM ──

    def connect_llm(self, llm_func: Any) -> None:
        """Gemma 4 연결 / Connect Gemma 4"""
        self._llm_func = llm_func
        logger.info("Gemma 4 연결 완료 / LLM connected")

    # ── 통계 / Statistics ──

    def get_statistics(self) -> Dict[str, Any]:
        """통계 정보 반환 / Return statistics"""
        entity_types: Dict[str, int] = defaultdict(int)
        relation_types: Dict[str, int] = defaultdict(int)
        for e in self._entities.values():
            entity_types[e.entity_type.value] += 1
        for r in self._relations.values():
            relation_types[r.relation_type.value] += 1

        return {
            "total_entities": len(self._entities),
            "total_relations": len(self._relations),
            "max_entities": self.MAX_ENTITIES,
            "max_relations": self.MAX_RELATIONS,
            "entity_types": dict(entity_types),
            "relation_types": dict(relation_types),
        }

    def close(self) -> None:
        """그래프 데이터베이스 종료 / Close graph database"""
        if self._conn:
            self._conn.close()
            self._conn = None
        logger.info("세계 지식 그래프 종료 / World Knowledge Graph closed")
