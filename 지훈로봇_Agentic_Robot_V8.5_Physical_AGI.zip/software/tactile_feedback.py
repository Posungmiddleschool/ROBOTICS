#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — 촉각 피드백 시스템 (Tactile Feedback System)
============================================================

FSR-402 ×3 (좌우 핑거끝 + 손바닥) → ESP32-S3 ADC → UART → Jetson#2
힘 PID 제어: Kp=0.5, Ki=0.01, Kd=0.1, 목표 5N, 최대 10N

V8.5 변경사항 / V8.5 Changes from V8.5:
  - FSR 센서 건전성 모니터링 (FSR sensor health monitoring)
  - 접촉 패턴 분류 (Contact pattern classification)
  - 표면 질감 추정 (Surface texture estimation)

임계값 / Thresholds:
  - 가벼운 접촉 (light touch): 1N
  - 확실 파지 (firm grasp): 5N
  - 과부하 (overload): 50N (센서 한계)
  - 자동 릴리즈: 10N 초과 시

작성일: 2026-05-19
버전: V8.5.5-AGI
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import struct
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V84.TactileFeedback")

# ============================================================================
# 상수 정의 (Constants)
# ============================================================================

FSR_MODEL: str = "FSR-402"
FSR_COUNT: int = 3
FSR_FORCE_MIN_N: float = 0.1
FSR_FORCE_MAX_N: float = 100.0

LIGHT_TOUCH_THRESHOLD_N: float = 1.0
FIRM_GRASP_THRESHOLD_N: float = 5.0
OVERLOAD_THRESHOLD_N: float = 50.0
AUTO_RELEASE_THRESHOLD_N: float = 10.0

FORCE_PID_KP: float = 0.5
FORCE_PID_KI: float = 0.01
FORCE_PID_KD: float = 0.1
TARGET_FORCE_N: float = 5.0
MAX_GRASP_FORCE_N: float = 10.0

ESP32_UART_PORT: str = "/dev/ttyTHS1"
ESP32_UART_BAUDRATE: int = 921600
FORCE_CONTROL_LOOP_HZ: int = 100
FORCE_CONTROL_DT: float = 1.0 / FORCE_CONTROL_LOOP_HZ

FSR_CHANNELS: Dict[str, int] = {
    "finger_left": 0,
    "finger_right": 1,
    "palm": 2,
}

ESP32_ADC_RESOLUTION: int = 12
ESP32_ADC_MAX: int = 4095
ESP32_VREF: float = 3.3
FSR_VOLTAGE_DIVIDER_R: float = 10000.0

FSR_CALIBRATION_TABLE: List[Tuple[float, float]] = [
    (0.0, 0.0), (0.5, 0.1), (1.0, 0.5), (1.5, 1.0),
    (2.0, 2.0), (2.5, 4.0), (3.0, 8.0), (3.3, 100.0),
]

# V8.5: FSR 건전성 모니터링 상수
FSR_HEALTH_STUCK_THRESHOLD = 50       # 연속 동일 ADC값 → 고장 의심
FSR_HEALTH_NOISE_FLOOR = 5           # 정상 노이즈 플로어 (ADC 단위)
FSR_HEALTH_DRIFT_THRESHOLD_PCT = 15  # 영점 드리프트 임계 (%)
FSR_HEALTH_CHECK_INTERVAL_S = 1.0    # 건전성 확인 주기

# V8.5: 접촉 패턴 분류 상수
PATTERN_WINDOW_SIZE = 50              # 패턴 분석 윈도우
PATTERN_FORCE_BINS = 10               # 힘 구간 수
PATTERN_CLASSIFICATION_MIN_SAMPLES = 20

# V8.5: 표면 질감 추정 상수
TEXTURE_WINDOW_SIZE = 100             # 질감 분석 윈도우
TEXTURE_VARIANCE_SMOOTH = 0.3         # 매끄러운 표면 분산 임계
TEXTURE_VARIANCE_ROUGH = 1.5          # 거친 표면 분산 임계
TEXTURE_HIGH_FREQ_THRESHOLD = 5.0     # 고주파 성분 임계 (Hz)

# V8.5 AGI: 질감 분류기 상수 / V8.5 AGI: Texture classifier constants
TEXTURE_CLASSIFIER_FEATURES = ["variance", "high_freq", "roughness_index", "zero_crossing_rate"]
TEXTURE_CLASSIFIER_WINDOW = 200          # 분류용 분석 윈도우 (샘플 수)
TEXTURE_CLASSIFIER_MIN_SAMPLES = 50      # 최소 샘플 수
TEXTURE_CLASSIFIER_UPDATE_HZ = 10        # 분류 업데이트 주파수 (Hz)

# V8.5 AGI: 슬립 감지기 상수 / V8.5 AGI: Slip detector constants
SLIP_DETECT_WINDOW = 30                  # 슬립 감지 윈도우
SLIP_FORCE_DROP_PCT = 20.0              # 힘 강하 비율 임계값 (%)
SLIP_FORCE_RISE_PCT = 15.0             # 힘 상승 비율 임계값 (%)
SLIP_ACCEL_THRESHOLD = 5.0             # 힘 가속도 임계값 (N/s²)
SLIP_CONFIRM_MS = 50                    # 슬립 확정 시간 (ms)
SLIP_RECOVERY_FORCE_BOOST_PCT = 20.0   # 슬립 복구 힘 증가 (%)

# V8.5 AGI: 힘 분포 맵 상수 / V8.5 AGI: Force mapping constants
FORCE_MAP_GRID_SIZE = 16               # 힘 맵 그리드 해상도 (16×16)
FORCE_MAP_SENSOR_POSITIONS = {          # 센서 위치 (정규화된 좌표 0~1)
    "finger_left": (0.3, 0.5),
    "finger_right": (0.7, 0.5),
    "palm": (0.5, 0.2),
}
FORCE_MAP_INTERPOLATION = "rbf"         # 보간 방법 (rbf, bilinear, nearest)
FORCE_MAP_UPDATE_HZ = 50                # 힘 맵 업데이트 주파수


# ============================================================================
# 열거형
# ============================================================================

class TouchState(Enum):
    NO_CONTACT = "no_contact"
    LIGHT_TOUCH = "light_touch"
    FIRM_GRASP = "firm_grasp"
    OVERLOAD = "overload"


class ForceControlState(Enum):
    IDLE = "idle"
    CONTROLLING = "controlling"
    TARGET_REACHED = "target_reached"
    OVERRUN = "overrun"
    ERROR = "error"


# V8.5: FSR 건전성 상태
class FSRHealthStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"           # 성능 저하
    STUCK = "stuck"                 # 값 고정 (고장)
    DRIFTED = "drifted"             # 영점 드리프트
    FAILED = "failed"               # 완전 고장


# V8.5: 접촉 패턴 분류
class ContactPattern(Enum):
    NO_CONTACT = "no_contact"       # 무접촉
    POINT_CONTACT = "point_contact"  # 점 접촉 (뾰족한 물체)
    LINE_CONTACT = "line_contact"    # 선 접촉 (가장자리)
    SURFACE_CONTACT = "surface_contact"  # 면 접촉 (평면 물체)
    IRREGULAR = "irregular"          # 불규칙 (복잡 형상)


# V8.5: 표면 질감 추정
class SurfaceTexture(Enum):
    SMOOTH = "smooth"           # 매끄러운 (유리, 금속)
    SLIGHTLY_ROUGH = "slightly_rough"  # 약간 거친 (종이, 플라스틱)
    ROUGH = "rough"             # 거친 (나무, 직물)
    VERY_ROUGH = "very_rough"   # 매우 거친 (사포, 거친 돌)
    UNKNOWN = "unknown"


# V8.5 AGI: 슬립 상태 열거형 / V8.5 AGI: Slip state enumeration
class SlipState(Enum):
    """V8.5 AGI: 슬립 상태 / Slip detection state."""
    STABLE = "stable"           # 안정 파지
    SLIP_WARNING = "slip_warning"  # 슬립 경고
    SLIP_CONFIRMED = "slip_confirmed"  # 슬립 확정
    RECOVERING = "recovering"    # 슬립 복구 중


# ============================================================================
# V8.5 데이터 클래스
# ============================================================================

@dataclass
class FSRReading:
    """단일 FSR 센서 판독값"""
    channel: str = ""
    raw_adc: int = 0
    voltage_v: float = 0.0
    force_n: float = 0.0
    touch_state: TouchState = TouchState.NO_CONTACT
    timestamp: float = field(default_factory=time.monotonic)


@dataclass
class ForcePIDState:
    """힘 PID 제어기 상태"""
    target_force_n: float = TARGET_FORCE_N
    current_force_n: float = 0.0
    error: float = 0.0
    integral: float = 0.0
    derivative: float = 0.0
    output: float = 0.0
    control_state: ForceControlState = ForceControlState.IDLE


@dataclass
class FSRHealthData:
    """V8.5: FSR 센서 건전성 데이터"""
    channel: str = ""
    status: FSRHealthStatus = FSRHealthStatus.HEALTHY
    consecutive_same_adc: int = 0
    zero_drift_pct: float = 0.0
    noise_level: float = 0.0
    last_check_time: float = 0.0
    total_readings: int = 0
    stuck_readings: int = 0


@dataclass
class ContactPatternData:
    """V8.5: 접촉 패턴 데이터"""
    pattern: ContactPattern = ContactPattern.NO_CONTACT
    confidence: float = 0.0
    force_distribution: List[float] = field(default_factory=lambda: [0.0] * PATTERN_FORCE_BINS)
    asymmetry_index: float = 0.0  # 좌우 비대칭 지수
    temporal_stability: float = 1.0  # 시간적 안정성 (0~1)


@dataclass
class SurfaceTextureData:
    """V8.5: 표면 질감 데이터"""
    texture: SurfaceTexture = SurfaceTexture.UNKNOWN
    confidence: float = 0.0
    force_variance: float = 0.0
    high_freq_content: float = 0.0
    roughness_index: float = 0.0   # 0=매끈, 1=매우 거침


@dataclass
class TextureClassificationResult:
    """V8.5 AGI: 질감 분류 결과 / Texture classification result."""
    texture: SurfaceTexture = SurfaceTexture.UNKNOWN
    confidence: float = 0.0
    features: Dict[str, float] = field(default_factory=dict)
    classified_at: float = 0.0
    sample_count: int = 0


@dataclass
class SlipDetectionResult:
    """V8.5 AGI: 슬립 감지 결과 / Slip detection result."""
    state: SlipState = SlipState.STABLE
    force_drop_pct: float = 0.0
    force_rise_pct: float = 0.0
    acceleration_n_s2: float = 0.0
    detected_at: float = 0.0
    confirmation_ms: float = 0.0
    recommended_force_boost_pct: float = 0.0


@dataclass
class ForceMapPoint:
    """V8.5 AGI: 힘 맵 포인트 / Force map point."""
    x: float = 0.0       # 정규화된 x 좌표 (0~1)
    y: float = 0.0       # 정규화된 y 좌표 (0~1)
    force_n: float = 0.0 # 해당 위치 힘 (N)


@dataclass
class ForceDistributionMap:
    """V8.5 AGI: 힘 분포 맵 / Force distribution map."""
    grid_size: int = FORCE_MAP_GRID_SIZE
    forces: List[List[float]] = field(default_factory=list)
    total_force_n: float = 0.0
    peak_force_n: float = 0.0
    peak_position: Tuple[float, float] = (0.5, 0.5)
    center_of_force: Tuple[float, float] = (0.5, 0.5)
    update_time: float = 0.0


# ============================================================================
# TactileFeedback V8.5
# ============================================================================

class TactileFeedback:
    """
    촉각 피드백 시스템 V8.5

    V8.5 신규 기능:
    - FSR 센서 건전성 모니터링
    - 접촉 패턴 분류
    - 표면 질감 추정
    """

    def __init__(
        self,
        uart_port: str = ESP32_UART_PORT,
        baudrate: int = ESP32_UART_BAUDRATE,
        simulation_mode: bool = True,
    ):
        self._uart_port = uart_port
        self._baudrate = baudrate
        self._simulation = simulation_mode
        self._serial = None
        self._lock = threading.Lock()
        self._running = False

        self._readings: Dict[str, FSRReading] = {
            name: FSRReading(channel=name) for name in FSR_CHANNELS
        }
        self._history: Dict[str, deque] = {
            name: deque(maxlen=1000) for name in FSR_CHANNELS
        }

        self._pid = ForcePIDState()
        self._pid_kp = FORCE_PID_KP
        self._pid_ki = FORCE_PID_KI
        self._pid_kd = FORCE_PID_KD
        self._prev_error: float = 0.0
        self._force_control_enabled: bool = False
        self._force_callback: Optional[Callable] = None
        self._auto_release_callback: Optional[Callable] = None

        self._rx_thread: Optional[threading.Thread] = None
        self._sample_count: int = 0
        self._overload_count: int = 0

        # V8.5: FSR 건전성 데이터
        self._fsr_health: Dict[str, FSRHealthData] = {
            name: FSRHealthData(channel=name) for name in FSR_CHANNELS
        }
        self._prev_adc: Dict[str, int] = {name: 0 for name in FSR_CHANNELS}
        self._consecutive_same: Dict[str, int] = {name: 0 for name in FSR_CHANNELS}

        # V8.5: 접촉 패턴 데이터
        self._contact_pattern: ContactPatternData = ContactPatternData()
        self._pattern_force_history: deque = deque(maxlen=PATTERN_WINDOW_SIZE)

        # V8.5: 표면 질감 데이터
        self._surface_texture: SurfaceTextureData = SurfaceTextureData()
        self._texture_force_history: deque = deque(maxlen=TEXTURE_WINDOW_SIZE)

        logger.info("TactileFeedback V8.5 초기화 완료 "
                     f"(simulation={simulation_mode})")

    # ── 시작/중지 ──

    def start(self) -> bool:
        if self._running:
            return True

        if not self._simulation:
            try:
                import serial
                self._serial = serial.Serial(
                    port=self._uart_port,
                    baudrate=self._baudrate,
                    bytesize=8, parity='N', stopbits=1,
                    timeout=0.01,
                )
            except Exception as e:
                logger.warning(f"UART 연결 실패: {e}")
                self._simulation = True

        self._running = True
        self._rx_thread = threading.Thread(
            target=self._rx_loop, daemon=True,
            name="TactileFeedback_RX"
        )
        self._rx_thread.start()

        logger.info("TactileFeedback V8.5 시작")
        return True

    def stop(self) -> None:
        self._running = False
        self._force_control_enabled = False
        if self._rx_thread and self._rx_thread.is_alive():
            self._rx_thread.join(timeout=1.0)
        if self._serial and self._serial.is_open:
            self._serial.close()
        logger.info("TactileFeedback V8.5 중지")

    # ── UART 수신 루프 ──

    def _rx_loop(self) -> None:
        while self._running:
            if self._simulation:
                self._simulate_readings()
                time.sleep(FORCE_CONTROL_DT)
                continue

            try:
                if self._serial and self._serial.is_open:
                    data = self._serial.read(5)
                    if len(data) == 5 and data[0] == 0xAA:
                        ch = data[1]
                        adc_raw = (data[2] << 8) | data[3]
                        crc = data[4]
                        if (0xAA ^ ch ^ data[2] ^ data[3]) == crc:
                            self._update_reading(ch, adc_raw)
            except Exception as e:
                logger.debug(f"UART 수신 오류: {e}")
                time.sleep(0.001)

    def _simulate_readings(self) -> None:
        base_force = self._pid.target_force_n if self._force_control_enabled else 0.0
        noise = (hash(time.monotonic_ns()) % 100 - 50) / 100.0

        for name, ch in FSR_CHANNELS.items():
            if name == "palm":
                force = base_force * 0.3 + noise * 0.5
            else:
                force = base_force * 0.5 + noise

            force = max(0.0, force)
            self._update_force(name, force)

    def _update_reading(self, channel: int, adc_raw: int) -> None:
        name = None
        for n, ch in FSR_CHANNELS.items():
            if ch == channel:
                name = n
                break
        if name is None:
            return

        voltage = (adc_raw / ESP32_ADC_MAX) * ESP32_VREF
        force = self._voltage_to_force(voltage)

        # V8.5: FSR 건전성 업데이트
        self._update_fsr_health(name, adc_raw)

        self._update_force(name, force)

    def _update_force(self, name: str, force_n: float) -> None:
        reading = self._readings[name]
        reading.force_n = force_n
        reading.timestamp = time.monotonic()

        if force_n >= OVERLOAD_THRESHOLD_N:
            reading.touch_state = TouchState.OVERLOAD
            self._overload_count += 1
        elif force_n >= FIRM_GRASP_THRESHOLD_N:
            reading.touch_state = TouchState.FIRM_GRASP
        elif force_n >= LIGHT_TOUCH_THRESHOLD_N:
            reading.touch_state = TouchState.LIGHT_TOUCH
        else:
            reading.touch_state = TouchState.NO_CONTACT

        self._history[name].append((reading.timestamp, force_n))
        self._sample_count += 1

        # V8.5: 패턴 및 질감 데이터 업데이트
        self._pattern_force_history.append(force_n)
        self._texture_force_history.append(force_n)

        if force_n > AUTO_RELEASE_THRESHOLD_N and self._force_control_enabled:
            logger.warning(f"과부하 감지 {name}: {force_n:.1f}N")
            self._force_control_enabled = False
            if self._auto_release_callback:
                try:
                    self._auto_release_callback()
                except Exception:
                    pass

    # ── V8.5: FSR 센서 건전성 모니터링 ──

    def _update_fsr_health(self, name: str, adc_raw: int) -> FSRHealthData:
        """
        V8.5: FSR 센서 건전성 업데이트 / Update FSR sensor health.

        검사 항목:
        1. 정지 감지: ADC 값이 연속 동일 → 고장 의심
        2. 영점 드리프트: 무부하 시 ADC 값이 0에서 멀어짐
        3. 노이즈 레벨: 정상 범위 내 노이즈 확인
        """
        health = self._fsr_health[name]
        health.total_readings += 1

        # 1. 정지 감지
        if adc_raw == self._prev_adc.get(name, 0):
            self._consecutive_same[name] = self._consecutive_same.get(name, 0) + 1
        else:
            self._consecutive_same[name] = 0

        health.consecutive_same_adc = self._consecutive_same[name]

        if health.consecutive_same_adc >= FSR_HEALTH_STUCK_THRESHOLD:
            health.status = FSRHealthStatus.STUCK
            health.stuck_readings += 1
            logger.error(
                "FSR 고장 의심 (정지) — %s: %d회 연속 동일 ADC값 (%d)",
                name, health.consecutive_same_adc, adc_raw,
            )

        # 2. 영점 드리프트 (무부하 시 ADC가 0이어야 함)
        if adc_raw > ESP32_ADC_MAX * 0.05:  # 5% 이상 → 드리프트
            drift_pct = (adc_raw / ESP32_ADC_MAX) * 100
            health.zero_drift_pct = drift_pct
            if drift_pct > FSR_HEALTH_DRIFT_THRESHOLD_PCT:
                health.status = FSRHealthStatus.DRIFTED
                logger.warning(
                    "FSR 영점 드리프트 — %s: %.1f%%", name, drift_pct,
                )

        # 3. 노이즈 레벨 (건전한 센서는 약간의 노이즈 있음)
        prev = self._prev_adc.get(name, 0)
        noise = abs(adc_raw - prev)
        health.noise_level = noise

        # 정상: 약간의 노이즈, 비정상: 완전 무노이즈(고장) 또는 과도한 노이즈
        if health.consecutive_same_adc < FSR_HEALTH_STUCK_THRESHOLD:
            if health.zero_drift_pct < FSR_HEALTH_DRIFT_THRESHOLD_PCT:
                health.status = FSRHealthStatus.HEALTHY
            elif health.status != FSRHealthStatus.STUCK:
                health.status = FSRHealthStatus.DEGRADED

        self._prev_adc[name] = adc_raw
        health.last_check_time = time.monotonic()

        return health

    def get_fsr_health(self, channel: Optional[str] = None) -> Any:
        """
        V8.5: FSR 건전성 조회 / Get FSR sensor health.

        Args:
            channel: 채널 이름, None이면 전체

        Returns:
            FSRHealthData 또는 Dict[str, FSRHealthData]
        """
        with self._lock:
            if channel:
                return self._fsr_health.get(channel)
            return dict(self._fsr_health)

    # ── V8.5: 접촉 패턴 분류 ──

    def classify_contact_pattern(self) -> ContactPatternData:
        """
        V8.5: 접촉 패턴 분류 / Classify contact pattern.

        3개 FSR 채널의 힘 분포를 분석하여
        접촉 패턴을 분류.

        패턴:
        - NO_CONTACT: 모든 채널 < 1N
        - POINT_CONTACT: 1개 채널만 높은 힘
        - LINE_CONTACT: 2개 인접 채널이 비슷한 힘
        - SURFACE_CONTACT: 3개 채널이 비슷한 힘
        - IRREGULAR: 불규칙한 힘 분포
        """
        with self._lock:
            forces = {
                name: self._readings[name].force_n
                for name in FSR_CHANNELS
            }

            left = forces.get("finger_left", 0.0)
            right = forces.get("finger_right", 0.0)
            palm = forces.get("palm", 0.0)

            total = left + right + palm
            pattern_data = self._contact_pattern

            if total < LIGHT_TOUCH_THRESHOLD_N:
                pattern_data.pattern = ContactPattern.NO_CONTACT
                pattern_data.confidence = 1.0
                return pattern_data

            # 힘 분포 분석
            force_list = [left, right, palm]
            max_force = max(force_list)
            active_count = sum(1 for f in force_list if f > LIGHT_TOUCH_THRESHOLD_N)

            # 비대칭 지수
            if left + right > 0.01:
                pattern_data.asymmetry_index = abs(left - right) / (left + right)
            else:
                pattern_data.asymmetry_index = 0.0

            # 시간적 안정성 (최근 윈도우 내 분산 기반)
            if len(self._pattern_force_history) >= PATTERN_CLASSIFICATION_MIN_SAMPLES:
                recent = list(self._pattern_force_history)[-PATTERN_CLASSIFICATION_MIN_SAMPLES:]
                mean_f = sum(recent) / len(recent)
                if mean_f > 0.01:
                    var_f = sum((f - mean_f) ** 2 for f in recent) / len(recent)
                    pattern_data.temporal_stability = max(0.0, 1.0 - var_f / (mean_f ** 2))

            # 패턴 분류
            if active_count == 1:
                pattern_data.pattern = ContactPattern.POINT_CONTACT
                pattern_data.confidence = 0.8
            elif active_count == 2:
                # 좌우 핑거만 또는 핑거+손바닥
                if palm < LIGHT_TOUCH_THRESHOLD_N:
                    pattern_data.pattern = ContactPattern.LINE_CONTACT
                    pattern_data.confidence = 0.7
                else:
                    pattern_data.pattern = ContactPattern.IRREGULAR
                    pattern_data.confidence = 0.5
            elif active_count == 3:
                # 세 채널 모두 활성 → 면 접촉 또는 파지
                force_ratio = min(force_list) / max(force_list) if max_force > 0 else 0
                if force_ratio > 0.5:
                    pattern_data.pattern = ContactPattern.SURFACE_CONTACT
                    pattern_data.confidence = 0.8
                else:
                    pattern_data.pattern = ContactPattern.IRREGULAR
                    pattern_data.confidence = 0.6

            # 힘 분포 저장
            max_f = max(force_list) if max(force_list) > 0 else 1.0
            pattern_data.force_distribution = [f / max_f for f in force_list]

            return pattern_data

    def get_contact_pattern(self) -> ContactPatternData:
        """V8.5: 접촉 패턴 조회."""
        return self.classify_contact_pattern()

    # ── V8.5: 표면 질감 추정 ──

    def estimate_surface_texture(self) -> SurfaceTextureData:
        """
        V8.5: 표면 질감 추정 / Estimate surface texture.

        FSR 힘 시계열의 통계적 특성으로 표면 질감 추정:
        - 매끄러운 표면: 힘 변동이 작음 (낮은 분산)
        - 거친 표면: 힘 변동이 큼 (높은 분산)
        - 고주파 성분: 미세한 요철에 의한 빠른 변동
        """
        with self._lock:
            texture_data = self._surface_texture

            if len(self._texture_force_history) < 10:
                texture_data.texture = SurfaceTexture.UNKNOWN
                texture_data.confidence = 0.0
                return texture_data

            forces = list(self._texture_force_history)

            # 1. 분산 계산 (질감의 거칠기)
            mean_force = sum(forces) / len(forces)
            variance = sum((f - mean_force) ** 2 for f in forces) / len(forces)
            texture_data.force_variance = variance

            # 2. 고주파 성분 (인접 샘플 간 차이)
            high_freq_sum = 0.0
            for i in range(1, len(forces)):
                high_freq_sum += abs(forces[i] - forces[i - 1])
            high_freq = high_freq_sum / max(len(forces) - 1, 1)
            texture_data.high_freq_content = high_freq

            # 3. 거칠기 지수 (0=매끈, 1=매우 거침)
            roughness = min(1.0, variance / (TEXTURE_VARIANCE_ROUGH * 10))
            texture_data.roughness_index = roughness

            # 4. 질감 분류
            if variance < TEXTURE_VARIANCE_SMOOTH:
                texture_data.texture = SurfaceTexture.SMOOTH
                texture_data.confidence = 0.7
            elif variance < TEXTURE_VARIANCE_ROUGH * 0.5:
                texture_data.texture = SurfaceTexture.SLIGHTLY_ROUGH
                texture_data.confidence = 0.6
            elif variance < TEXTURE_VARIANCE_ROUGH:
                texture_data.texture = SurfaceTexture.ROUGH
                texture_data.confidence = 0.7
            else:
                texture_data.texture = SurfaceTexture.VERY_ROUGH
                texture_data.confidence = 0.6

            # 고주파 성분으로 보정
            if high_freq > TEXTURE_HIGH_FREQ_THRESHOLD:
                # 고주파가 높으면 한 단계 거칠게
                if texture_data.texture == SurfaceTexture.SMOOTH:
                    texture_data.texture = SurfaceTexture.SLIGHTLY_ROUGH
                elif texture_data.texture == SurfaceTexture.SLIGHTLY_ROUGH:
                    texture_data.texture = SurfaceTexture.ROUGH

            return texture_data

    def get_surface_texture(self) -> SurfaceTextureData:
        """V8.5: 표면 질감 조회."""
        return self.estimate_surface_texture()

    # ── 기존 기능 (그대로 유지) ──

    def _voltage_to_force(self, voltage: float) -> float:
        if voltage <= 0.0:
            return 0.0
        for i in range(len(FSR_CALIBRATION_TABLE) - 1):
            v0, f0 = FSR_CALIBRATION_TABLE[i]
            v1, f1 = FSR_CALIBRATION_TABLE[i + 1]
            if v0 <= voltage <= v1:
                t = (voltage - v0) / (v1 - v0) if (v1 - v0) > 0 else 0.0
                return f0 + t * (f1 - f0)
        return FSR_CALIBRATION_TABLE[-1][1]

    def read_force(self, channel: str = "combined") -> float:
        with self._lock:
            if channel == "combined":
                left = self._readings["finger_left"].force_n
                right = self._readings["finger_right"].force_n
                return left + right
            elif channel in self._readings:
                return self._readings[channel].force_n
            else:
                return 0.0

    def read_all_forces(self) -> Dict[str, FSRReading]:
        with self._lock:
            return dict(self._readings)

    def get_touch_state(self, channel: str = "combined") -> TouchState:
        if channel == "combined":
            max_state = TouchState.NO_CONTACT
            for name in ["finger_left", "finger_right", "palm"]:
                state = self._readings[name].touch_state
                if state.value > max_state.value:
                    max_state = state
            return max_state
        return self._readings.get(channel, FSRReading()).touch_state

    def set_target_force(self, force_n: float) -> bool:
        force_n = max(0.0, min(MAX_GRASP_FORCE_N, force_n))
        with self._lock:
            self._pid.target_force_n = force_n
        return True

    def enable_force_control(self) -> bool:
        if self._force_control_enabled:
            return True
        self._force_control_enabled = True
        self._pid.control_state = ForceControlState.CONTROLLING
        self._prev_error = 0.0
        self._pid.integral = 0.0
        self._ctrl_thread = threading.Thread(
            target=self._force_control_loop, daemon=True,
            name="ForceControl_Loop"
        )
        self._ctrl_thread.start()
        return True

    def disable_force_control(self) -> bool:
        self._force_control_enabled = False
        self._pid.control_state = ForceControlState.IDLE
        return True

    def _force_control_loop(self) -> None:
        while self._force_control_enabled and self._running:
            try:
                current_force = self.read_force("combined")
                self._pid.current_force_n = current_force

                error = self._pid.target_force_n - current_force
                self._pid.error = error

                self._pid.integral += error * FORCE_CONTROL_DT
                self._pid.integral = max(-10.0, min(10.0, self._pid.integral))

                self._pid.derivative = (error - self._prev_error) / FORCE_CONTROL_DT
                self._prev_error = error

                output = (self._pid_kp * error +
                          self._pid_ki * self._pid.integral +
                          self._pid_kd * self._pid.derivative)
                self._pid.output = output

                if abs(error) < 0.5:
                    self._pid.control_state = ForceControlState.TARGET_REACHED
                elif current_force > AUTO_RELEASE_THRESHOLD_N:
                    self._pid.control_state = ForceControlState.OVERRUN
                    self._force_control_enabled = False
                    if self._auto_release_callback:
                        self._auto_release_callback()
                else:
                    self._pid.control_state = ForceControlState.CONTROLLING

                self._send_force_command(output)

            except Exception as e:
                logger.error(f"힘 제어 루프 오류: {e}")
                self._pid.control_state = ForceControlState.ERROR

            time.sleep(FORCE_CONTROL_DT)

    def _send_force_command(self, output: float) -> None:
        if self._simulation:
            return
        try:
            if self._serial and self._serial.is_open:
                cmd = 0x01
                data_int = int(max(-1000, min(1000, output * 100)))
                data_h = (data_int >> 8) & 0xFF
                data_l = data_int & 0xFF
                crc = 0xBB ^ cmd ^ data_h ^ data_l
                packet = bytes([0xBB, cmd, data_h, data_l, crc])
                self._serial.write(packet)
        except Exception as e:
            logger.debug(f"힘 제어 명령 전송 실패: {e}")

    def set_auto_release_callback(self, callback: Callable) -> None:
        self._auto_release_callback = callback

    def set_force_callback(self, callback: Callable) -> None:
        self._force_callback = callback

    def get_pid_state(self) -> ForcePIDState:
        return self._pid

    def get_statistics(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "sample_count": self._sample_count,
                "overload_count": self._overload_count,
                "force_control_enabled": self._force_control_enabled,
                "current_forces_n": {
                    name: reading.force_n
                    for name, reading in self._readings.items()
                },
                "target_force_n": self._pid.target_force_n,
                "pid_output": self._pid.output,
                # V8.5 추가
                "fsr_health": {
                    name: health.status.value
                    for name, health in self._fsr_health.items()
                },
                "contact_pattern": self._contact_pattern.pattern.value,
                "surface_texture": self._surface_texture.texture.value,
            }

    def get_force_history(self, channel: str,
                          duration_s: float = 1.0) -> List[Tuple[float, float]]:
        if channel not in self._history:
            return []
        cutoff = time.monotonic() - duration_s
        return [(t, f) for t, f in self._history[channel] if t >= cutoff]

    # ========================================================================
    # V8.5 AGI: 질감 분류기 (Texture Classifier)
    # ========================================================================

    def classify_texture(self, channel: str = "combined") -> TextureClassificationResult:
        """
        V8.5 AGI: 표면 질감 분류 / Classify surface texture.

        FSR 힘 시계열에서 다중 특징을 추출하여
        표면 질감을 분류. 기존 estimate_surface_texture보다
        더 정교한 분류 제공.

        특징 추출:
        1. 분산 (variance): 힘 변동의 크기
        2. 고주파 성분 (high_freq): 인접 샘플 간 차이의 평균
        3. 거칠기 지수 (roughness_index): 0~1 정규화
        4. 영교차율 (zero_crossing_rate): 힘 변화 방향 전환 빈도

        분류 기준:
        - SMOOTH: 분산 < 0.3, 고주파 < 0.5
        - SLIGHTLY_ROUGH: 분산 0.3~0.7
        - ROUGH: 분산 0.7~1.5
        - VERY_ROUGH: 분산 > 1.5 또는 고주파 > 5.0

        Args:
            channel: 채널 이름 (기본: combined)

        Returns:
            질감 분류 결과
        """
        result = TextureClassificationResult()

        # 힘 이력 확보 / Get force history
        if channel == "combined":
            # 모든 채널의 힘 합산 이력 사용
            forces = list(self._texture_force_history)
        elif channel in self._history:
            recent = list(self._history[channel])[-TEXTURE_CLASSIFIER_WINDOW:]
            forces = [f for _, f in recent]
        else:
            return result

        if len(forces) < TEXTURE_CLASSIFIER_MIN_SAMPLES:
            result.texture = SurfaceTexture.UNKNOWN
            result.confidence = 0.0
            return result

        # 특징 추출 / Feature extraction
        mean_force = sum(forces) / len(forces)

        # 1. 분산 / Variance
        variance = sum((f - mean_force) ** 2 for f in forces) / len(forces)

        # 2. 고주파 성분 / High frequency content
        high_freq_sum = 0.0
        for i in range(1, len(forces)):
            high_freq_sum += abs(forces[i] - forces[i - 1])
        high_freq = high_freq_sum / max(len(forces) - 1, 1)

        # 3. 거칠기 지수 / Roughness index
        roughness_index = min(1.0, variance / (TEXTURE_VARIANCE_ROUGH * 10))

        # 4. 영교차율 / Zero-crossing rate (평균 편차 기준)
        mean_deviation = [f - mean_force for f in forces]
        zero_crossings = 0
        for i in range(1, len(mean_deviation)):
            if mean_deviation[i - 1] * mean_deviation[i] < 0:
                zero_crossings += 1
        zero_crossing_rate = zero_crossings / max(len(mean_deviation) - 1, 1)

        # 특징 벡터 저장 / Store feature vector
        result.features = {
            "variance": round(variance, 4),
            "high_freq": round(high_freq, 4),
            "roughness_index": round(roughness_index, 4),
            "zero_crossing_rate": round(zero_crossing_rate, 4),
        }
        result.sample_count = len(forces)

        # 분류 / Classification
        if variance < TEXTURE_VARIANCE_SMOOTH and high_freq < 0.5:
            result.texture = SurfaceTexture.SMOOTH
            result.confidence = 0.85
        elif variance < 0.7 and high_freq < 2.0:
            result.texture = SurfaceTexture.SLIGHTLY_ROUGH
            result.confidence = 0.75
        elif variance < TEXTURE_VARIANCE_ROUGH:
            result.texture = SurfaceTexture.ROUGH
            result.confidence = 0.80
        else:
            result.texture = SurfaceTexture.VERY_ROUGH
            result.confidence = 0.70

        # 영교차율로 신뢰도 보정 / Adjust confidence with zero-crossing rate
        if zero_crossing_rate > 0.4:
            result.confidence *= 0.9  # 노이즈가 많으면 신뢰도 감소

        # 고주파 성분으로 보정 / Adjust with high freq
        if high_freq > TEXTURE_HIGH_FREQ_THRESHOLD:
            # 고주파가 높으면 한 단계 거칠게, 신뢰도 약간 증가
            if result.texture == SurfaceTexture.SMOOTH:
                result.texture = SurfaceTexture.SLIGHTLY_ROUGH
            elif result.texture == SurfaceTexture.SLIGHTLY_ROUGH:
                result.texture = SurfaceTexture.ROUGH
            result.confidence = min(1.0, result.confidence * 1.1)

        result.classified_at = time.monotonic()
        return result

    # ========================================================================
    # V8.5 AGI: 슬립 감지기 (Slip Detector)
    # ========================================================================

    def detect_slip(self, channel: str = "combined") -> SlipDetectionResult:
        """
        V8.5 AGI: 실시간 슬립 감지 / Real-time slip detection.

        파지 중 물체가 미끄러지는 것을 실시간으로 감지.
        기존 그리퍼의 슬립 감지보다 더 빠르고 정확.

        감지 방법:
        1. 힘 급강하: 짧은 시간에 힘이 N% 이상 감소
        2. 힘 급상승: 물체가 재파지될 때 힘이 급증
        3. 힘 가속도: 힘 변화율의 변화율 (2차 미분)이 임계값 초과

        복구 권장:
        - 슬립 감지 시 파지력을 N% 증가시키는 것을 권장

        Args:
            channel: 채널 이름

        Returns:
            슬립 감지 결과
        """
        result = SlipDetectionResult()

        # 힘 이력 확보 / Get force history
        if channel == "combined":
            forces = list(self._texture_force_history)[-SLIP_DETECT_WINDOW:]
        elif channel in self._history:
            recent = list(self._history[channel])[-SLIP_DETECT_WINDOW:]
            forces = [f for _, f in recent]
        else:
            return result

        if len(forces) < 5:
            return result

        # 1. 힘 급강하 감지 / Detect force drop
        current_force = forces[-1]
        baseline_force = sum(forces[:-5]) / max(len(forces) - 5, 1)
        if baseline_force > 0.5:
            force_drop_pct = ((baseline_force - current_force) / baseline_force) * 100.0
        else:
            force_drop_pct = 0.0
        result.force_drop_pct = force_drop_pct

        # 2. 힘 급상승 감지 / Detect force rise
        prev_force = forces[-2] if len(forces) >= 2 else current_force
        if prev_force > 0.1:
            force_rise_pct = ((current_force - prev_force) / prev_force) * 100.0
        else:
            force_rise_pct = 0.0
        result.force_rise_pct = abs(force_rise_pct)

        # 3. 힘 가속도 계산 / Calculate force acceleration
        if len(forces) >= 3:
            velocity_1 = forces[-1] - forces[-2]
            velocity_2 = forces[-2] - forces[-3]
            acceleration = abs(velocity_1 - velocity_2) * FORCE_CONTROL_LOOP_HZ
        else:
            acceleration = 0.0
        result.acceleration_n_s2 = acceleration

        # 슬립 판정 / Determine slip state
        is_slip_indicated = (
            force_drop_pct > SLIP_FORCE_DROP_PCT or
            force_rise_pct > SLIP_FORCE_RISE_PCT or
            acceleration > SLIP_ACCEL_THRESHOLD
        )

        if is_slip_indicated:
            # 슬립 감지 시간 확인 / Check slip confirmation time
            if not hasattr(self, '_slip_start_time'):
                self._slip_start_time = time.monotonic()
                result.state = SlipState.SLIP_WARNING
            else:
                elapsed_ms = (time.monotonic() - self._slip_start_time) * 1000.0
                result.confirmation_ms = elapsed_ms
                if elapsed_ms > SLIP_CONFIRM_MS:
                    result.state = SlipState.SLIP_CONFIRMED
                    result.recommended_force_boost_pct = SLIP_RECOVERY_FORCE_BOOST_PCT
                    result.detected_at = time.monotonic()
                    logger.warning(
                        "V8.5 AGI: 슬립 확정 — 강하=%.1f%%, 상승=%.1f%%, 가속도=%.1fN/s²",
                        force_drop_pct, force_rise_pct, acceleration,
                    )
                else:
                    result.state = SlipState.SLIP_WARNING
        else:
            # 슬립 아님 / No slip
            if hasattr(self, '_slip_start_time'):
                # 이전 슬립에서 복구 중 / Recovering from previous slip
                result.state = SlipState.RECOVERING
                del self._slip_start_time
            else:
                result.state = SlipState.STABLE

        return result

    # ========================================================================
    # V8.5 AGI: 힘 분포 맵 (Force Mapping)
    # ========================================================================

    def compute_force_map(self) -> ForceDistributionMap:
        """
        V8.5 AGI: 힘 분포 맵 계산 / Compute force distribution map.

        3개 FSR 센서의 힘 값을 바탕으로
        그리퍼 접촉면 전체의 힘 분포를 추정.

        방법:
        1. 각 센서의 위치와 힘 값을 획득
        2. RBF (Radial Basis Function) 보간으로
           센서 사이의 힘 분포 추정
        3. 그리드 맵으로 변환

        용도:
        - 파지 안정성 평가
        - 힘 중심(center of force) 계산
        - 불균형 파지 감지

        Returns:
            힘 분포 맵
        """
        fmap = ForceDistributionMap()

        # 센서 힘 값 획득 / Get sensor force values
        sensor_forces: Dict[str, float] = {}
        with self._lock:
            for name in FSR_CHANNELS:
                sensor_forces[name] = self._readings[name].force_n

        # 빈 그리드 초기화 / Initialize empty grid
        n = fmap.grid_size
        fmap.forces = [[0.0] * n for _ in range(n)]

        # RBF 보간 / RBF interpolation
        # 각 그리드 포인트에서 가중 평균으로 힘 추정
        sigma = 0.25  # RBF 확산 파라미터 (그리퍼 크기 기반)

        for gy in range(n):
            for gx in range(n):
                # 정규화된 좌표 / Normalized coordinates
                nx_coord = gx / (n - 1)
                ny_coord = gy / (n - 1)

                total_weight = 0.0
                weighted_force = 0.0

                for sensor_name, force in sensor_forces.items():
                    if sensor_name not in FORCE_MAP_SENSOR_POSITIONS:
                        continue
                    sx, sy = FORCE_MAP_SENSOR_POSITIONS[sensor_name]

                    # RBF 가중치 / RBF weight
                    dist_sq = (nx_coord - sx) ** 2 + (ny_coord - sy) ** 2
                    weight = math.exp(-dist_sq / (2 * sigma ** 2))

                    weighted_force += weight * force
                    total_weight += weight

                if total_weight > 0:
                    fmap.forces[gy][gx] = weighted_force / total_weight

        # 통계 계산 / Calculate statistics
        total_force = 0.0
        peak_force = 0.0
        peak_x, peak_y = 0.5, 0.5
        moment_x = 0.0
        moment_y = 0.0

        for gy in range(n):
            for gx in range(n):
                f = fmap.forces[gy][gx]
                total_force += f
                if f > peak_force:
                    peak_force = f
                    peak_x = gx / (n - 1)
                    peak_y = gy / (n - 1)
                moment_x += f * (gx / (n - 1))
                moment_y += f * (gy / (n - 1))

        fmap.total_force_n = total_force
        fmap.peak_force_n = peak_force
        fmap.peak_position = (peak_x, peak_y)

        # 힘 중심 계산 / Calculate center of force
        if total_force > 0:
            fmap.center_of_force = (moment_x / total_force, moment_y / total_force)
        else:
            fmap.center_of_force = (0.5, 0.5)

        fmap.update_time = time.monotonic()
        return fmap
