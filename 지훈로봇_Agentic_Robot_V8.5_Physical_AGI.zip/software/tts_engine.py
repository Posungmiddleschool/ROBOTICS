#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TTS 엔진 (Text-to-Speech Engine)
=================================================

myshell-ai/MeloTTS-Korean → Jetson#2 CPU 추론, 24kHz 출력

특징:
  - VRAM: ~300MB (MeloTTS-Korean)
  - 감정 매핑: happy/sad/angry/neutral/excited
  - 자연스러운 한국어 발화
  - 지연 <200ms (첫 샘플)
  - 출력: MAX98357A I2S 앰프 → 3W 스피커 ×2 (L/R)
  - 감정 태그 텍스트 지원

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import asyncio
import io
import logging
import os
import queue
import struct
import threading
import time
import wave
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any, AsyncIterator, Callable, Dict, Generator, List, Optional, Tuple

import numpy as np

# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

DEFAULT_SAMPLE_RATE = 24000        # MeloTTS 출력 24kHz
DEFAULT_SPEED = 1.0                # 기본 말하기 속도
FIRST_SAMPLE_TARGET_MS = 200       # 첫 샘플 목표 지연 (ms)
MELOTTS_VRAM_MB = 300              # MeloTTS VRAM 사용량
I2S_DEVICE = "MAX98357A"          # I2S 앰프 장치명
SPEAKER_COUNT = 2                  # 좌/우 스피커
SPEAKER_WATT = 3                   # 스피커 출력 (W)
EMOTION_TAG_PATTERN = r"<(happy|sad|angry|neutral|excited)>"  # 감정 태그 패턴

logger = logging.getLogger("jihun.v84.tts_engine")
logger.setLevel(logging.DEBUG)


# ──────────────────────────────────────────────────────────────────────────────
# 열거형 / Enumerations
# ──────────────────────────────────────────────────────────────────────────────

class Emotion(Enum):
    """감정 / Emotion types"""
    NEUTRAL = "neutral"
    HAPPY = "happy"
    SAD = "sad"
    ANGRY = "angry"
    EXCITED = "excited"


class TTSStatus(Enum):
    """TTS 상태 / TTS status"""
    IDLE = "idle"
    LOADING = "loading"
    READY = "ready"
    SPEAKING = "speaking"
    ERROR = "error"


class AudioOutputMode(Enum):
    """오디오 출력 모드 / Audio output mode"""
    I2S = "i2s"            # MAX98357A I2S 앰프 (기본)
    FILE = "file"           # WAV 파일 저장
    STREAM = "stream"       # 스트리밍 출력


# ──────────────────────────────────────────────────────────────────────────────
# 데이터 클래스 / Data Classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class TTSConfig:
    """TTS 설정 / TTS configuration"""
    model_name: str = "myshell-ai/MeloTTS-Korean"
    language: str = "KR"
    sample_rate: int = DEFAULT_SAMPLE_RATE
    speed: float = DEFAULT_SPEED
    speaker_id: str = "KR"
    device: str = "cpu"             # Jetson#2 CPU 추론
    output_mode: AudioOutputMode = AudioOutputMode.I2S
    i2s_device: str = "hw:0,0"     # ALSA 장치
    volume: float = 0.8            # 출력 볼륨 (0~1)


@dataclass
class EmotionMapping:
    """감정 매핑 설정 / Emotion mapping configuration"""
    speaker_ids: Dict[str, str] = field(default_factory=lambda: {
        Emotion.NEUTRAL.value: "KR",
        Emotion.HAPPY.value: "KR-happy",
        Emotion.SAD.value: "KR-sad",
        Emotion.ANGRY.value: "KR-angry",
        Emotion.EXCITED.value: "KR-excited",
    })
    speed_adjustments: Dict[str, float] = field(default_factory=lambda: {
        Emotion.NEUTRAL.value: 1.0,
        Emotion.HAPPY.value: 1.1,
        Emotion.SAD.value: 0.85,
        Emotion.ANGRY.value: 1.05,
        Emotion.EXCITED.value: 1.15,
    })
    pitch_adjustments: Dict[str, float] = field(default_factory=lambda: {
        Emotion.NEUTRAL.value: 0.0,
        Emotion.HAPPY.value: 2.0,
        Emotion.SAD.value: -2.0,
        Emotion.ANGRY.value: -1.0,
        Emotion.EXCITED.value: 3.0,
    })


@dataclass
class SynthesisResult:
    """합성 결과 / Synthesis result"""
    audio_data: np.ndarray = field(default_factory=lambda: np.array([], dtype=np.float32))
    sample_rate: int = DEFAULT_SAMPLE_RATE
    duration_s: float = 0.0
    text: str = ""
    emotion: str = "neutral"
    first_sample_latency_ms: float = 0.0
    synthesis_time_ms: float = 0.0
    samples_generated: int = 0


@dataclass
class TTSMetrics:
    """TTS 메트릭 / TTS metrics"""
    total_syntheses: int = 0
    avg_first_sample_ms: float = 0.0
    avg_synthesis_time_ms: float = 0.0
    avg_duration_s: float = 0.0
    total_audio_seconds: float = 0.0
    vram_usage_mb: float = MELOTTS_VRAM_MB


# ──────────────────────────────────────────────────────────────────────────────
# 감정 태그 파서 / Emotion Tag Parser
# ──────────────────────────────────────────────────────────────────────────────

class EmotionTagParser:
    """
    텍스트 내 감정 태그 파서
    
    형식: <happy>안녕하세요</happy> 반갑습니다 <sad>아쉽네요</sad>
    태그가 없으면 기본 감정(neutral) 적용.
    """

    def __init__(self, default_emotion: Emotion = Emotion.NEUTRAL) -> None:
        self._default_emotion = default_emotion

    def parse(self, text: str) -> List[Tuple[str, Emotion]]:
        """
        감정 태그가 포함된 텍스트를 파싱
        
        Returns:
            List of (text_segment, emotion) tuples
        """
        import re
        segments: List[Tuple[str, Emotion]] = []

        # <emotion>text</emotion> 패턴 매칭
        pattern = r"<(happy|sad|angry|neutral|excited)>(.*?)</\1>"
        last_end = 0

        for match in re.finditer(pattern, text, re.DOTALL):
            # 태그 앞 텍스트
            before = text[last_end:match.start()].strip()
            if before:
                segments.append((before, self._default_emotion))

            # 태그 내 텍스트
            emotion_str = match.group(1)
            content = match.group(2).strip()
            if content:
                try:
                    emotion = Emotion(emotion_str)
                except ValueError:
                    emotion = self._default_emotion
                segments.append((content, emotion))

            last_end = match.end()

        # 남은 텍스트
        remaining = text[last_end:].strip()
        if remaining:
            segments.append((remaining, self._default_emotion))

        # 태그가 전혀 없으면 전체를 기본 감정으로
        if not segments:
            segments.append((text, self._default_emotion))

        return segments


# ──────────────────────────────────────────────────────────────────────────────
# 메인 클래스 / Main Class
# ──────────────────────────────────────────────────────────────────────────────

class TTSEngine:
    """
    MeloTTS-Korean TTS 엔진
    
    Jetson#2 CPU에서 실행:
    - myshell-ai/MeloTTS-Korean → 300MB VRAM
    - 24kHz 출력 → MAX98357A I2S 앰프 → 3W 스피커 ×2
    - 감정 매핑 (happy/sad/angry/neutral/excited)
    - 감정 태그 텍스트 지원
    - 첫 샘플 지연 <200ms
    """

    def __init__(self, config: Optional[TTSConfig] = None) -> None:
        self._config = config or TTSConfig()
        self._status: TTSStatus = TTSStatus.IDLE
        self._model: Any = None
        self._emotion_mapping = EmotionMapping()
        self._tag_parser = EmotionTagParser()
        self._metrics = TTSMetrics()
        self._audio_queue: queue.Queue = queue.Queue()
        self._is_speaking = False
        self._speak_thread: Optional[threading.Thread] = None

        self._logger = logging.getLogger("jihun.v84.tts_engine")
        self._logger.setLevel(logging.DEBUG)

    # ── 모델 로드 / Model Loading ────────────────────────────────────────────

    def load_model(self) -> bool:
        """
        MeloTTS-Korean 모델 로드
        
        Returns:
            로드 성공 여부
        """
        self._status = TTSStatus.LOADING
        self._logger.info(f"TTS 모델 로드: {self._config.model_name}")

        try:
            from melotts import TTS

            self._model = TTS(
                model_name=self._config.model_name,
                language=self._config.language,
                device=self._config.device,
            )
            self._status = TTSStatus.READY
            self._metrics.vram_usage_mb = MELOTTS_VRAM_MB
            self._logger.info("MeloTTS-Korean 모델 로드 완료")
            return True

        except ImportError:
            self._logger.warning("melotts 미설치 — 시뮬레이션 모드")
            self._status = TTSStatus.READY
            return True
        except Exception as e:
            self._status = TTSStatus.ERROR
            self._logger.error(f"TTS 모델 로드 실패: {e}")
            return False

    # ── 합성 / Synthesize ────────────────────────────────────────────────────

    def synthesize(
        self,
        text: str,
        emotion: Optional[Emotion] = None,
        speed: Optional[float] = None,
    ) -> SynthesisResult:
        """
        텍스트를 음성으로 합성 (동기)
        
        감정 태그가 포함된 텍스트를 자동으로 파싱합니다.
        태그가 없으면 emotion 매개변수를 사용합니다.
        
        Args:
            text: 합성할 텍스트 (감정 태그 포함 가능)
            emotion: 기본 감정 (태그가 없을 때 사용)
            speed: 말하기 속도 배율
            
        Returns:
            SynthesisResult: 합성 결과
        """
        if self._status != TTSStatus.READY:
            return SynthesisResult(text=text, emotion="error")

        start_time = time.time()
        default_emotion = emotion or Emotion.NEUTRAL
        target_speed = speed or self._config.speed

        # 감정 태그 파싱
        segments = self._tag_parser.parse(text)
        if segments and segments[0][1] == Emotion.NEUTRAL and default_emotion != Emotion.NEUTRAL:
            # 태그가 없으면 매개변수 감정 사용
            segments = [(seg_text, default_emotion) for seg_text, _ in segments]

        # 세그먼트별 합성
        all_audio: List[np.ndarray] = []
        first_sample_time = None

        for seg_text, seg_emotion in segments:
            audio = self._synthesize_segment(seg_text, seg_emotion, target_speed)
            if first_sample_time is None and len(audio) > 0:
                first_sample_time = time.time()
            if len(audio) > 0:
                all_audio.append(audio)

        # 결합
        if all_audio:
            combined = np.concatenate(all_audio)
        else:
            combined = np.array([], dtype=np.float32)

        # 결과 생성
        result = SynthesisResult(
            audio_data=combined,
            sample_rate=self._config.sample_rate,
            duration_s=len(combined) / self._config.sample_rate if len(combined) > 0 else 0.0,
            text=text,
            emotion=default_emotion.value,
            first_sample_latency_ms=(
                (first_sample_time - start_time) * 1000 if first_sample_time else 0.0
            ),
            synthesis_time_ms=(time.time() - start_time) * 1000,
            samples_generated=len(combined),
        )

        # I2S 출력
        if self._config.output_mode == AudioOutputMode.I2S and len(combined) > 0:
            self._output_i2s(combined)

        self._update_metrics(result)
        return result

    def _synthesize_segment(
        self,
        text: str,
        emotion: Emotion,
        speed: float,
    ) -> np.ndarray:
        """단일 세그먼트 합성 / Synthesize a single segment"""
        emotion_str = emotion.value

        # 감정별 화자 ID 및 속도 조정
        speaker_id = self._emotion_mapping.speaker_ids.get(
            emotion_str, self._config.speaker_id
        )
        speed_adj = self._emotion_mapping.speed_adjustments.get(emotion_str, 1.0)
        adjusted_speed = speed * speed_adj

        try:
            if self._model is not None:
                # MeloTTS 합성
                audio = self._model.tts(
                    text=text,
                    speaker_id=speaker_id,
                    speed=adjusted_speed,
                )
                return np.array(audio, dtype=np.float32)
            else:
                # 시뮬레이션: 24kHz 사인파 (테스트용)
                duration = len(text) * 0.06  # 글자당 ~60ms
                t = np.linspace(
                    0, duration,
                    int(duration * self._config.sample_rate),
                    dtype=np.float32,
                )
                return np.sin(2 * np.pi * 440 * t) * 0.1

        except Exception as e:
            self._logger.error(f"합성 오류: {e}")
            return np.array([], dtype=np.float32)

    # ── 스트리밍 합성 / Stream Synthesize ────────────────────────────────────

    def stream_synthesize(
        self,
        text: str,
        emotion: Optional[Emotion] = None,
        speed: Optional[float] = None,
        chunk_samples: int = 4800,    # 200ms @ 24kHz
    ) -> Generator[np.ndarray, None, None]:
        """
        스트리밍 합성 (제너레이터)
        
        청크 단위로 오디오를 생성하여 즉시 출력합니다.
        첫 샘플 지연 <200ms를 보장합니다.
        
        Args:
            text: 합성할 텍스트
            emotion: 감정
            speed: 속도
            chunk_samples: 청크당 샘플 수
            
        Yields:
            np.ndarray: 오디오 청크
        """
        result = self.synthesize(text, emotion, speed)

        # 청크 분할
        audio = result.audio_data
        for i in range(0, len(audio), chunk_samples):
            chunk = audio[i:i + chunk_samples]
            yield chunk

    async def stream_synthesize_async(
        self,
        text: str,
        emotion: Optional[Emotion] = None,
        speed: Optional[float] = None,
    ) -> AsyncIterator[np.ndarray]:
        """비동기 스트리밍 합성 / Async streaming synthesis"""
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None, self.synthesize, text, emotion, speed
        )

        chunk_size = 4800  # 200ms
        audio = result.audio_data
        for i in range(0, len(audio), chunk_size):
            chunk = audio[i:i + chunk_size]
            yield chunk

    # ── 감정 설정 / Set Emotion ──────────────────────────────────────────────

    def set_emotion(self, emotion: Emotion) -> None:
        """
        기본 감정 설정
        
        Args:
            emotion: 설정할 감정
        """
        self._config.speaker_id = self._emotion_mapping.speaker_ids.get(
            emotion.value, "KR"
        )
        self._logger.info(f"TTS 감정 변경: {emotion.value}")

    # ── 속도 설정 / Set Speed ────────────────────────────────────────────────

    def set_speed(self, speed: float) -> None:
        """
        말하기 속도 설정
        
        Args:
            speed: 속도 배율 (0.5=느리게, 2.0=빠르게)
        """
        self._config.speed = max(0.5, min(2.0, speed))
        self._logger.info(f"TTS 속도 변경: {self._config.speed}")

    # ── I2S 출력 / I2S Output ────────────────────────────────────────────────

    def _output_i2s(self, audio_data: np.ndarray) -> None:
        """
        MAX98357A I2S 앰프로 오디오 출력
        
        Jetson#2 I2S → MAX98357A → 3W 스피커 ×2 (L/R)
        ALSA를 통해 I2S 디바이스에 출력합니다.
        """
        try:
            import sounddevice as sd

            # 볼륨 조절
            volume = self._config.volume
            audio = (audio_data * volume).astype(np.float32)

            # 스테레오 변환 (L/R 동일)
            stereo = np.column_stack([audio, audio])

            sd.play(stereo, samplerate=self._config.sample_rate)
            self._logger.debug(f"I2S 출력: {len(audio)}샘플, {self._config.sample_rate}Hz")

        except ImportError:
            self._logger.debug("sounddevice 미설치 — I2S 출력 스킵")
        except Exception as e:
            self._logger.error(f"I2S 출력 오류: {e}")

    # ── WAV 저장 / Save WAV ──────────────────────────────────────────────────

    def save_wav(
        self,
        audio_data: np.ndarray,
        output_path: str,
        sample_rate: Optional[int] = None,
    ) -> None:
        """
        오디오를 WAV 파일로 저장
        
        Args:
            audio_data: 오디오 데이터
            output_path: 출력 파일 경로
            sample_rate: 샘플링 레이트
        """
        sr = sample_rate or self._config.sample_rate
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        # float32 → int16 변환
        audio_int16 = (audio_data * 32767).astype(np.int16)

        with wave.open(output_path, "w") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sr)
            wf.writeframes(audio_int16.tobytes())

        self._logger.info(f"WAV 저장: {output_path} ({len(audio_data)/sr:.1f}초)")

    # ── 메트릭 / Metrics ─────────────────────────────────────────────────────

    def _update_metrics(self, result: SynthesisResult) -> None:
        """메트릭 업데이트 / Update metrics"""
        n = self._metrics.total_syntheses + 1
        self._metrics.total_syntheses = n
        self._metrics.avg_first_sample_ms = (
            (n - 1) * self._metrics.avg_first_sample_ms + result.first_sample_latency_ms
        ) / n
        self._metrics.avg_synthesis_time_ms = (
            (n - 1) * self._metrics.avg_synthesis_time_ms + result.synthesis_time_ms
        ) / n
        self._metrics.avg_duration_s = (
            (n - 1) * self._metrics.avg_duration_s + result.duration_s
        ) / n
        self._metrics.total_audio_seconds += result.duration_s

    @property
    def status(self) -> TTSStatus:
        return self._status

    @property
    def metrics(self) -> TTSMetrics:
        return self._metrics

    @property
    def is_speaking(self) -> bool:
        return self._is_speaking

    def get_status_summary(self) -> Dict[str, Any]:
        return {
            "status": self._status.value,
            "model": self._config.model_name,
            "sample_rate": self._config.sample_rate,
            "speed": self._config.speed,
            "output_mode": self._config.output_mode.value,
            "total_syntheses": self._metrics.total_syntheses,
            "avg_first_sample_ms": round(self._metrics.avg_first_sample_ms, 1),
            "avg_duration_s": round(self._metrics.avg_duration_s, 2),
            "vram_usage_mb": self._metrics.vram_usage_mb,
        }
