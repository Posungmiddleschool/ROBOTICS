#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TODO 8: I2S 오디오 파이프라인 검증
====================================================

ICS-43434 MEMS 마이크 ×2 + MAX98357A 앰프 ×2 → Jetson #2 I2S

검증 항목:
  - arecord -l 장치 인식
  - 16kHz 스테레오 녹음
  - 재생 테스트
  - 풀듀플렉스 (동시 녹음+재생)
  - VAD (Voice Activity Detection)

연결:
  - 입력: ICS-43434 ×2 → I2S BCLK/LRCLK/DATA (L/R 채널)
  - 출력: MAX98357A ×2 → I2S BCLK/LRCLK/DATA (L/R 채널)
  - 호스트: Jetson #2 I2S 컨트롤러

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from hardware.config import JihunRobotV7Config, STTConfig, TTSConfig, WakeWordConfig

logger = logging.getLogger("jihun.v84.audio_pipeline")

# ============================================================================
# 상수
# ============================================================================

CONFIG_DIR = Path("/opt/jihun")

# I2S 설정
I2S_SAMPLE_RATE = 16000     # 16kHz (Whisper/Gemma4 오디오)
I2S_CHANNELS = 2            # 스테레오 (L/R 마이크)
I2S_BIT_DEPTH = 16          # 16-bit
I2S_FRAME_SIZE = I2S_CHANNELS * (I2S_BIT_DEPTH // 8)  # 4 bytes/frame

# 오디오 장치
INPUT_DEVICE = "hw:CARD=ics43434,DEV=0"    # ICS-43434 MEMS 마이크
OUTPUT_DEVICE = "hw:CARD=max98357a,DEV=0"  # MAX98357A 앰프

# 테스트 파라미터
RECORD_DURATION_S = 5
TEST_TONE_FREQ_HZ = 440  # A4 음
TEST_TONE_DURATION_S = 3

# VAD 설정
VAD_SILENCE_THRESHOLD_S = 1.0  # 1초 침묵 = 발화 종료
VAD_ENERGY_THRESHOLD = 500      # RMS 에너지 임계값

# ALSA 믹서 설정
ALSA_MIXER_CAPTURE = "Capture"
ALSA_MIXER_PLAYBACK = "Master"


@dataclass
class AudioDeviceInfo:
    """오디오 장치 정보"""
    card_id: int = 0
    device_id: int = 0
    name: str = ""
    type: str = ""         # "input" 또는 "output"
    sample_rate: int = I2S_SAMPLE_RATE
    channels: int = I2S_CHANNELS
    is_available: bool = False


@dataclass
class AudioTestResult:
    """오디오 테스트 결과"""
    record_ok: bool = False
    playback_ok: bool = False
    full_duplex_ok: bool = False
    vad_ok: bool = False
    record_file: str = ""
    record_duration_s: float = 0.0
    record_filesize_bytes: int = 0
    errors: List[str] = field(default_factory=list)


@dataclass
class I2SConfig:
    """I2S 하드웨어 설정"""
    bclk_pin: int = 7       # I2S 비트 클럭
    lrclk_pin: int = 8      # I2S L/R 클럭
    data_in_pin: int = 12   # I2S 데이터 입력 (마이크)
    data_out_pin: int = 11  # I2S 데이터 출력 (앰프)
    sample_rate: int = I2S_SAMPLE_RATE
    bit_depth: int = I2S_BIT_DEPTH
    channels: int = I2S_CHANNELS


class AudioPipeline:
    """
    TODO 8: I2S 오디오 파이프라인 검증

    기능:
      - I2S 입력 초기화 (ICS-43434 MEMS 마이크 ×2)
      - I2S 출력 초기화 (MAX98357A 앰프 ×2)
      - 녹음 테스트 (5초)
      - 재생 테스트
      - 풀듀플렉스 검증
      - VAD 설정
    """

    def __init__(self, config: Optional[JihunRobotV7Config] = None):
        self.config = config or JihunRobotV7Config()
        self.stt_cfg = self.config.ai.stt
        self.tts_cfg = self.config.ai.tts
        self.wake_word_cfg = self.config.ai.wake_word
        self._i2s_config = I2SConfig()
        self._input_device: Optional[AudioDeviceInfo] = None
        self._output_device: Optional[AudioDeviceInfo] = None

    # ========================================================================
    # 공용 메서드
    # ========================================================================

    def setup(self) -> bool:
        """전체 오디오 파이프라인 설정"""
        logger.info("=== I2S 오디오 파이프라인 검증 ===")

        # 1. I2S 입력 초기화
        if not self.init_i2s_input():
            logger.error("I2S 입력 초기화 실패")
            return False

        # 2. I2S 출력 초기화
        if not self.init_i2s_output():
            logger.warning("I2S 출력 초기화 실패 — TTS 불가")

        # 3. 녹음 테스트
        self.test_record()

        # 4. 재생 테스트
        self.test_playback()

        # 5. 풀듀플렉스 검증
        self.verify_full_duplex()

        # 6. VAD 설정
        self.setup_vad()

        logger.info("=== 오디오 파이프라인 검증 완료 ===")
        return True

    def verify(self) -> bool:
        """오디오 파이프라인 검증"""
        devices = self._list_audio_devices()
        has_input = any(d.type == "input" and d.is_available for d in devices)
        has_output = any(d.type == "output" and d.is_available for d in devices)
        return has_input

    # ========================================================================
    # TODO 8-1: I2S 입력 초기화 (마이크)
    # ========================================================================

    def init_i2s_input(self) -> bool:
        """
        ICS-43434 MEMS 마이크 ×2 I2S 입력 초기화

        하드웨어 연결:
          - ICS-43434 #1 → I2S L 채널 (왼쪽 마이크)
          - ICS-43434 #2 → I2S R 채널 (오른쪽 마이크)
          - BCLK: 비트 클럭 공유
          - LRCLK: L/R 선택 신호 공유

        사양:
          - 16kHz 샘플레이트 (Whisper/Gemma4 오디오)
          - 16-bit 해상도
          - 2채널 (스테레오)
        """
        logger.info("I2S 입력 (ICS-43434 MEMS 마이크 ×2) 초기화 중...")

        # 1. I2S 오버레이 로드 (Jetson Device Tree)
        self._load_i2s_overlay()

        # 2. 오디오 장치 스캔
        devices = self._list_audio_devices()
        input_devices = [d for d in devices if d.type == "input"]

        if not input_devices:
            logger.error("  ✗ 입력 장치 미인식 — I2S 오버레이 확인 필요")
            return False

        # ICS-43434 찾기
        for dev in input_devices:
            if "ics43434" in dev.name.lower() or "i2s" in dev.name.lower():
                self._input_device = dev
                break

        if self._input_device is None:
            # 첫 번째 입력 장치 사용
            self._input_device = input_devices[0]
            logger.warning(f"  ⚠ ICS-43434 미인식 — 대체 장치: {self._input_device.name}")

        logger.info(
            f"  ✓ 입력 장치: {self._input_device.name} "
            f"(카드 {self._input_device.card_id})"
        )

        # 3. ALSA 믹서 설정
        self._set_alsa_mixer_input()

        logger.info(
            f"  ✓ I2S 입력: {I2S_SAMPLE_RATE}Hz, {I2S_CHANNELS}ch, {I2S_BIT_DEPTH}-bit"
        )
        return True

    def _load_i2s_overlay(self) -> None:
        """Jetson I2S Device Tree 오버레이 로드"""
        try:
            # Jetson I2S 오버레이 로드
            result = subprocess.run(
                ["sudo", "dtoverlay", "i2s-mic"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                logger.info("  ✓ I2S 오버레이 로드 성공")
            else:
                logger.warning(f"  ⚠ I2S 오버레이 로드 실패: {result.stderr.strip()}")
                logger.info("  수동 설정: /boot/extlinux/extlinux.conf에 I2S 오버레이 추가")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            logger.warning("  ⚠ dtoverlay 명령 불가 — 수동 I2S 설정 필요")

    # ========================================================================
    # TODO 8-2: I2S 출력 초기화 (앰프)
    # ========================================================================

    def init_i2s_output(self) -> bool:
        """
        MAX98357A I2S 앰프 ×2 출력 초기화

        하드웨어 연결:
          - MAX98357A #1 → I2S L 채널 (왼쪽 스피커)
          - MAX98357A #2 → I2S R 채널 (오른쪽 스피커)
          - BCLK: 비트 클럭 공유
          - LRCLK: L/R 선택 신호 공유

        사양:
          - 24kHz 샘플레이트 (MeloTTS 출력)
          - 16-bit 해상도
          - 2채널 (스테레오)
          - 3W/4Ω 출력
        """
        logger.info("I2S 출력 (MAX98357A 앰프 ×2) 초기화 중...")

        # 오디오 장치 스캔
        devices = self._list_audio_devices()
        output_devices = [d for d in devices if d.type == "output"]

        if not output_devices:
            logger.error("  ✗ 출력 장치 미인식")
            return False

        # MAX98357A 찾기
        for dev in output_devices:
            if "max98357a" in dev.name.lower() or "i2s" in dev.name.lower():
                self._output_device = dev
                break

        if self._output_device is None:
            self._output_device = output_devices[0]
            logger.warning(f"  ⚠ MAX98357A 미인식 — 대체 장치: {self._output_device.name}")

        logger.info(
            f"  ✓ 출력 장치: {self._output_device.name} "
            f"(카드 {self._output_device.card_id})"
        )

        # ALSA 믹서 설정
        self._set_alsa_mixer_output()

        logger.info(
            f"  ✓ I2S 출력: {self.tts_cfg.sample_rate_hz}Hz, {I2S_CHANNELS}ch, {I2S_BIT_DEPTH}-bit"
        )
        return True

    # ========================================================================
    # TODO 8-3: 녹음 테스트
    # ========================================================================

    def test_record(self, duration_s: float = RECORD_DURATION_S) -> bool:
        """
        5초 녹음 테스트

        검증:
          - arecord로 녹음 파일 생성
          - 파일 크기 > 0
          - PCM WAV 헤더 정상
        """
        logger.info(f"녹음 테스트 ({duration_s}s)...")

        output_file = CONFIG_DIR / "test_recording.wav"
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        try:
            device = INPUT_DEVICE
            if self._input_device:
                device = f"hw:CARD={self._input_device.card_id},DEV=0"

            cmd = [
                "arecord",
                "-D", device,
                "-f", "S16_LE",              # 16-bit Little Endian
                "-r", str(I2S_SAMPLE_RATE),   # 16kHz
                "-c", str(I2S_CHANNELS),      # 2채널
                "-d", str(int(duration_s)),   # 녹음 시간
                str(output_file),
            ]

            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=duration_s + 10,
            )

            if result.returncode == 0 and output_file.exists():
                file_size = output_file.stat().st_size
                logger.info(
                    f"  ✓ 녹음 성공: {output_file} ({file_size} bytes, {duration_s}s)"
                )

                # WAV 파일 검증
                self._verify_wav_file(output_file)
                return True
            else:
                logger.error(f"  ✗ 녹음 실패: {result.stderr}")
                return False

        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.error(f"  ✗ arecord 실행 불가: {e}")
            return False

    def _verify_wav_file(self, filepath: Path) -> bool:
        """WAV 파일 헤더 검증"""
        try:
            with wave.open(str(filepath), "rb") as wf:
                channels = wf.getnchannels()
                sample_rate = wf.getframerate()
                frames = wf.getnframes()
                duration = frames / sample_rate if sample_rate > 0 else 0

                logger.info(
                    f"  WAV: {channels}ch, {sample_rate}Hz, "
                    f"{duration:.1f}s, {frames} frames"
                )
                return channels == I2S_CHANNELS and sample_rate == I2S_SAMPLE_RATE
        except Exception as e:
            logger.warning(f"  ⚠ WAV 파일 검증 실패: {e}")
            return False

    # ========================================================================
    # TODO 8-4: 재생 테스트
    # ========================================================================

    def test_playback(self) -> bool:
        """
        테스트 톤 재생 및 검증

        440Hz (A4) 사인파 3초 재생
        """
        logger.info("재생 테스트 (440Hz, 3s)...")

        # 테스트 톤 WAV 파일 생성
        tone_file = CONFIG_DIR / "test_tone.wav"
        self._generate_test_tone(tone_file)

        if not tone_file.exists():
            logger.error("  ✗ 테스트 톤 생성 실패")
            return False

        # 재생
        try:
            device = OUTPUT_DEVICE
            if self._output_device:
                device = f"hw:CARD={self._output_device.card_id},DEV=0"

            cmd = [
                "aplay",
                "-D", device,
                str(tone_file),
            ]

            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=10,
            )

            if result.returncode == 0:
                logger.info("  ✓ 재생 성공 — 스피커에서 소리 들림 확인")
                return True
            else:
                logger.error(f"  ✗ 재생 실패: {result.stderr}")
                return False

        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.error(f"  ✗ aplay 실행 불가: {e}")
            return False

    def _generate_test_tone(self, filepath: Path) -> bool:
        """440Hz 테스트 톤 WAV 파일 생성"""
        try:
            import numpy as np

            sample_rate = self.tts_cfg.sample_rate_hz
            duration = TEST_TONE_DURATION_S
            frequency = TEST_TONE_FREQ_HZ

            t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
            tone = (np.sin(2 * np.pi * frequency * t) * 16000).astype(np.int16)

            # 스테레오로 변환
            stereo = np.column_stack([tone, tone])

            with wave.open(str(filepath), "wb") as wf:
                wf.setnchannels(2)
                wf.setsampwidth(2)  # 16-bit
                wf.setframerate(sample_rate)
                wf.writeframes(stereo.tobytes())

            logger.info(f"  테스트 톤 생성: {filepath}")
            return True

        except ImportError:
            logger.warning("  ⚠ numpy 미설치 — 테스트 톤 생성 불가")
            return False

    # ========================================================================
    # TODO 8-5: 풀듀플렉스 검증
    # ========================================================================

    def verify_full_duplex(self) -> bool:
        """
        동시 녹음+재생 (풀듀플렉스) 검증

        I2S는 기본적으로 풀듀플렉스 지원
        BCLK/LRCLK를 공유하므로 동시 입출력 가능
        """
        logger.info("풀듀플렉스 (동시 녹음+재생) 검증 중...")

        # 녹음과 재생을 동시에 실행
        record_file = CONFIG_DIR / "test_duplex_rec.wav"

        try:
            # 백그라운드 녹음
            input_device = INPUT_DEVICE
            if self._input_device:
                input_device = f"hw:CARD={self._input_device.card_id},DEV=0"

            record_proc = subprocess.Popen(
                [
                    "arecord", "-D", input_device,
                    "-f", "S16_LE", "-r", str(I2S_SAMPLE_RATE),
                    "-c", str(I2S_CHANNELS), "-d", "5",
                    str(record_file),
                ],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            )

            time.sleep(0.5)  # 녹음 시작 대기

            # 전경 재생
            tone_file = CONFIG_DIR / "test_tone.wav"
            if tone_file.exists():
                output_device = OUTPUT_DEVICE
                if self._output_device:
                    output_device = f"hw:CARD={self._output_device.card_id},DEV=0"

                play_proc = subprocess.run(
                    ["aplay", "-D", output_device, str(tone_file)],
                    capture_output=True, text=True, timeout=10,
                )

            # 녹음 완료 대기
            record_proc.wait(timeout=10)

            if record_file.exists() and record_file.stat().st_size > 0:
                logger.info("  ✓ 풀듀플렉스 성공 — 동시 녹음+재생 확인")
                return True
            else:
                logger.warning("  ⚠ 풀듀플렉스 녹음 결과 없음")
                return False

        except Exception as e:
            logger.error(f"  ✗ 풀듀플렉스 테스트 실패: {e}")
            return False

    # ========================================================================
    # TODO 8-6: VAD 설정
    # ========================================================================

    def setup_vad(self) -> bool:
        """
        Voice Activity Detection (VAD) 설정

        설정:
          - 침묵 1초 = 발화 종료
          - RMS 에너지 임계값 기반
          - Whisper VAD 또는 WebRTC VAD 사용

        동작:
          1. 오디오 스트림에서 RMS 에너지 계산
          2. 에너지가 임계값 이하인 구간 감지
          3. 침묵 1초 지속 → 발화 종료 → STT 처리 시작
        """
        logger.info("VAD (Voice Activity Detection) 설정 중...")

        vad_config = {
            "engine": "webrtcvad",                  # WebRTC VAD (경량)
            "sample_rate": self.stt_cfg.sample_rate_hz,
            "frame_duration_ms": 30,                # 30ms 프레임
            "silence_duration_s": VAD_SILENCE_THRESHOLD_S,
            "energy_threshold": VAD_ENERGY_THRESHOLD,
            "aggressiveness": 3,                    # 0-3 (3=가장 공격적 필터링)
            "wake_word": self.wake_word_cfg.keyword,
            "wake_word_sensitivity": self.wake_word_cfg.sensitivity,
        }

        # VAD 설정 파일 저장
        config_path = CONFIG_DIR / "vad_config.json"
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            config_path.write_text(json.dumps(vad_config, indent=2, ensure_ascii=False))
            logger.info(f"  ✓ VAD 설정 저장: {config_path}")
        except IOError as e:
            logger.warning(f"  ⚠ VAD 설정 저장 실패: {e}")

        # 웨이크워드 설정
        logger.info(
            f"  웨이크워드: '{self.wake_word_cfg.keyword}' "
            f"(감도: {self.wake_word_cfg.sensitivity})"
        )
        logger.info(
            f"  침묵 타임아웃: {VAD_SILENCE_THRESHOLD_S}초 → 발화 종료"
        )

        return True

    # ========================================================================
    # 유틸리티
    # ========================================================================

    def _list_audio_devices(self) -> List[AudioDeviceInfo]:
        """오디오 장치 목록 조회 (arecord -l / aplay -l)"""
        devices: List[AudioDeviceInfo] = []

        # 입력 장치
        try:
            result = subprocess.run(
                ["arecord", "-l"], capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if "card" in line.lower():
                        dev = self._parse_audio_device_line(line, "input")
                        if dev:
                            devices.append(dev)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # 출력 장치
        try:
            result = subprocess.run(
                ["aplay", "-l"], capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if "card" in line.lower():
                        dev = self._parse_audio_device_line(line, "output")
                        if dev:
                            devices.append(dev)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        return devices

    @staticmethod
    def _parse_audio_device_line(line: str, dev_type: str) -> Optional[AudioDeviceInfo]:
        """오디오 장치 정보 파싱"""
        import re
        # 예: "card 0: ics43434 [ICS-43434], device 0: ..."
        match = re.search(r"card\s+(\d+).*device\s+(\d+):\s*(.+?)[,\[]", line)
        if match:
            return AudioDeviceInfo(
                card_id=int(match.group(1)),
                device_id=int(match.group(2)),
                name=match.group(3).strip(),
                type=dev_type,
                is_available=True,
            )
        return None

    def _set_alsa_mixer_input(self) -> None:
        """ALSA 입력 믹서 설정"""
        try:
            # 캡처 볼륨 최대
            subprocess.run(
                ["amixer", "-c", str(self._input_device.card_id if self._input_device else 0),
                 "set", ALSA_MIXER_CAPTURE, "100%"],
                capture_output=True, text=True, timeout=5,
            )
            logger.info("  ✓ 입력 볼륨: 100%")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            logger.warning("  ⚠ ALSA 믹서 설정 불가")

    def _set_alsa_mixer_output(self) -> None:
        """ALSA 출력 믹서 설정"""
        try:
            # 출력 볼륨 80% (스피커 보호)
            subprocess.run(
                ["amixer", "-c", str(self._output_device.card_id if self._output_device else 0),
                 "set", ALSA_MIXER_PLAYBACK, "80%"],
                capture_output=True, text=True, timeout=5,
            )
            logger.info("  ✓ 출력 볼륨: 80%")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            logger.warning("  ⚠ ALSA 믹서 설정 불가")

    def get_audio_status(self) -> Dict:
        """오디오 파이프라인 상태 반환"""
        devices = self._list_audio_devices()
        return {
            "input_device": {
                "name": self._input_device.name if self._input_device else "N/A",
                "available": self._input_device.is_available if self._input_device else False,
            },
            "output_device": {
                "name": self._output_device.name if self._output_device else "N/A",
                "available": self._output_device.is_available if self._output_device else False,
            },
            "i2s_config": {
                "sample_rate": self._i2s_config.sample_rate,
                "channels": self._i2s_config.channels,
                "bit_depth": self._i2s_config.bit_depth,
            },
            "devices_found": len(devices),
            "vad_silence_s": VAD_SILENCE_THRESHOLD_S,
        }
