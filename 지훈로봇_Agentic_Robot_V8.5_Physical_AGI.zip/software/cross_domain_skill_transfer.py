#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
지훈 로봇 V8.5 — 교차 도메인 스킬 전이 (Cross-Domain Skill Transfer)
====================================================================

한 도메인에서 배운 스킬을 다른 도메인으로 전이합니다.
이것이 바로 범용 AGI의 핵심 — 특정 작업에 갇히지 않는 지능입니다.

혁신:
  - 대기업: 각 작업을 따로 학습 (100개 작업 = 100번 학습)
  - 우리: 한 번 배운 원리를 모든 작업에 적용 (1번 학습 → 100개 작업)
  
  일론 머스크가 전기차로 내연기차를 이긴 원리:
  - 내연기차: 모델별로 엔진 따로 개발
  - 테슬라: 하나의 소프트웨어 플랫폼 → 모든 모델 적용
  
  마찬가지로:
  - 유니트리: 각 동작 따로 프로그래밍
  - 지훈 로봇: 하나의 학습 원리 → 모든 작업 적용

작성자: 안지훈 (보성중학교 2학년 4반 10번)
버전: V8.5
"""

from __future__ import annotations

import json
import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("jihun.v85.cross_domain_skill_transfer")
logger.setLevel(logging.DEBUG)


@dataclass
class Skill:
    """스킬 — 특정 작업에서 학습한 능력"""
    skill_id: str = ""
    name: str = ""
    source_domain: str = ""         # 학습한 도메인
    target_domains: List[str] = field(default_factory=list)  # 전이 가능한 도메인
    core_principles: List[str] = field(default_factory=list)  # 핵심 원리
    parameters: Dict[str, float] = field(default_factory=dict)  # 스킬 파라미터
    success_rate: float = 0.0       # 원래 도메인에서의 성공률
    transfer_count: int = 0         # 전이 횟수
    last_used: float = 0.0


@dataclass
class TransferResult:
    """전이 결과"""
    source_skill: str = ""
    target_domain: str = ""
    transfer_success: bool = False
    adapted_parameters: Dict[str, float] = field(default_factory=dict)
    confidence: float = 0.0
    notes: str = ""


class CrossDomainSkillTransfer:
    """
    교차 도메인 스킬 전이 — 한 분야의 경험을 다른 분야에 적용
    
    이것이 바로 인간이 범용 지능을 가지는 핵심 메커니즘입니다:
    - 요리에서 배운 '힘 조절' → 공예에 적용
    - 청소에서 배운 '장애물 회피' → 쇼핑에 적용
    - 스포츠에서 배운 '타이밍' → 요리에 적용
    
    대기업의 로봇은 각 작업을 독립적으로 학습합니다.
    하지만 진정한 Physical AGI는 한 번 배운 것을 모든 곳에 적용합니다.
    """

    def __init__(self, gemma4_inference: Optional[Any] = None):
        self._gemma4 = gemma4_inference
        self._skill_db: Dict[str, Skill] = {}
        self._transfer_history: deque = deque(maxlen=1000)
        self._lock = threading.Lock()

        # 기본 전이 매핑 초기화
        self._init_transfer_map()
        
        logger.info("CrossDomainSkillTransfer V8.5 초기화 완료")

    def _init_transfer_map(self):
        """
        전이 매핑 초기화 — 어떤 스킬이 어떤 도메인으로 전이 가능한지
        
        이것은 하드코딩된 규칙이 아닌, 시작점입니다.
        AI가 경험을 통해 이 매핑을 확장합니다.
        """
        # 요리 → 공예: 힘 조절, 온도 감지, 정밀 동작
        self._register_skill(Skill(
            name="fragile_object_handling",
            source_domain="cooking",
            target_domains=["craft", "shopping", "cleaning"],
            core_principles=[
                "물체의 취약도를 평가하고 그에 맞춰 파지력 조절",
                "급격한 힘 변화를 피하고 부드럽게 접근",
                "시각적으로 물체 상태를 실시간 모니터링",
            ],
            parameters={"grip_force_n": 3.5, "approach_speed": 0.2, "release_speed": 0.3},
        ))

        # 청소 → 쇼핑: 장애물 회피, 공간 탐색
        self._register_skill(Skill(
            name="obstacle_navigation",
            source_domain="cleaning",
            target_domains=["shopping", "public_transport", "field_trip"],
            core_principles=[
                "LiDAR/카메라로 장애물 감지 → 경로 재계획",
                "움직이는 장애물의 속도/방향 예측",
                "안전 거리 유지하며 이동",
            ],
            parameters={"safe_distance_m": 0.3, "max_speed_ms": 0.5, "scan_rate_hz": 10},
        ))

        # 스포츠 → 요리: 타이밍, 반응 속도
        self._register_skill(Skill(
            name="precise_timing",
            source_domain="ball_sports",
            target_domains=["cooking", "craft"],
            core_principles=[
                "시각적 피드백에 빠르게 반응",
                "예측과 실행의 타이밍 정밀 조절",
                "실패 시 즉각적 보정",
            ],
            parameters={"reaction_time_ms": 150, "prediction_horizon_ms": 500},
        ))

        # 대중교통 → 답사: 공간 인식, 경로 계획
        self._register_skill(Skill(
            name="spatial_navigation",
            source_domain="public_transport",
            target_domains=["field_trip", "shopping", "cleaning"],
            core_principles=[
                "공간 지도 구축 및 갱신",
                "경로 최적화 (최단/안전/에너지 효율)",
                "표지판/랜드마크 인식",
            ],
            parameters={"map_resolution_m": 0.1, "path_safety_margin_m": 0.2},
        ))

        # 고객 응대 → 모든 도메인: 자연어 처리, 감정 인식
        self._register_skill(Skill(
            name="human_interaction",
            source_domain="customer_service",
            target_domains=["shopping", "public_transport", "field_trip", "cooking"],
            core_principles=[
                "인간의 의도와 감정 파악",
                "상황에 맞는 언어적/비언어적 응답",
                "안전 거리 유지 + 예의 바른 행동",
            ],
            parameters={"speech_rate": 1.0, "gesture_amplitude": 0.7},
        ))

    def _register_skill(self, skill: Skill):
        """스킬 등록"""
        if not skill.skill_id:
            skill.skill_id = f"skill_{len(self._skill_db)}"
        self._skill_db[skill.name] = skill

    def transfer(
        self,
        source_domain: str,
        target_domain: str,
        task_context: Optional[Dict] = None,
    ) -> List[TransferResult]:
        """
        스킬 전이 — source_domain에서 배운 스킬을 target_domain에 적용
        
        Args:
            source_domain: 원본 도메인
            target_domain: 대상 도메인
            task_context: 작업 컨텍스트
            
        Returns:
            전이 결과 목록
        """
        results = []
        task_context = task_context or {}

        # 전이 가능한 스킬 찾기
        transferable_skills = [
            s for s in self._skill_db.values()
            if s.source_domain == source_domain and target_domain in s.target_domains
        ]

        # 간접 전이도 검색 (A→B→C)
        if not transferable_skills:
            transferable_skills = self._find_indirect_transfers(source_domain, target_domain)

        for skill in transferable_skills:
            # 파라미터 적응
            adapted_params = self._adapt_parameters(skill, target_domain, task_context)

            # AI 추론으로 전이 품질 평가
            confidence = self._evaluate_transfer_confidence(skill, target_domain)

            result = TransferResult(
                source_skill=skill.name,
                target_domain=target_domain,
                transfer_success=confidence > 0.5,
                adapted_parameters=adapted_params,
                confidence=confidence,
                notes=self._generate_transfer_notes(skill, target_domain),
            )

            results.append(result)
            skill.transfer_count += 1

            # 전이 이력 기록
            with self._lock:
                self._transfer_history.append({
                    "skill": skill.name,
                    "source": source_domain,
                    "target": target_domain,
                    "confidence": confidence,
                    "timestamp": time.time(),
                })

        logger.info(
            f"스킬 전이: {source_domain} → {target_domain}, "
            f"{len(results)}개 스킬 전이 가능"
        )

        return results

    def _adapt_parameters(
        self, skill: Skill, target_domain: str, context: Dict
    ) -> Dict[str, float]:
        """
        스킬 파라미터를 대상 도메인에 맞게 적응
        
        원리는 같지만, 구체적인 수치는 도메인에 따라 다릅니다.
        예: '힘 조절' 원리는 같지만, 요리에서는 3.5N, 공예에서는 5N
        """
        adapted = skill.parameters.copy()

        # 도메인별 파라미터 조정 계수
        domain_adjustments = {
            "shopping": {"grip_force_n": 1.2, "approach_speed": 1.3, "max_speed_ms": 1.5},
            "cooking": {"grip_force_n": 0.8, "approach_speed": 0.7, "reaction_time_ms": 1.0},
            "craft": {"grip_force_n": 0.9, "approach_speed": 0.5, "reaction_time_ms": 0.8},
            "public_transport": {"max_speed_ms": 1.2, "safe_distance_m": 1.5},
            "field_trip": {"max_speed_ms": 1.0, "map_resolution_m": 0.5},
            "cleaning": {"grip_force_n": 1.5, "approach_speed": 1.0},
            "ball_sports": {"reaction_time_ms": 0.5, "grip_force_n": 2.0},
            "customer_service": {"speech_rate": 1.0, "gesture_amplitude": 0.8},
        }

        adjustments = domain_adjustments.get(target_domain, {})
        for param, factor in adjustments.items():
            if param in adapted:
                adapted[param] = adapted[param] * factor

        # AI 추론으로 미세 조정
        if self._gemma4 and context:
            try:
                prompt = (
                    f"스킬 '{skill.name}'의 파라미터를 {target_domain} 도메인에 맞게 조정하세요.\n"
                    f"원본 파라미터: {json.dumps(adapted, ensure_ascii=False)}\n"
                    f"컨텍스트: {json.dumps(context, ensure_ascii=False)[:200]}\n"
                    f"조정된 파라미터를 JSON으로 출력하세요."
                )
                result = self._gemma4.generate(prompt, max_tokens=200, temperature=0.3)
                # AI 결과 파싱 시도
                if result and result.text:
                    try:
                        json_start = result.text.find("{")
                        json_end = result.text.rfind("}") + 1
                        if json_start >= 0 and json_end > json_start:
                            ai_params = json.loads(result.text[json_start:json_end])
                            for k, v in ai_params.items():
                                if isinstance(v, (int, float)):
                                    adapted[k] = v
                    except json.JSONDecodeError:
                        pass
            except Exception:
                pass

        return adapted

    def _evaluate_transfer_confidence(self, skill: Skill, target_domain: str) -> float:
        """전이 신뢰도 평가"""
        base_confidence = 0.7  # 기본 신뢰도

        # 원래 도메인 성공률 반영
        base_confidence *= (0.5 + 0.5 * skill.success_rate)

        # 전이 횟수 반영 (많이 전이될수록 검증됨)
        if skill.transfer_count > 0:
            base_confidence = min(1.0, base_confidence + 0.05 * skill.transfer_count)

        return base_confidence

    def _find_indirect_transfers(self, source: str, target: str) -> List[Skill]:
        """간접 전이 경로 탐색 (A→B→C)"""
        results = []
        for skill in self._skill_db.values():
            if skill.source_domain == source:
                for intermediate in skill.target_domains:
                    for skill2 in self._skill_db.values():
                        if skill2.source_domain == intermediate and target in skill2.target_domains:
                            results.append(skill)
                            results.append(skill2)
                            break
        return results

    def _generate_transfer_notes(self, skill: Skill, target_domain: str) -> str:
        """전이 노트 생성"""
        principles = ", ".join(skill.core_principles[:2])
        return (
            f"스킬 '{skill.name}' ({skill.source_domain})을 {target_domain}에 적용. "
            f"핵심 원리: {principles}"
        )

    def learn_from_experience(
        self, skill_name: str, domain: str, success: bool, parameters_used: Dict[str, float]
    ) -> None:
        """경험으로부터 전이 매핑 학습"""
        if skill_name in self._skill_db:
            skill = self._skill_db[skill_name]
            if success and domain not in skill.target_domains:
                # 성공한 도메인을 전이 대상에 추가
                skill.target_domains.append(domain)
                logger.info(f"새 전이 매핑 학습: {skill_name} → {domain}")

    def get_transferable_skills(self, domain: str) -> List[Skill]:
        """특정 도메인에 전이 가능한 스킬 목록"""
        return [
            s for s in self._skill_db.values()
            if domain in s.target_domains
        ]

    def get_statistics(self) -> Dict[str, Any]:
        """전이 통계"""
        with self._lock:
            return {
                "total_skills": len(self._skill_db),
                "total_transfers": len(self._transfer_history),
                "avg_confidence": np.mean([t.get("confidence", 0) for t in self._transfer_history]) if self._transfer_history else 0.0,
            }
