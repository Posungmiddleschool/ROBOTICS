#!/usr/bin/env python3
"""
physical_task_curriculum.py — Physical Task Curriculum for Jihun Robot V8.5 (Physical AGI)

물리적 과제 커리큘럼 — 로봇이 직접 체험하며 배우는 구조화된 물리 과제 진행 체계.
단순한 보행부터 복잡한 공예까지, 각 과제는 로봇이 직접 시도·실패·적응·숙달하는
구체화된 상호작용(embodied interaction)을 통해 물리 세계를 가르친다.

This is NOT about reading about tasks. The robot physically attempts, fails,
adapts, and masters tasks through embodied interaction.

Key Concepts:
  - Vygotsky's Zone of Proximal Development (ZPD) applied to physical skills
  - Progressive difficulty from simple walking to complex craftwork
  - Learning through DOING: attempt → fail → adapt → master
  - Safety constraints for every physical interaction
  - Quantitative success criteria with measurable thresholds

Author: Jihun Robot V8.5 Team
License: MIT
"""

from __future__ import annotations

import json
import logging
import sqlite3
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum, IntEnum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

# ─── 로깅 설정 / Logging Configuration ───────────────────────────────────────

logger = logging.getLogger("physical_task_curriculum")
logger.setLevel(logging.DEBUG)

_formatter = logging.Formatter(
    "[%(asctime)s] %(levelname)s %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

_console_handler = logging.StreamHandler()
_console_handler.setLevel(logging.INFO)
_console_handler.setFormatter(_formatter)
logger.addHandler(_console_handler)

# 파일 핸들러는 모듈 초기화 시 설정 / File handler set during module init
_file_handler: Optional[logging.FileHandler] = None


# ═══════════════════════════════════════════════════════════════════════════════
# 열거형 / Enumerations
# ═══════════════════════════════════════════════════════════════════════════════


class TaskDifficulty(IntEnum):
    """
    과제 난이도 척도 (1~10) / Task difficulty scale (1-10).

    1  — 가장 기초적인 물리 과제 / Most basic physical task
    5  — 중간 수준, 기본 숙련 필요 / Intermediate, requires basic proficiency
    10 — 최고 난이도, 복합 숙련 필요 / Highest difficulty, requires compound mastery
    """

    LEVEL_1 = 1
    LEVEL_2 = 2
    LEVEL_3 = 3
    LEVEL_4 = 4
    LEVEL_5 = 5
    LEVEL_6 = 6
    LEVEL_7 = 7
    LEVEL_8 = 8
    LEVEL_9 = 9
    LEVEL_10 = 10


class TaskCategory(Enum):
    """
    물리 과제 카테고리 / Physical task categories.

    각 카테고리는 로봇이 습득해야 할 물리적 역량의 독립적 영역을 나타낸다.
    Each category represents an independent domain of physical capability.

    V8.5 Physical AGI: 8개 신규 도메인 추가 (쇼핑, 요리, 청소, 공예, 대중교통, 고객서비스, 구기운동, 현장학습)
    """

    LOCOMOTION = "locomotion"                      # 이동 / Walking & moving
    TERRAIN_NAVIGATION = "terrain_navigation"      # 지형 탐색 / Terrain traversal
    LIFTING = "lifting"                            # 들어올리기 / Picking up
    CARRYING = "carrying"                          # 운반 / Transporting objects
    PRECISE_MANIPULATION = "precise_manipulation"  # 정밀 조작 / Fine motor control
    CRAFTWORK = "craftwork"                        # 공예 / Craft & creation
    TOOL_USE = "tool_use"                          # 도구 사용 / Tool operation
    MULTI_STEP = "multi_step"                      # 다단계 과제 / Sequential tasks
    EXPLORATION = "exploration"                    # 탐험 / Unknown environment
    # V8.5 Physical AGI 신규 카테고리 / New categories
    SHOPPING = "shopping"                          # 쇼핑 / Store navigation & purchasing
    COOKING = "cooking"                            # 요리 / Food preparation & cooking
    CLEANING = "cleaning"                          # 청소 / Cleaning & tidying
    PUBLIC_TRANSPORT = "public_transport"          # 대중교통 / Using public transit
    CUSTOMER_SERVICE = "customer_service"          # 고객 서비스 / Serving customers
    BALL_SPORTS = "ball_sports"                    # 구기 운동 / Ball sports (throw, catch, aim)
    FIELD_TRIP = "field_trip"                      # 현장 학습 / Outdoor navigation & observation


# ═══════════════════════════════════════════════════════════════════════════════
# 데이터 클래스 / Data Classes
# ═══════════════════════════════════════════════════════════════════════════════


@dataclass
class PhysicalTask:
    """
    물리 과제 정의 / Physical task definition.

    로봇이 직접 수행해야 할 물리적 과제의 완전한 명세.
    성공 기준, 안전 제약, 전제 조건 등을 모두 포함한다.

    Attributes:
        task_id: 과제 고유 식별자 / Unique task identifier
        name: 과제 이름 / Human-readable task name
        category: 과제 카테고리 / Task category
        difficulty: 난이도 (1~10) / Difficulty level (1-10)
        description: 로봇이 물리적으로 달성해야 할 내용 / What robot must physically accomplish
        required_primitive_skills: 사전 숙달 필수 원시 기술 / Primitives that must be mastered first
        success_criteria: 성공 기준 (키: 측정명, 값: 임계값) / Measurable success thresholds
        safety_constraints: 안전 제약 / Safety limits that must never be violated
        terrain_requirements: 필요 지형 조건 / Required terrain type
        object_requirements: 필요 물체 목록 / Objects needed for the task
        typical_duration_s: 일반 소요 시간(초) / Typical completion time in seconds
        prerequisite_task_ids: 선수 과제 ID 목록 / Tasks that must be completed first
        energy_estimate_j: 예상 에너지 소비(줄) / Estimated energy consumption in Joules
    """

    task_id: str
    name: str
    category: TaskCategory
    difficulty: TaskDifficulty
    description: str
    required_primitive_skills: List[str] = field(default_factory=list)
    success_criteria: Dict[str, float] = field(default_factory=dict)
    safety_constraints: Dict[str, float] = field(default_factory=dict)
    terrain_requirements: str = "flat"
    object_requirements: List[str] = field(default_factory=list)
    typical_duration_s: float = 30.0
    prerequisite_task_ids: List[str] = field(default_factory=list)
    energy_estimate_j: float = 100.0

    def to_dict(self) -> Dict[str, Any]:
        """데이터클래스를 직렬화 가능한 dict로 변환 / Serialize to dict."""
        d = asdict(self)
        d["category"] = self.category.value
        d["difficulty"] = int(self.difficulty)
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PhysicalTask":
        """dict에서 PhysicalTask 복원 / Deserialize from dict."""
        d["category"] = TaskCategory(d["category"])
        d["difficulty"] = TaskDifficulty(d["difficulty"])
        return cls(**d)


@dataclass
class TaskOutcome:
    """
    과제 수행 결과 / Task attempt outcome.

    로봇이 과제를 시도한 후의 측정 결과. 성공/실패, 정밀도, 안정성,
    학습 가치 등을 정량적으로 기록한다.

    Attributes:
        task_id: 수행한 과제 ID / Task that was attempted
        attempt_number: 시도 횟수 / Attempt number (1-based)
        success: 성공 여부 / Whether task was completed successfully
        completion_time_s: 완료 시간(초) / Time to complete in seconds
        precision_scores: 정밀도 점수 / Per-metric precision scores
        stability_score: 안정성 점수 (0~1) / Postural stability during task
        force_efficiency: 힘 효율 (0~1) / How efficiently force was applied
        learning_value: 학습 가치 (0~1) / How much new information this attempt provided
        failure_mode: 실패 원인 / Failure mode if unsuccessful
        timestamp: 기록 시각 / ISO-8601 timestamp
    """

    task_id: str
    attempt_number: int
    success: bool
    completion_time_s: float
    precision_scores: Dict[str, float] = field(default_factory=dict)
    stability_score: float = 0.0
    force_efficiency: float = 0.0
    learning_value: float = 0.0
    failure_mode: Optional[str] = None
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> Dict[str, Any]:
        """직렬화 / Serialize to dict."""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TaskOutcome":
        """역직렬화 / Deserialize from dict."""
        return cls(**d)


# ═══════════════════════════════════════════════════════════════════════════════
# 근접발달영역 (ZPD) / Zone of Proximal Development
# ═══════════════════════════════════════════════════════════════════════════════


class ZoneOfProximalDevelopment:
    """
    비고츠키 근접발달영역(ZPD)의 물리 과제 적용 / Vygotsky's ZPD applied to physical tasks.

    로봇의 현재 역량 수준을 평가하고, 적절한 도전 수준(70~85% 성공률 영역)의
    과제를 선택한다. 너무 쉬우면 학습이 없고, 너무 어려우면 좌절만 남는다.
    ZPD 영역의 과제가 가장 효율적인 학습을 제공한다.

    Assess the robot's current capability and select tasks in the 70-85% success
    rate zone — challenging enough to learn, achievable enough to persist.
    """

    # ZPD 목표 성공률 범위 / Target success rate window for ZPD
    ZPD_LOWER_BOUND: float = 0.70  # 하한 / Lower bound
    ZPD_UPPER_BOUND: float = 0.85  # 상한 / Upper bound

    # 플래토(정체) 감지 파라미터 / Plateau detection parameters
    PLATEAU_IMPROVEMENT_THRESHOLD: float = 0.02  # 2% 미만 개선 시 정체 간주
    PLATEAU_WINDOW_DEFAULT: int = 10

    def __init__(self) -> None:
        # 카테고리별 최근 결과 추적 / Track recent outcomes per category
        self._category_outcomes: Dict[TaskCategory, List[TaskOutcome]] = {}
        # 카테고리별 현재 난이도 수준 / Current difficulty level per category
        self._current_levels: Dict[TaskCategory, TaskDifficulty] = {}
        logger.info(
            "ZoneOfProximalDevelopment 초기화 완료 / ZPD initialized "
            f"(target success rate: {self.ZPD_LOWER_BOUND:.0%}–{self.ZPD_UPPER_BOUND:.0%})"
        )

    # ─── 현재 수준 평가 / Assess current level ──────────────────────────────

    def assess_current_level(self, task_category: TaskCategory) -> TaskDifficulty:
        """
        주어진 카테고리의 현재 역량 수준 평가 / Assess current capability level.

        최근 시도들의 성공률을 분석하여 로봇의 현재 난이도 수준을 추정한다.
        Analyzes recent attempt success rates to estimate the robot's current
        difficulty level in the given category.

        Args:
            task_category: 평가할 카테고리 / Category to assess

        Returns:
            추정된 현재 난이도 수준 / Estimated current difficulty level
        """
        outcomes = self._category_outcomes.get(task_category, [])

        if not outcomes:
            # 시도 기록이 없으면 가장 기초 수준 / No attempts → base level
            self._current_levels[task_category] = TaskDifficulty.LEVEL_1
            logger.info(
                f"[{task_category.value}] 시도 기록 없음 → LEVEL_1 / "
                f"No prior attempts → LEVEL_1"
            )
            return TaskDifficulty.LEVEL_1

        # 최근 20개 시도 분석 / Analyze last 20 attempts
        recent = outcomes[-20:]
        success_rate = sum(1 for o in recent if o.success) / len(recent)

        # 성공한 과제들의 최대 난이도 추출 / Find max difficulty among successful tasks
        # 이 정보는 외부에서 제공되어야 하지만, outcome의 learning_value를
        # 프록시로 사용하여 수준 추정
        avg_learning = np.mean([o.learning_value for o in recent])
        avg_stability = np.mean([o.stability_score for o in recent])

        # 종합 역량 지표 / Composite capability metric
        capability = (
            success_rate * 0.5
            + avg_stability * 0.3
            + min(avg_learning * 2, 1.0) * 0.2
        )

        # 역량을 난이도 수준으로 매핑 (0~1 → 1~10) / Map capability to difficulty
        level = max(1, min(10, int(round(capability * 10))))
        difficulty = TaskDifficulty(level)

        self._current_levels[task_category] = difficulty
        logger.info(
            f"[{task_category.value}] 수준 평가: LEVEL_{level} "
            f"(성공률={success_rate:.1%}, 안정성={avg_stability:.2f}, "
            f"학습가치={avg_learning:.2f}) / "
            f"Assessed: LEVEL_{level} "
            f"(success={success_rate:.1%}, stability={avg_stability:.2f}, "
            f"learning={avg_learning:.2f})"
        )
        return difficulty

    # ─── 다음 과제 선택 / Select next task ───────────────────────────────────

    def select_next_task(
        self,
        task_category: TaskCategory,
        current_level: TaskDifficulty,
        available_tasks: Optional[List[PhysicalTask]] = None,
    ) -> Optional[PhysicalTask]:
        """
        ZPD 영역의 다음 과제 선택 / Select next task in the ZPD zone.

        현재 수준보다 약간 높은 난이도의 과제를 선택하여 최적의 학습 효과를
        달성한다. 70~85% 성공률을 목표로 하는 과제를 우선 선택한다.

        Args:
            task_category: 과제 카테고리 / Task category
            current_level: 현재 난이도 수준 / Current difficulty level
            available_tasks: 선택 가능한 과제 목록 / Available tasks to choose from

        Returns:
            ZPD 영역의 과제 (없으면 None) / Task in ZPD zone, or None
        """
        if available_tasks is None:
            logger.warning(
                f"[{task_category.value}] 선택 가능한 과제 없음 / No available tasks"
            )
            return None

        # 카테고리 필터링 / Filter by category
        category_tasks = [t for t in available_tasks if t.category == task_category]
        if not category_tasks:
            logger.warning(
                f"[{task_category.value}] 해당 카테고리 과제 없음 / "
                f"No tasks in this category"
            )
            return None

        # ZPD 타겟: 현재 수준 + 1 (적절한 도전) / ZPD target: current + 1
        target_level = TaskDifficulty(min(current_level + 1, 10))

        # 타겟 난이도 과제 우선 선택 / Prefer tasks at target difficulty
        target_tasks = [t for t in category_tasks if t.difficulty == target_level]

        if target_tasks:
            selected = target_tasks[0]
            logger.info(
                f"[{task_category.value}] ZPD 과제 선택: {selected.task_id} "
                f"(난이도 {int(selected.difficulty)}, 현재 수준 {int(current_level)}) / "
                f"ZPD task: {selected.task_id} "
                f"(difficulty {int(selected.difficulty)}, current {int(current_level)})"
            )
            return selected

        # 타겟 난이도가 없으면 현재 수준 또는 +2 범위 탐색
        # Fallback: search current level or +2 range
        for delta in [0, 2, -1]:
            level = TaskDifficulty(max(1, min(10, current_level + delta)))
            fallback_tasks = [t for t in category_tasks if t.difficulty == level]
            if fallback_tasks:
                selected = fallback_tasks[0]
                logger.info(
                    f"[{task_category.value}] 대체 과제 선택: {selected.task_id} "
                    f"(난이도 {int(selected.difficulty)}) / "
                    f"Fallback task: {selected.task_id} "
                    f"(difficulty {int(selected.difficulty)})"
                )
                return selected

        logger.warning(
            f"[{task_category.value}] ZPD 영역에 적합한 과제 없음 / "
            f"No suitable task in ZPD zone"
        )
        return None

    # ─── 난이도 조정 / Adjust difficulty ──────────────────────────────────────

    def adjust_difficulty(self, recent_outcomes: List[TaskOutcome]) -> TaskDifficulty:
        """
        최근 결과에 따른 난이도 조정 / Adjust difficulty based on recent outcomes.

        성공률이 85% 초과 → 난이도 상향 (너무 쉬움)
        성공률이 70% 미만 → 난이도 하향 (너무 어려움)
        70~85% → 유지 (ZPD 영역)

        Adjusts difficulty up if success rate > 85% (too easy),
        down if < 70% (too hard), maintains if in ZPD sweet spot.

        Args:
            recent_outcomes: 최근 과제 수행 결과 / Recent task outcomes

        Returns:
            조정된 난이도 수준 / Adjusted difficulty level
        """
        if not recent_outcomes:
            return TaskDifficulty.LEVEL_1

        success_rate = sum(1 for o in recent_outcomes if o.success) / len(
            recent_outcomes
        )

        # 현재 수준 추정 (과제 ID 기반은 외부 정보 필요 → outcome의 learning_value 활용)
        # Estimate current level from outcomes
        avg_learning = np.mean([o.learning_value for o in recent_outcomes])
        estimated_level = max(1, min(10, int(round(avg_learning * 10 + 1))))
        current = TaskDifficulty(estimated_level)

        if success_rate > self.ZPD_UPPER_BOUND:
            # 성공률 너무 높음 → 난이도 상향 / Too easy → increase
            new_level = TaskDifficulty(min(10, current + 1))
            logger.info(
                f"난이도 상향: LEVEL_{int(current)} → LEVEL_{int(new_level)} "
                f"(성공률={success_rate:.1%} > {self.ZPD_UPPER_BOUND:.0%}) / "
                f"Difficulty UP: {int(current)}→{int(new_level)} "
                f"(success={success_rate:.1%})"
            )
            return new_level

        elif success_rate < self.ZPD_LOWER_BOUND:
            # 성공률 너무 낮음 → 난이도 하향 / Too hard → decrease
            new_level = TaskDifficulty(max(1, current - 1))
            logger.info(
                f"난이도 하향: LEVEL_{int(current)} → LEVEL_{int(new_level)} "
                f"(성공률={success_rate:.1%} < {self.ZPD_LOWER_BOUND:.0%}) / "
                f"Difficulty DOWN: {int(current)}→{int(new_level)} "
                f"(success={success_rate:.1%})"
            )
            return new_level

        else:
            # ZPD 영역 → 유지 / In ZPD zone → maintain
            logger.info(
                f"난이도 유지: LEVEL_{int(current)} "
                f"(성공률={success_rate:.1%}, ZPD 영역) / "
                f"Difficulty MAINTAIN: {int(current)} "
                f"(success={success_rate:.1%}, in ZPD)"
            )
            return current

    # ─── 플래토(정체) 감지 / Detect plateau ──────────────────────────────────

    def detect_plateau(
        self, recent_outcomes: List[TaskOutcome], window: int = 10
    ) -> bool:
        """
        학습 정체(플래토) 감지 / Detect learning plateau.

        최근 N번의 시도에서 유의미한 성능 향상이 없으면 플래토로 판단한다.
        동일한 난이도에서 반복적으로 실패하거나, 성공률이 정체되는 경우가 해당된다.

        Detects plateau when there's no meaningful improvement across recent
        attempts — the robot is stuck and needs a breakthrough strategy.

        Args:
            recent_outcomes: 최근 과제 수행 결과 / Recent outcomes
            window: 분석 윈도우 크기 / Number of recent attempts to analyze

        Returns:
            플래토 여부 / Whether a plateau is detected
        """
        if len(recent_outcomes) < window:
            logger.debug(
                f"플래토 분석: 데이터 부족 ({len(recent_outcomes)}/{window}) / "
                f"Plateau check: insufficient data ({len(recent_outcomes)}/{window})"
            )
            return False

        recent = recent_outcomes[-window:]

        # 성공률 추세 분석 / Analyze success rate trend
        # 윈도우를 반으로 나누어 전반부/후반부 비교
        half = window // 2
        first_half = recent[:half]
        second_half = recent[half:]

        first_success_rate = sum(1 for o in first_half if o.success) / len(first_half)
        second_success_rate = sum(1 for o in second_half if o.success) / len(second_half)

        # 학습 가치 추세 / Learning value trend
        first_avg_learning = np.mean([o.learning_value for o in first_half])
        second_avg_learning = np.mean([o.learning_value for o in second_half])

        # 안정성 추세 / Stability trend
        first_avg_stability = np.mean([o.stability_score for o in first_half])
        second_avg_stability = np.mean([o.stability_score for o in second_half])

        # 종합 개선도 / Composite improvement
        success_improvement = second_success_rate - first_success_rate
        learning_improvement = second_avg_learning - first_avg_learning
        stability_improvement = second_avg_stability - first_avg_stability

        total_improvement = (
            success_improvement * 0.4
            + learning_improvement * 0.3
            + stability_improvement * 0.3
        )

        is_plateau = total_improvement < self.PLATEAU_IMPROVEMENT_THRESHOLD

        if is_plateau:
            logger.warning(
                f"⚡ 학습 정체(플래토) 감지! 최근 {window}회 시도에서 "
                f"개선도={total_improvement:.3f} < {self.PLATEAU_IMPROVEMENT_THRESHOLD} / "
                f"Plateau detected! improvement={total_improvement:.3f} "
                f"over last {window} attempts"
            )
        else:
            logger.debug(
                f"플래토 아님: 개선도={total_improvement:.3f} / "
                f"No plateau: improvement={total_improvement:.3f}"
            )

        return is_plateau

    # ─── 돌파 전략 제안 / Suggest breakthrough strategy ──────────────────────

    def suggest_breakthrough_strategy(self, plateau_context: str) -> str:
        """
        플래토 돌파 전략 제안 / Suggest strategy to break through a plateau.

        정체 원인에 따라 다른 돌파 전략을 제안한다:
        - lost_balance → 안정성 훈련 우선
        - excessive_force → 힘 조절 훈련
        - imprecise_grip → 정밀 그립 훈련
        - timeout → 효율성 훈련
        - general → 난이도 일시 하향 또는 다른 카테고리 전환

        Args:
            plateau_context: 정체 맥락 (주로 실패 모드) / Plateau context (typically failure mode)

        Returns:
            돌파 전략 설명 / Breakthrough strategy description
        """
        strategies: Dict[str, str] = {
            "lost_balance": (
                "🏠 안정성 돌파: 보행 안정성 기초 훈련으로 회귀하세요. "
                "한 발 서기, 무게 중심 이동 연습을 반복한 후 다시 도전하세요. "
                "/ Stability breakthrough: Return to balance fundamentals. "
                "Practice single-leg stance and center-of-gravity shifts before retrying."
            ),
            "excessive_force": (
                "🏠 힘 조절 돌파: 더 부드러운 물체(스펀지, 젤리)로 힘 제어를 "
                "연습하세요. 점진적으로 단단한 물체로 전환하세요. "
                "/ Force control breakthrough: Practice on softer objects (sponge, jelly). "
                "Gradually transition to harder objects."
            ),
            "imprecise_grip": (
                "🏠 그립 정밀도 돌파: 더 큰 물체로 그립 연습을 시작하세요. "
                "성공하면 점차 작은 물체로 전환하세요. "
                "/ Grip precision breakthrough: Start with larger objects. "
                "Gradually reduce object size as precision improves."
            ),
            "timeout": (
                "🏠 효율성 돌파: 동작 속도보다 정확도에 집중하세요. "
                "정확도가 확보되면 자연스럽게 속도가 향상됩니다. "
                "/ Efficiency breakthrough: Focus on accuracy over speed. "
                "Speed will naturally improve once accuracy is established."
            ),
        }

        if plateau_context in strategies:
            strategy = strategies[plateau_context]
        else:
            strategy = (
                "🏠 일반 돌파 전략: (1) 난이도를 1~2단계 일시 하향하세요. "
                "(2) 다른 카테고리의 과제를 먼저 수행하여 교차 학습 효과를 얻으세요. "
                "(3) 기초 원시 기술을 재훈련하세요. "
                "/ General breakthrough: (1) Temporarily reduce difficulty by 1-2 levels. "
                "(2) Try tasks in a different category for cross-training. "
                "(3) Retrain foundational primitive skills."
            )

        logger.info(
            f"💡 돌파 전략 제안 (맥락: {plateau_context}): {strategy[:80]}... / "
            f"Breakthrough strategy (context: {plateau_context})"
        )
        return strategy

    # ─── 결과 업데이트 / Update with outcome ──────────────────────────────────

    def update_outcome(self, outcome: TaskOutcome, category: TaskCategory) -> None:
        """
        과제 결과를 ZPD 추적에 반영 / Incorporate outcome into ZPD tracking.

        Args:
            outcome: 과제 수행 결과 / Task outcome
            category: 해당 카테고리 / Task category
        """
        if category not in self._category_outcomes:
            self._category_outcomes[category] = []
        self._category_outcomes[category].append(outcome)
        logger.debug(
            f"[{category.value}] 결과 기록: 과제={outcome.task_id}, "
            f"성공={outcome.success}, 시도={outcome.attempt_number} / "
            f"Outcome recorded: task={outcome.task_id}, "
            f"success={outcome.success}, attempt={outcome.attempt_number}"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# 물리 과제 커리큘럼 / Physical Task Curriculum
# ═══════════════════════════════════════════════════════════════════════════════


class PhysicalTaskCurriculum:
    """
    물리 과제 커리큘럼 관리자 / Physical Task Curriculum Manager.

    48개 이상의 물리 과제를 카테고리 및 난이도별로 조직하고, ZPD 기반
    과제 선택, 진도 추적, 약점 분석, AGI 수준 추정 기능을 제공한다.
    모든 데이터는 SQLite에 영속적으로 저장된다.

    Manages 48+ physical tasks organized by category and difficulty, with
    ZPD-based task selection, progress tracking, weakness analysis, and
    AGI level estimation. All data persists in SQLite.
    """

    DEFAULT_DB_PATH = "physical_curriculum.db"

    def __init__(self, db_path: Optional[str] = None) -> None:
        """
        커리큘럼 관리자 초기화 / Initialize curriculum manager.

        Args:
            db_path: SQLite 데이터베이스 경로 / Path to SQLite database
        """
        self._db_path = db_path or self.DEFAULT_DB_PATH
        self._tasks: Dict[str, PhysicalTask] = {}
        self._outcomes: List[TaskOutcome] = []
        self._completed_task_ids: set = set()
        self._zpd = ZoneOfProximalDevelopment()
        self._initialized = False

        # 파일 로깅 설정 / Set up file logging
        global _file_handler
        if _file_handler is None:
            log_dir = Path(self._db_path).parent
            log_file = log_dir / "physical_curriculum.log"
            _file_handler = logging.FileHandler(str(log_file), encoding="utf-8")
            _file_handler.setLevel(logging.DEBUG)
            _file_handler.setFormatter(_formatter)
            logger.addHandler(_file_handler)

        logger.info(
            f"PhysicalTaskCurriculum 생성 (DB: {self._db_path}) / "
            f"Curriculum created (DB: {self._db_path})"
        )

    # ═════════════════════════════════════════════════════════════════════════
    # 데이터베이스 초기화 및 영속성 / Database Initialization & Persistence
    # ═════════════════════════════════════════════════════════════════════════

    def _init_db(self) -> None:
        """SQLite 데이터베이스 스키마 초기화 / Initialize SQLite schema."""
        conn = sqlite3.connect(self._db_path)
        cursor = conn.cursor()

        # 과제 정의 테이블 / Task definitions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id         TEXT PRIMARY KEY,
                name            TEXT NOT NULL,
                category        TEXT NOT NULL,
                difficulty      INTEGER NOT NULL,
                description     TEXT NOT NULL,
                required_primitive_skills TEXT NOT NULL DEFAULT '[]',
                success_criteria    TEXT NOT NULL DEFAULT '{}',
                safety_constraints  TEXT NOT NULL DEFAULT '{}',
                terrain_requirements TEXT NOT NULL DEFAULT 'flat',
                object_requirements  TEXT NOT NULL DEFAULT '[]',
                typical_duration_s   REAL NOT NULL DEFAULT 30.0,
                prerequisite_task_ids TEXT NOT NULL DEFAULT '[]',
                energy_estimate_j    REAL NOT NULL DEFAULT 100.0
            )
        """)

        # 과제 수행 결과 테이블 / Task outcomes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS outcomes (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id         TEXT NOT NULL,
                attempt_number  INTEGER NOT NULL,
                success         INTEGER NOT NULL,
                completion_time_s REAL NOT NULL,
                precision_scores   TEXT NOT NULL DEFAULT '{}',
                stability_score    REAL NOT NULL DEFAULT 0.0,
                force_efficiency   REAL NOT NULL DEFAULT 0.0,
                learning_value     REAL NOT NULL DEFAULT 0.0,
                failure_mode       TEXT,
                timestamp          TEXT NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(task_id)
            )
        """)

        # 과제 완료 상태 테이블 / Task mastery tracking table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS mastery (
                task_id         TEXT PRIMARY KEY,
                mastered        INTEGER NOT NULL DEFAULT 0,
                best_score      REAL NOT NULL DEFAULT 0.0,
                attempt_count   INTEGER NOT NULL DEFAULT 0,
                success_count   INTEGER NOT NULL DEFAULT 0,
                last_attempt_ts TEXT,
                FOREIGN KEY (task_id) REFERENCES tasks(task_id)
            )
        """)

        # 인덱스 생성 / Create indices
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_outcomes_task_id ON outcomes(task_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_outcomes_timestamp ON outcomes(timestamp)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_tasks_difficulty ON tasks(difficulty)"
        )

        conn.commit()
        conn.close()
        logger.debug("SQLite 스키마 초기화 완료 / SQLite schema initialized")

    def _save_task_to_db(self, task: PhysicalTask) -> None:
        """과제 정의를 DB에 저장 / Save task definition to database."""
        conn = sqlite3.connect(self._db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT OR REPLACE INTO tasks (
                task_id, name, category, difficulty, description,
                required_primitive_skills, success_criteria, safety_constraints,
                terrain_requirements, object_requirements, typical_duration_s,
                prerequisite_task_ids, energy_estimate_j
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                task.task_id,
                task.name,
                task.category.value,
                int(task.difficulty),
                task.description,
                json.dumps(task.required_primitive_skills),
                json.dumps(task.success_criteria),
                json.dumps(task.safety_constraints),
                task.terrain_requirements,
                json.dumps(task.object_requirements),
                task.typical_duration_s,
                json.dumps(task.prerequisite_task_ids),
                task.energy_estimate_j,
            ),
        )
        conn.commit()
        conn.close()

    def _save_outcome_to_db(self, outcome: TaskOutcome) -> None:
        """과제 수행 결과를 DB에 저장 / Save outcome to database."""
        conn = sqlite3.connect(self._db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO outcomes (
                task_id, attempt_number, success, completion_time_s,
                precision_scores, stability_score, force_efficiency,
                learning_value, failure_mode, timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                outcome.task_id,
                outcome.attempt_number,
                int(outcome.success),
                outcome.completion_time_s,
                json.dumps(outcome.precision_scores),
                outcome.stability_score,
                outcome.force_efficiency,
                outcome.learning_value,
                outcome.failure_mode,
                outcome.timestamp,
            ),
        )

        # 마스터리 테이블 업데이트 / Update mastery table
        cursor.execute(
            "SELECT attempt_count, success_count, best_score FROM mastery WHERE task_id = ?",
            (outcome.task_id,),
        )
        row = cursor.fetchone()

        if row:
            attempt_count = row[0] + 1
            success_count = row[1] + (1 if outcome.success else 0)
            best_score = max(row[2], self._compute_outcome_score(outcome))
            mastered = 1 if (success_count / attempt_count >= 0.8 and attempt_count >= 3) else 0
            cursor.execute(
                """
                UPDATE mastery
                SET attempt_count=?, success_count=?, best_score=?, mastered=?, last_attempt_ts=?
                WHERE task_id=?
                """,
                (attempt_count, success_count, best_score, mastered, outcome.timestamp, outcome.task_id),
            )
        else:
            attempt_count = 1
            success_count = 1 if outcome.success else 0
            best_score = self._compute_outcome_score(outcome)
            cursor.execute(
                """
                INSERT INTO mastery (task_id, mastered, best_score, attempt_count, success_count, last_attempt_ts)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (outcome.task_id, 0, best_score, attempt_count, success_count, outcome.timestamp),
            )

        conn.commit()
        conn.close()

    def _load_tasks_from_db(self) -> Dict[str, PhysicalTask]:
        """DB에서 과제 정의 로드 / Load task definitions from database."""
        tasks: Dict[str, PhysicalTask] = {}
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tasks")
            rows = cursor.fetchall()
            conn.close()

            for row in rows:
                task = PhysicalTask(
                    task_id=row[0],
                    name=row[1],
                    category=TaskCategory(row[2]),
                    difficulty=TaskDifficulty(row[3]),
                    description=row[4],
                    required_primitive_skills=json.loads(row[5]),
                    success_criteria=json.loads(row[6]),
                    safety_constraints=json.loads(row[7]),
                    terrain_requirements=row[8],
                    object_requirements=json.loads(row[9]),
                    typical_duration_s=row[10],
                    prerequisite_task_ids=json.loads(row[11]),
                    energy_estimate_j=row[12],
                )
                tasks[task.task_id] = task
        except sqlite3.OperationalError:
            logger.debug("DB에 과제 데이터 없음 / No task data in DB yet")

        return tasks

    def _load_outcomes_from_db(self) -> List[TaskOutcome]:
        """DB에서 과제 결과 로드 / Load outcomes from database."""
        outcomes: List[TaskOutcome] = []
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM outcomes ORDER BY timestamp")
            rows = cursor.fetchall()
            conn.close()

            for row in rows:
                outcome = TaskOutcome(
                    task_id=row[1],
                    attempt_number=row[2],
                    success=bool(row[3]),
                    completion_time_s=row[4],
                    precision_scores=json.loads(row[5]),
                    stability_score=row[6],
                    force_efficiency=row[7],
                    learning_value=row[8],
                    failure_mode=row[9],
                    timestamp=row[10],
                )
                outcomes.append(outcome)
        except sqlite3.OperationalError:
            logger.debug("DB에 결과 데이터 없음 / No outcome data in DB yet")

        return outcomes

    def _load_mastery_from_db(self) -> set:
        """DB에서 숙달 과제 로드 / Load mastered task IDs from database."""
        mastered: set = set()
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT task_id FROM mastery WHERE mastered = 1")
            rows = cursor.fetchall()
            conn.close()
            mastered = {row[0] for row in rows}
        except sqlite3.OperationalError:
            logger.debug("DB에 마스터리 데이터 없음 / No mastery data in DB yet")

        return mastered

    @staticmethod
    def _compute_outcome_score(outcome: TaskOutcome) -> float:
        """
        과제 결과의 종합 점수 계산 (0~1) / Compute composite outcome score.

        성공 여부, 정밀도, 안정성, 힘 효율을 종합하여 0~1 점수를 산출한다.
        """
        precision_avg = (
            np.mean(list(outcome.precision_scores.values()))
            if outcome.precision_scores
            else 0.5
        )
        score = (
            (1.0 if outcome.success else 0.0) * 0.4
            + precision_avg * 0.2
            + outcome.stability_score * 0.2
            + outcome.force_efficiency * 0.2
        )
        return float(np.clip(score, 0.0, 1.0))

    # ═════════════════════════════════════════════════════════════════════════
    # 과제 정의 / Task Definitions (48 tasks)
    # ═════════════════════════════════════════════════════════════════════════

    def _define_all_tasks(self) -> Dict[str, PhysicalTask]:
        """
        전체 48개 물리 과제 정의 / Define all 48 physical tasks.

        각 과제는 로봇이 직접 체험하며 배우는 구체적인 물리적 도전이다.
        난이도와 성공 기준은 실제 로봇 하드웨어 역량을 기반으로 설정한다.
        """

        tasks: Dict[str, PhysicalTask] = {}

        # ─── LOCOMOTION (8 tasks) 이동 ────────────────────────────────────────

        tasks["flat_walk_1m"] = PhysicalTask(
            task_id="flat_walk_1m",
            name="Flat Ground Walk 1m",
            category=TaskCategory.LOCOMOTION,
            difficulty=TaskDifficulty.LEVEL_1,
            description=(
                "평지에서 1미터 직선 보행. 로봇의 가장 기본적인 이동 능력. "
                "균형을 유지하며 전방으로 직진한다. "
                "/ Walk 1 meter in a straight line on flat ground. "
                "The most fundamental locomotion skill — maintain balance while walking forward."
            ),
            required_primitive_skills=["stand_still", "shift_weight", "step_forward"],
            success_criteria={
                "completion_time_s": 15.0,
                "position_error_mm": 50.0,
                "stability_score": 0.6,
                "path_deviation_mm": 30.0,
            },
            safety_constraints={
                "max_force_N": 200.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 10.0,
            },
            terrain_requirements="flat",
            object_requirements=[],
            typical_duration_s=10.0,
            prerequisite_task_ids=[],
            energy_estimate_j=50.0,
        )

        tasks["flat_walk_5m"] = PhysicalTask(
            task_id="flat_walk_5m",
            name="Flat Ground Walk 5m",
            category=TaskCategory.LOCOMOTION,
            difficulty=TaskDifficulty.LEVEL_2,
            description=(
                "평지에서 5미터 보행. 지속적인 균형 유지와 보행 리듬 유지가 필요. "
                "/ Walk 5 meters on flat ground. Requires sustained balance and consistent gait rhythm."
            ),
            required_primitive_skills=["stand_still", "shift_weight", "step_forward", "maintain_rhythm"],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 100.0,
                "stability_score": 0.65,
                "path_deviation_mm": 50.0,
            },
            safety_constraints={
                "max_force_N": 200.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 10.0,
            },
            terrain_requirements="flat",
            object_requirements=[],
            typical_duration_s=25.0,
            prerequisite_task_ids=["flat_walk_1m"],
            energy_estimate_j=150.0,
        )

        tasks["rough_terrain_walk_3m"] = PhysicalTask(
            task_id="rough_terrain_walk_3m",
            name="Rough Terrain Walk 3m",
            category=TaskCategory.LOCOMOTION,
            difficulty=TaskDifficulty.LEVEL_4,
            description=(
                "거친 지형에서 3미터 보행. 작은 장애물과 요철을 넘어 균형을 유지하며 이동. "
                "/ Walk 3 meters on rough terrain with small obstacles and uneven surface. "
                "Maintain balance while adapting steps to surface irregularities."
            ),
            required_primitive_skills=["stand_still", "shift_weight", "step_forward", "adapt_foot_placement"],
            success_criteria={
                "completion_time_s": 45.0,
                "position_error_mm": 200.0,
                "stability_score": 0.6,
                "path_deviation_mm": 150.0,
            },
            safety_constraints={
                "max_force_N": 300.0,
                "max_tilt_deg": 25.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="rough",
            object_requirements=[],
            typical_duration_s=35.0,
            prerequisite_task_ids=["flat_walk_5m"],
            energy_estimate_j=350.0,
        )

        tasks["slope_ascend_30deg"] = PhysicalTask(
            task_id="slope_ascend_30deg",
            name="Slope Ascend 30°",
            category=TaskCategory.LOCOMOTION,
            difficulty=TaskDifficulty.LEVEL_5,
            description=(
                "30도 경사면 올라가기. 무게 중심을 전방으로 이동시키며 경사에 맞춘 "
                "보행 각도 조절이 필요. 미끄러지지 않고 안정적으로 등반. "
                "/ Ascend a 30-degree slope. Shift center of gravity forward and adjust "
                "step angles for the incline. Climb without slipping."
            ),
            required_primitive_skills=["shift_weight", "step_forward", "lean_forward", "adapt_foot_placement"],
            success_criteria={
                "completion_time_s": 40.0,
                "position_error_mm": 200.0,
                "stability_score": 0.65,
                "slip_count": 2.0,
            },
            safety_constraints={
                "max_force_N": 400.0,
                "max_tilt_deg": 35.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="slope",
            object_requirements=[],
            typical_duration_s=30.0,
            prerequisite_task_ids=["flat_walk_5m", "rough_terrain_walk_3m"],
            energy_estimate_j=500.0,
        )

        tasks["stair_climb_3_steps"] = PhysicalTask(
            task_id="stair_climb_3_steps",
            name="Stair Climb 3 Steps",
            category=TaskCategory.LOCOMOTION,
            difficulty=TaskDifficulty.LEVEL_6,
            description=(
                "3계단 오르기. 각 계단의 높이에 맞춰 발을 정확히 올리고 무게 중심을 "
                "안정적으로 이동. 추락 위험이 있으므로 안전이 최우선. "
                "/ Climb 3 stairs. Precisely lift foot to each step height and shift "
                "weight stably. Safety is paramount — fall risk is present."
            ),
            required_primitive_skills=["shift_weight", "step_forward", "lift_foot_high", "stabilize_single_leg"],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 50.0,
                "stability_score": 0.7,
                "foot_placement_error_mm": 20.0,
            },
            safety_constraints={
                "max_force_N": 400.0,
                "max_tilt_deg": 30.0,
                "min_clearance_mm": 3.0,
            },
            terrain_requirements="stairs",
            object_requirements=[],
            typical_duration_s=25.0,
            prerequisite_task_ids=["slope_ascend_30deg"],
            energy_estimate_j=400.0,
        )

        tasks["uneven_rocks_traverse"] = PhysicalTask(
            task_id="uneven_rocks_traverse",
            name="Uneven Rocks Traverse",
            category=TaskCategory.LOCOMOTION,
            difficulty=TaskDifficulty.LEVEL_7,
            description=(
                "불규칙한 바위 지형 횡단. 각 발 딛는 위치의 높이와 기울기가 다른 "
                "불규칙 표면에서 실시간 적응 보행이 필요. "
                "/ Traverse irregular rocky terrain. Each foothold has different height "
                "and slope — requires real-time adaptive walking."
            ),
            required_primitive_skills=[
                "adapt_foot_placement", "shift_weight", "stabilize_single_leg",
                "perceive_surface_angle", "adjust_com_height",
            ],
            success_criteria={
                "completion_time_s": 60.0,
                "position_error_mm": 300.0,
                "stability_score": 0.6,
                "foot_placement_error_mm": 30.0,
            },
            safety_constraints={
                "max_force_N": 500.0,
                "max_tilt_deg": 30.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="uneven",
            object_requirements=[],
            typical_duration_s=50.0,
            prerequisite_task_ids=["rough_terrain_walk_3m", "stair_climb_3_steps"],
            energy_estimate_j=800.0,
        )

        tasks["narrow_beam_walk"] = PhysicalTask(
            task_id="narrow_beam_walk",
            name="Narrow Beam Walk",
            category=TaskCategory.LOCOMOTION,
            difficulty=TaskDifficulty.LEVEL_8,
            description=(
                "폭 10cm 좁은 평형봉 보행. 발의 위치 정밀도와 좌우 균형 유지가 "
                "극도로 중요. 한 발이라도 벗어나면 낙하. "
                "/ Walk across a 10cm-wide balance beam. Extreme foot placement precision "
                "and lateral balance required. One misstep means a fall."
            ),
            required_primitive_skills=[
                "precise_foot_placement", "lateral_balance", "slow_controlled_step",
            ],
            success_criteria={
                "completion_time_s": 45.0,
                "position_error_mm": 10.0,
                "stability_score": 0.8,
                "foot_placement_error_mm": 5.0,
            },
            safety_constraints={
                "max_force_N": 300.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="narrow",
            object_requirements=["balance_beam_10cm"],
            typical_duration_s=40.0,
            prerequisite_task_ids=["uneven_rocks_traverse"],
            energy_estimate_j=600.0,
        )

        tasks["dynamic_obstacle_dodge"] = PhysicalTask(
            task_id="dynamic_obstacle_dodge",
            name="Dynamic Obstacle Dodge",
            category=TaskCategory.LOCOMOTION,
            difficulty=TaskDifficulty.LEVEL_9,
            description=(
                "움직이는 장애물 회피 보행. 예측 불가능한 방향으로 이동하는 장애물들을 "
                "실시간으로 감지하고 회피하며 목적지까지 이동. "
                "/ Walk while dodging moving obstacles. Detect and avoid obstacles "
                "moving in unpredictable directions in real-time."
            ),
            required_primitive_skills=[
                "precise_foot_placement", "rapid_direction_change",
                "perceive_motion", "predict_trajectory",
            ],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 200.0,
                "stability_score": 0.7,
                "collision_count": 0.0,
            },
            safety_constraints={
                "max_force_N": 400.0,
                "max_tilt_deg": 25.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["moving_obstacles"],
            typical_duration_s=25.0,
            prerequisite_task_ids=["narrow_beam_walk"],
            energy_estimate_j=700.0,
        )

        # ─── TERRAIN_NAVIGATION (6 tasks) 지형 탐색 ──────────────────────────

        tasks["carpet_navigate"] = PhysicalTask(
            task_id="carpet_navigate",
            name="Carpet Surface Navigate",
            category=TaskCategory.TERRAIN_NAVIGATION,
            difficulty=TaskDifficulty.LEVEL_1,
            description=(
                "카펫 표면 위 이동. 부드러운 표면에서의 마찰 특성을 학습. "
                "바닥에 발이 묻히지 않도록 적응. "
                "/ Navigate on carpet surface. Learn friction characteristics "
                "of soft surfaces. Avoid feet sinking into the pile."
            ),
            required_primitive_skills=["walk_forward", "sense_surface"],
            success_criteria={
                "completion_time_s": 20.0,
                "position_error_mm": 100.0,
                "stability_score": 0.6,
            },
            safety_constraints={
                "max_force_N": 200.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 10.0,
            },
            terrain_requirements="flat",
            object_requirements=["carpet"],
            typical_duration_s=15.0,
            prerequisite_task_ids=[],
            energy_estimate_j=80.0,
        )

        tasks["gravel_walk"] = PhysicalTask(
            task_id="gravel_walk",
            name="Gravel Surface Walk",
            category=TaskCategory.TERRAIN_NAVIGATION,
            difficulty=TaskDifficulty.LEVEL_3,
            description=(
                "자갈 표면 보행. 불안정한 작은 돌들 위에서 균형 유지. "
                "각 발걸음마다 지면이 미세하게 움직임. "
                "/ Walk on gravel surface. Maintain balance on unstable small stones. "
                "The ground shifts microscopically with each step."
            ),
            required_primitive_skills=["walk_forward", "sense_surface", "adapt_foot_placement"],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 200.0,
                "stability_score": 0.55,
                "slip_count": 3.0,
            },
            safety_constraints={
                "max_force_N": 300.0,
                "max_tilt_deg": 25.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="rough",
            object_requirements=["gravel_patch"],
            typical_duration_s=25.0,
            prerequisite_task_ids=["carpet_navigate"],
            energy_estimate_j=250.0,
        )

        tasks["wet_surface_walk"] = PhysicalTask(
            task_id="wet_surface_walk",
            name="Wet Surface Walk",
            category=TaskCategory.TERRAIN_NAVIGATION,
            difficulty=TaskDifficulty.LEVEL_5,
            description=(
                "젖은 표면 보행. 마찰 계수가 크게 감소한 상태에서 미끄러지지 않고 이동. "
                "보폭을 줄이고 발바닥 접지력을 높여야 함. "
                "/ Walk on wet surface. Navigate with greatly reduced friction coefficient. "
                "Must shorten stride and maximize sole grip."
            ),
            required_primitive_skills=["walk_forward", "sense_surface", "control_grip_force"],
            success_criteria={
                "completion_time_s": 40.0,
                "position_error_mm": 150.0,
                "stability_score": 0.6,
                "slip_count": 2.0,
            },
            safety_constraints={
                "max_force_N": 250.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["wet_surface"],
            typical_duration_s=35.0,
            prerequisite_task_ids=["gravel_walk"],
            energy_estimate_j=300.0,
        )

        tasks["stairs_up_down"] = PhysicalTask(
            task_id="stairs_up_down",
            name="Stairs Up and Down",
            category=TaskCategory.TERRAIN_NAVIGATION,
            difficulty=TaskDifficulty.LEVEL_6,
            description=(
                "계단 올라가기 및 내려가기. 내려갈 때는 중력을 제어하며 한 계단씩 "
                "안전하게 하강. 올라갈 때보다 더 높은 균형 제어 필요. "
                "/ Ascend and descend stairs. Descending requires gravity control — "
                "step down safely one stair at a time. Higher balance control than ascending."
            ),
            required_primitive_skills=[
                "lift_foot_high", "stabilize_single_leg", "control_descent",
            ],
            success_criteria={
                "completion_time_s": 50.0,
                "position_error_mm": 50.0,
                "stability_score": 0.7,
                "foot_placement_error_mm": 15.0,
            },
            safety_constraints={
                "max_force_N": 400.0,
                "max_tilt_deg": 25.0,
                "min_clearance_mm": 3.0,
            },
            terrain_requirements="stairs",
            object_requirements=["staircase_5_steps"],
            typical_duration_s=45.0,
            prerequisite_task_ids=["wet_surface_walk"],
            energy_estimate_j=600.0,
        )

        tasks["steep_hill_35deg"] = PhysicalTask(
            task_id="steep_hill_35deg",
            name="Steep Hill 35° Navigate",
            category=TaskCategory.TERRAIN_NAVIGATION,
            difficulty=TaskDifficulty.LEVEL_8,
            description=(
                "35도 가파른 언덕 탐색. 올라가고 내려오는 전체 경로. 미끄러짐 위험이 "
                "높고 체력 소모가 큼. 하강 시 특히 주의 필요. "
                "/ Navigate a steep 35-degree hill. Full ascent and descent. "
                "High slip risk and significant energy expenditure. Caution on descent."
            ),
            required_primitive_skills=[
                "lean_forward", "adapt_foot_placement", "control_descent",
                "sense_surface", "adjust_com_height",
            ],
            success_criteria={
                "completion_time_s": 90.0,
                "position_error_mm": 500.0,
                "stability_score": 0.6,
                "slip_count": 3.0,
            },
            safety_constraints={
                "max_force_N": 600.0,
                "max_tilt_deg": 40.0,
                "min_clearance_mm": 3.0,
            },
            terrain_requirements="slope",
            object_requirements=[],
            typical_duration_s=80.0,
            prerequisite_task_ids=["stairs_up_down", "slope_ascend_30deg"],
            energy_estimate_j=1200.0,
        )

        tasks["rubble_field_navigate"] = PhysicalTask(
            task_id="rubble_field_navigate",
            name="Rubble Field Navigate",
            category=TaskCategory.TERRAIN_NAVIGATION,
            difficulty=TaskDifficulty.LEVEL_10,
            description=(
                "잔해 더미 탐색. 재난 현장과 같은 불규칙 잔해 속에서 안전 경로를 "
                "찾아 이동. 불안정한 잔해가 무너질 수 있어 극도의 주의 필요. "
                "/ Navigate through rubble field. Find safe path through irregular debris "
                "like a disaster site. Unstable rubble may collapse — extreme caution required."
            ),
            required_primitive_skills=[
                "adapt_foot_placement", "perceive_surface_angle", "predict_trajectory",
                "rapid_direction_change", "stabilize_single_leg", "adjust_com_height",
            ],
            success_criteria={
                "completion_time_s": 120.0,
                "position_error_mm": 800.0,
                "stability_score": 0.55,
                "collapse_count": 1.0,
            },
            safety_constraints={
                "max_force_N": 800.0,
                "max_tilt_deg": 35.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="uneven",
            object_requirements=["rubble_pile"],
            typical_duration_s=100.0,
            prerequisite_task_ids=["steep_hill_35deg", "uneven_rocks_traverse"],
            energy_estimate_j=2000.0,
        )

        # ─── LIFTING (6 tasks) 들어올리기 ────────────────────────────────────

        tasks["lift_100g_object"] = PhysicalTask(
            task_id="lift_100g_object",
            name="Lift 100g Object",
            category=TaskCategory.LIFTING,
            difficulty=TaskDifficulty.LEVEL_1,
            description=(
                "100g 물체 들어올리기. 기본적인 집기와 들어올리기 동작. "
                "너무 가벼워서 힘 조절이 오히려 어려울 수 있음. "
                "/ Lift a 100-gram object. Basic grasping and lifting. "
                "Being so light, force control can actually be tricky."
            ),
            required_primitive_skills=["open_gripper", "close_gripper", "lift_arm"],
            success_criteria={
                "completion_time_s": 10.0,
                "position_error_mm": 20.0,
                "force_overshoot_N": 2.0,
                "stability_score": 0.7,
            },
            safety_constraints={
                "max_force_N": 20.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["100g_cube"],
            typical_duration_s=8.0,
            prerequisite_task_ids=[],
            energy_estimate_j=30.0,
        )

        tasks["lift_1kg_box"] = PhysicalTask(
            task_id="lift_1kg_box",
            name="Lift 1kg Box",
            category=TaskCategory.LIFTING,
            difficulty=TaskDifficulty.LEVEL_3,
            description=(
                "1kg 상자 들어올리기. 적당한 무게로 그립력과 팔 힘의 조율이 필요. "
                "상자가 미끄러지지 않도록 적절한 파지력 유지. "
                "/ Lift a 1kg box. Requires coordination of grip force and arm strength. "
                "Maintain adequate grip to prevent the box from slipping."
            ),
            required_primitive_skills=["open_gripper", "close_gripper", "lift_arm", "control_grip_force"],
            success_criteria={
                "completion_time_s": 12.0,
                "position_error_mm": 30.0,
                "force_overshoot_N": 3.0,
                "stability_score": 0.65,
            },
            safety_constraints={
                "max_force_N": 50.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["1kg_box"],
            typical_duration_s=10.0,
            prerequisite_task_ids=["lift_100g_object"],
            energy_estimate_j=80.0,
        )

        tasks["lift_2kg_box_shelf"] = PhysicalTask(
            task_id="lift_2kg_box_shelf",
            name="Lift 2kg Box from Shelf",
            category=TaskCategory.LIFTING,
            difficulty=TaskDifficulty.LEVEL_5,
            description=(
                "선반에서 2kg 상자 들어올리기. 높이 위치한 물체에 접근하고, 무거운 "
                "물체를 안전하게 꺼내야 함. 자세 불안정 가능. "
                "/ Lift a 2kg box from a shelf. Reach for a high object and safely "
                "remove a heavy item. Postural instability risk."
            ),
            required_primitive_skills=[
                "close_gripper", "lift_arm", "control_grip_force",
                "reach_overhead", "stabilize_core",
            ],
            success_criteria={
                "completion_time_s": 20.0,
                "position_error_mm": 50.0,
                "force_overshoot_N": 5.0,
                "stability_score": 0.6,
            },
            safety_constraints={
                "max_force_N": 100.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["2kg_box", "shelf_1m_high"],
            typical_duration_s=15.0,
            prerequisite_task_ids=["lift_1kg_box"],
            energy_estimate_j=200.0,
        )

        tasks["lift_irregular_shape"] = PhysicalTask(
            task_id="lift_irregular_shape",
            name="Lift Irregular Shape",
            category=TaskCategory.LIFTING,
            difficulty=TaskDifficulty.LEVEL_7,
            description=(
                "불규칙 형태 물체 들어올리기. 무게 중심이 편향되어 있어 파지점을 "
                "지능적으로 선택해야 함. 물체가 회전하거나 미끄러질 수 있음. "
                "/ Lift an irregularly shaped object. Center of gravity is offset — "
                "must intelligently select grasp points. Object may rotate or slip."
            ),
            required_primitive_skills=[
                "close_gripper", "control_grip_force", "perceive_com",
                "adapt_grasp", "stabilize_core",
            ],
            success_criteria={
                "completion_time_s": 20.0,
                "position_error_mm": 40.0,
                "force_overshoot_N": 4.0,
                "stability_score": 0.6,
            },
            safety_constraints={
                "max_force_N": 80.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 3.0,
            },
            terrain_requirements="flat",
            object_requirements=["irregular_object_1kg"],
            typical_duration_s=18.0,
            prerequisite_task_ids=["lift_2kg_box_shelf"],
            energy_estimate_j=150.0,
        )

        tasks["lift_fragile_egg"] = PhysicalTask(
            task_id="lift_fragile_egg",
            name="Lift Fragile Egg",
            category=TaskCategory.LIFTING,
            difficulty=TaskDifficulty.LEVEL_8,
            description=(
                "깨지기 쉬운 계란 들어올리기. 최소한의 힘으로 파지하고 들어올리기. "
                "너무 세면 깨지고, 너무 약하면 떨어뜨림. 힘 제어의 극한. "
                "/ Lift a fragile egg. Grasp and lift with minimum necessary force. "
                "Too hard → breaks. Too soft → drops. The extreme of force control."
            ),
            required_primitive_skills=[
                "close_gripper", "control_grip_force", "sense_compliance",
                "delicate_touch",
            ],
            success_criteria={
                "completion_time_s": 15.0,
                "position_error_mm": 15.0,
                "force_overshoot_N": 0.5,
                "stability_score": 0.8,
            },
            safety_constraints={
                "max_force_N": 10.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["egg"],
            typical_duration_s=12.0,
            prerequisite_task_ids=["lift_irregular_shape"],
            energy_estimate_j=50.0,
        )

        tasks["lift_and_rotate_2kg"] = PhysicalTask(
            task_id="lift_and_rotate_2kg",
            name="Lift and Rotate 2kg Object",
            category=TaskCategory.LIFTING,
            difficulty=TaskDifficulty.LEVEL_9,
            description=(
                "2kg 물체 들어올려 180도 회전. 무거운 물체를 들고 팔을 회전시키는 "
                "동안 원심력에 대항하여 안정성 유지. "
                "/ Lift a 2kg object and rotate it 180 degrees. Counter centripetal "
                "forces while rotating a heavy object. Maintain stability throughout."
            ),
            required_primitive_skills=[
                "close_gripper", "control_grip_force", "stabilize_core",
                "rotate_wrist", "compensate_centrifugal",
            ],
            success_criteria={
                "completion_time_s": 20.0,
                "position_error_mm": 30.0,
                "force_overshoot_N": 5.0,
                "stability_score": 0.7,
                "rotation_error_deg": 10.0,
            },
            safety_constraints={
                "max_force_N": 120.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["2kg_cylinder"],
            typical_duration_s=18.0,
            prerequisite_task_ids=["lift_2kg_box_shelf", "lift_irregular_shape"],
            energy_estimate_j=300.0,
        )

        # ─── CARRYING (5 tasks) 운반 ─────────────────────────────────────────

        tasks["carry_cup_1m"] = PhysicalTask(
            task_id="carry_cup_1m",
            name="Carry Cup 1m",
            category=TaskCategory.CARRYING,
            difficulty=TaskDifficulty.LEVEL_2,
            description=(
                "컵을 1미터 운반. 컵이 기울어지지 않도록 수평을 유지하며 이동. "
                "물이 찬 컵이라면 더 어려움. "
                "/ Carry a cup 1 meter. Keep it level during transport — "
                "even harder if the cup is filled with water."
            ),
            required_primitive_skills=["close_gripper", "walk_forward", "maintain_level"],
            success_criteria={
                "completion_time_s": 15.0,
                "position_error_mm": 30.0,
                "tilt_error_deg": 10.0,
                "stability_score": 0.65,
            },
            safety_constraints={
                "max_force_N": 30.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["cup"],
            typical_duration_s=12.0,
            prerequisite_task_ids=["lift_100g_object"],
            energy_estimate_j=80.0,
        )

        tasks["carry_1kg_tray"] = PhysicalTask(
            task_id="carry_1kg_tray",
            name="Carry 1kg Tray",
            category=TaskCategory.CARRYING,
            difficulty=TaskDifficulty.LEVEL_4,
            description=(
                "1kg 트레이 운반. 트레이 위의 물체가 떨어지지 않도록 수평 유지. "
                "보행 시 발생하는 진동을 흡수해야 함. "
                "/ Carry a 1kg tray. Keep it level so objects don't fall off. "
                "Must absorb vibrations generated during walking."
            ),
            required_primitive_skills=["close_gripper", "walk_forward", "maintain_level", "dampen_vibration"],
            success_criteria={
                "completion_time_s": 25.0,
                "position_error_mm": 50.0,
                "tilt_error_deg": 8.0,
                "stability_score": 0.65,
            },
            safety_constraints={
                "max_force_N": 60.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["1kg_tray"],
            typical_duration_s=20.0,
            prerequisite_task_ids=["carry_cup_1m", "lift_1kg_box"],
            energy_estimate_j=180.0,
        )

        tasks["carry_fragile_3m"] = PhysicalTask(
            task_id="carry_fragile_3m",
            name="Carry Fragile Object 3m",
            category=TaskCategory.CARRYING,
            difficulty=TaskDifficulty.LEVEL_7,
            description=(
                "깨지기 쉬운 물체를 3미터 운반. 충격을 최소화하고 수평을 완벽히 유지. "
                "조금만 흔들려도 파손 위험. "
                "/ Carry a fragile object 3 meters. Minimize shock and maintain "
                "perfect level. Even slight vibration risks breakage."
            ),
            required_primitive_skills=[
                "control_grip_force", "walk_forward", "maintain_level",
                "dampen_vibration", "delicate_touch",
            ],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 20.0,
                "tilt_error_deg": 5.0,
                "force_overshoot_N": 1.0,
                "stability_score": 0.75,
            },
            safety_constraints={
                "max_force_N": 15.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["fragile_vase"],
            typical_duration_s=28.0,
            prerequisite_task_ids=["carry_1kg_tray", "lift_fragile_egg"],
            energy_estimate_j=150.0,
        )

        tasks["carry_while_walking_rough"] = PhysicalTask(
            task_id="carry_while_walking_rough",
            name="Carry While Walking Rough Terrain",
            category=TaskCategory.CARRYING,
            difficulty=TaskDifficulty.LEVEL_8,
            description=(
                "거친 지형에서 물체 운반. 자세 불안정과 진동이 극대화되는 상황에서 "
                "물체를 안전하게 파지하고 운반. 이중 과제 수행. "
                "/ Carry an object while walking on rough terrain. Postural instability "
                "and vibrations are maximized. A dual-task challenge."
            ),
            required_primitive_skills=[
                "control_grip_force", "adapt_foot_placement", "maintain_level",
                "dampen_vibration", "stabilize_core",
            ],
            success_criteria={
                "completion_time_s": 45.0,
                "position_error_mm": 100.0,
                "tilt_error_deg": 10.0,
                "stability_score": 0.6,
            },
            safety_constraints={
                "max_force_N": 80.0,
                "max_tilt_deg": 25.0,
                "min_clearance_mm": 3.0,
            },
            terrain_requirements="rough",
            object_requirements=["1kg_box"],
            typical_duration_s=40.0,
            prerequisite_task_ids=["carry_fragile_3m", "rough_terrain_walk_3m"],
            energy_estimate_j=500.0,
        )

        tasks["carry_and_place_precisely"] = PhysicalTask(
            task_id="carry_and_place_precisely",
            name="Carry and Place Precisely",
            category=TaskCategory.CARRYING,
            difficulty=TaskDifficulty.LEVEL_9,
            description=(
                "물체 운반 후 정밀 배치. 운반 후 물체를 목표 위치에 mm 단위 정밀도로 "
                "내려놓기. 운반의 피로 후 정밀 동작이 필요. "
                "/ Carry an object and place it precisely. After transport, place "
                "at target location with mm-level precision. Precision after fatigue."
            ),
            required_primitive_skills=[
                "control_grip_force", "walk_forward", "maintain_level",
                "precise_placement", "release_gently",
            ],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 5.0,
                "tilt_error_deg": 3.0,
                "stability_score": 0.8,
                "placement_error_mm": 3.0,
            },
            safety_constraints={
                "max_force_N": 50.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="flat",
            object_requirements=["1kg_box", "target_marker"],
            typical_duration_s=25.0,
            prerequisite_task_ids=["carry_while_walking_rough"],
            energy_estimate_j=350.0,
        )

        # ─── PRECISE_MANIPULATION (6 tasks) 정밀 조작 ────────────────────────

        tasks["place_block_on_block"] = PhysicalTask(
            task_id="place_block_on_block",
            name="Place Block on Block",
            category=TaskCategory.PRECISE_MANIPULATION,
            difficulty=TaskDifficulty.LEVEL_3,
            description=(
                "블록 위에 블록 올려놓기. 첫 번째 블록 위에 두 번째 블록을 "
                "안정적으로 적층. 정렬과 안정성이 핵심. "
                "/ Place a block on top of another block. Stack the second block "
                "stably on the first. Alignment and stability are key."
            ),
            required_primitive_skills=["close_gripper", "precise_placement", "release_gently"],
            success_criteria={
                "completion_time_s": 15.0,
                "position_error_mm": 10.0,
                "stability_score": 0.7,
                "alignment_error_mm": 8.0,
            },
            safety_constraints={
                "max_force_N": 30.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 3.0,
            },
            terrain_requirements="flat",
            object_requirements=["2x_cube_block"],
            typical_duration_s=12.0,
            prerequisite_task_ids=["lift_100g_object"],
            energy_estimate_j=60.0,
        )

        tasks["insert_peg_in_hole"] = PhysicalTask(
            task_id="insert_peg_in_hole",
            name="Insert Peg in Hole",
            category=TaskCategory.PRECISE_MANIPULATION,
            difficulty=TaskDifficulty.LEVEL_5,
            description=(
                "구멍에 핀 삽입. 핀과 구멍의 간섭을 피하면서 정확한 각도와 위치로 "
                "삽입. 힘 피드백을 통한 조정이 필요. "
                "/ Insert a peg into a hole. Avoid interference between peg and hole "
                "while inserting at the correct angle and position. Force-feedback adjustment."
            ),
            required_primitive_skills=[
                "precise_placement", "control_grip_force", "sense_compliance",
                "align_axis",
            ],
            success_criteria={
                "completion_time_s": 20.0,
                "position_error_mm": 5.0,
                "force_overshoot_N": 2.0,
                "alignment_error_deg": 5.0,
            },
            safety_constraints={
                "max_force_N": 30.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 1.0,
            },
            terrain_requirements="flat",
            object_requirements=["peg_5mm", "hole_board"],
            typical_duration_s=18.0,
            prerequisite_task_ids=["place_block_on_block"],
            energy_estimate_j=80.0,
        )

        tasks["thread_needle"] = PhysicalTask(
            task_id="thread_needle",
            name="Thread Needle",
            category=TaskCategory.PRECISE_MANIPULATION,
            difficulty=TaskDifficulty.LEVEL_7,
            description=(
                "바늘귀에 실 꿰기. 극도의 정밀도와 미세 힘 제어가 필요. "
                "실이 유연하여 예측 불가능한 움직임을 보임. "
                "/ Thread a needle. Requires extreme precision and micro force control. "
                "The thread is flexible and moves unpredictably."
            ),
            required_primitive_skills=[
                "precise_placement", "control_grip_force", "align_axis",
                "delicate_touch", "stabilize_tremor",
            ],
            success_criteria={
                "completion_time_s": 60.0,
                "position_error_mm": 1.0,
                "force_overshoot_N": 0.3,
                "alignment_error_deg": 2.0,
            },
            safety_constraints={
                "max_force_N": 5.0,
                "max_tilt_deg": 5.0,
                "min_clearance_mm": 0.5,
            },
            terrain_requirements="flat",
            object_requirements=["needle", "thread"],
            typical_duration_s=50.0,
            prerequisite_task_ids=["insert_peg_in_hole"],
            energy_estimate_j=100.0,
        )

        tasks["screw_in_screw"] = PhysicalTask(
            task_id="screw_in_screw",
            name="Screw In Screw",
            category=TaskCategory.PRECISE_MANIPULATION,
            difficulty=TaskDifficulty.LEVEL_8,
            description=(
                "나사 돌려 넣기. 회전과 압력을 동시에 가해야 함. 나사산의 피치에 "
                "맞는 정밀한 회전-병진 조화가 필요. "
                "/ Screw in a screw. Must apply rotation and pressure simultaneously. "
                "Requires precise rotation-translation coordination matching thread pitch."
            ),
            required_primitive_skills=[
                "rotate_wrist", "control_grip_force", "align_axis",
                "sense_compliance", "precise_placement",
            ],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 2.0,
                "force_overshoot_N": 3.0,
                "alignment_error_deg": 3.0,
                "rotation_accuracy_deg": 5.0,
            },
            safety_constraints={
                "max_force_N": 20.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 1.0,
            },
            terrain_requirements="flat",
            object_requirements=["screw_m4", "screw_board"],
            typical_duration_s=25.0,
            prerequisite_task_ids=["thread_needle"],
            energy_estimate_j=120.0,
        )

        tasks["assemble_3_pieces"] = PhysicalTask(
            task_id="assemble_3_pieces",
            name="Assemble 3 Pieces",
            category=TaskCategory.PRECISE_MANIPULATION,
            difficulty=TaskDifficulty.LEVEL_9,
            description=(
                "3개 부품 조립. 각 부품을 순서대로 정확히 맞춰 조립. "
                "부품 간 결합을 위한 정밀한 위치 및 힘 제어. "
                "/ Assemble 3 pieces. Fit each part in sequence precisely. "
                "Precise position and force control for inter-part connections."
            ),
            required_primitive_skills=[
                "precise_placement", "control_grip_force", "align_axis",
                "sense_compliance", "rotate_wrist", "sequence_actions",
            ],
            success_criteria={
                "completion_time_s": 60.0,
                "position_error_mm": 3.0,
                "force_overshoot_N": 3.0,
                "alignment_error_deg": 3.0,
                "assembly_completeness": 1.0,
            },
            safety_constraints={
                "max_force_N": 30.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 1.0,
            },
            terrain_requirements="flat",
            object_requirements=["3_piece_assembly_kit"],
            typical_duration_s=55.0,
            prerequisite_task_ids=["screw_in_screw"],
            energy_estimate_j=200.0,
        )

        tasks["micro_adjust_1mm"] = PhysicalTask(
            task_id="micro_adjust_1mm",
            name="Micro Adjust 1mm Precision",
            category=TaskCategory.PRECISE_MANIPULATION,
            difficulty=TaskDifficulty.LEVEL_10,
            description=(
                "1mm 정밀도 미세 조정. 물체를 목표 위치에 1mm 이내 오차로 배치. "
                "진동, 온도, 유격 등 모든 오차 요인을 보정해야 하는 극한 정밀도. "
                "/ 1mm precision micro-adjustment. Place an object within 1mm of target. "
                "Must compensate for vibration, temperature, backlash — extreme precision."
            ),
            required_primitive_skills=[
                "precise_placement", "control_grip_force", "stabilize_tremor",
                "delicate_touch", "sense_compliance", "compensate_backlash",
            ],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 1.0,
                "force_overshoot_N": 0.5,
                "alignment_error_deg": 1.0,
            },
            safety_constraints={
                "max_force_N": 10.0,
                "max_tilt_deg": 5.0,
                "min_clearance_mm": 0.5,
            },
            terrain_requirements="flat",
            object_requirements=["micro_adjust_target", "precision_object"],
            typical_duration_s=25.0,
            prerequisite_task_ids=["assemble_3_pieces"],
            energy_estimate_j=80.0,
        )

        # ─── CRAFTWORK (5 tasks) 공예 ────────────────────────────────────────

        tasks["shape_clay_ball"] = PhysicalTask(
            task_id="shape_clay_ball",
            name="Shape Clay Ball",
            category=TaskCategory.CRAFTWORK,
            difficulty=TaskDifficulty.LEVEL_4,
            description=(
                "점토로 공 만들기. 양손으로 점토를 둥글게 성형. 균일한 압력 분배와 "
                "지속적인 형태 피드백이 필요. "
                "/ Shape a ball from clay. Use both hands to round the clay. "
                "Requires uniform pressure distribution and continuous shape feedback."
            ),
            required_primitive_skills=[
                "close_gripper", "control_grip_force", "sense_compliance",
                "bilateral_coordination",
            ],
            success_criteria={
                "completion_time_s": 45.0,
                "position_error_mm": 10.0,
                "sphericity_score": 0.7,
                "force_overshoot_N": 3.0,
            },
            safety_constraints={
                "max_force_N": 30.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["clay_200g"],
            typical_duration_s=40.0,
            prerequisite_task_ids=["lift_100g_object"],
            energy_estimate_j=150.0,
        )

        tasks["fold_paper_precisely"] = PhysicalTask(
            task_id="fold_paper_precisely",
            name="Fold Paper Precisely",
            category=TaskCategory.CRAFTWORK,
            difficulty=TaskDifficulty.LEVEL_6,
            description=(
                "종이 정밀 접기. 종이를 지정된 선에 맞춰 정확히 접기. "
                "얇고 유연한 재질의 정밀 조작이 필요. "
                "/ Fold paper precisely. Fold along a designated line with accuracy. "
                "Requires precise manipulation of thin, flexible material."
            ),
            required_primitive_skills=[
                "control_grip_force", "precise_placement", "delicate_touch",
                "bilateral_coordination",
            ],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 3.0,
                "alignment_error_deg": 5.0,
                "crease_quality": 0.7,
            },
            safety_constraints={
                "max_force_N": 10.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="flat",
            object_requirements=["a4_paper"],
            typical_duration_s=25.0,
            prerequisite_task_ids=["shape_clay_ball"],
            energy_estimate_j=60.0,
        )

        tasks["carve_soft_material"] = PhysicalTask(
            task_id="carve_soft_material",
            name="Carve Soft Material",
            category=TaskCategory.CRAFTWORK,
            difficulty=TaskDifficulty.LEVEL_7,
            description=(
                "부드러운 재료 조각. 지정된 패턴에 따라 비누나 점토에 조각. "
                "깎아내는 과정에서 힘 방향과 깊이를 정밀 제어. "
                "/ Carve soft material. Carve a pattern into soap or clay. "
                "Precise control of force direction and depth during material removal."
            ),
            required_primitive_skills=[
                "control_grip_force", "precise_placement", "delicate_touch",
                "apply_directed_force",
            ],
            success_criteria={
                "completion_time_s": 60.0,
                "position_error_mm": 3.0,
                "depth_error_mm": 2.0,
                "pattern_accuracy": 0.7,
            },
            safety_constraints={
                "max_force_N": 20.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="flat",
            object_requirements=["soap_bar", "carving_tool"],
            typical_duration_s=55.0,
            prerequisite_task_ids=["fold_paper_precisely"],
            energy_estimate_j=200.0,
        )

        tasks["weave_two_strips"] = PhysicalTask(
            task_id="weave_two_strips",
            name="Weave Two Strips",
            category=TaskCategory.CRAFTWORK,
            difficulty=TaskDifficulty.LEVEL_8,
            description=(
                "두 줄 교직. 종이나 천 스트립을 번갈아 엮어 직조 패턴 생성. "
                "교차점마다 정밀한 위치 제어와 유연체 조작이 필요. "
                "/ Weave two strips. Interlace paper or fabric strips alternately. "
                "Precise position control and flexible object manipulation at each crossover."
            ),
            required_primitive_skills=[
                "precise_placement", "control_grip_force", "delicate_touch",
                "bilateral_coordination", "sequence_actions",
            ],
            success_criteria={
                "completion_time_s": 90.0,
                "position_error_mm": 5.0,
                "pattern_accuracy": 0.8,
                "weave_tightness": 0.7,
            },
            safety_constraints={
                "max_force_N": 10.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="flat",
            object_requirements=["2x_fabric_strip"],
            typical_duration_s=80.0,
            prerequisite_task_ids=["carve_soft_material"],
            energy_estimate_j=300.0,
        )

        tasks["miniature_assembly"] = PhysicalTask(
            task_id="miniature_assembly",
            name="Miniature Assembly",
            category=TaskCategory.CRAFTWORK,
            difficulty=TaskDifficulty.LEVEL_10,
            description=(
                "미니어처 조립. 소형 부품들을 정밀하게 결합하여 완성품 조립. "
                "모든 공예 기술의 총체적 적용. 극한 정밀도와 인내. "
                "/ Miniature assembly. Precisely join small parts into a finished product. "
                "Comprehensive application of all craft skills. Extreme precision and patience."
            ),
            required_primitive_skills=[
                "precise_placement", "control_grip_force", "delicate_touch",
                "bilateral_coordination", "sequence_actions", "stabilize_tremor",
                "align_axis",
            ],
            success_criteria={
                "completion_time_s": 180.0,
                "position_error_mm": 1.0,
                "pattern_accuracy": 0.9,
                "assembly_completeness": 1.0,
            },
            safety_constraints={
                "max_force_N": 8.0,
                "max_tilt_deg": 5.0,
                "min_clearance_mm": 0.5,
            },
            terrain_requirements="flat",
            object_requirements=["miniature_kit", "tweezers", "glue"],
            typical_duration_s=150.0,
            prerequisite_task_ids=["weave_two_strips", "assemble_3_pieces"],
            energy_estimate_j=500.0,
        )

        # ─── TOOL_USE (4 tasks) 도구 사용 ────────────────────────────────────

        tasks["use_screwdriver"] = PhysicalTask(
            task_id="use_screwdriver",
            name="Use Screwdriver",
            category=TaskCategory.TOOL_USE,
            difficulty=TaskDifficulty.LEVEL_5,
            description=(
                "드라이버 사용하기. 드라이버를 잡고 나사에 정렬하여 회전시키기. "
                "도구의 물리적 특성(길이, 무게, 회전축)을 이해해야 함. "
                "/ Use a screwdriver. Grip, align to screw, and rotate. "
                "Must understand the tool's physical properties (length, weight, rotation axis)."
            ),
            required_primitive_skills=[
                "close_gripper", "rotate_wrist", "align_axis",
                "control_grip_force",
            ],
            success_criteria={
                "completion_time_s": 25.0,
                "position_error_mm": 5.0,
                "alignment_error_deg": 5.0,
                "torque_efficiency": 0.6,
            },
            safety_constraints={
                "max_force_N": 30.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="flat",
            object_requirements=["screwdriver", "screw_m4", "screw_board"],
            typical_duration_s=20.0,
            prerequisite_task_ids=["lift_1kg_box"],
            energy_estimate_j=120.0,
        )

        tasks["use_hammer_nail"] = PhysicalTask(
            task_id="use_hammer_nail",
            name="Use Hammer to Drive Nail",
            category=TaskCategory.TOOL_USE,
            difficulty=TaskDifficulty.LEVEL_6,
            description=(
                "망치로 못 박기. 망치를 휘둘러 못에 충격을 가함. 충격력의 방향과 "
                "크기를 제어. 빗나가면 위험. "
                "/ Use a hammer to drive a nail. Swing the hammer to deliver impact. "
                "Control impact force direction and magnitude. Missing is dangerous."
            ),
            required_primitive_skills=[
                "close_gripper", "apply_directed_force", "aim_precisely",
                "control_impact_force",
            ],
            success_criteria={
                "completion_time_s": 20.0,
                "position_error_mm": 5.0,
                "alignment_error_deg": 10.0,
                "nail_depth_accuracy": 0.6,
            },
            safety_constraints={
                "max_force_N": 150.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["hammer", "nail", "wood_board"],
            typical_duration_s=18.0,
            prerequisite_task_ids=["use_screwdriver"],
            energy_estimate_j=200.0,
        )

        tasks["use_brush_paint"] = PhysicalTask(
            task_id="use_brush_paint",
            name="Use Brush to Paint",
            category=TaskCategory.TOOL_USE,
            difficulty=TaskDifficulty.LEVEL_7,
            description=(
                "붓으로 칠하기. 붓에 페인트를 묻혀 지정된 영역에 균일하게 칠함. "
                "압력에 따른 붓터치 변화를 제어. "
                "/ Use a brush to paint. Load paint and apply evenly to a target area. "
                "Control brush stroke variation with applied pressure."
            ),
            required_primitive_skills=[
                "control_grip_force", "precise_placement", "delicate_touch",
                "smooth_motion",
            ],
            success_criteria={
                "completion_time_s": 60.0,
                "position_error_mm": 5.0,
                "coverage_uniformity": 0.7,
                "overflow_count": 2.0,
            },
            safety_constraints={
                "max_force_N": 15.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="flat",
            object_requirements=["paint_brush", "paint", "canvas"],
            typical_duration_s=55.0,
            prerequisite_task_ids=["use_hammer_nail"],
            energy_estimate_j=150.0,
        )

        tasks["use_scissors_cut"] = PhysicalTask(
            task_id="use_scissors_cut",
            name="Use Scissors to Cut",
            category=TaskCategory.TOOL_USE,
            difficulty=TaskDifficulty.LEVEL_8,
            description=(
                "가위로 자르기. 종이나 천을 지정된 선을 따라 가위로 자르기. "
                "두 날의 벌림-닫기 동작과 이동의 협응이 필요. "
                "/ Use scissors to cut. Cut paper or fabric along a line. "
                "Coordination of open-close scissor action with linear movement."
            ),
            required_primitive_skills=[
                "control_grip_force", "precise_placement", "bilateral_coordination",
                "sequence_actions",
            ],
            success_criteria={
                "completion_time_s": 30.0,
                "position_error_mm": 3.0,
                "cut_accuracy": 0.7,
                "smoothness_score": 0.6,
            },
            safety_constraints={
                "max_force_N": 25.0,
                "max_tilt_deg": 10.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="flat",
            object_requirements=["scissors", "paper_strip"],
            typical_duration_s=25.0,
            prerequisite_task_ids=["use_brush_paint"],
            energy_estimate_j=100.0,
        )

        # ─── MULTI_STEP (5 tasks) 다단계 과제 ───────────────────────────────

        tasks["fetch_and_deliver"] = PhysicalTask(
            task_id="fetch_and_deliver",
            name="Fetch and Deliver",
            category=TaskCategory.MULTI_STEP,
            difficulty=TaskDifficulty.LEVEL_4,
            description=(
                "물건 가져다주기. 지시된 위치에서 물체를 집어 목적지까지 운반. "
                "이동 → 파지 → 운반 → 배치의 순차적 수행. "
                "/ Fetch and deliver an item. Pick up object at indicated location, "
                "carry to destination. Sequential: navigate → grasp → carry → place."
            ),
            required_primitive_skills=[
                "walk_forward", "close_gripper", "maintain_level",
                "precise_placement", "sequence_actions",
            ],
            success_criteria={
                "completion_time_s": 45.0,
                "position_error_mm": 50.0,
                "stability_score": 0.6,
                "sequence_completion": 1.0,
            },
            safety_constraints={
                "max_force_N": 60.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["1kg_box", "destination_marker"],
            typical_duration_s=40.0,
            prerequisite_task_ids=["flat_walk_5m", "carry_cup_1m"],
            energy_estimate_j=300.0,
        )

        tasks["sort_3_objects"] = PhysicalTask(
            task_id="sort_3_objects",
            name="Sort 3 Objects",
            category=TaskCategory.MULTI_STEP,
            difficulty=TaskDifficulty.LEVEL_5,
            description=(
                "3개 물체 분류. 서로 다른 크기/색상/무게의 물체를 지정된 위치에 "
                "분류. 인식 → 파지 → 이동 → 배치를 물체마다 반복. "
                "/ Sort 3 objects by size/color/weight. Recognize → grasp → move → place "
                "for each object. Requires perception and sequential action."
            ),
            required_primitive_skills=[
                "close_gripper", "control_grip_force", "precise_placement",
                "sequence_actions", "perceive_properties",
            ],
            success_criteria={
                "completion_time_s": 60.0,
                "position_error_mm": 30.0,
                "sort_accuracy": 0.9,
                "sequence_completion": 1.0,
            },
            safety_constraints={
                "max_force_N": 50.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["3_sorted_objects", "3_bins"],
            typical_duration_s=55.0,
            prerequisite_task_ids=["fetch_and_deliver"],
            energy_estimate_j=350.0,
        )

        tasks["prepare_workspace"] = PhysicalTask(
            task_id="prepare_workspace",
            name="Prepare Workspace",
            category=TaskCategory.MULTI_STEP,
            difficulty=TaskDifficulty.LEVEL_7,
            description=(
                "작업 공간 준비. 여러 도구와 재료를 지정된 배치로 정리. "
                "청소 → 도구 배치 → 재료 준비의 다단계 과정. "
                "/ Prepare workspace. Arrange multiple tools and materials in specified "
                "layout. Clean → place tools → ready materials. Multi-step process."
            ),
            required_primitive_skills=[
                "close_gripper", "precise_placement", "sequence_actions",
                "perceive_properties", "carry_cup_1m",
            ],
            success_criteria={
                "completion_time_s": 90.0,
                "position_error_mm": 20.0,
                "layout_accuracy": 0.8,
                "sequence_completion": 1.0,
            },
            safety_constraints={
                "max_force_N": 60.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 3.0,
            },
            terrain_requirements="flat",
            object_requirements=["tools_set", "work_mat", "material_tray"],
            typical_duration_s=80.0,
            prerequisite_task_ids=["sort_3_objects"],
            energy_estimate_j=500.0,
        )

        tasks["cook_simple_recipe"] = PhysicalTask(
            task_id="cook_simple_recipe",
            name="Cook Simple Recipe",
            category=TaskCategory.MULTI_STEP,
            difficulty=TaskDifficulty.LEVEL_9,
            description=(
                "간단한 요리. 재료 준비 → 혼합 → 가열 → 완성의 전체 과정. "
                "열, 날카로운 도구, 위생 규칙 등 다중 안전 제약. "
                "/ Cook a simple recipe. Prepare → mix → heat → serve. "
                "Multiple safety constraints: heat, sharp tools, hygiene rules."
            ),
            required_primitive_skills=[
                "control_grip_force", "precise_placement", "sequence_actions",
                "use_scissors_cut", "sense_temperature", "delicate_touch",
            ],
            success_criteria={
                "completion_time_s": 180.0,
                "position_error_mm": 20.0,
                "recipe_completion": 0.9,
                "safety_compliance": 1.0,
            },
            safety_constraints={
                "max_force_N": 50.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 5.0,
                "max_temperature_C": 60.0,
            },
            terrain_requirements="flat",
            object_requirements=["ingredients", "bowl", "spatula", "hotplate"],
            typical_duration_s=160.0,
            prerequisite_task_ids=["prepare_workspace", "use_scissors_cut"],
            energy_estimate_j=800.0,
        )

        tasks["full_craft_project"] = PhysicalTask(
            task_id="full_craft_project",
            name="Full Craft Project",
            category=TaskCategory.MULTI_STEP,
            difficulty=TaskDifficulty.LEVEL_10,
            description=(
                "완전 공예 프로젝트. 설계 → 재료 준비 → 가공 → 조립 → 마감의 "
                "전체 공정. 모든 물리 역량의 총체적 통합. "
                "/ Full craft project. Design → prepare → fabricate → assemble → finish. "
                "Comprehensive integration of all physical capabilities."
            ),
            required_primitive_skills=[
                "precise_placement", "control_grip_force", "delicate_touch",
                "bilateral_coordination", "sequence_actions", "use_scissors_cut",
                "use_screwdriver", "shape_clay_ball", "assemble_3_pieces",
            ],
            success_criteria={
                "completion_time_s": 360.0,
                "position_error_mm": 5.0,
                "project_completion": 0.9,
                "craft_quality": 0.7,
                "safety_compliance": 1.0,
            },
            safety_constraints={
                "max_force_N": 50.0,
                "max_tilt_deg": 15.0,
                "min_clearance_mm": 2.0,
            },
            terrain_requirements="flat",
            object_requirements=["craft_kit", "tools_set", "glue", "paint"],
            typical_duration_s=300.0,
            prerequisite_task_ids=["cook_simple_recipe", "miniature_assembly"],
            energy_estimate_j=1500.0,
        )

        # ─── EXPLORATION (3 tasks) 탐험 ─────────────────────────────────────

        tasks["map_unknown_room"] = PhysicalTask(
            task_id="map_unknown_room",
            name="Map Unknown Room",
            category=TaskCategory.EXPLORATION,
            difficulty=TaskDifficulty.LEVEL_3,
            description=(
                "미지의 방 지도 작성. 방 안을 탐색하면서 장애물과 공간을 인식하여 "
                "2D 지도 구축. 안전하면서도 효율적인 탐색 경로 생성. "
                "/ Map an unknown room. Explore and detect obstacles and open spaces "
                "to build a 2D map. Generate safe and efficient exploration paths."
            ),
            required_primitive_skills=["walk_forward", "sense_surface", "perceive_obstacle"],
            success_criteria={
                "completion_time_s": 120.0,
                "map_coverage_pct": 80.0,
                "position_error_mm": 100.0,
                "stability_score": 0.6,
            },
            safety_constraints={
                "max_force_N": 200.0,
                "max_tilt_deg": 20.0,
                "min_clearance_mm": 10.0,
            },
            terrain_requirements="flat",
            object_requirements=["unknown_room"],
            typical_duration_s=100.0,
            prerequisite_task_ids=["flat_walk_5m"],
            energy_estimate_j=600.0,
        )

        tasks["find_hidden_object"] = PhysicalTask(
            task_id="find_hidden_object",
            name="Find Hidden Object",
            category=TaskCategory.EXPLORATION,
            difficulty=TaskDifficulty.LEVEL_5,
            description=(
                "숨겨진 물체 찾기. 방 안의 가구 뒤나 안에 숨겨진 물체를 탐색하여 "
                "발견. 시야 제한 상황에서의 체계적 탐색 전략이 필요. "
                "/ Find a hidden object. Search behind/inside furniture to discover it. "
                "Requires systematic search strategy under limited visibility."
            ),
            required_primitive_skills=[
                "walk_forward", "perceive_obstacle", "close_gripper",
                "adapt_foot_placement", "perceive_properties",
            ],
            success_criteria={
                "completion_time_s": 90.0,
                "search_efficiency": 0.5,
                "stability_score": 0.6,
                "found": 1.0,
            },
            safety_constraints={
                "max_force_N": 100.0,
                "max_tilt_deg": 25.0,
                "min_clearance_mm": 5.0,
            },
            terrain_requirements="flat",
            object_requirements=["hidden_object", "furniture"],
            typical_duration_s=80.0,
            prerequisite_task_ids=["map_unknown_room"],
            energy_estimate_j=500.0,
        )

        tasks["adaptive_terrain_exploration"] = PhysicalTask(
            task_id="adaptive_terrain_exploration",
            name="Adaptive Terrain Exploration",
            category=TaskCategory.EXPLORATION,
            difficulty=TaskDifficulty.LEVEL_8,
            description=(
                "적응형 지형 탐험. 다양한 지형이 혼합된 환경을 자율적으로 탐색. "
                "각 지형에 맞게 보행 전략을 실시간 전환하며 지도 구축. "
                "/ Adaptive terrain exploration. Autonomously explore mixed-terrain "
                "environments. Switch walking strategies in real-time per terrain type."
            ),
            required_primitive_skills=[
                "adapt_foot_placement", "perceive_surface_angle", "sense_surface",
                "perceive_obstacle", "rapid_direction_change",
            ],
            success_criteria={
                "completion_time_s": 180.0,
                "map_coverage_pct": 70.0,
                "terrain_adaptation_score": 0.7,
                "stability_score": 0.6,
            },
            safety_constraints={
                "max_force_N": 500.0,
                "max_tilt_deg": 30.0,
                "min_clearance_mm": 3.0,
            },
            terrain_requirements="uneven",
            object_requirements=["mixed_terrain_area"],
            typical_duration_s=160.0,
            prerequisite_task_ids=["find_hidden_object", "rough_terrain_walk_3m"],
            energy_estimate_j=1500.0,
        )

        return tasks

    # ═════════════════════════════════════════════════════════════════════════
    # 공개 메서드 / Public Methods
    # ═════════════════════════════════════════════════════════════════════════

    def initialize(self) -> None:
        """
        커리큘럼 초기화 / Initialize the curriculum.

        데이터베이스 스키마를 생성하고, 모든 과제 정의를 로드하며,
        선수 과제 관계를 검증한다.

        Creates DB schema, loads all task definitions, and validates
        prerequisite chains for consistency.
        """
        logger.info("=" * 70)
        logger.info("물리 과제 커리큘럼 초기화 시작 / Physical Task Curriculum initializing...")
        logger.info("=" * 70)

        # 1. DB 초기화 / Initialize database
        self._init_db()

        # 2. 과제 정의 생성 / Generate task definitions
        all_tasks = self._define_all_tasks()
        logger.info(
            f"📋 총 {len(all_tasks)}개 물리 과제 정의 완료 / "
            f"Defined {len(all_tasks)} physical tasks"
        )

        # 3. 카테고리별 통계 / Category breakdown
        for cat in TaskCategory:
            count = sum(1 for t in all_tasks.values() if t.category == cat)
            logger.info(f"  • {cat.value}: {count}개 과제 / {count} tasks")

        # 4. DB에 과제 저장 (기존 데이터 보존) / Save tasks to DB
        existing_tasks = self._load_tasks_from_db()
        if len(existing_tasks) < len(all_tasks):
            for task in all_tasks.values():
                self._save_task_to_db(task)
            logger.info(
                f"💾 {len(all_tasks)}개 과제를 DB에 저장 / "
                f"Saved {len(all_tasks)} tasks to database"
            )
        else:
            logger.info(
                "💾 DB에 이미 모든 과제 존재, 스킵 / "
                "All tasks already in DB, skipping save"
            )

        # 5. 메모리에 로드 / Load into memory
        self._tasks = all_tasks

        # 6. 기존 결과 로드 / Load existing outcomes
        self._outcomes = self._load_outcomes_from_db()

        # 7. 숙달 과제 로드 / Load mastered tasks
        self._completed_task_ids = self._load_mastery_from_db()

        # 8. ZPD에 기존 결과 반영 / Feed existing outcomes to ZPD
        for outcome in self._outcomes:
            task = self._tasks.get(outcome.task_id)
            if task:
                self._zpd.update_outcome(outcome, task.category)

        # 9. 선수 과제 무결성 검증 / Validate prerequisite chains
        self._validate_prerequisites()

        self._initialized = True
        logger.info("-" * 70)
        logger.info(
            f"✅ 커리큘럼 초기화 완료: {len(self._tasks)}개 과제, "
            f"{len(self._outcomes)}개 기록, "
            f"{len(self._completed_task_ids)}개 숙달 / "
            f"Curriculum ready: {len(self._tasks)} tasks, "
            f"{len(self._outcomes)} records, "
            f"{len(self._completed_task_ids)} mastered"
        )
        logger.info("=" * 70)

    def _validate_prerequisites(self) -> None:
        """
        선수 과제 관계의 무결성 검증 / Validate prerequisite chain integrity.

        존재하지 않는 과제 ID 참조나 순환 의존성을 검출한다.
        """
        for task_id, task in self._tasks.items():
            for prereq_id in task.prerequisite_task_ids:
                if prereq_id not in self._tasks:
                    logger.error(
                        f"❌ 선수 과제 무결성 오류: '{task_id}'의 선수 과제 "
                        f"'{prereq_id}'가 존재하지 않음 / "
                        f"Prerequisite integrity error: '{prereq_id}' for "
                        f"'{task_id}' does not exist"
                    )

        # 순환 의존성 검사 (DFS) / Cycle detection via DFS
        visited: set = set()
        rec_stack: set = set()

        def _has_cycle(tid: str) -> bool:
            visited.add(tid)
            rec_stack.add(tid)
            task = self._tasks.get(tid)
            if task:
                for prereq in task.prerequisite_task_ids:
                    if prereq not in visited:
                        if _has_cycle(prereq):
                            return True
                    elif prereq in rec_stack:
                        logger.error(
                            f"❌ 순환 의존성 감지: {tid} ↔ {prereq} / "
                            f"Circular dependency detected: {tid} ↔ {prereq}"
                        )
                        return True
            rec_stack.discard(tid)
            return False

        for tid in self._tasks:
            if tid not in visited:
                _has_cycle(tid)

        logger.debug("선수 과제 무결성 검증 완료 / Prerequisite validation complete")

    def get_task(self, task_id: str) -> Optional[PhysicalTask]:
        """
        과제 ID로 과제 조회 / Get task by ID.

        Args:
            task_id: 과제 고유 식별자 / Unique task identifier

        Returns:
            PhysicalTask 또는 None / PhysicalTask or None if not found
        """
        task = self._tasks.get(task_id)
        if task is None:
            logger.warning(f"과제 '{task_id}'를 찾을 수 없음 / Task '{task_id}' not found")
        return task

    def get_available_tasks(self, completed_tasks: Optional[List[str]] = None) -> List[PhysicalTask]:
        """
        현재 수행 가능한 과제 목록 반환 / Get list of available tasks.

        선수 과제가 모두 완료된 과제만 반환한다.
        Only returns tasks whose prerequisites are all completed.

        Args:
            completed_tasks: 완료된 과제 ID 목록 (None이면 내부 상태 사용)
                             / List of completed task IDs (uses internal state if None)

        Returns:
            수행 가능한 과제 목록 / List of available PhysicalTask
        """
        if completed_tasks is None:
            completed_set = self._completed_task_ids
        else:
            completed_set = set(completed_tasks)

        available: List[PhysicalTask] = []
        for task_id, task in self._tasks.items():
            # 이미 숙달한 과제는 제외 / Exclude already mastered tasks
            if task_id in completed_set:
                continue
            # 모든 선수 과제가 완료되었는지 확인 / Check all prerequisites met
            if all(p in completed_set for p in task.prerequisite_task_ids):
                available.append(task)

        logger.info(
            f"수행 가능한 과제: {len(available)}개 / "
            f"Available tasks: {len(available)}"
        )
        return available

    def get_next_task(
        self,
        category: TaskCategory,
        skill_assessment: Optional[Dict[str, float]] = None,
    ) -> Optional[PhysicalTask]:
        """
        ZPD 기반 다음 과제 선택 / Select next task based on ZPD.

        주어진 카테고리에서 로봇의 현재 역량 수준(ZPD)을 기반으로
        최적의 학습 효과를 제공하는 과제를 선택한다.

        Selects the task that provides optimal learning based on the robot's
        current capability level (ZPD) in the given category.

        Args:
            category: 과제 카테고리 / Task category
            skill_assessment: 선택적 역량 평가 dict / Optional skill assessment

        Returns:
            ZPD 기반 선택된 과제 / ZPD-selected PhysicalTask, or None
        """
        if not self._initialized:
            logger.error("커리큘럼이 초기화되지 않음 / Curriculum not initialized")
            return None

        # 현재 수준 평가 / Assess current level
        current_level = self._zpd.assess_current_level(category)

        # 수행 가능한 과제 목록 / Get available tasks
        available = self.get_available_tasks()

        # ZPD 기반 선택 / ZPD-based selection
        next_task = self._zpd.select_next_task(category, current_level, available)

        if next_task:
            logger.info(
                f"🎯 다음 과제: {next_task.task_id} ({next_task.name}) "
                f"[{category.value}, 난이도 {int(next_task.difficulty)}] / "
                f"Next task: {next_task.task_id} "
                f"[{category.value}, difficulty {int(next_task.difficulty)}]"
            )
        else:
            logger.info(
                f"[{category.value}] 다음 과제 없음 (모두 숙달했거나 선수 조건 미충족) / "
                f"No next task (all mastered or prerequisites unmet)"
            )

        return next_task

    def record_outcome(self, outcome: TaskOutcome) -> None:
        """
        과제 수행 결과 기록 / Record a task attempt outcome.

        결과를 메모리, DB, ZPD에 반영한다.

        Args:
            outcome: 과제 수행 결과 / Task outcome to record
        """
        if not self._initialized:
            logger.error("커리큘럼이 초기화되지 않음 / Curriculum not initialized")
            return

        # 메모리에 저장 / Store in memory
        self._outcomes.append(outcome)

        # DB에 저장 / Persist to database
        self._save_outcome_to_db(outcome)

        # ZPD에 반영 / Update ZPD
        task = self._tasks.get(outcome.task_id)
        if task:
            self._zpd.update_outcome(outcome, task.category)

        # 숙달 상태 업데이트 / Update mastery state
        # 3회 이상 시도 중 80% 이상 성공 시 숙달 간주
        task_outcomes = [o for o in self._outcomes if o.task_id == outcome.task_id]
        if len(task_outcomes) >= 3:
            success_rate = sum(1 for o in task_outcomes if o.success) / len(task_outcomes)
            if success_rate >= 0.8:
                self._completed_task_ids.add(outcome.task_id)
                logger.info(
                    f"🏆 과제 숙달: {outcome.task_id} "
                    f"(성공률 {success_rate:.0%}, {len(task_outcomes)}회 시도) / "
                    f"Task mastered: {outcome.task_id} "
                    f"(success rate {success_rate:.0%}, {len(task_outcomes)} attempts)"
                )

        # 플래토 감지 / Detect plateau
        if task:
            category_outcomes = [
                o for o in self._outcomes
                if o.task_id in {t.task_id for t in self._tasks.values() if t.category == task.category}
            ]
            if self._zpd.detect_plateau(category_outcomes):
                # 최근 실패 모드 분석 / Analyze recent failure modes
                recent_failures = [
                    o for o in category_outcomes[-10:]
                    if not o.success and o.failure_mode
                ]
                context = (
                    recent_failures[-1].failure_mode
                    if recent_failures
                    else "general"
                )
                strategy = self._zpd.suggest_breakthrough_strategy(context)
                logger.info(f"💡 돌파 전략: {strategy}")

        logger.info(
            f"📝 결과 기록: {outcome.task_id} 시도#{outcome.attempt_number} "
            f"성공={outcome.success} / "
            f"Outcome recorded: {outcome.task_id} attempt#{outcome.attempt_number} "
            f"success={outcome.success}"
        )

    def get_progress_report(self) -> Dict[str, Any]:
        """
        진도 보고서 생성 / Generate progress report.

        카테고리별 숙달률, 전체 물리 AGI 점수, 약점 분석 등을 포함한다.

        Returns:
            진도 보고서 dict / Progress report dictionary
        """
        report: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "total_tasks": len(self._tasks),
            "total_outcomes": len(self._outcomes),
            "mastered_tasks": len(self._completed_task_ids),
            "mastery_per_category": {},
            "success_rate_per_category": {},
            "overall_agi_score": 0.0,
            "weak_areas": [],
            "category_details": {},
        }

        for cat in TaskCategory:
            cat_tasks = [t for t in self._tasks.values() if t.category == cat]
            cat_task_ids = {t.task_id for t in cat_tasks}
            mastered_in_cat = cat_task_ids & self._completed_task_ids
            mastery_rate = len(mastered_in_cat) / len(cat_tasks) if cat_tasks else 0.0

            # 카테고리별 성공률 / Category success rate
            cat_outcomes = [
                o for o in self._outcomes if o.task_id in cat_task_ids
            ]
            success_rate = (
                sum(1 for o in cat_outcomes if o.success) / len(cat_outcomes)
                if cat_outcomes
                else 0.0
            )

            # 난이도별 숙달 수 / Mastered count per difficulty level
            difficulty_breakdown: Dict[int, Dict[str, Any]] = {}
            for t in cat_tasks:
                diff_key = int(t.difficulty)
                if diff_key not in difficulty_breakdown:
                    difficulty_breakdown[diff_key] = {"total": 0, "mastered": 0}
                difficulty_breakdown[diff_key]["total"] += 1
                if t.task_id in self._completed_task_ids:
                    difficulty_breakdown[diff_key]["mastered"] += 1

            report["mastery_per_category"][cat.value] = mastery_rate
            report["success_rate_per_category"][cat.value] = success_rate
            report["category_details"][cat.value] = {
                "total_tasks": len(cat_tasks),
                "mastered_tasks": len(mastered_in_cat),
                "mastery_rate": mastery_rate,
                "success_rate": success_rate,
                "total_attempts": len(cat_outcomes),
                "difficulty_breakdown": difficulty_breakdown,
                "mastered_task_ids": sorted(mastered_in_cat),
            }

        # 전체 AGI 점수 / Overall Physical AGI score
        report["overall_agi_score"] = self.estimate_agi_level()

        # 약점 영역 / Weak areas
        report["weak_areas"] = [c.value for c in self.get_weak_areas()]

        logger.info(
            f"📊 진도 보고서 생성: 숙달 {len(self._completed_task_ids)}/{len(self._tasks)}, "
            f"AGI 점수 {report['overall_agi_score']:.2f} / "
            f"Progress report: mastered {len(self._completed_task_ids)}/{len(self._tasks)}, "
            f"AGI score {report['overall_agi_score']:.2f}"
        )

        return report

    def get_weak_areas(self) -> List[TaskCategory]:
        """
        약점 카테고리 식별 / Identify weak areas.

        성공률이 가장 낮은 카테고리들을 반환한다.
        Returns categories with the lowest success rates.

        Returns:
            약점 카테고리 목록 (성공률 오름차순) / Weak categories sorted by success rate ascending
        """
        category_scores: Dict[TaskCategory, float] = {}

        for cat in TaskCategory:
            cat_task_ids = {
                t.task_id for t in self._tasks.values() if t.category == cat
            }
            cat_outcomes = [
                o for o in self._outcomes if o.task_id in cat_task_ids
            ]

            if not cat_outcomes:
                category_scores[cat] = 0.0
            else:
                success_rate = sum(1 for o in cat_outcomes if o.success) / len(
                    cat_outcomes
                )
                category_scores[cat] = success_rate

        # 성공률 기준 오름차순 정렬 / Sort ascending by success rate
        sorted_cats = sorted(category_scores.items(), key=lambda x: x[1])

        # 50% 미만 성공률을 약점으로 간주 / Consider < 50% success rate as weak
        weak = [cat for cat, score in sorted_cats if score < 0.5]

        if not weak and sorted_cats:
            # 모든 카테고리가 50% 이상이면 가장 낮은 것 반환
            # If all >= 50%, return the lowest
            weak = [sorted_cats[0][0]]

        logger.info(
            f"약점 영역: {[c.value for c in weak]} / "
            f"Weak areas: {[c.value for c in weak]}"
        )
        return weak

    def suggest_practice(self) -> Optional[PhysicalTask]:
        """
        약점 영역 기반 연습 과제 제안 / Suggest practice task targeting weakest area.

        가장 약한 카테고리에서 ZPD 기반 과제를 선택하여 집중 연습을 유도한다.

        Returns:
            추천 연습 과제 / Recommended practice task, or None
        """
        weak_areas = self.get_weak_areas()
        if not weak_areas:
            logger.info("약점 영역 없음 — 모든 카테고리가 양호 / No weak areas — all categories healthy")
            return None

        # 가장 약한 카테고리에서 과제 선택 / Select from weakest category
        target_category = weak_areas[0]
        task = self.get_next_task(target_category)

        if task:
            logger.info(
                f"💪 연습 추천: {task.task_id} ({task.name}) "
                f"[약점 영역: {target_category.value}] / "
                f"Practice suggestion: {task.task_id} "
                f"[weak area: {target_category.value}]"
            )
        else:
            logger.info(
                f"[{target_category.value}] 추천할 연습 과제 없음 / "
                f"No practice task to suggest"
            )

        return task

    def estimate_agi_level(self) -> float:
        """
        물리 AGI 수준 추정 (0.0~1.0) / Estimate Physical AGI level.

        모든 카테고리의 숙달 과제를 종합하여 0.0(전무)~1.0(완전 숙달)의
        AGI 수준 점수를 산출한다. 카테고리 간 균형을 고려하며, 한 카테고리에
        치우친 숙달은 페널티를 받는다.

        Computes a 0.0-1.0 AGI score based on mastered tasks across all
        categories. Balance across categories is rewarded; skewed mastery
        is penalized.

        Returns:
            AGI 수준 점수 (0.0~1.0) / AGI level score (0.0-1.0)
        """
        if not self._tasks:
            return 0.0

        category_mastery: Dict[TaskCategory, float] = {}
        for cat in TaskCategory:
            cat_tasks = [t for t in self._tasks.values() if t.category == cat]
            if not cat_tasks:
                category_mastery[cat] = 0.0
                continue

            # 난이도 가중 숙달률 / Difficulty-weighted mastery rate
            total_weight = 0.0
            mastered_weight = 0.0
            for t in cat_tasks:
                weight = float(t.difficulty)  # 높은 난이도 = 높은 가중치
                total_weight += weight
                if t.task_id in self._completed_task_ids:
                    mastered_weight += weight

            category_mastery[cat] = (
                mastered_weight / total_weight if total_weight > 0 else 0.0
            )

        # 카테고리 평균 숙달률 / Average mastery across categories
        avg_mastery = np.mean(list(category_mastery.values()))

        # 균형 보너스/페널티 / Balance bonus/penalty
        # 모든 카테고리가 비슷한 수준이면 보너스, 치우치면 페널티
        mastery_values = list(category_mastery.values())
        std_mastery = np.std(mastery_values)

        # 표준편차가 낮을수록 균형적 → 보너스
        # Low standard deviation = balanced → bonus
        balance_factor = 1.0 - min(std_mastery * 2, 0.3)  # 최대 30% 페널티

        # 최소 숙달 카테고리 기반 보정 (약한 사슬의 고리)
        # Correction based on weakest category (weakest link)
        min_mastery = min(category_mastery.values())

        # 종합 AGI 점수 / Composite AGI score
        agi_score = float(
            avg_mastery * 0.5
            + balance_factor * avg_mastery * 0.3
            + min_mastery * 0.2
        )
        agi_score = float(np.clip(agi_score, 0.0, 1.0))

        logger.debug(
            f"AGI 수준 추정: {agi_score:.3f} "
            f"(평균숙달={avg_mastery:.3f}, 균형계수={balance_factor:.3f}, "
            f"최소숙달={min_mastery:.3f}) / "
            f"AGI estimate: {agi_score:.3f} "
            f"(avg_mastery={avg_mastery:.3f}, balance={balance_factor:.3f}, "
            f"min_mastery={min_mastery:.3f})"
        )

        return agi_score

    def get_curriculum_summary(self) -> str:
        """
        커리큘럼 요약 문자열 반환 / Return human-readable curriculum summary.

        Returns:
            커리큘럼 요약 / Formatted summary string
        """
        lines = [
            "=" * 70,
            "🤖 지훈 로봇 V8.5 — 물리 과제 커리큘럼 요약",
            "   Jihun Robot V8.5 — Physical Task Curriculum Summary",
            "=" * 70,
            "",
            f"총 과제 수 / Total tasks: {len(self._tasks)}",
            f"총 시도 기록 / Total outcomes: {len(self._outcomes)}",
            f"숙달 과제 / Mastered: {len(self._completed_task_ids)}",
            f"물리 AGI 수준 / Physical AGI level: {self.estimate_agi_level():.2f}",
            "",
            "카테고리별 현황 / Category Status:",
            "-" * 50,
        ]

        for cat in TaskCategory:
            cat_tasks = [t for t in self._tasks.values() if t.category == cat]
            mastered = sum(1 for t in cat_tasks if t.task_id in self._completed_task_ids)
            rate = mastered / len(cat_tasks) if cat_tasks else 0.0
            bar_len = 20
            filled = int(rate * bar_len)
            bar = "█" * filled + "░" * (bar_len - filled)
            lines.append(
                f"  {cat.value:25s} [{bar}] {mastered:2d}/{len(cat_tasks):2d} ({rate:.0%})"
            )

        # 약점 영역 / Weak areas
        weak = self.get_weak_areas()
        if weak:
            lines.append("")
            lines.append("⚠️  약점 영역 / Weak areas:")
            for w in weak:
                lines.append(f"  • {w.value}")

        # 다음 추천 / Next suggestion
        next_task = self.suggest_practice()
        if next_task:
            lines.append("")
            lines.append(
                f"💡 다음 추천 과제 / Suggested next: "
                f"{next_task.task_id} ({next_task.name}) "
                f"[난이도/difficulty {int(next_task.difficulty)}]"
            )

        lines.append("")
        lines.append("=" * 70)
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# 모듈 진입점 / Module Entry Point
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # 커리큘럼 초기화 및 요약 출력 / Initialize and print summary
    curriculum = PhysicalTaskCurriculum()
    curriculum.initialize()
    print(curriculum.get_curriculum_summary())

    # 예시: 과제 수행 시뮬레이션 / Example: simulate task outcomes
    print("\n" + "─" * 50)
    print("예시 과제 수행 시뮬레이션 / Sample task simulation")
    print("─" * 50)

    # 첫 번째 과제 시도 / Try first task
    first_task = curriculum.get_task("flat_walk_1m")
    if first_task:
        print(f"\n📋 과제: {first_task.name} — {first_task.description[:60]}...")

        # 시도 결과 기록 / Record attempt outcome
        outcome = TaskOutcome(
            task_id="flat_walk_1m",
            attempt_number=1,
            success=True,
            completion_time_s=12.0,
            precision_scores={"position_error_mm": 35.0, "path_deviation_mm": 20.0},
            stability_score=0.72,
            force_efficiency=0.65,
            learning_value=0.8,
            failure_mode=None,
        )
        curriculum.record_outcome(outcome)
        print(f"  ✅ 성공! 안정성={outcome.stability_score:.2f}")

        # 다음 과제 추천 / Get next task recommendation
        next_task = curriculum.get_next_task(TaskCategory.LOCOMOTION)
        if next_task:
            print(f"\n🎯 다음 과제: {next_task.name} (난이도 {int(next_task.difficulty)})")

    # 진도 보고서 / Progress report
    report = curriculum.get_progress_report()
    print(f"\n📊 AGI 수준: {report['overall_agi_score']:.3f}")
    print(f"📊 숙달률: {report['mastered_tasks']}/{report['total_tasks']}")


# ============================================================================
# V8.5 Physical AGI - 신규 커리큘럼 / New Curricula
# ============================================================================
#
# 중요 원칙 / IMPORTANT PRINCIPLE:
#   이 커리큘럼은 하드코딩된 과제 시퀀스가 아니다.
#   각 과제는 "목표(GOAL)"와 "난이도(DIFFICULTY)"로 정의되며,
#   AI가 스스로 판단하여 액션을 구성하여 달성해야 한다.
#
#   These are NOT hardcoded task sequences. Each task is defined as a GOAL
#   with difficulty levels, and the AI must learn to compose actions
#   autonomously to achieve them.
# ============================================================================


def define_shopping_curriculum() -> Dict[str, PhysicalTask]:
    """
    쇼핑 커리큘럼 / Shopping Curriculum.

    목표: 상점을 탐색하고, 물품을 찾고, 집어 들고, 결제하는 전체 과정
    Goal: Navigate store, find items, pick up, pay - the complete shopping process.

    하드코딩된 시퀀스 없음 — AI가 목표를 달성하기 위해 스스로 액션을 구성
    NO hardcoded sequences — AI composes actions autonomously to achieve goals.
    """
    tasks: Dict[str, PhysicalTask] = {}

    # 레벨 1: 상점 입구 인식 / Recognize store entrance
    tasks["shop_01_enter"] = PhysicalTask(
        task_id="shop_01_enter",
        name="상점 입장",
        category=TaskCategory.SHOPPING,
        difficulty=TaskDifficulty.LEVEL_1,
        description="상점 입구를 인식하고 안전하게 입장한다 / Recognize and safely enter the store entrance",
        required_primitive_skills=["walk_forward", "scan_area"],
        success_criteria={"entrance_detected": 0.8, "entry_completed": 1.0},
        safety_constraints={"max_speed": 0.3, "min_obstacle_distance": 0.5},
        object_requirements=["door", "entrance_sign"],
        typical_duration_s=30.0,
        energy_estimate_j=50.0,
    )

    # 레벨 2: 매장 내비게이션 / Navigate store
    tasks["shop_02_navigate"] = PhysicalTask(
        task_id="shop_02_navigate",
        name="매장 탐색",
        category=TaskCategory.SHOPPING,
        difficulty=TaskDifficulty.LEVEL_2,
        description="매장 레이아웃을 파악하고 목표 코너로 이동한다 / Understand store layout and navigate to target aisle",
        required_primitive_skills=["walk_forward", "turn_in_place", "scan_area", "look_at"],
        success_criteria={"aisle_reached": 0.7, "path_efficiency": 0.5},
        safety_constraints={"max_speed": 0.4, "avoid_shoppers": 0.8},
        object_requirements=["signs", "shelves"],
        typical_duration_s=60.0,
        energy_estimate_j=150.0,
    )

    # 레벨 3: 물품 식별 / Identify items
    tasks["shop_03_identify"] = PhysicalTask(
        task_id="shop_03_identify",
        name="물품 식별",
        category=TaskCategory.SHOPPING,
        difficulty=TaskDifficulty.LEVEL_3,
        description="선반에서 원하는 물품을 시각적으로 식별한다 / Visually identify desired items on shelves",
        required_primitive_skills=["look_at", "scan_area", "track_object"],
        success_criteria={"item_detected": 0.8, "item_correct": 0.7},
        safety_constraints={"no_shelf_contact": 0.9},
        object_requirements=["products", "price_tags"],
        typical_duration_s=45.0,
        energy_estimate_j=40.0,
    )

    # 레벨 4: 물품 집기 / Pick up items
    tasks["shop_04_pick"] = PhysicalTask(
        task_id="shop_04_pick",
        name="물품 집기",
        category=TaskCategory.SHOPPING,
        difficulty=TaskDifficulty.LEVEL_4,
        description="선반에서 물품을 적절한 힘으로 집어 든다 / Pick up items from shelves with appropriate force",
        required_primitive_skills=["grip_close", "lift", "crouch", "grip_hold"],
        success_criteria={"grasp_success": 0.8, "no_damage": 0.95, "grip_stable": 0.8},
        safety_constraints={"max_grip_force": 8.0, "fragile_detection": 0.8},
        object_requirements=["products", "shopping_basket"],
        typical_duration_s=20.0,
        energy_estimate_j=60.0,
    )

    # 레벨 5: 장바구니 운반 / Carry shopping basket
    tasks["shop_05_carry"] = PhysicalTask(
        task_id="shop_05_carry",
        name="장바구니 운반",
        category=TaskCategory.SHOPPING,
        difficulty=TaskDifficulty.LEVEL_5,
        description="장바구니를 들고 매장을 이동한다 / Carry shopping basket while navigating store",
        required_primitive_skills=["carry_walk", "carry_turn", "grip_hold"],
        success_criteria=["basket_stable", "navigation_accurate"],
        safety_constraints={"max_carry_weight_kg": 5.0, "balance_min": 0.7},
        object_requirements=["shopping_basket", "products"],
        typical_duration_s=120.0,
        energy_estimate_j=300.0,
    )

    # 레벨 6: 계산대 이동 / Navigate to checkout
    tasks["shop_06_checkout_nav"] = PhysicalTask(
        task_id="shop_06_checkout_nav",
        name="계산대 이동",
        category=TaskCategory.SHOPPING,
        difficulty=TaskDifficulty.LEVEL_3,
        description="계산대를 찾아 줄을 선다 / Find checkout counter and wait in line",
        required_primitive_skills=["walk_forward", "scan_area", "stabilize"],
        success_criteria={"checkout_found": 0.9, "line_followed": 0.7},
        safety_constraints={"person_distance_min": 0.5},
        typical_duration_s=60.0,
        energy_estimate_j=100.0,
    )

    # 레벨 7: 결제 / Payment
    tasks["shop_07_pay"] = PhysicalTask(
        task_id="shop_07_pay",
        name="결제",
        category=TaskCategory.SHOPPING,
        difficulty=TaskDifficulty.LEVEL_7,
        description="물품을 계산대에 올리고 결제를 수행한다 / Place items on counter and complete payment",
        required_primitive_skills=["place", "press_button", "grip_open", "wave"],
        success_criteria={"items_placed": 0.9, "payment_initiated": 0.7},
        safety_constraints={"card_handling_care": 0.9},
        object_requirements=["counter", "payment_terminal", "card"],
        typical_duration_s=90.0,
        energy_estimate_j=80.0,
    )

    # 레벨 8: 포장 및 퇴장 / Bag and exit
    tasks["shop_08_bag_exit"] = PhysicalTask(
        task_id="shop_08_bag_exit",
        name="포장 및 퇴장",
        category=TaskCategory.SHOPPING,
        difficulty=TaskDifficulty.LEVEL_6,
        description="구매한 물품을 가방에 담고 상점을 나간다 / Bag purchased items and exit store",
        required_primitive_skills=["grip_close", "carry_walk", "two_hand_carry"],
        success_criteria={"bagging_complete": 0.8, "exit_safe": 0.9},
        safety_constraints={"bag_weight_max_kg": 8.0, "exit_path_clear": 0.9},
        typical_duration_s=60.0,
        energy_estimate_j=150.0,
    )

    logger.info(
        "쇼핑 커리큘럼 %d개 과제 정의됨 / Defined %d shopping curriculum tasks",
        len(tasks), len(tasks),
    )
    return tasks


def define_cooking_curriculum() -> Dict[str, PhysicalTask]:
    """
    요리 커리큘럼 / Cooking Curriculum.

    목표: 레시피를 따르고, 식재료를 다루고, 도구를 사용하여 요리 완성
    Goal: Follow recipe, handle food, use tools to complete cooking.
    """
    tasks: Dict[str, PhysicalTask] = {}

    tasks["cook_01_read_recipe"] = PhysicalTask(
        task_id="cook_01_read_recipe",
        name="레시피 읽기",
        category=TaskCategory.COOKING,
        difficulty=TaskDifficulty.LEVEL_2,
        description="레시피를 인식하고 필요한 재료와 단계를 파악한다 / Read recipe and identify required ingredients and steps",
        required_primitive_skills=["look_at", "scan_area", "focus_distance"],
        success_criteria={"recipe_parsed": 0.8, "ingredients_identified": 0.7},
        safety_constraints={},
        object_requirements=["recipe_card", "screen"],
        typical_duration_s=30.0,
        energy_estimate_j=20.0,
    )

    tasks["cook_02_gather_ingredients"] = PhysicalTask(
        task_id="cook_02_gather_ingredients",
        name="재료 모으기",
        category=TaskCategory.COOKING,
        difficulty=TaskDifficulty.LEVEL_4,
        description="필요한 식재료를 찾아 조리대로 가져온다 / Find and bring ingredients to the counter",
        required_primitive_skills=["walk_forward", "grip_close", "carry_walk", "place"],
        success_criteria={"ingredients_found": 0.8, "items_transported": 0.7},
        safety_constraints={"fragile_handling": 0.9, "raw_food_safety": 0.8},
        object_requirements=["ingredients", "containers", "counter"],
        typical_duration_s=120.0,
        energy_estimate_j=200.0,
    )

    tasks["cook_03_wash"] = PhysicalTask(
        task_id="cook_03_wash",
        name="재료 세척",
        category=TaskCategory.COOKING,
        difficulty=TaskDifficulty.LEVEL_3,
        description="야채/과일을 물로 세척한다 / Wash vegetables/fruits with water",
        required_primitive_skills=["grip_hold", "rotate_wrist", "place"],
        success_criteria={"washing_complete": 0.8, "no_damage": 0.9},
        safety_constraints={"water_temperature": 0.7, "no_slip": 0.8},
        object_requirements=["sink", "water_tap", "vegetables"],
        typical_duration_s=60.0,
        energy_estimate_j=50.0,
    )

    tasks["cook_04_cut"] = PhysicalTask(
        task_id="cook_04_cut",
        name="재료 자르기",
        category=TaskCategory.COOKING,
        difficulty=TaskDifficulty.LEVEL_7,
        description="식재료를 칼로 원하는 크기로 자른다 / Cut ingredients to desired size with knife",
        required_primitive_skills=["grasp_handle", "cut", "hold_steady", "slide_on_surface"],
        success_criteria={"cut_accuracy": 0.6, "safety_maintained": 0.99, "finger_safety": 0.99},
        safety_constraints={"blade_safety": 0.99, "cutting_board_stable": 0.9, "max_force": 10.0},
        object_requirements=["knife", "cutting_board", "ingredients"],
        typical_duration_s=120.0,
        energy_estimate_j=80.0,
    )

    tasks["cook_05_cook_heat"] = PhysicalTask(
        task_id="cook_05_cook_heat",
        name="조리 (가열)",
        category=TaskCategory.COOKING,
        difficulty=TaskDifficulty.LEVEL_8,
        description="가열 기구를 사용하여 식재료를 조리한다 / Cook ingredients using heat source",
        required_primitive_skills=["grasp_handle", "squeeze", "pour", "stir", "hold_steady"],
        success_criteria={"temperature_control": 0.7, "no_burn": 0.95, "food_cooked": 0.8},
        safety_constraints={"heat_distance_min_m": 0.15, "hot_surface_awareness": 0.99, "max_approach_time_s": 3.0},
        object_requirements=["stove", "pan", "oil", "ingredients"],
        typical_duration_s=600.0,
        energy_estimate_j=300.0,
    )

    tasks["cook_06_season"] = PhysicalTask(
        task_id="cook_06_season",
        name="간맞추기",
        category=TaskCategory.COOKING,
        difficulty=TaskDifficulty.LEVEL_5,
        description="양념을 적절량 첨가하여 맛을 조절한다 / Add seasonings in appropriate amounts",
        required_primitive_skills=["pinch", "pour", "palpate"],
        success_criteria={"seasoning_amount": 0.7, "taste_balance": 0.5},
        safety_constraints={"no_contamination": 0.9},
        object_requirements=["seasoning", "spoons", "food"],
        typical_duration_s=30.0,
        energy_estimate_j=30.0,
    )

    tasks["cook_07_plate"] = PhysicalTask(
        task_id="cook_07_plate",
        name="플레이팅",
        category=TaskCategory.COOKING,
        difficulty=TaskDifficulty.LEVEL_6,
        description="완성된 요리를 접시에 예쁘게 담는다 / Plate completed dish attractively",
        required_primitive_skills=["slide_on_surface", "place", "two_hand_carry", "rotate_wrist"],
        success_criteria={"placement_accuracy": 0.7, "presentation_quality": 0.5},
        safety_constraints={"hot_food_handling": 0.9, "no_spill": 0.8},
        object_requirements=["plate", "food", "serving_utensils"],
        typical_duration_s=60.0,
        energy_estimate_j=60.0,
    )

    logger.info(
        "요리 커리큘럼 %d개 과제 정의됨 / Defined %d cooking curriculum tasks",
        len(tasks), len(tasks),
    )
    return tasks


def define_cleaning_curriculum() -> Dict[str, PhysicalTask]:
    """
    청소 커리큘럼 / Cleaning Curriculum.

    목표: 오염 식별 → 방법 선택 → 실행 → 확인
    Goal: Identify dirt → choose method → execute → verify.
    """
    tasks: Dict[str, PhysicalTask] = {}

    tasks["clean_01_detect"] = PhysicalTask(
        task_id="clean_01_detect",
        name="오염 감지",
        category=TaskCategory.CLEANING,
        difficulty=TaskDifficulty.LEVEL_2,
        description="시각/촉각으로 오염을 감지한다 / Detect dirt/stains visually or tactilely",
        required_primitive_skills=["scan_area", "palpate", "look_at"],
        success_criteria={"detection_accuracy": 0.7},
        safety_constraints={},
        object_requirements=["surfaces"],
        typical_duration_s=30.0,
        energy_estimate_j=20.0,
    )

    tasks["clean_02_select_method"] = PhysicalTask(
        task_id="clean_02_select_method",
        name="청소 방법 선택",
        category=TaskCategory.CLEANING,
        difficulty=TaskDifficulty.LEVEL_4,
        description="오염 유형에 따라 청소 방법과 도구를 선택한다 / Choose cleaning method and tools based on dirt type",
        required_primitive_skills=["look_at", "scan_area"],
        success_criteria={"method_appropriate": 0.7},
        safety_constraints={},
        object_requirements=["cleaning_supplies"],
        typical_duration_s=15.0,
        energy_estimate_j=10.0,
    )

    tasks["clean_03_wipe"] = PhysicalTask(
        task_id="clean_03_wipe",
        name="닦기",
        category=TaskCategory.CLEANING,
        difficulty=TaskDifficulty.LEVEL_3,
        description="천이나 스펀지로 표면을 닦는다 / Wipe surface with cloth or sponge",
        required_primitive_skills=["grasp_handle", "slide_on_surface", "grip_hold", "apply_force"],
        success_criteria={"area_covered": 0.8, "cleanliness": 0.7},
        safety_constraints={"surface_safe": 0.9},
        object_requirements=["cloth", "sponge", "surface"],
        typical_duration_s=60.0,
        energy_estimate_j=80.0,
    )

    tasks["clean_04_sweep"] = PhysicalTask(
        task_id="clean_04_sweep",
        name="쓸기",
        category=TaskCategory.CLEANING,
        difficulty=TaskDifficulty.LEVEL_4,
        description="빗자루로 바닥을 쓸어 모은다 / Sweep floor with broom",
        required_primitive_skills=["grasp_handle", "swing", "carry_walk"],
        success_criteria={"debris_collected": 0.8, "area_covered": 0.7},
        safety_constraints={"dust_control": 0.7},
        object_requirements=["broom", "dustpan"],
        typical_duration_s=120.0,
        energy_estimate_j=150.0,
    )

    tasks["clean_05_organize"] = PhysicalTask(
        task_id="clean_05_organize",
        name="정리정돈",
        category=TaskCategory.CLEANING,
        difficulty=TaskDifficulty.LEVEL_5,
        description="물건을 제자리에 정리한다 / Organize items to their proper places",
        required_primitive_skills=["grip_close", "lift", "carry_walk", "place", "slide_on_surface"],
        success_criteria={"items_organized": 0.7, "placement_accuracy": 0.6},
        safety_constraints={"fragile_handling": 0.9},
        object_requirements=["items", "shelves", "containers"],
        typical_duration_s=180.0,
        energy_estimate_j=250.0,
    )

    tasks["clean_06_verify"] = PhysicalTask(
        task_id="clean_06_verify",
        name="청결 확인",
        category=TaskCategory.CLEANING,
        difficulty=TaskDifficulty.LEVEL_2,
        description="청소 결과를 시각적으로 확인한다 / Visually verify cleaning results",
        required_primitive_skills=["scan_area", "look_at"],
        success_criteria={"verification_accuracy": 0.8},
        safety_constraints={},
        typical_duration_s=20.0,
        energy_estimate_j=15.0,
    )

    logger.info(
        "청소 커리큘럼 %d개 과제 정의됨 / Defined %d cleaning curriculum tasks",
        len(tasks), len(tasks),
    )
    return tasks


def define_crafting_curriculum() -> Dict[str, PhysicalTask]:
    """
    공예 커리큘럼 / Crafting Curriculum.

    목표: 재료 다루기 → 정밀 작업 → 조립 → 완성
    Goal: Handle materials → precision work → assemble → complete.
    """
    tasks: Dict[str, PhysicalTask] = {}

    tasks["craft_01_select_materials"] = PhysicalTask(
        task_id="craft_01_select_materials",
        name="재료 선택",
        category=TaskCategory.CRAFTWORK,
        difficulty=TaskDifficulty.LEVEL_3,
        description="공예에 필요한 재료를 식별하고 선택한다 / Identify and select materials for crafting",
        required_primitive_skills=["look_at", "palpate", "grip_close"],
        success_criteria={"material_correct": 0.8},
        safety_constraints={},
        object_requirements=["craft_materials"],
        typical_duration_s=30.0,
        energy_estimate_j=30.0,
    )

    tasks["craft_02_measure"] = PhysicalTask(
        task_id="craft_02_measure",
        name="측정",
        category=TaskCategory.CRAFTWORK,
        difficulty=TaskDifficulty.LEVEL_5,
        description="재료를 정확한 크기로 측정한다 / Measure materials to precise dimensions",
        required_primitive_skills=["look_at", "hold_steady", "pinch"],
        success_criteria={"measurement_accuracy_mm": 2.0},
        safety_constraints={},
        object_requirements=["ruler", "materials", "marking_tool"],
        typical_duration_s=30.0,
        energy_estimate_j=20.0,
    )

    tasks["craft_03_cut_shape"] = PhysicalTask(
        task_id="craft_03_cut_shape",
        name="재단",
        category=TaskCategory.CRAFTWORK,
        difficulty=TaskDifficulty.LEVEL_7,
        description="가위나 칼로 재료를 원하는 모양으로 자른다 / Cut materials to desired shape with scissors or knife",
        required_primitive_skills=["grasp_handle", "cut", "hold_steady", "squeeze"],
        success_criteria={"cut_precision": 0.6, "safety_maintained": 0.99},
        safety_constraints={"blade_safety": 0.99, "finger_clearance": 0.99},
        object_requirements=["scissors", "craft_knife", "materials"],
        typical_duration_s=120.0,
        energy_estimate_j=80.0,
    )

    tasks["craft_04_assemble"] = PhysicalTask(
        task_id="craft_04_assemble",
        name="조립",
        category=TaskCategory.CRAFTWORK,
        difficulty=TaskDifficulty.LEVEL_8,
        description="부품들을 정확한 위치에 조립한다 / Assemble parts in correct positions",
        required_primitive_skills=["grip_close", "insert", "twist", "hold_steady", "place"],
        success_criteria={"alignment_accuracy": 0.7, "joint_security": 0.8},
        safety_constraints={"glue_safety": 0.9, "pinch_points": 0.9},
        object_requirements=["parts", "glue", "tools"],
        typical_duration_s=180.0,
        energy_estimate_j=120.0,
    )

    tasks["craft_05_decorate"] = PhysicalTask(
        task_id="craft_05_decorate",
        name="장식",
        category=TaskCategory.CRAFTWORK,
        difficulty=TaskDifficulty.LEVEL_6,
        description="완성품에 장식을 추가한다 / Add decorative elements to finished piece",
        required_primitive_skills=["brush_stroke", "pinch", "place"],
        success_criteria={"decoration_accuracy": 0.6, "aesthetic_quality": 0.5},
        safety_constraints={"paint_safety": 0.9},
        object_requirements=["paint", "brushes", "decorations"],
        typical_duration_s=120.0,
        energy_estimate_j=60.0,
    )

    logger.info(
        "공예 커리큘럼 %d개 과제 정의됨 / Defined %d crafting curriculum tasks",
        len(tasks), len(tasks),
    )
    return tasks


def define_public_transport_curriculum() -> Dict[str, PhysicalTask]:
    """
    대중교통 커리큘럼 / Public Transport Curriculum.

    목표: 표지 읽기 → 이동 → 승차 → 하차
    Goal: Read signs → navigate → board → alight.
    """
    tasks: Dict[str, PhysicalTask] = {}

    tasks["transit_01_read_signs"] = PhysicalTask(
        task_id="transit_01_read_signs",
        name="표지판 읽기",
        category=TaskCategory.PUBLIC_TRANSPORT,
        difficulty=TaskDifficulty.LEVEL_3,
        description="역/정류장 표지판을 인식하고 방향을 파악한다 / Read station/bus stop signs and determine direction",
        required_primitive_skills=["look_at", "scan_area", "focus_distance"],
        success_criteria={"sign_recognized": 0.7, "direction_correct": 0.8},
        safety_constraints={},
        object_requirements=["signs", "maps"],
        typical_duration_s=30.0,
        energy_estimate_j=20.0,
    )

    tasks["transit_02_navigate_station"] = PhysicalTask(
        task_id="transit_02_navigate_station",
        name="역사 이동",
        category=TaskCategory.PUBLIC_TRANSPORT,
        difficulty=TaskDifficulty.LEVEL_5,
        description="역사 내에서 승강장까지 이동한다 / Navigate inside station to the platform",
        required_primitive_skills=["walk_forward", "climb_step", "scan_area", "balance_on_slope"],
        success_criteria={"platform_reached": 0.8, "time_efficient": 0.5},
        safety_constraints={"crowd_awareness": 0.8, "gap_mindful": 0.9},
        object_requirements=["stairs", "escalator", "gates"],
        typical_duration_s=120.0,
        energy_estimate_j=200.0,
    )

    tasks["transit_03_board"] = PhysicalTask(
        task_id="transit_03_board",
        name="승차",
        category=TaskCategory.PUBLIC_TRANSPORT,
        difficulty=TaskDifficulty.LEVEL_6,
        description="차량 문이 열렸을 때 안전하게 탑승한다 / Board safely when vehicle doors open",
        required_primitive_skills=["walk_forward", "climb_step", "stabilize"],
        success_criteria={"boarding_safe": 0.95, "timing_correct": 0.8},
        safety_constraints={"gap_clearance": 0.9, "door_timing": 0.9},
        typical_duration_s=15.0,
        energy_estimate_j=40.0,
    )

    tasks["transit_04_riding"] = PhysicalTask(
        task_id="transit_04_riding",
        name="승차 중 안전 유지",
        category=TaskCategory.PUBLIC_TRANSPORT,
        difficulty=TaskDifficulty.LEVEL_4,
        description="이동 중 균형을 유지하고 안전하게 선다/앉는다 / Maintain balance and stand/sit safely during transit",
        required_primitive_skills=["stabilize", "shift_weight", "crouch"],
        success_criteria={"balance_maintained": 0.9},
        safety_constraints={"handhold_required": 0.95},
        typical_duration_s=600.0,
        energy_estimate_j=150.0,
    )

    tasks["transit_05_alight"] = PhysicalTask(
        task_id="transit_05_alight",
        name="하차",
        category=TaskCategory.PUBLIC_TRANSPORT,
        difficulty=TaskDifficulty.LEVEL_6,
        description="목적역에서 안전하게 하차한다 / Alight safely at destination station",
        required_primitive_skills=["walk_forward", "descend_step", "stabilize"],
        success_criteria={"alighting_safe": 0.95, "timing_correct": 0.8},
        safety_constraints={"gap_mindful": 0.9, "platform_awareness": 0.9},
        typical_duration_s=15.0,
        energy_estimate_j=40.0,
    )

    logger.info(
        "대중교통 커리큘럼 %d개 과제 정의됨 / Defined %d public transport curriculum tasks",
        len(tasks), len(tasks),
    )
    return tasks


def define_customer_service_curriculum() -> Dict[str, PhysicalTask]:
    """
    고객 서비스 커리큘럼 / Customer Service Curriculum.

    목표: 인사 → 이해 → 응답 → 배려
    Goal: Greet → understand → respond → care.
    """
    tasks: Dict[str, PhysicalTask] = {}

    tasks["svc_01_greet"] = PhysicalTask(
        task_id="svc_01_greet",
        name="인사",
        category=TaskCategory.CUSTOMER_SERVICE,
        difficulty=TaskDifficulty.LEVEL_2,
        description="고객을 인식하고 적절한 제스처로 인사한다 / Recognize customer and greet with appropriate gesture",
        required_primitive_skills=["wave", "nod_gesture", "bow", "look_at"],
        success_criteria={"gesture_appropriate": 0.8, "timing_natural": 0.6},
        safety_constraints={"personal_space": 0.8},
        typical_duration_s=10.0,
        energy_estimate_j=15.0,
    )

    tasks["svc_02_listen"] = PhysicalTask(
        task_id="svc_02_listen",
        name="요청 듣기",
        difficulty=TaskDifficulty.LEVEL_4,
        description="고객의 요청을 주의 깊게 듣고 이해한다 / Listen to and understand customer requests",
        required_primitive_skills=["look_at", "nod_gesture", "stabilize"],
        success_criteria={"request_understood": 0.7},
        safety_constraints={},
        typical_duration_s=30.0,
        energy_estimate_j=10.0,
    )

    tasks["svc_03_respond"] = PhysicalTask(
        task_id="svc_03_respond",
        name="응답 및 안내",
        category=TaskCategory.CUSTOMER_SERVICE,
        difficulty=TaskDifficulty.LEVEL_6,
        description="고객 요청에 적절히 응답하고 안내한다 / Respond appropriately and guide customer",
        required_primitive_skills=["point", "wave", "nod_gesture", "walk_forward"],
        success_criteria={"response_appropriate": 0.7, "guidance_clear": 0.6},
        safety_constraints={},
        typical_duration_s=60.0,
        energy_estimate_j=50.0,
    )

    tasks["svc_04_handover"] = PhysicalTask(
        task_id="svc_04_handover",
        name="물품 전달",
        category=TaskCategory.CUSTOMER_SERVICE,
        difficulty=TaskDifficulty.LEVEL_5,
        description="고객에게 물품을 정중하게 전달한다 / Hand over items politely to customer",
        required_primitive_skills=["carry_walk", "handover", "release_gently", "bow"],
        success_criteria={"handover_smooth": 0.8, "no_damage": 0.95},
        safety_constraints={"fragile_handling": 0.9},
        object_requirements=["items", "customer"],
        typical_duration_s=20.0,
        energy_estimate_j=30.0,
    )

    tasks["svc_05_farewell"] = PhysicalTask(
        task_id="svc_05_farewell",
        name="작별 인사",
        category=TaskCategory.CUSTOMER_SERVICE,
        difficulty=TaskDifficulty.LEVEL_2,
        description="고객에게 정중하게 작별 인사한다 / Bid polite farewell to customer",
        required_primitive_skills=["bow", "wave", "nod_gesture"],
        success_criteria={"gesture_appropriate": 0.8},
        safety_constraints={},
        typical_duration_s=5.0,
        energy_estimate_j=10.0,
    )

    logger.info(
        "고객 서비스 커리큘럼 %d개 과제 정의됨 / Defined %d customer service curriculum tasks",
        len(tasks), len(tasks),
    )
    return tasks


def define_ball_sports_curriculum() -> Dict[str, PhysicalTask]:
    """
    구기 운동 커리큘럼 / Ball Sports Curriculum.

    목표: 던지기 → 잡기 → 조준 → 경기
    Goal: Throw → catch → aim → play.
    """
    tasks: Dict[str, PhysicalTask] = {}

    tasks["ball_01_grasp"] = PhysicalTask(
        task_id="ball_01_grasp",
        name="공 잡기",
        category=TaskCategory.BALL_SPORTS,
        difficulty=TaskDifficulty.LEVEL_2,
        description="공을 적절한 힘으로 잡는다 / Grasp ball with appropriate force",
        required_primitive_skills=["grip_close", "grip_hold", "palpate"],
        success_criteria={"grasp_stable": 0.8, "no_crush": 0.9},
        safety_constraints={},
        object_requirements=["ball"],
        typical_duration_s=5.0,
        energy_estimate_j=10.0,
    )

    tasks["ball_02_throw"] = PhysicalTask(
        task_id="ball_02_throw",
        name="던지기",
        category=TaskCategory.BALL_SPORTS,
        difficulty=TaskDifficulty.LEVEL_5,
        description="공을 목표 방향으로 던진다 / Throw ball toward target direction",
        required_primitive_skills=["grip_hold", "swing", "lean_forward", "release_gently"],
        success_criteria={"throw_accuracy_deg": 15.0, "throw_distance_m": 3.0},
        safety_constraints={"throw_zone_clear": 0.9},
        object_requirements=["ball", "target"],
        typical_duration_s=5.0,
        energy_estimate_j=30.0,
    )

    tasks["ball_03_catch"] = PhysicalTask(
        task_id="ball_03_catch",
        name="받기",
        category=TaskCategory.BALL_SPORTS,
        difficulty=TaskDifficulty.LEVEL_7,
        description="날아오는 공을 잡는다 / Catch incoming ball",
        required_primitive_skills=["track_object", "grip_close", "stabilize", "shift_weight"],
        success_criteria={"catch_success_rate": 0.5, "reaction_time_s": 0.5},
        safety_constraints={"face_protection": 0.9},
        object_requirements=["ball"],
        typical_duration_s=5.0,
        energy_estimate_j=20.0,
    )

    tasks["ball_04_aim"] = PhysicalTask(
        task_id="ball_04_aim",
        name="조준 던지기",
        category=TaskCategory.BALL_SPORTS,
        difficulty=TaskDifficulty.LEVEL_8,
        description="특정 목표물을 조준하여 정확히 던진다 / Aim and throw at specific target accurately",
        required_primitive_skills=["look_at", "grip_hold", "swing", "hold_steady", "release_gently"],
        success_criteria={"target_hit_rate": 0.4, "precision_cm": 30.0},
        safety_constraints={"throw_zone_clear": 0.95},
        object_requirements=["ball", "target", "net"],
        typical_duration_s=10.0,
        energy_estimate_j=40.0,
    )

    tasks["ball_05_dribble"] = PhysicalTask(
        task_id="ball_05_dribble",
        name="드리블",
        category=TaskCategory.BALL_SPORTS,
        difficulty=TaskDifficulty.LEVEL_9,
        description="공을 바닥에 튀기며 이동한다 / Dribble ball while moving",
        required_primitive_skills=["push", "walk_forward", "tap", "stabilize"],
        success_criteria={"dribble_continuous": 0.5, "control_retained": 0.5},
        safety_constraints={"surface_suitable": 0.8},
        object_requirements=["ball", "flat_surface"],
        typical_duration_s=30.0,
        energy_estimate_j=100.0,
    )

    logger.info(
        "구기 운동 커리큘럼 %d개 과제 정의됨 / Defined %d ball sports curriculum tasks",
        len(tasks), len(tasks),
    )
    return tasks


def define_field_trip_curriculum() -> Dict[str, PhysicalTask]:
    """
    현장 학습 커리큘럼 / Field Trip Curriculum.

    목표: 야외 탐색 → 관찰 → 기록 → 귀환
    Goal: Outdoor navigation → observation → recording → return.
    """
    tasks: Dict[str, PhysicalTask] = {}

    tasks["field_01_outdoor_nav"] = PhysicalTask(
        task_id="field_01_outdoor_nav",
        name="야외 이동",
        category=TaskCategory.FIELD_TRIP,
        difficulty=TaskDifficulty.LEVEL_4,
        description="야외 환경에서 안전하게 이동한다 / Navigate safely in outdoor environment",
        required_primitive_skills=["walk_forward", "balance_on_slope", "scan_area", "climb_step"],
        success_criteria={"navigation_safe": 0.9, "path_efficient": 0.6},
        safety_constraints={"terrain_assessment": 0.8, "obstacle_avoidance": 0.9},
        object_requirements=["path", "terrain"],
        typical_duration_s=300.0,
        energy_estimate_j=500.0,
    )

    tasks["field_02_observe"] = PhysicalTask(
        task_id="field_02_observe",
        name="관찰",
        category=TaskCategory.FIELD_TRIP,
        difficulty=TaskDifficulty.LEVEL_3,
        description="자연/문화 대상을 관찰한다 / Observe natural/cultural subjects",
        required_primitive_skills=["look_at", "scan_area", "focus_distance", "track_object"],
        success_criteria={"observation_quality": 0.7},
        safety_constraints={"distance_maintained": 0.8},
        object_requirements=["observation_target"],
        typical_duration_s=120.0,
        energy_estimate_j=40.0,
    )

    tasks["field_03_collect"] = PhysicalTask(
        task_id="field_03_collect",
        name="표본 수집",
        category=TaskCategory.FIELD_TRIP,
        difficulty=TaskDifficulty.LEVEL_5,
        description="표본을 안전하게 수집한다 / Collect specimens safely",
        required_primitive_skills=["crouch", "grip_close", "grip_hold", "carry_walk"],
        success_criteria={"collection_safe": 0.9, "specimen_intact": 0.8},
        safety_constraints={"hazardous_material": 0.95, "environmental_impact_min": 0.8},
        object_requirements=["specimens", "containers"],
        typical_duration_s=60.0,
        energy_estimate_j=80.0,
    )

    tasks["field_04_return"] = PhysicalTask(
        task_id="field_04_return",
        name="귀환",
        category=TaskCategory.FIELD_TRIP,
        difficulty=TaskDifficulty.LEVEL_4,
        description="수집한 자료를 가지고 안전하게 귀환한다 / Return safely with collected materials",
        required_primitive_skills=["carry_walk", "walk_forward", "stabilize", "scan_area"],
        success_criteria={"return_safe": 0.95, "materials_intact": 0.8},
        safety_constraints={"fatigue_monitoring": 0.7, "route_familiarity": 0.7},
        typical_duration_s=300.0,
        energy_estimate_j=500.0,
    )

    logger.info(
        "현장 학습 커리큘럼 %d개 과제 정의됨 / Defined %d field trip curriculum tasks",
        len(tasks), len(tasks),
    )
    return tasks


def define_all_v85_curricula() -> Dict[str, PhysicalTask]:
    """
    V8.5 Physical AGI 전체 신규 커리큘럼 정의 / Define all V8.5 new curricula.

    8개 신규 도메인의 모든 과제를 통합한다.
    Integrates all tasks from 8 new domains.

    중요: 이 과제들은 목표(GOAL)이지 하드코딩된 시퀀스가 아니다.
    IMPORTANT: These are GOALS, not hardcoded sequences.
    AI가 스스로 판단하여 액션을 구성해야 한다.
    """
    all_tasks: Dict[str, PhysicalTask] = {}
    all_tasks.update(define_shopping_curriculum())
    all_tasks.update(define_cooking_curriculum())
    all_tasks.update(define_cleaning_curriculum())
    all_tasks.update(define_crafting_curriculum())
    all_tasks.update(define_public_transport_curriculum())
    all_tasks.update(define_customer_service_curriculum())
    all_tasks.update(define_ball_sports_curriculum())
    all_tasks.update(define_field_trip_curriculum())

    logger.info(
        "V8.5 신규 커리큘럼 총 %d개 과제 정의 완료 / "
        "V8.5 new curricula: %d total tasks defined",
        len(all_tasks),
        len(all_tasks),
    )
    return all_tasks

