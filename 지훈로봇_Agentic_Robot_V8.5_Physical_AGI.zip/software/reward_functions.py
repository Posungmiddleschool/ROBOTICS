#!/usr/bin/env python3
"""
reward_functions.py — V8.5 Multi-Objective Reward Function Library
지훈 로봇 물리적 AGI — V8.5 다목적 보상 함수 라이브러리

Physical AGI requires sophisticated, multi-objective reward shaping.
Single scalar rewards fail to capture the nuance of physical interaction:
a task may succeed but waste energy, or be fast but unstable.

Physical AGI는 정교한 다목적 보상 설계가 필요합니다.
단일 스칼라 보상은 물리적 상호작용의 뉘앙스를 포착하지 못합니다:
작업은 성공하되 에너지를 낭비하거나, 빠르지만 불안정할 수 있습니다.

Components / 구성요소:
  1. PhysicalRewardCalculator — 5개 보상 컴포넌트 계산기
  2. AdaptiveRewardShaper     — 학습 진행에 따른 가중치 자동 조절
  3. RewardNormalizer         — 실행 z-score 정규화
  4. compute_combined_reward  — 가중 결합 보상 함수

Reward Components / 보상 컴포넌트:
  - task_success:      작업 성공도 [-1, 1]
  - precision:         정밀도 보상 [-1, 1]
  - energy_efficiency: 에너지 효율 [-1, 1]
  - stability:         안정성 보상 [-1, 1]
  - time_efficiency:   시간 효율 [-1, 1]

Hardware: Dual Jetson Orin NX 16GB
AI Model: Gemma 4 E4B Q4_K_M
Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple, Union

import numpy as np

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.reward_functions")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 상수 / Constants ────────────────────────────────────────────────────────

REWARD_COMPONENTS = [
    "task_success", "precision", "energy_efficiency",
    "stability", "time_efficiency",
]
DEFAULT_WEIGHTS = {
    "task_success": 0.30,
    "precision": 0.20,
    "energy_efficiency": 0.15,
    "stability": 0.20,
    "time_efficiency": 0.15,
}
# 보상 클램핑 / Reward clamping bounds
R_MIN, R_MAX = -1.0, 1.0
# 정규화 안정성 엡실론 / Normalization epsilon
EPS = 1e-8
# 적응형 보상 셰이퍼 윈도우 / Adaptive shaper window size
SHAPER_WINDOW = 100
# 정체 탐지 임계값 / Plateau detection threshold
PLATEAU_THRESHOLD = 0.01
PLATEAU_PATIENCE = 20

# 커리큘럼 보상 스케줄링 / Curriculum reward scheduling
CURRICULUM_SCHEDULE = {
    # (min_level, max_level): {component: scale_factor}
    # 쉬운 작업(레벨 1-3): 성공 보상 강화, 정밀도 완화
    "easy": {
        "level_range": (1, 3),
        "scales": {
            "task_success": 1.5,
            "precision": 0.5,
            "energy_efficiency": 0.5,
            "stability": 1.0,
            "time_efficiency": 0.5,
        },
    },
    # 중간 작업(레벨 4-6): 균형 보상
    "medium": {
        "level_range": (4, 6),
        "scales": {
            "task_success": 1.0,
            "precision": 1.0,
            "energy_efficiency": 1.0,
            "stability": 1.0,
            "time_efficiency": 1.0,
        },
    },
    # 어려운 작업(레벨 7-10): 정밀도와 효율 강화
    "hard": {
        "level_range": (7, 10),
        "scales": {
            "task_success": 0.7,
            "precision": 1.5,
            "energy_efficiency": 1.3,
            "stability": 1.2,
            "time_efficiency": 1.3,
        },
    },
}


# ─── 데이터 클래스 / Data Classes ────────────────────────────────────────────


@dataclass
class RewardComponents:
    """
    다목적 보상 컴포넌트 / Multi-objective reward components.

    각 보상 컴포넌트는 [-1, 1] 범위로 정규화됩니다.
    각 컴포넌트의 가중치는 AdaptiveRewardShaper에 의해 동적으로 조정됩니다.

    Attributes:
        task_success:      작업 성공 보상 (-1=완전실패, 1=완전성공)
        precision:         정밀도 보상 (기대값 대비 정확도)
        energy_efficiency: 에너지 효율 보상 (작업 가치 대비 에너지 소비)
        stability:         안정성 보상 (균형 및 외란 내성)
        time_efficiency:   시간 효율 보상 (예상 대비 실제 소요 시간)
        metadata:          추가 메타데이터
        timestamp:         기록 시각
    """
    task_success: float = 0.0
    precision: float = 0.0
    energy_efficiency: float = 0.0
    stability: float = 0.0
    time_efficiency: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> Dict[str, float]:
        """딕셔너리로 변환 / Convert to dictionary."""
        return {
            "task_success": self.task_success,
            "precision": self.precision,
            "energy_efficiency": self.energy_efficiency,
            "stability": self.stability,
            "time_efficiency": self.time_efficiency,
        }

    def to_vector(self) -> np.ndarray:
        """넘파이 벡터로 변환 / Convert to numpy vector."""
        return np.array([
            self.task_success, self.precision, self.energy_efficiency,
            self.stability, self.time_efficiency,
        ], dtype=np.float64)


@dataclass
class RewardRecord:
    """
    보상 기록 / Reward record for persistence.

    SQLite에 저장되는 보상 기록입니다.
    """
    record_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    components: RewardComponents = field(default_factory=RewardComponents)
    combined_reward: float = 0.0
    weights_used: Dict[str, float] = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))
    task_type: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ─── SQLite 저장소 / SQLite Repository ───────────────────────────────────────


class RewardRepository:
    """
    보상 기록 SQLite 저장소 / Reward record SQLite repository.

    모든 보상 계산 결과를 SQLite에 영속화하여 학습 분석에 활용합니다.
    """

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS reward_records (
        record_id TEXT PRIMARY KEY,
        task_success REAL,
        precision REAL,
        energy_efficiency REAL,
        stability REAL,
        time_efficiency REAL,
        combined_reward REAL,
        weights_json TEXT,
        task_type TEXT,
        timestamp TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_reward_task ON reward_records(task_type);
    CREATE INDEX IF NOT EXISTS idx_reward_combined ON reward_records(combined_reward DESC);

    CREATE TABLE IF NOT EXISTS reward_stats (
        component TEXT PRIMARY KEY,
        running_mean REAL DEFAULT 0.0,
        running_var REAL DEFAULT 1.0,
        count INTEGER DEFAULT 0,
        updated_at TEXT
    );
    """

    def __init__(self, db_path: Union[str, Path] = "reward_history.db") -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()
        logger.info("RewardRepository 초기화: %s", self._db_path)

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(
                str(self._db_path), check_same_thread=False
            )
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript(self.SCHEMA)
        conn.commit()

    def save_record(self, record: RewardRecord) -> bool:
        """보상 기록 저장 / Save reward record."""
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT OR REPLACE INTO reward_records
                (record_id, task_success, precision, energy_efficiency,
                 stability, time_efficiency, combined_reward, weights_json,
                 task_type, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    record.record_id,
                    record.components.task_success,
                    record.components.precision,
                    record.components.energy_efficiency,
                    record.components.stability,
                    record.components.time_efficiency,
                    record.combined_reward,
                    json.dumps(record.weights_used),
                    record.task_type,
                    record.timestamp,
                ),
            )
            conn.commit()
            return True
        except sqlite3.Error as e:
            logger.error("보상 기록 저장 실패: %s", e)
            return False

    def get_recent(self, n: int = 100) -> List[Dict]:
        """최근 N개 보상 기록 조회 / Get recent N reward records."""
        try:
            conn = self._get_conn()
            rows = conn.execute(
                "SELECT * FROM reward_records ORDER BY timestamp DESC LIMIT ?", (n,)
            ).fetchall()
            return [dict(r) for r in rows]
        except sqlite3.Error:
            return []

    def get_component_stats(self) -> Dict[str, Dict[str, float]]:
        """컴포넌트별 통계 조회 / Get per-component statistics."""
        try:
            conn = self._get_conn()
            stats = {}
            for comp in REWARD_COMPONENTS:
                row = conn.execute(
                    f"SELECT AVG({comp}) as mean, "
                    f"MAX({comp}) as max_val, "
                    f"MIN({comp}) as min_val "
                    f"FROM reward_records"
                ).fetchone()
                if row:
                    stats[comp] = {
                        "mean": row["mean"] or 0.0,
                        "max": row["max_val"] or 0.0,
                        "min": row["min_val"] or 0.0,
                    }
            return stats
        except sqlite3.Error:
            return {}


# ─── 물리적 보상 계산기 / Physical Reward Calculator ─────────────────────────


class PhysicalRewardCalculator:
    """
    다목적 물리적 보상 계산기 / Multi-objective physical reward calculator.

    5개의 보상 컴포넌트를 독립적으로 계산합니다.
    각 컴포넌트는 [-1, 1] 범위로 정규화되어 결합됩니다.

    Usage:
        calc = PhysicalRewardCalculator()
        components = calc.compute_all(
            task_result={"success": True, "error": 0.02},
            expected={"position": [1.0, 0.0]}, actual={"position": [1.01, 0.01]},
            energy_used=0.5, task_value=1.0,
            balance_score=0.9, perturbation=0.1,
            actual_time=2.5, expected_time=3.0,
        )
    """

    def __init__(self) -> None:
        self._history: List[RewardComponents] = []
        self._lock = threading.Lock()
        logger.info("PhysicalRewardCalculator 초기화 완료")

    # ── 작업 성공 보상 / Task Success Reward ─────────────────────────────

    @staticmethod
    def task_success_reward(result: Dict[str, Any]) -> float:
        """
        작업 성공 보상 계산 / Compute task success reward.

        작업의 성공/실패 정도를 [-1, 1] 범위로 평가합니다.

        Args:
            result: 작업 결과 딕셔너리
                - success (bool): 성공 여부
                - partial_progress (float): 부분 진행도 0~1
                - failure_severity (float): 실패 심각도 0~1

        Returns:
            float: 보상 값 [-1, 1]
                1.0 = 완전 성공
                0.0 = 부분 성공 또는 미시도
               -1.0 = 치명적 실패
        """
        success = result.get("success", False)
        partial = result.get("partial_progress", 0.0)
        severity = result.get("failure_severity", 0.0)

        if success:
            reward = 1.0
        elif partial > 0.0:
            # 부분 성공: 진행도에 비례 / Partial success: proportional to progress
            reward = 2.0 * partial - 1.0  # maps [0,1] -> [-1,1]
        else:
            # 실패: 심각도에 반비례 / Failure: inversely proportional to severity
            reward = -severity

        return float(np.clip(reward, R_MIN, R_MAX))

    # ── 정밀도 보상 / Precision Reward ───────────────────────────────────

    @staticmethod
    def precision_reward(expected_vs_actual: Dict[str, Any]) -> float:
        """
        정밀도 보상 계산 / Compute precision reward.

        기대값과 실제값의 차이를 기반으로 정밀도를 평가합니다.

        Args:
            expected_vs_actual: 기대-실제 비교 딕셔너리
                - expected: 기대값 (스칼라 또는 벡터)
                - actual: 실제값 (스칼라 또는 벡터)
                - tolerance: 허용 오차 (기본값: 0.05)

        Returns:
            float: 정밀도 보상 [-1, 1]
                1.0 = 완벽한 정밀도
               -1.0 = 매우 부정확
        """
        expected = expected_vs_actual.get("expected", 0.0)
        actual = expected_vs_actual.get("actual", 0.0)
        tolerance = expected_vs_actual.get("tolerance", 0.05)

        # 넘파이 배열로 변환 / Convert to numpy arrays
        exp_arr = np.asarray(expected, dtype=np.float64).flatten()
        act_arr = np.asarray(actual, dtype=np.float64).flatten()

        # 크기 맞추기 / Match sizes
        min_len = min(len(exp_arr), len(act_arr))
        if min_len == 0:
            return 0.0
        exp_arr = exp_arr[:min_len]
        act_arr = act_arr[:min_len]

        # 평균 절대 오차 / Mean absolute error
        mae = float(np.mean(np.abs(exp_arr - act_arr)))

        # 허용 오차 내면 최대 보상 / Max reward if within tolerance
        if mae <= tolerance:
            reward = 1.0 - 0.5 * (mae / max(tolerance, EPS))
        else:
            # 허용 오차 초과: 지속적으로 감소 / Beyond tolerance: continuous decay
            reward = max(-1.0, 1.0 - 2.0 * (mae - tolerance) / max(tolerance, EPS))

        return float(np.clip(reward, R_MIN, R_MAX))

    # ── 에너지 효율 보상 / Energy Efficiency Reward ──────────────────────

    @staticmethod
    def energy_efficiency_reward(energy_used: float, task_value: float) -> float:
        """
        에너지 효율 보상 계산 / Compute energy efficiency reward.

        작업 가치 대비 에너지 소비의 효율성을 평가합니다.

        Args:
            energy_used: 소비된 에너지 (와트초 또는 임의 단위)
            task_value: 작업의 가치 (높을수록 중요한 작업)

        Returns:
            float: 에너지 효율 보상 [-1, 1]
                1.0 = 극히 효율적 (적은 에너지로 높은 가치)
               -1.0 = 극히 비효율적
        """
        if task_value <= 0.0:
            # 가치 없는 작업에 에너지 소비 = 비효율 / Spending energy on valueless task
            return -1.0 if energy_used > 0.0 else 0.0

        # 효율 비율 / Efficiency ratio
        # 이상적인 에너지 = task_value의 일정 비율 (0.1 단위)
        ideal_energy = max(task_value * 0.1, EPS)
        efficiency = ideal_energy / max(energy_used, EPS)

        # efficiency가 1.0이면 이상적, >1.0이면 매우 효율적, <1.0이면 비효율적
        # efficiency=1.0 -> reward=0.5, efficiency=2.0 -> reward=1.0
        # efficiency=0.5 -> reward=-0.5, efficiency=0.0 -> reward=-1.0
        reward = 2.0 * efficiency - 1.0

        return float(np.clip(reward, R_MIN, R_MAX))

    # ── 안정성 보상 / Stability Reward ──────────────────────────────────

    @staticmethod
    def stability_reward(balance_score: float, perturbation: float) -> float:
        """
        안정성 보상 계산 / Compute stability reward.

        균형 점수와 외란에 대한 내성을 기반으로 안정성을 평가합니다.

        Args:
            balance_score: 균형 점수 (0~1, 1=완벽한 균형)
            perturbation: 외란 크기 (0~1, 0=외란 없음)

        Returns:
            float: 안정성 보상 [-1, 1]
                1.0 = 완벽한 균형 + 외란 무시
               -1.0 = 완전 불안정
        """
        balance_score = float(np.clip(balance_score, 0.0, 1.0))
        perturbation = float(np.clip(perturbation, 0.0, 1.0))

        # 균형 점수를 [-1, 1]로 매핑 / Map balance to [-1, 1]
        balance_reward = 2.0 * balance_score - 1.0

        # 외란 내성: 외란이 큰데도 균형을 유지하면 추가 보상
        # Perturbation resilience: bonus for maintaining balance under perturbation
        if perturbation > 0.0:
            resilience_bonus = balance_score * perturbation * 0.3
        else:
            resilience_bonus = 0.0

        reward = balance_reward + resilience_bonus
        return float(np.clip(reward, R_MIN, R_MAX))

    # ── 시간 효율 보상 / Time Efficiency Reward ─────────────────────────

    @staticmethod
    def time_efficiency_reward(actual_time: float, expected_time: float) -> float:
        """
        시간 효율 보상 계산 / Compute time efficiency reward.

        예상 시간 대비 실제 소요 시간의 효율성을 평가합니다.

        Args:
            actual_time: 실제 소요 시간 (초)
            expected_time: 예상 소요 시간 (초)

        Returns:
            float: 시간 효율 보상 [-1, 1]
                1.0 = 예상보다 훨씬 빠름
                0.0 = 예상 시간과 동일
               -1.0 = 예상보다 훨씬 느림
        """
        if expected_time <= 0.0:
            return 0.0 if actual_time <= 0.0 else -1.0

        time_ratio = actual_time / expected_time

        # time_ratio=1.0 -> reward=0.0 (예상대로)
        # time_ratio=0.5 -> reward=1.0 (2배 빠름)
        # time_ratio=2.0 -> reward=-1.0 (2배 느림)
        if time_ratio <= 1.0:
            # 예상보다 빠름: 비례적 보상 / Faster than expected
            reward = 2.0 * (1.0 - time_ratio)
        else:
            # 예상보다 느림: 비례적 벌점 / Slower than expected
            reward = -min(1.0, (time_ratio - 1.0))

        return float(np.clip(reward, R_MIN, R_MAX))

    # ── 전체 보상 계산 / Compute All Components ─────────────────────────

    def compute_all(
        self,
        task_result: Dict[str, Any],
        expected_vs_actual: Dict[str, Any],
        energy_used: float,
        task_value: float,
        balance_score: float,
        perturbation: float,
        actual_time: float,
        expected_time: float,
    ) -> RewardComponents:
        """
        모든 보상 컴포넌트 계산 / Compute all reward components.

        Args:
            task_result: 작업 결과
            expected_vs_actual: 기대-실제 비교
            energy_used: 소비 에너지
            task_value: 작업 가치
            balance_score: 균형 점수
            perturbation: 외란 크기
            actual_time: 실제 소요 시간
            expected_time: 예상 소요 시간

        Returns:
            RewardComponents: 5개 보상 컴포넌트
        """
        components = RewardComponents(
            task_success=self.task_success_reward(task_result),
            precision=self.precision_reward(expected_vs_actual),
            energy_efficiency=self.energy_efficiency_reward(energy_used, task_value),
            stability=self.stability_reward(balance_score, perturbation),
            time_efficiency=self.time_efficiency_reward(actual_time, expected_time),
        )

        with self._lock:
            self._history.append(components)
            if len(self._history) > 1000:
                self._history = self._history[-1000:]

        logger.debug(
            "보상 계산 완료: 성공=%.3f, 정밀도=%.3f, 에너지=%.3f, "
            "안정성=%.3f, 시간=%.3f",
            components.task_success, components.precision,
            components.energy_efficiency, components.stability,
            components.time_efficiency,
        )

        return components

    def get_history(self, n: int = 100) -> List[RewardComponents]:
        """최근 N개 보상 히스토리 반환 / Return recent N reward history."""
        with self._lock:
            return self._history[-n:]

    def compute_pareto_front(
        self,
        history: Optional[List[RewardComponents]] = None,
    ) -> List[RewardComponents]:
        """
        파레토 프론티어 계산 / Compute Pareto front from reward history.

        다목적 보상에서 어느 한 목표도 희생하지 않고 개선할 수 없는
        해집합(파레토 최적)을 찾습니다.

        Args:
            history: 보상 히스토리 (None이면 내부 히스토리 사용)

        Returns:
            List[RewardComponents]: 파레토 최적 보상 컴포넌트 목록
        """
        if history is None:
            with self._lock:
                history = list(self._history)

        if len(history) < 2:
            return list(history)

        # 각 보상을 벡터로 변환 / Convert to vectors
        vectors = [h.to_vector() for h in history]
        n = len(vectors)

        pareto_indices: List[int] = []
        for i in range(n):
            dominated = False
            for j in range(n):
                if i == j:
                    continue
                # j가 i를 지배하는지 확인 / Check if j dominates i
                # j가 모든 컴포넌트에서 >= 이고 적어도 하나에서 > 이면 지배
                all_geq = all(vectors[j][k] >= vectors[i][k] for k in range(5))
                any_gt = any(vectors[j][k] > vectors[i][k] for k in range(5))
                if all_geq and any_gt:
                    dominated = True
                    break
            if not dominated:
                pareto_indices.append(i)

        pareto_front = [history[i] for i in pareto_indices]
        logger.info(
            "파레토 프론티어: %d/%d개 해가 비지배 / %d of %d solutions are non-dominated",
            len(pareto_front), n, len(pareto_front), n,
        )
        return pareto_front

    def compute_curriculum_reward(
        self,
        components: RewardComponents,
        curriculum_level: int = 1,
        weights: Optional[Dict[str, float]] = None,
    ) -> float:
        """
        커리큘럼 기반 보상 계산 / Compute curriculum-based reward.

        커리큘럼 레벨에 따라 보상 스케일이 다르게 적용됩니다.
        쉬운 작업(레벨 1-3)에서는 성공 보상이 강화되고,
        어려운 작업(레벨 7-10)에서는 정밀도와 효율이 강조됩니다.

        Args:
            components: 보상 컴포넌트
            curriculum_level: 커리큘럼 레벨 (1-10)
            weights: 기본 가중치 (None이면 DEFAULT_WEIGHTS)

        Returns:
            float: 커리큘럼 조정된 결합 보상
        """
        weights = weights or dict(DEFAULT_WEIGHTS)

        # 커리큘럼 스케일 결정 / Determine curriculum scale
        scale = CURRICULUM_SCHEDULE["easy"]["scales"]  # 기본값
        for tier_name, tier in CURRICULUM_SCHEDULE.items():
            lo, hi = tier["level_range"]
            if lo <= curriculum_level <= hi:
                scale = tier["scales"]
                break

        # 커리큘럼 가중치 적용 / Apply curriculum-scaled weights
        scaled_weights = {}
        for comp_name, base_weight in weights.items():
            scaled_weights[comp_name] = base_weight * scale.get(comp_name, 1.0)

        # 정규화 / Normalize
        total = sum(scaled_weights.values())
        if total > 0.0:
            for k in scaled_weights:
                scaled_weights[k] /= total

        # 결합 보상 계산 / Compute combined reward
        comp_dict = components.to_dict()
        combined = 0.0
        for comp_name, weight in scaled_weights.items():
            combined += weight * comp_dict.get(comp_name, 0.0)

        return float(np.clip(combined, R_MIN, R_MAX))


# ─── 적응형 보상 셰이퍼 / Adaptive Reward Shaper ────────────────────────────


class AdaptiveRewardShaper:
    """
    학습 진행 기반 적응형 보상 셰이퍼 / Learning-progress adaptive reward shaper.

    슬라이딩 윈도우로 보상을 추적하고, 정체(plateau)를 감지하여
    가장 약한 컴포넌트의 가중치를 자동으로 증가시킵니다.

    학습 초기에는 작업 성공에 집중하고, 성공률이 높아지면
    정밀도와 효율성으로 포커스를 이동합니다.

    Usage:
        shaper = AdaptiveRewardShaper()
        weights = shaper.update_and_get_weights(components)
        # 가중치가 자동으로 조정됨
    """

    def __init__(
        self,
        initial_weights: Optional[Dict[str, float]] = None,
        window_size: int = SHAPER_WINDOW,
        plateau_threshold: float = PLATEAU_THRESHOLD,
        plateau_patience: int = PLATEAU_PATIENCE,
        adaptation_rate: float = 0.05,
    ) -> None:
        self._weights = dict(initial_weights or DEFAULT_WEIGHTS)
        self._window_size = window_size
        self._plateau_threshold = plateau_threshold
        self._plateau_patience = plateau_patience
        self._adaptation_rate = adaptation_rate

        # 컴포넌트별 보상 히스토리 / Per-component reward history
        self._histories: Dict[str, Deque[float]] = {
            comp: deque(maxlen=window_size) for comp in REWARD_COMPONENTS
        }

        # 정체 카운터 / Plateau counter per component
        self._plateau_counters: Dict[str, int] = {
            comp: 0 for comp in REWARD_COMPONENTS
        }

        # 이전 평균 보상 / Previous mean rewards
        self._prev_means: Dict[str, float] = {
            comp: 0.0 for comp in REWARD_COMPONENTS
        }

        # 학습 진행 추적 / Learning progress tracking
        self._learning_progress: Dict[str, Deque[float]] = {
            comp: deque(maxlen=20) for comp in REWARD_COMPONENTS
        }
        self._total_adaptations: int = 0

        self._lock = threading.Lock()
        self._total_updates = 0

        logger.info(
            "AdaptiveRewardShaper 초기화: 윈도우=%d, 임계값=%.3f, 적응률=%.3f",
            window_size, plateau_threshold, adaptation_rate,
        )

    def update(self, components: RewardComponents) -> Dict[str, float]:
        """
        보상 컴포넌트로 셰이퍼 업데이트 / Update shaper with reward components.

        새로운 보상을 관찰하고 정체를 감지하여 가중치를 조정합니다.

        Args:
            components: 보상 컴포넌트

        Returns:
            Dict[str, float]: 업데이트된 가중치
        """
        with self._lock:
            comp_dict = components.to_dict()

            # 각 컴포넌트 히스토리 업데이트 / Update per-component history
            for comp_name, value in comp_dict.items():
                self._histories[comp_name].append(value)

            # 정체 감지 및 가중치 조정 / Detect plateaus and adjust weights
            self._detect_and_adjust()

            self._total_updates += 1

        return dict(self._weights)

    def _detect_and_adjust(self) -> None:
        """
        정체 감지, 학습 진행 측정, 가중치 조정 / Detect plateaus, measure learning progress, adjust weights.

        슬라이딩 윈도우 내에서 각 컴포넌트의 평균 보상 변화를 관찰합니다.
        변화가 임계값 미만이면 정체로 판단하고 해당 컴포넌트의
        가중치를 증가시킵니다. 또한 학습 진행 속도를 기반으로
        빠르게 개선되는 컴포넌트의 가중치를 감소시킵니다.
        """
        current_means: Dict[str, float] = {}
        learning_rates: Dict[str, float] = {}

        for comp in REWARD_COMPONENTS:
            history = self._histories[comp]
            if len(history) < 10:
                continue

            hist_list = list(history)
            current_mean = float(np.mean(hist_list))
            current_means[comp] = current_mean

            # 학습 진행 속도 = 최근 평균 - 이전 평균 / Learning rate = recent - previous
            prev_mean = self._prev_means[comp]
            delta = current_mean - prev_mean
            self._learning_progress[comp].append(delta)
            learning_rates[comp] = delta

            # 이전 평균과 비교 / Compare with previous mean
            if abs(delta) < self._plateau_threshold:
                self._plateau_counters[comp] += 1
            else:
                self._plateau_counters[comp] = 0

            self._prev_means[comp] = current_mean

        # ── 정체된 컴포넌트 부스트 / Boost plateaued component ──
        max_plateau_comp = max(
            self._plateau_counters, key=self._plateau_counters.get
        )
        max_plateau_count = self._plateau_counters[max_plateau_comp]

        if max_plateau_count >= self._plateau_patience:
            self._boost_component(max_plateau_comp)

        # ── 학습 진행 기반 가중치 조정 / Learning-progress-based adjustment ──
        # 빠르게 개선되는 컴포넌트는 가중치를 약간 감소시키고,
        # 정체된 컴포넌트에 그 비중을 이전합니다.
        if len(current_means) >= 3 and self._total_updates % 20 == 0:
            self._progress_based_adjustment(learning_rates)

    def _boost_component(self, component: str) -> None:
        """
        약한 컴포넌트의 가중치 증가 / Boost weight of weakest component.

        정체된 컴포넌트의 가중치를 증가시키고,
        다른 컴포넌트의 가중치를 비례적으로 감소시킵니다.

        Args:
            component: 가중치를 증가시킬 컴포넌트명
        """
        if component not in self._weights:
            return

        # 증가분 / Boost amount
        boost = self._adaptation_rate
        self._weights[component] += boost

        # 다른 컴포넌트에서 비례적으로 감소 / Proportionally decrease others
        other_comps = [c for c in REWARD_COMPONENTS if c != component]
        total_other = sum(self._weights.get(c, 0.0) for c in other_comps)

        if total_other > 0.0:
            for c in other_comps:
                reduction = boost * (self._weights.get(c, 0.0) / total_other)
                self._weights[c] = max(0.01, self._weights.get(c, 0.0) - reduction)

        # 정규화: 가중치 합 = 1.0 / Normalize weights to sum to 1.0
        total = sum(self._weights.values())
        if total > 0.0:
            for c in self._weights:
                self._weights[c] /= total

        # 정체 카운터 리셋 / Reset plateau counter
        self._plateau_counters[component] = 0
        self._total_adaptations += 1

        logger.info(
            "가중치 적응: %s 부스트 → 가중치=%s",
            component,
            {k: round(v, 3) for k, v in self._weights.items()},
        )

    def _progress_based_adjustment(self, learning_rates: Dict[str, float]) -> None:
        """
        학습 진행 속도에 따른 가중치 미세 조정 / Fine-tune weights based on learning progress.

        빠르게 개선되는 컴포넌트는 이미 충분히 학습되고 있으므로
        가중치를 약간 감소시키고, 정체된 컴포넌트에 비중을 이전합니다.

        Args:
            learning_rates: 컴포넌트별 학습 진행 속도
        """
        if not learning_rates:
            return

        # 학습 진행 속도 순위 / Rank by learning progress
        sorted_comps = sorted(learning_rates.items(), key=lambda x: x[1], reverse=True)

        # 가장 빠르게 개선되는 컴포넌트에서 가장 느린 컴포넌트로 약간 이전
        if len(sorted_comps) >= 2:
            best_comp, _ = sorted_comps[0]
            worst_comp, _ = sorted_comps[-1]

            # 미세 조정 (0.01) / Small adjustment
            micro_adjust = 0.01
            if self._weights.get(best_comp, 0.0) > 0.05:
                self._weights[best_comp] = self._weights.get(best_comp, 0.0) - micro_adjust
                self._weights[worst_comp] = self._weights.get(worst_comp, 0.0) + micro_adjust

                # 정규화 / Normalize
                total = sum(self._weights.values())
                if total > 0.0:
                    for c in self._weights:
                        self._weights[c] /= total

                logger.debug(
                    "진행 기반 조정: %s(-%.3f) → %s(+%.3f)",
                    best_comp, micro_adjust, worst_comp, micro_adjust,
                )

    def get_weights(self) -> Dict[str, float]:
        """현재 가중치 반환 / Return current weights."""
        with self._lock:
            return dict(self._weights)

    def get_plateau_status(self) -> Dict[str, int]:
        """정체 상태 반환 / Return plateau status."""
        with self._lock:
            return dict(self._plateau_counters)

    def get_learning_progress(self) -> Dict[str, float]:
        """컴포넌트별 평균 학습 진행 속도 반환 / Return per-component mean learning progress."""
        with self._lock:
            progress = {}
            for comp, prog_hist in self._learning_progress.items():
                if len(prog_hist) > 0:
                    progress[comp] = float(np.mean(list(prog_hist)))
                else:
                    progress[comp] = 0.0
            return progress

    def get_adaptation_count(self) -> int:
        """총 적응 횟수 반환 / Return total adaptation count."""
        with self._lock:
            return self._total_adaptations


# ─── 보상 정규화기 / Reward Normalizer ───────────────────────────────────────


class RewardNormalizer:
    """
    실행 z-score 정규화기 / Running z-score reward normalizer.

    각 보상 컴포넌트에 대해 실행 평균과 분산을 유지하고
    z-score 정규화를 수행합니다. 이는 보상 스케일이 다른
    컴포넌트 간의 균형을 맞추는 데 필수적입니다.

    Welford의 온라인 알고리즘을 사용하여 메모리 효율적으로
    평균과 분산을 업데이트합니다.

    Usage:
        normalizer = RewardNormalizer()
        normalized = normalizer.normalize(components)
    """

    def __init__(
        self,
        components: Optional[List[str]] = None,
        clip_range: float = 5.0,
        min_count: int = 30,
    ) -> None:
        self._components = components or REWARD_COMPONENTS
        self._clip_range = clip_range
        self._min_count = min_count

        # Welford 온라인 통계 / Welford online statistics
        self._count: Dict[str, int] = {c: 0 for c in self._components}
        self._mean: Dict[str, float] = {c: 0.0 for c in self._components}
        self._m2: Dict[str, float] = {c: 0.0 for c in self._components}

        self._lock = threading.Lock()
        logger.info(
            "RewardNormalizer 초기화: %d개 컴포넌트, 클립=%.1f",
            len(self._components), clip_range,
        )

    def update(self, component_name: str, value: float) -> None:
        """
        Welford 알고리즘으로 통계 업데이트 / Update statistics with Welford algorithm.

        Args:
            component_name: 컴포넌트명
            value: 관측값
        """
        with self._lock:
            if component_name not in self._count:
                return

            self._count[component_name] += 1
            n = self._count[component_name]
            delta = value - self._mean[component_name]
            self._mean[component_name] += delta / n
            delta2 = value - self._mean[component_name]
            self._m2[component_name] += delta * delta2

    def normalize(self, components: RewardComponents) -> RewardComponents:
        """
        보상 컴포넌트 정규화 / Normalize reward components.

        z-score 정규화 후 [-clip_range, clip_range]로 클리핑하고
        [-1, 1]로 다시 매핑합니다.

        Args:
            components: 원본 보상 컴포넌트

        Returns:
            RewardComponents: 정규화된 보상 컴포넌트
        """
        comp_dict = components.to_dict()
        normalized = {}

        for comp_name, value in comp_dict.items():
            self.update(comp_name, value)

            with self._lock:
                n = self._count.get(comp_name, 0)
                if n < self._min_count:
                    # 샘플 부족: 원래 값 사용 / Not enough samples: use original
                    normalized[comp_name] = value
                    continue

                mean = self._mean.get(comp_name, 0.0)
                variance = self._m2.get(comp_name, 1.0) / max(n, 1)
                std = math.sqrt(max(variance, EPS))

            # z-score 계산 / Compute z-score
            z = (value - mean) / std

            # 클리핑 후 [-1, 1] 매핑 / Clip then map to [-1, 1]
            z_clipped = np.clip(z, -self._clip_range, self._clip_range)
            normalized[comp_name] = float(z_clipped / self._clip_range)

        return RewardComponents(
            task_success=normalized.get("task_success", 0.0),
            precision=normalized.get("precision", 0.0),
            energy_efficiency=normalized.get("energy_efficiency", 0.0),
            stability=normalized.get("stability", 0.0),
            time_efficiency=normalized.get("time_efficiency", 0.0),
            metadata=components.metadata,
            timestamp=components.timestamp,
        )

    def get_statistics(self) -> Dict[str, Dict[str, float]]:
        """현재 통계 반환 / Return current statistics."""
        with self._lock:
            stats = {}
            for comp in self._components:
                n = self._count.get(comp, 0)
                mean = self._mean.get(comp, 0.0)
                variance = self._m2.get(comp, 1.0) / max(n, 1)
                stats[comp] = {
                    "count": n,
                    "mean": mean,
                    "std": math.sqrt(max(variance, EPS)),
                }
            return stats


# ─── 결합 보상 함수 / Combined Reward Function ──────────────────────────────


def compute_combined_reward(
    experience: Dict[str, Any],
    weights: Optional[Dict[str, float]] = None,
    calculator: Optional[PhysicalRewardCalculator] = None,
    normalizer: Optional[RewardNormalizer] = None,
) -> Tuple[float, RewardComponents]:
    """
    가중 결합 보상 계산 / Compute weighted combined reward.

    경험 데이터에서 5개 보상 컴포넌트를 계산하고,
    가중합으로 결합 보상을 산출합니다.

    Args:
        experience: 물리적 경험 딕셔너리
            - task_result: 작업 결과
            - expected_vs_actual: 기대-실제 비교
            - energy_used: 소비 에너지
            - task_value: 작업 가치
            - balance_score: 균형 점수
            - perturbation: 외란 크기
            - actual_time: 실제 소요 시간
            - expected_time: 예상 소요 시간
        weights: 컴포넌트 가중치 (기본값: DEFAULT_WEIGHTS)
        calculator: 보상 계산기 (기본값: 새로 생성)
        normalizer: 보상 정규화기 (선택)

    Returns:
        Tuple[float, RewardComponents]: (결합 보상, 보상 컴포넌트)
    """
    weights = weights or dict(DEFAULT_WEIGHTS)
    calculator = calculator or PhysicalRewardCalculator()

    # 보상 컴포넌트 계산 / Compute reward components
    components = calculator.compute_all(
        task_result=experience.get("task_result", {}),
        expected_vs_actual=experience.get("expected_vs_actual", {}),
        energy_used=experience.get("energy_used", 0.0),
        task_value=experience.get("task_value", 1.0),
        balance_score=experience.get("balance_score", 0.5),
        perturbation=experience.get("perturbation", 0.0),
        actual_time=experience.get("actual_time", 1.0),
        expected_time=experience.get("expected_time", 1.0),
    )

    # 정규화 (선택) / Optional normalization
    if normalizer is not None:
        components = normalizer.normalize(components)

    # 가중합 / Weighted sum
    comp_dict = components.to_dict()
    combined = 0.0
    for comp_name, weight in weights.items():
        combined += weight * comp_dict.get(comp_name, 0.0)

    # 결합 보상 클램핑 / Clamp combined reward
    combined = float(np.clip(combined, R_MIN, R_MAX))

    logger.debug(
        "결합 보상: %.3f (가중치: %s)",
        combined,
        {k: round(v, 2) for k, v in weights.items()},
    )

    return combined, components


# ─── 모듈 진입점 / Module Entry Point ───────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)

    print("=" * 60)
    print("보상 함수 라이브러리 테스트 / Reward Functions Library Test")
    print("=" * 60)

    calc = PhysicalRewardCalculator()

    # 테스트 1: 성공적인 작업 / Test 1: Successful task
    success_exp = {
        "task_result": {"success": True},
        "expected_vs_actual": {
            "expected": [1.0, 0.0, 0.5],
            "actual": [1.01, 0.01, 0.49],
            "tolerance": 0.05,
        },
        "energy_used": 0.3,
        "task_value": 1.0,
        "balance_score": 0.95,
        "perturbation": 0.05,
        "actual_time": 2.8,
        "expected_time": 3.0,
    }

    combined, comps = compute_combined_reward(success_exp)
    print(f"\n성공 작업 / Successful task:")
    print(f"  컴포넌트: {comps.to_dict()}")
    print(f"  결합 보상: {combined:.3f}")

    # 테스트 2: 실패한 작업 / Test 2: Failed task
    fail_exp = {
        "task_result": {"success": False, "failure_severity": 0.8},
        "expected_vs_actual": {
            "expected": [1.0, 0.0],
            "actual": [0.3, 0.7],
            "tolerance": 0.05,
        },
        "energy_used": 1.5,
        "task_value": 0.5,
        "balance_score": 0.2,
        "perturbation": 0.6,
        "actual_time": 8.0,
        "expected_time": 3.0,
    }

    combined2, comps2 = compute_combined_reward(fail_exp)
    print(f"\n실패 작업 / Failed task:")
    print(f"  컴포넌트: {comps2.to_dict()}")
    print(f"  결합 보상: {combined2:.3f}")

    # 테스트 3: 적응형 셰이퍼 / Test 3: Adaptive shaper
    print("\n적응형 보상 셰이퍼 테스트 / Adaptive Reward Shaper Test")
    shaper = AdaptiveRewardShaper()
    for i in range(50):
        # 정체된 보상 시뮬레이션 / Simulate plateauing rewards
        plateau_comp = RewardComponents(
            task_success=0.5,  # 정체됨 / Plateaued
            precision=0.5,
            energy_efficiency=0.5 + i * 0.001,
            stability=0.5,
            time_efficiency=0.5 + i * 0.002,
        )
        weights = shaper.update(plateau_comp)

    print(f"  50회 업데이트 후 가중치: {weights}")
    print(f"  정체 상태: {shaper.get_plateau_status()}")

    # 테스트 4: 정규화기 / Test 4: Normalizer
    print("\n보상 정규화기 테스트 / Reward Normalizer Test")
    norm = RewardNormalizer(min_count=10)
    rng = np.random.RandomState(42)
    for _ in range(50):
        rc = RewardComponents(
            task_success=float(rng.normal(0.6, 0.2)),
            precision=float(rng.normal(0.4, 0.3)),
            energy_efficiency=float(rng.normal(0.3, 0.15)),
            stability=float(rng.normal(0.7, 0.1)),
            time_efficiency=float(rng.normal(0.5, 0.25)),
        )
        normalized = norm.normalize(rc)

    print(f"  정규화 통계: {norm.get_statistics()}")
    print("\n모든 테스트 완료 / All tests completed.")
