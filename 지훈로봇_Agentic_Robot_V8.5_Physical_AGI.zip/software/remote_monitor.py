#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 원격 모니터링 시스템
======================================

ESP32-S3 WiFi AP 모드 → 스마트폰 웹 대시보드
WebSocket 실시간 업데이트 + RESTful API 상태 조회

TODO 52: remote_monitor.py

하드웨어:
  - ESP32-S3 WiFi AP 모드 (WPA2 보안)
  - 접속 기기 1대 제한
  - WebSocket 실시간 데이터 스트리밍
  - RESTful API 상태 조회

기능:
  - 배터리, 온도, 모드, 센서 상태, AI 응답 표시
  - WPA2 보안, 1대 접속 제한
  - 반응형 웹 대시보드

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

# 웹 서버 (ESP32 마이크로파이썬 또는 Jetson Python)
try:
    from aiohttp import web, WSMsgType
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

logger = logging.getLogger(__name__)


# ============================================================================
# 상수 및 열거형
# ============================================================================

class ConnectionType(Enum):
    """연결 타입"""
    WEBSOCKET = "websocket"
    HTTP = "http"


# 서버 설정
DEFAULT_AP_SSID = "JihunRobot-V7"
DEFAULT_AP_PASSWORD = "jihun2026"   # WPA2 최소 8자
DEFAULT_PORT = 8080
MAX_CLIENTS = 1                      # 동시 접속 1대 제한
WEBSOCKET_PING_INTERVAL_S = 30.0
DATA_STREAM_INTERVAL_MS = 500        # 데이터 스트리밍 주기 (500ms)
SESSION_TIMEOUT_S = 300.0            # 세션 타임아웃 (5분)


# ============================================================================
# 데이터 클래스
# ============================================================================

@dataclass
class RobotStatus:
    """로봇 상태 데이터 — 대시보드에 표시되는 모든 정보"""
    # 배터리
    battery_voltage_v: float = 12.8
    battery_soc_percent: float = 50.0
    battery_current_a: float = 0.0
    battery_charging: bool = False

    # 온도
    jetson1_temp_c: float = 45.0
    jetson2_temp_c: float = 42.0
    motor_temp_c: float = 35.0

    # 동작 모드
    robot_mode: str = "standby"
    led_color: str = "blue"

    # 센서 상태
    lidar_ok: bool = True
    camera_ok: bool = True
    imu_ok: bool = True
    tof_front_ok: bool = True
    tof_rear_ok: bool = True

    # AI 상태
    ai_model_loaded: bool = False
    ai_last_response: str = ""
    ai_inference_time_ms: float = 0.0

    # 네비게이션
    position_x: float = 0.0
    position_y: float = 0.0
    heading_deg: float = 0.0
    target_distance_m: float = 0.0

    # 안전
    safety_level: str = "normal"
    estop_active: bool = False

    # 그리퍼
    gripper_state: str = "open"
    grasp_force_n: float = 0.0

    # 시스템
    uptime_s: float = 0.0
    cpu_usage_pct: float = 0.0
    ram_usage_pct: float = 0.0
    wifi_clients: int = 0

    # 타임스탬프
    timestamp: float = 0.0

    def __post_init__(self):
        if self.timestamp == 0.0:
            self.timestamp = time.time()

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 (JSON 직렬화용)"""
        return {
            "battery": {
                "voltage_v": self.battery_voltage_v,
                "soc_percent": self.battery_soc_percent,
                "current_a": self.battery_current_a,
                "charging": self.battery_charging,
            },
            "temperature": {
                "jetson1_c": self.jetson1_temp_c,
                "jetson2_c": self.jetson2_temp_c,
                "motor_c": self.motor_temp_c,
            },
            "mode": {
                "robot": self.robot_mode,
                "led_color": self.led_color,
            },
            "sensors": {
                "lidar": self.lidar_ok,
                "camera": self.camera_ok,
                "imu": self.imu_ok,
                "tof_front": self.tof_front_ok,
                "tof_rear": self.tof_rear_ok,
            },
            "ai": {
                "model_loaded": self.ai_model_loaded,
                "last_response": self.ai_last_response,
                "inference_ms": self.ai_inference_time_ms,
            },
            "navigation": {
                "x": self.position_x,
                "y": self.position_y,
                "heading_deg": self.heading_deg,
                "target_dist_m": self.target_distance_m,
            },
            "safety": {
                "level": self.safety_level,
                "estop": self.estop_active,
            },
            "gripper": {
                "state": self.gripper_state,
                "force_n": self.grasp_force_n,
            },
            "system": {
                "uptime_s": self.uptime_s,
                "cpu_pct": self.cpu_usage_pct,
                "ram_pct": self.ram_usage_pct,
                "wifi_clients": self.wifi_clients,
            },
            "timestamp": self.timestamp,
        }


# ============================================================================
# 웹 대시보드 HTML (인라인)
# ============================================================================

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>지훈 로봇 V8.5 대시보드</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, sans-serif; background: #1a1a2e; color: #eee; padding: 16px; }
  h1 { text-align: center; color: #e94560; margin-bottom: 16px; font-size: 1.5rem; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 12px; }
  .card { background: #16213e; border-radius: 12px; padding: 16px; border: 1px solid #0f3460; }
  .card h2 { font-size: 0.9rem; color: #e94560; margin-bottom: 8px; text-transform: uppercase; }
  .row { display: flex; justify-content: space-between; padding: 4px 0; font-size: 0.85rem; }
  .row .label { color: #888; }
  .row .value { font-weight: bold; }
  .status-ok { color: #4ecca3; }
  .status-warn { color: #ffc107; }
  .status-error { color: #e94560; }
  .battery-bar { height: 20px; background: #333; border-radius: 10px; overflow: hidden; margin-top: 8px; }
  .battery-fill { height: 100%; transition: width 0.5s; border-radius: 10px; }
  .connected { color: #4ecca3; }
  .disconnected { color: #e94560; }
  #conn-status { text-align: center; font-size: 0.8rem; margin-bottom: 12px; }
</style>
</head>
<body>
<h1>🤖 지훈 로봇 V7</h1>
<div id="conn-status" class="disconnected">연결 끊김</div>
<div class="grid" id="dashboard">
  <div class="card">
    <h2>🔋 배터리</h2>
    <div class="row"><span class="label">전압</span><span class="value" id="batt-v">--</span></div>
    <div class="row"><span class="label">잔량</span><span class="value" id="batt-soc">--</span></div>
    <div class="row"><span class="label">전류</span><span class="value" id="batt-a">--</span></div>
    <div class="row"><span class="label">충전</span><span class="value" id="batt-chg">--</span></div>
    <div class="battery-bar"><div class="battery-fill" id="batt-bar" style="width:50%;background:#4ecca3"></div></div>
  </div>
  <div class="card">
    <h2>🌡️ 온도</h2>
    <div class="row"><span class="label">Jetson #1</span><span class="value" id="temp-j1">--</span></div>
    <div class="row"><span class="label">Jetson #2</span><span class="value" id="temp-j2">--</span></div>
    <div class="row"><span class="label">모터</span><span class="value" id="temp-m">--</span></div>
  </div>
  <div class="card">
    <h2>🎮 모드</h2>
    <div class="row"><span class="label">동작 모드</span><span class="value" id="mode-robot">--</span></div>
    <div class="row"><span class="label">LED</span><span class="value" id="mode-led">--</span></div>
  </div>
  <div class="card">
    <h2>📡 센서</h2>
    <div class="row"><span class="label">LiDAR</span><span class="value" id="s-lidar">--</span></div>
    <div class="row"><span class="label">카메라</span><span class="value" id="s-cam">--</span></div>
    <div class="row"><span class="label">IMU</span><span class="value" id="s-imu">--</span></div>
    <div class="row"><span class="label">ToF 전방</span><span class="value" id="s-tof-f">--</span></div>
    <div class="row"><span class="label">ToF 후방</span><span class="value" id="s-tof-r">--</span></div>
  </div>
  <div class="card">
    <h2>🧠 AI</h2>
    <div class="row"><span class="label">모델</span><span class="value" id="ai-model">--</span></div>
    <div class="row"><span class="label">추론 시간</span><span class="value" id="ai-time">--</span></div>
    <div class="row"><span class="label">마지막 응답</span><span class="value" id="ai-resp" style="font-size:0.7rem">--</span></div>
  </div>
  <div class="card">
    <h2>⚠️ 안전</h2>
    <div class="row"><span class="label">안전 등급</span><span class="value" id="saf-level">--</span></div>
    <div class="row"><span class="label">E-Stop</span><span class="value" id="saf-estop">--</span></div>
  </div>
</div>
<script>
const ws = new WebSocket('ws://' + location.host + '/ws');
ws.onopen = () => { document.getElementById('conn-status').className='connected'; document.getElementById('conn-status').textContent='연결됨'; };
ws.onclose = () => { document.getElementById('conn-status').className='disconnected'; document.getElementById('conn-status').textContent='연결 끊김'; };
ws.onmessage = (e) => {
  const d = JSON.parse(e.data);
  document.getElementById('batt-v').textContent = d.battery.voltage_v.toFixed(1) + 'V';
  document.getElementById('batt-soc').textContent = d.battery.soc_percent.toFixed(0) + '%';
  document.getElementById('batt-a').textContent = d.battery.current_a.toFixed(2) + 'A';
  document.getElementById('batt-chg').textContent = d.battery.charging ? '충전중' : '방전';
  const bar = document.getElementById('batt-bar');
  bar.style.width = d.battery.soc_percent + '%';
  bar.style.background = d.battery.soc_percent > 30 ? '#4ecca3' : d.battery.soc_percent > 15 ? '#ffc107' : '#e94560';
  document.getElementById('temp-j1').textContent = d.temperature.jetson1_c.toFixed(1) + '°C';
  document.getElementById('temp-j2').textContent = d.temperature.jetson2_c.toFixed(1) + '°C';
  document.getElementById('temp-m').textContent = d.temperature.motor_c.toFixed(1) + '°C';
  document.getElementById('mode-robot').textContent = d.mode.robot;
  document.getElementById('mode-led').textContent = d.mode.led_color;
  const ok = v => v ? '<span class="status-ok">정상</span>' : '<span class="status-error">오류</span>';
  document.getElementById('s-lidar').innerHTML = ok(d.sensors.lidar);
  document.getElementById('s-cam').innerHTML = ok(d.sensors.camera);
  document.getElementById('s-imu').innerHTML = ok(d.sensors.imu);
  document.getElementById('s-tof-f').innerHTML = ok(d.sensors.tof_front);
  document.getElementById('s-tof-r').innerHTML = ok(d.sensors.tof_rear);
  document.getElementById('ai-model').innerHTML = d.ai.model_loaded ? '<span class="status-ok">로드됨</span>' : '<span class="status-warn">미로드</span>';
  document.getElementById('ai-time').textContent = d.ai.inference_ms.toFixed(0) + 'ms';
  document.getElementById('ai-resp').textContent = d.ai.last_response.substring(0, 50);
  document.getElementById('saf-level').textContent = d.safety.level;
  document.getElementById('saf-estop').innerHTML = d.safety.estop ? '<span class="status-error">활성</span>' : '<span class="status-ok">비활성</span>';
};
</script>
</body>
</html>"""


# ============================================================================
# 메인 클래스: RemoteMonitor
# ============================================================================

class RemoteMonitor:
    """
    지훈 로봇 V8.5 — 원격 모니터링 시스템

    ESP32-S3 WiFi AP → 스마트폰 웹 대시보드
    - WebSocket 실시간 데이터 스트리밍
    - RESTful API 상태 조회
    - WPA2 보안, 1대 접속 제한
    - 반응형 웹 UI
    """

    def __init__(
        self,
        ssid: str = DEFAULT_AP_SSID,
        password: str = DEFAULT_AP_PASSWORD,
        port: int = DEFAULT_PORT,
        max_clients: int = MAX_CLIENTS,
    ):
        self._ssid = ssid
        self._password = password
        self._port = port
        self._max_clients = max_clients

        # 로봇 상태
        self._robot_status = RobotStatus()

        # WebSocket 클라이언트
        self._ws_clients: List[Any] = []
        self._ws_lock = asyncio.Lock() if AIOHTTP_AVAILABLE else None

        # 서버 상태
        self._running = False
        self._server_task: Optional[asyncio.Task] = None
        self._stream_task: Optional[asyncio.Task] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # 상태 업데이트 콜백
        self._status_callbacks: List[Callable[[], RobotStatus]] = []

        # REST API 핸들러
        self._api_handlers: Dict[str, Callable] = {}

        logger.info("RemoteMonitor 인스턴스 생성 (SSID=%s, port=%d)", ssid, port)

    # --- 서버 시작/종료 ---

    def start_server(self) -> bool:
        """
        웹 서버 시작 (비동기)

        Returns:
            서버 시작 성공 여부
        """
        if not AIOHTTP_AVAILABLE:
            logger.error("aiohttp 미설치 — 웹 서버 시작 불가")
            return False

        try:
            self._running = True
            # 별도 스레드에서 asyncio 이벤트 루프 실행
            thread = threading.Thread(target=self._run_server, daemon=True,
                                      name="RemoteMonitor-Server")
            thread.start()
            logger.info("원격 모니터링 서버 시작 (http://0.0.0.0:%d)", self._port)
            return True
        except Exception as e:
            logger.error("서버 시작 실패: %s", e)
            return False

    def stop_server(self) -> None:
        """웹 서버 종료"""
        self._running = False
        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(self._shutdown(), self._loop)
        logger.info("원격 모니터링 서버 종료")

    def _run_server(self) -> None:
        """비동기 서버 실행 (별도 스레드)"""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._async_start())
        except Exception as e:
            logger.error("서버 루프 오류: %s", e)

    async def _async_start(self) -> None:
        """aiohttp 앱 시작"""
        app = web.Application()

        # 라우팅
        app.router.add_get("/", self._handle_dashboard)
        app.router.add_get("/ws", self._handle_websocket)
        app.router.add_get("/api/status", self._handle_api_status)
        app.router.add_get("/api/battery", self._handle_api_battery)
        app.router.add_get("/api/sensors", self._handle_api_sensors)
        app.router.add_get("/api/safety", self._handle_api_safety)

        # 커스텀 API 핸들러 등록
        for path, handler in self._api_handlers.items():
            app.router.add_get(f"/api/{path}", handler)

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", self._port)
        await site.start()

        # 데이터 스트리밍 태스크 시작
        self._stream_task = asyncio.create_task(self._stream_data())

        # 서버 실행 유지
        while self._running:
            await asyncio.sleep(1.0)

        await runner.cleanup()

    async def _shutdown(self) -> None:
        """서버 종료"""
        self._running = False
        if self._stream_task:
            self._stream_task.cancel()

    # --- HTTP 핸들러 ---

    async def _handle_dashboard(self, request: Any) -> Any:
        """대시보드 HTML 제공"""
        return web.Response(text=DASHBOARD_HTML, content_type="text/html")

    async def _handle_api_status(self, request: Any) -> Any:
        """전체 상태 API"""
        self._update_status_from_callbacks()
        return web.json_response(self._robot_status.to_dict())

    async def _handle_api_battery(self, request: Any) -> Any:
        """배터리 상태 API"""
        self._update_status_from_callbacks()
        return web.json_response(self._robot_status.to_dict()["battery"])

    async def _handle_api_sensors(self, request: Any) -> Any:
        """센서 상태 API"""
        self._update_status_from_callbacks()
        return web.json_response(self._robot_status.to_dict()["sensors"])

    async def _handle_api_safety(self, request: Any) -> Any:
        """안전 상태 API"""
        self._update_status_from_callbacks()
        return web.json_response(self._robot_status.to_dict()["safety"])

    # --- WebSocket 핸들러 ---

    async def _handle_websocket(self, request: Any) -> Any:
        """WebSocket 연결 처리"""
        ws = web.WebSocketResponse()
        await ws.prepare(request)

        # 접속 제한 확인
        async with self._ws_lock:
            if len(self._ws_clients) >= self._max_clients:
                await ws.send_json({"error": "최대 접속 수 초과", "max_clients": self._max_clients})
                await ws.close()
                return ws
            self._ws_clients.append(ws)

        client_ip = request.remote
        logger.info("WebSocket 클라이언트 접속: %s (현재 %d명)", client_ip, len(self._ws_clients))
        self._robot_status.wifi_clients = len(self._ws_clients)

        try:
            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    # 클라이언트 명령 처리
                    try:
                        data = json.loads(msg.data)
                        await self._handle_client_command(ws, data)
                    except json.JSONDecodeError:
                        await ws.send_json({"error": "잘못된 JSON"})
                elif msg.type == WSMsgType.ERROR:
                    logger.error("WebSocket 오류: %s", ws.exception())
        finally:
            async with self._ws_lock:
                if ws in self._ws_clients:
                    self._ws_clients.remove(ws)
            self._robot_status.wifi_clients = len(self._ws_clients)
            logger.info("WebSocket 클라이언트 접속 해제: %s", client_ip)

        return ws

    async def _handle_client_command(self, ws: Any, data: Dict) -> None:
        """클라이언트 명령 처리"""
        cmd = data.get("command", "")
        if cmd == "ping":
            await ws.send_json({"command": "pong", "timestamp": time.time()})
        elif cmd == "get_status":
            self._update_status_from_callbacks()
            await ws.send_json(self._robot_status.to_dict())
        elif cmd == "estop":
            logger.warning("원격 E-Stop 명령 수신!")
            # 실제 E-Stop은 안전 시스템으로 전달
            await ws.send_json({"command": "estop", "result": "activated"})
        else:
            await ws.send_json({"error": f"알 수 없는 명령: {cmd}"})

    # --- 데이터 스트리밍 ---

    async def _stream_data(self) -> None:
        """WebSocket으로 실시간 데이터 스트리밍"""
        while self._running:
            self._update_status_from_callbacks()
            status_json = self._robot_status.to_dict()

            # 모든 WebSocket 클라이언트에 브로드캐스트
            async with self._ws_lock:
                disconnected = []
                for ws in self._ws_clients:
                    try:
                        await ws.send_json(status_json)
                    except Exception:
                        disconnected.append(ws)
                for ws in disconnected:
                    self._ws_clients.remove(ws)

            await asyncio.sleep(DATA_STREAM_INTERVAL_MS / 1000.0)

    def _update_status_from_callbacks(self) -> None:
        """콜백에서 최신 로봇 상태 업데이트"""
        for callback in self._status_callbacks:
            try:
                updated = callback()
                if isinstance(updated, RobotStatus):
                    self._robot_status = updated
            except Exception as e:
                logger.error("상태 콜백 오류: %s", e)

    # --- 공개 메서드 ---

    def get_status(self) -> RobotStatus:
        """현재 로봇 상태 반환"""
        return self._robot_status

    def update_status(self, status: RobotStatus) -> None:
        """로봇 상태 업데이트 (외부에서 호출)"""
        self._robot_status = status

    def stream_data(self, data: Dict[str, Any]) -> None:
        """
        커스텀 데이터 스트리밍

        Args:
            data: 스트리밍할 데이터 딕셔너리
        """
        # 다음 스트리밍 주기에 포함됨
        for key, value in data.items():
            if hasattr(self._robot_status, key):
                setattr(self._robot_status, key, value)

    def handle_client(self, path: str, handler: Callable) -> None:
        """
        커스텀 REST API 핸들러 등록

        Args:
            path: API 경로 (/api/ 제외)
            handler: 비동기 핸들러 함수
        """
        self._api_handlers[path] = handler
        logger.info("API 핸들러 등록: /api/%s", path)

    def register_status_callback(self, callback: Callable[[], RobotStatus]) -> None:
        """
        상태 업데이트 콜백 등록

        Args:
            callback: RobotStatus를 반환하는 콜백 함수
        """
        self._status_callbacks.append(callback)

    def get_server_info(self) -> Dict:
        """서버 정보 반환"""
        return {
            "ssid": self._ssid,
            "port": self._port,
            "max_clients": self._max_clients,
            "connected_clients": len(self._ws_clients),
            "running": self._running,
        }


# ============================================================================
# 메인 진입점 (단독 테스트용)
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    monitor = RemoteMonitor()
    if monitor.start_server():
        print(f"=== 원격 모니터링 서버 테스트 ===")
        print(f"SSID: {monitor._ssid}")
        print(f"URL: http://localhost:{monitor._port}")
        print(f"WebSocket: ws://localhost:{monitor._port}/ws")
        print(f"API: http://localhost:{monitor._port}/api/status")

        # 상태 업데이트 시뮬레이션
        print("\n10초간 상태 업데이트 시뮬레이션...")
        for i in range(20):
            status = RobotStatus(
                battery_soc_percent=max(0, 80 - i * 2),
                jetson1_temp_c=45 + i * 0.5,
                robot_mode="autonomous" if i % 3 == 0 else "standby",
                ai_last_response=f"테스트 응답 {i}",
            )
            monitor.update_status(status)
            time.sleep(0.5)

        print(f"\n서버 정보: {monitor.get_server_info()}")
        monitor.stop_server()
        print("테스트 완료")
    else:
        print("서버 시작 실패 — aiohttp 설치 필요")
