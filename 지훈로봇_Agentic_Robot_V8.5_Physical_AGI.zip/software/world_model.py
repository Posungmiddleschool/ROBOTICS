#!/usr/bin/env python3
"""
지훈 로봇 V8.5 - 물리적 세계 모델
Jihun Robot V8.5 - Physical World Model

TODO 18: 물리적 세계 모델 (Physical AGI 핵심)
로봇이 물리적 상호작용의 결과를 예측하는 세계 모델입니다.
사족보행 시 균형, 지형 횡단 시 미끄러짐, 파지 시 파손/슬립,
공예 시 정밀도 등 물리적 결과를 예측합니다.

핵심 원칙:
    WORLD DATA = 물리적 경험. 웹 크롤링이 아님.
    로봇은 직접 물리적으로 행동하면서 세계를 배웁니다.

하드웨어: Dual Jetson Orin NX 16GB
AI 모델: Gemma 4 E4B Q4_K_M
작성일: 2026-05-19
버전: V8.5.4 — Physical AGI 재설계
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple, Union

import numpy as np

# ─── PyTorch 가용성 / PyTorch Availability ──────────────────────────────────

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.optim import AdamW
    from torch.optim.lr_scheduler import CosineAnnealingLR
    _HAS_TORCH = True
except ImportError:
    torch = None  # type: ignore[assignment]
    nn = None  # type: ignore[assignment]
    F = None  # type: ignore[assignment]
    AdamW = None  # type: ignore[assignment]
    CosineAnnealingLR = None  # type: ignore[assignment]
    _HAS_TORCH = False

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.physical_world_model")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 열거형 / Enums ─────────────────────────────────────────────────────────


class TerrainType(str, Enum):
    """지형 유형 / Terrain types."""
    FLAT = "flat"
    ROUGH = "rough"
    SLOPE = "slope"
    STAIRS = "stairs"
    WET = "wet"
    GRAVEL = "gravel"
    SAND = "sand"
    NARROW = "narrow"
    UNEVEN = "uneven"
    CARPET = "carpet"
    ICE = "ice"
    MUD = "mud"
    OBSTACLE = "obstacle"
    UNKNOWN = "unknown"


class GripOutcome(str, Enum):
    """파지 결과 / Grip outcome predictions."""
    HOLD = "hold"
    SLIP = "slip"
    CRUSH = "crush"
    MISS = "miss"
    PARTIAL = "partial"


class LocomotionOutcome(str, Enum):
    """이동 결과 / Locomotion outcome predictions."""
    STABLE = "stable"
    WOBBLE = "wobble"
    SLIP = "slip"
    FALL = "fall"
    RECOVER = "recover"
    STUCK = "stuck"


class PredictionConfidence(str, Enum):
    """예측 신뢰도 / Prediction confidence level."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNKNOWN = "unknown"


# ─── 데이터 클래스 / Data Classes ───────────────────────────────────────────


@dataclass
class PhysicalState:
    """
    로봇 + 환경의 물리적 상태 / Full physical state of robot + environment.

    모든 값은 실제 센서/액추에이터에서 수집되는 물리적 측정값입니다.
    추상적 잠재 벡터가 아닌, 물리적으로 의미 있는 상태 표현입니다.

    Attributes:
        joint_positions: 12개 관절 위치 (rad)
        joint_velocities: 12개 관절 속도 (rad/s)
        joint_torques: 12개 관절 토크 (Nm)
        base_position: 베이스 위치 (x, y, z) m
        base_orientation: 베이스 방향 (roll, pitch, yaw) rad
        base_velocity: 선형+각속도 (vx, vy, vz, wx, wy, wz)
        contact_forces: 4발 접촉력 (4×3) N
        gripper_aperture: 그리퍼 열림 (0~1)
        gripper_force: 파지력 (N)
        object_detected: 물체 감지 여부
        terrain_type: 현재 지형
        stability_margin: 안정성 여유 (0=불안정, 1=완전안정)
        center_of_mass_offset: 무게중심 편차 (x, y) m
    """
    joint_positions: np.ndarray = field(default_factory=lambda: np.zeros(12))
    joint_velocities: np.ndarray = field(default_factory=lambda: np.zeros(12))
    joint_torques: np.ndarray = field(default_factory=lambda: np.zeros(12))
    base_position: np.ndarray = field(default_factory=lambda: np.zeros(3))
    base_orientation: np.ndarray = field(default_factory=lambda: np.zeros(3))
    base_velocity: np.ndarray = field(default_factory=lambda: np.zeros(6))
    contact_forces: np.ndarray = field(default_factory=lambda: np.zeros(12))
    gripper_aperture: float = 1.0
    gripper_force: float = 0.0
    object_detected: bool = False
    terrain_type: TerrainType = TerrainType.FLAT
    stability_margin: float = 1.0
    center_of_mass_offset: np.ndarray = field(default_factory=lambda: np.zeros(2))

    STATE_DIM: int = 62  # 고정 차원 / Fixed dimension

    def to_vector(self) -> np.ndarray:
        """물리적 상태를 특징 벡터로 변환 / Convert physical state to feature vector."""
        features = np.concatenate([
            self.joint_positions.flatten()[:12],
            self.joint_velocities.flatten()[:12],
            self.joint_torques.flatten()[:12],
            self.base_position.flatten()[:3],
            self.base_orientation.flatten()[:3],
            self.base_velocity.flatten()[:6],
            self.contact_forces.flatten()[:12],
            [self.gripper_aperture, self.gripper_force,
             float(self.object_detected),
             float(list(TerrainType).index(self.terrain_type))
             / max(1, len(TerrainType) - 1),
             self.stability_margin],
            self.center_of_mass_offset.flatten()[:2],
        ])
        # STATE_DIM에 맞추기 / Pad or truncate to STATE_DIM
        if len(features) < self.STATE_DIM:
            features = np.pad(features, (0, self.STATE_DIM - len(features)))
        return features[:self.STATE_DIM]

    @classmethod
    def from_vector(cls, vec: np.ndarray) -> "PhysicalState":
        """특징 벡터에서 상태 복원 / Reconstruct state from feature vector."""
        vec = vec.flatten()
        state = cls()
        idx = 0
        state.joint_positions = vec[idx:idx+12]; idx += 12
        state.joint_velocities = vec[idx:idx+12]; idx += 12
        state.joint_torques = vec[idx:idx+12]; idx += 12
        state.base_position = vec[idx:idx+3]; idx += 3
        state.base_orientation = vec[idx:idx+3]; idx += 3
        state.base_velocity = vec[idx:idx+6]; idx += 6
        state.contact_forces = vec[idx:idx+12]; idx += 12
        if idx + 5 <= len(vec):
            state.gripper_aperture = float(vec[idx]); idx += 1
            state.gripper_force = float(vec[idx]); idx += 1
            state.object_detected = bool(vec[idx] > 0.5); idx += 1
            terrain_idx = int(vec[idx] * (len(TerrainType) - 1))
            state.terrain_type = list(TerrainType)[
                max(0, min(terrain_idx, len(TerrainType) - 1))
            ]
            idx += 1
            state.stability_margin = float(vec[idx]); idx += 1
        if idx + 2 <= len(vec):
            state.center_of_mass_offset = vec[idx:idx+2]
        return state


@dataclass
class PhysicalAction:
    """
    물리적 행동 / Physical action with parameters.
    """
    action_type: str = "stop"
    parameters: Dict[str, float] = field(default_factory=dict)
    duration_ms: int = 100
    ACTION_DIM: int = 32

    def to_vector(self) -> np.ndarray:
        """행동을 특징 벡터로 변환 / Convert action to feature vector."""
        # 행동 타입 해시 + 파라미터 값들 / Action type hash + parameter values
        type_hash = float(hash(self.action_type) % 10000) / 10000.0
        param_values = list(self.parameters.values())[:15]
        while len(param_values) < 15:
            param_values.append(0.0)
        features = np.array([
            type_hash,
            *param_values,
            self.duration_ms / 1000.0,
        ], dtype=np.float64)
        if len(features) < self.ACTION_DIM:
            features = np.pad(features, (0, self.ACTION_DIM - len(features)))
        return features[:self.ACTION_DIM]


@dataclass
class TerrainPrediction:
    """지형 예측 결과 / Terrain prediction result."""
    terrain_type: TerrainType = TerrainType.UNKNOWN
    friction_coefficient: float = 0.5
    hardness: float = 0.5
    elevation_ahead: float = 0.0
    slip_probability: float = 0.0
    confidence: float = 0.0


@dataclass
class GripPrediction:
    """파지 결과 예측 / Grip outcome prediction."""
    outcome: GripOutcome = GripOutcome.HOLD
    slip_probability: float = 0.0
    crush_probability: float = 0.0
    miss_probability: float = 0.0
    optimal_force: float = 5.0
    confidence: float = 0.0


@dataclass
class LocomotionPrediction:
    """이동 결과 예측 / Locomotion outcome prediction."""
    outcome: LocomotionOutcome = LocomotionOutcome.STABLE
    stability_after: float = 1.0
    slip_probability: float = 0.0
    fall_probability: float = 0.0
    energy_cost_j: float = 0.0
    confidence: float = 0.0


@dataclass
class PhysicalPrediction:
    """
    물리적 예측 결과 / Physical prediction result.

    행동의 물리적 결과를 종합적으로 예측합니다.
    """
    predicted_next_state: Optional[PhysicalState] = None
    predicted_stability: float = 1.0
    predicted_slip_probability: float = 0.0
    predicted_fall_probability: float = 0.0
    terrain_prediction: Optional[TerrainPrediction] = None
    grip_prediction: Optional[GripPrediction] = None
    locomotion_prediction: Optional[LocomotionPrediction] = None
    uncertainty: Dict[str, float] = field(default_factory=dict)
    confidence: float = 0.0
    prediction_loss: float = 0.0


# ─── SQLite 저장소 / SQLite Repository ──────────────────────────────────────


class PhysicalWorldModelRepository:
    """물리적 세계 모델 SQLite 저장소 / Physical world model SQLite repository."""

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS physical_predictions (
        prediction_id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        action_type TEXT,
        terrain_type TEXT,
        predicted_stability REAL,
        predicted_slip_prob REAL,
        actual_stability REAL,
        actual_slip_prob REAL,
        prediction_error REAL,
        confidence REAL
    );
    CREATE INDEX IF NOT EXISTS idx_physpred_ts ON physical_predictions(timestamp);

    CREATE TABLE IF NOT EXISTS model_training (
        step INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
        prediction_loss REAL,
        stability_loss REAL,
        slip_loss REAL,
        grip_loss REAL,
        total_loss REAL,
        n_samples INTEGER
    );

    CREATE TABLE IF NOT EXISTS terrain_stats (
        terrain_type TEXT PRIMARY KEY,
        avg_friction REAL,
        avg_hardness REAL,
        avg_slip_prob REAL,
        sample_count INTEGER,
        last_updated TEXT
    );
    """

    def __init__(self, db_path: Union[str, Path] = "physical_world_model.db") -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()
        logger.info("PhysicalWorldModelRepository 초기화: %s", self._db_path)

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(
                str(self._db_path), check_same_thread=False
            )
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript(self.SCHEMA)
        conn.commit()

    def save_prediction(
        self,
        action_type: str,
        terrain_type: str,
        predicted_stability: float,
        predicted_slip: float,
        actual_stability: float = 0.0,
        actual_slip: float = 0.0,
        prediction_error: float = 0.0,
        confidence: float = 0.0,
    ) -> None:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT INTO physical_predictions
                (timestamp, action_type, terrain_type, predicted_stability,
                 predicted_slip_prob, actual_stability, actual_slip_prob,
                 prediction_error, confidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    datetime.now(timezone.utc).isoformat(),
                    action_type, terrain_type,
                    predicted_stability, predicted_slip,
                    actual_stability, actual_slip,
                    prediction_error, confidence,
                ),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("예측 기록 저장 실패: %s", e)

    def save_training_step(
        self,
        pred_loss: float,
        stability_loss: float,
        slip_loss: float,
        grip_loss: float,
        total_loss: float,
        n_samples: int,
    ) -> None:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT INTO model_training
                (prediction_loss, stability_loss, slip_loss, grip_loss, total_loss, n_samples)
                VALUES (?, ?, ?, ?, ?, ?)""",
                (pred_loss, stability_loss, slip_loss, grip_loss, total_loss, n_samples),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("학습 스텝 기록 실패: %s", e)

    def update_terrain_stats(
        self, terrain_type: str, friction: float, hardness: float, slip_prob: float
    ) -> None:
        try:
            conn = self._get_conn()
            row = conn.execute(
                "SELECT sample_count, avg_friction, avg_hardness, avg_slip_prob "
                "FROM terrain_stats WHERE terrain_type = ?",
                (terrain_type,),
            ).fetchone()
            if row:
                n = row[0] + 1
                alpha = 1.0 / n
                conn.execute(
                    """UPDATE terrain_stats SET
                    avg_friction = avg_friction * (1-?) + ? * ?,
                    avg_hardness = avg_hardness * (1-?) + ? * ?,
                    avg_slip_prob = avg_slip_prob * (1-?) + ? * ?,
                    sample_count = ?,
                    last_updated = ?
                    WHERE terrain_type = ?""",
                    (alpha, alpha, friction, alpha, alpha, hardness,
                     alpha, alpha, slip_prob, n,
                     datetime.now(timezone.utc).isoformat(), terrain_type),
                )
            else:
                conn.execute(
                    """INSERT INTO terrain_stats
                    (terrain_type, avg_friction, avg_hardness, avg_slip_prob, sample_count, last_updated)
                    VALUES (?, ?, ?, ?, 1, ?)""",
                    (terrain_type, friction, hardness, slip_prob,
                     datetime.now(timezone.utc).isoformat()),
                )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("지형 통계 업데이트 실패: %s", e)

    def get_terrain_friction(self, terrain_type: str) -> float:
        try:
            conn = self._get_conn()
            row = conn.execute(
                "SELECT avg_friction FROM terrain_stats WHERE terrain_type = ?",
                (terrain_type,),
            ).fetchone()
            return float(row[0]) if row else 0.5
        except sqlite3.Error:
            return 0.5

    def get_stats(self) -> Dict[str, Any]:
        try:
            conn = self._get_conn()
            total = conn.execute("SELECT COUNT(*) FROM physical_predictions").fetchone()[0]
            avg_err = conn.execute("SELECT AVG(prediction_error) FROM physical_predictions").fetchone()[0] or 0.0
            terrains = conn.execute("SELECT COUNT(*) FROM terrain_stats").fetchone()[0]
            return {
                "total_predictions": total,
                "avg_prediction_error": round(avg_err, 6),
                "terrain_types_learned": terrains,
            }
        except sqlite3.Error:
            return {}


# ─── 지형 예측기 / Terrain Predictor ────────────────────────────────────────


class TerrainPredictor:
    """
    지형 예측기 / Terrain predictor.

    IMU 진동 패턴과 접촉력으로부터 지형의 마찰계수, 경도,
    미끄러짐 확률을 예측합니다. 로봇이 걸으면서 실시간으로
    지형을 분류하고 횡단 전략을 수립하는 데 사용됩니다.

    Usage:
        predictor = TerrainPredictor()
        terrain = predictor.classify_terrain(imu_vibration)
        friction = predictor.estimate_friction(terrain.terrain_type, contact_force)
        slip_prob = predictor.predict_slip_probability(terrain, velocity, contact_force)
    """

    # 지형별 기본 마찰계수 / Default friction coefficients per terrain
    FRICTION_TABLE: Dict[str, float] = {
        "flat": 0.8, "rough": 0.7, "slope": 0.6, "stairs": 0.75,
        "wet": 0.3, "gravel": 0.5, "sand": 0.4, "narrow": 0.8,
        "uneven": 0.6, "carpet": 0.7, "ice": 0.1, "mud": 0.35,
        "obstacle": 0.65, "unknown": 0.5,
    }

    HARDNESS_TABLE: Dict[str, float] = {
        "flat": 0.9, "rough": 0.7, "slope": 0.8, "stairs": 0.9,
        "wet": 0.6, "gravel": 0.4, "sand": 0.2, "narrow": 0.8,
        "uneven": 0.5, "carpet": 0.5, "ice": 0.9, "mud": 0.15,
        "obstacle": 0.7, "unknown": 0.5,
    }

    def __init__(self) -> None:
        # 학습된 마찰계수 (경험으로 갱신) / Learned friction (updated by experience)
        self._learned_friction: Dict[str, Deque[float]] = {}
        self._lock = threading.Lock()
        logger.info("TerrainPredictor 초기화 완료")

    def classify_terrain(
        self,
        imu_vibration: np.ndarray,
        contact_force_pattern: Optional[np.ndarray] = None,
    ) -> TerrainPrediction:
        """
        IMU 진동 패턴으로 지형 분류 / Classify terrain from IMU vibration.

        Args:
            imu_vibration: IMU 진동 데이터 (6축, 최근 N샘플)
            contact_force_pattern: 접촉력 패턴 (선택적)

        Returns:
            지형 예측 결과
        """
        vib = np.asarray(imu_vibration, dtype=np.float64).flatten()

        # 진동 특징 추출 / Extract vibration features
        rms = float(np.sqrt(np.mean(vib ** 2))) if len(vib) > 0 else 0.0
        peak = float(np.max(np.abs(vib))) if len(vib) > 0 else 0.0
        variance = float(np.var(vib)) if len(vib) > 0 else 0.0

        # 휴리스틱 분류 (실제로는 학습된 분류기 사용) / Heuristic classification
        if rms < 0.05 and variance < 0.001:
            terrain = TerrainType.FLAT
        elif rms < 0.1 and variance < 0.005:
            terrain = TerrainType.CARPET
        elif rms > 0.5 and variance > 0.1:
            terrain = TerrainType.GRAVEL
        elif rms > 0.3 and peak > 2.0:
            terrain = TerrainType.UNEVEN
        elif variance > 0.05 and rms > 0.2:
            terrain = TerrainType.ROUGH
        else:
            terrain = TerrainType.FLAT

        friction = self.estimate_friction(terrain)
        hardness = self.HARDNESS_TABLE.get(terrain.value, 0.5)

        return TerrainPrediction(
            terrain_type=terrain,
            friction_coefficient=friction,
            hardness=hardness,
            elevation_ahead=0.0,
            slip_probability=self.predict_slip_probability_simple(friction, 0.5),
            confidence=min(1.0, 0.5 + rms * 0.3),
        )

    def estimate_friction(
        self,
        terrain_type: Union[TerrainType, str],
        contact_force: float = 10.0,
    ) -> float:
        """
        지형의 마찰계수 추정 / Estimate terrain friction coefficient.

        경험을 통해 학습된 값을 우선 사용합니다.

        Args:
            terrain_type: 지형 유형
            contact_force: 접촉력 (N)

        Returns:
            추정 마찰계수 (μ)
        """
        t_name = terrain_type.value if isinstance(terrain_type, TerrainType) else terrain_type

        # 학습된 값 우선 / Prefer learned values
        with self._lock:
            if t_name in self._learned_friction and len(self._learned_friction[t_name]) >= 3:
                return float(np.median(list(self._learned_friction[t_name])))

        # 기본값 / Default
        return self.FRICTION_TABLE.get(t_name, 0.5)

    def predict_slip_probability_simple(
        self, friction: float, velocity: float
    ) -> float:
        """
        마찰계수와 속도로 미끄러짐 확률 추정 / Estimate slip probability.

        Args:
            friction: 마찰계수
            velocity: 이동 속도 (m/s)

        Returns:
            미끄러짐 확률 (0~1)
        """
        # 마찰이 낮고 속도가 높으면 미끄러질 확률 증가
        slip = 1.0 / (1.0 + math.exp(5.0 * (friction - 0.5))) * min(1.0, velocity / 1.5)
        return float(np.clip(slip, 0.0, 1.0))

    def update_from_experience(
        self, terrain_type: str, measured_friction: float
    ) -> None:
        """경험으로 마찰계수 업데이트 / Update friction from experience."""
        with self._lock:
            if terrain_type not in self._learned_friction:
                self._learned_friction[terrain_type] = deque(maxlen=100)
            self._learned_friction[terrain_type].append(measured_friction)

    def predict_ahead(
        self, current_state: PhysicalState, distance_m: float
    ) -> TerrainPrediction:
        """전방 지형 예측 / Predict terrain ahead."""
        return TerrainPrediction(
            terrain_type=current_state.terrain_type,
            friction_coefficient=self.estimate_friction(current_state.terrain_type),
            hardness=self.HARDNESS_TABLE.get(current_state.terrain_type.value, 0.5),
            elevation_ahead=0.0,
            slip_probability=self.predict_slip_probability_simple(
                self.estimate_friction(current_state.terrain_type),
                float(np.linalg.norm(current_state.base_velocity[:3])),
            ),
            confidence=0.5,
        )


# ─── 힘 결과 예측기 / Force Outcome Predictor ───────────────────────────────


class ForceOutcomePredictor:
    """
    힘 인가 결과 예측기 / Force outcome predictor.

    물체에 힘을 가할 때 어떤 일이 발생할지 예측합니다.
    파지 시 슬립/파손, 밀 때 이동/전도, 들 때 성공/탈락 등.
    공예와 정밀 조작에 필수적인 예측 능력입니다.

    Usage:
        predictor = ForceOutcomePredictor()
        grip_pred = predictor.predict_grip_outcome(object_mass=0.2, grip_force=5.0)
        push_pred = predictor.predict_push_outcome(object_mass=1.0, push_force=10.0)
    """

    def __init__(self) -> None:
        # 물체별 최적 파지력 기록 / Object-specific optimal grip force records
        self._grip_history: Dict[str, Deque[Tuple[float, float]]] = {}
        self._lock = threading.Lock()
        logger.info("ForceOutcomePredictor 초기화 완료")

    def predict_grip_outcome(
        self,
        object_mass: float = 0.1,
        object_fragility: float = 0.5,
        grip_force: float = 5.0,
        grip_aperture: float = 0.5,
        surface_friction: float = 0.5,
    ) -> GripPrediction:
        """
        파지 결과 예측 / Predict grip outcome.

        Args:
            object_mass: 물체 질량 (kg)
            object_fragility: 물체 취약도 (0=단단, 1=매우부서지기쉬움)
            grip_force: 파지력 (N)
            grip_aperture: 파지 열림 (0=닫힘, 1=열림)
            surface_friction: 표면 마찰계수

        Returns:
            파지 결과 예측
        """
        # 필요 최소 파지력 = 중력 / 마찰계수 / 2접촉면
        gravity = 9.81
        min_force = (object_mass * gravity) / (2.0 * surface_friction + 1e-6)

        # 파괴력 = 취약도 × 파지력
        crush_threshold = 2.0 + (1.0 - object_fragility) * 20.0  # 단단할수록 높은 임계값

        # 확률 계산 / Calculate probabilities
        if grip_force < min_force * 0.8:
            slip_prob = 0.9
            crush_prob = 0.0
            miss_prob = 0.05
            outcome = GripOutcome.SLIP
        elif grip_force > crush_threshold:
            slip_prob = 0.0
            crush_prob = 0.8
            miss_prob = 0.0
            outcome = GripOutcome.CRUSH
        else:
            slip_prob = max(0.0, 1.0 - grip_force / (min_force + 1e-6))
            crush_prob = max(0.0, (grip_force - crush_threshold * 0.8) / (crush_threshold * 0.2 + 1e-6))
            miss_prob = 0.02
            outcome = GripOutcome.HOLD

        optimal_force = min_force * 1.5  # 여유 50%

        return GripPrediction(
            outcome=outcome,
            slip_probability=float(np.clip(slip_prob, 0, 1)),
            crush_probability=float(np.clip(crush_prob, 0, 1)),
            miss_probability=float(np.clip(miss_prob, 0, 1)),
            optimal_force=round(optimal_force, 2),
            confidence=0.7,
        )

    def predict_push_outcome(
        self,
        object_mass: float = 1.0,
        push_force: float = 10.0,
        surface_friction: float = 0.5,
        object_height_ratio: float = 1.0,
    ) -> Dict[str, Any]:
        """밀기 결과 예측 / Predict push outcome."""
        friction_force = surface_friction * object_mass * 9.81
        tip_threshold = push_force * object_height_ratio / (object_mass * 9.81 * 0.5 + 1e-6)

        if push_force > friction_force * 1.5:
            if tip_threshold > 1.0:
                return {"outcome": "tip", "probability": 0.7, "confidence": 0.6}
            return {"outcome": "slide", "probability": 0.8, "confidence": 0.7}
        elif push_force > friction_force:
            return {"outcome": "move_slow", "probability": 0.6, "confidence": 0.5}
        return {"outcome": "stuck", "probability": 0.8, "confidence": 0.6}

    def predict_lift_outcome(
        self,
        object_weight: float = 1.0,
        grip_strength: float = 10.0,
        com_offset: float = 0.0,
    ) -> Dict[str, Any]:
        """들어올리기 결과 예측 / Predict lift outcome."""
        if grip_strength < object_weight * 9.81:
            return {"outcome": "drop", "probability": 0.9, "confidence": 0.8}
        if com_offset > 0.05:
            return {"outcome": "tilt", "probability": 0.6, "confidence": 0.5}
        return {"outcome": "success", "probability": 0.85, "confidence": 0.7}

    def predict_insertion_outcome(
        self,
        hole_diameter: float = 10.0,
        peg_diameter: float = 9.5,
        insertion_force: float = 5.0,
        alignment_error: float = 0.5,
    ) -> Dict[str, Any]:
        """삽입 결과 예측 / Predict insertion outcome."""
        clearance = hole_diameter - peg_diameter
        if clearance < 0:
            return {"outcome": "jam", "probability": 0.95, "confidence": 0.9}
        if alignment_error > clearance * 0.5:
            return {"outcome": "jam", "probability": 0.7, "confidence": 0.6}
        return {"outcome": "insert", "probability": 0.8, "confidence": 0.7}

    def update_from_experience(
        self, object_type: str, grip_force: float, actual_outcome: str
    ) -> None:
        """경험으로 최적 파지력 갱신 / Update optimal grip force from experience."""
        with self._lock:
            if object_type not in self._grip_history:
                self._grip_history[object_type] = deque(maxlen=50)
            success = 1.0 if actual_outcome == "hold" else 0.0
            self._grip_history[object_type].append((grip_force, success))


# ─── 이동 예측기 / Locomotion Predictor ─────────────────────────────────────


class LocomotionPredictor:
    """
    이동 결과 예측기 / Locomotion outcome predictor.

    보행 시 균형, 지형 횡단 시 안정성, 에너지 비용을 예측합니다.
    사족보행 로봇이 울퉁불퉁한 길을 안전하게 지나기 위해
    각 스텝의 결과를 사전에 예측합니다.

    Usage:
        predictor = LocomotionPredictor()
        step_pred = predictor.predict_step_outcome(current_state, step_params)
        stability = predictor.predict_stability(trajectory, perturbation)
    """

    def __init__(self) -> None:
        # 지형별 성공률 기록 / Terrain-specific success rates
        self._terrain_success: Dict[str, Deque[float]] = {}
        self._lock = threading.Lock()
        logger.info("LocomotionPredictor 초기화 완료")

    def predict_step_outcome(
        self,
        current_state: PhysicalState,
        step_speed: float = 0.3,
        step_height: float = 0.02,
        step_direction: str = "forward",
    ) -> LocomotionPrediction:
        """
        스텝 결과 예측 / Predict step outcome.

        Args:
            current_state: 현재 물리적 상태
            step_speed: 스텝 속도 (m/s)
            step_height: 스텝 높이 (m)
            step_direction: 스텝 방향

        Returns:
            이동 결과 예측
        """
        terrain = current_state.terrain_type
        stability = current_state.stability_margin
        velocity = float(np.linalg.norm(current_state.base_velocity[:3]))

        # 기본 안정성 추정 / Base stability estimation
        base_stability = stability

        # 지형 효과 / Terrain effect
        terrain_risk = {
            "flat": 0.0, "rough": 0.2, "slope": 0.4, "stairs": 0.3,
            "wet": 0.6, "gravel": 0.3, "sand": 0.35, "narrow": 0.25,
            "uneven": 0.4, "carpet": 0.1, "ice": 0.8, "mud": 0.5,
            "obstacle": 0.35, "unknown": 0.3,
        }
        risk = terrain_risk.get(terrain.value, 0.3)

        # 속도 효과 / Speed effect (빠를수록 위험)
        speed_risk = min(1.0, step_speed / 1.0) * 0.3

        # 안정성 예측 / Predicted stability
        predicted_stability = max(0.0, base_stability - risk - speed_risk)

        # 결과 분류 / Classify outcome
        if predicted_stability > 0.7:
            outcome = LocomotionOutcome.STABLE
        elif predicted_stability > 0.4:
            outcome = LocomotionOutcome.WOBBLE
        elif predicted_stability > 0.2:
            outcome = LocomotionOutcome.SLIP
        else:
            outcome = LocomotionOutcome.FALL

        # 에너지 비용 추정 / Estimate energy cost
        base_energy = 5.0  # J per step on flat
        terrain_energy_factor = 1.0 + risk * 2.0
        energy_cost = base_energy * terrain_energy_factor * (1.0 + step_height * 20.0)

        return LocomotionPrediction(
            outcome=outcome,
            stability_after=predicted_stability,
            slip_probability=min(1.0, risk + speed_risk),
            fall_probability=max(0.0, 1.0 - predicted_stability) * 0.3,
            energy_cost_j=energy_cost,
            confidence=0.6 + base_stability * 0.3,
        )

    def predict_stability(
        self,
        state: PhysicalState,
        perturbation_force: float = 0.0,
        perturbation_direction: Optional[np.ndarray] = None,
    ) -> Dict[str, Any]:
        """
        외란에 대한 안정성 예측 / Predict stability under perturbation.

        Args:
            state: 현재 상태
            perturbation_force: 외란 힘 (N)
            perturbation_direction: 외란 방향 (3D)

        Returns:
            안정성 예측 결과
        """
        com_offset = float(np.linalg.norm(state.center_of_mass_offset))
        base_stability = state.stability_margin

        if perturbation_force > 0:
            # 외란이 있으면 안정성 감소 / Stability decreases with perturbation
            stability_after = max(
                0.0,
                base_stability - perturbation_force * 0.02 - com_offset * 0.5,
            )
        else:
            stability_after = base_stability

        can_recover = stability_after > 0.3

        return {
            "stability_before": round(base_stability, 3),
            "stability_after": round(stability_after, 3),
            "can_recover": can_recover,
            "recovery_margin": round(max(0.0, stability_after - 0.3), 3),
            "fall_probability": round(max(0.0, 1.0 - stability_after) * 0.5, 3),
        }

    def predict_terrain_crossing(
        self,
        terrain: TerrainType,
        approach_speed: float = 0.3,
        current_stability: float = 1.0,
    ) -> Dict[str, Any]:
        """지형 횡단 예측 / Predict terrain crossing outcome."""
        success_rates = {
            "flat": 0.99, "rough": 0.85, "slope": 0.70, "stairs": 0.75,
            "wet": 0.50, "gravel": 0.65, "sand": 0.60, "narrow": 0.80,
            "uneven": 0.55, "carpet": 0.95, "ice": 0.30, "mud": 0.45,
            "obstacle": 0.65, "unknown": 0.50,
        }
        base_rate = success_rates.get(terrain.value, 0.50)
        adjusted = base_rate * current_stability * (1.0 - approach_speed * 0.1)

        return {
            "terrain": terrain.value,
            "success_probability": round(max(0.0, adjusted), 3),
            "recommended_speed": round(min(0.5, 0.3 / (1.0 - adjusted + 0.1)), 2),
            "risk_level": "low" if adjusted > 0.8 else "medium" if adjusted > 0.5 else "high",
        }

    def update_from_experience(
        self, terrain_type: str, success: bool
    ) -> None:
        """경험으로 지형 성공률 갱신 / Update terrain success rate from experience."""
        with self._lock:
            if terrain_type not in self._terrain_success:
                self._terrain_success[terrain_type] = deque(maxlen=100)
            self._terrain_success[terrain_type].append(1.0 if success else 0.0)


# ─── 물리적 세계 모델 / Physical World Model ─────────────────────────────────


class PhysicalWorldModel:
    """
    물리적 세계 모델 / Physical World Model.

    로봇이 물리적 상호작용의 결과를 예측하는 핵심 모델입니다.
    모든 학습은 직접적인 물리적 경험에서 비롯됩니다.

    아키텍처:
        PhysicalState → StateEncoder → 잠재상태 (256-dim, 물리적 구조 보존)
        (잠재상태, 행동) → TransitionPredictor → 다음 잠재상태
        잠재상태 → 각 도메인 디코더 → 물리적 예측 (안정성, 슬립, 힘, 지형)

    학습:
        - 모든 학습 데이터 = 물리적 경험 (걷기, 잡기, 들기, 공예)
        - 웹 크롤링 데이터 없음
        - 온라인 학습: 매 물리적 경험 후 모델 갱신

    Usage:
        model = PhysicalWorldModel()
        model.initialize()
        prediction = model.predict_next(current_state, action)
        model.train_on_experience(experiences)
    """

    def __init__(
        self,
        latent_dim: int = 256,
        db_path: Union[str, Path] = "physical_world_model.db",
    ) -> None:
        self._latent_dim = latent_dim
        self._state_dim = PhysicalState.STATE_DIM
        self._action_dim = PhysicalAction.ACTION_DIM

        # 저장소 / Repository
        self._repository = PhysicalWorldModelRepository(db_path)

        # 하위 예측기 / Sub-predictors
        self._terrain_predictor = TerrainPredictor()
        self._force_predictor = ForceOutcomePredictor()
        self._locomotion_predictor = LocomotionPredictor()

        # 상태 인코더 가중치 / State encoder weights
        hidden_dim = 512
        self._enc_W1 = np.random.randn(self._state_dim, hidden_dim) * np.sqrt(2.0 / self._state_dim)
        self._enc_b1 = np.zeros(hidden_dim)
        self._enc_W2 = np.random.randn(hidden_dim, latent_dim) * np.sqrt(2.0 / hidden_dim)
        self._enc_b2 = np.zeros(latent_dim)

        # 전이 예측기 가중치 / Transition predictor weights
        trans_input = latent_dim + self._action_dim
        self._trans_W1 = np.random.randn(trans_input, hidden_dim) * np.sqrt(2.0 / trans_input)
        self._trans_b1 = np.zeros(hidden_dim)
        self._trans_W2 = np.random.randn(hidden_dim, latent_dim) * np.sqrt(2.0 / hidden_dim)
        self._trans_b2 = np.zeros(latent_dim)

        # 도메인 디코더 가중치 / Domain decoder weights
        # 안정성 디코더 / Stability decoder
        self._stab_W = np.random.randn(latent_dim, 64) * 0.01
        self._stab_b = np.zeros(64)
        self._stab_W2 = np.random.randn(64, 1) * 0.01
        self._stab_b2 = np.zeros(1)

        # 슬립 디코더 / Slip decoder
        self._slip_W = np.random.randn(latent_dim, 64) * 0.01
        self._slip_b = np.zeros(64)
        self._slip_W2 = np.random.randn(64, 1) * 0.01
        self._slip_b2 = np.zeros(1)

        # 경험 버퍼 / Experience buffer
        self._experience_buffer: Deque[Dict[str, Any]] = deque(maxlen=100000)
        self._buffer_lock = threading.Lock()

        # 학습 상태 / Training state
        self._training_steps: int = 0
        self._loss_history: Deque[float] = deque(maxlen=1000)
        self._is_training: bool = False
        self._training_lock = threading.Lock()

        # 정규화 통계 / Normalization statistics
        self._running_mean: Optional[np.ndarray] = None
        self._running_var: Optional[np.ndarray] = None
        self._n_updates: int = 0

        logger.info(
            "PhysicalWorldModel 초기화: state_dim=%d, action_dim=%d, latent_dim=%d",
            self._state_dim, self._action_dim, latent_dim,
        )

    def initialize(self) -> None:
        """모델 초기화 / Initialize model."""
        logger.info("PhysicalWorldModel 초기화 완료 — 물리적 경험 기반 학습 준비")

    def encode_state(self, state: PhysicalState) -> np.ndarray:
        """물리적 상태 → 잠재 벡터 / Encode physical state to latent vector."""
        x = state.to_vector()
        x = self._normalize(x)
        h = np.maximum(0, x @ self._enc_W1 + self._enc_b1)
        z = h @ self._enc_W2 + self._enc_b2
        norm = np.linalg.norm(z)
        if norm > 1e-8:
            z = z / norm
        return z

    def predict_transition(
        self, latent: np.ndarray, action: PhysicalAction
    ) -> np.ndarray:
        """잠재 상태 + 행동 → 다음 잠재 상태 / Predict next latent state."""
        a = action.to_vector()
        x = np.concatenate([latent, a])
        h = np.maximum(0, x @ self._trans_W1 + self._trans_b1)
        z_next = h @ self._trans_W2 + self._trans_b2
        norm = np.linalg.norm(z_next)
        if norm > 1e-8:
            z_next = z_next / norm
        return z_next

    def decode_stability(self, latent: np.ndarray) -> float:
        """잠재 상태 → 안정성 / Decode stability from latent."""
        h = np.maximum(0, latent @ self._stab_W + self._stab_b)
        val = float((h @ self._stab_W2 + self._stab_b2).item())
        return float(np.clip(val, 0.0, 1.0))

    def decode_slip(self, latent: np.ndarray) -> float:
        """잠재 상태 → 슬립 확률 / Decode slip probability from latent."""
        h = np.maximum(0, latent @ self._slip_W + self._slip_b)
        val = float((h @ self._slip_W2 + self._slip_b2).item())
        return float(np.clip(1.0 / (1.0 + math.exp(-val)), 0.0, 1.0))

    def predict_next(
        self,
        current_state: PhysicalState,
        action: PhysicalAction,
    ) -> PhysicalPrediction:
        """
        다음 상태 종합 예측 / Comprehensive next state prediction.

        Args:
            current_state: 현재 물리적 상태
            action: 수행할 행동

        Returns:
            물리적 예측 결과
        """
        # 잠재 공간 예측 / Latent space prediction
        z_current = self.encode_state(current_state)
        z_next = self.predict_transition(z_current, action)

        # 안정성 예측 / Predict stability
        predicted_stability = self.decode_stability(z_next)
        predicted_slip = self.decode_slip(z_next)

        # 지형 예측 / Terrain prediction
        terrain_pred = self._terrain_predictor.classify_terrain(
            current_state.base_velocity
        )

        # 이동 예측 / Locomotion prediction
        speed = float(np.linalg.norm(current_state.base_velocity[:3]))
        locomotion_pred = self._locomotion_predictor.predict_step_outcome(
            current_state, step_speed=speed
        )

        # 파지 예측 (파지 행동인 경우) / Grip prediction (if grip action)
        grip_pred = None
        if "grip" in action.action_type.lower():
            grip_pred = self._force_predictor.predict_grip_outcome(
                grip_force=action.parameters.get("force", 5.0),
                grip_aperture=action.parameters.get("aperture", 0.5),
            )

        # 불확실성 추정 / Estimate uncertainty
        distance = float(np.linalg.norm(z_next - z_current))
        uncertainty = {
            "state": min(1.0, distance),
            "stability": max(0.0, 1.0 - predicted_stability),
            "slip": predicted_slip,
        }

        confidence = max(0.0, 1.0 - np.mean(list(uncertainty.values())))

        return PhysicalPrediction(
            predicted_next_state=PhysicalState.from_vector(
                self._latent_to_state_approx(z_next, current_state)
            ),
            predicted_stability=predicted_stability,
            predicted_slip_probability=predicted_slip,
            predicted_fall_probability=max(0.0, 1.0 - predicted_stability) * 0.3,
            terrain_prediction=terrain_pred,
            grip_prediction=grip_pred,
            locomotion_prediction=locomotion_pred,
            uncertainty=uncertainty,
            confidence=confidence,
        )

    def predict_trajectory(
        self,
        initial_state: PhysicalState,
        actions: List[PhysicalAction],
        horizon: int = 10,
    ) -> List[PhysicalPrediction]:
        """행동 시퀀스에 따른 궤적 예측 / Predict trajectory for action sequence."""
        predictions: List[PhysicalPrediction] = []
        current_state = initial_state

        for i, action in enumerate(actions[:horizon]):
            pred = self.predict_next(current_state, action)
            predictions.append(pred)

            # 예측된 다음 상태로 업데이트 / Update to predicted next state
            if pred.predicted_next_state is not None:
                current_state = pred.predicted_next_state

            # 높은 불확실성이면 중단 / Stop if high uncertainty
            if pred.predicted_stability < 0.2:
                logger.warning(
                    "궤적 예측 스텝 %d: 낮은 안정성 (%.2f), 중단",
                    i, pred.predicted_stability,
                )
                break

        return predictions

    def simulate_task(
        self,
        initial_state: PhysicalState,
        task_actions: List[PhysicalAction],
    ) -> Dict[str, Any]:
        """
        작업 시뮬레이션 / Simulate entire task before executing.

        물리적으로 실행하기 전에 내부 시뮬레이션으로 결과를 예측합니다.
        "생각 후 행동"의 핵심 메커니즘입니다.
        """
        predictions = self.predict_trajectory(initial_state, task_actions)

        if not predictions:
            return {"success_probability": 0.0, "min_stability": 0.0}

        min_stability = min(p.predicted_stability for p in predictions)
        max_slip = max(p.predicted_slip_probability for p in predictions)
        avg_confidence = np.mean([p.confidence for p in predictions])

        success_prob = min_stability * (1.0 - max_slip) * avg_confidence

        return {
            "success_probability": round(float(success_prob), 3),
            "min_stability": round(float(min_stability), 3),
            "max_slip_probability": round(float(max_slip), 3),
            "avg_confidence": round(float(avg_confidence), 3),
            "steps_predicted": len(predictions),
            "risk_level": (
                "low" if success_prob > 0.8
                else "medium" if success_prob > 0.5
                else "high"
            ),
            "recommended": success_prob > 0.5,
        }

    def train_on_experience(
        self,
        experiences: List[Dict[str, Any]],
        learning_rate: float = 1e-4,
    ) -> Dict[str, float]:
        """
        물리적 경험으로 모델 학습 / Train model on physical experiences.

        Args:
            experiences: 물리적 경험 목록 (state, action, next_state, outcome)
            learning_rate: 학습률

        Returns:
            학습 메트릭
        """
        if not experiences:
            return {"status": "no_data"}

        total_loss = 0.0
        stability_loss = 0.0
        slip_loss = 0.0
        grip_loss = 0.0
        n_samples = len(experiences)

        for exp in experiences:
            state_vec = np.asarray(exp.get("state", []), dtype=np.float64)
            action_vec = np.asarray(exp.get("action", []), dtype=np.float64)
            next_state_vec = np.asarray(exp.get("next_state", []), dtype=np.float64)

            if len(state_vec) < self._state_dim:
                state_vec = np.pad(state_vec, (0, self._state_dim - len(state_vec)))
            if len(action_vec) < self._action_dim:
                action_vec = np.pad(action_vec, (0, self._action_dim - len(action_vec)))

            # 인코딩 / Encode
            z_current = self._raw_encode(state_vec)
            z_next_actual = self._raw_encode(next_state_vec[:self._state_dim])

            # 전이 예측 / Predict transition
            x = np.concatenate([z_current, action_vec[:self._action_dim]])
            h = np.maximum(0, x @ self._trans_W1 + self._trans_b1)
            z_next_pred = h @ self._trans_W2 + self._trans_b2

            # 예측 손실 / Prediction loss
            pred_loss = float(np.mean((z_next_pred - z_next_actual) ** 2))

            # 안정성 손실 / Stability loss
            actual_stability = exp.get("outcome", {}).get("stability", 0.5)
            pred_stability = self.decode_stability(z_next_pred)
            stab_loss = (pred_stability - actual_stability) ** 2

            # 슬립 손실 / Slip loss
            actual_slip = exp.get("outcome", {}).get("slip", 0.0)
            pred_slip = self.decode_slip(z_next_pred)
            sl_loss = (pred_slip - actual_slip) ** 2

            total_loss += pred_loss + 0.5 * stab_loss + 0.5 * sl_loss
            stability_loss += stab_loss
            slip_loss += sl_loss

            # 역전파 (간소화) / Backprop (simplified)
            error = z_next_pred - z_next_actual
            relu_mask = (h > 0).astype(np.float64)

            grad_W2 = np.outer(h, error)
            grad_b2 = error
            grad_h = (error @ self._trans_W2.T) * relu_mask
            grad_W1 = np.outer(x, grad_h)
            grad_b1 = grad_h

            self._trans_W2 -= learning_rate * np.clip(grad_W2, -1.0, 1.0)
            self._trans_b2 -= learning_rate * np.clip(grad_b2, -1.0, 1.0)
            self._trans_W1 -= learning_rate * np.clip(grad_W1, -1.0, 1.0)
            self._trans_b1 -= learning_rate * np.clip(grad_b1, -1.0, 1.0)

        avg_total = total_loss / max(1, n_samples)
        self._training_steps += 1
        self._loss_history.append(avg_total)

        # 저장소 기록 / Log to repository
        self._repository.save_training_step(
            pred_loss=total_loss / max(1, n_samples),
            stability_loss=stability_loss / max(1, n_samples),
            slip_loss=slip_loss / max(1, n_samples),
            grip_loss=grip_loss / max(1, n_samples),
            total_loss=avg_total,
            n_samples=n_samples,
        )

        logger.info(
            "물리적 세계 모델 학습: %d 경험, 손실=%.6f (안정성=%.4f, 슬립=%.4f)",
            n_samples, avg_total,
            stability_loss / max(1, n_samples),
            slip_loss / max(1, n_samples),
        )

        return {
            "total_loss": round(avg_total, 6),
            "stability_loss": round(stability_loss / max(1, n_samples), 6),
            "slip_loss": round(slip_loss / max(1, n_samples), 6),
            "n_samples": n_samples,
        }

    def get_most_uncertain_action(
        self, state: PhysicalState
    ) -> PhysicalAction:
        """
        가장 불확실한 행동 반환 (호기심 기반 탐색용) /
        Return most uncertain action for curiosity-driven exploration.
        """
        # 여러 행동을 시뮬레이션하여 불확실성이 가장 높은 것 선택
        # Simulate multiple actions and select the most uncertain one
        test_actions = [
            PhysicalAction("walk_forward", {"speed": 0.3}),
            PhysicalAction("strafe_left", {"speed": 0.2}),
            PhysicalAction("climb_step", {"height": 0.05}),
            PhysicalAction("grip_close", {"force": 5.0}),
            PhysicalAction("lift", {"height": 0.1, "force": 10.0}),
        ]

        max_uncertainty = 0.0
        best_action = test_actions[0]

        for action in test_actions:
            pred = self.predict_next(state, action)
            avg_unc = np.mean(list(pred.uncertainty.values()))
            if avg_unc > max_uncertainty:
                max_uncertainty = avg_unc
                best_action = action

        return best_action

    def _raw_encode(self, state_vec: np.ndarray) -> np.ndarray:
        """원시 벡터 인코딩 / Encode raw vector."""
        x = self._normalize(state_vec[:self._state_dim])
        h = np.maximum(0, x @ self._enc_W1 + self._enc_b1)
        z = h @ self._enc_W2 + self._enc_b2
        norm = np.linalg.norm(z)
        if norm > 1e-8:
            z = z / norm
        return z

    def _latent_to_state_approx(
        self, latent: np.ndarray, reference_state: PhysicalState
    ) -> np.ndarray:
        """잠재 벡터 → 근사 상태 벡터 / Approximate state from latent."""
        # 실제로는 디코더가 필요하지만, 참조 상태 기반 근사 사용
        # In practice a decoder is needed; use reference-based approximation
        ref_vec = reference_state.to_vector()
        # 잠재 벡터 방향으로 미세 조정 / Slight adjustment toward latent direction
        adjustment = np.random.randn(self._state_dim) * 0.01
        return ref_vec + adjustment

    def _normalize(self, x: np.ndarray) -> np.ndarray:
        """정규화 / Normalize features.

        Before any training data has been observed, _running_mean and
        _running_var are None.  In that case we return the input unchanged —
        normalisation is only meaningful after we have accumulated enough
        samples to estimate reliable statistics.  This is intentional: the
        first few forward passes operate on raw (un-normalised) features,
        which is safe because the encoder weights are randomly initialised
        and the model has not yet been trained.
        """
        x = np.asarray(x, dtype=np.float64).flatten()
        if self._running_mean is not None and self._running_var is not None:
            return (x - self._running_mean) / (np.sqrt(self._running_var) + 1e-8)
        # No training statistics yet — return input unchanged (safe default).
        return x

    def update_normalization(self, features: np.ndarray) -> None:
        """정규화 통계 업데이트 / Update normalization statistics."""
        self._n_updates += 1
        batch_mean = np.mean(features, axis=0) if features.ndim > 1 else features
        batch_var = np.var(features, axis=0) if features.ndim > 1 else np.ones_like(features) * 0.1

        if self._running_mean is None:
            self._running_mean = np.asarray(batch_mean, dtype=np.float64).flatten()
            self._running_var = np.asarray(batch_var, dtype=np.float64).flatten()
        else:
            alpha = min(0.01, 1.0 / self._n_updates)
            self._running_mean = (1 - alpha) * self._running_mean + alpha * batch_mean.flatten()
            self._running_var = (1 - alpha) * self._running_var + alpha * batch_var.flatten()

    def add_experience(self, experience: Dict[str, Any]) -> None:
        """경험 추가 / Add experience to buffer."""
        with self._buffer_lock:
            self._experience_buffer.append(experience)

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        avg_loss = float(np.mean(list(self._loss_history))) if self._loss_history else 0.0
        return {
            "training_steps": self._training_steps,
            "avg_loss": round(avg_loss, 6),
            "experience_buffer_size": len(self._experience_buffer),
            "repository": self._repository.get_stats(),
        }

    def shutdown(self) -> None:
        """종료 / Shutdown."""
        logger.info("PhysicalWorldModel 종료 — 학습 스텝: %d", self._training_steps)


# ═══════════════════════════════════════════════════════════════════════════
# V8.5 PyTorch Neural Network Upgrades
# ═══════════════════════════════════════════════════════════════════════════
#
# 실제 PyTorch 기반 신경망 모델 — 진짜 학습/역전파 지원
# Real PyTorch-based neural network — actual training/backpropagation
#
# 기존 numpy 기반 PhysicalWorldModel을 대체하는 고수준 래퍼 포함
# Includes high-level wrapper replacing the numpy-based PhysicalWorldModel
# ═══════════════════════════════════════════════════════════════════════════


if _HAS_TORCH:

    # ─── PyTorch 신경망 모델 / PyTorch Neural Network Model ────────────────

    class PhysicalWorldModelNet(nn.Module):
        """
        V8.5 PyTorch 신경망 세계 모델 / V8.5 PyTorch Neural World Model.

        실제 학습 가능한 PyTorch Module입니다. 기존 numpy 행렬 곱셈 기반
        "신경망"을 대체하는 진짜 신경망입니다.

        Architecture:
            StateEncoder: PhysicalState(62) → latent(256) via FC(62→256→512→256) + ReLU+BN+Dropout
            ActionEncoder: PhysicalAction(32) → action_latent(128) via FC(32→128→128)
            TransitionModel: concat(latent, action_latent)(384) → next_latent(256) via FC(384→512→256)
            StabilityDecoder: latent(256) → stability(1) sigmoid
            SlipDecoder: latent(256) → slip_prob(1) sigmoid
            ForceDecoder: latent(256) → force_prediction(16) for contact forces
            TerrainClassifier: latent(256) → terrain_class(14) softmax

        Usage:
            net = PhysicalWorldModelNet()
            predictions = net(state_tensor, action_tensor)
        """

        STATE_DIM: int = 62
        ACTION_DIM: int = 32
        LATENT_DIM: int = 256
        ACTION_LATENT_DIM: int = 128
        NUM_TERRAIN_CLASSES: int = 14  # TerrainType has 14 members
        FORCE_PRED_DIM: int = 16  # Predicted contact forces (4 feet × 4 features)

        def __init__(self, dropout_rate: float = 0.1) -> None:
            super().__init__()

            # ── StateEncoder: PhysicalState(62) → latent(256) ──
            self.state_encoder = nn.Sequential(
                nn.Linear(self.STATE_DIM, 256),
                nn.ReLU(inplace=True),
                nn.BatchNorm1d(256),
                nn.Dropout(dropout_rate),
                nn.Linear(256, 512),
                nn.ReLU(inplace=True),
                nn.BatchNorm1d(512),
                nn.Dropout(dropout_rate),
                nn.Linear(512, self.LATENT_DIM),
                nn.ReLU(inplace=True),
                nn.BatchNorm1d(self.LATENT_DIM),
            )

            # ── ActionEncoder: PhysicalAction(32) → action_latent(128) ──
            self.action_encoder = nn.Sequential(
                nn.Linear(self.ACTION_DIM, 128),
                nn.ReLU(inplace=True),
                nn.BatchNorm1d(128),
                nn.Linear(128, self.ACTION_LATENT_DIM),
                nn.ReLU(inplace=True),
            )

            # ── TransitionModel: concat(latent, action_latent)(384) → next_latent(256) ──
            transition_input_dim = self.LATENT_DIM + self.ACTION_LATENT_DIM  # 256 + 128 = 384
            self.transition_model = nn.Sequential(
                nn.Linear(transition_input_dim, 512),
                nn.ReLU(inplace=True),
                nn.BatchNorm1d(512),
                nn.Dropout(dropout_rate),
                nn.Linear(512, 256),
                nn.ReLU(inplace=True),
                nn.BatchNorm1d(256),
                nn.Linear(256, self.LATENT_DIM),
            )

            # ── Domain Decoders ──
            # StabilityDecoder: latent(256) → stability(1) sigmoid
            self.stability_decoder = nn.Sequential(
                nn.Linear(self.LATENT_DIM, 64),
                nn.ReLU(inplace=True),
                nn.Linear(64, 1),
                nn.Sigmoid(),
            )

            # SlipDecoder: latent(256) → slip_prob(1) sigmoid
            self.slip_decoder = nn.Sequential(
                nn.Linear(self.LATENT_DIM, 64),
                nn.ReLU(inplace=True),
                nn.Linear(64, 1),
                nn.Sigmoid(),
            )

            # ForceDecoder: latent(256) → force_prediction(16)
            self.force_decoder = nn.Sequential(
                nn.Linear(self.LATENT_DIM, 64),
                nn.ReLU(inplace=True),
                nn.Linear(64, self.FORCE_PRED_DIM),
            )

            # TerrainClassifier: latent(256) → terrain_class(14) softmax
            self.terrain_classifier = nn.Sequential(
                nn.Linear(self.LATENT_DIM, 128),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout_rate),
                nn.Linear(128, self.NUM_TERRAIN_CLASSES),
                # softmax applied in forward() via F.log_softmax for NLLLoss compatibility
            )

            # Kaiming initialization
            self._init_weights()

        def _init_weights(self) -> None:
            """Kaiming 초기화 / Kaiming (He) initialization for all linear layers."""
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    nn.init.kaiming_normal_(
                        module.weight, mode="fan_in", nonlinearity="relu"
                    )
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)
                elif isinstance(module, nn.BatchNorm1d):
                    nn.init.ones_(module.weight)
                    nn.init.zeros_(module.bias)

        def forward(
            self,
            state: torch.Tensor,
            action: torch.Tensor,
        ) -> Dict[str, torch.Tensor]:
            """
            순전파 / Forward pass.

            Args:
                state: (batch, 62) 물리적 상태 텐서
                action: (batch, 32) 행동 텐서

            Returns:
                Dictionary of predictions:
                    latent: (batch, 256) — encoded current state
                    next_latent: (batch, 256) — predicted next latent
                    stability: (batch, 1) — predicted stability [0,1]
                    slip_prob: (batch, 1) — predicted slip probability [0,1]
                    force_pred: (batch, 16) — predicted contact forces
                    terrain_logits: (batch, 14) — terrain class logits
            """
            # Encode
            latent = self.state_encoder(state)           # (batch, 256)
            action_latent = self.action_encoder(action)   # (batch, 128)

            # Transition
            trans_input = torch.cat([latent, action_latent], dim=-1)  # (batch, 384)
            next_latent = self.transition_model(trans_input)           # (batch, 256)

            # Decode predictions from next_latent
            stability = self.stability_decoder(next_latent)       # (batch, 1)
            slip_prob = self.slip_decoder(next_latent)            # (batch, 1)
            force_pred = self.force_decoder(next_latent)          # (batch, 16)
            terrain_logits = self.terrain_classifier(next_latent) # (batch, 14)

            return {
                "latent": latent,
                "next_latent": next_latent,
                "stability": stability,
                "slip_prob": slip_prob,
                "force_pred": force_pred,
                "terrain_logits": terrain_logits,
            }

        def encode(self, state: torch.Tensor) -> torch.Tensor:
            """상태만 인코딩 / Encode state only."""
            return self.state_encoder(state)

        def predict_transition_only(
            self, latent: torch.Tensor, action: torch.Tensor
        ) -> torch.Tensor:
            """전이만 예측 / Predict transition only."""
            action_latent = self.action_encoder(action)
            trans_input = torch.cat([latent, action_latent], dim=-1)
            return self.transition_model(trans_input)

    # ─── JEPA 손실 / JEPA Loss ────────────────────────────────────────────────

    class JEPALoss(nn.Module):
        """
        Joint Embedding Predictive Architecture 손실 / JEPA Loss.

        VICReg 스타일 손실: 분산(Variance) + 불변성(Invariance) + 공분산(Covariance)
        현재 잠재 상태와 행동으로부터 다음 잠재 상태를 예측합니다.
        표현 붕괴(representation collapse)를 방지합니다.

        VICReg-style loss:
            - Variance: keeps representations from collapsing to a single point
            - Invariance: pulls predicted next-latent close to actual next-latent
            - Covariance: decorrelates latent dimensions

        Usage:
            jepa = JEPALoss()
            loss = jepa(predicted_latent, target_latent)
        """

        def __init__(
            self,
            variance_weight: float = 25.0,
            invariance_weight: float = 25.0,
            covariance_weight: float = 1.0,
            epsilon: float = 1e-4,
        ) -> None:
            super().__init__()
            self.variance_weight = variance_weight
            self.invariance_weight = invariance_weight
            self.covariance_weight = covariance_weight
            self.epsilon = epsilon

        def forward(
            self,
            predicted: torch.Tensor,
            target: torch.Tensor,
        ) -> torch.Tensor:
            """
            JEPA 손실 계산 / Compute JEPA loss.

            Args:
                predicted: (batch, dim) 예측된 잠재 표현
                target: (batch, dim) 실제 목표 잠재 표현

            Returns:
                스칼라 손실
            """
            batch_size = predicted.shape[0]
            dim = predicted.shape[1]

            # ── Invariance: MSE between predicted and target ──
            invariance_loss = F.mse_loss(predicted, target)

            # ── Variance: prevent collapse — each dim should have variance > 1 ──
            pred_std = torch.sqrt(predicted.var(dim=0) + self.epsilon)
            target_std = torch.sqrt(target.var(dim=0) + self.epsilon)
            variance_loss = (
                torch.mean(F.relu(1.0 - pred_std))
                + torch.mean(F.relu(1.0 - target_std))
            )

            # ── Covariance: decorrelate off-diagonal elements ──
            pred_centered = predicted - predicted.mean(dim=0)
            target_centered = target - target.mean(dim=0)
            pred_cov = (pred_centered.T @ pred_centered) / (batch_size - 1 + self.epsilon)
            target_cov = (target_centered.T @ target_centered) / (batch_size - 1 + self.epsilon)

            # Off-diagonal penalty
            off_diag_mask = ~torch.eye(dim, device=predicted.device, dtype=torch.bool)
            covariance_loss = (
                pred_cov[off_diag_mask].pow(2).sum() / dim
                + target_cov[off_diag_mask].pow(2).sum() / dim
            )

            total_loss = (
                self.invariance_weight * invariance_loss
                + self.variance_weight * variance_loss
                + self.covariance_weight * covariance_loss
            )
            return total_loss

    # ─── 세계 모델 트레이너 / World Model Trainer ────────────────────────────

    class WorldModelTrainer:
        """
        V8.5 세계 모델 트레이너 / V8.5 World Model Trainer.

        실제 PyTorch 학습 루프를 제공합니다.
        AdamW 옵티마이저, 그래디언트 클리핑, 학습률 스케줄링을 사용합니다.

        손실 구성:
            transition_loss (MSE) + stability_loss (BCE) + slip_loss (BCE)
            + terrain_loss (CE) + jepa_loss + force_loss (MSE)

        Usage:
            model = PhysicalWorldModelNet()
            trainer = WorldModelTrainer(model)
            metrics = trainer.train_step(batch)
            trainer.save_checkpoint("world_model.pt")
        """

        def __init__(
            self,
            model: PhysicalWorldModelNet,
            lr: float = 1e-3,
            device: str = "cuda",
            grad_clip_norm: float = 1.0,
            weight_decay: float = 1e-4,
            # Loss weights
            transition_weight: float = 1.0,
            stability_weight: float = 0.5,
            slip_weight: float = 0.5,
            terrain_weight: float = 0.3,
            jepa_weight: float = 0.1,
            force_weight: float = 0.3,
        ) -> None:
            self.device = torch.device(device if torch.cuda.is_available() else "cpu")
            self.model = model.to(self.device)
            self.grad_clip_norm = grad_clip_norm

            # Loss weights
            self.transition_weight = transition_weight
            self.stability_weight = stability_weight
            self.slip_weight = slip_weight
            self.terrain_weight = terrain_weight
            self.jepa_weight = jepa_weight
            self.force_weight = force_weight

            # Optimizer: AdamW with weight decay
            self.optimizer = AdamW(
                self.model.parameters(),
                lr=lr,
                weight_decay=weight_decay,
            )

            # Learning rate scheduler: CosineAnnealing
            self.scheduler = CosineAnnealingLR(
                self.optimizer, T_max=10000, eta_min=lr * 0.01
            )

            # Loss functions
            self.mse_loss = nn.MSELoss()
            self.bce_loss = nn.BCELoss()
            self.ce_loss = nn.CrossEntropyLoss()
            self.jepa_loss = JEPALoss()

            # Training state
            self._step_count: int = 0
            self._loss_history: List[float] = []

            logger.info(
                "WorldModelTrainer 초기화: device=%s, lr=%.1e, grad_clip=%.1f",
                self.device, lr, grad_clip_norm,
            )

        def train_step(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
            """
            단일 학습 스텝 / Single training gradient step.

            Args:
                batch: Dictionary with keys:
                    state: (batch, 62) current state
                    action: (batch, 32) action taken
                    next_state: (batch, 62) resulting next state
                    stability: (batch, 1) actual stability label
                    slip: (batch, 1) actual slip label
                    terrain_class: (batch,) integer terrain class labels
                    contact_forces: (batch, 16) actual contact forces

            Returns:
                Dictionary of scalar loss values
            """
            self.model.train()

            # Move batch to device
            state = batch["state"].to(self.device)
            action = batch["action"].to(self.device)
            next_state = batch["next_state"].to(self.device)
            stability_target = batch["stability"].to(self.device)
            slip_target = batch["slip"].to(self.device)
            terrain_target = batch["terrain_class"].to(self.device)
            forces_target = batch["contact_forces"].to(self.device)

            # Forward pass
            predictions = self.model(state, action)

            # Encode next state for JEPA target
            with torch.no_grad():
                target_latent = self.model.encode(next_state)

            # ── Compute losses ──

            # 1. Transition loss: MSE between predicted next latent and encoded next state
            transition_loss = self.mse_loss(
                predictions["next_latent"], target_latent.detach()
            )

            # 2. Stability loss: Binary cross-entropy
            stability_loss = self.bce_loss(
                predictions["stability"], stability_target
            )

            # 3. Slip loss: Binary cross-entropy
            slip_loss = self.bce_loss(
                predictions["slip_prob"], slip_target
            )

            # 4. Terrain classification loss: Cross-entropy
            terrain_loss = self.ce_loss(
                predictions["terrain_logits"], terrain_target
            )

            # 5. JEPA loss: VICReg-style representation learning
            jepa_loss = self.jepa_loss(
                predictions["next_latent"], target_latent.detach()
            )

            # 6. Force prediction loss: MSE
            force_loss = self.mse_loss(
                predictions["force_pred"], forces_target
            )

            # ── Total loss ──
            total_loss = (
                self.transition_weight * transition_loss
                + self.stability_weight * stability_loss
                + self.slip_weight * slip_loss
                + self.terrain_weight * terrain_loss
                + self.jepa_weight * jepa_loss
                + self.force_weight * force_loss
            )

            # ── Backward + optimize ──
            self.optimizer.zero_grad()
            total_loss.backward()

            # Gradient clipping
            nn.utils.clip_grad_norm_(
                self.model.parameters(), self.grad_clip_norm
            )

            self.optimizer.step()
            self.scheduler.step()

            # Track
            self._step_count += 1
            loss_val = total_loss.item()
            self._loss_history.append(loss_val)

            metrics = {
                "total_loss": loss_val,
                "transition_loss": transition_loss.item(),
                "stability_loss": stability_loss.item(),
                "slip_loss": slip_loss.item(),
                "terrain_loss": terrain_loss.item(),
                "jepa_loss": jepa_loss.item(),
                "force_loss": force_loss.item(),
                "lr": self.scheduler.get_last_lr()[0],
                "step": self._step_count,
            }

            if self._step_count % 100 == 0:
                logger.info(
                    "WorldModelTrainer 스텝 %d: total_loss=%.4f, "
                    "trans=%.4f, stab=%.4f, slip=%.4f, terrain=%.4f, "
                    "jepa=%.4f, force=%.4f, lr=%.2e",
                    self._step_count, loss_val,
                    transition_loss.item(), stability_loss.item(),
                    slip_loss.item(), terrain_loss.item(),
                    jepa_loss.item(), force_loss.item(),
                    self.scheduler.get_last_lr()[0],
                )

            return metrics

        def save_checkpoint(self, path: Union[str, Path]) -> None:
            """체크포인트 저장 / Save model checkpoint."""
            checkpoint = {
                "model_state_dict": self.model.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "scheduler_state_dict": self.scheduler.state_dict(),
                "step_count": self._step_count,
                "loss_history": self._loss_history[-1000:],  # Keep last 1000
            }
            save_path = Path(path)
            save_path.parent.mkdir(parents=True, exist_ok=True)
            torch.save(checkpoint, str(save_path))
            logger.info("체크포인트 저장: %s (스텝 %d)", save_path, self._step_count)

        def load_checkpoint(self, path: Union[str, Path]) -> None:
            """체크포인트 로드 / Load model checkpoint."""
            checkpoint = torch.load(str(path), map_location=self.device, weights_only=False)
            self.model.load_state_dict(checkpoint["model_state_dict"])
            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
            self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
            self._step_count = checkpoint.get("step_count", 0)
            self._loss_history = checkpoint.get("loss_history", [])
            logger.info("체크포인트 로드: %s (스텝 %d)", path, self._step_count)

        @property
        def step_count(self) -> int:
            """학습 스텝 수 / Training step count."""
            return self._step_count

    # ─── 신경망 세계 모델 / Neural World Model ────────────────────────────────

    class NeuralWorldModel:
        """
        V8.5 신경망 세계 모델 / V8.5 Neural World Model.

        PhysicalWorldModelNet을 내부적으로 사용하는 고수준 래퍼입니다.
        기존 numpy 기반 PhysicalWorldModel과 동일한 인터페이스를 제공하며,
        PyTorch를 사용할 수 없는 경우 numpy 기반으로 폴백합니다.

        High-level wrapper using PhysicalWorldModelNet internally.
        Provides the same interface as the numpy-based PhysicalWorldModel.
        Falls back to numpy-based prediction if PyTorch is not available.

        Usage:
            model = NeuralWorldModel()
            prediction = model.predict_next(state, action)
            model.train_on_experience(experiences)
            trajectory = model.simulate_trajectory(state, actions, n_steps)
        """

        def __init__(
            self,
            device: str = "cuda",
            lr: float = 1e-3,
            checkpoint_path: Optional[Union[str, Path]] = None,
        ) -> None:
            self._device = torch.device(device if torch.cuda.is_available() else "cpu")
            self._net = PhysicalWorldModelNet().to(self._device)
            self._trainer = WorldModelTrainer(self._net, lr=lr, device=str(self._device))
            self._fallback_model = PhysicalWorldModel()  # numpy fallback
            self._step_count: int = 0

            if checkpoint_path is not None:
                cp_path = Path(checkpoint_path)
                if cp_path.exists():
                    self._trainer.load_checkpoint(cp_path)
                    logger.info("NeuralWorldModel: 체크포인트 로드 %s", cp_path)

            logger.info(
                "NeuralWorldModel 초기화: device=%s, lr=%.1e",
                self._device, lr,
            )

        def predict_next(
            self,
            state: PhysicalState,
            action: PhysicalAction,
        ) -> PhysicalPrediction:
            """
            다음 상태 예측 / Predict next state (same interface as PhysicalWorldModel).

            PyTorch 모델을 사용하여 예측합니다. 실패 시 numpy 기반으로 폴백합니다.
            """
            try:
                self._net.eval()
                with torch.no_grad():
                    state_t = torch.FloatTensor(
                        state.to_vector()
                    ).unsqueeze(0).to(self._device)
                    action_t = torch.FloatTensor(
                        action.to_vector()
                    ).unsqueeze(0).to(self._device)

                    preds = self._net(state_t, action_t)

                # Extract scalar predictions
                stability = float(preds["stability"].squeeze().cpu())
                slip_prob = float(preds["slip_prob"].squeeze().cpu())
                force_pred = preds["force_pred"].squeeze().cpu().numpy()
                terrain_logits = preds["terrain_logits"].squeeze().cpu()
                terrain_idx = int(terrain_logits.argmax().item())
                terrain_types = list(TerrainType)
                predicted_terrain = terrain_types[
                    max(0, min(terrain_idx, len(terrain_types) - 1))
                ]
                terrain_confidence = float(
                    F.softmax(terrain_logits, dim=0).max().item()
                )

                # Build terrain prediction
                terrain_pred = TerrainPrediction(
                    terrain_type=predicted_terrain,
                    friction_coefficient=TerrainPredictor.FRICTION_TABLE.get(
                        predicted_terrain.value, 0.5
                    ),
                    hardness=TerrainPredictor.HARDNESS_TABLE.get(
                        predicted_terrain.value, 0.5
                    ),
                    elevation_ahead=0.0,
                    slip_probability=slip_prob,
                    confidence=terrain_confidence,
                )

                # Approximate next state from predicted latent
                next_latent_np = preds["next_latent"].squeeze().cpu().numpy()
                ref_vec = state.to_vector()
                # Scale adjustment by latent prediction
                scale = float(np.linalg.norm(next_latent_np)) * 0.01
                adjustment = np.random.randn(len(ref_vec)) * scale
                approx_next_vec = ref_vec + adjustment
                approx_next_vec[57] = stability  # stability_margin index
                predicted_next_state = PhysicalState.from_vector(approx_next_vec)

                # Build locomotion prediction
                fall_prob = max(0.0, 1.0 - stability) * 0.3
                if stability > 0.7:
                    loco_outcome = LocomotionOutcome.STABLE
                elif stability > 0.4:
                    loco_outcome = LocomotionOutcome.WOBBLE
                elif stability > 0.2:
                    loco_outcome = LocomotionOutcome.SLIP
                else:
                    loco_outcome = LocomotionOutcome.FALL

                locomotion_pred = LocomotionPrediction(
                    outcome=loco_outcome,
                    stability_after=stability,
                    slip_probability=slip_prob,
                    fall_probability=fall_prob,
                    energy_cost_j=5.0,
                    confidence=terrain_confidence * 0.8,
                )

                # Build uncertainty
                uncertainty = {
                    "state": min(1.0, float(np.linalg.norm(next_latent_np))),
                    "stability": max(0.0, 1.0 - stability),
                    "slip": slip_prob,
                }
                confidence = max(0.0, 1.0 - np.mean(list(uncertainty.values())))

                return PhysicalPrediction(
                    predicted_next_state=predicted_next_state,
                    predicted_stability=stability,
                    predicted_slip_probability=slip_prob,
                    predicted_fall_probability=fall_prob,
                    terrain_prediction=terrain_pred,
                    grip_prediction=None,
                    locomotion_prediction=locomotion_pred,
                    uncertainty=uncertainty,
                    confidence=confidence,
                )

            except Exception as e:
                logger.warning(
                    "PyTorch 예측 실패, numpy 폴백: %s", e
                )
                return self._fallback_model.predict_next(state, action)

        def train_on_experience(
            self,
            experiences: List[Dict[str, Any]],
        ) -> Dict[str, float]:
            """
            경험 배치로 모델 학습 / Train model on a batch of experiences.

            Args:
                experiences: List of dicts with keys:
                    state, action, next_state, stability, slip, terrain_class, contact_forces

            Returns:
                Training metrics dictionary
            """
            if not experiences:
                return {"status": "no_data"}

            try:
                batch_size = len(experiences)

                # Build tensors from experiences
                state_vecs = []
                action_vecs = []
                next_state_vecs = []
                stability_labels = []
                slip_labels = []
                terrain_labels = []
                force_labels = []

                for exp in experiences:
                    # State
                    s = exp.get("state")
                    if isinstance(s, PhysicalState):
                        state_vecs.append(s.to_vector())
                    else:
                        sv = np.asarray(s, dtype=np.float64).flatten()
                        if len(sv) < PhysicalState.STATE_DIM:
                            sv = np.pad(sv, (0, PhysicalState.STATE_DIM - len(sv)))
                        state_vecs.append(sv[:PhysicalState.STATE_DIM])

                    # Action
                    a = exp.get("action")
                    if isinstance(a, PhysicalAction):
                        action_vecs.append(a.to_vector())
                    else:
                        av = np.asarray(a, dtype=np.float64).flatten()
                        if len(av) < PhysicalAction.ACTION_DIM:
                            av = np.pad(av, (0, PhysicalAction.ACTION_DIM - len(av)))
                        action_vecs.append(av[:PhysicalAction.ACTION_DIM])

                    # Next state
                    ns = exp.get("next_state")
                    if isinstance(ns, PhysicalState):
                        next_state_vecs.append(ns.to_vector())
                    else:
                        nsv = np.asarray(ns, dtype=np.float64).flatten()
                        if len(nsv) < PhysicalState.STATE_DIM:
                            nsv = np.pad(nsv, (0, PhysicalState.STATE_DIM - len(nsv)))
                        next_state_vecs.append(nsv[:PhysicalState.STATE_DIM])

                    # Labels
                    outcome = exp.get("outcome", {})
                    stability_labels.append([float(outcome.get("stability", 0.5))])
                    slip_labels.append([float(outcome.get("slip", 0.0))])
                    terrain_labels.append(int(outcome.get("terrain_class", 0)))
                    cf = np.asarray(outcome.get("contact_forces", np.zeros(16)), dtype=np.float64).flatten()
                    if len(cf) < 16:
                        cf = np.pad(cf, (0, 16 - len(cf)))
                    force_labels.append(cf[:16])

                # BatchNorm1d requires batch_size >= 2 in training mode.
                # Duplicate single-sample batches to avoid the issue.
                if len(state_vecs) == 1:
                    state_vecs = state_vecs * 2
                    action_vecs = action_vecs * 2
                    next_state_vecs = next_state_vecs * 2
                    stability_labels = stability_labels * 2
                    slip_labels = slip_labels * 2
                    terrain_labels = terrain_labels * 2
                    force_labels = force_labels * 2

                batch = {
                    "state": torch.FloatTensor(np.stack(state_vecs)).to(self._device),
                    "action": torch.FloatTensor(np.stack(action_vecs)).to(self._device),
                    "next_state": torch.FloatTensor(np.stack(next_state_vecs)).to(self._device),
                    "stability": torch.FloatTensor(np.stack(stability_labels)).to(self._device),
                    "slip": torch.FloatTensor(np.stack(slip_labels)).to(self._device),
                    "terrain_class": torch.LongTensor(terrain_labels).to(self._device),
                    "contact_forces": torch.FloatTensor(np.stack(force_labels)).to(self._device),
                }

                metrics = self._trainer.train_step(batch)
                self._step_count += 1
                return metrics

            except Exception as e:
                logger.warning(
                    "PyTorch 학습 실패, numpy 폴백: %s", e
                )
                return self._fallback_model.train_on_experience(experiences)

        def train_online(
            self,
            state: PhysicalState,
            action: PhysicalAction,
            next_state: PhysicalState,
            stability: float = 0.5,
            slip: float = 0.0,
            terrain_class: int = 0,
            contact_forces: Optional[np.ndarray] = None,
        ) -> Dict[str, float]:
            """
            단일 스텝 온라인 학습 / Single-step online learning.

            물리적 경험을 하나씩 받아 실시간으로 모델을 갱신합니다.

            Args:
                state: 현재 상태
                action: 수행한 행동
                next_state: 결과 상태
                stability: 실제 안정성 (0~1)
                slip: 실제 미끄러짐 여부 (0~1)
                terrain_class: 실제 지형 클래스 인덱스 (0~13)
                contact_forces: 실제 접촉력 (16-dim)

            Returns:
                Training metrics
            """
            if contact_forces is None:
                contact_forces = np.zeros(16)

            experience = {
                "state": state,
                "action": action,
                "next_state": next_state,
                "outcome": {
                    "stability": stability,
                    "slip": slip,
                    "terrain_class": terrain_class,
                    "contact_forces": contact_forces,
                },
            }
            return self.train_on_experience([experience])

        def simulate_trajectory(
            self,
            initial_state: PhysicalState,
            action_sequence: List[PhysicalAction],
            n_steps: int = 10,
        ) -> List[PhysicalPrediction]:
            """
            궤적 시뮬레이션 / Simulate trajectory.

            초기 상태에서 행동 시퀀스를 수행했을 때의 궤적을 예측합니다.

            Args:
                initial_state: 초기 물리적 상태
                action_sequence: 행동 시퀀스
                n_steps: 최대 시뮬레이션 스텝 수

            Returns:
                예측 결과 리스트
            """
            predictions: List[PhysicalPrediction] = []
            current_state = initial_state

            for i, action in enumerate(action_sequence[:n_steps]):
                pred = self.predict_next(current_state, action)
                predictions.append(pred)

                if pred.predicted_next_state is not None:
                    current_state = pred.predicted_next_state

                # 높은 불확실성이면 중단 / Stop if high uncertainty
                if pred.predicted_stability < 0.2:
                    logger.warning(
                        "궤적 시뮬레이션 스텝 %d: 낮은 안정성 (%.2f), 중단",
                        i, pred.predicted_stability,
                    )
                    break

            return predictions

        def evaluate_prediction_accuracy(
            self,
            test_data: List[Dict[str, Any]],
        ) -> Dict[str, float]:
            """
            예측 정확도 평가 / Evaluate prediction accuracy on test data.

            Args:
                test_data: List of dicts with state, action, next_state, outcome

            Returns:
                Dictionary of evaluation metrics
            """
            if not test_data:
                return {"status": "no_data"}

            stability_errors = []
            slip_errors = []
            terrain_correct = 0
            force_errors = []

            self._net.eval()

            with torch.no_grad():
                for sample in test_data:
                    state = sample["state"]
                    action = sample["action"]
                    outcome = sample.get("outcome", {})

                    # Get prediction
                    if isinstance(state, PhysicalState):
                        state_vec = state.to_vector()
                    else:
                        state_vec = np.asarray(state, dtype=np.float64).flatten()

                    if isinstance(action, PhysicalAction):
                        action_vec = action.to_vector()
                    else:
                        action_vec = np.asarray(action, dtype=np.float64).flatten()

                    state_t = torch.FloatTensor(state_vec).unsqueeze(0).to(self._device)
                    action_t = torch.FloatTensor(action_vec).unsqueeze(0).to(self._device)

                    preds = self._net(state_t, action_t)

                    # Compare
                    actual_stability = float(outcome.get("stability", 0.5))
                    pred_stability = float(preds["stability"].squeeze().cpu())
                    stability_errors.append(abs(pred_stability - actual_stability))

                    actual_slip = float(outcome.get("slip", 0.0))
                    pred_slip = float(preds["slip_prob"].squeeze().cpu())
                    slip_errors.append(abs(pred_slip - actual_slip))

                    actual_terrain = int(outcome.get("terrain_class", 0))
                    pred_terrain = int(preds["terrain_logits"].squeeze().argmax().cpu())
                    if pred_terrain == actual_terrain:
                        terrain_correct += 1

                    actual_forces = np.asarray(
                        outcome.get("contact_forces", np.zeros(16)), dtype=np.float64
                    ).flatten()[:16]
                    pred_forces = preds["force_pred"].squeeze().cpu().numpy()[:16]
                    if len(actual_forces) == len(pred_forces):
                        force_errors.append(float(np.mean((actual_forces - pred_forces) ** 2)))

            n = len(test_data)
            metrics = {
                "n_samples": n,
                "stability_mae": round(float(np.mean(stability_errors)), 4),
                "slip_mae": round(float(np.mean(slip_errors)), 4),
                "terrain_accuracy": round(terrain_correct / max(1, n), 4),
                "force_mse": round(float(np.mean(force_errors)) if force_errors else 0.0, 4),
            }

            logger.info(
                "평가 결과: stability_mae=%.4f, slip_mae=%.4f, "
                "terrain_acc=%.4f, force_mse=%.4f (%d 샘플)",
                metrics["stability_mae"], metrics["slip_mae"],
                metrics["terrain_accuracy"], metrics["force_mse"], n,
            )

            return metrics

        def save_checkpoint(self, path: Union[str, Path]) -> None:
            """체크포인트 저장 / Save checkpoint."""
            self._trainer.save_checkpoint(path)

        def load_checkpoint(self, path: Union[str, Path]) -> None:
            """체크포인트 로드 / Load checkpoint."""
            self._trainer.load_checkpoint(path)

        def get_stats(self) -> Dict[str, Any]:
            """통계 반환 / Return statistics."""
            fallback_stats = self._fallback_model.get_stats()
            return {
                "pytorch_available": True,
                "device": str(self._device),
                "training_steps": self._trainer.step_count,
                "model_parameters": sum(
                    p.numel() for p in self._net.parameters()
                ),
                "fallback_stats": fallback_stats,
            }

else:
    # ── PyTorch 미가용 시 폴백 / Fallback when PyTorch is not available ──

    class NeuralWorldModel:  # type: ignore[no-redef]
        """
        PyTorch 미가용 시 NeuralWorldModel 폴백 / Fallback NeuralWorldModel without PyTorch.

        PyTorch가 설치되지 않은 환경에서는 numpy 기반 PhysicalWorldModel을
        래핑하여 동일한 인터페이스를 제공합니다.
        """

        def __init__(
            self,
            device: str = "cuda",
            lr: float = 1e-3,
            checkpoint_path: Optional[Union[str, Path]] = None,
        ) -> None:
            self._model = PhysicalWorldModel()
            logger.warning(
                "PyTorch 미설치 — NeuralWorldModel이 numpy 기반으로 동작합니다. "
                "실제 신경망 학습을 위해 PyTorch를 설치하세요."
            )

        def predict_next(
            self, state: PhysicalState, action: PhysicalAction
        ) -> PhysicalPrediction:
            return self._model.predict_next(state, action)

        def train_on_experience(
            self, experiences: List[Dict[str, Any]]
        ) -> Dict[str, float]:
            return self._model.train_on_experience(experiences)

        def train_online(
            self,
            state: PhysicalState,
            action: PhysicalAction,
            next_state: PhysicalState,
            stability: float = 0.5,
            slip: float = 0.0,
            terrain_class: int = 0,
            contact_forces: Optional[np.ndarray] = None,
        ) -> Dict[str, float]:
            experience = {
                "state": state.to_vector(),
                "action": action.to_vector(),
                "next_state": next_state.to_vector(),
                "outcome": {
                    "stability": stability,
                    "slip": slip,
                    "terrain_class": terrain_class,
                    "contact_forces": contact_forces if contact_forces is not None else np.zeros(16),
                },
            }
            return self._model.train_on_experience([experience])

        def simulate_trajectory(
            self,
            initial_state: PhysicalState,
            action_sequence: List[PhysicalAction],
            n_steps: int = 10,
        ) -> List[PhysicalPrediction]:
            return self._model.predict_trajectory(
                initial_state, action_sequence, horizon=n_steps
            )

        def evaluate_prediction_accuracy(
            self, test_data: List[Dict[str, Any]]
        ) -> Dict[str, float]:
            return {"status": "pytorch_not_available", "n_samples": len(test_data)}

        def save_checkpoint(self, path: Union[str, Path]) -> None:
            logger.warning("PyTorch 미설치 — 체크포인트 저장 불가")

        def load_checkpoint(self, path: Union[str, Path]) -> None:
            logger.warning("PyTorch 미설치 — 체크포인트 로드 불가")

        def get_stats(self) -> Dict[str, Any]:
            return {
                "pytorch_available": False,
                "fallback_stats": self._model.get_stats(),
            }



# ─── V8.5 JEPA 신경망 세계 모델 / V8.5 JEPA Neural World Model ──────────────


class NeuralWorldModel:
    """
    V8.5 JEPA 신경망 세계 모델 / V8.5 JEPA Neural World Model.

    Joint-Embedding Predictive Architecture (JEPA) 스타일 세계 모델.
    현재 잠재 상태와 행동 잠재 표현으로부터 다음 잠재 상태를 예측합니다.
    PyTorch를 사용한 실제 신경망 학습을 수행하며, PyTorch가 없으면
    numpy 기반 폴백으로 동작합니다.

    Architecture:
        StateEncoder:    physical_state (62-dim) → latent (128-dim)
        ActionEncoder:   action (16-dim)          → action_latent (64-dim)
        TransitionModel: latent(128) + action_latent(64) → next_latent (128)
        StateDecoder:    latent (128-dim)          → predicted_state (62-dim)
        RewardHead:      latent (128-dim)          → scalar reward
        UncertaintyHead: latent (128-dim)          → uncertainty estimate

    Usage:
        model = NeuralWorldModel()
        prediction = model.predict_next(state, action)
        model.train_online(state, action, next_state)
        uncertainty = model.get_uncertainty(state)
    """

    # ── 차원 상수 / Dimension constants ──
    STATE_DIM: int = 62
    ACTION_DIM: int = 16      # 압축된 행동 표현 차원
    LATENT_DIM: int = 128
    ACTION_LATENT_DIM: int = 64
    REPLAY_CAPACITY: int = 50000
    BATCH_SIZE: int = 32
    LEARNING_RATE: float = 1e-3

    def __init__(
        self,
        device: str = "auto",
        lr: Optional[float] = None,
        replay_capacity: Optional[int] = None,
    ) -> None:
        self._device_str = device
        self._lr = lr if lr is not None else self.LEARNING_RATE
        self._replay_capacity = replay_capacity if replay_capacity is not None else self.REPLAY_CAPACITY

        # 경험 리플레이 버퍼 / Experience replay buffer
        self._replay_buffer: Deque[Dict[str, np.ndarray]] = deque(maxlen=self._replay_capacity)
        self._buffer_lock = threading.Lock()

        # 학습 상태 / Training state
        self._step_count: int = 0
        self._loss_history: Deque[float] = deque(maxlen=1000)
        self._initialized: bool = False

        # PyTorch 가용성에 따른 초기화 / Initialize based on PyTorch availability
        self._use_pytorch: bool = _HAS_TORCH
        self._nets: Dict[str, Any] = {}
        self._optimizer = None
        self._scheduler = None

        if _HAS_TORCH:
            self._init_pytorch()
        else:
            self._init_numpy_fallback()

        self._initialized = True
        mode_str = "PyTorch" if self._use_pytorch else "numpy-fallback"
        logger.info(
            "NeuralWorldModel (JEPA) 초기화: mode=%s, state_dim=%d, action_dim=%d, "
            "latent_dim=%d, action_latent_dim=%d",
            mode_str, self.STATE_DIM, self.ACTION_DIM,
            self.LATENT_DIM, self.ACTION_LATENT_DIM,
        )

    # ── PyTorch 초기화 / PyTorch initialization ──────────────────────────

    def _init_pytorch(self) -> None:
        """PyTorch 신경망 모듈 생성 / Build PyTorch neural modules."""
        assert torch is not None and nn is not None  # for type checker

        if self._device_str == "auto":
            self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self._device = torch.device(self._device_str)

        # StateEncoder: 62 → 128
        self._nets["state_encoder"] = nn.Sequential(
            nn.Linear(self.STATE_DIM, 256),
            nn.LayerNorm(256),
            nn.GELU(),
            nn.Linear(256, self.LATENT_DIM),
            nn.LayerNorm(self.LATENT_DIM),
        ).to(self._device)

        # ActionEncoder: 16 → 64
        self._nets["action_encoder"] = nn.Sequential(
            nn.Linear(self.ACTION_DIM, 128),
            nn.LayerNorm(128),
            nn.GELU(),
            nn.Linear(128, self.ACTION_LATENT_DIM),
            nn.LayerNorm(self.ACTION_LATENT_DIM),
        ).to(self._device)

        # TransitionModel: (128 + 64) → 128
        self._nets["transition_model"] = nn.Sequential(
            nn.Linear(self.LATENT_DIM + self.ACTION_LATENT_DIM, 256),
            nn.LayerNorm(256),
            nn.GELU(),
            nn.Linear(256, 256),
            nn.GELU(),
            nn.Linear(256, self.LATENT_DIM),
        ).to(self._device)

        # StateDecoder: 128 → 62
        self._nets["state_decoder"] = nn.Sequential(
            nn.Linear(self.LATENT_DIM, 256),
            nn.GELU(),
            nn.Linear(256, self.STATE_DIM),
        ).to(self._device)

        # RewardHead: 128 → 1
        self._nets["reward_head"] = nn.Sequential(
            nn.Linear(self.LATENT_DIM, 64),
            nn.GELU(),
            nn.Linear(64, 1),
        ).to(self._device)

        # UncertaintyHead: 128 → 1
        self._nets["uncertainty_head"] = nn.Sequential(
            nn.Linear(self.LATENT_DIM, 64),
            nn.GELU(),
            nn.Linear(64, 1),
            nn.Softplus(),  # uncertainty 는 항상 양수
        ).to(self._device)

        # JEPA 예측 손실: 잠재 공간에서의 예측 오차
        # JEPA predictive loss: prediction error in latent space

        # Optimizer (모든 네트워크 파라미터 통합)
        all_params = []
        for net in self._nets.values():
            all_params.extend(list(net.parameters()))
        self._optimizer = AdamW(all_params, lr=self._lr, weight_decay=1e-4)
        self._scheduler = CosineAnnealingLR(self._optimizer, T_max=10000, eta_min=1e-5)

    # ── Numpy 폴백 초기화 / Numpy fallback initialization ────────────────

    def _init_numpy_fallback(self) -> None:
        """PyTorch 미가용 시 numpy 기반 폴백 초기화 / Numpy fallback without PyTorch."""
        def _xavier(rows: int, cols: int) -> np.ndarray:
            return np.random.randn(rows, cols) * np.sqrt(2.0 / (rows + cols))

        self._np_state_enc_W = _xavier(self.STATE_DIM, self.LATENT_DIM)
        self._np_state_enc_b = np.zeros(self.LATENT_DIM)

        self._np_action_enc_W = _xavier(self.ACTION_DIM, self.ACTION_LATENT_DIM)
        self._np_action_enc_b = np.zeros(self.ACTION_LATENT_DIM)

        trans_in = self.LATENT_DIM + self.ACTION_LATENT_DIM
        self._np_trans_W1 = _xavier(trans_in, 256)
        self._np_trans_b1 = np.zeros(256)
        self._np_trans_W2 = _xavier(256, self.LATENT_DIM)
        self._np_trans_b2 = np.zeros(self.LATENT_DIM)

        self._np_dec_W = _xavier(self.LATENT_DIM, self.STATE_DIM)
        self._np_dec_b = np.zeros(self.STATE_DIM)

        self._np_reward_W = _xavier(self.LATENT_DIM, 1)
        self._np_reward_b = np.zeros(1)

        self._np_unc_W = _xavier(self.LATENT_DIM, 1)
        self._np_unc_b = np.zeros(1)

        logger.info("NeuralWorldModel: numpy 폴백 모드로 초기화됨")

    # ── 인코딩 / Encoding ────────────────────────────────────────────────

    def _encode_state(self, state_vec: np.ndarray) -> Any:
        """상태 벡터를 잠재 공간으로 인코딩 / Encode state vector to latent."""
        if self._use_pytorch:
            assert torch is not None
            x = torch.FloatTensor(state_vec).unsqueeze(0).to(self._device)
            with torch.no_grad():
                z = self._nets["state_encoder"](x)
            return z.squeeze(0)
        else:
            x = state_vec.flatten()[:self.STATE_DIM]
            h = np.maximum(0, x @ self._np_state_enc_W + self._np_state_enc_b)
            return h

    def _encode_action(self, action_vec: np.ndarray) -> Any:
        """행동 벡터를 잠재 공간으로 인코딩 / Encode action vector to latent."""
        if self._use_pytorch:
            assert torch is not None
            x = torch.FloatTensor(action_vec).unsqueeze(0).to(self._device)
            with torch.no_grad():
                z = self._nets["action_encoder"](x)
            return z.squeeze(0)
        else:
            x = action_vec.flatten()[:self.ACTION_DIM]
            h = np.maximum(0, x @ self._np_action_enc_W + self._np_action_enc_b)
            return h

    def _predict_transition(self, state_latent: Any, action_latent: Any) -> Any:
        """잠재 상태 + 행동 잠재 → 다음 잠재 상태 / Predict next latent from latents."""
        if self._use_pytorch:
            assert torch is not None
            if state_latent.dim() == 1:
                state_latent = state_latent.unsqueeze(0)
            if action_latent.dim() == 1:
                action_latent = action_latent.unsqueeze(0)
            combined = torch.cat([state_latent, action_latent], dim=-1)
            with torch.no_grad():
                next_z = self._nets["transition_model"](combined)
            return next_z.squeeze(0)
        else:
            combined = np.concatenate([state_latent, action_latent])
            h = np.maximum(0, combined @ self._np_trans_W1 + self._np_trans_b1)
            next_z = h @ self._np_trans_W2 + self._np_trans_b2
            return next_z

    def _decode_state(self, latent: Any) -> np.ndarray:
        """잠재 상태 → 예측 상태 벡터 / Decode latent to predicted state."""
        if self._use_pytorch:
            assert torch is not None
            if latent.dim() == 1:
                latent = latent.unsqueeze(0)
            with torch.no_grad():
                pred = self._nets["state_decoder"](latent)
            return pred.squeeze(0).cpu().numpy()
        else:
            return latent @ self._np_dec_W + self._np_dec_b

    def _predict_reward(self, latent: Any) -> float:
        """잠재 상태 → 보상 예측 / Predict reward from latent."""
        if self._use_pytorch:
            assert torch is not None
            if latent.dim() == 1:
                latent = latent.unsqueeze(0)
            with torch.no_grad():
                r = self._nets["reward_head"](latent)
            return float(r.squeeze().cpu().item())
        else:
            return float((latent @ self._np_reward_W + self._np_reward_b).item())

    def _predict_uncertainty(self, latent: Any) -> float:
        """잠재 상태 → 불확실성 예측 / Predict uncertainty from latent."""
        if self._use_pytorch:
            assert torch is not None
            if latent.dim() == 1:
                latent = latent.unsqueeze(0)
            with torch.no_grad():
                u = self._nets["uncertainty_head"](latent)
            return float(u.squeeze().cpu().item())
        else:
            return float(np.softplus(latent @ self._np_unc_W + self._np_unc_b).item())

    # ── 행동 벡터 준비 / Prepare action vector ───────────────────────────

    def _prepare_action_vec(self, action: Any) -> np.ndarray:
        """다양한 행동 입력을 16-dim 벡터로 변환 / Convert various action inputs to 16-dim."""
        if action is None:
            return np.zeros(self.ACTION_DIM)
        if isinstance(action, PhysicalAction):
            full_vec = action.to_vector()
            # 32-dim → 16-dim 압축 (짝수 인덱스 + 홀수 인덱스 평균)
            if len(full_vec) >= self.ACTION_DIM:
                return full_vec[:self.ACTION_DIM]
            else:
                padded = np.zeros(self.ACTION_DIM)
                padded[:len(full_vec)] = full_vec
                return padded
        if isinstance(action, np.ndarray):
            vec = action.flatten()
            if len(vec) >= self.ACTION_DIM:
                return vec[:self.ACTION_DIM]
            padded = np.zeros(self.ACTION_DIM)
            padded[:len(vec)] = vec
            return padded
        # dict, list, tuple 등 / dict, list, tuple etc.
        try:
            vec = np.asarray(action, dtype=np.float64).flatten()
            if len(vec) >= self.ACTION_DIM:
                return vec[:self.ACTION_DIM]
            padded = np.zeros(self.ACTION_DIM)
            padded[:len(vec)] = vec
            return padded
        except Exception:
            return np.zeros(self.ACTION_DIM)

    def _prepare_state_vec(self, state: Any) -> np.ndarray:
        """다양한 상태 입력을 62-dim 벡터로 변환 / Convert various state inputs to 62-dim."""
        if state is None:
            return np.zeros(self.STATE_DIM)
        if isinstance(state, PhysicalState):
            return state.to_vector()
        if isinstance(state, np.ndarray):
            vec = state.flatten()
            if len(vec) >= self.STATE_DIM:
                return vec[:self.STATE_DIM]
            padded = np.zeros(self.STATE_DIM)
            padded[:len(vec)] = vec
            return padded
        try:
            vec = np.asarray(state, dtype=np.float64).flatten()
            if len(vec) >= self.STATE_DIM:
                return vec[:self.STATE_DIM]
            padded = np.zeros(self.STATE_DIM)
            padded[:len(vec)] = vec
            return padded
        except Exception:
            return np.zeros(self.STATE_DIM)

    # ── 공개 메서드 / Public methods ──────────────────────────────────────

    def predict_next(
        self,
        state: Any,
        action: Any,
    ) -> Dict[str, Any]:
        """
        다음 상태 예측 / Predict next state from current state and action.

        Args:
            state: 현재 상태 (PhysicalState, ndarray, None)
            action: 행동 (PhysicalAction, ndarray, None)

        Returns:
            예측 결과 딕셔너리 / Prediction result dictionary
        """
        state_vec = self._prepare_state_vec(state)
        action_vec = self._prepare_action_vec(action)

        state_latent = self._encode_state(state_vec)
        action_latent = self._encode_action(action_vec)
        next_latent = self._predict_transition(state_latent, action_latent)

        predicted_state_vec = self._decode_state(next_latent)
        reward = self._predict_reward(next_latent)
        uncertainty = self._predict_uncertainty(next_latent)

        # PhysicalState 객체로 복원 시도 / Try to reconstruct PhysicalState
        predicted_next_state = None
        try:
            predicted_next_state = PhysicalState.from_vector(predicted_state_vec)
        except Exception:
            pass

        return {
            "predicted_next_state": predicted_next_state,
            "predicted_state_vec": predicted_state_vec,
            "predicted_reward": reward,
            "predicted_uncertainty": uncertainty,
            "state_latent_norm": float(
                np.linalg.norm(
                    state_latent.cpu().numpy() if self._use_pytorch and torch is not None
                    else state_latent
                )
            ),
        }

    def train_online(
        self,
        state: Any,
        action: Any,
        next_state: Any,
    ) -> Dict[str, float]:
        """
        온라인 학습: 단일 전이 경험으로 모델 갱신 / Online training on a single transition.

        main.py에서 None 인수로 호출될 수 있으므로 None을 안전하게 처리합니다.
        Handles None args gracefully since main.py may call with None.

        Args:
            state: 현재 상태 (None 허용)
            action: 행동 (None 허용)
            next_state: 다음 상태 (None 허용)

        Returns:
            학습 메트릭 / Training metrics
        """
        # None 인수 처리 / Handle None arguments
        if state is None and action is None and next_state is None:
            logger.debug("NeuralWorldModel.train_online: 모든 인수가 None — 학습 건너뜀")
            return {"status": "skipped_no_data", "loss": 0.0}

        state_vec = self._prepare_state_vec(state)
        action_vec = self._prepare_action_vec(action)
        next_state_vec = self._prepare_state_vec(next_state)

        # 리플레이 버퍼에 저장 / Store in replay buffer
        with self._buffer_lock:
            self._replay_buffer.append({
                "state": state_vec,
                "action": action_vec,
                "next_state": next_state_vec,
            })

        # 버퍼가 충분히 차지 않으면 학습하지 않음 / Don't train until buffer is large enough
        if len(self._replay_buffer) < self.BATCH_SIZE:
            return {"status": "buffering", "buffer_size": len(self._replay_buffer)}

        # 미니배치 학습 / Mini-batch training
        if self._use_pytorch:
            return self._train_pytorch_batch()
        else:
            return self._train_numpy_step(state_vec, action_vec, next_state_vec)

    def _train_pytorch_batch(self) -> Dict[str, float]:
        """PyTorch 기반 미니배치 학습 / PyTorch-based mini-batch training."""
        assert torch is not None and nn is not None and F is not None

        # 리플레이 버퍼에서 미니배치 샘플링 / Sample mini-batch from replay buffer
        with self._buffer_lock:
            indices = np.random.choice(
                len(self._replay_buffer),
                size=min(self.BATCH_SIZE, len(self._replay_buffer)),
                replace=False,
            )
            batch = [self._replay_buffer[i] for i in indices]

        states = torch.FloatTensor(np.stack([b["state"] for b in batch])).to(self._device)
        actions = torch.FloatTensor(np.stack([b["action"] for b in batch])).to(self._device)
        next_states = torch.FloatTensor(np.stack([b["next_state"] for b in batch])).to(self._device)

        # Forward pass
        self._optimizer.zero_grad()

        # JEPA: 현재 잠재 상태 예측
        state_z = self._nets["state_encoder"](states)
        action_z = self._nets["action_encoder"](actions)
        combined = torch.cat([state_z, action_z], dim=-1)
        pred_next_z = self._nets["transition_model"](combined)

        # 실제 다음 상태의 잠재 표현 (target)
        with torch.no_grad():
            target_next_z = self._nets["state_encoder"](next_states)

        # ── 손실 계산 / Loss computation ──

        # 1. JEPA 잠재 예측 손실 (코사인 + MSE)
        jepa_mse = F.mse_loss(pred_next_z, target_next_z)
        cosine_sim = F.cosine_similarity(pred_next_z, target_next_z, dim=-1)
        jepa_cosine = (1.0 - cosine_sim).mean()
        loss_jepa = jepa_mse + 0.5 * jepa_cosine

        # 2. 상태 복원 손실
        pred_state = self._nets["state_decoder"](pred_next_z)
        loss_reconstruction = F.mse_loss(pred_state, next_states)

        # 3. 보상 예측 손실 (임시: 상태 변화량 기반)
        state_delta = next_states - states
        implicit_reward = -torch.norm(state_delta, dim=-1, keepdim=True) * 0.01
        pred_reward = self._nets["reward_head"](pred_next_z)
        loss_reward = F.mse_loss(pred_reward, implicit_reward)

        # 총 손실
        total_loss = loss_jepa + 0.5 * loss_reconstruction + 0.1 * loss_reward

        # Backward + Update
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(
            [p for net in self._nets.values() for p in net.parameters()],
            max_norm=1.0,
        )
        self._optimizer.step()
        if self._scheduler is not None:
            self._scheduler.step()

        self._step_count += 1
        loss_val = float(total_loss.item())
        self._loss_history.append(loss_val)

        return {
            "loss": loss_val,
            "jepa_loss": float(loss_jepa.item()),
            "reconstruction_loss": float(loss_reconstruction.item()),
            "reward_loss": float(loss_reward.item()),
            "step": self._step_count,
        }

    def _train_numpy_step(
        self,
        state_vec: np.ndarray,
        action_vec: np.ndarray,
        next_state_vec: np.ndarray,
    ) -> Dict[str, float]:
        """Numpy 기반 단일 스텝 학습 / Numpy-based single step training."""
        # 순전파 / Forward pass
        state_z = np.maximum(0, state_vec @ self._np_state_enc_W + self._np_state_enc_b)
        action_z = np.maximum(0, action_vec @ self._np_action_enc_W + self._np_action_enc_b)
        combined = np.concatenate([state_z, action_z])
        h = np.maximum(0, combined @ self._np_trans_W1 + self._np_trans_b1)
        pred_next_z = h @ self._np_trans_W2 + self._np_trans_b2

        # 타겟
        target_z = np.maximum(0, next_state_vec @ self._np_state_enc_W + self._np_state_enc_b)

        # 손실 / Loss
        error = pred_next_z - target_z
        loss = float(np.mean(error ** 2))

        # 간단한 경사 하강 (온라인 SGD 근사)
        lr = self._lr * 0.01  # 작은 학습률
        self._np_trans_W2 -= lr * np.outer(h, error)
        self._np_trans_b2 -= lr * error

        self._step_count += 1
        self._loss_history.append(loss)

        return {"loss": loss, "step": self._step_count, "mode": "numpy"}

    def get_uncertainty(self, state: Any) -> float:
        """
        상태의 불확실성 추정 / Get uncertainty estimate for a state.

        Args:
            state: 물리적 상태 (PhysicalState, ndarray, None)

        Returns:
            불확실성 스칼라 값 / Uncertainty scalar value
        """
        state_vec = self._prepare_state_vec(state)
        latent = self._encode_state(state_vec)
        return self._predict_uncertainty(latent)

    def get_stats(self) -> Dict[str, Any]:
        """모델 통계 / Get model statistics."""
        return {
            "pytorch_available": self._use_pytorch,
            "device": str(self._device) if self._use_pytorch else "numpy",
            "step_count": self._step_count,
            "replay_buffer_size": len(self._replay_buffer),
            "avg_loss": float(np.mean(list(self._loss_history))) if self._loss_history else 0.0,
            "architecture": "JEPA",
            "latent_dim": self.LATENT_DIM,
            "action_latent_dim": self.ACTION_LATENT_DIM,
        }

    def save_checkpoint(self, path: Union[str, Path]) -> None:
        """체크포인트 저장 / Save model checkpoint."""
        if not self._use_pytorch:
            logger.warning("PyTorch 미설치 — 체크포인트 저장 불가")
            return
        assert torch is not None
        cp_path = Path(path)
        cp_path.parent.mkdir(parents=True, exist_ok=True)
        state_dicts = {name: net.state_dict() for name, net in self._nets.items()}
        torch.save({
            "nets": state_dicts,
            "optimizer": self._optimizer.state_dict() if self._optimizer else None,
            "scheduler": self._scheduler.state_dict() if self._scheduler else None,
            "step_count": self._step_count,
        }, str(cp_path))
        logger.info("NeuralWorldModel 체크포인트 저장: %s", cp_path)

    def load_checkpoint(self, path: Union[str, Path]) -> None:
        """체크포인트 로드 / Load model checkpoint."""
        if not self._use_pytorch:
            logger.warning("PyTorch 미설치 — 체크포인트 로드 불가")
            return
        assert torch is not None
        cp_path = Path(path)
        if not cp_path.exists():
            logger.warning("체크포인트 파일 없음: %s", cp_path)
            return
        checkpoint = torch.load(str(cp_path), map_location=self._device, weights_only=False)
        for name, state_dict in checkpoint.get("nets", {}).items():
            if name in self._nets:
                self._nets[name].load_state_dict(state_dict)
        if self._optimizer and checkpoint.get("optimizer"):
            self._optimizer.load_state_dict(checkpoint["optimizer"])
        if self._scheduler and checkpoint.get("scheduler"):
            self._scheduler.load_state_dict(checkpoint["scheduler"])
        self._step_count = checkpoint.get("step_count", 0)
        logger.info("NeuralWorldModel 체크포인트 로드: %s (step=%d)", cp_path, self._step_count)


# ============================================================================
# RSSM (Recurrent State Space Model) - DreamerV3-style Latent Dynamics
# 혁신: 하드코딩된 휴리스틱을 실제 학습 가능한 잠재 동역학 모델로 교체
# ============================================================================

class RSSMLayer(nn.Module):
    """Recurrent State Space Model - DreamerV3 스타일 잠재 동역학 모델
    
    물리적 AGI의 핵심: 세계의 물리적 상태를 잠재 공간에서 예측하고
    불확실성을 정량화하여 안전한 행동 계획을 가능하게 함.
    
    혁신 포인트:
    - 결정론적(deterministic) + 확률론적(stochastic) 상태 분리
    - 앙상블 예측으로 에피스템믹 불확실성 정량화
    - 미분 가능한 물리 사전 지식 통합 (F=ma 유도 편향)
    - 계층적 세계 모델 (느린 지형 수준 + 빠른 스텝 수준)
    """
    
    def __init__(self, state_dim=62, action_dim=32, latent_dim=256, 
                 hidden_dim=512, num_ensemble=5, stochastic_dim=32):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.latent_dim = latent_dim
        self.hidden_dim = hidden_dim
        self.num_ensemble = num_ensemble
        self.stochastic_dim = stochastic_dim
        
        # Encoder: 물리적 상태 → 잠재 공간
        self.state_encoder = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, latent_dim)
        )
        
        # Action encoder
        self.action_encoder = nn.Sequential(
            nn.Linear(action_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, latent_dim // 2)
        )
        
        # Deterministic path: GRU recurrent model
        self.gru_cell = nn.GRUCell(stochastic_dim + latent_dim // 2, latent_dim)
        
        # Stochastic prior: p(s_t | h_t) - prior distribution
        self.prior_net = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, stochastic_dim * 2)  # mean + log_std
        )
        
        # Stochastic posterior: q(s_t | h_t, o_t) - posterior with observation
        self.posterior_net = nn.Sequential(
            nn.Linear(latent_dim + latent_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, stochastic_dim * 2)  # mean + log_std
        )
        
        # Transition predictor: 잠재 상태 → 다음 물리적 상태
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim + stochastic_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, state_dim)
        )
        
        # Reward predictor (optional - for planning)
        self.reward_head = nn.Sequential(
            nn.Linear(latent_dim + stochastic_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 1)
        )
        
        # Continue predictor (episode termination)
        self.continue_head = nn.Sequential(
            nn.Linear(latent_dim + stochastic_dim, hidden_dim // 4),
            nn.GELU(),
            nn.Linear(hidden_dim // 4, 1),
            nn.Sigmoid()
        )
        
        # Physics-informed prior network (differentiable F=ma)
        self.physics_prior = DifferentiablePhysicsPrior(state_dim, action_dim, hidden_dim)
        
        # Ensemble members for epistemic uncertainty
        self.ensemble_transition = nn.ModuleList([
            nn.Sequential(
                nn.Linear(latent_dim + stochastic_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, latent_dim)
            ) for _ in range(num_ensemble)
        ])
        
        # Initialize weights
        self._init_weights()
    
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.zeros_(m.bias)
    
    def reparameterize(self, mean, log_std):
        """Reparameterization trick for differentiable sampling"""
        std = torch.exp(log_std.clamp(-5, 2))  # Prevent extreme values
        eps = torch.randn_like(std)
        return mean + std * eps
    
    def get_prior(self, deterministic_state):
        """사전 분포: h_t → s_t 분포 (행동 없이 예측)"""
        params = self.prior_net(deterministic_state)
        mean, log_std = params.chunk(2, dim=-1)
        log_std = torch.tanh(log_std)  # Bound log_std
        sample = self.reparameterize(mean, log_std)
        return mean, log_std, sample
    
    def get_posterior(self, deterministic_state, encoded_obs):
        """사후 분포: h_t, o_t → s_t 분포 (관찰로 보정)"""
        combined = torch.cat([deterministic_state, encoded_obs], dim=-1)
        params = self.posterior_net(combined)
        mean, log_std = params.chunk(2, dim=-1)
        log_std = torch.tanh(log_std)
        sample = self.reparameterize(mean, log_std)
        return mean, log_std, sample
    
    def forward(self, state, action, prev_deterministic=None, prev_stochastic=None):
        """단계 전이: (s_t, a_t, h_{t-1}) → (h_t, s_t, ŝ_{t+1})
        
        Args:
            state: 현재 물리적 상태 [batch, state_dim]
            action: 현재 행동 [batch, action_dim]
            prev_deterministic: 이전 결정론적 상태 [batch, latent_dim]
            prev_stochastic: 이전 확률론적 상태 [batch, stochastic_dim]
        
        Returns:
            dict with next state prediction, latent states, distributions
        """
        batch_size = state.shape[0]
        device = state.device
        
        if prev_deterministic is None:
            prev_deterministic = torch.zeros(batch_size, self.latent_dim, device=device)
        if prev_stochastic is None:
            prev_stochastic = torch.zeros(batch_size, self.stochastic_dim, device=device)
        
        # Encode current observation and action
        encoded_obs = self.state_encoder(state)
        encoded_act = self.action_encoder(action)
        
        # Deterministic state update via GRU
        gru_input = torch.cat([prev_stochastic, encoded_act], dim=-1)
        deterministic = self.gru_cell(gru_input, prev_deterministic)
        
        # Posterior: incorporate current observation
        post_mean, post_log_std, post_sample = self.get_posterior(deterministic, encoded_obs)
        
        # Prior: without observation (for planning/dreaming)
        prior_mean, prior_log_std, prior_sample = self.get_prior(deterministic)
        
        # Combine deterministic + stochastic for prediction
        latent_combined = torch.cat([deterministic, post_sample], dim=-1)
        
        # Decode to physical state prediction
        predicted_state = self.decoder(latent_combined)
        
        # Physics-informed correction
        physics_pred = self.physics_prior(state, action)
        predicted_state = predicted_state + 0.1 * (physics_pred - predicted_state).detach()
        
        # Reward prediction
        predicted_reward = self.reward_head(latent_combined)
        
        # Continue prediction
        predicted_continue = self.continue_head(latent_combined)
        
        # Ensemble predictions for uncertainty
        ensemble_preds = []
        for ens_net in self.ensemble_transition:
            ensemble_preds.append(ens_net(latent_combined))
        ensemble_preds = torch.stack(ensemble_preds, dim=0)  # [ensemble, batch, latent]
        epistemic_uncertainty = ensemble_preds.var(dim=0).mean(dim=-1)  # [batch]
        
        return {
            'predicted_state': predicted_state,
            'predicted_reward': predicted_reward,
            'predicted_continue': predicted_continue,
            'deterministic': deterministic,
            'posterior_mean': post_mean,
            'posterior_log_std': post_log_std,
            'posterior_sample': post_sample,
            'prior_mean': prior_mean,
            'prior_log_std': prior_log_std,
            'prior_sample': prior_sample,
            'epistemic_uncertainty': epistemic_uncertainty,
            'encoded_obs': encoded_obs,
        }
    
    def compute_loss(self, batch_states, batch_actions, beta=1.0, free_bits=1.0):
        """RSSM 학습 손실 함수
        
        L = L_reconstruction + β * KL(q||p) + L_reward + L_continue
        
        Args:
            batch_states: [seq_len, batch, state_dim]
            batch_actions: [seq_len, batch, action_dim]
            beta: KL 다이버전스 가중치 (free bits 적용)
            free_bits: KL 최소값 (posterior collapse 방지)
        """
        seq_len, batch_size = batch_states.shape[:2]
        device = batch_states.device
        
        total_recon_loss = 0
        total_kl_loss = 0
        total_reward_loss = 0
        total_continue_loss = 0
        
        prev_det = None
        prev_stoch = None
        
        for t in range(seq_len):
            result = self.forward(
                batch_states[t], batch_actions[t],
                prev_det, prev_stoch
            )
            
            # Reconstruction loss: MSE on predicted state
            recon_loss = F.mse_loss(result['predicted_state'], batch_states[t])
            total_recon_loss += recon_loss
            
            # KL divergence: KL(q(s_t|h_t,o_t) || p(s_t|h_t))
            kl = self._kl_divergence(
                result['posterior_mean'], result['posterior_log_std'],
                result['prior_mean'], result['prior_log_std']
            )
            # Free bits: prevent posterior collapse
            kl = torch.clamp(kl - free_bits, min=0) + free_bits
            total_kl_loss += kl.mean()
            
            # Reward loss (if available)
            # For now, use 0 reward as placeholder
            total_reward_loss += 0
            
            # Continue loss (if available)
            total_continue_loss += 0
            
            # Update recurrent state
            prev_det = result['deterministic'].detach()
            prev_stoch = result['posterior_sample'].detach()
        
        n = seq_len
        loss = (total_recon_loss / n + 
                beta * total_kl_loss / n + 
                total_reward_loss / n + 
                total_continue_loss / n)
        
        return {
            'total_loss': loss,
            'recon_loss': total_recon_loss / n,
            'kl_loss': total_kl_loss / n,
            'reward_loss': total_reward_loss / n,
            'continue_loss': total_continue_loss / n,
        }
    
    def _kl_divergence(self, q_mean, q_log_std, p_mean, p_log_std):
        """KL(q||p) for two diagonal Gaussians"""
        q_std = torch.exp(q_log_std)
        p_std = torch.exp(p_log_std)
        kl = (p_log_std - q_log_std + 
              (q_std.pow(2) + (q_mean - p_mean).pow(2)) / (2 * p_std.pow(2)) - 0.5)
        return kl.sum(dim=-1)
    
    def imagine(self, initial_state, policy_fn, horizon=10):
        """상상 롤아웃: 월드 모델 내에서 미래 시나리오 시뮬레이션
        
        Physical AGI 핵심 기능: 행동 전에 "이렇게 하면 어떻게 될까?"를
        시뮬레이션하여 최적의 행동을 선택.
        
        Args:
            initial_state: 초기 상태 [batch, state_dim]
            policy_fn: 상태 → 행동 함수
            horizon: 상상 시간 범위
        """
        imagined_states = [initial_state]
        imagined_rewards = []
        imagined_uncertainties = []
        
        prev_det = None
        prev_stoch = None
        current_state = initial_state
        
        for h in range(horizon):
            action = policy_fn(current_state)
            result = self.forward(current_state, action, prev_det, prev_stoch)
            
            imagined_states.append(result['predicted_state'])
            imagined_rewards.append(result['predicted_reward'])
            imagined_uncertainties.append(result['epistemic_uncertainty'])
            
            current_state = result['predicted_state'].detach()
            prev_det = result['deterministic'].detach()
            prev_stoch = result['posterior_sample'].detach()
        
        return {
            'states': torch.stack(imagined_states, dim=0),
            'rewards': torch.stack(imagined_rewards, dim=0),
            'uncertainties': torch.stack(imagined_uncertainties, dim=0),
        }


class DifferentiablePhysicsPrior(nn.Module):
    """미분 가능한 물리 사전 지식 네트워크
    
    뉴턴 역학(F=ma), 마찰 원뿔, 중력 등의 물리 법칙을
    신경망의 유도 편향(inductive bias)으로 통합.
    
    이것은 하드코딩된 물리 공식을 대체하는 것이 아니라,
    물리 법칙을 소프트 제약으로 학습에 주입하는 혁신적 방식.
    """
    
    def __init__(self, state_dim, action_dim, hidden_dim):
        super().__init__()
        # Physics-informed correction network
        self.correction_net = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, state_dim),
            nn.Tanh()  # Bounded corrections for stability
        )
        
        # Learnable physics constants
        self.gravity = nn.Parameter(torch.tensor(9.81))
        self.friction_scale = nn.Parameter(torch.tensor(1.0))
        self.damping = nn.Parameter(torch.tensor(0.1))
    
    def forward(self, state, action):
        """물리 사전 지식을 적용한 상태 예측
        
        기본: 관성 유지 (현재 상태)
        수정: 학습 가능한 물리 보정
        """
        # Inertial baseline: state persists
        physics_correction = self.correction_net(torch.cat([state, action], dim=-1))
        
        # Apply bounded physics correction
        predicted = state + self.damping * physics_correction
        
        return predicted


class HierarchicalWorldModel(nn.Module):
    """계층적 세계 모델: 느린 지형 수준 + 빠른 스텝 수준
    
    혁신: 두 가지 시간 척도에서 세계를 이해
    - 느린 모델: 지형 변화, 방 전환 (초 단위)
    - 빠른 모델: 스텝 안정성, 파지 조정 (밀리초 단위)
    """
    
    def __init__(self, state_dim=62, action_dim=32, latent_dim=256):
        super().__init__()
        self.slow_model = RSSMLayer(state_dim, action_dim, latent_dim, 
                                     num_ensemble=3, stochastic_dim=64)
        self.fast_model = RSSMLayer(state_dim, action_dim, latent_dim // 2,
                                     num_ensemble=5, stochastic_dim=32)
        
        # Cross-scale attention
        self.slow_proj = nn.Linear(latent_dim, latent_dim // 2)
        self.scale_attention = nn.MultiheadAttention(
            embed_dim=latent_dim // 2, num_heads=4, batch_first=True
        )
        
        # Fusion layer
        self.fusion = nn.Sequential(
            nn.Linear(latent_dim + latent_dim // 2, latent_dim),
            nn.GELU(),
            nn.Linear(latent_dim, state_dim)
        )
    
    def forward(self, state, action, slow_context=None, 
                prev_fast_det=None, prev_fast_stoch=None):
        """두 시간 척도의 융합 예측"""
        # Slow model: operates on lower frequency
        if slow_context is None:
            slow_result = self.slow_model(state, action)
            slow_context = slow_result['deterministic']
        
        # Fast model: operates on high frequency
        fast_result = self.fast_model(state, action, prev_fast_det, prev_fast_stoch)
        
        # Cross-scale attention: fast model attends to slow context
        slow_proj = self.slow_proj(slow_context)
        slow_expanded = slow_proj.unsqueeze(1)
        fast_det = fast_result['deterministic'].unsqueeze(1)
        attended, _ = self.scale_attention(fast_det, slow_expanded, slow_expanded)
        attended = attended.squeeze(1)
        
        # Fuse predictions
        fused_latent = torch.cat([slow_context, attended], dim=-1)
        fused_prediction = self.fusion(fused_latent)
        
        return {
            'predicted_state': fused_prediction,
            'slow_result': slow_result if slow_context is None else None,
            'fast_result': fast_result,
            'slow_context': slow_context,
        }


class WorldModelTrainer:
    """월드 모델 학습 파이프라인
    
    물리적 경험 데이터로 RSSM을 학습하는 엔드투엔드 파이프라인.
    시뮬레이션 사전 학습 → 실제 환경 미세조정 흐름 지원.
    """
    
    def __init__(self, model, lr=3e-4, weight_decay=1e-5, 
                 grad_clip=100.0, warmup_steps=1000):
        self.model = model
        self.optimizer = torch.optim.AdamW(
            model.parameters(), lr=lr, weight_decay=weight_decay
        )
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer, T_0=1000, T_mult=2
        )
        self.grad_clip = grad_clip
        self.warmup_steps = warmup_steps
        self.step_count = 0
        self.loss_history = []
    
    def train_step(self, batch_states, batch_actions):
        """단일 학습 스텝
        
        Args:
            batch_states: [seq_len, batch, state_dim]
            batch_actions: [seq_len, batch, action_dim]
        """
        self.model.train()
        self.optimizer.zero_grad()
        
        losses = self.model.compute_loss(batch_states, batch_actions)
        loss = losses['total_loss']
        
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
        self.optimizer.step()
        self.scheduler.step()
        
        self.step_count += 1
        self.loss_history.append({
            'step': self.step_count,
            **{k: v.item() if isinstance(v, torch.Tensor) else v 
               for k, v in losses.items()}
        })
        
        return losses


# ═══════════════════════════════════════════════════════════════════════════
# V8.5 Physical AGI 추가 클래스 / V8.5 Physical AGI Additional Classes
# ═══════════════════════════════════════════════════════════════════════════


class PhysicalCommonSense:
    """
    물리적 상식 인코딩 / Physical Common-Sense Knowledge Encoder.

    로봇이 기본적인 물리 지식을 인코딩하고 활용할 수 있게 합니다.
    중력, 마찰, 무게, 온도 효과, 재질 특성 등 일상적 물리 지식을
    구조화된 형태로 저장하고 추론에 활용합니다.

    Usage:
        commonsense = PhysicalCommonSense()
        result = commonsense.reason("push", object_mass=2.0, surface="ice")
    """

    # ─── 중력 지식 / Gravity Knowledge ────────────────────────────────────
    GRAVITY: float = 9.81  # m/s²

    # ─── 마찰계수 표 / Friction Coefficient Table ────────────────────────
    FRICTION_COEFFICIENTS: Dict[str, Tuple[float, float]] = {
        # (정지마찰계수, 운동마찰계수) / (static, kinetic)
        "rubber_on_concrete": (1.0, 0.8),
        "steel_on_steel": (0.74, 0.57),
        "rubber_on_ice": (0.15, 0.10),
        "wood_on_wood": (0.5, 0.3),
        "glass_on_glass": (0.94, 0.4),
        "teflon_on_teflon": (0.04, 0.04),
        "leather_on_metal": (0.6, 0.5),
        "plastic_on_wood": (0.4, 0.3),
        "wet_surface": (0.3, 0.2),
        "oily_surface": (0.1, 0.05),
    }

    # ─── 재질 특성 표 / Material Properties Table ────────────────────────
    MATERIAL_PROPERTIES: Dict[str, Dict[str, float]] = {
        "steel":      {"density_kg_m3": 7800, "young_modulus_gpa": 200, "melting_point_c": 1500, "fragility": 0.1, "elasticity": 0.3},
        "aluminum":   {"density_kg_m3": 2700, "young_modulus_gpa": 69,  "melting_point_c": 660,  "fragility": 0.1, "elasticity": 0.4},
        "glass":      {"density_kg_m3": 2500, "young_modulus_gpa": 70,  "melting_point_c": 1500, "fragility": 0.9, "elasticity": 0.05},
        "wood":       {"density_kg_m3": 600,  "young_modulus_gpa": 12,  "melting_point_c": 300,  "fragility": 0.3, "elasticity": 0.2},
        "plastic":    {"density_kg_m3": 1000, "young_modulus_gpa": 3,   "melting_point_c": 150,  "fragility": 0.4, "elasticity": 0.6},
        "rubber":     {"density_kg_m3": 1200, "young_modulus_gpa": 0.1, "melting_point_c": 180,  "fragility": 0.1, "elasticity": 0.95},
        "ceramic":    {"density_kg_m3": 3000, "young_modulus_gpa": 300, "melting_point_c": 2000, "fragility": 0.85, "elasticity": 0.02},
        "foam":       {"density_kg_m3": 50,   "young_modulus_gpa": 0.01,"melting_point_c": 100,  "fragility": 0.2, "elasticity": 0.8},
        "paper":      {"density_kg_m3": 800,  "young_modulus_gpa": 5,   "melting_point_c": 233,  "fragility": 0.6, "elasticity": 0.1},
        "fabric":     {"density_kg_m3": 400,  "young_modulus_gpa": 0.5, "melting_point_c": 260,  "fragility": 0.1, "elasticity": 0.7},
    }

    # ─── 온도 효과 규칙 / Temperature Effect Rules ──────────────────────
    TEMPERATURE_EFFECTS: Dict[str, Dict[str, Any]] = {
        "freeze":    {"below_c": 0,     "effect": "물이 얼음으로 변함", "friction_change": 0.3, "stiffness_change": 2.0},
        "boil":      {"above_c": 100,   "effect": "물이 끓음", "mass_loss_rate": 0.01},
        "soften":    {"above_c": 150,   "effect": "플라스틱이 연화됨", "stiffness_change": 0.1},
        "melt_metal":{"above_c": 660,   "effect": "알루미늄 녹음", "structural_integrity": 0.0},
        "brittle":   {"below_c": -20,   "effect": "플라스틱이 취성화됨", "fragility_change": 2.0},
        "expand":    {"per_c": 0.000012,"effect": "열팽창 (강철)", "length_change_per_c": 0.0012},
    }

    def __init__(self) -> None:
        self._learned_facts: Dict[str, Any] = {}
        self._lock = threading.Lock()
        logger.info("PhysicalCommonSense 초기화 완료 — 기본 물리 상식 로드됨")

    def reason(
        self,
        action: str,
        object_mass: float = 1.0,
        object_material: str = "plastic",
        surface: str = "wood_on_wood",
        temperature_c: float = 20.0,
        inclination_deg: float = 0.0,
    ) -> Dict[str, Any]:
        """
        물리적 상식으로 행동 결과 추론 / Reason about action outcome using physical common-sense.

        Args:
            action: 행동 유형 (push, lift, grip, drop, heat, etc.)
            object_mass: 물체 질량 (kg)
            object_material: 물체 재질
            surface: 표면 종류
            temperature_c: 온도 (°C)
            inclination_deg: 경사각 (도)

        Returns:
            추론 결과 딕셔너리
        """
        material_props = self.MATERIAL_PROPERTIES.get(object_material, {"fragility": 0.5, "elasticity": 0.3})
        friction_pair = self.FRICTION_COEFFICIENTS.get(surface, (0.5, 0.3))

        result: Dict[str, Any] = {
            "action": action,
            "object_mass_kg": object_mass,
            "object_material": object_material,
            "surface": surface,
            "temperature_c": temperature_c,
        }

        # ── 온도 효과 적용 / Apply temperature effects ──
        temp_mods = self._compute_temperature_effects(temperature_c, object_material)
        result["temperature_effects"] = temp_mods

        # ── 행동별 추론 / Per-action reasoning ──
        if action == "push":
            gravity_force = object_mass * self.GRAVITY
            normal_force = gravity_force * math.cos(math.radians(inclination_deg))
            max_static_friction = friction_pair[0] * normal_force
            slope_force = gravity_force * math.sin(math.radians(inclination_deg))
            result["max_push_force_before_slip"] = round(max_static_friction, 2)
            result["will_slide_on_slope"] = slope_force > max_static_friction
            result["kinetic_friction_force"] = round(friction_pair[1] * normal_force, 2)

        elif action == "lift":
            weight = object_mass * self.GRAVITY
            min_grip_force = weight / (2.0 * friction_pair[0] + 1e-6)
            result["weight_n"] = round(weight, 2)
            result["min_grip_force_n"] = round(min_grip_force, 2)
            result["recommended_grip_force_n"] = round(min_grip_force * 1.5, 2)
            result["crush_risk"] = material_props["fragility"] > 0.7

        elif action == "grip":
            weight = object_mass * self.GRAVITY
            min_force = weight / (2.0 * friction_pair[0] + 1e-6)
            result["min_grip_force_n"] = round(min_force, 2)
            result["object_fragility"] = material_props["fragility"]
            result["deformation_risk"] = material_props["elasticity"] > 0.5

        elif action == "drop":
            impact_velocity = math.sqrt(2 * self.GRAVITY * 1.0)  # 1m 낙하 가정
            impact_force = object_mass * impact_velocity / 0.01  # 10ms 감속
            result["impact_velocity_m_s"] = round(impact_velocity, 2)
            result["impact_force_n"] = round(impact_force, 2)
            result["will_break"] = material_props["fragility"] > 0.6 and impact_force > 50

        elif action == "heat":
            melting_point = material_props.get("melting_point_c", 1000)
            result["melting_point_c"] = melting_point
            result["will_melt"] = temperature_c >= melting_point
            result["thermal_deformation"] = temperature_c > melting_point * 0.7

        else:
            result["note"] = f"알 수 없는 행동: {action}"

        return result

    def _compute_temperature_effects(
        self, temperature_c: float, material: str
    ) -> Dict[str, Any]:
        """온도 효과 계산 / Compute temperature effects on materials."""
        effects: Dict[str, Any] = {}
        material_props = self.MATERIAL_PROPERTIES.get(material, {})

        if temperature_c <= 0:
            effects["water_state"] = "solid"
            effects["friction_modifier"] = 0.3
        elif temperature_c >= 100:
            effects["water_state"] = "gas"
            effects["friction_modifier"] = 0.9
        else:
            effects["water_state"] = "liquid"
            effects["friction_modifier"] = 0.7

        melting_point = material_props.get("melting_point_c", 1000)
        if temperature_c > melting_point * 0.8:
            effects["material_state"] = "near_melting"
            effects["stiffness_modifier"] = 0.3
        elif temperature_c < -20:
            effects["material_state"] = "brittle"
            effects["fragility_modifier"] = 2.0
        else:
            effects["material_state"] = "normal"
            effects["stiffness_modifier"] = 1.0

        return effects

    def add_learned_fact(self, key: str, value: Any) -> None:
        """학습된 물리 사실 추가 / Add a learned physical fact."""
        with self._lock:
            self._learned_facts[key] = value

    def get_learned_facts(self) -> Dict[str, Any]:
        """학습된 물리 사실 반환 / Return all learned physical facts."""
        with self._lock:
            return dict(self._learned_facts)


class CausalPhysicalReasoner:
    """
    인과적 물리 추론기 / Causal Physical Reasoner.

    물리적 원인과 결과를 추론합니다.
    "이것을 밀면 어떻게 될까?", "이것을 가열하면 녹을까?"와 같은
    인과적 질문에 답합니다.

    Usage:
        reasoner = CausalPhysicalReasoner()
        result = reasoner.reason_cause_effect("push_object", {"friction": 0.1, "mass": 5.0})
    """

    # 인과 규칙 라이브러리 / Causal rule library
    CAUSAL_RULES: List[Dict[str, Any]] = [
        {"cause": "applied_force > friction_force", "effect": "object_moves", "mechanism": "Newton's 2nd law"},
        {"cause": "applied_force <= friction_force", "effect": "object_stays", "mechanism": "static friction"},
        {"cause": "grip_force < weight/friction", "effect": "object_slips", "mechanism": "friction cone"},
        {"cause": "grip_force > crush_threshold", "effect": "object_deforms", "mechanism": "stress-strain"},
        {"cause": "temperature > melting_point", "effect": "material_melts", "mechanism": "phase transition"},
        {"cause": "temperature < freezing_point", "effect": "water_freezes", "mechanism": "phase transition"},
        {"cause": "center_of_mass_outside_support", "effect": "object_falls", "mechanism": "gravity torque"},
        {"cause": "impact_force > yield_strength", "effect": "object_breaks", "mechanism": "material failure"},
        {"cause": "torque_applied", "effect": "rotation", "mechanism": "τ = Iα"},
        {"cause": "vibration_frequency_resonant", "effect": "resonance_damage", "mechanism": "mechanical resonance"},
    ]

    def __init__(self) -> None:
        self._learned_rules: List[Dict[str, Any]] = []
        self._inference_history: Deque[Dict[str, Any]] = deque(maxlen=1000)
        logger.info("CausalPhysicalReasoner 초기화 완료")

    def reason_cause_effect(
        self, action: str, context: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        인과적 추론 수행 / Perform causal physical reasoning.

        Args:
            action: 행동 종류
            context: 물리적 컨텍스트 (마찰, 질량, 힘 등)

        Returns:
            인과 추론 결과
        """
        all_rules = self.CAUSAL_RULES + self._learned_rules
        matched: List[Dict[str, Any]] = []

        for rule in all_rules:
            if self._rule_matches(rule, action, context):
                confidence = self._compute_rule_confidence(rule, context)
                matched.append({
                    "rule": rule["cause"],
                    "effect": rule["effect"],
                    "mechanism": rule.get("mechanism", "unknown"),
                    "confidence": round(confidence, 3),
                })

        # 신뢰도 순 정렬 / Sort by confidence
        matched.sort(key=lambda x: x["confidence"], reverse=True)

        result = {
            "action": action,
            "context": context,
            "predicted_effects": matched[:5],
            "most_likely_effect": matched[0] if matched else None,
            "num_rules_checked": len(all_rules),
        }

        self._inference_history.append(result)
        return result

    def _rule_matches(
        self, rule: Dict[str, Any], action: str, context: Dict[str, float]
    ) -> bool:
        """규칙이 현재 상황에 매치되는지 확인 / Check if rule matches current situation."""
        cause = rule["cause"]

        # 힘 비교 규칙 / Force comparison rules
        if "applied_force > friction_force" in cause:
            return context.get("applied_force", 0) > context.get("friction_force", 0)
        if "applied_force <= friction_force" in cause:
            return context.get("applied_force", 0) <= context.get("friction_force", 0)
        if "grip_force < weight/friction" in cause:
            weight = context.get("weight", 10)
            friction = context.get("friction", 0.5)
            return context.get("grip_force", 0) < weight / (2 * friction + 1e-6)
        if "grip_force > crush_threshold" in cause:
            return context.get("grip_force", 0) > context.get("crush_threshold", 50)
        if "temperature > melting_point" in cause:
            return context.get("temperature", 20) > context.get("melting_point", 1000)
        if "temperature < freezing_point" in cause:
            return context.get("temperature", 20) < context.get("freezing_point", 0)
        if "center_of_mass_outside_support" in cause:
            return context.get("com_offset", 0) > context.get("support_width", 0.1) / 2
        if "impact_force > yield_strength" in cause:
            return context.get("impact_force", 0) > context.get("yield_strength", 100)

        # 키워드 기반 매칭 / Keyword-based matching
        action_keywords = action.lower().split("_")
        cause_keywords = cause.lower().replace(">", "").replace("<", "").replace("=", "").split()
        return bool(set(action_keywords) & set(cause_keywords))

    def _compute_rule_confidence(
        self, rule: Dict[str, Any], context: Dict[str, float]
    ) -> float:
        """규칙 신뢰도 계산 / Compute confidence for a matched rule."""
        base = 0.8  # 기본 신뢰도 / Base confidence

        # 컨텍스트 값이 극단적일수록 신뢰도 증가 / More extreme values → higher confidence
        cause = rule["cause"]
        if ">" in cause or "<" in cause:
            parts = cause.replace(">", "|").replace("<=", "|").replace("<", "|").split("|")
            if len(parts) >= 2:
                try:
                    lhs = float(context.get(parts[0].strip(), 0))
                    rhs_str = parts[1].strip()
                    if "/" in rhs_str:
                        num, den = rhs_str.split("/")
                        rhs = float(context.get(num.strip(), 1)) / (float(context.get(den.strip(), 1)) + 1e-6)
                    else:
                        rhs = float(context.get(rhs_str, 0))
                    margin = abs(lhs - rhs) / (abs(rhs) + 1e-6)
                    base = min(1.0, base + margin * 0.1)
                except (ValueError, ZeroDivisionError):
                    pass

        return base

    def add_causal_rule(self, cause: str, effect: str, mechanism: str = "learned") -> None:
        """학습된 인과 규칙 추가 / Add a learned causal rule."""
        self._learned_rules.append({
            "cause": cause, "effect": effect, "mechanism": mechanism,
        })
        logger.info("새 인과 규칙 학습: %s → %s (%s)", cause, effect, mechanism)


class VideoPredictionWorldModel:
    """
    비디오 예측 세계 모델 / Video Prediction World Model.

    비디오 관찰로부터 세계 동역학을 학습합니다.
    PyTorch가 사용 가능하면 신경망 기반, 아니면 numpy 기반 폴백을 사용합니다.

    Usage:
        vpm = VideoPredictionWorldModel()
        vpm.learn_from_frames(frames, actions)
        prediction = vpm.predict_next_frames(current_frames, planned_action)
    """

    def __init__(self, latent_dim: int = 64, sequence_length: int = 4) -> None:
        self._latent_dim = latent_dim
        self._seq_len = sequence_length
        self._frame_history: Deque[np.ndarray] = deque(maxlen=sequence_length)
        self._action_history: Deque[np.ndarray] = deque(maxlen=sequence_length)
        self._transition_matrix: Optional[np.ndarray] = None
        self._is_trained = False

        # PyTorch 모델 (가용 시) / PyTorch model (if available)
        self._torch_model = None
        if _HAS_TORCH:
            self._init_torch_model()

        logger.info(
            "VideoPredictionWorldModel 초기화: latent=%d, seq=%d, torch=%s",
            latent_dim, sequence_length, _HAS_TORCH,
        )

    def _init_torch_model(self) -> None:
        """PyTorch 비디오 예측 모델 초기화 / Initialize PyTorch video prediction model."""
        if not _HAS_TORCH:
            return

        class _VideoPredictor(nn.Module):
            """간소화된 비디오 예측 네트워크 / Simplified video prediction network."""
            def __init__(self, latent_dim: int, action_dim: int = 16):
                super().__init__()
                self.encoder = nn.Sequential(
                    nn.Linear(64 * 64 * 3, 512),
                    nn.ReLU(),
                    nn.Linear(512, latent_dim),
                )
                self.transition = nn.Sequential(
                    nn.Linear(latent_dim + action_dim, 256),
                    nn.ReLU(),
                    nn.Linear(256, latent_dim),
                )
                self.decoder = nn.Sequential(
                    nn.Linear(latent_dim, 512),
                    nn.ReLU(),
                    nn.Linear(512, 64 * 64 * 3),
                    nn.Sigmoid(),
                )

            def forward(self, frame_latent, action):
                z_next = self.transition(torch.cat([frame_latent, action], dim=-1))
                return self.decoder(z_next), z_next

        self._torch_model = _VideoPredictor(self._latent_dim)
        logger.info("PyTorch 비디오 예측 모델 초기화 완료")

    def learn_from_frames(
        self, frames: List[np.ndarray], actions: List[np.ndarray]
    ) -> Dict[str, Any]:
        """
        프레임 시퀀스로부터 세계 동역학 학습 / Learn world dynamics from frame sequences.

        Args:
            frames: 이미지 프레임 리스트 (각 H×W×3)
            actions: 각 프레임 전환 시의 행동 벡터

        Returns:
            학습 결과
        """
        if len(frames) < 2:
            return {"status": "insufficient_data"}

        # 프레임 특징 추출 / Extract frame features
        features = []
        for frame in frames:
            # 다운샘플링하여 특징 벡터 생성 / Downsample to feature vector
            h, w = frame.shape[:2]
            step_h, step_w = max(1, h // 8), max(1, w // 8)
            downsampled = frame[::step_h, ::step_w, :].flatten().astype(np.float64)
            if len(downsampled) > self._latent_dim:
                # PCA 근사: 처음 latent_dim 차원만 사용 / Approximate PCA
                downsampled = downsampled[:self._latent_dim]
            elif len(downsampled) < self._latent_dim:
                downsampled = np.pad(downsampled, (0, self._latent_dim - len(downsampled)))
            features.append(downsampled[:self._latent_dim])

        # 전이 행렬 추정 / Estimate transition matrix
        features_arr = np.array(features)
        actions_arr = np.array([a.flatten()[:16] for a in actions])
        # Pad actions if needed
        if actions_arr.shape[1] < 16:
            actions_arr = np.pad(actions_arr, ((0, 0), (0, 16 - actions_arr.shape[1])))

        X = np.hstack([features_arr[:-1], actions_arr[:-1][:len(features_arr)-1]])
        Y = features_arr[1:]

        if len(X) > 0 and len(Y) > 0:
            # 최소제곱법으로 전이 행렬 학습 / Learn transition via least squares
            try:
                self._transition_matrix = np.linalg.lstsq(X, Y, rcond=None)[0].T
                self._is_trained = True
            except np.linalg.LinAlgError:
                self._transition_matrix = np.random.randn(self._latent_dim, X.shape[1]) * 0.01

        # PyTorch 모델 학습 (가용 시) / Train PyTorch model (if available)
        if _HAS_TORCH and self._torch_model is not None:
            self._train_torch_model(features_arr, actions_arr)

        return {"status": "success", "n_frames": len(frames)}

    def _train_torch_model(
        self, features: np.ndarray, actions: np.ndarray, epochs: int = 10
    ) -> None:
        """PyTorch 모델 학습 / Train PyTorch video prediction model."""
        if not _HAS_TORCH or self._torch_model is None:
            return

        optimizer = torch.optim.Adam(self._torch_model.parameters(), lr=1e-3)

        for _ in range(epochs):
            for i in range(len(features) - 1):
                z_t = torch.tensor(features[i], dtype=torch.float32).unsqueeze(0)
                a_t = torch.tensor(actions[i], dtype=torch.float32).unsqueeze(0)
                if a_t.shape[1] < 16:
                    a_t = F.pad(a_t, (0, 16 - a_t.shape[1]))

                pred_frame, _ = self._torch_model(z_t, a_t)
                target = torch.tensor(features[i+1], dtype=torch.float32).unsqueeze(0)

                # 디코더 타겟 근사 / Approximate decoder target
                loss = F.mse_loss(pred_frame[:, :self._latent_dim], target)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

    def predict_next_frames(
        self, current_frames: List[np.ndarray], planned_action: np.ndarray
    ) -> np.ndarray:
        """
        다음 프레임 예측 / Predict next frames given current frames and planned action.

        Args:
            current_frames: 현재 프레임들
            planned_action: 계획된 행동

        Returns:
            예측된 다음 프레임 특징 벡터
        """
        if not current_frames:
            return np.zeros(self._latent_dim)

        # 마지막 프레임 특징 추출 / Extract last frame features
        frame = current_frames[-1]
        h, w = frame.shape[:2]
        step_h, step_w = max(1, h // 8), max(1, w // 8)
        downsampled = frame[::step_h, ::step_w, :].flatten().astype(np.float64)
        if len(downsampled) > self._latent_dim:
            downsampled = downsampled[:self._latent_dim]
        elif len(downsampled) < self._latent_dim:
            downsampled = np.pad(downsampled, (0, self._latent_dim - len(downsampled)))
        z_current = downsampled[:self._latent_dim]

        # 행동 벡터 정규화 / Normalize action vector
        a = planned_action.flatten()[:16]
        if len(a) < 16:
            a = np.pad(a, (0, 16 - len(a)))

        # 전이 예측 / Transition prediction
        if self._is_trained and self._transition_matrix is not None:
            x = np.concatenate([z_current, a])
            z_next = self._transition_matrix @ x
        else:
            # 폴백: 현재 상태 + 작은 변화 / Fallback: current state + small perturbation
            z_next = z_current + np.random.randn(self._latent_dim) * 0.01

        return z_next

    @property
    def is_trained(self) -> bool:
        return self._is_trained


class YouTubeVideoLearner:
    """
    YouTube 비디오 학습기 / YouTube Video Learner.

    YouTube 비디오에서 물리적 지식을 추출합니다.
    비디오의 시각적 관찰로부터 물리 법칙, 객체 상호작용,
    인과 관계를 학습합니다.

    주의: 실제 YouTube API 연동은 외부 의존성이 필요하므로,
    이 구현은 로컬 비디오 파일 처리를 기반으로 하며
    외부 API 연동 인터페이스를 제공합니다.

    Usage:
        learner = YouTubeVideoLearner()
        knowledge = learner.extract_physical_knowledge(video_frames, metadata)
    """

    def __init__(self, commonsense: Optional[PhysicalCommonSense] = None) -> None:
        self._commonsense = commonsense or PhysicalCommonSense()
        self._extracted_knowledge: List[Dict[str, Any]] = []
        self._physical_rules: List[Dict[str, Any]] = []
        logger.info("YouTubeVideoLearner 초기화 완료")

    def extract_physical_knowledge(
        self,
        video_frames: List[np.ndarray],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        비디오 프레임에서 물리적 지식 추출 / Extract physical knowledge from video frames.

        Args:
            video_frames: 비디오 프레임 리스트 (H×W×3 numpy arrays)
            metadata: 비디오 메타데이터 (제목, 설명, 태그 등)

        Returns:
            추출된 물리적 지식
        """
        if len(video_frames) < 2:
            return {"status": "insufficient_frames", "extracted_rules": 0}

        knowledge: Dict[str, Any] = {
            "status": "success",
            "n_frames": len(video_frames),
            "metadata": metadata or {},
            "extracted_rules": [],
            "object_interactions": [],
            "physical_events": [],
        }

        # 1. 프레임 간 변화 감지 / Detect inter-frame changes
        changes = self._detect_frame_changes(video_frames)

        # 2. 객체 궤적 추출 / Extract object trajectories
        trajectories = self._extract_trajectories(changes)
        knowledge["object_interactions"] = trajectories[:10]

        # 3. 물리적 이벤트 감지 / Detect physical events
        events = self._detect_physical_events(changes, trajectories)
        knowledge["physical_events"] = events[:10]

        # 4. 물리 규칙 추론 / Infer physical rules
        rules = self._infer_physical_rules(events, trajectories)
        knowledge["extracted_rules"] = rules[:10]
        self._physical_rules.extend(rules)

        # 5. 상식과 통합 / Integrate with common-sense
        for rule in rules:
            self._commonsense.add_learned_fact(
                f"video_rule_{len(self._extracted_knowledge)}",
                rule,
            )

        self._extracted_knowledge.append(knowledge)
        logger.info(
            "비디오에서 %d개 물리 규칙, %d개 이벤트 추출",
            len(rules), len(events),
        )
        return knowledge

    def _detect_frame_changes(
        self, frames: List[np.ndarray]
    ) -> List[Dict[str, Any]]:
        """프레임 간 변화 감지 / Detect changes between consecutive frames."""
        changes = []
        for i in range(1, len(frames)):
            prev = frames[i-1].astype(np.float64)
            curr = frames[i].astype(np.float64)

            # 프레임 차이 / Frame difference
            if prev.shape == curr.shape:
                diff = np.abs(curr - prev)
                avg_change = float(np.mean(diff))
                max_change = float(np.max(diff))
                changed_pixels = float(np.sum(diff > 30)) / diff.size

                # 변화 영역 감지 / Detect change regions
                if changed_pixels > 0.01:
                    changes.append({
                        "frame_idx": i,
                        "avg_change": round(avg_change, 2),
                        "max_change": round(max_change, 2),
                        "changed_fraction": round(changed_pixels, 3),
                        "change_magnitude": "large" if changed_pixels > 0.2 else "medium" if changed_pixels > 0.05 else "small",
                    })
        return changes

    def _extract_trajectories(
        self, changes: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """객체 궤적 추출 / Extract object trajectories from frame changes."""
        trajectories = []
        # 간소화된 궤적 추출 / Simplified trajectory extraction
        for i, change in enumerate(changes):
            if change["change_magnitude"] in ("large", "medium"):
                trajectories.append({
                    "start_frame": change["frame_idx"] - 1,
                    "end_frame": change["frame_idx"],
                    "type": "displacement" if change["changed_fraction"] < 0.5 else "scene_change",
                    "magnitude": change["avg_change"],
                })
        return trajectories

    def _detect_physical_events(
        self,
        changes: List[Dict[str, Any]],
        trajectories: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """물리적 이벤트 감지 / Detect physical events."""
        events = []
        for i in range(1, len(changes)):
            prev = changes[i-1]
            curr = changes[i]

            # 연속적 변화 = 운동 / Continuous change = motion
            if curr["change_magnitude"] != "small" and prev["change_magnitude"] != "small":
                events.append({
                    "type": "continuous_motion",
                    "frames": (prev["frame_idx"], curr["frame_idx"]),
                    "velocity_indicator": abs(curr["avg_change"] - prev["avg_change"]),
                })

            # 갑작스런 변화 = 충돌/파괴 / Sudden change = impact/break
            if curr["changed_fraction"] > prev["changed_fraction"] * 3:
                events.append({
                    "type": "sudden_impact",
                    "frame": curr["frame_idx"],
                    "intensity": curr["changed_fraction"],
                })

            # 변화 감소 = 정지 / Decreasing change = stopping
            if curr["avg_change"] < prev["avg_change"] * 0.5:
                events.append({
                    "type": "deceleration",
                    "frame": curr["frame_idx"],
                })

        return events

    def _infer_physical_rules(
        self,
        events: List[Dict[str, Any]],
        trajectories: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """물리 규칙 추론 / Infer physical rules from observed events."""
        rules = []

        # 충돌 후 속도 변화 → 반발 계수 / Velocity change after impact → restitution
        impacts = [e for e in events if e["type"] == "sudden_impact"]
        if impacts:
            rules.append({
                "rule": "objects_slow_down_after_impact",
                "evidence_count": len(impacts),
                "confidence": min(1.0, 0.5 + len(impacts) * 0.1),
                "source": "video_observation",
            })

        # 연속 운동 → 관성 / Continuous motion → inertia
        motions = [e for e in events if e["type"] == "continuous_motion"]
        if motions:
            rules.append({
                "rule": "objects_in_motion_stay_in_motion",
                "evidence_count": len(motions),
                "confidence": min(1.0, 0.5 + len(motions) * 0.05),
                "source": "video_observation",
            })

        # 감속 → 마찰 / Deceleration → friction
        decels = [e for e in events if e["type"] == "deceleration"]
        if decels:
            rules.append({
                "rule": "friction_causes_deceleration",
                "evidence_count": len(decels),
                "confidence": min(1.0, 0.5 + len(decels) * 0.1),
                "source": "video_observation",
            })

        return rules

    def get_learned_rules(self) -> List[Dict[str, Any]]:
        """학습된 물리 규칙 반환 / Return all learned physical rules."""
        return list(self._physical_rules)

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        return {
            "total_videos_processed": len(self._extracted_knowledge),
            "total_rules_extracted": len(self._physical_rules),
        }
