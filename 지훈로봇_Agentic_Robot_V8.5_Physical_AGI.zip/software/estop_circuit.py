#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 하드웨어 E-Stop 회로 제어 / Hardware E-Stop Circuit Control
============================================================================

TODO 44: EStopController 클래스 구현

버튼 스위치 → GPIO 인터럽트 → 모터 드라이버 EN 단자 LOW
회로: 10kΩ 풀업, NO (Normal Open) 스위치
50ms 모터 정지 on E-Stop 버튼 누름
복구: 버튼 해제 후 수동 리셋 필요 (자동 재시작 방지)

버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("jihun.v84.estop_circuit")
logger.setLevel(logging.INFO)


# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

ESTOP_GPIO_PIN = 17                # Jetson #1 GPIO_17 (BCM 번호)
MOTOR_ENABLE_PIN = 27              # 모터 드라이버 EN 핀
PULLUP_RESISTOR_OHM = 10000       # 10kΩ 풀업 저항
MOTOR_STOP_TARGET_MS = 50         # 모터 정지 목표 시간 (50ms)
DEBOUNCE_MS = 10                   # 디바운스 시간 (10ms)


@dataclass
class EStopState:
    """E-Stop 상태"""
    button_pressed: bool = False
    motor_power_enabled: bool = True
    estop_active: bool = False
    last_trigger_time: float = 0.0
    last_release_time: float = 0.0
    trigger_count: int = 0
    auto_restart_blocked: bool = True   # 자동 재시작 방지


# ──────────────────────────────────────────────────────────────────────────────
# E-Stop 컨트롤러 / E-Stop Controller
# ──────────────────────────────────────────────────────────────────────────────

class EStopController:
    """
    하드웨어 E-Stop 회로 제어 / Hardware E-Stop Circuit Control

    회로 구성:
    - 10kΩ 풀업 저항 → GPIO 핀 (HIGH = 정상)
    - NO (Normal Open) 버튼 스위치 → GND
    - 버튼 누름 → GPIO LOW → 인터럽트 발생

    동작:
    - 버튼 누름 → GPIO 인터럽트 → 모터 드라이버 EN 단자 LOW → 50ms 내 정지
    - 버튼 해제 → 수동 리셋 필요 (자동 재시작 방지)

    검증: E-Stop 버튼 누름 → 50ms 내 모터 정지
    """

    def __init__(
        self,
        estop_pin: int = ESTOP_GPIO_PIN,
        motor_enable_pin: int = MOTOR_ENABLE_PIN,
        simulate: bool = True,
    ) -> None:
        self._estop_pin = estop_pin
        self._motor_enable_pin = motor_enable_pin
        self._simulate = simulate

        self._state = EStopState()
        self._lock = threading.RLock()

        # GPIO 객체 (실제 환경)
        self._gpio: Optional[Any] = None

        # 콜백
        self._on_estop_callbacks: List[Callable] = []
        self._on_reset_callbacks: List[Callable] = []

        logger.info(
            f"E-Stop 컨트롤러 초기화: "
            f"핀={estop_pin}, 모터EN={motor_enable_pin}, "
            f"시뮬레이션={simulate}"
        )

    # ──────────────────────────────────────────────────────────────────────
    # setup_estop() — E-Stop 초기 설정
    # ──────────────────────────────────────────────────────────────────────

    def setup_estop(self) -> bool:
        """
        E-Stop GPIO 초기 설정

        - GPIO 핀을 입력으로 설정 (풀업)
        - 모터 EN 핀을 출력으로 설정 (HIGH = 활성)
        - 인터럽트 핸들러 등록 (FALLING EDGE)

        Returns:
            설정 성공 여부
        """
        if self._simulate:
            logger.info("E-Stop 시뮬레이션 모드 — GPIO 초기화 스킵")
            return True

        try:
            import RPi.GPIO as GPIO

            GPIO.setmode(GPIO.BCM)

            # E-Stop 핀: 입력 + 풀업
            GPIO.setup(
                self._estop_pin,
                GPIO.IN,
                pull_up_down=GPIO.PUD_UP,
            )

            # 모터 EN 핀: 출력 (HIGH = 모터 활성)
            GPIO.setup(self._motor_enable_pin, GPIO.OUT, initial=GPIO.HIGH)

            # 인터럽트 핸들러 등록 (FALLING EDGE = 버튼 누름)
            GPIO.add_event_detect(
                self._estop_pin,
                GPIO.FALLING,
                callback=self._handle_gpio_interrupt,
                bouncetime=DEBOUNCE_MS,
            )

            self._gpio = GPIO
            logger.info("E-Stop GPIO 설정 완료")
            return True

        except ImportError:
            logger.warning(
                "RPi.GPIO 미설치 — 시뮬레이션 모드로 전환"
            )
            self._simulate = True
            return True
        except Exception as e:
            logger.error(f"E-Stop GPIO 설정 오류: {e}")
            return False

    # ──────────────────────────────────────────────────────────────────────
    # handle_interrupt() — GPIO 인터럽트 핸들러
    # ──────────────────────────────────────────────────────────────────────

    def _handle_gpio_interrupt(self, channel: int) -> None:
        """
        GPIO 인터럽트 핸들러 — 버튼 누름 감지

        실제 하드웨어에서 GPIO FALLING EDGE 시 자동 호출됨
        시뮬레이션에서는 simulate_button_press()로 수동 호출
        """
        start_time = time.time()

        with self._lock:
            self._state.button_pressed = True
            self._state.estop_active = True
            self._state.last_trigger_time = start_time
            self._state.trigger_count += 1

        # 모터 전원 즉시 차단
        self.cut_motor_power()

        # 콜백 실행
        for callback in self._on_estop_callbacks:
            try:
                callback()
            except Exception:
                pass

        elapsed_ms = (time.time() - start_time) * 1000
        logger.critical(
            f"E-Stop 버튼 눌림 감지! 모터 전원 차단 "
            f"({elapsed_ms:.1f}ms)"
        )

    # ──────────────────────────────────────────────────────────────────────
    # cut_motor_power() — 모터 전원 차단
    # ──────────────────────────────────────────────────────────────────────

    def cut_motor_power(self) -> None:
        """
        모터 드라이버 EN 단자 LOW → 모터 전원 차단

        50ms 내 모터 정지 목표
        """
        if not self._simulate and self._gpio:
            try:
                self._gpio.output(self._motor_enable_pin, self._gpio.LOW)
            except Exception as e:
                logger.error(f"모터 EN 핀 제어 오류: {e}")

        self._state.motor_power_enabled = False
        logger.warning("모터 전원 차단 — EN 단자 LOW")

    # ──────────────────────────────────────────────────────────────────────
    # reset() — E-Stop 리셋
    # ──────────────────────────────────────────────────────────────────────

    def reset(self) -> bool:
        """
        E-Stop 리셋 — 버튼 해제 후 수동 리셋

        안전 규칙:
        - 버튼이 여전히 눌려있으면 리셋 불가
        - 자동 재시작 절대 불가 — 반드시 수동 리셋 필요

        Returns:
            리셋 성공 여부
        """
        with self._lock:
            # 버튼 해제 확인
            if self.is_button_pressed():
                logger.warning(
                    "E-Stop 버튼이 아직 눌려있음 — 리셋 불가"
                )
                return False

            # 자동 재시작 방지 확인
            if self._state.auto_restart_blocked:
                # 수동 리셋이어야 함 — 자동 호출이면 거부
                pass  # 실제 구현에서는 호출 컨텍스트 확인

            # 모터 EN 핀 HIGH → 모터 전원 복구
            if not self._simulate and self._gpio:
                try:
                    self._gpio.output(
                        self._motor_enable_pin, self._gpio.HIGH
                    )
                except Exception as e:
                    logger.error(f"모터 EN 핀 복구 오류: {e}")
                    return False

            self._state.motor_power_enabled = True
            self._state.estop_active = False
            self._state.button_pressed = False
            self._state.last_release_time = time.time()

            # 리셋 콜백 실행
            for callback in self._on_reset_callbacks:
                try:
                    callback()
                except Exception:
                    pass

            logger.info("E-Stop 리셋 — 모터 전원 복구 (수동 리셋)")
            return True

    # ──────────────────────────────────────────────────────────────────────
    # 상태 확인 메서드
    # ──────────────────────────────────────────────────────────────────────

    def is_estop_active(self) -> bool:
        """E-Stop 활성 상태 확인"""
        return self._state.estop_active

    def is_button_pressed(self) -> bool:
        """버튼 눌림 상태 확인 — 실제 GPIO 읽기"""
        if self._simulate:
            return self._state.button_pressed

        if self._gpio:
            try:
                return (
                    self._gpio.input(self._estop_pin)
                    == self._gpio.LOW
                )
            except Exception:
                pass

        return self._state.button_pressed

    def is_button_released(self) -> bool:
        """버튼 해제 상태 확인"""
        return not self.is_button_pressed()

    def is_motor_power_enabled(self) -> bool:
        """모터 전원 상태 확인"""
        return self._state.motor_power_enabled

    # ──────────────────────────────────────────────────────────────────────
    # 시뮬레이션 메서드
    # ──────────────────────────────────────────────────────────────────────

    def simulate_button_press(self) -> None:
        """시뮬레이션: E-Stop 버튼 누름"""
        self._handle_gpio_interrupt(self._estop_pin)

    def simulate_button_release(self) -> None:
        """시뮬레이션: E-Stop 버튼 해제"""
        with self._lock:
            self._state.button_pressed = False

    # ──────────────────────────────────────────────────────────────────────
    # 콜백 등록
    # ──────────────────────────────────────────────────────────────────────

    def register_estop_callback(self, callback: Callable) -> None:
        """E-Stop 트리거 콜백 등록"""
        self._on_estop_callbacks.append(callback)

    def register_reset_callback(self, callback: Callable) -> None:
        """E-Stop 리셋 콜백 등록"""
        self._on_reset_callbacks.append(callback)

    # ──────────────────────────────────────────────────────────────────────
    # 상태 및 통계
    # ──────────────────────────────────────────────────────────────────────

    def get_state(self) -> Dict[str, Any]:
        """E-Stop 상태 반환"""
        return {
            "estop_active": self._state.estop_active,
            "button_pressed": self._state.button_pressed,
            "motor_power_enabled": self._state.motor_power_enabled,
            "trigger_count": self._state.trigger_count,
            "last_trigger_time": self._state.last_trigger_time,
            "last_release_time": self._state.last_release_time,
            "auto_restart_blocked": self._state.auto_restart_blocked,
            "simulate_mode": self._simulate,
        }

    def shutdown(self) -> None:
        """E-Stop 컨트롤러 종료"""
        if not self._simulate and self._gpio:
            try:
                self._gpio.cleanup()
            except Exception:
                pass
        logger.info("E-Stop 컨트롤러 종료 완료")


# ============================================================================
# Dual-Channel E-Stop — IEC 62443 / ISO 13850 준수 이중화 안전 정지
# ============================================================================
# 단일 채널 E-Stop은 GPIO 핀 고장 시 안전 정지가 불가능.
# 이중화: 채널 A (GPIO 17) + 채널 B (GPIO 22) 동시 모니터링.
# 한 채널이라도 활성화되면 즉시 정지. 양채널 불일치 시 경고.
# ============================================================================

class DualChannelEStop:
    """이중 채널 비상 정지 회로 — 안전 등급 SIL 2 / PLd 목표
    
    채널 A: GPIO 17 (주 비상 정지 스위치)
    채널 B: GPIO 22 (보조 비상 정지 스위치)
    모터 인에이블: GPIO 27 (양채널 AND 제어)
    
    안전 원칙:
    1. 어느 한 채널이라도 LOW → 즉시 정지
    2. 양채널 불일치 → 경고 + 정지 (안전 쪽으로)
    3. 워치독: 100ms 주기 상태 확인 (인터럽트 실패 대비)
    4. 자동 재시작 절대 불가 (수동 리셋만 허용)
    """
    
    def __init__(self, channel_a_pin=17, channel_b_pin=22, 
                 motor_enable_pin=27, debounce_ms=10,
                 watchdog_interval_ms=100):
        self.channel_a_pin = channel_a_pin
        self.channel_b_pin = channel_b_pin
        self.motor_enable_pin = motor_enable_pin
        self.debounce_ms = debounce_ms
        self.watchdog_interval_ms = watchdog_interval_ms
        
        self._gpio_available = False
        self._state = EStopState.CLEARED if 'EStopState' in dir() else 'CLEARED'
        self._channel_a_triggered = False
        self._channel_b_triggered = False
        self._mismatch_count = 0
        self._last_mismatch_time = 0
        self._auto_restart_blocked = True
        self._running = False
        self._watchdog_thread = None
        self._lock = threading.Lock()
        
        self._callbacks = {
            'estop': [],
            'reset': [],
            'mismatch': [],
        }
        
        self._init_gpio()
    
    def _init_gpio(self):
        """GPIO 초기화 (이중 채널)"""
        try:
            import Jetson.GPIO as GPIO
            GPIO.setmode(GPIO.BCM)
            
            # Channel A
            GPIO.setup(self.channel_a_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            GPIO.add_event_detect(self.channel_a_pin, GPIO.FALLING,
                                  callback=self._channel_a_isr,
                                  bouncetime=self.debounce_ms)
            
            # Channel B
            GPIO.setup(self.channel_b_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            GPIO.add_event_detect(self.channel_b_pin, GPIO.FALLING,
                                  callback=self._channel_b_isr,
                                  bouncetime=self.debounce_ms)
            
            # Motor enable
            GPIO.setup(self.motor_enable_pin, GPIO.OUT, initial=GPIO.HIGH)
            
            self._gpio_available = True
            logging.info(f"[DualEStop] 이중 채널 초기화 완료 "
                        f"CH_A=GPIO{self.channel_a_pin}, CH_B=GPIO{self.channel_b_pin}")
        except ImportError:
            try:
                import RPi.GPIO as GPIO
                GPIO.setmode(GPIO.BCM)
                GPIO.setup(self.channel_a_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
                GPIO.add_event_detect(self.channel_a_pin, GPIO.FALLING,
                                      callback=self._channel_a_isr,
                                      bouncetime=self.debounce_ms)
                GPIO.setup(self.channel_b_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
                GPIO.add_event_detect(self.channel_b_pin, GPIO.FALLING,
                                      callback=self._channel_b_isr,
                                      bouncetime=self.debounce_ms)
                GPIO.setup(self.motor_enable_pin, GPIO.OUT, initial=GPIO.HIGH)
                self._gpio_available = True
            except ImportError:
                logging.warning("[DualEStop] GPIO 없음 - 시뮬레이션 모드")
                self._gpio_available = False
    
    def _channel_a_isr(self, channel):
        """채널 A 인터럽트 서비스 루틴"""
        with self._lock:
            self._channel_a_triggered = True
            self._trigger_estop("Channel A")
            self._check_channel_mismatch()
    
    def _channel_b_isr(self, channel):
        """채널 B 인터럽트 서비스 루틴"""
        with self._lock:
            self._channel_b_triggered = True
            self._trigger_estop("Channel B")
            self._check_channel_mismatch()
    
    def _trigger_estop(self, source):
        """비상 정지 실행"""
        self._state = EStopState if isinstance(EStopState, type) else 'TRIGGERED'
        self._auto_restart_blocked = True
        
        # 모터 인에이블 즉시 LOW (안전)
        if self._gpio_available:
            try:
                import Jetson.GPIO as GPIO
                GPIO.output(self.motor_enable_pin, GPIO.LOW)
            except ImportError:
                try:
                    import RPi.GPIO as GPIO
                    GPIO.output(self.motor_enable_pin, GPIO.LOW)
                except:
                    pass
        
        logging.critical(f"[DualEStop] 비상 정지! 출처={source}")
        
        for cb in self._callbacks['estop']:
            try:
                cb(source)
            except Exception as e:
                logging.error(f"[DualEStop] 콜백 오류: {e}")
    
    def _check_channel_mismatch(self):
        """채널 불일치 검사 (한 채널만 트리거된 경우)"""
        if self._channel_a_triggered != self._channel_b_triggered:
            self._mismatch_count += 1
            self._last_mismatch_time = time.time()
            logging.warning(
                f"[DualEStop] 채널 불일치! A={self._channel_a_triggered}, "
                f"B={self._channel_b_triggered} (불일치 횟수={self._mismatch_count})"
            )
            for cb in self._callbacks.get('mismatch', []):
                try:
                    cb(self._channel_a_triggered, self._channel_b_triggered)
                except:
                    pass
    
    def start_watchdog(self):
        """워치독 시작: 주기적 상태 확인"""
        self._running = True
        self._watchdog_thread = threading.Thread(
            target=self._watchdog_loop, daemon=True
        )
        self._watchdog_thread.start()
        logging.info("[DualEStop] 워치독 시작")
    
    def _watchdog_loop(self):
        """워치독 루프: 인터럽트 실패 대비 주기적 확인"""
        while self._running:
            try:
                if self._gpio_available:
                    import Jetson.GPIO as GPIO
                    a_state = GPIO.input(self.channel_a_pin)
                    b_state = GPIO.input(self.channel_b_pin)
                    
                    if a_state == GPIO.LOW or b_state == GPIO.LOW:
                        with self._lock:
                            if a_state == GPIO.LOW:
                                self._channel_a_triggered = True
                            if b_state == GPIO.LOW:
                                self._channel_b_triggered = True
                            self._trigger_estop("Watchdog")
            except ImportError:
                try:
                    import RPi.GPIO as GPIO
                    a_state = GPIO.input(self.channel_a_pin)
                    b_state = GPIO.input(self.channel_b_pin)
                    if a_state == GPIO.LOW or b_state == GPIO.LOW:
                        with self._lock:
                            if a_state == GPIO.LOW:
                                self._channel_a_triggered = True
                            if b_state == GPIO.LOW:
                                self._channel_b_triggered = True
                            self._trigger_estop("Watchdog")
                except:
                    pass
            
            time.sleep(self.watchdog_interval_ms / 1000.0)
    
    def reset(self):
        """수동 리셋 (자동 재시작 불가)"""
        with self._lock:
            if self._auto_restart_blocked:
                # 채널 상태 확인
                if self._channel_a_triggered or self._channel_b_triggered:
                    logging.warning("[DualEStop] 리셋 불가 - 채널이 여전히 트리거됨")
                    return False
                
                self._state = EStopState if isinstance(EStopState, type) else 'CLEARED'
                self._auto_restart_blocked = False
                logging.info("[DualEStop] 수동 리셋 완료")
                
                for cb in self._callbacks['reset']:
                    try:
                        cb()
                    except:
                        pass
                return True
            return False
    
    def stop_watchdog(self):
        """워치독 정지"""
        self._running = False
        if self._watchdog_thread:
            self._watchdog_thread.join(timeout=1.0)
    
    @property
    def is_safe(self):
        """안전 상태 반환 (양채널 모두 정상일 때만 True)"""
        return not self._channel_a_triggered and not self._channel_b_triggered
    
    @property
    def state(self):
        return self._state
    
    @property
    def health(self):
        """E-Stop 시스템 건강 상태"""
        return {
            'channel_a_ok': not self._channel_a_triggered,
            'channel_b_ok': not self._channel_b_triggered,
            'mismatch_count': self._mismatch_count,
            'auto_restart_blocked': self._auto_restart_blocked,
            'gpio_available': self._gpio_available,
        }
