#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TODO 4: ROS2 Jazzy 워크스페이스 초기화
========================================================

~/jihun_ws/src에 패키지 구조 생성 및 colcon build 검증

패키지 (6개):
  - jihun_bringup: 기본 부팅 및 통신 노드
  - jihun_motor: 모터 제어 노드
  - jihun_vision: 비전 파이프라인 노드
  - jihun_audio: 오디오 파이프라인 노드
  - jihun_navigation: 내비게이션 노드
  - jihun_gripper: 그리퍼 제어 노드

커스텀 메시지:
  - MotorCmd.msg: 모터 명령
  - SensorData.msg: 센서 데이터
  - AIDecision.msg: AI 결정

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from hardware.config import JihunRobotV7Config

logger = logging.getLogger("jihun.v84.ros2_workspace")

# ============================================================================
# 상수
# ============================================================================

WORKSPACE_ROOT = Path.home() / "jihun_ws"
WORKSPACE_SRC = WORKSPACE_ROOT / "src"
ROS2_DISTRO = "jazzy"

# 패키지 정의
PACKAGES = {
    "jihun_bringup": {
        "description": "지훈 로봇 V8.5 기본 부팅 및 통신 노드",
        "dependencies": ["rclpy", "std_msgs", "jihun_msg"],
        "node": "talker",
        "node_class": "TalkerNode",
    },
    "jihun_motor": {
        "description": "지훈 로봇 V8.5 모터 제어 노드 (100Hz RT)",
        "dependencies": ["rclpy", "std_msgs", "jihun_msg"],
        "node": "motor_cmd_node",
        "node_class": "MotorCmdNode",
    },
    "jihun_vision": {
        "description": "지훈 로봇 V8.5 비전 파이프라인 노드",
        "dependencies": ["rclpy", "std_msgs", "sensor_msgs", "jihun_msg"],
        "node": "vision_node",
        "node_class": "VisionNode",
    },
    "jihun_audio": {
        "description": "지훈 로봇 V8.5 오디오 파이프라인 노드 (STT/TTS)",
        "dependencies": ["rclpy", "std_msgs", "jihun_msg"],
        "node": "audio_node",
        "node_class": "AudioNode",
    },
    "jihun_navigation": {
        "description": "지훈 로봇 V8.5 내비게이션 노드 (Nav2)",
        "dependencies": ["rclpy", "std_msgs", "geometry_msgs", "nav_msgs", "jihun_msg"],
        "node": "nav_node",
        "node_class": "NavNode",
    },
    "jihun_gripper": {
        "description": "지훈 로봇 V8.5 그리퍼 제어 노드",
        "dependencies": ["rclpy", "std_msgs", "jihun_msg"],
        "node": "gripper_node",
        "node_class": "GripperNode",
    },
}


@dataclass
class PackageBuildResult:
    """패키지 빌드 결과"""
    package_name: str
    success: bool
    build_time_s: float = 0.0
    errors: List[str] = field(default_factory=list)


@dataclass
class WorkspaceStatus:
    """워크스페이스 상태"""
    workspace_exists: bool = False
    packages_found: List[str] = field(default_factory=list)
    build_results: List[PackageBuildResult] = field(default_factory=list)
    install_dir_exists: bool = False


class ROS2Workspace:
    """
    TODO 4: ROS2 Jazzy 워크스페이스 초기화

    기능:
      - 워크스페이스 디렉토리 구조 생성
      - 6개 패키지 소스 생성 (package.xml, setup.py, 노드)
      - 커스텀 메시지 정의 (MotorCmd, SensorData, AIDecision)
      - colcon build 실행 및 검증
    """

    def __init__(self, config: Optional[JihunRobotV7Config] = None):
        self.config = config or JihunRobotV7Config()
        self._status = WorkspaceStatus()

    # ========================================================================
    # 공용 메서드
    # ========================================================================

    def setup(self) -> bool:
        """전체 ROS2 워크스페이스 설정"""
        logger.info("=== ROS2 Jazzy 워크스페이스 초기화 ===")

        # 1. ROS2 환경 확인
        if not self._check_ros2_env():
            logger.error("ROS2 Jazzy 환경 미설치")
            return False

        # 2. 워크스페이스 디렉토리 생성
        self._create_workspace_dirs()

        # 3. 커스텀 메시지 패키지 생성
        self._create_msg_package()

        # 4. 패키지 소스 생성
        for pkg_name, pkg_info in PACKAGES.items():
            self._create_package(pkg_name, pkg_info)

        # 5. colcon build
        build_ok = self._colcon_build()

        if build_ok:
            logger.info("=== ROS2 워크스페이스 초기화 완료 ===")
        else:
            logger.warning("=== ROS2 워크스페이스 빌드 실패 — 수동 확인 필요 ===")
        return build_ok

    def verify(self) -> bool:
        """워크스페이스 검증"""
        status = self._check_workspace_status()
        return status.workspace_exists and len(status.packages_found) >= 6

    # ========================================================================
    # ROS2 환경 확인
    # ========================================================================

    def _check_ros2_env(self) -> bool:
        """ROS2 Jazzy 설치 확인"""
        try:
            result = subprocess.run(
                ["ros2", "--version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                logger.info(f"  ✓ ROS2 설치됨: {result.stdout.strip()}")
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # source 후 재시도
        try:
            result = subprocess.run(
                ["bash", "-c", "source /opt/ros/jazzy/setup.bash && ros2 --version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                logger.info(f"  ✓ ROS2 Jazzy: {result.stdout.strip()}")
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        logger.error("  ✗ ROS2 Jazzy 미설치")
        logger.info("  설치: sudo apt-get install ros-jazzy-ros-base")
        return False

    # ========================================================================
    # 워크스페이스 디렉토리 생성
    # ========================================================================

    def _create_workspace_dirs(self) -> None:
        """워크스페이스 디렉토리 구조 생성"""
        dirs = [
            WORKSPACE_ROOT,
            WORKSPACE_SRC,
            WORKSPACE_ROOT / "build",
            WORKSPACE_ROOT / "install",
            WORKSPACE_ROOT / "log",
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)
            logger.info(f"  디렉토리: {d}")

    # ========================================================================
    # 커스텀 메시지 패키지 생성
    # ========================================================================

    def _create_msg_package(self) -> None:
        """jihun_msg 커스텀 메시지 패키지 생성"""
        msg_dir = WORKSPACE_SRC / "jihun_msg"
        msg_dir.mkdir(parents=True, exist_ok=True)

        # package.xml
        package_xml = """<?xml version="1.0"?>
<?xml-model href="http://download.ros.org/schema/package_format3.xsd" schematypens="http://www.w3.org/2001/XMLSchema"?>
<package format="3">
  <name>jihun_msg</name>
  <version>7.0.0</version>
  <description>지훈 로봇 V8.5 커스텀 메시지 타입</description>
  <maintainer email="jihun@jihun-robotics.com">Jihun Robotics</maintainer>
  <license>MIT</license>

  <buildtool_depend>ament_cmake</buildtool_depend>
  <buildtool_depend>rosidl_default_generators</buildtool_depend>

  <depend>std_msgs</depend>
  <depend>geometry_msgs</depend>

  <exec_depend>rosidl_default_runtime</exec_depend>

  <member_of_group>rosidl_interface_packages</member_of_group>

  <export>
    <build_type>ament_cmake</build_type>
  </export>
</package>
"""
        (msg_dir / "package.xml").write_text(package_xml)

        # CMakeLists.txt
        cmake = """cmake_minimum_required(VERSION 3.8)
project(jihun_msg)

find_package(ament_cmake REQUIRED)
find_package(rosidl_default_generators REQUIRED)
find_package(std_msgs REQUIRED)
find_package(geometry_msgs REQUIRED)

rosidl_generate_interfaces(${PROJECT_NAME}
  "msg/MotorCmd.msg"
  "msg/SensorData.msg"
  "msg/AIDecision.msg"
  DEPENDENCIES std_msgs geometry_msgs
)

ament_package()
"""
        (msg_dir / "CMakeLists.txt").write_text(cmake)

        # 메시지 정의
        msg_subdir = msg_dir / "msg"
        msg_subdir.mkdir(parents=True, exist_ok=True)

        # MotorCmd.msg
        (msg_subdir / "MotorCmd.msg").write_text("""# 지훈 로봇 V8.5 — 모터 명령 메시지
# 모터 ID (0=FL휠, 1=FR휠, 2=RL휠, 3=RR휠, 4=좌승강, 5=우승강, 6=좌피치, 7=우피치)
uint8 motor_id

# 제어 모드 (0=속도, 1=위치, 2=토크)
uint8 control_mode

# 목표값 (속도: m/s, 위치: rad, 토크: N·m)
float64 target_value

# 속도 제한 (m/s 또는 rad/s)
float64 velocity_limit

# 토크 제한 (N·m)
float64 torque_limit

# 타임스탬프
builtin_interfaces/Time stamp
""")

        # SensorData.msg
        (msg_subdir / "SensorData.msg").write_text("""# 지훈 로봇 V8.5 — 센서 데이터 메시지
# IMU 데이터
float64[9] imu_orientation       # 쿼터니언 + 오일러
float64[3] imu_angular_velocity  # rad/s
float64[3] imu_linear_accel      # m/s²

# LiDAR
float64[] lidar_ranges           # m
float64[] lidar_angles           # rad

# ToF (VL53L5CX 8×8)
float64[64] tof_front_distances  # m
float64[64] tof_rear_distances   # m

# 로드셀 (HX711 ×4)
float64[4] load_cell_weights     # kg

# FSR (×3)
float64[3] fsr_forces            # N

# 배터리
float64 battery_voltage           # V
float64 battery_current           # A
float64 battery_soc               # %

# 온도
float64 jetson1_temp              # °C
float64 jetson2_temp              # °C

# 타임스탬프
builtin_interfaces/Time stamp
""")

        # AIDecision.msg
        (msg_subdir / "AIDecision.msg").write_text("""# 지훈 로봇 V8.5 — AI 결정 메시지
# 결정 유형 (0=이동, 1=파지, 2=음성, 3=정지, 4=복합)
uint8 decision_type

# 명령 문자열 (JSON 형식)
string command_json

# 신뢰도 (0.0~1.0)
float64 confidence

# 우선순위 (0=최고, 10=최저)
uint8 priority

# 소스 (0=Gemma4, 1=Reflex, 2=STT, 3=수동)
uint8 source

# 타임스탬프
builtin_interfaces/Time stamp
""")

        logger.info("  ✓ jihun_msg 커스텀 메시지 패키지 생성 완료")

    # ========================================================================
    # 패키지 소스 생성
    # ========================================================================

    def _create_package(self, pkg_name: str, pkg_info: Dict) -> None:
        """개별 패키지 소스 생성"""
        pkg_dir = WORKSPACE_SRC / pkg_name
        pkg_subdir = pkg_dir / pkg_name  # Python 패키지 디렉토리
        pkg_dir.mkdir(parents=True, exist_ok=True)
        pkg_subdir.mkdir(parents=True, exist_ok=True)

        # package.xml
        deps_xml = "\n".join(f"  <depend>{d}</depend>" for d in pkg_info["dependencies"])
        package_xml = f"""<?xml version="1.0"?>
<?xml-model href="http://download.ros.org/schema/package_format3.xsd" schematypens="http://www.w3.org/2001/XMLSchema"?>
<package format="3">
  <name>{pkg_name}</name>
  <version>7.0.0</version>
  <description>{pkg_info["description"]}</description>
  <maintainer email="jihun@jihun-robotics.com">Jihun Robotics</maintainer>
  <license>MIT</license>

  <buildtool_depend>ament_cmake_python</buildtool_depend>
  <buildtool_depend>rosidl_default_generators</buildtool_depend>

{deps_xml}

  <exec_depend>rosidl_default_runtime</exec_depend>

  <export>
    <build_type>ament_python</build_type>
  </export>
</package>
"""
        (pkg_dir / "package.xml").write_text(package_xml)

        # setup.py
        setup_py = f"""from setuptools import setup, find_packages

package_name = '{pkg_name}'

setup(
    name=package_name,
    version='7.0.0',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/{pkg_name}', ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Jihun Robotics',
    maintainer_email='jihun@jihun-robotics.com',
    description='{pkg_info["description"]}',
    license='MIT',
    entry_points={{
        'console_scripts': [
            '{pkg_info["node"]} = {pkg_name}.{pkg_info["node"]}:{pkg_info["node_class"]}',
        ],
    }},
)
"""
        (pkg_dir / "setup.py").write_text(setup_py)

        # __init__.py
        (pkg_subdir / "__init__.py").write_text("")

        # resource 마커
        resource_dir = pkg_dir / "resource"
        resource_dir.mkdir(parents=True, exist_ok=True)
        (resource_dir / pkg_name).write_text("")

        # 노드 소스 생성
        self._create_node_source(pkg_subdir, pkg_name, pkg_info)

        logger.info(f"  ✓ 패키지 생성: {pkg_name}")

    def _create_node_source(self, pkg_subdir: Path, pkg_name: str, pkg_info: Dict) -> None:
        """노드 Python 소스 파일 생성"""
        node_name = pkg_info["node"]
        node_class = pkg_info["node_class"]

        # 각 노드에 맞는 소스 코드
        node_templates = {
            "talker": self._template_talker,
            "motor_cmd_node": self._template_motor_cmd,
            "vision_node": self._template_vision,
            "audio_node": self._template_audio,
            "nav_node": self._template_nav,
            "gripper_node": self._template_gripper,
        }

        template_fn = node_templates.get(node_name, self._template_generic)
        source = template_fn(pkg_name, node_name, node_class)
        (pkg_subdir / f"{node_name}.py").write_text(source)

    # ========================================================================
    # 노드 템플릿
    # ========================================================================

    def _template_talker(self, pkg: str, node: str, cls: str) -> str:
        return f'''#!/usr/bin/env python3
"""지훈 로봇 V8.5 — Bringup Talker 노드"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class {cls}(Node):
    """기본 통신 테스트 노드 — heartbeat 발행"""

    def __init__(self):
        super().__init__("jihun_talker")
        self.publisher_ = self.create_publisher(String, "jihun_heartbeat", 10)
        timer_period = 1.0  # 1Hz
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.count = 0
        self.get_logger().info("지훈 로봇 V8.5 Talker 노드 시작")

    def timer_callback(self):
        msg = String()
        msg.data = f"Jihun V8.5 heartbeat #{{self.count}}"
        self.publisher_.publish(msg)
        self.get_logger().debug(f"발행: {{msg.data}}")
        self.count += 1


def main(args=None):
    rclpy.init(args=args)
    node = {cls}()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
'''

    def _template_motor_cmd(self, pkg: str, node: str, cls: str) -> str:
        return f'''#!/usr/bin/env python3
"""지훈 로봇 V8.5 — 모터 제어 노드 (100Hz RT)"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from jihun_msg.msg import MotorCmd


class {cls}(Node):
    """모터 제어 노드 — cmd_vel → 모터 명령 변환"""

    def __init__(self):
        super().__init__("jihun_motor_cmd")
        self.cmd_sub = self.create_subscription(
            MotorCmd, "motor_cmd", self.cmd_callback, 10
        )
        self.feedback_pub = self.create_publisher(String, "motor_feedback", 10)
        self.control_timer = self.create_timer(0.01, self.control_loop)  # 100Hz
        self.get_logger().info("모터 제어 노드 시작 (100Hz)")

    def cmd_callback(self, msg):
        self.get_logger().info(
            f"모터 #{{msg.motor_id}} 모드={{msg.control_mode}} "
            f"목표={{msg.target_value}}"
        )

    def control_loop(self):
        """100Hz 제어 루프 — PREEMPT_RT에서 우선순위 보장"""
        pass  # 실제 모터 제어 로직은 Phase 1에서 구현


def main(args=None):
    rclpy.init(args=args)
    node = {cls}()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
'''

    def _template_vision(self, pkg: str, node: str, cls: str) -> str:
        return f'''#!/usr/bin/env python3
"""지훈 로봇 V8.5 — 비전 파이프라인 노드"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from sensor_msgs.msg import Image
from jihun_msg.msg import AIDecision


class {cls}(Node):
    """비전 노드 — OAK-D Pro → 객체 탐지 + 깊이 추정"""

    def __init__(self):
        super().__init__("jihun_vision")
        self.image_sub = self.create_subscription(
            Image, "camera/image_raw", self.image_callback, 10
        )
        self.detection_pub = self.create_publisher(AIDecision, "vision/detection", 10)
        self.depth_pub = self.create_publisher(Image, "vision/depth", 10)
        self.get_logger().info("비전 파이프라인 노드 시작")

    def image_callback(self, msg):
        """이미지 수신 → 객체 탐지 + 깊이 추정"""
        pass  # Phase 3에서 구현


def main(args=None):
    rclpy.init(args=args)
    node = {cls}()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
'''

    def _template_audio(self, pkg: str, node: str, cls: str) -> str:
        return f'''#!/usr/bin/env python3
"""지훈 로봇 V8.5 — 오디오 파이프라인 노드 (STT/TTS)"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from jihun_msg.msg import AIDecision


class {cls}(Node):
    """오디오 노드 — 마이크 입력 → STT → TTS → 스피커 출력"""

    def __init__(self):
        super().__init__("jihun_audio")
        self.stt_sub = self.create_subscription(
            String, "audio/stt_text", self.stt_callback, 10
        )
        self.tts_pub = self.create_publisher(String, "audio/tts_text", 10)
        self.decision_pub = self.create_publisher(AIDecision, "ai/stt_decision", 10)
        self.get_logger().info("오디오 파이프라인 노드 시작")

    def stt_callback(self, msg):
        """STT 결과 수신 → AI 결정 퍼블리시"""
        self.get_logger().info(f"STT: {{msg.data}}")


def main(args=None):
    rclpy.init(args=args)
    node = {cls}()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
'''

    def _template_nav(self, pkg: str, node: str, cls: str) -> str:
        return f'''#!/usr/bin/env python3
"""지훈 로봇 V8.5 — 내비게이션 노드 (Nav2)"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import String
from jihun_msg.msg import AIDecision


class {cls}(Node):
    """내비게이션 노드 — Nav2 + Cartographer SLAM"""

    def __init__(self):
        super().__init__("jihun_navigation")
        self.cmd_vel_pub = self.create_publisher(Twist, "cmd_vel", 10)
        self.odom_sub = self.create_subscription(
            Odometry, "odom", self.odom_callback, 10
        )
        self.goal_sub = self.create_subscription(
            AIDecision, "ai/nav_goal", self.goal_callback, 10
        )
        self.get_logger().info("내비게이션 노드 시작")

    def odom_callback(self, msg):
        """오도메트리 수신"""
        pass

    def goal_callback(self, msg):
        """AI 내비게이션 목표 수신"""
        self.get_logger().info(f"내비게이션 목표: {{msg.command_json}}")


def main(args=None):
    rclpy.init(args=args)
    node = {cls}()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
'''

    def _template_gripper(self, pkg: str, node: str, cls: str) -> str:
        return f'''#!/usr/bin/env python3
"""지훈 로봇 V8.5 — 그리퍼 제어 노드"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from jihun_msg.msg import MotorCmd, AIDecision


class {cls}(Node):
    """그리퍼 노드 — Fin Ray 그리퍼 + FSR 촉각 피드백"""

    def __init__(self):
        super().__init__("jihun_gripper")
        self.cmd_sub = self.create_subscription(
            AIDecision, "ai/gripper_cmd", self.cmd_callback, 10
        )
        self.motor_pub = self.create_publisher(MotorCmd, "gripper/motor_cmd", 10)
        self.feedback_pub = self.create_publisher(String, "gripper/feedback", 10)
        self.get_logger().info("그리퍼 제어 노드 시작")

    def cmd_callback(self, msg):
        """AI 그리퍼 명령 수신"""
        self.get_logger().info(f"그리퍼 명령: {{msg.command_json}}")


def main(args=None):
    rclpy.init(args=args)
    node = {cls}()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
'''

    def _template_generic(self, pkg: str, node: str, cls: str) -> str:
        return f'''#!/usr/bin/env python3
"""지훈 로봇 V8.5 — {pkg} 노드"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class {cls}(Node):
    def __init__(self):
        super().__init__("jihun_{node}")
        self.get_logger().info("{pkg} 노드 시작")


def main(args=None):
    rclpy.init(args=args)
    node = {cls}()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
'''

    # ========================================================================
    # colcon build
    # ========================================================================

    def _colcon_build(self) -> bool:
        """colcon build 실행"""
        logger.info("colcon build 실행 중...")

        try:
            result = subprocess.run(
                [
                    "bash", "-c",
                    f"source /opt/ros/{ROS2_DISTRO}/setup.bash && "
                    f"cd {WORKSPACE_ROOT} && "
                    "colcon build --symlink-install",
                ],
                capture_output=True, text=True, timeout=300,
            )

            if result.returncode == 0:
                logger.info("  ✓ colcon build 성공")
                return True
            else:
                logger.error(f"  ✗ colcon build 실패:\n{result.stderr[-500:]}")
                return False

        except subprocess.TimeoutExpired:
            logger.error("  ✗ colcon build 타임아웃 (300s)")
            return False
        except FileNotFoundError:
            logger.error("  ✗ colcon 미설치")
            return False

    # ========================================================================
    # 워크스페이스 상태 확인
    # ========================================================================

    def _check_workspace_status(self) -> WorkspaceStatus:
        """워크스페이스 상태 확인"""
        status = WorkspaceStatus()
        status.workspace_exists = WORKSPACE_ROOT.exists()
        status.install_dir_exists = (WORKSPACE_ROOT / "install").exists()

        if WORKSPACE_SRC.exists():
            for d in WORKSPACE_SRC.iterdir():
                if d.is_dir() and (d / "package.xml").exists():
                    status.packages_found.append(d.name)

        return status
