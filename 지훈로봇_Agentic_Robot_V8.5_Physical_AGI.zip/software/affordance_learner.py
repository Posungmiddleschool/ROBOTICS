#!/usr/bin/env python3
"""
Object Affordance & Tool Use Learning Module / 객체 기능성 및 도구 사용 학습 모듈

지훈 로봇 V8의 객체 기능성(affordance) 학습 및 도구 사용 시스템입니다.
객체와 상호작용하며 가능한 행동을 학습하고, 도구를 발견하여 사용법을 익힙니다.

**Physical AGI Paradigm**: WORLD DATA = Physical interaction experience, NOT web crawling.
The robot learns affordances by physically interacting with objects — gripping,
lifting, pushing, rotating — and observing the outcomes. All knowledge comes
from embodied physical experience, not from downloading textual descriptions.

로봇은 객체를 물리적으로 조작하며 기능성을 학습합니다. 웹에서 정보를 크롤링하는
것이 아니라, 직접 물체를 잡아보고 들어보고 밀어보며 가능한 행동을 발견합니다.

TODO 37-38: Object Affordance & Tool Use Learning

Components / 구성 요소:
  - AffordanceLearner: 객체의 가능 행동 학습
  - ToolDiscovery: 도구 발견 및 사용법 학습

Affordance Examples / 기능성 예시:
  - Cup: can_grasp, can_fill, can_pour_from, can_stack
  - Chair: can_sit_on, can_push, can_lift
  - Door: can_open, can_close, can_push

Learning Process / 학습 프로세스:
  1. 익숙하지 않은 객체 식별
  2. 물리적 탐색 (push, lift, rotate)
  3. 효과 관찰
  4. 기능성 모델 구축
  5. 작업 도구로 사용 시도

Storage: SQLite with object features + affordance scores

Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np

# ─── PyTorch 선택적 임포트 / Optional PyTorch Import ─────────────────────────

TORCH_AVAILABLE = False
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    TORCH_AVAILABLE = True
except ImportError:
    torch = None  # type: ignore[assignment]
    nn = None  # type: ignore[assignment]
    F = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums / 열거형
# ---------------------------------------------------------------------------

class AffordanceAction(Enum):
    """기능성 행동 열거형 / Affordable action types."""
    CAN_GRASP = "can_grasp"
    CAN_LIFT = "can_lift"
    CAN_PUSH = "can_push"
    CAN_PULL = "can_pull"
    CAN_ROTATE = "can_rotate"
    CAN_OPEN = "can_open"
    CAN_CLOSE = "can_close"
    CAN_SIT_ON = "can_sit_on"
    CAN_STACK = "can_stack"
    CAN_FILL = "can_fill"
    CAN_POUR_FROM = "can_pour_from"
    CAN_DRINK_FROM = "can_drink_from"
    CAN_CUT_WITH = "can_cut_with"
    CAN_WRITE_WITH = "can_write_with"
    CAN_CLEAN_WITH = "can_clean_with"
    CAN_SUPPORT = "can_support"
    CAN_ROLL = "can_roll"
    CAN_SQUEEZE = "can_squeeze"
    CAN_FLIP = "can_flip"
    CAN_HANG = "can_hang"


class ExplorationAction(Enum):
    """탐색 행동 열거형 / Exploration action types."""
    PUSH = "push"
    LIFT = "lift"
    ROTATE = "rotate"
    POKE = "poke"
    SHAKE = "shake"
    TILT = "tilt"
    SQUEEZE = "squeeze"
    DROP = "drop"
    SLIDE = "slide"


class ToolCategory(Enum):
    """도구 카테고리 열거형 / Tool category types."""
    CUTTING = "cutting"          # 칼, 가위
    GRASPING = "grasping"       # 집게, 장갑
    CONTAINER = "container"     # 컵, 그릇
    WRITING = "writing"         # 펜, 연필
    CLEANING = "cleaning"       # 걸레, 브러시
    MEASURING = "measuring"     # 자, 저울
    FASTENING = "fastening"     # 테이프, 클립
    STRIKING = "striking"       # 망치, 몽둥이
    UNKNOWN = "unknown"         # 알 수 없음


class ObjectCategory(Enum):
    """객체 카테고리 열거형 / Object category types."""
    FURNITURE = "furniture"
    UTENSIL = "utensil"
    TOOL = "tool"
    CONTAINER = "container"
    ELECTRONIC = "electronic"
    DOOR = "door"
    FOOD = "food"
    CLOTHING = "clothing"
    UNKNOWN = "unknown"


# Korean names / 한국어명
AFFORDANCE_KOREAN: Dict[AffordanceAction, str] = {
    AffordanceAction.CAN_GRASP: "잡을 수 있음",
    AffordanceAction.CAN_LIFT: "들어올릴 수 있음",
    AffordanceAction.CAN_PUSH: "밀 수 있음",
    AffordanceAction.CAN_PULL: "당길 수 있음",
    AffordanceAction.CAN_ROTATE: "회전시킬 수 있음",
    AffordanceAction.CAN_OPEN: "열 수 있음",
    AffordanceAction.CAN_CLOSE: "닫을 수 있음",
    AffordanceAction.CAN_SIT_ON: "앉을 수 있음",
    AffordanceAction.CAN_STACK: "쌓을 수 있음",
    AffordanceAction.CAN_FILL: "채울 수 있음",
    AffordanceAction.CAN_POUR_FROM: "붓을 수 있음",
    AffordanceAction.CAN_DRINK_FROM: "마실 수 있음",
    AffordanceAction.CAN_CUT_WITH: "자를 수 있음",
    AffordanceAction.CAN_WRITE_WITH: "쓸 수 있음",
    AffordanceAction.CAN_CLEAN_WITH: "청소할 수 있음",
    AffordanceAction.CAN_SUPPORT: "지지할 수 있음",
    AffordanceAction.CAN_ROLL: "굴릴 수 있음",
    AffordanceAction.CAN_SQUEEZE: "짤 수 있음",
    AffordanceAction.CAN_FLIP: "뒤집을 수 있음",
    AffordanceAction.CAN_HANG: "걸 수 있음",
}

EXPLORATION_KOREAN: Dict[ExplorationAction, str] = {
    ExplorationAction.PUSH: "밀기",
    ExplorationAction.LIFT: "들기",
    ExplorationAction.ROTATE: "회전",
    ExplorationAction.POKE: "찌르기",
    ExplorationAction.SHAKE: "흔들기",
    ExplorationAction.TILT: "기울이기",
    ExplorationAction.SQUEEZE: "짜기",
    ExplorationAction.DROP: "떨어뜨리기",
    ExplorationAction.SLIDE: "밀어내기",
}

TOOL_CATEGORY_KOREAN: Dict[ToolCategory, str] = {
    ToolCategory.CUTTING: "절단 도구",
    ToolCategory.GRASPING: "파지 도구",
    ToolCategory.CONTAINER: "용기",
    ToolCategory.WRITING: "필기 도구",
    ToolCategory.CLEANING: "청소 도구",
    ToolCategory.MEASURING: "측정 도구",
    ToolCategory.FASTENING: "고정 도구",
    ToolCategory.STRIKING: "타격 도구",
    ToolCategory.UNKNOWN: "알 수 없음",
}


# ---------------------------------------------------------------------------
# Data Classes / 데이터 클래스
# ---------------------------------------------------------------------------

@dataclass
class ObjectFeatures:
    """
    객체 특징 데이터 / Object feature data.

    시각 및 물리적 특징을 저장합니다.
    """
    object_id: str = ""
    name: str = ""
    category: ObjectCategory = ObjectCategory.UNKNOWN
    # Physical properties / 물리적 특성
    weight_kg: float = 0.0
    height_m: float = 0.0
    width_m: float = 0.0
    depth_m: float = 0.0
    is_rigid: bool = True
    is_fragile: bool = False
    has_handle: bool = False
    has_opening: bool = False
    has_surface: bool = True
    is_sharp: bool = False
    is_round: bool = False
    # Visual features / 시각적 특징
    color: str = ""
    shape: str = ""  # box, cylinder, sphere, irregular
    texture: str = ""  # smooth, rough, soft, hard
    # Metadata
    observed_count: int = 0
    last_observed: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    custom_features: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AffordanceScore:
    """
    기능성 점수 / Affordance score for a specific action.

    객체와 행동의 조합에 대한 점수와 근거를 저장합니다.
    """
    action: AffordanceAction = AffordanceAction.CAN_GRASP
    score: float = 0.0  # 0.0 ~ 1.0
    confidence: float = 0.0  # 0.0 ~ 1.0
    evidence_count: int = 0
    last_tested: str = ""
    reasoning: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AffordanceModel:
    """
    객체 기능성 모델 / Object affordance model.

    하나의 객체에 대한 전체 기능성 모델입니다.
    """
    model_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    object_features: ObjectFeatures = field(default_factory=ObjectFeatures)
    affordance_scores: Dict[str, AffordanceScore] = field(default_factory=dict)
    is_tool: bool = False
    tool_category: ToolCategory = ToolCategory.UNKNOWN
    tool_usage_patterns: List[Dict[str, Any]] = field(default_factory=list)
    exploration_history: List[Dict[str, Any]] = field(default_factory=list)
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    updated_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def get_top_affordances(self, n: int = 5) -> List[Tuple[AffordanceAction, float]]:
        """
        상위 N개 기능성 반환 / Get top-N affordances by score.

        Args:
            n: 반환할 개수

        Returns:
            List of (action, score) tuples sorted by score descending
        """
        sorted_affordances = sorted(
            self.affordance_scores.items(),
            key=lambda x: x[1].score,
            reverse=True,
        )
        return [
            (AffordanceAction(action_str), score_obj.score)
            for action_str, score_obj in sorted_affordances[:n]
        ]

    def can_perform(self, action: AffordanceAction, threshold: float = 0.5) -> bool:
        """
        특정 행동 가능 여부 확인 / Check if an action is affordable.

        Args:
            action: 확인할 행동
            threshold: 가능 판정 임계값

        Returns:
            bool: 행동 가능 여부
        """
        score_obj = self.affordance_scores.get(action.value)
        if score_obj is None:
            return False
        return score_obj.score >= threshold


@dataclass
class ExplorationResult:
    """
    탐색 결과 / Exploration result.

    객체에 대한 탐색 행동의 결과를 저장합니다.
    """
    exploration_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    object_id: str = ""
    action: ExplorationAction = ExplorationAction.PUSH
    success: bool = False
    observed_effect: str = ""
    new_affordances: List[AffordanceAction] = field(default_factory=list)
    updated_scores: Dict[str, float] = field(default_factory=dict)
    safety_concern: bool = False
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class ToolUsagePattern:
    """
    도구 사용 패턴 / Tool usage pattern.

    도구의 사용 방법과 효과를 정의합니다.
    """
    pattern_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tool_category: ToolCategory = ToolCategory.UNKNOWN
    task_description: str = ""
    korean_description: str = ""
    required_affordances: List[AffordanceAction] = field(default_factory=list)
    usage_steps: List[str] = field(default_factory=list)
    success_rate: float = 0.0
    practice_count: int = 0
    mastery_level: float = 0.0  # 0.0 ~ 1.0
    last_used: str = ""


# ---------------------------------------------------------------------------
# Default Affordance Templates / 기본 기능성 템플릿
# ---------------------------------------------------------------------------

# Common object affordance templates / 일반 객체 기능성 템플릿
DEFAULT_AFFORDANCE_TEMPLATES: Dict[str, Dict[AffordanceAction, float]] = {
    "cup": {
        AffordanceAction.CAN_GRASP: 0.95,
        AffordanceAction.CAN_LIFT: 0.90,
        AffordanceAction.CAN_FILL: 0.95,
        AffordanceAction.CAN_POUR_FROM: 0.85,
        AffordanceAction.CAN_DRINK_FROM: 0.90,
        AffordanceAction.CAN_STACK: 0.60,
        AffordanceAction.CAN_ROTATE: 0.70,
    },
    "chair": {
        AffordanceAction.CAN_SIT_ON: 0.95,
        AffordanceAction.CAN_PUSH: 0.80,
        AffordanceAction.CAN_LIFT: 0.40,
        AffordanceAction.CAN_SUPPORT: 0.90,
    },
    "door": {
        AffordanceAction.CAN_OPEN: 0.90,
        AffordanceAction.CAN_CLOSE: 0.90,
        AffordanceAction.CAN_PUSH: 0.85,
        AffordanceAction.CAN_PULL: 0.85,
        AffordanceAction.CAN_ROTATE: 0.30,
    },
    "knife": {
        AffordanceAction.CAN_GRASP: 0.95,
        AffordanceAction.CAN_CUT_WITH: 0.95,
        AffordanceAction.CAN_LIFT: 0.90,
    },
    "pen": {
        AffordanceAction.CAN_GRASP: 0.95,
        AffordanceAction.CAN_WRITE_WITH: 0.95,
        AffordanceAction.CAN_LIFT: 0.95,
    },
    "bottle": {
        AffordanceAction.CAN_GRASP: 0.90,
        AffordanceAction.CAN_LIFT: 0.85,
        AffordanceAction.CAN_FILL: 0.80,
        AffordanceAction.CAN_POUR_FROM: 0.75,
        AffordanceAction.CAN_SQUEEZE: 0.40,
        AffordanceAction.CAN_ROLL: 0.50,
    },
    "table": {
        AffordanceAction.CAN_SUPPORT: 0.95,
        AffordanceAction.CAN_PUSH: 0.30,
        AffordanceAction.CAN_STACK: 0.20,
    },
    "book": {
        AffordanceAction.CAN_GRASP: 0.90,
        AffordanceAction.CAN_LIFT: 0.90,
        AffordanceAction.CAN_OPEN: 0.85,
        AffordanceAction.CAN_CLOSE: 0.85,
        AffordanceAction.CAN_STACK: 0.90,
    },
}

# Feature-to-affordance inference rules / 특징-기능성 추론 규칙
FEATURE_AFFORDANCE_RULES: List[Dict[str, Any]] = [
    {
        "condition": {"has_handle": True},
        "affordances": {
            AffordanceAction.CAN_GRASP: 0.8,
        },
    },
    {
        "condition": {"has_opening": True},
        "affordances": {
            AffordanceAction.CAN_FILL: 0.7,
            AffordanceAction.CAN_POUR_FROM: 0.5,
        },
    },
    {
        "condition": {"is_sharp": True},
        "affordances": {
            AffordanceAction.CAN_CUT_WITH: 0.8,
        },
    },
    {
        "condition": {"is_round": True},
        "affordances": {
            AffordanceAction.CAN_ROLL: 0.7,
        },
    },
    {
        "condition": {"weight_kg": ("<", 2.0)},
        "affordances": {
            AffordanceAction.CAN_LIFT: 0.8,
        },
    },
    {
        "condition": {"weight_kg": (">", 20.0)},
        "affordances": {
            AffordanceAction.CAN_SIT_ON: 0.6,
            AffordanceAction.CAN_SUPPORT: 0.7,
        },
    },
    {
        "condition": {"has_surface": True, "weight_kg": (">", 10.0)},
        "affordances": {
            AffordanceAction.CAN_SUPPORT: 0.8,
        },
    },
    {
        "condition": {"is_rigid": True, "is_fragile": False},
        "affordances": {
            AffordanceAction.CAN_PUSH: 0.5,
        },
    },
]


# ---------------------------------------------------------------------------
# AffordanceLearner / 기능성 학습기
# ---------------------------------------------------------------------------

class AffordanceLearner:
    """
    객체 기능성 학습기 / Object Affordance Learner.

    객체의 물리적 특징으로부터 기능성을 추론하고,
    탐색을 통해 학습하며, 경험을 누적합니다.

    Storage: SQLite with object features + affordance scores

    Usage:
        >>> learner = AffordanceLearner()
        >>> features = ObjectFeatures(name="cup", has_handle=True, has_opening=True)
        >>> model = learner.learn_affordances(features)
        >>> print(model.get_top_affordances(3))
    """

    def __init__(self, db_path: Optional[str] = None) -> None:
        """
        AffordanceLearner 초기화.

        Args:
            db_path: SQLite DB 경로 (None 시 메모리 DB)
        """
        self._db_path = db_path or ":memory:"
        self._db_conn: Optional[sqlite3.Connection] = None
        self._models: Dict[str, AffordanceModel] = {}
        self._init_db()
        self._load_templates()
        logger.info("AffordanceLearner 초기화: DB=%s", self._db_path)

    def _get_conn(self) -> sqlite3.Connection:
        """DB 연결 반환 (:memory: 시 캐시된 연결 사용) / Get DB connection."""
        if self._db_path == ":memory:":
            if self._db_conn is None:
                self._db_conn = sqlite3.connect(self._db_path)
            return self._db_conn
        return sqlite3.connect(self._db_path)

    def _init_db(self) -> None:
        """데이터베이스 초기화 / Initialize database."""
        try:
            conn = self._get_conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS affordance_models (
                    model_id TEXT PRIMARY KEY,
                    object_id TEXT NOT NULL,
                    object_name TEXT,
                    category TEXT,
                    features_json TEXT NOT NULL,
                    affordance_scores_json TEXT NOT NULL,
                    is_tool INTEGER DEFAULT 0,
                    tool_category TEXT DEFAULT 'unknown',
                    exploration_count INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS exploration_log (
                    exploration_id TEXT PRIMARY KEY,
                    object_id TEXT NOT NULL,
                    action TEXT NOT NULL,
                    success INTEGER DEFAULT 0,
                    observed_effect TEXT,
                    new_affordances_json TEXT,
                    safety_concern INTEGER DEFAULT 0,
                    timestamp TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_affordance_object
                ON affordance_models(object_id)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_exploration_object
                ON exploration_log(object_id)
            """)
            conn.commit()
            if self._db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("AffordanceLearner DB 초기화 실패: %s", e)
            raise

    def _load_templates(self) -> None:
        """기본 템플릿 로드 / Load default affordance templates."""
        for name, affordances in DEFAULT_AFFORDANCE_TEMPLATES.items():
            features = ObjectFeatures(
                object_id=f"template_{name}",
                name=name,
            )
            model = AffordanceModel(
                object_features=features,
            )
            for action, score in affordances.items():
                model.affordance_scores[action.value] = AffordanceScore(
                    action=action,
                    score=score,
                    confidence=0.5,  # Template confidence / 템플릿 신뢰도
                    evidence_count=1,
                    reasoning=f"기본 템플릿: {name}",
                )
            self._models[f"template_{name}"] = model
        logger.debug("기본 기능성 템플릿 %d개 로드", len(DEFAULT_AFFORDANCE_TEMPLATES))

    def learn_affordances(
        self, features: ObjectFeatures
    ) -> AffordanceModel:
        """
        객체 특징으로부터 기능성 학습 / Learn affordances from object features.

        특징 기반 추론 + 템플릿 매칭으로 초기 기능성 모델을 구축합니다.

        Args:
            features: 객체 특징

        Returns:
            AffordanceModel: 학습된 기능성 모델
        """
        obj_id = features.object_id or str(uuid.uuid4())
        features.object_id = obj_id

        # Check for existing model / 기존 모델 확인
        if obj_id in self._models:
            model = self._models[obj_id]
            model.object_features = features
            model.updated_at = datetime.now(timezone.utc).isoformat()
            logger.info("기존 모델 업데이트: %s", obj_id)
            return model

        model = AffordanceModel(object_features=features)

        # 1. Feature-based inference / 특징 기반 추론
        self._infer_from_features(model)

        # 2. Template matching / 템플릿 매칭
        self._match_templates(model)

        # 3. Category-based inference / 카테고리 기반 추론
        self._infer_from_category(model)

        # Store model / 모델 저장
        self._models[obj_id] = model
        self._save_model(model)

        logger.info(
            "기능성 학습 완료: %s (%d개 기능성)",
            features.name or obj_id,
            len(model.affordance_scores),
        )
        return model

    def _infer_from_features(self, model: AffordanceModel) -> None:
        """
        객체 특징으로부터 기능성 추론 / Infer affordances from features.

        Args:
            model: 기능성 모델 (인플레이스 업데이트)
        """
        features = model.object_features

        for rule in FEATURE_AFFORDANCE_RULES:
            condition = rule["condition"]
            matches = True

            for key, expected in condition.items():
                actual = getattr(features, key, None)
                if actual is None:
                    matches = False
                    break

                if isinstance(expected, tuple):
                    op, val = expected
                    if op == "<" and not (actual < val):
                        matches = False
                    elif op == ">" and not (actual > val):
                        matches = False
                    elif op == "==" and not (actual == val):
                        matches = False
                elif actual != expected:
                    matches = False

                if not matches:
                    break

            if matches:
                for action, score in rule["affordances"].items():
                    existing = model.affordance_scores.get(action.value)
                    if existing:
                        # Update with higher confidence / 더 높은 신뢰도로 업데이트
                        if score > existing.score:
                            existing.score = score
                            existing.evidence_count += 1
                            existing.reasoning += " | 특징 추론"
                    else:
                        model.affordance_scores[action.value] = AffordanceScore(
                            action=action,
                            score=score,
                            confidence=0.4,
                            evidence_count=1,
                            reasoning="특징 기반 추론",
                        )

    def _match_templates(self, model: AffordanceModel) -> None:
        """
        템플릿 매칭 / Match against known object templates.

        Args:
            model: 기능성 모델 (인플레이스 업데이트)
        """
        name = model.object_features.name.lower()
        template_key = f"template_{name}"

        if template_key in self._models:
            template = self._models[template_key]
            for action_str, score_obj in template.affordance_scores.items():
                existing = model.affordance_scores.get(action_str)
                if existing:
                    # Weighted average with template / 템플릿과 가중 평균
                    existing.score = (
                        existing.score * 0.6 + score_obj.score * 0.4
                    )
                    existing.confidence = min(
                        1.0, existing.confidence + 0.2
                    )
                    existing.evidence_count += 1
                else:
                    model.affordance_scores[action_str] = AffordanceScore(
                        action=score_obj.action,
                        score=score_obj.score * 0.8,
                        confidence=0.5,
                        evidence_count=1,
                        reasoning=f"템플릿 매칭: {name}",
                    )

    def _infer_from_category(self, model: AffordanceModel) -> None:
        """
        카테고리 기반 추론 / Infer affordances from object category.

        Args:
            model: 기능성 모델 (인플레이스 업데이트)
        """
        category_defaults: Dict[ObjectCategory, Dict[AffordanceAction, float]] = {
            ObjectCategory.UTENSIL: {
                AffordanceAction.CAN_GRASP: 0.85,
                AffordanceAction.CAN_LIFT: 0.80,
            },
            ObjectCategory.CONTAINER: {
                AffordanceAction.CAN_GRASP: 0.80,
                AffordanceAction.CAN_FILL: 0.75,
                AffordanceAction.CAN_POUR_FROM: 0.60,
            },
            ObjectCategory.FURNITURE: {
                AffordanceAction.CAN_SUPPORT: 0.80,
                AffordanceAction.CAN_PUSH: 0.50,
            },
            ObjectCategory.DOOR: {
                AffordanceAction.CAN_OPEN: 0.85,
                AffordanceAction.CAN_CLOSE: 0.85,
            },
            ObjectCategory.TOOL: {
                AffordanceAction.CAN_GRASP: 0.90,
                AffordanceAction.CAN_LIFT: 0.85,
            },
        }

        cat = model.object_features.category
        defaults = category_defaults.get(cat, {})
        for action, score in defaults.items():
            if action.value not in model.affordance_scores:
                model.affordance_scores[action.value] = AffordanceScore(
                    action=action,
                    score=score,
                    confidence=0.3,
                    evidence_count=0,
                    reasoning=f"카테고리 추론: {cat.value}",
                )

    def explore_object(
        self,
        object_id: str,
        action: ExplorationAction,
        observed_effect: str = "",
        success: bool = False,
    ) -> ExplorationResult:
        """
        객체 탐색 / Explore an object with a specific action.

        탐색 결과를 기반으로 기능성 점수를 업데이트합니다.

        Args:
            object_id: 객체 ID
            action: 탐색 행동
            observed_effect: 관찰된 효과
            success: 탐색 성공 여부

        Returns:
            ExplorationResult: 탐색 결과
        """
        result = ExplorationResult(
            object_id=object_id,
            action=action,
            success=success,
            observed_effect=observed_effect,
        )

        model = self._models.get(object_id)
        if model is None:
            logger.warning("탐색 대상 객체를 찾을 수 없음: %s", object_id)
            return result

        # Update affordance scores based on exploration / 탐색 기반 점수 업데이트
        action_affordance_map: Dict[ExplorationAction, List[AffordanceAction]] = {
            ExplorationAction.PUSH: [AffordanceAction.CAN_PUSH],
            ExplorationAction.LIFT: [AffordanceAction.CAN_LIFT],
            ExplorationAction.ROTATE: [AffordanceAction.CAN_ROTATE],
            ExplorationAction.POKE: [AffordanceAction.CAN_PUSH],
            ExplorationAction.SQUEEZE: [AffordanceAction.CAN_SQUEEZE],
            ExplorationAction.TILT: [AffordanceAction.CAN_ROTATE],
            ExplorationAction.SHAKE: [AffordanceAction.CAN_GRASP],
            ExplorationAction.DROP: [AffordanceAction.CAN_LIFT],
            ExplorationAction.SLIDE: [AffordanceAction.CAN_PUSH],
        }

        affected_actions = action_affordance_map.get(action, [])

        for aff_action in affected_actions:
            existing = model.affordance_scores.get(aff_action.value)
            if existing:
                # Update score based on success/failure / 성공/실패 기반 점수 업데이트
                if success:
                    existing.score = min(
                        1.0,
                        existing.score * 0.7 + 0.3 * 1.0,
                    )
                    existing.confidence = min(1.0, existing.confidence + 0.1)
                else:
                    existing.score = max(
                        0.0,
                        existing.score * 0.7 + 0.3 * 0.0,
                    )
                existing.evidence_count += 1
                existing.last_tested = datetime.now(timezone.utc).isoformat()
                existing.reasoning += f" | 탐색({action.value}): {'성공' if success else '실패'}"
                result.updated_scores[aff_action.value] = existing.score
            else:
                # New affordance discovered from exploration / 탐색으로 새 기능성 발견
                new_score = 0.7 if success else 0.3
                model.affordance_scores[aff_action.value] = AffordanceScore(
                    action=aff_action,
                    score=new_score,
                    confidence=0.5,
                    evidence_count=1,
                    last_tested=datetime.now(timezone.utc).isoformat(),
                    reasoning=f"탐색 발견({action.value}): {'성공' if success else '실패'}",
                )
                result.new_affordances.append(aff_action)
                result.updated_scores[aff_action.value] = new_score

        # Record exploration / 탐색 기록
        model.exploration_history.append({
            "action": action.value,
            "success": success,
            "effect": observed_effect,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        model.updated_at = datetime.now(timezone.utc).isoformat()

        # Save exploration log / 탐색 로그 저장
        self._save_exploration(result)

        # Check for safety concerns / 안전 우려 확인
        if observed_effect and any(
            kw in observed_effect.lower()
            for kw in ["break", "crack", "sharp", "dangerous", "불안", "위험"]
        ):
            result.safety_concern = True
            logger.warning("탐색 중 안전 우려 감지: %s", observed_effect)

        logger.info(
            "객체 탐색: %s - %s (%s), 효과: %s",
            object_id, action.value,
            "성공" if success else "실패",
            observed_effect[:30] if observed_effect else "없음",
        )

        return result

    def get_model(self, object_id: str) -> Optional[AffordanceModel]:
        """
        기능성 모델 조회 / Get affordance model for an object.

        Args:
            object_id: 객체 ID

        Returns:
            Optional[AffordanceModel]: 기능성 모델 (없으면 None)
        """
        return self._models.get(object_id)

    def find_similar_objects(
        self, features: ObjectFeatures, limit: int = 5
    ) -> List[Tuple[str, float]]:
        """
        유사 객체 검색 / Find objects with similar features.

        Args:
            features: 비교할 객체 특징
            limit: 최대 반환 개수

        Returns:
            List of (object_id, similarity_score) tuples
        """
        similarities: List[Tuple[str, float]] = []

        for obj_id, model in self._models.items():
            if obj_id.startswith("template_"):
                continue

            sim = self._compute_similarity(
                features, model.object_features
            )
            similarities.append((obj_id, sim))

        similarities.sort(key=lambda x: x[1], reverse=True)
        return similarities[:limit]

    def _compute_similarity(
        self, f1: ObjectFeatures, f2: ObjectFeatures
    ) -> float:
        """
        객체 특징 유사도 계산 / Compute similarity between two objects.

        Args:
            f1: 첫 번째 객체 특징
            f2: 두 번째 객체 특징

        Returns:
            float: 유사도 (0.0 ~ 1.0)
        """
        score = 0.0
        count = 0

        # Category match / 카테고리 일치
        if f1.category != ObjectCategory.UNKNOWN and f2.category != ObjectCategory.UNKNOWN:
            score += 1.0 if f1.category == f2.category else 0.0
            count += 1

        # Boolean features / 불린 특징
        bool_features = [
            "is_rigid", "is_fragile", "has_handle",
            "has_opening", "has_surface", "is_sharp", "is_round",
        ]
        for feat in bool_features:
            v1 = getattr(f1, feat, None)
            v2 = getattr(f2, feat, None)
            if v1 is not None and v2 is not None:
                score += 1.0 if v1 == v2 else 0.0
                count += 1

        # Shape match / 형태 일치
        if f1.shape and f2.shape:
            score += 1.0 if f1.shape == f2.shape else 0.0
            count += 1

        return score / max(count, 1)

    def _save_model(self, model: AffordanceModel) -> None:
        """
        모델을 DB에 저장 / Save model to database.

        Args:
            model: 저장할 기능성 모델
        """
        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT OR REPLACE INTO affordance_models
                    (model_id, object_id, object_name, category,
                     features_json, affordance_scores_json,
                     is_tool, tool_category, exploration_count,
                     created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    model.model_id,
                    model.object_features.object_id,
                    model.object_features.name,
                    model.object_features.category.value,
                    json.dumps({
                        "weight_kg": model.object_features.weight_kg,
                        "is_rigid": model.object_features.is_rigid,
                        "has_handle": model.object_features.has_handle,
                        "has_opening": model.object_features.has_opening,
                        "has_surface": model.object_features.has_surface,
                        "is_sharp": model.object_features.is_sharp,
                        "is_round": model.object_features.is_round,
                        "shape": model.object_features.shape,
                    }, ensure_ascii=False),
                    json.dumps({
                        k: {
                            "score": v.score,
                            "confidence": v.confidence,
                            "evidence_count": v.evidence_count,
                            "reasoning": v.reasoning,
                        }
                        for k, v in model.affordance_scores.items()
                    }, ensure_ascii=False),
                    int(model.is_tool),
                    model.tool_category.value,
                    len(model.exploration_history),
                    model.created_at,
                    model.updated_at,
                ),
            )
            conn.commit()
            if self._db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("모델 저장 실패: %s", e)

    def _save_exploration(self, result: ExplorationResult) -> None:
        """
        탐색 결과를 DB에 저장 / Save exploration result to database.

        Args:
            result: 탐색 결과
        """
        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT INTO exploration_log
                    (exploration_id, object_id, action, success,
                     observed_effect, new_affordances_json,
                     safety_concern, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    result.exploration_id,
                    result.object_id,
                    result.action.value,
                    int(result.success),
                    result.observed_effect,
                    json.dumps(
                        [a.value for a in result.new_affordances],
                        ensure_ascii=False,
                    ),
                    int(result.safety_concern),
                    result.timestamp,
                ),
            )
            conn.commit()
            if self._db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("탐색 로그 저장 실패: %s", e)

    def get_all_models(self) -> Dict[str, AffordanceModel]:
        """
        모든 기능성 모델 반환 / Return all affordance models.

        Returns:
            Dict: 객체 ID → 기능성 모델 매핑
        """
        return dict(self._models)

    # ------------------------------------------------------------------
    # Physical AGI Methods / Physical AGI 메서드
    # ------------------------------------------------------------------

    def predict_physical_affordances(
        self, object_properties: Dict[str, Any]
    ) -> Dict[str, float]:
        """
        객체의 물리적 속성으로부터 기능성 예측 / Predict physical affordances from object properties.

        Physical AGI 핵심 메서드: 객체의 질량, 파편성, 형태 등 물리적 속성을
        기반으로 어떤 물리적 행동이 가능한지 예측합니다. 이 정보는 실제
        물리적 상호작용 이전에 행동 계획에 활용됩니다.

        Physical AGI core method: predicts which physical actions are possible
        with an object based on its physical properties (mass, fragility, shape).
        This is used for action planning before actual physical interaction.

        Args:
            object_properties: 객체 물리 속성 딕셔너리
                - mass_kg (float): 질량 (kg) / mass in kg
                - fragility (float): 파편성 0~1 / fragility 0-1
                - shape (str): 형태 (box, cylinder, sphere, irregular)
                - is_rigid (bool): 강성 여부 / rigidity
                - has_handle (bool): 손잡이 여부 / handle presence
                - surface_friction (float): 마찰계수 0~1 / surface friction

        Returns:
            Dict[str, float]: 기능성 예측 결과 {action_name: probability}
        """
        predictions: Dict[str, float] = {}

        # 질량 기반 예측 / Mass-based prediction
        mass = object_properties.get("mass_kg", 1.0)
        if mass < 0.5:
            predictions["can_lift"] = 0.95
            predictions["can_throw"] = 0.80
            predictions["can_place_precisely"] = 0.75
        elif mass < 5.0:
            predictions["can_lift"] = 0.80
            predictions["can_throw"] = 0.40
            predictions["can_place_precisely"] = 0.60
        elif mass < 20.0:
            predictions["can_lift"] = 0.40
            predictions["can_push"] = 0.80
            predictions["can_place_precisely"] = 0.20
        else:
            predictions["can_lift"] = 0.05
            predictions["can_push"] = 0.60
            predictions["can_climb_on"] = 0.70

        # 파편성 기반 예측 / Fragility-based prediction
        fragility = object_properties.get("fragility", 0.0)
        if fragility > 0.7:
            predictions["can_squeeze"] = 0.10
            predictions["requires_gentle_grip"] = 0.90
            predictions["can_drop_safely"] = 0.05
        elif fragility > 0.3:
            predictions["requires_gentle_grip"] = 0.50
            predictions["can_drop_safely"] = 0.30
        else:
            predictions["can_squeeze"] = 0.70
            predictions["can_drop_safely"] = 0.80

        # 형태 기반 예측 / Shape-based prediction
        shape = object_properties.get("shape", "box")
        if shape == "sphere":
            predictions["can_roll"] = 0.85
            predictions["can_stack"] = 0.15
            predictions["can_grasp_stably"] = 0.40
        elif shape == "cylinder":
            predictions["can_roll"] = 0.70
            predictions["can_stack"] = 0.60
            predictions["can_grasp_stably"] = 0.75
        elif shape == "box":
            predictions["can_roll"] = 0.05
            predictions["can_stack"] = 0.85
            predictions["can_grasp_stably"] = 0.90
        else:  # irregular
            predictions["can_roll"] = 0.20
            predictions["can_stack"] = 0.20
            predictions["can_grasp_stably"] = 0.50

        # 강성 기반 예측 / Rigidity-based prediction
        is_rigid = object_properties.get("is_rigid", True)
        if not is_rigid:
            predictions["can_deform"] = 0.80
            predictions["can_fold"] = 0.60
            predictions["can_squeeze_into_gap"] = 0.70

        # 손잡이 기반 예측 / Handle-based prediction
        has_handle = object_properties.get("has_handle", False)
        if has_handle:
            predictions["can_grasp_stably"] = min(
                1.0, predictions.get("can_grasp_stably", 0.5) + 0.3
            )
            predictions["can_hang"] = 0.75
            predictions["can_pull"] = 0.80

        # 마찰계수 기반 예측 / Friction-based prediction
        friction = object_properties.get("surface_friction", 0.5)
        if friction < 0.2:
            predictions["can_slide"] = 0.85
            predictions["grip_requires_pressure"] = 0.90
        elif friction > 0.7:
            predictions["can_slide"] = 0.15
            predictions["grip_requires_pressure"] = 0.20

        logger.info(
            "물리적 기능성 예측 완료 / Physical affordances predicted: %d actions for object (mass=%.1fkg, shape=%s)",
            len(predictions), mass, shape,
        )
        return predictions

    def _update_from_physical_experience(
        self, experience: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        물리적 경험으로부터 기능성 모델 업데이트 / Update affordance model from physical experience.

        Physical AGI 핵심 메서드: 로봇이 객체와 물리적으로 상호작용한 결과를
        바탕으로 기능성 모델을 업데이트합니다. 예측과 실제 결과의 차이를
        학습 신호로 사용하여 모델을 개선합니다.

        Physical AGI core method: updates affordance models based on actual
        physical interaction outcomes. The gap between prediction and reality
        serves as the learning signal for model refinement.

        Args:
            experience: 물리적 상호작용 경험 딕셔너리
                - object_id (str): 객체 ID
                - action_attempted (str): 시도한 행동
                - action_succeeded (bool): 행동 성공 여부
                - predicted_probability (float): 예측된 성공 확률
                - observed_force (float): 관측된 힘 (N)
                - observed_deformation (float): 관측된 변형량
                - terrain_type (str): 지형 유형 (flat, inclined, rough)

        Returns:
            Dict[str, Any]: 업데이트 결과 {updated_actions, prediction_error, learning_signal}
        """
        object_id = experience.get("object_id", "")
        action = experience.get("action_attempted", "")
        succeeded = experience.get("action_succeeded", False)
        predicted = experience.get("predicted_probability", 0.5)

        if not object_id or not action:
            logger.warning("물리적 경험 업데이트: 필수 필드 누락 / Missing required fields")
            return {"status": "error", "reason": "missing_fields"}

        # 예측 오차 계산 / Compute prediction error
        actual = 1.0 if succeeded else 0.0
        prediction_error = abs(predicted - actual)

        # 학습 신호 생성 / Generate learning signal
        # 예측 오차가 클수록 더 많이 학습 / Larger prediction error = more learning
        learning_rate = 0.3
        learning_signal = prediction_error * learning_rate

        # 모델 업데이트 / Update model
        updated_actions: Dict[str, float] = {}
        model = self._models.get(object_id)
        if model:
            # 기존 점수 업데이트 / Update existing score
            for action_key, score_obj in model.affordance_scores.items():
                if action_key == action or action in action_key:
                    old_score = score_obj.score
                    new_score = old_score + learning_signal * (actual - old_score)
                    score_obj.score = max(0.0, min(1.0, new_score))
                    score_obj.evidence_count += 1
                    score_obj.reasoning += f" | 물리경험({action}): {'성공' if succeeded else '실패'}"
                    updated_actions[action_key] = score_obj.score

            # 물리적 관측(힘, 변형) 기반 추가 업데이트 / Additional update from physical observations
            observed_force = experience.get("observed_force", 0.0)
            observed_deformation = experience.get("observed_deformation", 0.0)

            if observed_force > 0:
                # 큰 힘이 필요했다면 무거운 객체 / High force = heavy object
                if observed_force > 20.0:
                    for key in ["can_lift", "can_throw"]:
                        if key in model.affordance_scores:
                            model.affordance_scores[key].score *= 0.8  # Lower probability
                            updated_actions[key] = model.affordance_scores[key].score

            if observed_deformation > 0.1:
                # 변형이 관측되면 비강성 객체 / Deformation = non-rigid object
                model.object_features.is_rigid = False
                if "can_squeeze" not in model.affordance_scores:
                    model.affordance_scores["can_squeeze"] = AffordanceScore(
                        action=AffordanceAction.CAN_SQUEEZE,
                        score=0.6,
                        confidence=0.5,
                        evidence_count=1,
                        reasoning="물리경험: 변형 관측됨 / Physical experience: deformation observed",
                    )
                    updated_actions["can_squeeze"] = 0.6

            model.updated_at = datetime.now(timezone.utc).isoformat()
            self._save_model(model)

        result = {
            "status": "updated",
            "object_id": object_id,
            "action": action,
            "prediction_error": round(prediction_error, 4),
            "learning_signal": round(learning_signal, 4),
            "updated_actions": updated_actions,
        }

        logger.info(
            "물리적 경험 반영 / Physical experience integrated: %s/%s error=%.3f signal=%.3f",
            object_id, action, prediction_error, learning_signal,
        )
        return result

    def get_exploration_history(
        self, object_id: Optional[str] = None, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        탐색 이력 조회 / Get exploration history.

        Args:
            object_id: 객체 ID 필터 (None이면 전체)
            limit: 최대 조회 건수

        Returns:
            List[Dict]: 탐색 이력
        """
        try:
            conn = self._get_conn()
            conn.row_factory = sqlite3.Row
            if object_id:
                rows = conn.execute(
                    """
                    SELECT * FROM exploration_log
                    WHERE object_id = ?
                    ORDER BY timestamp DESC LIMIT ?
                    """,
                    (object_id, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT * FROM exploration_log
                    ORDER BY timestamp DESC LIMIT ?
                    """,
                    (limit,),
                ).fetchall()
            if self._db_path != ":memory:":
                conn.close()
            return [dict(r) for r in rows]
        except sqlite3.Error as e:
            logger.error("탐색 이력 조회 실패: %s", e)
            return []


# ---------------------------------------------------------------------------
# ToolDiscovery / 도구 발견기
# ---------------------------------------------------------------------------

class ToolDiscovery:
    """
    도구 발견 및 학습기 / Tool Discovery and Learning.

    익숙하지 않은 객체를 도구로 인식하고, 사용법을 학습합니다.

    Discovery Process / 발견 프로세스:
      1. Identify unfamiliar object
      2. Physical exploration (push, lift, rotate)
      3. Observe effects
      4. Build affordance model
      5. Try using as tool for tasks

    Usage:
        >>> discovery = ToolDiscovery()
        >>> is_tool = discovery.identify_as_tool(model)
        >>> if is_tool:
        ...     pattern = discovery.learn_usage(model, "cut paper")
    """

    # Tool identification criteria / 도구 식별 기준
    TOOL_INDICATORS: Dict[ToolCategory, Dict[str, Any]] = {
        ToolCategory.CUTTING: {
            "required_affordances": [AffordanceAction.CAN_CUT_WITH],
            "features": {"is_sharp": True},
            "min_affordance_score": 0.6,
        },
        ToolCategory.GRASPING: {
            "required_affordances": [AffordanceAction.CAN_GRASP],
            "features": {"has_handle": True},
            "min_affordance_score": 0.7,
        },
        ToolCategory.CONTAINER: {
            "required_affordances": [
                AffordanceAction.CAN_FILL, AffordanceAction.CAN_GRASP
            ],
            "features": {"has_opening": True},
            "min_affordance_score": 0.5,
        },
        ToolCategory.WRITING: {
            "required_affordances": [AffordanceAction.CAN_WRITE_WITH],
            "features": {"is_sharp": False},
            "min_affordance_score": 0.6,
        },
        ToolCategory.CLEANING: {
            "required_affordances": [AffordanceAction.CAN_CLEAN_WITH],
            "features": {},
            "min_affordance_score": 0.5,
        },
        ToolCategory.STRIKING: {
            "required_affordances": [AffordanceAction.CAN_LIFT],
            "features": {"is_rigid": True, "weight_kg": (">", 0.3)},
            "min_affordance_score": 0.5,
        },
    }

    def __init__(
        self,
        affordance_learner: Optional[AffordanceLearner] = None,
        db_path: Optional[str] = None,
    ) -> None:
        """
        ToolDiscovery 초기화.

        Args:
            affordance_learner: 기능성 학습기 인스턴스
            db_path: SQLite DB 경로
        """
        self._learner = affordance_learner or AffordanceLearner(
            db_path=db_path
        )
        self._tool_patterns: Dict[str, ToolUsagePattern] = {}
        self._tool_db_path = db_path or ":memory:"
        self._tool_db_conn: Optional[sqlite3.Connection] = None
        self._init_tool_db()
        logger.info("ToolDiscovery 초기화 완료")

    def _get_tool_conn(self) -> sqlite3.Connection:
        """도구 DB 연결 반환 / Get tool DB connection."""
        if self._tool_db_path == ":memory:":
            if self._tool_db_conn is None:
                self._tool_db_conn = sqlite3.connect(self._tool_db_path)
            return self._tool_db_conn
        return sqlite3.connect(self._tool_db_path)

    def _init_tool_db(self) -> None:
        """도구 DB 초기화 / Initialize tool database."""
        try:
            conn = self._get_tool_conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tool_patterns (
                    pattern_id TEXT PRIMARY KEY,
                    tool_category TEXT NOT NULL,
                    task_description TEXT,
                    korean_description TEXT,
                    required_affordances_json TEXT,
                    usage_steps_json TEXT,
                    success_rate REAL DEFAULT 0.0,
                    practice_count INTEGER DEFAULT 0,
                    mastery_level REAL DEFAULT 0.0,
                    last_used TEXT
                )
            """)
            conn.commit()
            if self._tool_db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("도구 DB 초기화 실패: %s", e)

    def identify_as_tool(
        self, model: AffordanceModel
    ) -> Tuple[bool, ToolCategory]:
        """
        객체를 도구로 식별 / Identify if an object is a tool.

        기능성 점수와 물리적 특징을 기반으로 도구 여부를 판정합니다.

        Args:
            model: 객체 기능성 모델

        Returns:
            Tuple[bool, ToolCategory]: (도구 여부, 도구 카테고리)
        """
        best_category = ToolCategory.UNKNOWN
        best_score = 0.0

        for category, criteria in self.TOOL_INDICATORS.items():
            score = 0.0
            max_score = 0.0

            # Check affordances / 기능성 확인
            for req_action in criteria.get("required_affordances", []):
                max_score += 1.0
                aff_score = model.affordance_scores.get(req_action.value)
                if aff_score and aff_score.score >= criteria.get(
                    "min_affordance_score", 0.5
                ):
                    score += aff_score.score

            # Check features / 특징 확인
            features = criteria.get("features", {})
            for feat_name, expected in features.items():
                max_score += 1.0
                actual = getattr(model.object_features, feat_name, None)
                if actual is None:
                    continue
                if isinstance(expected, tuple):
                    op, val = expected
                    if op == ">" and actual > val:
                        score += 1.0
                    elif op == "<" and actual < val:
                        score += 1.0
                elif actual == expected:
                    score += 1.0

            # Compute category score / 카테고리 점수 계산
            if max_score > 0:
                category_score = score / max_score
            else:
                category_score = 0.0

            if category_score > best_score:
                best_score = category_score
                best_category = category

        is_tool = best_score >= 0.5

        if is_tool:
            model.is_tool = True
            model.tool_category = best_category
            logger.info(
                "도구 식별: %s → %s (점수: %.2f)",
                model.object_features.name or model.object_features.object_id,
                TOOL_CATEGORY_KOREAN.get(best_category, best_category.value),
                best_score,
            )
        else:
            logger.debug(
                "도구 아님: %s (최고 점수: %.2f)",
                model.object_features.name, best_score,
            )

        return is_tool, best_category

    def learn_usage(
        self,
        model: AffordanceModel,
        task_description: str,
        korean_description: str = "",
        usage_steps: Optional[List[str]] = None,
    ) -> ToolUsagePattern:
        """
        도구 사용법 학습 / Learn tool usage pattern.

        Args:
            model: 도구 기능성 모델
            task_description: 작업 설명 (영어)
            korean_description: 작업 설명 (한국어)
            usage_steps: 사용 단계

        Returns:
            ToolUsagePattern: 학습된 사용 패턴
        """
        if not model.is_tool:
            logger.warning("도구가 아닌 객체의 사용법 학습 시도: %s", model.object_features.name)
            model.is_tool = True

        pattern = ToolUsagePattern(
            tool_category=model.tool_category,
            task_description=task_description,
            korean_description=korean_description,
            required_affordances=[
                AffordanceAction(a) for a in model.affordance_scores
                if model.affordance_scores[a].score >= 0.5
            ],
            usage_steps=usage_steps or [],
            practice_count=0,
            mastery_level=0.0,
        )

        self._tool_patterns[pattern.pattern_id] = pattern

        # Store in model / 모델에 저장
        model.tool_usage_patterns.append({
            "pattern_id": pattern.pattern_id,
            "task": task_description,
            "category": model.tool_category.value,
        })

        logger.info(
            "도구 사용법 학습: %s → %s (%s)",
            model.object_features.name,
            task_description,
            TOOL_CATEGORY_KOREAN.get(model.tool_category, "?"),
        )

        return pattern

    def practice_tool(
        self,
        pattern_id: str,
        success: bool,
    ) -> Optional[ToolUsagePattern]:
        """
        도구 사용 연습 / Practice tool usage and update mastery.

        Args:
            pattern_id: 사용 패턴 ID
            success: 사용 성공 여부

        Returns:
            Optional[ToolUsagePattern]: 업데이트된 사용 패턴
        """
        pattern = self._tool_patterns.get(pattern_id)
        if pattern is None:
            logger.warning("사용 패턴을 찾을 수 없음: %s", pattern_id)
            return None

        pattern.practice_count += 1

        # Update success rate / 성공률 업데이트
        if pattern.practice_count == 1:
            pattern.success_rate = 1.0 if success else 0.0
        else:
            alpha = 0.3  # Learning rate / 학습률
            pattern.success_rate = (
                pattern.success_rate * (1 - alpha)
                + (1.0 if success else 0.0) * alpha
            )

        # Update mastery level / 숙련도 업데이트
        # Mastery depends on success rate and practice count
        practice_factor = min(1.0, pattern.practice_count / 20.0)
        pattern.mastery_level = pattern.success_rate * practice_factor
        pattern.last_used = datetime.now(timezone.utc).isoformat()

        logger.info(
            "도구 연습: %s (%s) - 성공률: %.2f, 숙련도: %.2f",
            pattern.task_description,
            "성공" if success else "실패",
            pattern.success_rate,
            pattern.mastery_level,
        )

        return pattern

    def find_tool_for_task(
        self, task_description: str, required_actions: Optional[List[AffordanceAction]] = None
    ) -> List[Tuple[str, ToolUsagePattern]]:
        """
        작업에 적합한 도구 검색 / Find suitable tools for a task.

        Args:
            task_description: 작업 설명
            required_actions: 필수 기능성 목록

        Returns:
            List of (object_id, pattern) tuples
        """
        results: List[Tuple[str, ToolUsagePattern]] = []

        for obj_id, model in self._learner.get_all_models().items():
            if not model.is_tool:
                continue

            # Check if model has required affordances / 필수 기능성 확인
            if required_actions:
                has_all = all(
                    model.can_perform(action, threshold=0.5)
                    for action in required_actions
                )
                if not has_all:
                    continue

            # Find matching patterns / 매칭 패턴 검색
            for pattern in self._tool_patterns.values():
                if pattern.tool_category == model.tool_category:
                    results.append((obj_id, pattern))

        # Sort by mastery level / 숙련도 기반 정렬
        results.sort(key=lambda x: x[1].mastery_level, reverse=True)
        return results

    def discover_and_explore(
        self, features: ObjectFeatures
    ) -> AffordanceModel:
        """
        객체 발견 및 탐색 파이프라인 / Discovery and exploration pipeline.

        전체 프로세스:
        1. 기능성 학습
        2. 도구 식별
        3. 기본 탐색 수행

        Args:
            features: 객체 특징

        Returns:
            AffordanceModel: 학습된 기능성 모델
        """
        # 1. Learn affordances / 기능성 학습
        model = self._learner.learn_affordances(features)

        # 2. Identify as tool / 도구 식별
        is_tool, category = self.identify_as_tool(model)

        # 3. Basic exploration / 기본 탐색
        if model.exploration_history:
            # Already explored / 이미 탐색됨
            return model

        exploration_actions = self._get_exploration_plan(model)
        for action in exploration_actions:
            self._learner.explore_object(
                object_id=model.object_features.object_id,
                action=action,
                observed_effect="자동 탐색",
                success=True,  # Default to success for simulation
            )

        logger.info(
            "발견 및 탐색 완료: %s (도구: %s, 카테고리: %s)",
            features.name,
            "예" if is_tool else "아니오",
            TOOL_CATEGORY_KOREAN.get(category, "?"),
        )

        return model

    def _get_exploration_plan(
        self, model: AffordanceModel
    ) -> List[ExplorationAction]:
        """
        탐색 계획 생성 / Generate exploration plan for an object.

        Args:
            model: 기능성 모델

        Returns:
            List[ExplorationAction]: 탐색 행동 목록
        """
        plan: List[ExplorationAction] = []

        # Always try basic interactions / 기본 상호작용 시도
        plan.append(ExplorationAction.PUSH)

        if model.object_features.weight_kg < 10.0:
            plan.append(ExplorationAction.LIFT)

        if model.object_features.is_round:
            plan.append(ExplorationAction.ROTATE)

        if not model.object_features.is_rigid:
            plan.append(ExplorationAction.SQUEEZE)

        # Limit exploration / 탐색 제한
        return plan[:5]

    def get_tool_patterns(self) -> Dict[str, ToolUsagePattern]:
        """
        모든 도구 사용 패턴 반환 / Return all tool usage patterns.

        Returns:
            Dict: 패턴 ID → 사용 패턴 매핑
        """
        return dict(self._tool_patterns)

    def get_mastery_report(self) -> Dict[str, Any]:
        """
        도구 숙련도 보고서 생성 / Generate tool mastery report.

        Returns:
            Dict: 숙련도 보고서
        """
        total_tools = sum(
            1 for m in self._learner.get_all_models().values() if m.is_tool
        )
        mastered = sum(
            1 for p in self._tool_patterns.values()
            if p.mastery_level >= 0.8
        )
        practicing = sum(
            1 for p in self._tool_patterns.values()
            if 0.2 <= p.mastery_level < 0.8
        )
        beginner = sum(
            1 for p in self._tool_patterns.values()
            if p.mastery_level < 0.2
        )

        return {
            "total_tools_known": total_tools,
            "mastered_tools": mastered,
            "practicing_tools": practicing,
            "beginner_tools": beginner,
            "total_patterns": len(self._tool_patterns),
            "average_mastery": (
                statistics.mean([p.mastery_level for p in self._tool_patterns.values()])
                if self._tool_patterns else 0.0
            ),
        }


# ---------------------------------------------------------------------------
# AffordancePredictorNet / 기능성 예측 신경망
# ---------------------------------------------------------------------------

class AffordancePredictorNet:
    """
    Neural network for visual+tactile affordance prediction.
    시각+촉각 기반 기능성 예측 신경망.

    시각 및 촉각 특징을 결합하여 15가지 기능성 점수를 예측합니다.
    누적된 기능성 경험으로부터 학습합니다.

    15 affordances:
        can_grasp, can_lift, can_push, can_pull, can_rotate,
        can_squeeze, can_pour, can_stack, can_insert, can_cut,
        can_hold, can_throw, can_roll, can_flip, can_puncture

    Usage:
        >>> net = AffordancePredictorNet(visual_dim=128, tactile_dim=64)
        >>> scores = net.predict_affordances(visual_features, tactile_features)
    """

    AFFORDANCE_NAMES: List[str] = [
        "can_grasp", "can_lift", "can_push", "can_pull", "can_rotate",
        "can_squeeze", "can_pour", "can_stack", "can_insert", "can_cut",
        "can_hold", "can_throw", "can_roll", "can_flip", "can_puncture",
    ]

    def __init__(
        self,
        visual_dim: int = 128,
        tactile_dim: int = 64,
        n_affordances: int = 15,
    ) -> None:
        """
        AffordancePredictorNet 초기화 / Initialize AffordancePredictorNet.

        Args:
            visual_dim: 시각 특징 벡터 차원 / Visual feature vector dimension
            tactile_dim: 촉각 특징 벡터 차원 / Tactile feature vector dimension
            n_affordances: 예측할 기능성 수 / Number of affordances to predict
        """
        self.visual_dim = visual_dim
        self.tactile_dim = tactile_dim
        self.n_affordances = n_affordances

        # Shared encoder weights / 공유 인코더 가중치
        # FC(visual_dim + tactile_dim → 256) + ReLU + BN
        # FC(256 → 256) + ReLU + BN
        self._encoder_W1: Optional[Any] = None  # (visual_dim+tactile_dim, 256)
        self._encoder_b1: Optional[Any] = None  # (256,)
        self._encoder_bn1_running_mean: Optional[Any] = None
        self._encoder_bn1_running_var: Optional[Any] = None

        self._encoder_W2: Optional[Any] = None  # (256, 256)
        self._encoder_b2: Optional[Any] = None  # (256,)
        self._encoder_bn2_running_mean: Optional[Any] = None
        self._encoder_bn2_running_var: Optional[Any] = None

        # Affordance head weights / 기능성 헤드 가중치
        # FC(256 → n_affordances) + sigmoid
        self._head_W: Optional[Any] = None  # (256, n_affordances)
        self._head_b: Optional[Any] = None  # (n_affordances,)

        # Training state / 학습 상태
        self._training_samples: List[Dict[str, Any]] = []
        self._is_initialized: bool = False

        self._initialize_weights()
        logger.info(
            "AffordancePredictorNet 초기화: visual=%d, tactile=%d, n_affordances=%d",
            visual_dim, tactile_dim, n_affordances,
        )

    def _initialize_weights(self) -> None:
        """가중치 초기화 / Initialize network weights with Xavier init."""
        try:
            import numpy as _np

            input_dim = self.visual_dim + self.tactile_dim

            # Encoder Layer 1 / 인코더 레이어 1
            self._encoder_W1 = _np.random.randn(input_dim, 256) * _np.sqrt(2.0 / input_dim)
            self._encoder_b1 = _np.zeros(256)
            self._encoder_bn1_running_mean = _np.zeros(256)
            self._encoder_bn1_running_var = _np.ones(256)

            # Encoder Layer 2 / 인코더 레이어 2
            self._encoder_W2 = _np.random.randn(256, 256) * _np.sqrt(2.0 / 256)
            self._encoder_b2 = _np.zeros(256)
            self._encoder_bn2_running_mean = _np.zeros(256)
            self._encoder_bn2_running_var = _np.ones(256)

            # Affordance head / 기능성 헤드
            self._head_W = _np.random.randn(256, self.n_affordances) * _np.sqrt(2.0 / 256)
            self._head_b = _np.zeros(self.n_affordances)

            self._is_initialized = True
        except ImportError:
            logger.warning("numpy 미설치 — 가중치 초기화 생략 / numpy not available — weights not initialized")

    def _relu(self, x: Any) -> Any:
        """ReLU 활성화 함수 / ReLU activation function."""
        import numpy as _np
        return _np.maximum(0, x)

    def _batch_norm(
        self,
        x: Any,
        running_mean: Any,
        running_var: Any,
        momentum: float = 0.1,
    ) -> Any:
        """
        배치 정규화 (추론 모드) / Batch normalization (inference mode).

        Running statistics를 사용하여 정규화합니다.
        """
        import numpy as _np
        eps = 1e-5
        x_norm = (x - running_mean) / _np.sqrt(running_var + eps)
        return x_norm

    def _sigmoid(self, x: Any) -> Any:
        """Sigmoid 활성화 함수 / Sigmoid activation function."""
        import numpy as _np
        return 1.0 / (1.0 + _np.exp(-_np.clip(x, -500, 500)))

    def _forward(self, visual_features: Any, tactile_features: Any) -> Any:
        """
        순전파 / Forward pass through the network.

        Args:
            visual_features: 시각 특징 벡터 / Visual feature vector
            tactile_features: 촉각 특징 벡터 / Tactile feature vector

        Returns:
            기능성 점수 벡터 (0~1) / Affordance score vector (0~1)
        """
        import numpy as _np

        if not self._is_initialized:
            return _np.zeros(self.n_affordances)

        # Concatenate inputs / 입력 결합
        if isinstance(visual_features, (list, tuple)):
            visual_features = _np.array(visual_features, dtype=_np.float32)
        if isinstance(tactile_features, (list, tuple)):
            tactile_features = _np.array(tactile_features, dtype=_np.float32)

        # Pad or truncate to expected dimensions / 예상 차원으로 패딩 또는 잘라내기
        if len(visual_features) < self.visual_dim:
            visual_features = _np.pad(visual_features, (0, self.visual_dim - len(visual_features)))
        elif len(visual_features) > self.visual_dim:
            visual_features = visual_features[:self.visual_dim]

        if len(tactile_features) < self.tactile_dim:
            tactile_features = _np.pad(tactile_features, (0, self.tactile_dim - len(tactile_features)))
        elif len(tactile_features) > self.tactile_dim:
            tactile_features = tactile_features[:self.tactile_dim]

        combined = _np.concatenate([visual_features, tactile_features])

        # Encoder Layer 1 / 인코더 레이어 1
        h = combined @ self._encoder_W1 + self._encoder_b1
        h = self._batch_norm(h, self._encoder_bn1_running_mean, self._encoder_bn1_running_var)
        h = self._relu(h)

        # Encoder Layer 2 / 인코더 레이어 2
        h = h @ self._encoder_W2 + self._encoder_b2
        h = self._batch_norm(h, self._encoder_bn2_running_mean, self._encoder_bn2_running_var)
        h = self._relu(h)

        # Affordance head / 기능성 헤드
        logits = h @ self._head_W + self._head_b
        scores = self._sigmoid(logits)

        return scores

    def predict_affordances(
        self,
        visual_features: Any,
        tactile_features: Any,
    ) -> Dict[str, float]:
        """
        시각+촉각 특징으로 기능성 예측 / Predict affordances from visual+tactile features.

        Args:
            visual_features: 시각 특징 벡터 (list, tuple, or ndarray)
            tactile_features: 촉각 특징 벡터 (list, tuple, or ndarray)

        Returns:
            Dict[str, float]: 기능성 이름 → 점수 (0~1) 매핑
        """
        scores = self._forward(visual_features, tactile_features)

        result: Dict[str, float] = {}
        for i, name in enumerate(self.AFFORDANCE_NAMES[:self.n_affordances]):
            val = float(scores[i]) if hasattr(scores, '__len__') else 0.0
            result[name] = max(0.0, min(1.0, val))

        return result

    def train_on_experience(
        self,
        visual_features: Any,
        tactile_features: Any,
        target_affordances: Dict[str, float],
        learning_rate: float = 0.001,
    ) -> float:
        """
        누적 기능성 경험으로 학습 / Train on accumulated affordance experiences.

        단순한 gradient descent로 가중치를 업데이트합니다.

        Args:
            visual_features: 시각 특징 벡터
            tactile_features: 촉각 특징 벡터
            target_affordances: 목표 기능성 점수 {name: score}
            learning_rate: 학습률

        Returns:
            float: 손실 값 (MSE)
        """
        import numpy as _np

        if not self._is_initialized:
            return 0.0

        # Store experience / 경험 저장
        self._training_samples.append({
            "visual": visual_features,
            "tactile": tactile_features,
            "targets": target_affordances,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        # Forward pass / 순전파
        combined_input = _np.concatenate([
            _np.array(visual_features, dtype=_np.float32).flatten()[:self.visual_dim]
            if len(_np.array(visual_features, dtype=_np.float32).flatten()) >= self.visual_dim
            else _np.pad(_np.array(visual_features, dtype=_np.float32).flatten(), (0, self.visual_dim - len(_np.array(visual_features, dtype=_np.float32).flatten()))),
            _np.array(tactile_features, dtype=_np.float32).flatten()[:self.tactile_dim]
            if len(_np.array(tactile_features, dtype=_np.float32).flatten()) >= self.tactile_dim
            else _np.pad(_np.array(tactile_features, dtype=_np.float32).flatten(), (0, self.tactile_dim - len(_np.array(tactile_features, dtype=_np.float32).flatten()))),
        ])

        # Encoder forward / 인코더 순전파
        h1 = combined_input @ self._encoder_W1 + self._encoder_b1
        h1_bn = self._batch_norm(h1, self._encoder_bn1_running_mean, self._encoder_bn1_running_var)
        h1_act = self._relu(h1_bn)

        h2 = h1_act @ self._encoder_W2 + self._encoder_b2
        h2_bn = self._batch_norm(h2, self._encoder_bn2_running_mean, self._encoder_bn2_running_var)
        h2_act = self._relu(h2_bn)

        logits = h2_act @ self._head_W + self._head_b
        predictions = self._sigmoid(logits)

        # Build target vector / 목표 벡터 구성
        target_vec = _np.zeros(self.n_affordances)
        for i, name in enumerate(self.AFFORDANCE_NAMES[:self.n_affordances]):
            target_vec[i] = target_affordances.get(name, 0.0)

        # MSE loss / MSE 손실
        loss = float(_np.mean((predictions - target_vec) ** 2))

        # Simple gradient update / 단순 gradient 업데이트
        # d_loss/d_logits = 2 * (pred - target) * sigmoid_derivative
        d_logits = 2.0 * (predictions - target_vec) * predictions * (1.0 - predictions) / self.n_affordances

        # Update head weights / 헤드 가중치 업데이트
        self._head_W -= learning_rate * _np.outer(h2_act, d_logits)
        self._head_b -= learning_rate * d_logits

        logger.debug("AffordancePredictorNet 학습: loss=%.4f, samples=%d", loss, len(self._training_samples))
        return loss


# ---------------------------------------------------------------------------
# ToolDiscoveryEngine / 도구 발견 엔진
# ---------------------------------------------------------------------------

class ToolDiscoveryEngine:
    """
    Discovers tool use from affordance exploration.
    기능성 탐색으로부터 도구 사용을 발견하는 엔진.

    객체의 직접적 기능성을 넘어 간접적 사용(도구로서의 활용)을 발견합니다.
    "자르고 싶지만 맨손으로는 안 돼" → "이 얇은 금속판은 절단 도구로 쓸 수 있어"

    Usage:
        >>> engine = ToolDiscoveryEngine(affordance_learner=learner)
        >>> result = engine.discover_tool_use(object_features, "can_cut")
        >>> tools = engine.creative_tool_discovery(available_objects, "cut paper")
    """

    # Action-to-required-tool-property mapping / 행동-필요도구속성 매핑
    ACTION_TOOL_REQUIREMENTS: Dict[str, Dict[str, Any]] = {
        "can_cut": {
            "required_properties": ["is_sharp", "is_rigid"],
            "weight_threshold_kg": 2.0,
            "shape_preference": ["flat", "thin"],
            "tool_category": ToolCategory.CUTTING,
            "korean_action": "자르기",
        },
        "can_puncture": {
            "required_properties": ["is_sharp"],
            "weight_threshold_kg": 1.0,
            "shape_preference": ["pointed", "thin"],
            "tool_category": ToolCategory.CUTTING,
            "korean_action": "뚫기",
        },
        "can_pour": {
            "required_properties": ["has_opening"],
            "weight_threshold_kg": 5.0,
            "shape_preference": ["cylinder", "container"],
            "tool_category": ToolCategory.CONTAINER,
            "korean_action": "붓기",
        },
        "can_hold": {
            "required_properties": ["has_handle", "is_rigid"],
            "weight_threshold_kg": 3.0,
            "shape_preference": ["elongated"],
            "tool_category": ToolCategory.GRASPING,
            "korean_action": "잡기(도구)",
        },
        "can_squeeze": {
            "required_properties": [],
            "weight_threshold_kg": 1.0,
            "shape_preference": ["flexible"],
            "tool_category": ToolCategory.GRASPING,
            "korean_action": "짜기",
        },
        "can_throw": {
            "required_properties": ["is_rigid"],
            "weight_threshold_kg": 2.0,
            "shape_preference": ["sphere", "compact"],
            "tool_category": ToolCategory.STRIKING,
            "korean_action": "던지기",
        },
        "can_insert": {
            "required_properties": ["is_rigid"],
            "weight_threshold_kg": 1.0,
            "shape_preference": ["elongated", "thin"],
            "tool_category": ToolCategory.FASTENING,
            "korean_action": "끼워넣기",
        },
        "can_flip": {
            "required_properties": ["is_rigid", "has_surface"],
            "weight_threshold_kg": 2.0,
            "shape_preference": ["flat", "wide"],
            "tool_category": ToolCategory.UNKNOWN,
            "korean_action": "뒤집기",
        },
        "can_stack": {
            "required_properties": ["has_surface", "is_rigid"],
            "weight_threshold_kg": 10.0,
            "shape_preference": ["flat", "box"],
            "tool_category": ToolCategory.CONTAINER,
            "korean_action": "쌓기",
        },
        "can_roll": {
            "required_properties": ["is_round"],
            "weight_threshold_kg": 5.0,
            "shape_preference": ["sphere", "cylinder"],
            "tool_category": ToolCategory.UNKNOWN,
            "korean_action": "굴리기",
        },
        "can_push": {
            "required_properties": ["is_rigid"],
            "weight_threshold_kg": 5.0,
            "shape_preference": ["flat", "wide"],
            "tool_category": ToolCategory.UNKNOWN,
            "korean_action": "밀기",
        },
        "can_pull": {
            "required_properties": ["has_handle", "is_rigid"],
            "weight_threshold_kg": 3.0,
            "shape_preference": ["elongated"],
            "tool_category": ToolCategory.GRASPING,
            "korean_action": "당기기",
        },
        "can_rotate": {
            "required_properties": ["is_rigid", "has_handle"],
            "weight_threshold_kg": 3.0,
            "shape_preference": ["cylinder", "elongated"],
            "tool_category": ToolCategory.UNKNOWN,
            "korean_action": "회전시키기",
        },
        "can_lift": {
            "required_properties": ["has_handle"],
            "weight_threshold_kg": 20.0,
            "shape_preference": [],
            "tool_category": ToolCategory.UNKNOWN,
            "korean_action": "들어올리기",
        },
        "can_grasp": {
            "required_properties": ["has_handle"],
            "weight_threshold_kg": 2.0,
            "shape_preference": ["elongated", "compact"],
            "tool_category": ToolCategory.GRASPING,
            "korean_action": "잡기",
        },
    }

    def __init__(self, affordance_learner: AffordanceLearner) -> None:
        """
        ToolDiscoveryEngine 초기화 / Initialize ToolDiscoveryEngine.

        Args:
            affordance_learner: 기능성 학습기 인스턴스 / Affordance learner instance
        """
        self._learner = affordance_learner
        self._tool_library: Dict[str, Dict[str, Any]] = {}
        self._discovery_history: List[Dict[str, Any]] = []
        logger.info("ToolDiscoveryEngine 초기화 / ToolDiscoveryEngine initialized")

    def discover_tool_use(
        self,
        object_features: Dict[str, Any],
        desired_action: str,
    ) -> Dict[str, Any]:
        """
        객체를 도구로 사용하는 방법 발견 / Discover how to use an object as a tool.

        "자르고 싶지만 맨손으로 안 됨" → "이 얇은 금속판은 절단 도구로 사용 가능"

        객체의 직접적 기능성을 넘어, 원하는 행동을 위해 간접적으로
        활용할 수 있는 방법을 발견합니다.

        Args:
            object_features: 객체 특징 딕셔너리
                - name (str): 객체명
                - is_sharp (bool): 날카로움
                - is_rigid (bool): 강성
                - has_handle (bool): 손잡이
                - has_opening (bool): 개구부
                - is_round (bool): 둥근 형태
                - has_surface (bool): 표면
                - weight_kg (float): 무게
                - shape (str): 형태
            desired_action: 원하는 행동 (예: "can_cut")

        Returns:
            Dict: 발견 결과
                - can_use_as_tool (bool): 도구로 사용 가능 여부
                - tool_suitability (float): 도구 적합도 (0~1)
                - tool_category (str): 도구 카테고리
                - usage_description (str): 사용 방법 설명
                - korean_description (str): 한국어 설명
                - indirect_affordances (Dict[str, float]): 간접 기능성 점수
                - confidence (float): 신뢰도
        """
        result: Dict[str, Any] = {
            "can_use_as_tool": False,
            "tool_suitability": 0.0,
            "tool_category": "unknown",
            "usage_description": "",
            "korean_description": "",
            "indirect_affordances": {},
            "confidence": 0.0,
        }

        # Get requirements for desired action / 원하는 행동의 요구사항 획득
        requirements = self.ACTION_TOOL_REQUIREMENTS.get(desired_action)
        if not requirements:
            logger.warning("알 수 없는 행동: %s / Unknown action: %s", desired_action, desired_action)
            result["usage_description"] = f"Cannot evaluate: unknown action '{desired_action}'"
            return result

        # Evaluate as tool / 도구로 평가
        suitability = self.evaluate_as_tool(object_features, desired_action)

        if suitability > 0.3:
            result["can_use_as_tool"] = True
            result["tool_suitability"] = suitability

            # Determine tool category / 도구 카테고리 결정
            tool_cat = requirements["tool_category"]
            result["tool_category"] = tool_cat.value

            # Generate usage description / 사용법 설명 생성
            obj_name = object_features.get("name", "unknown object")
            korean_action = requirements["korean_action"]

            result["usage_description"] = (
                f"'{obj_name}' can be used as a tool for {desired_action} "
                f"(suitability: {suitability:.2f})"
            )
            result["korean_description"] = (
                f"'{obj_name}'을(를) {korean_action} 도구로 사용할 수 있습니다 "
                f"(적합도: {suitability:.2f})"
            )

            # Compute indirect affordances / 간접 기능성 계산
            result["indirect_affordances"] = {
                desired_action: suitability,
                "can_grasp": min(1.0, suitability * 1.2) if object_features.get("has_handle") else suitability * 0.5,
            }

            result["confidence"] = min(1.0, suitability + 0.1)

            # Record discovery / 발견 기록
            self._discovery_history.append({
                "object": obj_name,
                "desired_action": desired_action,
                "suitability": suitability,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })

            # Update tool library / 도구 라이브러리 업데이트
            self._tool_library[f"{obj_name}_{desired_action}"] = {
                "object_name": obj_name,
                "action": desired_action,
                "suitability": suitability,
                "tool_category": tool_cat.value,
            }

        logger.info(
            "도구 발견: %s → %s (적합도: %.2f) / Tool discovery: %s → %s (suitability: %.2f)",
            object_features.get("name", "?"), desired_action, suitability,
            object_features.get("name", "?"), desired_action, suitability,
        )

        return result

    def evaluate_as_tool(
        self,
        object_features: Dict[str, Any],
        target_action: str,
    ) -> float:
        """
        객체의 도구 적합도 평가 / Evaluate object's tool suitability for target action.

        Args:
            object_features: 객체 특징 딕셔너리
            target_action: 대상 행동 (예: "can_cut")

        Returns:
            float: 도구 적합도 (0~1, 1 = 완벽한 도구)
        """
        requirements = self.ACTION_TOOL_REQUIREMENTS.get(target_action)
        if not requirements:
            return 0.0

        score = 0.0
        max_score = 0.0

        # Check required properties / 필수 속성 확인
        required_props = requirements["required_properties"]
        if required_props:
            max_score += 0.5
            matched = sum(
                1 for prop in required_props
                if object_features.get(prop, False)
            )
            prop_score = matched / len(required_props) if required_props else 0.0
            score += 0.5 * prop_score

        # Check weight threshold / 무게 임계값 확인
        weight_threshold = requirements.get("weight_threshold_kg", 10.0)
        max_score += 0.2
        obj_weight = object_features.get("weight_kg", 5.0)
        if obj_weight <= weight_threshold:
            score += 0.2
        else:
            # Partial credit for heavy objects / 무거운 객체에 대한 부분 점수
            score += 0.2 * max(0.0, 1.0 - (obj_weight - weight_threshold) / weight_threshold)

        # Check shape preference / 형태 선호도 확인
        shape_prefs = requirements.get("shape_preference", [])
        if shape_prefs:
            max_score += 0.2
            obj_shape = object_features.get("shape", "")
            if obj_shape in shape_prefs:
                score += 0.2
            elif any(pref in obj_shape for pref in shape_prefs):
                score += 0.1

        # Bonus: check existing affordance model / 보너스: 기존 기능성 모델 확인
        max_score += 0.1
        obj_name = object_features.get("name", "")
        if obj_name:
            model = self._learner.get_model(f"obj_{obj_name}_1") or self._learner.get_model(f"template_{obj_name}")
            if model and model.affordance_scores:
                # If the object already has relevant affordances, boost score
                relevant = model.affordance_scores.get(target_action)
                if relevant and relevant.score > 0.3:
                    score += 0.1 * relevant.score

        # Normalize / 정규화
        return min(1.0, score / max(max_score, 1.0))

    def creative_tool_discovery(
        self,
        available_objects: List[Dict[str, Any]],
        goal: str,
    ) -> List[Dict[str, Any]]:
        """
        창의적 도구 발견 / Creative tool discovery.

        주어진 목표와 가용 객체 목록에서 창의적인 도구 사용법을 제안합니다.
        객체의 전통적 용도를 넘어 새로운 활용 방법을 찾습니다.

        Args:
            available_objects: 가용 객체 목록 [{name, features...}, ...]
            goal: 목표 (예: "cut paper", "open jar", "reach high shelf")

        Returns:
            List[Dict]: 제안된 도구 사용법 목록 (적합도 순 정렬)
                각 항목: {object_name, action, suitability, description, korean_description}
        """
        proposals: List[Dict[str, Any]] = []

        # Determine which actions might help the goal / 목표에 도움이 될 행동 결정
        goal_action_map: Dict[str, List[str]] = {
            "cut": ["can_cut", "can_puncture"],
            "open": ["can_rotate", "can_pull", "can_push", "can_lift"],
            "reach": ["can_push", "can_stack", "can_insert"],
            "hold": ["can_grasp", "can_hold", "can_squeeze"],
            "move": ["can_push", "can_pull", "can_lift", "can_roll"],
            "clean": ["can_push", "can_squeeze", "can_lift"],
            "pour": ["can_pour", "can_lift", "can_rotate"],
            "fix": ["can_insert", "can_push", "can_squeeze", "can_hold"],
            "measure": ["can_stack", "can_insert", "can_lift"],
        }

        # Map goal to actions / 목표를 행동에 매핑
        relevant_actions: List[str] = []
        goal_lower = goal.lower()
        for keyword, actions in goal_action_map.items():
            if keyword in goal_lower:
                relevant_actions.extend(actions)

        if not relevant_actions:
            # Default: try all actions / 기본: 모든 행동 시도
            relevant_actions = list(self.ACTION_TOOL_REQUIREMENTS.keys())

        # Evaluate each object for each relevant action / 각 객체를 각 관련 행동에 대해 평가
        for obj in available_objects:
            for action in relevant_actions:
                suitability = self.evaluate_as_tool(obj, action)
                if suitability > 0.2:
                    obj_name = obj.get("name", "unknown")
                    requirements = self.ACTION_TOOL_REQUIREMENTS.get(action, {})
                    korean_action = requirements.get("korean_action", action)

                    proposal = {
                        "object_name": obj_name,
                        "action": action,
                        "suitability": suitability,
                        "description": (
                            f"Use '{obj_name}' as a tool for {action} "
                            f"to achieve goal: {goal} (suitability: {suitability:.2f})"
                        ),
                        "korean_description": (
                            f"'{obj_name}'을(를) {korean_action} 도구로 사용하여 "
                            f"목표 '{goal}' 달성 (적합도: {suitability:.2f})"
                        ),
                        "object_features": obj,
                    }
                    proposals.append(proposal)

        # Sort by suitability / 적합도순 정렬
        proposals.sort(key=lambda p: p["suitability"], reverse=True)

        logger.info(
            "창의적 도구 발견: 목표='%s', %d개 제안 / Creative tool discovery: goal='%s', %d proposals",
            goal, len(proposals), goal, len(proposals),
        )

        return proposals

    def maintain_tool_library(self) -> Dict[str, Any]:
        """
        영구적 도구 지식 업데이트 / Update persistent tool knowledge.

        발견된 도구 지식을 정리하고 신뢰도를 재계산합니다.
        오래된 항목의 신뢰도를 감소시키고, 자주 사용된 도구의
        숙련도를 증가시킵니다.

        Returns:
            Dict: 유지보수 결과
                - total_tools (int): 전체 도구 수
                - updated (int): 업데이트된 항목 수
                - deprecated (int): 폐기된 항목 수
                - top_tools (List): 상위 도구 목록
        """
        updated = 0
        deprecated = 0
        now = datetime.now(timezone.utc)

        to_remove: List[str] = []

        for key, tool_info in self._tool_library.items():
            # Check if tool has been used recently / 최근 사용 여부 확인
            last_used_str = tool_info.get("last_used", "")
            if last_used_str:
                try:
                    last_used = datetime.fromisoformat(last_used_str)
                    days_since = (now - last_used).days
                    if days_since > 30:
                        # Decay confidence for unused tools / 미사용 도구 신뢰도 감소
                        tool_info["suitability"] = max(
                            0.0, tool_info.get("suitability", 0.5) - 0.01 * days_since
                        )
                        updated += 1
                    if days_since > 90 and tool_info.get("suitability", 0.0) < 0.1:
                        to_remove.append(key)
                        deprecated += 1
                except (ValueError, TypeError):
                    pass
            else:
                updated += 1

        # Remove deprecated tools / 폐기된 도구 제거
        for key in to_remove:
            del self._tool_library[key]

        # Get top tools / 상위 도구 목록
        top_tools = sorted(
            self._tool_library.items(),
            key=lambda x: x[1].get("suitability", 0.0),
            reverse=True,
        )[:10]

        result = {
            "total_tools": len(self._tool_library),
            "updated": updated,
            "deprecated": deprecated,
            "top_tools": [
                {"key": k, "name": v.get("object_name", "?"), "action": v.get("action", "?"), "suitability": v.get("suitability", 0.0)}
                for k, v in top_tools
            ],
        }

        logger.info(
            "도구 라이브러리 유지보수: %d개 도구, %d 업데이트, %d 폐기 / "
            "Tool library maintenance: %d tools, %d updated, %d deprecated",
            result["total_tools"], result["updated"], result["deprecated"],
            result["total_tools"], result["updated"], result["deprecated"],
        )

        return result


# ---------------------------------------------------------------------------
# Convenience Functions / 편의 함수
# ---------------------------------------------------------------------------

def create_affordance_system(
    db_path: Optional[str] = None,
) -> Tuple[AffordanceLearner, ToolDiscovery]:
    """
    기능성 학습 시스템 생성 / Create affordance learning system.

    Args:
        db_path: SQLite DB 경로

    Returns:
        Tuple[AffordanceLearner, ToolDiscovery]: 학습기와 발견기 튜플
    """
    learner = AffordanceLearner(db_path=db_path)
    discovery = ToolDiscovery(affordance_learner=learner, db_path=db_path)
    return learner, discovery


# ============================================================================
# Neural Affordance Prediction — 신경망 기반 어포던스 예측
# ============================================================================
# 기존: 규칙 기반 (if-else) → 한계: 새로운 물체에 일반화 불가
# 혁신: 시각/촉각/물리적 특성 → 어포던스 확률 분포 예측 신경망
# + 활성 탐색: "이 물체의 어포던스를 알기 위해 어떤 행동을 해야 할까?"
# ============================================================================

if TORCH_AVAILABLE:

    class NeuralAffordanceNet(nn.Module):
        """신경망 어포던스 예측기

        입력: 시각 특징(128D) + 촉각 특징(64D) + 물리적 특성(32D)
        출력: 20가지 어포던스 확률 + 불확실성

        혁신:
        1. MC Dropout 기반 불확실성 추정
        2. 활성 어포던스 탐색 (어떤 행동으로 어포던스를 알 수 있는지)
        3. 어포던스 전이 (유사 물체에서 어포던스 지식 전이)
        4. 물리적 제약 통합 (무거운 물체는 던질 수 없다)
        """

        NUM_AFFORDANCES = 20

        AFFORDANCE_NAMES = [
            'grasp', 'lift', 'push', 'pull', 'rotate', 'squeeze',
            'pour_from', 'contain', 'sit_on', 'stack_on',
            'cut_with', 'pierce', 'wrap', 'throw', 'roll',
            'slide', 'hammer_with', 'scoop_with', 'hang', 'lean_on'
        ]

        def __init__(self, visual_dim=128, tactile_dim=64, physical_dim=32,
                     hidden_dim=256, num_heads=4, dropout=0.1):
            super().__init__()
            self.visual_dim = visual_dim
            self.tactile_dim = tactile_dim
            self.physical_dim = physical_dim

            # Modality-specific encoders
            self.visual_encoder = nn.Sequential(
                nn.Linear(visual_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout),
            )

            self.tactile_encoder = nn.Sequential(
                nn.Linear(tactile_dim, hidden_dim // 2),
                nn.LayerNorm(hidden_dim // 2),
                nn.GELU(),
                nn.Dropout(dropout),
            )

            self.physical_encoder = nn.Sequential(
                nn.Linear(physical_dim, hidden_dim // 2),
                nn.LayerNorm(hidden_dim // 2),
                nn.GELU(),
                nn.Dropout(dropout),
            )

            # Cross-modal attention fusion
            self.fusion_attention = nn.MultiheadAttention(
                embed_dim=hidden_dim, num_heads=num_heads,
                dropout=dropout, batch_first=True
            )

            # Affordance prediction heads (per-affordance)
            self.affordance_heads = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(hidden_dim, hidden_dim // 2),
                    nn.GELU(),
                    nn.Dropout(dropout),  # MC Dropout for uncertainty
                    nn.Linear(hidden_dim // 2, 1),
                    nn.Sigmoid()
                ) for _ in range(self.NUM_AFFORDANCES)
            ])

            # Active exploration head: predict information gain per action
            self.exploration_head = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim // 2),
                nn.GELU(),
                nn.Linear(hidden_dim // 2, 9),  # 9 exploration actions
                nn.Softmax(dim=-1)
            )

            # Physics constraint layer
            self.physics_constraint = PhysicsConstraintLayer()

            self._init_weights()

        def _init_weights(self):
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

        def forward(self, visual_features=None, tactile_features=None,
                    physical_features=None, num_mc_samples=1):
            """어포던스 예측

            Args:
                visual_features: [batch, visual_dim] 또는 None
                tactile_features: [batch, tactile_dim] 또는 None
                physical_features: [batch, physical_dim] 또는 None
                num_mc_samples: MC Dropout 샘플 수 (불확실성 추정)

            Returns:
                dict: affordances, uncertainties, exploration_recommendation
            """
            batch_size = 1
            device = next(self.parameters()).device

            # Encode available modalities
            encoded_parts = []
            if visual_features is not None:
                if isinstance(visual_features, np.ndarray):
                    visual_features = torch.FloatTensor(visual_features).to(device)
                if visual_features.dim() == 1:
                    visual_features = visual_features.unsqueeze(0)
                batch_size = visual_features.shape[0]
                encoded_parts.append(self.visual_encoder(visual_features))

            if tactile_features is not None:
                if isinstance(tactile_features, np.ndarray):
                    tactile_features = torch.FloatTensor(tactile_features).to(device)
                if tactile_features.dim() == 1:
                    tactile_features = tactile_features.unsqueeze(0)
                batch_size = tactile_features.shape[0]
                encoded_parts.append(self.tactile_encoder(tactile_features))

            if physical_features is not None:
                if isinstance(physical_features, np.ndarray):
                    physical_features = torch.FloatTensor(physical_features).to(device)
                if physical_features.dim() == 1:
                    physical_features = physical_features.unsqueeze(0)
                batch_size = physical_features.shape[0]
                encoded_parts.append(self.physical_encoder(physical_features))

            if not encoded_parts:
                # No features provided — return uniform uncertainty
                return {
                    'affordances': {name: 0.5 for name in self.AFFORDANCE_NAMES},
                    'uncertainties': {name: 1.0 for name in self.AFFORDANCE_NAMES},
                    'exploration_action': 0,
                    'confidence': 0.0,
                }

            # Fuse modalities with attention
            if len(encoded_parts) == 1:
                fused = encoded_parts[0]
            else:
                # Pad to same dimension and concatenate
                target_dim = max(p.shape[-1] for p in encoded_parts)
                padded = []
                for p in encoded_parts:
                    if p.shape[-1] < target_dim:
                        pad_size = target_dim - p.shape[-1]
                        p = F.pad(p, (0, pad_size))
                    padded.append(p)

                stacked = torch.stack(padded, dim=1)  # [batch, modalities, dim]
                attended, _ = self.fusion_attention(
                    stacked, stacked, stacked
                )
                fused = attended.mean(dim=1)  # [batch, dim]

                # Project to hidden_dim if needed
                if fused.shape[-1] != self.affordance_heads[0][0].in_features:
                    proj = nn.Linear(fused.shape[-1], self.affordance_heads[0][0].in_features).to(device)
                    fused = proj(fused)

            # MC Dropout sampling for uncertainty
            all_affordance_samples = []
            for mc in range(num_mc_samples):
                affordance_probs = []
                for i, head in enumerate(self.affordance_heads):
                    prob = head(fused).squeeze(-1)  # [batch]
                    affordance_probs.append(prob)
                affordance_tensor = torch.stack(affordance_probs, dim=-1)  # [batch, 20]
                all_affordance_samples.append(affordance_tensor)

            samples = torch.stack(all_affordance_samples, dim=0)  # [mc, batch, 20]
            mean_probs = samples.mean(dim=0)  # [batch, 20]
            std_probs = samples.std(dim=0)  # [batch, 20]

            # Apply physics constraints
            if physical_features is not None:
                mean_probs = self.physics_constraint(mean_probs, physical_features)

            # Exploration recommendation
            exploration_probs = self.exploration_head(fused)  # [batch, 9]
            best_exploration = exploration_probs.argmax(dim=-1)  # [batch]

            # Format results
            result_affordances = {}
            result_uncertainties = {}
            for i, name in enumerate(self.AFFORDANCE_NAMES):
                result_affordances[name] = mean_probs[0, i].item() if batch_size == 1 else mean_probs[:, i].detach()
                result_uncertainties[name] = std_probs[0, i].item() if batch_size == 1 else std_probs[:, i].detach()

            return {
                'affordances': result_affordances,
                'uncertainties': result_uncertainties,
                'exploration_action': best_exploration[0].item() if batch_size == 1 else best_exploration.detach(),
                'confidence': 1.0 - std_probs.mean().item(),
                'fused_features': fused.detach(),
            }


    class PhysicsConstraintLayer(nn.Module):
        """물리적 제약 계층: 물리법칙에 위배되는 어포던스 확률 감소

        예: 무거운 물체는 던질 수 없다, 깨지기 쉬운 물체는 망치로 사용 불가
        """

        def __init__(self):
            super().__init__()
            # 학습 가능한 물리 제약 가중치
            self.mass_throw_threshold = nn.Parameter(torch.tensor(2.0))  # kg
            self.fragility_squeeze_threshold = nn.Parameter(torch.tensor(0.5))

        def forward(self, affordance_probs, physical_features):
            """물리적 제약 적용"""
            # physical_features: [batch, 32]
            # Assume: [0:4] = mass_features, [4:8] = fragility_features
            constrained = affordance_probs.clone()

            if physical_features.shape[-1] >= 8:
                mass_feat = physical_features[:, :4].mean(dim=-1)  # [batch]
                fragility_feat = physical_features[:, 4:8].mean(dim=-1)  # [batch]

                # 무거운 물체 → throw 확률 감소
                mass_mask = torch.sigmoid(mass_feat - self.mass_throw_threshold)
                constrained[:, 13] = constrained[:, 13] * (1 - mass_mask)  # throw

                # 깨지기 쉬운 물체 → squeeze/hammer 확률 감소
                frag_mask = torch.sigmoid(fragility_feat - self.fragility_squeeze_threshold)
                constrained[:, 5] = constrained[:, 5] * (1 - frag_mask)  # squeeze
                constrained[:, 16] = constrained[:, 16] * (1 - frag_mask)  # hammer_with

            return constrained


class AffordanceTransferNet:
    """어포던스 전이 네트워크: 유사 물체에서 어포던스 지식 전이

    "이 컵과 비슷한 머그잔을 본 적이 있어" → 어포던스 전이
    """

    def __init__(self, embedding_dim=256, temperature=0.1):
        self.embedding_dim = embedding_dim
        self.temperature = temperature
        self.known_objects = {}  # name → embedding
        self.known_affordances = {}  # name → affordance dict

    def register_object(self, name, embedding, affordances):
        """알려진 물체 등록"""
        if isinstance(embedding, torch.Tensor):
            embedding = embedding.detach().cpu().numpy()
        self.known_objects[name] = embedding
        self.known_affordances[name] = affordances

    def transfer_affordances(self, query_embedding, top_k=3):
        """쿼리 임베딩에 가장 유사한 k개 물체에서 어포던스 전이"""
        if not self.known_objects:
            return None

        if isinstance(query_embedding, torch.Tensor):
            query = query_embedding.detach().cpu().numpy()
        else:
            query = np.array(query_embedding)

        if query.ndim > 1:
            query = query.flatten()

        # 코사인 유사도 계산
        similarities = {}
        for name, emb in self.known_objects.items():
            if emb.ndim > 1:
                emb = emb.flatten()
            sim = np.dot(query, emb) / (np.linalg.norm(query) * np.linalg.norm(emb) + 1e-8)
            similarities[name] = sim

        # Top-k 선택
        sorted_objects = sorted(similarities.items(), key=lambda x: x[1], reverse=True)[:top_k]

        # 가중 평균으로 어포던스 전이
        transferred = {}
        total_weight = 0

        for name, sim in sorted_objects:
            weight = np.exp(sim / self.temperature)
            total_weight += weight

            for affordance_name, prob in self.known_affordances[name].items():
                if affordance_name not in transferred:
                    transferred[affordance_name] = 0
                transferred[affordance_name] += weight * prob

        if total_weight > 0:
            for k in transferred:
                transferred[k] /= total_weight

        return transferred


# ---------------------------------------------------------------------------
# Module Entry Point / 모듈 진입점
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import statistics as _statistics

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    print("=" * 60)
    print("지훈 로봇 V8.5 - Object Affordance & Tool Use Learning")
    print("객체 기능성 및 도구 사용 학습 모듈")
    print("=" * 60)

    learner, discovery = create_affordance_system()

    # Demo: learn affordances / 데모: 기능성 학습
    print("\n🔍 객체 기능성 학습 데모:\n")

    test_objects = [
        ObjectFeatures(
            object_id="obj_cup_1", name="cup",
            category=ObjectCategory.UTENSIL,
            has_handle=True, has_opening=True,
            weight_kg=0.2, is_rigid=True, is_fragile=True,
        ),
        ObjectFeatures(
            object_id="obj_chair_1", name="chair",
            category=ObjectCategory.FURNITURE,
            has_surface=True, weight_kg=5.0,
            is_rigid=True,
        ),
        ObjectFeatures(
            object_id="obj_knife_1", name="knife",
            category=ObjectCategory.TOOL,
            has_handle=True, is_sharp=True,
            weight_kg=0.15, is_rigid=True,
        ),
    ]

    for obj in test_objects:
        model = discovery.discover_and_explore(obj)
        print(f"  📦 {obj.name}:")
        print(f"    도구: {'예' if model.is_tool else '아니오'}"
              f" ({TOOL_CATEGORY_KOREAN.get(model.tool_category, '?')})")
        top = model.get_top_affordances(3)
        for action, score in top:
            print(f"    - {AFFORDANCE_KOREAN.get(action, action.value)}: {score:.2f}")
        print()

    # Tool usage learning / 도구 사용법 학습
    print("🔧 도구 사용법 학습:\n")
    knife_model = learner.get_model("obj_knife_1")
    if knife_model:
        pattern = discovery.learn_usage(
            knife_model,
            task_description="cut vegetables",
            korean_description="채소 썰기",
            usage_steps=["1. 칼을 잡는다", "2. 채소를 고정한다", "3. 채소를 썬다"],
        )
        # Practice / 연습
        for i in range(5):
            success = i > 0  # First attempt fails
            discovery.practice_tool(pattern.pattern_id, success)

        print(f"  작업: {pattern.korean_description}")
        print(f"  성공률: {pattern.success_rate:.2f}")
        print(f"  숙련도: {pattern.mastery_level:.2f}")

    # Mastery report / 숙련도 보고서
    report = discovery.get_mastery_report()
    print(f"\n📊 도구 숙련도 보고서:")
    print(f"  알려진 도구: {report['total_tools_known']}개")
    print(f"  숙련 도구: {report['mastered_tools']}개")
    print(f"  평균 숙련도: {report['average_mastery']:.2f}")
