#!/usr/bin/env python3
"""
Emotional Intelligence Module / 감성 지능 모듈

지훈 로봇 V8의 감성 지능 시스템입니다.
음성, 표정, 텍스트에서 감정을 인식하고,
공감 응답을 생성하며, 로봇 자체의 감정 상태를 관리합니다.

TODO 23: Emotional Intelligence Module

Components / 구성 요소:
  - EmotionRecognizer: 음성/표정/텍스트 감정 인식
  - EmotionState: 로봇 자체 감정 상태 모델
  - EmpathyEngine: 공감 응답 생성 엔진
  - MoodTracker: 소유자 기분 추적기

Emotion → Behavior Mapping / 감정-행동 매핑:
  - Owner sad   → gentle voice, concerned eyes, offer help
  - Owner angry → calm voice, neutral eyes, give space
  - Owner happy → energetic voice, happy eyes, celebrate
  - Unknown     → neutral, cautious approach

Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import statistics
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums / 열거형
# ---------------------------------------------------------------------------

class HumanEmotion(Enum):
    """인간 감정 열거형 / Human emotion types."""
    HAPPY = "happy"
    SAD = "sad"
    ANGRY = "angry"
    FEARFUL = "fearful"
    SURPRISED = "surprised"
    DISGUSTED = "disgusted"
    NEUTRAL = "neutral"
    CONFUSED = "confused"
    EXCITED = "excited"
    CALM = "calm"


class RobotEmotion(Enum):
    """로봇 감정 열거형 / Robot emotion types."""
    HAPPY = "happy"
    CONCERNED = "concerned"
    FOCUSED = "focused"
    CURIOUS = "curious"
    CAUTIOUS = "cautious"
    NEUTRAL = "neutral"
    EMPATHETIC = "empathetic"


class EmotionSource(Enum):
    """감정 인식 소스 / Emotion recognition source."""
    VOICE = "voice"
    FACE = "face"
    TEXT = "text"
    MULTI_MODAL = "multi_modal"


class VoiceFeature(Enum):
    """음성 특징 / Voice prosody features."""
    PITCH = "pitch"
    SPEED = "speed"
    VOLUME = "volume"
    PAUSE_FREQUENCY = "pause_frequency"
    ENERGY = "energy"


# Korean names for emotions / 감정 한국어명
HUMAN_EMOTION_KOREAN: Dict[HumanEmotion, str] = {
    HumanEmotion.HAPPY: "행복",
    HumanEmotion.SAD: "슬픔",
    HumanEmotion.ANGRY: "분노",
    HumanEmotion.FEARFUL: "두려움",
    HumanEmotion.SURPRISED: "놀람",
    HumanEmotion.DISGUSTED: "혐오",
    HumanEmotion.NEUTRAL: "중립",
    HumanEmotion.CONFUSED: "혼란",
    HumanEmotion.EXCITED: "흥분",
    HumanEmotion.CALM: "평온",
}

ROBOT_EMOTION_KOREAN: Dict[RobotEmotion, str] = {
    RobotEmotion.HAPPY: "행복",
    RobotEmotion.CONCERNED: "걱정",
    RobotEmotion.FOCUSED: "집중",
    RobotEmotion.CURIOUS: "호기심",
    RobotEmotion.CAUTIOUS: "신중",
    RobotEmotion.NEUTRAL: "중립",
    RobotEmotion.EMPATHETIC: "공감",
}


# ---------------------------------------------------------------------------
# Data Classes / 데이터 클래스
# ---------------------------------------------------------------------------

@dataclass
class VoiceFeatures:
    """
    음성 특징 데이터 / Voice prosody feature data.

    음성의 피치, 속도, 볼륨 등 특징을 저장합니다.
    """
    pitch_mean: float = 150.0  # Hz
    pitch_variance: float = 20.0
    speed: float = 1.0  # relative speed (1.0 = normal)
    volume_mean: float = 0.5  # 0.0 ~ 1.0
    volume_variance: float = 0.1
    pause_frequency: float = 0.1  # pauses per second
    energy: float = 0.5  # 0.0 ~ 1.0
    duration_seconds: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FaceFeatures:
    """
    얼굴 특징 데이터 / Face feature data.

    표정 인식 결과를 저장합니다. (카메라 사용 가능 시)
    """
    detected: bool = False
    smile_score: float = 0.0  # 0.0 ~ 1.0
    frown_score: float = 0.0  # 0.0 ~ 1.0
    eyebrow_raise: float = 0.0  # 0.0 ~ 1.0
    eye_openness: float = 0.5  # 0.0 ~ 1.0
    mouth_openness: float = 0.0  # 0.0 ~ 1.0
    confidence: float = 0.0  # 0.0 ~ 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TextSentiment:
    """
    텍스트 감정 분석 결과 / Text sentiment analysis result.

    Gemma 4 모델을 통한 텍스트 감정 분석 결과를 저장합니다.
    """
    text: str = ""
    sentiment_score: float = 0.0  # -1.0 (negative) ~ 1.0 (positive)
    emotion_scores: Dict[str, float] = field(default_factory=dict)
    dominant_emotion: HumanEmotion = HumanEmotion.NEUTRAL
    confidence: float = 0.0
    model_used: str = "gemma4"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EmotionDetection:
    """
    감정 인식 결과 / Emotion detection result.

    단일 소스 또는 다중 소스에서 인식된 감정 결과입니다.
    """
    detection_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    detected_emotion: HumanEmotion = HumanEmotion.NEUTRAL
    confidence: float = 0.0  # 0.0 ~ 1.0
    source: EmotionSource = EmotionSource.MULTI_MODAL
    voice_features: Optional[VoiceFeatures] = None
    face_features: Optional[FaceFeatures] = None
    text_sentiment: Optional[TextSentiment] = None
    valence: float = 0.0  # -1.0 (negative) ~ 1.0 (positive)
    arousal: float = 0.5  # 0.0 (calm) ~ 1.0 (excited)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class EmotionBehaviorMapping:
    """
    감정-행동 매핑 / Emotion-to-behavior mapping.

    인식된 소유자 감정에 따른 로봇의 행동 정의입니다.
    """
    owner_emotion: HumanEmotion = HumanEmotion.NEUTRAL
    robot_emotion: RobotEmotion = RobotEmotion.NEUTRAL
    voice_tone: str = "neutral"  # gentle, calm, energetic, neutral
    eye_expression: str = "neutral"  # concerned, neutral, happy, curious
    action_suggestion: str = ""
    korean_description: str = ""
    priority: int = 5  # 1 (highest) ~ 10 (lowest)


@dataclass
class MoodEntry:
    """
    기분 추적 항목 / Mood tracking entry.

    소유자의 기분 변화를 시계열로 기록합니다.
    """
    entry_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    emotion: HumanEmotion = HumanEmotion.NEUTRAL
    confidence: float = 0.0
    valence: float = 0.0
    arousal: float = 0.5
    source: str = ""
    context: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class MoodTrend:
    """
    기분 추세 / Mood trend analysis result.

    일정 기간 동안의 기분 변화 추세를 나타냅니다.
    """
    period: str = ""  # e.g., "7d", "30d"
    average_valence: float = 0.0
    valence_trend: float = 0.0  # negative = declining, positive = improving
    dominant_emotion: HumanEmotion = HumanEmotion.NEUTRAL
    emotion_distribution: Dict[str, float] = field(default_factory=dict)
    volatility: float = 0.0  # 0.0 ~ 1.0
    concern_level: float = 0.0  # 0.0 ~ 1.0
    recommendation: str = ""


# ---------------------------------------------------------------------------
# Default Emotion-Behavior Mappings / 기본 감정-행동 매핑
# ---------------------------------------------------------------------------

DEFAULT_BEHAVIOR_MAPPINGS: Dict[HumanEmotion, EmotionBehaviorMapping] = {
    HumanEmotion.SAD: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.SAD,
        robot_emotion=RobotEmotion.CONCERNED,
        voice_tone="gentle",
        eye_expression="concerned",
        action_suggestion="offer_help",
        korean_description="부드러운 목소리, 걱정하는 눈, 도움 제안",
        priority=2,
    ),
    HumanEmotion.ANGRY: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.ANGRY,
        robot_emotion=RobotEmotion.CAUTIOUS,
        voice_tone="calm",
        eye_expression="neutral",
        action_suggestion="give_space",
        korean_description="차분한 목소리, 중립적 눈, 공간 확보",
        priority=1,
    ),
    HumanEmotion.HAPPY: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.HAPPY,
        robot_emotion=RobotEmotion.HAPPY,
        voice_tone="energetic",
        eye_expression="happy",
        action_suggestion="celebrate",
        korean_description="활기찬 목소리, 행복한 눈, 함께 축하",
        priority=5,
    ),
    HumanEmotion.FEARFUL: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.FEARFUL,
        robot_emotion=RobotEmotion.EMPATHETIC,
        voice_tone="gentle",
        eye_expression="concerned",
        action_suggestion="comfort",
        korean_description="부드러운 목소리, 걱정하는 눈, 안심 시키기",
        priority=2,
    ),
    HumanEmotion.SURPRISED: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.SURPRISED,
        robot_emotion=RobotEmotion.CURIOUS,
        voice_tone="neutral",
        eye_expression="curious",
        action_suggestion="inquire",
        korean_description="중립적 목소리, 호기심 눈, 상황 확인",
        priority=4,
    ),
    HumanEmotion.NEUTRAL: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.NEUTRAL,
        robot_emotion=RobotEmotion.NEUTRAL,
        voice_tone="neutral",
        eye_expression="neutral",
        action_suggestion="standby",
        korean_description="중립적 목소리, 중립적 눈, 대기",
        priority=6,
    ),
    HumanEmotion.CONFUSED: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.CONFUSED,
        robot_emotion=RobotEmotion.FOCUSED,
        voice_tone="gentle",
        eye_expression="curious",
        action_suggestion="clarify",
        korean_description="부드러운 목소리, 호기심 눈, 명확히 하기",
        priority=3,
    ),
    HumanEmotion.EXCITED: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.EXCITED,
        robot_emotion=RobotEmotion.HAPPY,
        voice_tone="energetic",
        eye_expression="happy",
        action_suggestion="share_excitement",
        korean_description="활기찬 목소리, 행복한 눈, 함께 즐거워하기",
        priority=5,
    ),
    HumanEmotion.CALM: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.CALM,
        robot_emotion=RobotEmotion.NEUTRAL,
        voice_tone="neutral",
        eye_expression="neutral",
        action_suggestion="maintain",
        korean_description="중립적 목소리, 중립적 눈, 현재 상태 유지",
        priority=7,
    ),
    HumanEmotion.DISGUSTED: EmotionBehaviorMapping(
        owner_emotion=HumanEmotion.DISGUSTED,
        robot_emotion=RobotEmotion.CAUTIOUS,
        voice_tone="calm",
        eye_expression="neutral",
        action_suggestion="remove_cause",
        korean_description="차분한 목소리, 중립적 눈, 원인 제거 지원",
        priority=3,
    ),
}


# ---------------------------------------------------------------------------
# EmotionRecognizer / 감정 인식기
# ---------------------------------------------------------------------------

class EmotionRecognizer:
    """
    감정 인식기 / Emotion Recognizer.

    음성(프로소디), 얼굴(표정), 텍스트(감성)에서 감정을 인식합니다.
    다중 소스의 결과를 융합하여 최종 감정 판정을 내립니다.

    Usage:
        >>> recognizer = EmotionRecognizer()
        >>> voice = VoiceFeatures(pitch_mean=220, speed=0.7, volume_mean=0.3)
        >>> detection = recognizer.recognize_from_voice(voice)
        >>> print(detection.detected_emotion)
    """

    # Voice emotion profiles / 음성 감정 프로필 (pitch Hz, speed, volume)
    _VOICE_PROFILES: Dict[HumanEmotion, Dict[str, Tuple[float, float]]] = {
        HumanEmotion.HAPPY: {
            "pitch_mean": (180, 300),
            "speed": (1.0, 1.5),
            "volume_mean": (0.5, 0.9),
        },
        HumanEmotion.SAD: {
            "pitch_mean": (80, 140),
            "speed": (0.5, 0.8),
            "volume_mean": (0.1, 0.4),
        },
        HumanEmotion.ANGRY: {
            "pitch_mean": (150, 350),
            "speed": (1.1, 1.8),
            "volume_mean": (0.6, 1.0),
        },
        HumanEmotion.FEARFUL: {
            "pitch_mean": (200, 400),
            "speed": (1.2, 1.8),
            "volume_mean": (0.3, 0.7),
        },
        HumanEmotion.CALM: {
            "pitch_mean": (120, 180),
            "speed": (0.8, 1.0),
            "volume_mean": (0.3, 0.5),
        },
        HumanEmotion.EXCITED: {
            "pitch_mean": (200, 350),
            "speed": (1.2, 1.6),
            "volume_mean": (0.6, 0.9),
        },
        HumanEmotion.NEUTRAL: {
            "pitch_mean": (120, 180),
            "speed": (0.9, 1.1),
            "volume_mean": (0.3, 0.6),
        },
    }

    def __init__(self) -> None:
        """EmotionRecognizer 초기화."""
        self._text_analyzer: Optional[Callable] = None
        logger.info("EmotionRecognizer 초기화 완료")

    def recognize_from_voice(
        self, voice: VoiceFeatures
    ) -> EmotionDetection:
        """
        음성에서 감정 인식 / Recognize emotion from voice prosody.

        피치, 속도, 볼륨 패턴을 분석하여 감정을 판정합니다.

        Args:
            voice: 음성 특징 데이터

        Returns:
            EmotionDetection: 감정 인식 결과
        """
        emotion_scores: Dict[HumanEmotion, float] = {}

        for emotion, profile in self._VOICE_PROFILES.items():
            score = 0.0
            feature_count = 0

            for feature_name, (low, high) in profile.items():
                value = getattr(voice, feature_name, None)
                if value is None:
                    continue

                # Gaussian-like scoring / 가우시안 유사 점수 산출
                mid = (low + high) / 2
                sigma = (high - low) / 4
                if sigma > 0:
                    feature_score = math.exp(
                        -0.5 * ((value - mid) / sigma) ** 2
                    )
                else:
                    feature_score = 1.0 if abs(value - mid) < 1e-6 else 0.0

                score += feature_score
                feature_count += 1

            if feature_count > 0:
                emotion_scores[emotion] = score / feature_count

        if not emotion_scores:
            detected = HumanEmotion.NEUTRAL
            confidence = 0.0
        else:
            detected = max(emotion_scores, key=lambda e: emotion_scores[e])
            confidence = emotion_scores[detected]

        # Compute valence and arousal / 가효가와 각성도 계산
        valence = self._compute_valence(detected)
        arousal = self._compute_arousal(detected, voice)

        logger.debug(
            "음성 감정 인식: %s (%.2f)", detected.value, confidence
        )

        return EmotionDetection(
            detected_emotion=detected,
            confidence=confidence,
            source=EmotionSource.VOICE,
            voice_features=voice,
            valence=valence,
            arousal=arousal,
        )

    def recognize_from_face(
        self, face: FaceFeatures
    ) -> EmotionDetection:
        """
        얼굴에서 감정 인식 / Recognize emotion from facial expression.

        Args:
            face: 얼굴 특징 데이터

        Returns:
            EmotionDetection: 감정 인식 결과
        """
        if not face.detected:
            return EmotionDetection(
                detected_emotion=HumanEmotion.NEUTRAL,
                confidence=0.0,
                source=EmotionSource.FACE,
                face_features=face,
            )

        emotion_scores: Dict[HumanEmotion, float] = {}

        # Smile indicates happiness / 미소 = 행복
        emotion_scores[HumanEmotion.HAPPY] = face.smile_score
        # Frown indicates sadness/anger / 찡그림 = 슬픔/분노
        emotion_scores[HumanEmotion.SAD] = face.frown_score * 0.6
        emotion_scores[HumanEmotion.ANGRY] = face.frown_score * 0.4
        # Eyebrow raise = surprise / 눈썹 올림 = 놀람
        emotion_scores[HumanEmotion.SURPRISED] = (
            face.eyebrow_raise * 0.7 + face.mouth_openness * 0.3
        )
        # Wide eyes = fear / 큰 눈 = 두려움
        emotion_scores[HumanEmotion.FEARFUL] = max(0, face.eye_openness - 0.5) * 2

        detected = max(emotion_scores, key=lambda e: emotion_scores[e])
        confidence = emotion_scores[detected] * face.confidence

        valence = self._compute_valence(detected)
        arousal = 0.5  # Default arousal for face / 얼굴 기본 각성도

        logger.debug(
            "얼굴 감정 인식: %s (%.2f)", detected.value, confidence
        )

        return EmotionDetection(
            detected_emotion=detected,
            confidence=confidence,
            source=EmotionSource.FACE,
            face_features=face,
            valence=valence,
            arousal=arousal,
        )

    def recognize_from_text(
        self, sentiment: TextSentiment
    ) -> EmotionDetection:
        """
        텍스트에서 감정 인식 / Recognize emotion from text sentiment.

        Gemma 4 분석 결과를 바탕으로 감정을 판정합니다.

        Args:
            sentiment: 텍스트 감성 분석 결과

        Returns:
            EmotionDetection: 감정 인식 결과
        """
        detected = sentiment.dominant_emotion
        confidence = sentiment.confidence

        valence = sentiment.sentiment_score
        arousal = 0.5  # Text typically doesn't convey arousal well

        # Adjust arousal based on specific emotions / 특정 감정에 따른 각성도 조정
        high_arousal_emotions = {
            HumanEmotion.ANGRY, HumanEmotion.EXCITED,
            HumanEmotion.FEARFUL, HumanEmotion.SURPRISED,
        }
        if detected in high_arousal_emotions:
            arousal = 0.7 + 0.3 * confidence

        logger.debug(
            "텍스트 감정 인식: %s (%.2f)", detected.value, confidence
        )

        return EmotionDetection(
            detected_emotion=detected,
            confidence=confidence,
            source=EmotionSource.TEXT,
            text_sentiment=sentiment,
            valence=valence,
            arousal=arousal,
        )

    def recognize_multi_modal(
        self,
        voice: Optional[VoiceFeatures] = None,
        face: Optional[FaceFeatures] = None,
        text: Optional[TextSentiment] = None,
    ) -> EmotionDetection:
        """
        다중 소스 감정 인식 / Multi-modal emotion recognition.

        음성, 얼굴, 텍스트 감정 인식 결과를 융합합니다.
        가중 평균과 신뢰도 기반 결합을 사용합니다.

        Args:
            voice: 음성 특징 (선택)
            face: 얼굴 특징 (선택)
            text: 텍스트 감성 분석 (선택)

        Returns:
            EmotionDetection: 융합된 감정 인식 결과
        """
        detections: List[Tuple[EmotionDetection, float]] = []

        # Source weights / 소스 가중치
        source_weights = {
            EmotionSource.VOICE: 0.35,
            EmotionSource.FACE: 0.35,
            EmotionSource.TEXT: 0.30,
        }

        if voice is not None:
            det = self.recognize_from_voice(voice)
            detections.append((det, source_weights[EmotionSource.VOICE]))

        if face is not None:
            det = self.recognize_from_face(face)
            detections.append((det, source_weights[EmotionSource.FACE]))

        if text is not None:
            det = self.recognize_from_text(text)
            detections.append((det, source_weights[EmotionSource.TEXT]))

        if not detections:
            return EmotionDetection(
                detected_emotion=HumanEmotion.NEUTRAL,
                confidence=0.0,
                source=EmotionSource.MULTI_MODAL,
            )

        # Weighted emotion scoring / 가중 감정 점수 산출
        emotion_scores: Dict[HumanEmotion, float] = {}
        total_weight = 0.0

        for det, weight in detections:
            # Confidence-adjusted weight / 신뢰도 조정 가중치
            effective_weight = weight * max(det.confidence, 0.1)
            total_weight += effective_weight

            if det.detected_emotion not in emotion_scores:
                emotion_scores[det.detected_emotion] = 0.0
            emotion_scores[det.detected_emotion] += effective_weight

        # Normalize / 정규화
        if total_weight > 0:
            for emotion in emotion_scores:
                emotion_scores[emotion] /= total_weight

        detected = max(emotion_scores, key=lambda e: emotion_scores[e])
        confidence = emotion_scores[detected]

        # Weighted valence/arousal / 가중 가효가/각성도
        valence = sum(
            det.valence * weight for det, weight in detections
        ) / sum(weight for _, weight in detections)
        arousal = sum(
            det.arousal * weight for det, weight in detections
        ) / sum(weight for _, weight in detections)

        logger.info(
            "다중 소스 감정 인식: %s (%.2f) - %d개 소스 융합",
            detected.value, confidence, len(detections),
        )

        return EmotionDetection(
            detected_emotion=detected,
            confidence=confidence,
            source=EmotionSource.MULTI_MODAL,
            voice_features=voice,
            face_features=face,
            text_sentiment=text,
            valence=valence,
            arousal=arousal,
        )

    def _compute_valence(self, emotion: HumanEmotion) -> float:
        """
        감정의 가효가(valence) 계산 / Compute valence for an emotion.

        Args:
            emotion: 감정 유형

        Returns:
            float: 가효가 (-1.0 ~ 1.0)
        """
        valence_map: Dict[HumanEmotion, float] = {
            HumanEmotion.HAPPY: 0.8,
            HumanEmotion.SAD: -0.7,
            HumanEmotion.ANGRY: -0.6,
            HumanEmotion.FEARFUL: -0.5,
            HumanEmotion.SURPRISED: 0.1,
            HumanEmotion.DISGUSTED: -0.6,
            HumanEmotion.NEUTRAL: 0.0,
            HumanEmotion.CONFUSED: -0.2,
            HumanEmotion.EXCITED: 0.7,
            HumanEmotion.CALM: 0.2,
        }
        return valence_map.get(emotion, 0.0)

    def _compute_arousal(
        self, emotion: HumanEmotion, voice: VoiceFeatures
    ) -> float:
        """
        각성도(arousal) 계산 / Compute arousal from emotion and voice.

        Args:
            emotion: 감정 유형
            voice: 음성 특징

        Returns:
            float: 각성도 (0.0 ~ 1.0)
        """
        base_arousal: Dict[HumanEmotion, float] = {
            HumanEmotion.HAPPY: 0.6,
            HumanEmotion.SAD: 0.2,
            HumanEmotion.ANGRY: 0.8,
            HumanEmotion.FEARFUL: 0.7,
            HumanEmotion.SURPRISED: 0.8,
            HumanEmotion.DISGUSTED: 0.5,
            HumanEmotion.NEUTRAL: 0.4,
            HumanEmotion.CONFUSED: 0.5,
            HumanEmotion.EXCITED: 0.9,
            HumanEmotion.CALM: 0.2,
        }
        base = base_arousal.get(emotion, 0.4)

        # Voice adjustments / 음성 기반 조정
        speed_adj = (voice.speed - 1.0) * 0.2
        volume_adj = (voice.volume_mean - 0.5) * 0.2

        return max(0.0, min(1.0, base + speed_adj + volume_adj))

    def set_text_analyzer(self, analyzer: Any) -> None:
        """
        텍스트 분석기 설정 (Gemma 4 연동) / Set text analyzer for Gemma 4.

        Args:
            analyzer: 텍스트 감성 분석 callable
        """
        self._text_analyzer = analyzer
        logger.info("텍스트 분석기 설정 완료")


# ---------------------------------------------------------------------------
# EmotionState / 로봇 감정 상태
# ---------------------------------------------------------------------------

class EmotionState:
    """
    로봇 감정 상태 모델 / Robot Emotional State Model.

    로봇 자체의 감정 상태를 관리하고, 감정이 표현(눈, 목소리, 행동)에
    미치는 영향을 제어합니다.

    감정은 점진적으로 변화하며 (감정 관성), 급격한 변화를 방지합니다.

    Usage:
        >>> state = EmotionState()
        >>> state.set_emotion(RobotEmotion.CONCERNED, reason="owner sad")
        >>> print(state.current_emotion)
        RobotEmotion.CONCERNED
    """

    def __init__(
        self,
        inertia: float = 0.7,
        decay_rate: float = 0.05,
    ) -> None:
        """
        EmotionState 초기화.

        Args:
            inertia: 감정 관성 (0~1, 높을수록 천천히 변함)
            decay_rate: 감정 쇠퇴율 (초당, 높을수록 빨리 중립으로 복귀)
        """
        self._current_emotion = RobotEmotion.NEUTRAL
        self._intensity: float = 0.5  # 0.0 ~ 1.0
        self._inertia = inertia
        self._decay_rate = decay_rate
        self._emotion_history: List[Dict[str, Any]] = []
        self._last_update = datetime.now(timezone.utc)

        logger.info(
            "EmotionState 초기화: 감정=%s, 관성=%.2f",
            self._current_emotion.value, self._inertia,
        )

    @property
    def current_emotion(self) -> RobotEmotion:
        """현재 감정 반환 / Return current emotion."""
        return self._current_emotion

    @property
    def intensity(self) -> float:
        """현재 감정 강도 반환 / Return current emotion intensity."""
        return self._intensity

    def set_emotion(
        self,
        emotion: RobotEmotion,
        intensity: Optional[float] = None,
        reason: str = "",
    ) -> None:
        """
        감정 설정 / Set robot emotion.

        관성 효과를 적용하여 감정이 서서히 변화합니다.

        Args:
            emotion: 새 감정
            intensity: 감정 강도 (None 시 기존 강도 유지)
            reason: 감정 변화 사유
        """
        now = datetime.now(timezone.utc)

        # Apply inertia / 관성 적용
        if emotion != self._current_emotion:
            self._intensity = self._intensity * self._inertia + (
                1.0 - self._inertia
            ) * (intensity or 0.5)
        else:
            # Same emotion: increase intensity / 같은 감정: 강도 증가
            if intensity is not None:
                self._intensity = min(
                    1.0,
                    self._intensity * 0.7 + intensity * 0.3,
                )

        old_emotion = self._current_emotion
        self._current_emotion = emotion
        self._last_update = now

        # Log history / 이력 기록
        self._emotion_history.append({
            "timestamp": now.isoformat(),
            "old_emotion": old_emotion.value,
            "new_emotion": emotion.value,
            "intensity": self._intensity,
            "reason": reason,
        })

        # Keep history manageable / 이력 크기 제한
        if len(self._emotion_history) > 1000:
            self._emotion_history = self._emotion_history[-500:]

        logger.info(
            "감정 변화: %s → %s (강도: %.2f, 사유: %s)",
            old_emotion.value, emotion.value, self._intensity, reason,
        )

    def decay(self, elapsed_seconds: float = 1.0) -> None:
        """
        감정 쇠퇴 적용 / Apply emotion decay over time.

        시간이 지남에 따라 감정 강도가 서서히 감소합니다.

        Args:
            elapsed_seconds: 경과 시간(초)
        """
        self._intensity = max(
            0.0,
            self._intensity - self._decay_rate * elapsed_seconds,
        )

        if self._intensity < 0.1:
            self._current_emotion = RobotEmotion.NEUTRAL
            self._intensity = 0.0

    def get_expression(self) -> Dict[str, Any]:
        """
        현재 감정에 따른 표현 매개변수 반환 / Get expression parameters.

        로봇의 눈 표정, 목소리 톤 등의 표현 매개변수를 반환합니다.

        Returns:
            Dict: 표현 매개변수
        """
        expression_map: Dict[RobotEmotion, Dict[str, Any]] = {
            RobotEmotion.HAPPY: {
                "eye_shape": "curved_up",
                "eye_brightness": 0.9,
                "voice_pitch_offset": 0.1,
                "voice_speed_offset": 0.1,
                "color": "#FFD700",
            },
            RobotEmotion.CONCERNED: {
                "eye_shape": "drooping",
                "eye_brightness": 0.5,
                "voice_pitch_offset": -0.05,
                "voice_speed_offset": -0.1,
                "color": "#87CEEB",
            },
            RobotEmotion.FOCUSED: {
                "eye_shape": "centered",
                "eye_brightness": 0.8,
                "voice_pitch_offset": 0.0,
                "voice_speed_offset": 0.0,
                "color": "#4169E1",
            },
            RobotEmotion.CURIOUS: {
                "eye_shape": "wide",
                "eye_brightness": 0.85,
                "voice_pitch_offset": 0.05,
                "voice_speed_offset": 0.05,
                "color": "#32CD32",
            },
            RobotEmotion.CAUTIOUS: {
                "eye_shape": "narrow",
                "eye_brightness": 0.4,
                "voice_pitch_offset": -0.1,
                "voice_speed_offset": -0.15,
                "color": "#808080",
            },
            RobotEmotion.NEUTRAL: {
                "eye_shape": "default",
                "eye_brightness": 0.6,
                "voice_pitch_offset": 0.0,
                "voice_speed_offset": 0.0,
                "color": "#FFFFFF",
            },
            RobotEmotion.EMPATHETIC: {
                "eye_shape": "soft",
                "eye_brightness": 0.7,
                "voice_pitch_offset": -0.03,
                "voice_speed_offset": -0.05,
                "color": "#DDA0DD",
            },
        }

        expression = expression_map.get(
            self._current_emotion, expression_map[RobotEmotion.NEUTRAL]
        ).copy()

        # Scale by intensity / 강도에 따라 스케일링
        expression["intensity"] = self._intensity
        expression["current_emotion"] = self._current_emotion.value
        expression["korean_emotion"] = ROBOT_EMOTION_KOREAN.get(
            self._current_emotion, "알 수 없음"
        )

        return expression

    def get_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        감정 변화 이력 반환 / Return emotion change history.

        Args:
            limit: 최대 반환 건수

        Returns:
            List[Dict]: 감정 변화 이력
        """
        return self._emotion_history[-limit:]


# ---------------------------------------------------------------------------
# EmpathyEngine / 공감 엔진
# ---------------------------------------------------------------------------

class EmpathyEngine:
    """
    공감 응답 생성 엔진 / Empathetic Response Generation Engine.

    인식된 소유자 감정에 기반하여 공감적인 응답을 생성합니다.
    감정-행동 매핑을 사용하여 적절한 로봇 행동을 결정합니다.

    Usage:
        >>> engine = EmpathyEngine()
        >>> detection = EmotionDetection(detected_emotion=HumanEmotion.SAD)
        >>> response = engine.generate_response(detection)
        >>> print(response.response_text)
    """

    def __init__(
        self,
        behavior_mappings: Optional[
            Dict[HumanEmotion, EmotionBehaviorMapping]
        ] = None,
    ) -> None:
        """
        EmpathyEngine 초기화.

        Args:
            behavior_mappings: 감정-행동 매핑 (None 시 기본값)
        """
        self._mappings = behavior_mappings or dict(DEFAULT_BEHAVIOR_MAPPINGS)
        self._response_templates = self._init_response_templates()
        logger.info("EmpathyEngine 초기화 완료")

    def _init_response_templates(
        self,
    ) -> Dict[HumanEmotion, List[str]]:
        """
        응답 템플릿 초기화 / Initialize response templates.

        각 감정에 대한 한국어 응답 템플릿을 정의합니다.

        Returns:
            Dict: 감정별 응답 템플릿
        """
        return {
            HumanEmotion.SAD: [
                "힘든 시간을 보내고 계시는군요. 제가 도와드릴 일이 있을까요?",
                "슬퍼 보이시네요. 곁에 있어 드릴게요.",
                "마음이 아프시겠어요. 뭐든 말씀해 주세요.",
            ],
            HumanEmotion.ANGRY: [
                "화가 나셨군요. 천천히 심호흡해 보시겠어요?",
                "답답한 상황이셨군요. 제가 정리해 드릴까요?",
                "충분히 화나실 만한 상황이에요. 시간이 필요하시면 말씀해 주세요.",
            ],
            HumanEmotion.HAPPY: [
                "기분이 좋아 보이시네요! 저도 기뻐요!",
                "행복한 소식이 있으신가요? 함께 축하해요!",
                "미소가 보여서 저도 행복해져요!",
            ],
            HumanEmotion.FEARFUL: [
                "무서우시군요. 안전하니까 걱정 마세요.",
                "불안하시겠어요. 제가 함께 있을게요.",
                "괜찮아요. 천천히 진정해 볼까요?",
            ],
            HumanEmotion.CONFUSED: [
                "혼란스러우시군요. 차근차근 정리해 드릴게요.",
                "어려운 부분이 있으면 말씀해 주세요.",
                "다시 한번 설명해 드릴까요?",
            ],
            HumanEmotion.EXCITED: [
                "정말 신나 보이세요! 무슨 일이에요?",
                "흥미로운 일이 있으신가요? 저도 궁금해요!",
                "에너지가 넘치시네요! 같이 즐거워해요!",
            ],
            HumanEmotion.NEUTRAL: [
                "안녕하세요! 무엇을 도와드릴까요?",
                "편안한 하루 보내고 계신가요?",
            ],
            HumanEmotion.CALM: [
                "평온한 시간이네요. 좋은 분위기예요.",
                "차분한 하루를 보내고 계시군요.",
            ],
            HumanEmotion.SURPRISED: [
                "놀라셨군요! 무슨 일이 있으셨나요?",
                "갑작스러운 일이었군요. 괜찮으세요?",
            ],
            HumanEmotion.DISGUSTED: [
                "불쾌한 상황이셨군요. 해결할 수 있도록 도와드릴게요.",
                "원인을 찾아 제거해 드릴까요?",
            ],
        }

    def generate_response(
        self,
        detection: EmotionDetection,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        공감 응답 생성 / Generate empathetic response.

        감정 인식 결과에 기반하여 로봇의 응답을 생성합니다.

        Args:
            detection: 감정 인식 결과
            context: 추가 컨텍스트

        Returns:
            Dict: 공감 응답 결과
            - response_text (str): 응답 텍스트
            - robot_emotion (RobotEmotion): 로봇 감정
            - voice_tone (str): 목소리 톤
            - eye_expression (str): 눈 표정
            - action_suggestion (str): 행동 제안
        """
        emotion = detection.detected_emotion

        # Get behavior mapping / 행동 매핑 조회
        mapping = self._mappings.get(
            emotion,
            self._mappings[HumanEmotion.NEUTRAL],
        )

        # Get response text / 응답 텍스트 선택
        templates = self._response_templates.get(emotion, ["네, 알겠습니다."])
        # Simple rotation / 단순 순환 선택
        idx = hash(detection.detection_id) % len(templates)
        response_text = templates[idx]

        # Context-aware adjustments / 컨텍스트 인식 조정
        if context:
            if context.get("formal", False):
                response_text = response_text.replace("해요", "합니다")
            if context.get("emergency", False):
                response_text = "긴급 상황입니다! " + response_text

        logger.info(
            "공감 응답 생성: 감정=%s → 로봇감정=%s, 톤=%s",
            emotion.value, mapping.robot_emotion.value, mapping.voice_tone,
        )

        return {
            "response_text": response_text,
            "robot_emotion": mapping.robot_emotion,
            "voice_tone": mapping.voice_tone,
            "eye_expression": mapping.eye_expression,
            "action_suggestion": mapping.action_suggestion,
            "korean_description": mapping.korean_description,
            "priority": mapping.priority,
            "detection_confidence": detection.confidence,
        }

    def update_mapping(
        self, emotion: HumanEmotion, mapping: EmotionBehaviorMapping
    ) -> None:
        """
        감정-행동 매핑 업데이트 / Update emotion-behavior mapping.

        Args:
            emotion: 대상 감정
            mapping: 새 매핑
        """
        self._mappings[emotion] = mapping
        logger.info("감정-행동 매핑 업데이트: %s", emotion.value)


# ---------------------------------------------------------------------------
# MoodTracker / 기분 추적기
# ---------------------------------------------------------------------------

class MoodTracker:
    """
    소유자 기분 추적기 / Owner Mood Tracker.

    소유자의 감정을 시간에 따라 추적하고, 기분 추세를 분석하여
    사전 관리(proactive care)를 위한 정보를 제공합니다.

    데이터는 SQLite에 저장되어 영속성을 보장합니다.

    Usage:
        >>> tracker = MoodTracker()
        >>> tracker.record_mood(HumanEmotion.SAD, confidence=0.8)
        >>> trend = tracker.analyze_trend(period_days=7)
        >>> print(trend.recommendation)
    """

    def __init__(self, db_path: Optional[str] = None) -> None:
        """
        MoodTracker 초기화.

        Args:
            db_path: SQLite DB 경로 (None 시 메모리 DB)
        """
        self._db_path = db_path or ":memory:"
        self._db_conn: Optional[sqlite3.Connection] = None
        self._init_db()
        logger.info("MoodTracker 초기화: DB=%s", self._db_path)

    def _get_conn(self) -> sqlite3.Connection:
        """DB 연결 반환 (:memory: 시 캐시된 연결 사용) / Get DB connection."""
        if self._db_path == ":memory:":
            if self._db_conn is None:
                self._db_conn = sqlite3.connect(self._db_path)
            return self._db_conn
        return sqlite3.connect(self._db_path)

    def _init_db(self) -> None:
        """데이터베이스 초기화 / Initialize database."""
        try:
            conn = self._get_conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS mood_entries (
                    entry_id TEXT PRIMARY KEY,
                    emotion TEXT NOT NULL,
                    confidence REAL DEFAULT 0.0,
                    valence REAL DEFAULT 0.0,
                    arousal REAL DEFAULT 0.5,
                    source TEXT DEFAULT '',
                    context TEXT DEFAULT '',
                    timestamp TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_mood_timestamp
                ON mood_entries(timestamp)
            """)
            conn.commit()
            if self._db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("MoodTracker DB 초기화 실패: %s", e)
            raise

    def record_mood(
        self,
        emotion: HumanEmotion,
        confidence: float = 0.0,
        valence: float = 0.0,
        arousal: float = 0.5,
        source: str = "",
        context: str = "",
    ) -> MoodEntry:
        """
        기분 기록 / Record a mood entry.

        Args:
            emotion: 감지된 감정
            confidence: 신뢰도
            valence: 가효가
            arousal: 각성도
            source: 감지 소스
            context: 컨텍스트

        Returns:
            MoodEntry: 기록된 항목
        """
        entry = MoodEntry(
            emotion=emotion,
            confidence=confidence,
            valence=valence,
            arousal=arousal,
            source=source,
            context=context,
        )

        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT INTO mood_entries
                    (entry_id, emotion, confidence, valence, arousal,
                     source, context, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entry.entry_id,
                    entry.emotion.value,
                    entry.confidence,
                    entry.valence,
                    entry.arousal,
                    entry.source,
                    entry.context,
                    entry.timestamp,
                ),
            )
            conn.commit()
            if self._db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("기분 기록 저장 실패: %s", e)

        logger.debug(
            "기분 기록: %s (%.2f)", emotion.value, confidence
        )
        return entry

    def get_recent_moods(self, limit: int = 100) -> List[MoodEntry]:
        """
        최근 기분 기록 조회 / Get recent mood entries.

        Args:
            limit: 최대 조회 건수

        Returns:
            List[MoodEntry]: 기분 기록 목록
        """
        try:
            conn = self._get_conn()
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT * FROM mood_entries
                ORDER BY timestamp DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
            if self._db_path != ":memory:":
                conn.close()

            entries: List[MoodEntry] = []
            for row in rows:
                entries.append(
                    MoodEntry(
                        entry_id=row["entry_id"],
                        emotion=HumanEmotion(row["emotion"]),
                        confidence=row["confidence"],
                        valence=row["valence"],
                        arousal=row["arousal"],
                        source=row["source"],
                        context=row["context"],
                        timestamp=row["timestamp"],
                    )
                )
            return entries
        except sqlite3.Error as e:
            logger.error("기분 기록 조회 실패: %s", e)
            return []

    def analyze_trend(self, period_days: int = 7) -> MoodTrend:
        """
        기분 추세 분석 / Analyze mood trend over a period.

        Args:
            period_days: 분석 기간(일)

        Returns:
            MoodTrend: 기분 추세 분석 결과
        """
        entries = self.get_recent_moods(limit=500)

        if not entries:
            return MoodTrend(
                period=f"{period_days}d",
                recommendation="데이터가 부족합니다. 기분을 더 기록해주세요.",
            )

        # Compute statistics / 통계 계산
        valences = [e.valence for e in entries]
        avg_valence = statistics.mean(valences) if valences else 0.0

        # Trend (simple linear approximation) / 추세 (단순 선형 근사)
        if len(valences) >= 2:
            half = len(valences) // 2
            first_half_avg = statistics.mean(valences[:half])
            second_half_avg = statistics.mean(valences[half:])
            trend = second_half_avg - first_half_avg
        else:
            trend = 0.0

        # Emotion distribution / 감정 분포
        emotion_counts: Dict[str, int] = {}
        for entry in entries:
            key = entry.emotion.value
            emotion_counts[key] = emotion_counts.get(key, 0) + 1

        total = len(entries)
        emotion_dist = {
            k: v / total for k, v in emotion_counts.items()
        }

        # Dominant emotion / 주요 감정
        dominant = max(emotion_counts, key=emotion_counts.get)
        try:
            dominant_emotion = HumanEmotion(dominant)
        except ValueError:
            dominant_emotion = HumanEmotion.NEUTRAL

        # Volatility / 변동성
        if len(valences) >= 2:
            volatility = statistics.stdev(valences)
        else:
            volatility = 0.0

        # Concern level / 우려 수준
        concern = 0.0
        negative_emotions = {
            HumanEmotion.SAD.value,
            HumanEmotion.ANGRY.value,
            HumanEmotion.FEARFUL.value,
        }
        for neg_emotion in negative_emotions:
            concern += emotion_dist.get(neg_emotion, 0.0)

        concern = min(1.0, concern)

        # Recommendation / 권장 사항
        if concern > 0.6:
            recommendation = (
                "⚠️ 부정적 감정이 지속적으로 관찰됩니다. "
                "소유자의 안부를 적극적으로 확인하세요."
            )
        elif concern > 0.3:
            recommendation = (
                "부정적 감정이 간헐적으로 관찰됩니다. "
                "주의 깊게 관찰하며 필요시 도움을 제안하세요."
            )
        elif trend < -0.2:
            recommendation = (
                "기분이 점차 저하되는 추세입니다. "
                "긍정적인 활동을 제안해 보세요."
            )
        else:
            recommendation = (
                "소유자의 기분이 안정적입니다. 현재 상태를 유지하세요."
            )

        return MoodTrend(
            period=f"{period_days}d",
            average_valence=avg_valence,
            valence_trend=trend,
            dominant_emotion=dominant_emotion,
            emotion_distribution=emotion_dist,
            volatility=volatility,
            concern_level=concern,
            recommendation=recommendation,
        )

    def get_concern_level(self) -> float:
        """
        현재 우려 수준 반환 / Get current concern level.

        최근 기록을 기반으로 소유자의 부정적 감정 비율을 계산합니다.

        Returns:
            float: 우려 수준 (0.0 ~ 1.0)
        """
        recent = self.get_recent_moods(limit=20)
        if not recent:
            return 0.0

        negative_count = sum(
            1 for e in recent
            if e.emotion in {
                HumanEmotion.SAD,
                HumanEmotion.ANGRY,
                HumanEmotion.FEARFUL,
            }
        )
        return negative_count / len(recent)


# ---------------------------------------------------------------------------
# EmotionalIntelligence / 감성 지능 메인 클래스
# ---------------------------------------------------------------------------

class EmotionalIntelligence:
    """
    감성 지능 시스템 / Emotional Intelligence System.

    감정 인식, 공감 응답, 로봇 감정 상태, 기분 추적을
    통합 관리하는 메인 클래스입니다.

    Usage:
        >>> ei = EmotionalIntelligence()
        >>> result = ei.process_emotional_input(
        ...     voice=VoiceFeatures(pitch_mean=100, speed=0.6)
        ... )
        >>> print(result["response_text"])
    """

    def __init__(
        self,
        mood_db_path: Optional[str] = None,
    ) -> None:
        """
        EmotionalIntelligence 초기화.

        Args:
            mood_db_path: 기분 추적 DB 경로 (None 시 메모리 DB)
        """
        self._recognizer = EmotionRecognizer()
        self._emotion_state = EmotionState()
        self._empathy_engine = EmpathyEngine()
        self._mood_tracker = MoodTracker(db_path=mood_db_path)

        logger.info("EmotionalIntelligence 시스템 초기화 완료")

    def process_emotional_input(
        self,
        voice: Optional[VoiceFeatures] = None,
        face: Optional[FaceFeatures] = None,
        text: Optional[TextSentiment] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        감정 입력 처리 / Process emotional input and generate response.

        전체 감성 지능 파이프라인을 실행합니다:
        1. 감정 인식 (음성/얼굴/텍스트)
        2. 공감 응답 생성
        3. 로봇 감정 상태 업데이트
        4. 기분 추적 기록

        Args:
            voice: 음성 특징 (선택)
            face: 얼굴 특징 (선택)
            text: 텍스트 감성 분석 (선택)
            context: 추가 컨텍스트

        Returns:
            Dict: 처리 결과
        """
        # 1. Recognize emotion / 감정 인식
        detection = self._recognizer.recognize_multi_modal(
            voice=voice, face=face, text=text
        )

        # 2. Generate empathetic response / 공감 응답 생성
        response = self._empathy_engine.generate_response(
            detection, context=context
        )

        # 3. Update robot emotion state / 로봇 감정 상태 업데이트
        self._emotion_state.set_emotion(
            emotion=response["robot_emotion"],
            intensity=detection.confidence,
            reason=f"owner {detection.detected_emotion.value}",
        )

        # 4. Record mood / 기분 기록
        self._mood_tracker.record_mood(
            emotion=detection.detected_emotion,
            confidence=detection.confidence,
            valence=detection.valence,
            arousal=detection.arousal,
            source=detection.source.value,
            context=str(context) if context else "",
        )

        logger.info(
            "감정 처리 완료: 인식=%s, 응답=%s",
            detection.detected_emotion.value,
            response["action_suggestion"],
        )

        return {
            "detection": detection,
            "response": response,
            "robot_expression": self._emotion_state.get_expression(),
        }

    def get_robot_state(self) -> Dict[str, Any]:
        """
        로봇 감정 상태 조회 / Get current robot emotional state.

        Returns:
            Dict: 로봇 감정 상태 및 표현 매개변수
        """
        return {
            "emotion": self._emotion_state.current_emotion.value,
            "intensity": self._emotion_state.intensity,
            "expression": self._emotion_state.get_expression(),
            "korean_emotion": ROBOT_EMOTION_KOREAN.get(
                self._emotion_state.current_emotion, "알 수 없음"
            ),
        }

    def get_mood_analysis(self, period_days: int = 7) -> MoodTrend:
        """
        기분 분석 결과 조회 / Get mood analysis.

        Args:
            period_days: 분석 기간

        Returns:
            MoodTrend: 기분 추세 분석 결과
        """
        return self._mood_tracker.analyze_trend(period_days)

    def get_concern_level(self) -> float:
        """
        현재 우려 수준 조회 / Get current concern level.

        Returns:
            float: 우려 수준 (0~1)
        """
        return self._mood_tracker.get_concern_level()

    def decay_emotions(self, elapsed_seconds: float = 1.0) -> None:
        """
        감정 쇠퇴 적용 / Apply emotion decay.

        정기적으로 호출하여 감정이 자연스럽게 쇠퇴하도록 합니다.

        Args:
            elapsed_seconds: 경과 시간(초)
        """
        self._emotion_state.decay(elapsed_seconds)


# ---------------------------------------------------------------------------
# Module Entry Point / 모듈 진입점
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    print("=" * 60)
    print("지훈 로봇 V8.5 - Emotional Intelligence Module")
    print("감성 지능 모듈")
    print("=" * 60)

    ei = EmotionalIntelligence()

    # Demo: voice emotion recognition / 데모: 음성 감정 인식
    print("\n🎤 음성 감정 인식 데모:\n")

    test_voices = [
        ("행복한 목소리", VoiceFeatures(
            pitch_mean=250, speed=1.2, volume_mean=0.7, energy=0.8
        )),
        ("슬픈 목소리", VoiceFeatures(
            pitch_mean=100, speed=0.6, volume_mean=0.2, energy=0.3
        )),
        ("화난 목소리", VoiceFeatures(
            pitch_mean=280, speed=1.5, volume_mean=0.85, energy=0.9
        )),
    ]

    for name, voice in test_voices:
        result = ei.process_emotional_input(voice=voice)
        det = result["detection"]
        resp = result["response"]
        print(f"  {name}:")
        print(f"    인식 감정: {HUMAN_EMOTION_KOREAN.get(det.detected_emotion, '?')}")
        print(f"    신뢰도: {det.confidence:.2f}")
        print(f"    응답: {resp['response_text'][:40]}...")
        print(f"    로봇 감정: {resp['robot_emotion'].value}")
        print()

    # Mood analysis / 기분 분석
    print("📊 기분 추세 분석:")
    trend = ei.get_mood_analysis(period_days=1)
    print(f"  평균 가효가: {trend.average_valence:.2f}")
    print(f"  우려 수준: {trend.concern_level:.2f}")
    print(f"  권장 사항: {trend.recommendation}")
