#!/usr/bin/env python3
"""
Skill Composition Engine Module / 기술 조합 엔진 모듈

지훈 로봇 V8의 기술 조합 엔진입니다.
단순한 기술을 결합하여 복잡한 기술을 생성하고 관리합니다.

TODO 46: Skill Composition Engine

Composition Types / 조합 유형:
  1. Sequential: A then B (e.g., approach → grasp)
  2. Parallel: A and B simultaneously (e.g., move + look)
  3. Conditional: A if condition else B (e.g., push if door closed)
  4. Loop: repeat A until condition (e.g., search until found)

Components / 구성 요소:
  - SkillComposer: 복잡 기술 조합 생성기
  - CompositionPlanner: 목표 분해 계획기
  - CompositionValidator: 조합 검증기
  - CompositionLearner: 경험 기반 조합 학습기

Safety / 안전:
  - 각 단계 검증
  - 서브 기술 실패 시 긴급 정지
  - 최대 조합 깊이: 3 (과도하게 복잡한 조합 방지)

Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums / 열거형
# ---------------------------------------------------------------------------

class CompositionType(Enum):
    """조합 유형 열거형 / Composition type enumeration."""
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    CONDITIONAL = "conditional"
    LOOP = "loop"


class SkillStatus(Enum):
    """기술 상태 / Skill status."""
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PAUSED = "paused"
    EMERGENCY_STOP = "emergency_stop"


class ValidationLevel(Enum):
    """검증 수준 / Validation level."""
    PASS = "pass"
    WARNING = "warning"
    FAIL = "fail"


class SkillCategory(Enum):
    """기술 카테고리 / Skill category."""
    NAVIGATION = "navigation"
    MANIPULATION = "manipulation"
    PERCEPTION = "perception"
    COMMUNICATION = "communication"
    LEARNING = "learning"
    PLANNING = "planning"
    SAFETY = "safety"
    CUSTOM = "custom"


# Korean names / 한국어명
COMPOSITION_TYPE_KOREAN: Dict[CompositionType, str] = {
    CompositionType.SEQUENTIAL: "순차 조합",
    CompositionType.PARALLEL: "병렬 조합",
    CompositionType.CONDITIONAL: "조건부 조합",
    CompositionType.LOOP: "반복 조합",
}

SKILL_STATUS_KOREAN: Dict[SkillStatus, str] = {
    SkillStatus.IDLE: "대기",
    SkillStatus.RUNNING: "실행 중",
    SkillStatus.COMPLETED: "완료",
    SkillStatus.FAILED: "실패",
    SkillStatus.PAUSED: "일시정지",
    SkillStatus.EMERGENCY_STOP: "긴급 정지",
}

SKILL_CATEGORY_KOREAN: Dict[SkillCategory, str] = {
    SkillCategory.NAVIGATION: "내비게이션",
    SkillCategory.MANIPULATION: "조작",
    SkillCategory.PERCEPTION: "지각",
    SkillCategory.COMMUNICATION: "통신",
    SkillCategory.LEARNING: "학습",
    SkillCategory.PLANNING: "계획",
    SkillCategory.SAFETY: "안전",
    SkillCategory.CUSTOM: "사용자 정의",
}


# ---------------------------------------------------------------------------
# Constants / 상수
# ---------------------------------------------------------------------------

MAX_COMPOSITION_DEPTH = 3  # Maximum nesting depth / 최대 중첩 깊이
MAX_SUB_SKILLS = 10  # Maximum sub-skills per composition / 조합당 최대 서브 기술
MAX_LOOP_ITERATIONS = 50  # Maximum loop iterations / 최대 반복 횟수


# ---------------------------------------------------------------------------
# Data Classes / 데이터 클래스
# ---------------------------------------------------------------------------

@dataclass
class Skill:
    """
    기본 기술 정의 / Base skill definition.

    로봇이 수행할 수 있는 단일 기술 또는 조합 기술입니다.
    """
    skill_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    korean_name: str = ""
    description: str = ""
    category: SkillCategory = SkillCategory.CUSTOM
    # Execution / 실행
    execution_time_estimate: float = 0.0  # seconds
    required_capabilities: List[str] = field(default_factory=list)
    preconditions: List[str] = field(default_factory=list)
    postconditions: List[str] = field(default_factory=list)
    # Safety / 안전
    risk_level: float = 0.0  # 0.0 (safe) ~ 1.0 (dangerous)
    safety_checks: List[str] = field(default_factory=list)
    # Learning / 학습
    success_rate: float = 0.0  # 0.0 ~ 1.0
    practice_count: int = 0
    last_used: str = ""
    # Metadata / 메타데이터
    is_composite: bool = False
    version: int = 1
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class CompositionStep:
    """
    조합 단계 / Composition step.

    조합된 기술의 개별 단계를 정의합니다.
    """
    step_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    skill_id: str = ""
    skill_name: str = ""
    order: int = 0  # Execution order / 실행 순서
    # For conditional / 조건부용
    condition: str = ""
    is_else_branch: bool = False
    # For loop / 반복용
    loop_condition: str = ""  # Continue while true / 참인 동안 계속
    max_iterations: int = MAX_LOOP_ITERATIONS
    # Parameters / 매개변수
    parameters: Dict[str, Any] = field(default_factory=dict)
    # Safety / 안전
    critical_step: bool = False  # Failure = emergency stop / 실패 시 긴급 정지
    fallback_skill_id: str = ""  # Fallback if this step fails


@dataclass
class Composition:
    """
    기술 조합 정의 / Skill composition definition.

    여러 기술을 조합한 복합 기술입니다.
    """
    composition_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    korean_name: str = ""
    description: str = ""
    composition_type: CompositionType = CompositionType.SEQUENTIAL
    steps: List[CompositionStep] = field(default_factory=list)
    # Depth tracking / 깊이 추적
    depth: int = 1
    # Execution state / 실행 상태
    status: SkillStatus = SkillStatus.IDLE
    current_step_index: int = 0
    # Safety / 안전
    overall_risk_level: float = 0.0
    emergency_stop_enabled: bool = True
    # Learning / 학습
    success_rate: float = 0.0
    execution_count: int = 0
    last_executed: str = ""
    # Metadata / 메타데이터
    is_auto_composed: bool = False  # Auto-detected pattern
    tags: List[str] = field(default_factory=list)
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    @property
    def step_count(self) -> int:
        """단계 수 반환 / Return number of steps."""
        return len(self.steps)


@dataclass
class ValidationResult:
    """
    검증 결과 / Composition validation result.

    조합의 유효성 검사 결과입니다.
    """
    is_valid: bool = False
    level: ValidationLevel = ValidationLevel.FAIL
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    risk_assessment: Dict[str, float] = field(default_factory=dict)
    estimated_success_rate: float = 0.0
    suggestions: List[str] = field(default_factory=list)


@dataclass
class ExecutionResult:
    """
    실행 결과 / Composition execution result.

    조합 기술의 실행 결과입니다.
    """
    execution_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    composition_id: str = ""
    status: SkillStatus = SkillStatus.IDLE
    completed_steps: int = 0
    total_steps: int = 0
    failed_step: Optional[str] = None
    failure_reason: str = ""
    execution_time: float = 0.0
    step_results: List[Dict[str, Any]] = field(default_factory=list)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    @property
    def progress(self) -> float:
        """진행률 반환 / Return progress (0.0 ~ 1.0)."""
        if self.total_steps == 0:
            return 0.0
        return self.completed_steps / self.total_steps


@dataclass
class PatternObservation:
    """
    패턴 관찰 / Pattern observation for auto-composition.

    반복되는 기술 실행 패턴을 기록합니다.
    """
    observation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    skill_sequence: List[str] = field(default_factory=list)
    context: str = ""
    success: bool = True
    frequency: int = 1
    last_observed: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ---------------------------------------------------------------------------
# Default Skills / 기본 기술 라이브러리
# ---------------------------------------------------------------------------

DEFAULT_SKILLS: Dict[str, Skill] = {
    "navigate_to": Skill(
        skill_id="navigate_to",
        name="Navigate To",
        korean_name="이동하기",
        description="지정된 위치로 이동",
        category=SkillCategory.NAVIGATION,
        execution_time_estimate=5.0,
        required_capabilities=["navigation", "obstacle_avoidance"],
        risk_level=0.2,
    ),
    "approach_object": Skill(
        skill_id="approach_object",
        name="Approach Object",
        korean_name="객체 접근",
        description="대상 객체 근처로 접근",
        category=SkillCategory.NAVIGATION,
        execution_time_estimate=3.0,
        required_capabilities=["navigation", "object_detection"],
        risk_level=0.15,
    ),
    "grasp_object": Skill(
        skill_id="grasp_object",
        name="Grasp Object",
        korean_name="객체 파지",
        description="손으로 객체를 잡기",
        category=SkillCategory.MANIPULATION,
        execution_time_estimate=2.0,
        required_capabilities=["arm_control", "hand_control", "force_sensing"],
        risk_level=0.3,
    ),
    "place_object": Skill(
        skill_id="place_object",
        name="Place Object",
        korean_name="객체 놓기",
        description="잡은 객체를 목표 위치에 놓기",
        category=SkillCategory.MANIPULATION,
        execution_time_estimate=2.0,
        required_capabilities=["arm_control", "hand_control"],
        risk_level=0.25,
    ),
    "look_at": Skill(
        skill_id="look_at",
        name="Look At",
        korean_name="바라보기",
        description="지정된 방향이나 객체를 바라보기",
        category=SkillCategory.PERCEPTION,
        execution_time_estimate=1.0,
        required_capabilities=["head_control", "camera"],
        risk_level=0.05,
    ),
    "scan_environment": Skill(
        skill_id="scan_environment",
        name="Scan Environment",
        korean_name="환경 스캔",
        description="주변 환경을 스캔하여 정보 수집",
        category=SkillCategory.PERCEPTION,
        execution_time_estimate=3.0,
        required_capabilities=["camera", "lidar"],
        risk_level=0.05,
    ),
    "open_door": Skill(
        skill_id="open_door",
        name="Open Door",
        korean_name="문 열기",
        description="손잡이를 잡고 문 열기",
        category=SkillCategory.MANIPULATION,
        execution_time_estimate=3.0,
        required_capabilities=["arm_control", "hand_control", "force_sensing"],
        risk_level=0.35,
        safety_checks=["verify_door_type", "check_obstacles_behind"],
    ),
    "push_object": Skill(
        skill_id="push_object",
        name="Push Object",
        korean_name="객체 밀기",
        description="객체를 밀어 이동시키기",
        category=SkillCategory.MANIPULATION,
        execution_time_estimate=2.0,
        required_capabilities=["arm_control", "force_sensing"],
        risk_level=0.2,
    ),
    "speak": Skill(
        skill_id="speak",
        name="Speak",
        korean_name="말하기",
        description="음성으로 메시지 전달",
        category=SkillCategory.COMMUNICATION,
        execution_time_estimate=2.0,
        required_capabilities=["speaker", "tts"],
        risk_level=0.0,
    ),
    "wait": Skill(
        skill_id="wait",
        name="Wait",
        korean_name="대기",
        description="지정된 시간 동안 대기",
        category=SkillCategory.PLANNING,
        execution_time_estimate=1.0,
        risk_level=0.0,
    ),
    "check_safety": Skill(
        skill_id="check_safety",
        name="Check Safety",
        korean_name="안전 확인",
        description="현재 환경의 안전 상태 확인",
        category=SkillCategory.SAFETY,
        execution_time_estimate=1.0,
        required_capabilities=["sensors"],
        risk_level=0.0,
    ),
    "emergency_stop": Skill(
        skill_id="emergency_stop",
        name="Emergency Stop",
        korean_name="긴급 정지",
        description="모든 동작 즉시 정지",
        category=SkillCategory.SAFETY,
        execution_time_estimate=0.1,
        risk_level=0.0,
        safety_checks=["halt_all_motors", "stabilize"],
    ),
}


# ---------------------------------------------------------------------------
# SkillComposer / 기술 조합기
# ---------------------------------------------------------------------------

class SkillComposer:
    """
    기술 조합 생성기 / Skill Composition Creator.

    단순 기술을 조합하여 복잡한 기술을 생성합니다.
    4가지 조합 유형(순차, 병렬, 조건부, 반복)을 지원합니다.

    Usage:
        >>> composer = SkillComposer()
        >>> comp = composer.create_sequential(
        ...     name="pick_and_place",
        ...     skill_ids=["approach_object", "grasp_object", "place_object"],
        ... )
        >>> result = composer.validate(comp)
        >>> print(result.is_valid)
    """

    def __init__(
        self,
        skill_library: Optional[Dict[str, Skill]] = None,
        db_path: Optional[str] = None,
    ) -> None:
        """
        SkillComposer 초기화.

        Args:
            skill_library: 기술 라이브러리 (None 시 기본값)
            db_path: SQLite DB 경로
        """
        self._skills = dict(skill_library or DEFAULT_SKILLS)
        self._compositions: Dict[str, Composition] = {}
        self._db_path = db_path or ":memory:"
        self._db_conn: Optional[sqlite3.Connection] = None
        self._init_db()
        logger.info("SkillComposer 초기화: %d개 기술 등록", len(self._skills))

    def _get_conn(self) -> sqlite3.Connection:
        """DB 연결 반환 (:memory: 시 캐시된 연결 사용) / Get DB connection."""
        if self._db_path == ":memory:":
            if self._db_conn is None:
                self._db_conn = sqlite3.connect(self._db_path)
            return self._db_conn
        return sqlite3.connect(self._db_path)

    def _init_db(self) -> None:
        """데이터베이스 초기화 / Initialize database."""
        try:
            conn = self._get_conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS compositions (
                    composition_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    korean_name TEXT,
                    composition_type TEXT NOT NULL,
                    steps_json TEXT NOT NULL,
                    depth INTEGER DEFAULT 1,
                    risk_level REAL DEFAULT 0.0,
                    success_rate REAL DEFAULT 0.0,
                    execution_count INTEGER DEFAULT 0,
                    is_auto_composed INTEGER DEFAULT 0,
                    tags_json TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS execution_log (
                    execution_id TEXT PRIMARY KEY,
                    composition_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    completed_steps INTEGER DEFAULT 0,
                    total_steps INTEGER DEFAULT 0,
                    execution_time REAL DEFAULT 0.0,
                    timestamp TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS pattern_observations (
                    observation_id TEXT PRIMARY KEY,
                    skill_sequence_json TEXT NOT NULL,
                    context TEXT,
                    success INTEGER DEFAULT 1,
                    frequency INTEGER DEFAULT 1,
                    last_observed TEXT NOT NULL
                )
            """)
            conn.commit()
            if self._db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("SkillComposer DB 초기화 실패: %s", e)
            raise

    def create_sequential(
        self,
        name: str,
        korean_name: str = "",
        skill_ids: Optional[List[str]] = None,
        description: str = "",
        tags: Optional[List[str]] = None,
    ) -> Composition:
        """
        순차 조합 생성 / Create sequential composition.

        기술을 순서대로 실행합니다: A → B → C → ...

        Args:
            name: 조합 이름
            korean_name: 한국어 이름
            skill_ids: 실행할 기술 ID 목록 (순서대로)
            description: 설명
            tags: 태그

        Returns:
            Composition: 생성된 순차 조합
        """
        skill_ids = skill_ids or []
        steps = self._build_sequential_steps(skill_ids)

        comp = Composition(
            name=name,
            korean_name=korean_name or name,
            description=description or f"순차 조합: {' → '.join(skill_ids)}",
            composition_type=CompositionType.SEQUENTIAL,
            steps=steps,
            depth=1,
            tags=tags or [],
        )

        comp.overall_risk_level = self._compute_risk(comp)
        self._compositions[comp.composition_id] = comp
        self._save_composition(comp)

        logger.info(
            "순차 조합 생성: %s (%d단계)", name, len(steps)
        )
        return comp

    def create_parallel(
        self,
        name: str,
        korean_name: str = "",
        skill_ids: Optional[List[str]] = None,
        description: str = "",
        tags: Optional[List[str]] = None,
    ) -> Composition:
        """
        병렬 조합 생성 / Create parallel composition.

        기술을 동시에 실행합니다: A + B + C + ...

        Args:
            name: 조합 이름
            korean_name: 한국어 이름
            skill_ids: 동시 실행할 기술 ID 목록
            description: 설명
            tags: 태그

        Returns:
            Composition: 생성된 병렬 조합
        """
        skill_ids = skill_ids or []
        steps = [
            CompositionStep(
                skill_id=sid,
                skill_name=self._skills.get(sid, Skill()).name or sid,
                order=i,
            )
            for i, sid in enumerate(skill_ids)
        ]

        comp = Composition(
            name=name,
            korean_name=korean_name or name,
            description=description or f"병렬 조합: {' + '.join(skill_ids)}",
            composition_type=CompositionType.PARALLEL,
            steps=steps,
            depth=1,
            tags=tags or [],
        )

        comp.overall_risk_level = self._compute_risk(comp)
        self._compositions[comp.composition_id] = comp
        self._save_composition(comp)

        logger.info(
            "병렬 조합 생성: %s (%d기술)", name, len(steps)
        )
        return comp

    def create_conditional(
        self,
        name: str,
        condition: str,
        true_skill_id: str,
        false_skill_id: str = "",
        korean_name: str = "",
        description: str = "",
        tags: Optional[List[str]] = None,
    ) -> Composition:
        """
        조건부 조합 생성 / Create conditional composition.

        조건에 따라 분기: if condition → A, else → B

        Args:
            name: 조합 이름
            condition: 조건 표현식
            true_skill_id: 조건 참일 때 실행할 기술
            false_skill_id: 조건 거짓일 때 실행할 기술 (선택)
            korean_name: 한국어 이름
            description: 설명
            tags: 태그

        Returns:
            Composition: 생성된 조건부 조합
        """
        steps = [
            CompositionStep(
                skill_id=true_skill_id,
                skill_name=self._skills.get(true_skill_id, Skill()).name or true_skill_id,
                order=0,
                condition=condition,
                is_else_branch=False,
                critical_step=True,
            ),
        ]

        if false_skill_id:
            steps.append(
                CompositionStep(
                    skill_id=false_skill_id,
                    skill_name=self._skills.get(false_skill_id, Skill()).name or false_skill_id,
                    order=1,
                    condition=condition,
                    is_else_branch=True,
                )
            )

        comp = Composition(
            name=name,
            korean_name=korean_name or name,
            description=description or f"조건부: if {condition} → {true_skill_id} else → {false_skill_id}",
            composition_type=CompositionType.CONDITIONAL,
            steps=steps,
            depth=1,
            tags=tags or [],
        )

        comp.overall_risk_level = self._compute_risk(comp)
        self._compositions[comp.composition_id] = comp
        self._save_composition(comp)

        logger.info("조건부 조합 생성: %s (조건: %s)", name, condition)
        return comp

    def create_loop(
        self,
        name: str,
        skill_id: str,
        loop_condition: str,
        max_iterations: int = MAX_LOOP_ITERATIONS,
        korean_name: str = "",
        description: str = "",
        tags: Optional[List[str]] = None,
    ) -> Composition:
        """
        반복 조합 생성 / Create loop composition.

        조건이 충족될 때까지 반복: repeat A until condition

        Args:
            name: 조합 이름
            skill_id: 반복할 기술 ID
            loop_condition: 계속 조건 (참인 동안 반복)
            max_iterations: 최대 반복 횟수
            korean_name: 한국어 이름
            description: 설명
            tags: 태그

        Returns:
            Composition: 생성된 반복 조합
        """
        max_iterations = min(max_iterations, MAX_LOOP_ITERATIONS)

        steps = [
            CompositionStep(
                skill_id=skill_id,
                skill_name=self._skills.get(skill_id, Skill()).name or skill_id,
                order=0,
                loop_condition=loop_condition,
                max_iterations=max_iterations,
                critical_step=True,
            ),
        ]

        comp = Composition(
            name=name,
            korean_name=korean_name or name,
            description=description or f"반복: {skill_id} while {loop_condition}",
            composition_type=CompositionType.LOOP,
            steps=steps,
            depth=1,
            tags=tags or [],
        )

        comp.overall_risk_level = self._compute_risk(comp)
        self._compositions[comp.composition_id] = comp
        self._save_composition(comp)

        logger.info("반복 조합 생성: %s (최대 %d회)", name, max_iterations)
        return comp

    def _build_sequential_steps(
        self, skill_ids: List[str]
    ) -> List[CompositionStep]:
        """
        순차 단계 목록 생성 / Build sequential step list.

        Args:
            skill_ids: 기술 ID 목록

        Returns:
            List[CompositionStep]: 단계 목록
        """
        steps: List[CompositionStep] = []
        for i, sid in enumerate(skill_ids):
            skill = self._skills.get(sid, Skill())
            steps.append(
                CompositionStep(
                    skill_id=sid,
                    skill_name=skill.name or sid,
                    order=i,
                    critical_step=(skill.risk_level > 0.5),
                )
            )
        return steps

    def _compute_risk(self, comp: Composition) -> float:
        """
        조합 전체 위험도 계산 / Compute overall risk level.

        서브 기술의 위험도를 종합하여 조합 전체의 위험도를 산출합니다.

        Args:
            comp: 조합

        Returns:
            float: 전체 위험도 (0.0 ~ 1.0)
        """
        if not comp.steps:
            return 0.0

        risks = []
        for step in comp.steps:
            skill = self._skills.get(step.skill_id)
            if skill:
                risks.append(skill.risk_level)
            else:
                risks.append(0.5)  # Unknown skill = medium risk

        if not risks:
            return 0.0

        # Max risk dominates, but average contributes / 최대 위험 우선 + 평균 기여
        max_risk = max(risks)
        avg_risk = sum(risks) / len(risks)

        # More steps = higher cumulative risk / 단계 많을수록 누적 위험 증가
        step_factor = min(len(risks) / MAX_SUB_SKILLS, 1.0)

        overall = max_risk * 0.6 + avg_risk * 0.3 + step_factor * 0.1
        return min(1.0, overall)

    def validate(self, comp: Composition) -> ValidationResult:
        """
        조합 검증 / Validate a composition.

        안전성, 깊이, 기술 존재 여부 등을 검사합니다.

        Args:
            comp: 검증할 조합

        Returns:
            ValidationResult: 검증 결과
        """
        errors: List[str] = []
        warnings: List[str] = []
        suggestions: List[str] = []
        risk_assessment: Dict[str, float] = {}

        # 1. Check depth / 깊이 검사
        if comp.depth > MAX_COMPOSITION_DEPTH:
            errors.append(
                f"조합 깊이가 최대치 초과: {comp.depth} > {MAX_COMPOSITION_DEPTH}"
            )

        # 2. Check step count / 단계 수 검사
        if len(comp.steps) > MAX_SUB_SKILLS:
            errors.append(
                f"서브 기술 수가 최대치 초과: {len(comp.steps)} > {MAX_SUB_SKILLS}"
            )

        if len(comp.steps) == 0:
            errors.append("서브 기술이 없습니다.")

        # 3. Check skill existence / 기술 존재 여부
        for step in comp.steps:
            if step.skill_id not in self._skills:
                errors.append(
                    f"알 수 없는 기술: {step.skill_id} (단계 {step.order})"
                )

        # 4. Check loop constraints / 반복 제약 검사
        if comp.composition_type == CompositionType.LOOP:
            for step in comp.steps:
                if step.max_iterations > MAX_LOOP_ITERATIONS:
                    errors.append(
                        f"최대 반복 횟수 초과: {step.max_iterations} > {MAX_LOOP_ITERATIONS}"
                    )
                if not step.loop_condition:
                    warnings.append("반복 조건이 비어 있습니다. 무한 루프 위험.")

        # 5. Check conditional logic / 조건부 논리 검사
        if comp.composition_type == CompositionType.CONDITIONAL:
            has_then = any(not s.is_else_branch for s in comp.steps)
            has_else = any(s.is_else_branch for s in comp.steps)
            if not has_then:
                errors.append("조건부 조합에 'then' 분기가 없습니다.")
            if not has_else:
                warnings.append("'else' 분기가 없습니다. 조건 불만족 시 아무 동작 안 함.")

        # 6. Risk assessment / 위험도 평가
        risk_assessment["overall"] = comp.overall_risk_level
        for step in comp.steps:
            skill = self._skills.get(step.skill_id)
            risk_val = skill.risk_level if skill else 0.5
            risk_assessment[step.skill_id] = risk_val
            if risk_val > 0.7:
                warnings.append(
                    f"고위험 기술: {step.skill_id} (위험도: {risk_val:.2f})"
                )
                suggestions.append(
                    f"'{step.skill_id}'에 대한 안전 대책 추가 권장"
                )

        if comp.overall_risk_level > 0.8:
            errors.append(
                f"전체 위험도가 너무 높음: {comp.overall_risk_level:.2f}"
            )

        # 7. Check safety checks for critical steps / 중요 단계 안전 검사
        for step in comp.steps:
            if step.critical_step:
                skill = self._skills.get(step.skill_id)
                if skill and not skill.safety_checks:
                    warnings.append(
                        f"중요 단계 '{step.skill_id}'에 안전 검사가 없습니다."
                    )
                if not step.fallback_skill_id:
                    suggestions.append(
                        f"중요 단계 '{step.skill_id}'에 대체 기술 설정 권장"
                    )

        # Estimate success rate / 예상 성공률
        estimated_rate = self._estimate_success_rate(comp)

        # Determine validation level / 검증 수준 결정
        if errors:
            level = ValidationLevel.FAIL
            is_valid = False
        elif warnings:
            level = ValidationLevel.WARNING
            is_valid = True
        else:
            level = ValidationLevel.PASS
            is_valid = True

        result = ValidationResult(
            is_valid=is_valid,
            level=level,
            errors=errors,
            warnings=warnings,
            risk_assessment=risk_assessment,
            estimated_success_rate=estimated_rate,
            suggestions=suggestions,
        )

        logger.info(
            "조합 검증: %s - %s (오류: %d, 경고: %d)",
            comp.name,
            level.value,
            len(errors),
            len(warnings),
        )

        return result

    def _estimate_success_rate(self, comp: Composition) -> float:
        """
        예상 성공률 산출 / Estimate composition success rate.

        Args:
            comp: 조합

        Returns:
            float: 예상 성공률 (0.0 ~ 1.0)
        """
        if not comp.steps:
            return 0.0

        rates = []
        for step in comp.steps:
            skill = self._skills.get(step.skill_id)
            if skill and skill.success_rate > 0:
                rates.append(skill.success_rate)
            else:
                rates.append(0.5)  # Default for unmeasured / 미측정 기본값

        if comp.composition_type == CompositionType.SEQUENTIAL:
            # Sequential: all must succeed / 순차: 모두 성공해야 함
            product = 1.0
            for r in rates:
                product *= r
            return product

        elif comp.composition_type == CompositionType.PARALLEL:
            # Parallel: average / 병렬: 평균
            return statistics.mean(rates)

        elif comp.composition_type == CompositionType.CONDITIONAL:
            # Conditional: weighted average / 조건부: 가중 평균
            return statistics.mean(rates) if rates else 0.5

        elif comp.composition_type == CompositionType.LOOP:
            # Loop: single skill rate (conservative) / 반복: 단일 기술률 (보수적)
            return rates[0] * 0.8 if rates else 0.0

        return 0.5

    def get_composition(self, composition_id: str) -> Optional[Composition]:
        """
        조합 조회 / Get a composition by ID.

        Args:
            composition_id: 조합 ID

        Returns:
            Optional[Composition]: 조합 (없으면 None)
        """
        return self._compositions.get(composition_id)

    def get_all_compositions(self) -> Dict[str, Composition]:
        """
        모든 조합 반환 / Return all compositions.

        Returns:
            Dict: 조합 ID → 조합 매핑
        """
        return dict(self._compositions)

    def add_skill(self, skill: Skill) -> None:
        """
        기술 라이브러리에 기술 추가 / Add skill to library.

        Args:
            skill: 추가할 기술
        """
        self._skills[skill.skill_id] = skill
        logger.info("기술 추가: %s (%s)", skill.name, skill.skill_id)

    def _save_composition(self, comp: Composition) -> None:
        """
        조합을 DB에 저장 / Save composition to database.

        Args:
            comp: 저장할 조합
        """
        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT OR REPLACE INTO compositions
                    (composition_id, name, korean_name, composition_type,
                     steps_json, depth, risk_level, success_rate,
                     execution_count, is_auto_composed, tags_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    comp.composition_id,
                    comp.name,
                    comp.korean_name,
                    comp.composition_type.value,
                    json.dumps([
                        {
                            "step_id": s.step_id,
                            "skill_id": s.skill_id,
                            "order": s.order,
                            "condition": s.condition,
                            "is_else_branch": s.is_else_branch,
                            "loop_condition": s.loop_condition,
                            "max_iterations": s.max_iterations,
                            "critical_step": s.critical_step,
                            "fallback_skill_id": s.fallback_skill_id,
                        }
                        for s in comp.steps
                    ], ensure_ascii=False),
                    comp.depth,
                    comp.overall_risk_level,
                    comp.success_rate,
                    comp.execution_count,
                    int(comp.is_auto_composed),
                    json.dumps(comp.tags, ensure_ascii=False),
                    comp.created_at,
                ),
            )
            conn.commit()
            if self._db_path != ":memory:":
                conn.close()
        except sqlite3.Error as e:
            logger.error("조합 저장 실패: %s", e)


# ---------------------------------------------------------------------------
# CompositionPlanner / 조합 계획기
# ---------------------------------------------------------------------------

class CompositionPlanner:
    """
    조합 계획기 / Composition Planner.

    목표를 분해하여 적절한 기술 조합을 계획합니다.
    V8.5 SkillLibrary와 통합됩니다.

    Usage:
        >>> planner = CompositionPlanner()
        >>> plan = planner.plan("bring me a cup of water")
        >>> print(plan.name)
    """

    # Goal-to-skill mapping templates / 목표-기술 매핑 템플릿
    GOAL_TEMPLATES: Dict[str, Dict[str, Any]] = {
        "fetch_object": {
            "korean": "물건 가져오기",
            "type": CompositionType.SEQUENTIAL,
            "skills": ["scan_environment", "navigate_to", "approach_object", "grasp_object", "navigate_to", "place_object"],
            "description": "물건을 찾아서 가져오는 순차 조합",
        },
        "open_and_enter": {
            "korean": "문 열고 들어가기",
            "type": CompositionType.SEQUENTIAL,
            "skills": ["approach_object", "open_door", "navigate_to"],
            "description": "문을 열고 방으로 들어가는 순차 조합",
        },
        "search_and_report": {
            "korean": "검색 후 보고",
            "type": CompositionType.LOOP,
            "skills": ["scan_environment"],
            "loop_condition": "object_not_found",
            "description": "물건을 찾을 때까지 검색하는 반복 조합",
        },
        "safe_interact": {
            "korean": "안전한 상호작용",
            "type": CompositionType.CONDITIONAL,
            "condition": "is_safe",
            "true_skill": "grasp_object",
            "false_skill": "check_safety",
            "description": "안전 확인 후 상호작용하는 조건부 조합",
        },
        "explore_while_moving": {
            "korean": "이동하며 탐색",
            "type": CompositionType.PARALLEL,
            "skills": ["navigate_to", "scan_environment"],
            "description": "이동과 탐색을 동시에 수행하는 병렬 조합",
        },
    }

    def __init__(
        self,
        composer: Optional[SkillComposer] = None,
    ) -> None:
        """
        CompositionPlanner 초기화.

        Args:
            composer: SkillComposer 인스턴스
        """
        self._composer = composer or SkillComposer()
        logger.info("CompositionPlanner 초기화 완료")

    def plan(
        self,
        goal: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Optional[Composition]:
        """
        목표를 기술 조합으로 계획 / Plan skill composition for a goal.

        Args:
            goal: 목표 설명
            context: 추가 컨텍스트

        Returns:
            Optional[Composition]: 계획된 조합 (매칭 실패 시 None)
        """
        goal_lower = goal.lower()

        # Match against templates / 템플릿 매칭
        best_match = self._match_template(goal_lower)

        if best_match:
            template = self.GOAL_TEMPLATES[best_match]
            return self._compose_from_template(best_match, template)

        # If no template match, try to decompose / 템플릿 매칭 실패 시 분해 시도
        return self._decompose_goal(goal, context or {})

    def _match_template(self, goal: str) -> Optional[str]:
        """
        목표를 템플릿에 매칭 / Match goal to a template.

        Args:
            goal: 목표 문자열

        Returns:
            Optional[str]: 매칭된 템플릿 키
        """
        keyword_map: Dict[str, List[str]] = {
            "fetch_object": ["가져", "fetch", "bring", "물건", "컵", "cup"],
            "open_and_enter": ["문", "door", "열고", "open", "들어가", "enter"],
            "search_and_report": ["찾", "search", "find", "검색", "look for"],
            "safe_interact": ["안전", "safe", "조심", "careful", "interact"],
            "explore_while_moving": ["탐색", "explore", "이동하며", "while moving"],
        }

        for template_key, keywords in keyword_map.items():
            for kw in keywords:
                if kw in goal:
                    return template_key

        return None

    def _compose_from_template(
        self, template_key: str, template: Dict[str, Any]
    ) -> Composition:
        """
        템플릿으로부터 조합 생성 / Create composition from template.

        Args:
            template_key: 템플릿 키
            template: 템플릿 데이터

        Returns:
            Composition: 생성된 조합
        """
        comp_type = template["type"]

        if comp_type == CompositionType.SEQUENTIAL:
            return self._composer.create_sequential(
                name=template_key,
                korean_name=template["korean"],
                skill_ids=template["skills"],
                description=template["description"],
            )
        elif comp_type == CompositionType.PARALLEL:
            return self._composer.create_parallel(
                name=template_key,
                korean_name=template["korean"],
                skill_ids=template["skills"],
                description=template["description"],
            )
        elif comp_type == CompositionType.CONDITIONAL:
            return self._composer.create_conditional(
                name=template_key,
                condition=template["condition"],
                true_skill_id=template["true_skill"],
                false_skill_id=template["false_skill"],
                korean_name=template["korean"],
                description=template["description"],
            )
        elif comp_type == CompositionType.LOOP:
            comp = self._composer.create_loop(
                name=template_key,
                skill_id=template["skills"][0],
                loop_condition=template.get("loop_condition", "not_complete"),
                korean_name=template["korean"],
                description=template["description"],
            )
            return comp

        raise ValueError(f"지원하지 않는 조합 유형: {comp_type}")

    def _decompose_goal(
        self, goal: str, context: Dict[str, Any]
    ) -> Optional[Composition]:
        """
        목표를 분해하여 조합 생성 / Decompose goal into composition.

        간단한 휴리스틱으로 목표를 기술 단계로 분해합니다.

        Args:
            goal: 목표
            context: 컨텍스트

        Returns:
            Optional[Composition]: 생성된 조합 (분해 불가 시 None)
        """
        # Simple heuristic decomposition / 간단한 휴리스틱 분해
        steps: List[str] = []

        # Navigation needed? / 이동 필요?
        if any(kw in goal for kw in ["가", "이동", "go", "move", "fetch", "bring"]):
            steps.append("navigate_to")

        # Perception needed? / 지각 필요?
        if any(kw in goal for kw in ["찾", "보", "find", "look", "scan", "search"]):
            steps.append("scan_environment")

        # Manipulation needed? / 조작 필요?
        if any(kw in goal for kw in ["잡", "들", "grasp", "pick", "hold", "가져"]):
            steps.extend(["approach_object", "grasp_object"])

        if any(kw in goal for kw in ["놓", "두", "place", "put", "put down"]):
            steps.append("place_object")

        if any(kw in goal for kw in ["밀", "push", "문", "door"]):
            steps.append("push_object")

        # Communication needed? / 통신 필요?
        if any(kw in goal for kw in ["말", "알려", "speak", "tell", "say", "report"]):
            steps.append("speak")

        if not steps:
            logger.warning("목표 분해 실패: %s", goal)
            return None

        # Remove duplicates while preserving order / 중복 제거 (순서 유지)
        seen: Set[str] = set()
        unique_steps: List[str] = []
        for s in steps:
            if s not in seen:
                seen.add(s)
                unique_steps.append(s)

        return self._composer.create_sequential(
            name=f"auto_{goal[:20]}",
            korean_name=f"자동 계획: {goal[:20]}",
            skill_ids=unique_steps,
            description=f"목표 분해 자동 생성: {goal}",
        )


# ---------------------------------------------------------------------------
# CompositionValidator / 조합 검증기
# ---------------------------------------------------------------------------

class CompositionValidator:
    """
    조합 검증기 / Composition Validator.

    실행 전 조합의 안전성과 타당성을 검증합니다.
    SkillComposer.validate()를 래핑하고 추가 검사를 수행합니다.

    Usage:
        >>> validator = CompositionValidator()
        >>> result = validator.full_validation(composition)
        >>> if not result.is_valid:
        ...     print("검증 실패:", result.errors)
    """

    def __init__(
        self,
        composer: Optional[SkillComposer] = None,
    ) -> None:
        """
        CompositionValidator 초기화.

        Args:
            composer: SkillComposer 인스턴스
        """
        self._composer = composer or SkillComposer()
        logger.info("CompositionValidator 초기화 완료")

    def full_validation(self, comp: Composition) -> ValidationResult:
        """
        전체 검증 수행 / Perform full validation.

        기본 검증 + 추가 안전 검사를 수행합니다.

        Args:
            comp: 검증할 조합

        Returns:
            ValidationResult: 검증 결과
        """
        # Base validation / 기본 검증
        result = self._composer.validate(comp)

        # Additional safety checks / 추가 안전 검사
        self._check_resource_conflicts(comp, result)
        self._check_precondition_chain(comp, result)
        self._check_parallel_safety(comp, result)

        # Re-evaluate validity / 유효성 재평가
        if result.errors:
            result.is_valid = False
            result.level = ValidationLevel.FAIL

        return result

    def quick_validation(self, comp: Composition) -> bool:
        """
        빠른 검증 / Quick validation check.

        기본적인 안전 검사만 수행합니다.

        Args:
            comp: 검증할 조합

        Returns:
            bool: 검증 통과 여부
        """
        if comp.depth > MAX_COMPOSITION_DEPTH:
            return False
        if len(comp.steps) > MAX_SUB_SKILLS:
            return False
        if comp.overall_risk_level > 0.9:
            return False
        return True

    def _check_resource_conflicts(
        self, comp: Composition, result: ValidationResult
    ) -> None:
        """
        리소스 충돌 검사 / Check for resource conflicts.

        병렬 실행 시 동일 리소스를 요구하는 기술이 있는지 확인합니다.

        Args:
            comp: 조합
            result: 검증 결과 (업데이트)
        """
        if comp.composition_type != CompositionType.PARALLEL:
            return

        resource_map: Dict[str, List[str]] = {}
        for step in comp.steps:
            skill = self._composer._skills.get(step.skill_id)
            if skill:
                for cap in skill.required_capabilities:
                    if cap not in resource_map:
                        resource_map[cap] = []
                    resource_map[cap].append(step.skill_id)

        for resource, skills in resource_map.items():
            if len(skills) > 1:
                result.warnings.append(
                    f"리소스 충돌 가능: '{resource}'를 {skills}이(가) 동시 요구"
                )
                result.suggestions.append(
                    f"병렬 실행 대신 순차 실행을 고려하세요: {skills}"
                )

    def _check_precondition_chain(
        self, comp: Composition, result: ValidationResult
    ) -> None:
        """
        전제조건 체인 검사 / Check precondition chain for sequential compositions.

        Args:
            comp: 조합
            result: 검증 결과 (업데이트)
        """
        if comp.composition_type != CompositionType.SEQUENTIAL:
            return

        skills = self._composer._skills
        for i, step in enumerate(comp.steps):
            skill = skills.get(step.skill_id)
            if skill and skill.preconditions:
                # Check if earlier steps satisfy preconditions
                # (simplified check) / 이전 단계가 전제조건을 충족하는지 (단순화)
                satisfied = set()
                for prev_step in comp.steps[:i]:
                    prev_skill = skills.get(prev_step.skill_id)
                    if prev_skill:
                        satisfied.update(prev_skill.postconditions)

                unsatisfied = set(skill.preconditions) - satisfied
                if unsatisfied:
                    result.warnings.append(
                        f"단계 {i} '{step.skill_id}'의 미충족 전제조건: {unsatisfied}"
                    )

    def _check_parallel_safety(
        self, comp: Composition, result: ValidationResult
    ) -> None:
        """
        병렬 실행 안전성 검사 / Check parallel execution safety.

        Args:
            comp: 조합
            result: 검증 결과 (업데이트)
        """
        if comp.composition_type != CompositionType.PARALLEL:
            return

        skills = self._composer._skills
        high_risk_parallel = [
            step.skill_id for step in comp.steps
            if skills.get(step.skill_id, Skill()).risk_level > 0.5
        ]

        if len(high_risk_parallel) > 1:
            result.errors.append(
                f"고위험 기술 병렬 실행 위험: {high_risk_parallel}"
            )


# ---------------------------------------------------------------------------
# CompositionLearner / 조합 학습기
# ---------------------------------------------------------------------------

class CompositionLearner:
    """
    조합 학습기 / Composition Learner.

    경험으로부터 효과적인 기술 조합을 학습합니다.
    반복되는 패턴을 자동으로 감지하여 조합 기술로 생성합니다.

    Features:
      - 실행 결과로 성공률 업데이트
      - 반복 패턴 자동 감지 → 조합 생성
      - 비효율적 조합 식별 및 개선 제안

    Usage:
        >>> learner = CompositionLearner()
        >>> learner.record_execution(comp, exec_result)
        >>> patterns = learner.detect_patterns()
    """

    def __init__(
        self,
        composer: Optional[SkillComposer] = None,
        db_path: Optional[str] = None,
    ) -> None:
        """
        CompositionLearner 초기화.

        Args:
            composer: SkillComposer 인스턴스
            db_path: SQLite DB 경로
        """
        self._composer = composer or SkillComposer()
        self._db_path = db_path or ":memory:"
        self._observations: List[PatternObservation] = []
        self._pattern_threshold = 3  # Pattern detection threshold / 패턴 감지 임계값
        logger.info("CompositionLearner 초기화 완료")

    def record_execution(
        self,
        comp: Composition,
        result: ExecutionResult,
    ) -> None:
        """
        실행 결과 기록 / Record execution result for learning.

        Args:
            comp: 실행된 조합
            result: 실행 결과
        """
        # Update composition success rate / 조합 성공률 업데이트
        if result.status == SkillStatus.COMPLETED:
            comp.success_rate = (
                comp.success_rate * 0.8 + 1.0 * 0.2
                if comp.execution_count > 0 else 1.0
            )
        elif result.status == SkillStatus.FAILED:
            comp.success_rate = (
                comp.success_rate * 0.8 + 0.0 * 0.2
                if comp.execution_count > 0 else 0.0
            )

        comp.execution_count += 1
        comp.last_executed = datetime.now(timezone.utc).isoformat()

        # Record skill sequence as observation / 기술 시퀀스 관찰 기록
        skill_seq = [s.skill_id for s in comp.steps]
        self._record_observation(
            skill_sequence=skill_seq,
            context=comp.name,
            success=(result.status == SkillStatus.COMPLETED),
        )

        # Update skill success rates / 개별 기술 성공률 업데이트
        for step_result in result.step_results:
            skill_id = step_result.get("skill_id", "")
            success = step_result.get("success", False)
            skill = self._composer._skills.get(skill_id)
            if skill:
                if skill.practice_count == 0:
                    skill.success_rate = 1.0 if success else 0.0
                else:
                    skill.success_rate = (
                        skill.success_rate * 0.8
                        + (1.0 if success else 0.0) * 0.2
                    )
                skill.practice_count += 1

        logger.info(
            "실행 기록: %s - %s (성공률: %.2f)",
            comp.name,
            SKILL_STATUS_KOREAN.get(result.status, result.status.value),
            comp.success_rate,
        )

    def _record_observation(
        self,
        skill_sequence: List[str],
        context: str = "",
        success: bool = True,
    ) -> None:
        """
        패턴 관찰 기록 / Record pattern observation.

        Args:
            skill_sequence: 기술 시퀀스
            context: 컨텍스트
            success: 성공 여부
        """
        # Check for existing pattern / 기존 패턴 확인
        seq_key = json.dumps(skill_sequence)
        for obs in self._observations:
            if json.dumps(obs.skill_sequence) == seq_key:
                obs.frequency += 1
                obs.last_observed = datetime.now(timezone.utc).isoformat()
                if not success:
                    obs.success = False
                return

        # New observation / 새 관찰
        self._observations.append(
            PatternObservation(
                skill_sequence=skill_sequence,
                context=context,
                success=success,
            )
        )

    def detect_patterns(self) -> List[PatternObservation]:
        """
        반복 패턴 감지 / Detect repeated patterns.

        빈번하게 반복되는 기술 시퀀스를 감지하여
        자동 조합 생성 후보를 식별합니다.

        Returns:
            List[PatternObservation]: 감지된 패턴 목록
        """
        patterns = [
            obs for obs in self._observations
            if obs.frequency >= self._pattern_threshold
        ]

        # Also detect sub-sequences / 하위 시퀀스도 감지
        sub_patterns = self._detect_sub_patterns()
        patterns.extend(sub_patterns)

        # Sort by frequency / 빈도순 정렬
        patterns.sort(key=lambda p: p.frequency, reverse=True)

        if patterns:
            logger.info(
                "반복 패턴 %d개 감지", len(patterns)
            )

        return patterns

    def _detect_sub_patterns(self) -> List[PatternObservation]:
        """
        하위 시퀀스 패턴 감지 / Detect sub-sequence patterns.

        관찰된 시퀀스 내에서 반복되는 2-3개의 하위 시퀀스를 찾습니다.

        Returns:
            List[PatternObservation]: 감지된 하위 패턴
        """
        sub_patterns: Dict[str, PatternObservation] = {}

        for obs in self._observations:
            seq = obs.skill_sequence
            # Check sub-sequences of length 2-3 / 길이 2-3의 하위 시퀀스 확인
            for length in [2, 3]:
                for i in range(len(seq) - length + 1):
                    sub_seq = seq[i:i + length]
                    key = json.dumps(sub_seq)

                    if key in sub_patterns:
                        sub_patterns[key].frequency += 1
                    else:
                        sub_patterns[key] = PatternObservation(
                            skill_sequence=sub_seq,
                            context="sub-pattern",
                            frequency=1,
                        )

        # Filter by threshold / 임계값 필터
        return [
            p for p in sub_patterns.values()
            if p.frequency >= self._pattern_threshold + 1
        ]

    def auto_compose(self) -> List[Composition]:
        """
        자동 조합 생성 / Auto-create compositions from detected patterns.

        감지된 반복 패턴을 바탕으로 자동으로 조합 기술을 생성합니다.

        Returns:
            List[Composition]: 자동 생성된 조합 목록
        """
        patterns = self.detect_patterns()
        new_compositions: List[Composition] = []

        for pattern in patterns:
            # Skip if already composed / 이미 조합된 패턴 건너뛰기
            skill_ids = pattern.skill_sequence

            # Check if composition already exists / 기존 조합 확인
            existing = False
            for comp in self._composer.get_all_compositions().values():
                comp_skills = [s.skill_id for s in comp.steps]
                if comp_skills == skill_ids:
                    existing = True
                    break

            if existing:
                continue

            # Create auto composition / 자동 조합 생성
            name = "auto_" + "_".join(skill_ids[:3])
            korean_name = f"자동 조합 ({len(skill_ids)}단계)"

            comp = self._composer.create_sequential(
                name=name,
                korean_name=korean_name,
                skill_ids=skill_ids,
                description=f"자동 감지된 반복 패턴 (빈도: {pattern.frequency})",
                tags=["auto_composed", pattern.context],
            )
            comp.is_auto_composed = True

            new_compositions.append(comp)
            logger.info(
                "자동 조합 생성: %s (빈도: %d)",
                name, pattern.frequency,
            )

        return new_compositions

    def suggest_improvements(
        self, comp: Composition
    ) -> List[str]:
        """
        조합 개선 제안 / Suggest improvements for a composition.

        Args:
            comp: 분석할 조합

        Returns:
            List[str]: 개선 제안 목록
        """
        suggestions: List[str] = []

        # Low success rate / 낮은 성공률
        if comp.success_rate < 0.5 and comp.execution_count > 3:
            suggestions.append(
                f"성공률이 낮습니다 ({comp.success_rate:.0%}). "
                "단계별 분석으로 실패 원인을 파악하세요."
            )

        # High risk / 높은 위험도
        if comp.overall_risk_level > 0.6:
            suggestions.append(
                f"위험도가 높습니다 ({comp.overall_risk_level:.2f}). "
                "안전 검사 단계를 추가하세요."
            )

        # Too many steps / 단계 과다
        if comp.step_count > 7:
            suggestions.append(
                "단계가 많습니다. 하위 조합으로 나누는 것을 고려하세요."
            )

        # Missing fallbacks / 대체 기술 누락
        critical_without_fallback = [
            s.skill_id for s in comp.steps
            if s.critical_step and not s.fallback_skill_id
        ]
        if critical_without_fallback:
            suggestions.append(
                f"중요 단계에 대체 기술이 없습니다: {critical_without_fallback}"
            )

        return suggestions

    def get_observations(self, limit: int = 100) -> List[PatternObservation]:
        """
        관찰 기록 반환 / Return pattern observations.

        Args:
            limit: 최대 반환 개수

        Returns:
            List[PatternObservation]: 관찰 기록
        """
        return self._observations[-limit:]


# ---------------------------------------------------------------------------
# Convenience Functions / 편의 함수
# ---------------------------------------------------------------------------

def create_skill_composition_system(
    db_path: Optional[str] = None,
) -> Tuple[SkillComposer, CompositionPlanner, CompositionValidator, CompositionLearner]:
    """
    기술 조합 시스템 생성 / Create complete skill composition system.

    Args:
        db_path: SQLite DB 경로

    Returns:
        Tuple[SkillComposer, CompositionPlanner, CompositionValidator, CompositionLearner]
    """
    composer = SkillComposer(db_path=db_path)
    planner = CompositionPlanner(composer=composer)
    validator = CompositionValidator(composer=composer)
    learner = CompositionLearner(composer=composer, db_path=db_path)
    return composer, planner, validator, learner


# ---------------------------------------------------------------------------
# Module Entry Point / 모듈 진입점
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    print("=" * 60)
    print("지훈 로봇 V8.5 - Skill Composition Engine")
    print("기술 조합 엔진 모듈")
    print("=" * 60)

    composer, planner, validator, learner = create_skill_composition_system()

    # Demo: create compositions / 데모: 조합 생성
    print("\n🔧 기술 조합 생성 데모:\n")

    # 1. Sequential: pick and place / 순차: 집어서 놓기
    pick_place = composer.create_sequential(
        name="pick_and_place",
        korean_name="집어서 놓기",
        skill_ids=["approach_object", "grasp_object", "navigate_to", "place_object"],
        description="물건을 집어서 목표 위치에 놓기",
    )
    print(f"  순차 조합: {pick_place.korean_name} ({pick_place.step_count}단계)")

    # 2. Parallel: move while scanning / 병렬: 이동하며 스캔
    move_scan = composer.create_parallel(
        name="explore_while_moving",
        korean_name="이동하며 탐색",
        skill_ids=["navigate_to", "scan_environment"],
        description="이동하면서 환경을 스캔",
    )
    print(f"  병렬 조합: {move_scan.korean_name} ({move_scan.step_count}기술)")

    # 3. Conditional: push or pull door / 조건부: 문 밀기 또는 당기기
    door_comp = composer.create_conditional(
        name="open_door_smart",
        condition="door_push_type",
        true_skill_id="push_object",
        false_skill_id="grasp_object",
        korean_name="스마트 문 열기",
        description="문 유형에 따라 밀기 또는 당기기",
    )
    print(f"  조건부 조합: {door_comp.korean_name}")

    # 4. Loop: search until found / 반복: 찾을 때까지 검색
    search_loop = composer.create_loop(
        name="search_until_found",
        skill_id="scan_environment",
        loop_condition="object_not_found",
        max_iterations=20,
        korean_name="찾을 때까지 검색",
    )
    print(f"  반복 조합: {search_loop.korean_name} (최대 {20}회)")

    # Validate compositions / 조합 검증
    print("\n✅ 조합 검증:\n")
    for comp in [pick_place, move_scan, door_comp, search_loop]:
        result = validator.full_validation(comp)
        status = "✅ 통과" if result.is_valid else "❌ 실패"
        print(f"  {comp.korean_name}: {status}")
        if result.warnings:
            for w in result.warnings[:2]:
                print(f"    ⚠️ {w[:50]}...")
        if result.suggestions:
            for s in result.suggestions[:2]:
                print(f"    💡 {s[:50]}...")

    # Plan from goal / 목표에서 계획
    print("\n🎯 목표 기반 계획:\n")
    goals = [
        "컵 가져와",
        "문 열고 들어가",
        "안전하게 잡아",
    ]
    for goal in goals:
        plan = planner.plan(goal)
        if plan:
            print(f"  '{goal}' → {plan.korean_name} ({plan.step_count}단계)")
        else:
            print(f"  '{goal}' → 계획 실패")

    # Auto-compose from patterns / 패턴 자동 조합
    print("\n🤖 자동 패턴 감지:\n")
    # Simulate repeated observations / 반복 관찰 시뮬레이션
    for _ in range(5):
        learner.record_execution(
            pick_place,
            ExecutionResult(
                composition_id=pick_place.composition_id,
                status=SkillStatus.COMPLETED,
                completed_steps=4,
                total_steps=4,
            ),
        )

    patterns = learner.detect_patterns()
    print(f"  감지된 패턴: {len(patterns)}개")
    for p in patterns[:3]:
        print(f"    {' → '.join(p.skill_sequence)} (빈도: {p.frequency})")

    # Improvements / 개선 제안
    suggestions = learner.suggest_improvements(pick_place)
    if suggestions:
        print("\n  개선 제안:")
        for s in suggestions[:3]:
            print(f"    💡 {s}")
