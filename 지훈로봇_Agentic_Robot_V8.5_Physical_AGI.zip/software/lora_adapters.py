#!/usr/bin/env python3
"""
lora_adapters.py — V8.5 LoRA Adapter System for Skill-Specific Fine-Tuning
지훈 로봇 물리적 AGI — V8.5 스킬별 파인튜닝을 위한 LoRA 어댑터 시스템

LoRA (Low-Rank Adaptation) enables efficient, parameter-efficient fine-tuning
by injecting trainable low-rank matrices into frozen base model layers.
Each physical skill category gets its own LoRA adapter, and the system
manages switching, merging, and persistence of adapters.

LoRA는 고정된 기반 모델 레이어에 학습 가능한 저랭크 행렬을 주입하여
효율적인 파라미터 효율적 파인튜닝을 가능하게 합니다.
각 물리적 스킬 카테고리는 자체 LoRA 어댑터를 가지며, 시스템은
어댑터의 전환, 병합, 영속화를 관리합니다.

Components / 구성요소:
  1. LoRALayer          — nn.Module 저랭크 분해 레이어 (rank 8)
  2. SkillLoRAManager   — 스킬 카테고리별 LoRA 어댑터 관리
  3. EWCRegularizer     — Elastic Weight Consolidation (치명적 망각 방지)
  4. Numpy fallback     — torch 미사용 환경에서의 대체 구현

LoRA Formula / LoRA 수식:
  forward(x) = W·x + (α/r)·B·A·x
  where B ∈ ℝ^(out_dim × r), A ∈ ℝ^(r × in_dim), r = rank

Hardware: Dual Jetson Orin NX 16GB
AI Model: Gemma 4 E4B Q4_K_M
Author: 지훈 로봇 V8.5 개발팀
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np

# ─── PyTorch 선택적 임포트 / Optional PyTorch Import ─────────────────────────

TORCH_AVAILABLE = False
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.utils.data import DataLoader
    TORCH_AVAILABLE = True
except ImportError:
    torch = None
    nn = None
    F = None
    DataLoader = None

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.lora_adapters")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)

# ─── 상수 / Constants ────────────────────────────────────────────────────────

DEFAULT_LORA_RANK = 8
DEFAULT_LORA_ALPHA = 16.0  # α/r = 16/8 = 2.0 scaling
STATE_DIM = 62
HIDDEN_DIM = 256
EPS = 1e-8


class SkillCategory(str, Enum):
    """스킬 카테고리 / Skill categories."""
    LOCOMOTION = "locomotion"
    TERRAIN_NAV = "terrain_navigation"
    GRIPPING = "gripping"
    MANIPULATION = "manipulation"
    LIFTING = "lifting"
    CARRYING = "carrying"
    CRAFTWORK = "craftwork"
    TOOL_USE = "tool_use"
    MULTI_STEP = "multi_step"
    EXPLORATION = "exploration"


# ─── PyTorch LoRA 레이어 / PyTorch LoRA Layer ───────────────────────────────

if TORCH_AVAILABLE:

    class LoRALayer(nn.Module):
        """
        LoRA 저랭크 적응 레이어 / LoRA Low-Rank Adaptation Layer.

        기반 가중치 W는 고정(frozen)하고, 학습 가능한 저랭크 행렬
        B ∈ ℝ^(out_dim × rank)와 A ∈ ℝ^(rank × in_dim)를 추가합니다.

        forward(x) = W·x + (α/rank) · B·A·x

        Args:
            in_dim:    입력 차원 / Input dimension
            out_dim:   출력 차원 / Output dimension
            rank:      LoRA 랭크 / LoRA rank
            alpha:     스케일링 factor / Scaling factor
            dropout:   드롭아웃 비율 / Dropout rate
        """

        def __init__(
            self,
            in_dim: int,
            out_dim: int,
            rank: int = DEFAULT_LORA_RANK,
            alpha: float = DEFAULT_LORA_ALPHA,
            dropout: float = 0.0,
        ) -> None:
            super().__init__()
            self.in_dim = in_dim
            self.out_dim = out_dim
            self.rank = rank
            self.alpha = alpha
            self.scaling = alpha / rank

            # 기반 가중치 (고정) / Base weight (frozen)
            self.weight = nn.Parameter(
                torch.randn(out_dim, in_dim) * 0.02, requires_grad=False
            )

            # LoRA 행렬 B, A (학습 가능) / LoRA matrices B, A (trainable)
            # A: Kaiming 초기화, B: 영 초기화 → 초기에 ΔW = B·A ≈ 0
            self.lora_A = nn.Parameter(torch.randn(rank, in_dim) * 0.01)
            self.lora_B = nn.Parameter(torch.zeros(out_dim, rank))

            # 선택적 드롭아웃 / Optional dropout
            self.lora_dropout = nn.Dropout(p=dropout) if dropout > 0.0 else nn.Identity()

            # 병합 플래그 / Merge flag
            self._merged = False

            logger.debug(
                "LoRALayer 생성: in=%d, out=%d, rank=%d, alpha=%.1f",
                in_dim, out_dim, rank, alpha,
            )

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            """
            순전파 / Forward pass.

            병합 전: y = W·x + (α/r)·B·(A·x)
            병합 후: y = (W + ΔW)·x

            Args:
                x: 입력 텐서 [batch, in_dim]

            Returns:
                출력 텐서 [batch, out_dim]
            """
            if self._merged:
                # 병합된 가중치로 직접 계산 / Direct computation with merged weights
                return F.linear(x, self.weight)
            else:
                # 기반 + LoRA / Base + LoRA
                base_out = F.linear(x, self.weight)
                lora_in = self.lora_dropout(x)
                lora_out = F.linear(
                    F.linear(lora_in, self.lora_A), self.lora_B
                ) * self.scaling
                return base_out + lora_out

        def merge(self) -> None:
            """
            LoRA 가중치를 기반 가중치에 병합 / Merge LoRA weights into base weight.

            W_merged = W + (α/r) · B · A
            병합 후에는 추론 시 추가 연산이 필요 없습니다.
            """
            if not self._merged:
                delta_w = (self.lora_B @ self.lora_A) * self.scaling
                self.weight.data += delta_w
                self._merged = True
                logger.debug("LoRA 가중치 병합 완료")

        def unmerge(self) -> None:
            """
            병합된 가중치를 다시 분리 / Unmerge weights back into base + LoRA.
            """
            if self._merged:
                delta_w = (self.lora_B @ self.lora_A) * self.scaling
                self.weight.data -= delta_w
                self._merged = False
                logger.debug("LoRA 가중치 분리 완료")

        def get_lora_state(self) -> Dict[str, np.ndarray]:
            """LoRA 가중치를 numpy로 반환 / Return LoRA weights as numpy."""
            return {
                "lora_A": self.lora_A.detach().cpu().numpy(),
                "lora_B": self.lora_B.detach().cpu().numpy(),
                "weight": self.weight.detach().cpu().numpy(),
            }

        def load_lora_state(self, state: Dict[str, np.ndarray]) -> None:
            """numpy에서 LoRA 가중치 로드 / Load LoRA weights from numpy."""
            self.lora_A.data = torch.tensor(state["lora_A"], dtype=torch.float32)
            self.lora_B.data = torch.tensor(state["lora_B"], dtype=torch.float32)
            self.weight.data = torch.tensor(state["weight"], dtype=torch.float32)

        def extra_repr(self) -> str:
            return (
                f"in_dim={self.in_dim}, out_dim={self.out_dim}, "
                f"rank={self.rank}, alpha={self.alpha}, merged={self._merged}"
            )


# ─── Numpy 폴백 LoRA 레이어 / Numpy Fallback LoRA Layer ─────────────────────

class NumpyLoRALayer:
    """
    Numpy 기반 LoRA 레이어 (torch 미사용 환경) / Numpy-based LoRA layer (torch-free).

    torch를 사용할 수 없는 환경에서 LoRA 연산을 수행합니다.
    PyTorch LoRALayer와 동일한 인터페이스를 제공합니다.
    """

    def __init__(
        self,
        in_dim: int,
        out_dim: int,
        rank: int = DEFAULT_LORA_RANK,
        alpha: float = DEFAULT_LORA_ALPHA,
    ) -> None:
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank
        self._merged = False

        # 기반 가중치 / Base weight
        self.weight = np.random.randn(out_dim, in_dim).astype(np.float32) * 0.02
        # LoRA 행렬 / LoRA matrices
        self.lora_A = np.random.randn(rank, in_dim).astype(np.float32) * 0.01
        self.lora_B = np.zeros((out_dim, rank), dtype=np.float32)

    def forward(self, x: np.ndarray) -> np.ndarray:
        """순전파 / Forward pass."""
        if self._merged:
            return x @ self.weight.T
        else:
            base_out = x @ self.weight.T
            lora_out = (x @ self.lora_A.T @ self.lora_B.T) * self.scaling
            return base_out + lora_out

    def merge(self) -> None:
        """LoRA 가중치 병합 / Merge LoRA weights."""
        if not self._merged:
            delta_w = (self.lora_B @ self.lora_A) * self.scaling
            self.weight += delta_w
            self._merged = True

    def unmerge(self) -> None:
        """LoRA 가중치 분리 / Unmerge LoRA weights."""
        if self._merged:
            delta_w = (self.lora_B @ self.lora_A) * self.scaling
            self.weight -= delta_w
            self._merged = False

    def get_lora_state(self) -> Dict[str, np.ndarray]:
        """상태 반환 / Return state."""
        return {
            "lora_A": self.lora_A.copy(),
            "lora_B": self.lora_B.copy(),
            "weight": self.weight.copy(),
        }

    def load_lora_state(self, state: Dict[str, np.ndarray]) -> None:
        """상태 로드 / Load state."""
        self.lora_A = state["lora_A"].copy()
        self.lora_B = state["lora_B"].copy()
        self.weight = state["weight"].copy()


# ─── 스킬 LoRA 관리자 / Skill LoRA Manager ──────────────────────────────────


@dataclass
class AdapterInfo:
    """
    어댑터 정보 / Adapter information.
    """
    adapter_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    skill_category: str = ""
    rank: int = DEFAULT_LORA_RANK
    alpha: float = DEFAULT_LORA_ALPHA
    layers: Dict[str, Any] = field(default_factory=dict)  # name -> layer
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    training_steps: int = 0
    active: bool = False


class SkillLoRAManager:
    """
    스킬 카테고리별 LoRA 어댑터 관리자 / Per-skill-category LoRA adapter manager.

    각 스킬 카테고리에 대해 독립적인 LoRA 어댑터를 관리합니다.
    어댑터 전환, 병합, 저장/로드를 지원합니다.

    Usage:
        manager = SkillLoRAManager()
        manager.add_adapter("locomotion", base_model=None, rank=8)
        manager.activate_adapter("locomotion")
        # ... 학습 ...
        manager.merge_adapters()
        manager.save_adapters("/path/to/adapters")
    """

    def __init__(
        self,
        in_dim: int = STATE_DIM,
        hidden_dim: int = HIDDEN_DIM,
        out_dim: int = 32,
    ) -> None:
        self._in_dim = in_dim
        self._hidden_dim = hidden_dim
        self._out_dim = out_dim

        self._adapters: Dict[str, AdapterInfo] = {}
        self._active_category: Optional[str] = None
        self._lock = threading.Lock()

        # torch 가용성에 따른 레이어 팩토리 / Layer factory based on torch availability
        self._use_torch = TORCH_AVAILABLE
        if self._use_torch:
            logger.info("SkillLoRAManager: PyTorch LoRA 모드")
        else:
            logger.info("SkillLoRAManager: Numpy LoRA 폴백 모드")

    def _create_lora_layer(
        self, in_dim: int, out_dim: int, rank: int, alpha: float
    ) -> Union["LoRALayer", NumpyLoRALayer]:
        """LoRA 레이어 생성 / Create LoRA layer (torch or numpy)."""
        if self._use_torch and TORCH_AVAILABLE:
            return LoRALayer(in_dim, out_dim, rank=rank, alpha=alpha)
        return NumpyLoRALayer(in_dim, out_dim, rank=rank, alpha=alpha)

    def add_adapter(
        self,
        skill_category: str,
        base_model: Any = None,
        rank: int = DEFAULT_LORA_RANK,
        alpha: float = DEFAULT_LORA_ALPHA,
    ) -> AdapterInfo:
        """
        스킬 카테고리에 LoRA 어댑터 추가 / Add LoRA adapter for skill category.

        기반 모델이 제공되면 해당 모델의 레이어에 LoRA를 주입합니다.
        기반 모델이 없으면 독립적인 LoRA 레이어 세트를 생성합니다.

        Args:
            skill_category: 스킬 카테고리명
            base_model: 기반 모델 (선택)
            rank: LoRA 랭크
            alpha: LoRA 스케일링 factor

        Returns:
            AdapterInfo: 생성된 어댑터 정보
        """
        if skill_category in self._adapters:
            logger.warning(
                "어댑터 이미 존재: %s → 기존 어댑터 반환", skill_category
            )
            return self._adapters[skill_category]

        adapter = AdapterInfo(
            skill_category=skill_category,
            rank=rank,
            alpha=alpha,
        )

        if base_model is not None and self._use_torch and TORCH_AVAILABLE:
            # 기반 모델의 Linear 레이어에 LoRA 주입 / Inject LoRA into base model's Linear layers
            self._inject_lora_into_model(adapter, base_model, rank, alpha)
        else:
            # 독립 LoRA 레이어 세트 생성 / Create standalone LoRA layer set
            adapter.layers = {
                "layer_0": self._create_lora_layer(self._in_dim, self._hidden_dim, rank, alpha),
                "layer_1": self._create_lora_layer(self._hidden_dim, self._hidden_dim, rank, alpha),
                "layer_2": self._create_lora_layer(self._hidden_dim, self._out_dim, rank, alpha),
            }

        with self._lock:
            self._adapters[skill_category] = adapter

        logger.info(
            "LoRA 어댑터 추가: 카테고리=%s, rank=%d, alpha=%.1f, 레이어=%d",
            skill_category, rank, alpha, len(adapter.layers),
        )
        return adapter

    def _inject_lora_into_model(
        self, adapter: AdapterInfo, model: Any, rank: int, alpha: float
    ) -> None:
        """
        기반 모델에 LoRA 레이어 주입 / Inject LoRA layers into base model.

        torch.nn.Module의 Linear 레이어를 LoRALayer로 교체합니다.

        Args:
            adapter: 어댑터 정보
            model: 기반 torch 모델
            rank: LoRA 랭크
            alpha: LoRA 알파
        """
        if not TORCH_AVAILABLE or not isinstance(model, nn.Module):
            return

        for name, module in list(model.named_modules()):
            if isinstance(module, nn.Linear) and not name.endswith(".weight"):
                lora = LoRALayer(
                    module.in_features, module.out_features,
                    rank=rank, alpha=alpha,
                )
                # 기반 가중치 복사 / Copy base weights
                lora.weight.data = module.weight.data.clone()
                adapter.layers[name] = lora

    def activate_adapter(self, skill_category: str) -> bool:
        """
        특정 스킬 카테고리의 어댑터 활성화 / Activate adapter for skill category.

        이전 활성 어댑터는 비활성화됩니다.

        Args:
            skill_category: 활성화할 스킬 카테고리

        Returns:
            bool: 활성화 성공 여부
        """
        with self._lock:
            if skill_category not in self._adapters:
                logger.error("어댑터 없음: %s", skill_category)
                return False

            # 이전 어댑터 비활성화 / Deactivate previous
            if self._active_category and self._active_category in self._adapters:
                self._adapters[self._active_category].active = False

            # 새 어댑터 활성화 / Activate new
            self._adapters[skill_category].active = True
            self._active_category = skill_category

        logger.info("어댑터 활성화: %s", skill_category)
        return True

    def get_active_adapter(self) -> Optional[AdapterInfo]:
        """현재 활성 어댑터 반환 / Return currently active adapter."""
        with self._lock:
            if self._active_category and self._active_category in self._adapters:
                return self._adapters[self._active_category]
        return None

    def forward(self, x: Union[np.ndarray, Any]) -> Union[np.ndarray, Any]:
        """
        활성 어댑터로 순전파 수행 / Forward pass through active adapter.

        numpy 입력은 자동으로 torch 텐서로 변환 후 다시 numpy로 반환합니다.

        Args:
            x: 입력 데이터 (numpy 배열 또는 torch 텐서)

        Returns:
            출력 데이터 (입력과 동일한 타입)
        """
        adapter = self.get_active_adapter()
        if adapter is None:
            logger.warning("활성 어댑터 없음 → 입력 그대로 반환")
            return x

        # numpy → torch 변환 여부 추적 / Track whether we need numpy conversion
        was_numpy = isinstance(x, np.ndarray)
        h = x

        if was_numpy and self._use_torch and TORCH_AVAILABLE:
            # 어댑터 레이어가 LoRALayer(torch)인지 확인 / Check if layers are torch LoRALayer
            first_layer = next(iter(adapter.layers.values()))
            if isinstance(first_layer, nn.Module):
                h = torch.tensor(x, dtype=torch.float32)

        for layer_name in sorted(adapter.layers.keys()):
            layer = adapter.layers[layer_name]
            h = layer.forward(h)

        # torch → numpy 변환 / Convert back to numpy if input was numpy
        if was_numpy and TORCH_AVAILABLE and isinstance(h, torch.Tensor):
            h = h.detach().cpu().numpy()

        return h

    def merge_adapters(self) -> Optional[AdapterInfo]:
        """
        활성 어댑터의 LoRA 가중치를 기반 모델에 병합 / Merge active adapter's LoRA weights.

        병합 후에는 추론 시 추가 연산이 필요 없습니다.
        학습을 계속하려면 unmerge()를 호출하세요.

        Returns:
            AdapterInfo: 병합된 어댑터 정보
        """
        adapter = self.get_active_adapter()
        if adapter is None:
            logger.warning("병합할 활성 어댑터 없음")
            return None

        for name, layer in adapter.layers.items():
            layer.merge()

        logger.info(
            "어댑터 병합 완료: %s (%d 레이어)",
            adapter.skill_category, len(adapter.layers),
        )
        return adapter

    def unmerge_active(self) -> None:
        """활성 어댑터의 병합 해제 / Unmerge active adapter."""
        adapter = self.get_active_adapter()
        if adapter is None:
            return

        for name, layer in adapter.layers.items():
            layer.unmerge()

        logger.info("어댑터 병합 해제: %s", adapter.skill_category)

    def save_adapters(self, path: Union[str, Path]) -> bool:
        """
        모든 어댑터를 디렉토리에 저장 / Save all adapters to directory.

        각 어댑터는 별도의 .npz 파일로 저장됩니다.

        Args:
            path: 저장 디렉토리 경로

        Returns:
            bool: 저장 성공 여부
        """
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)

        try:
            with self._lock:
                for category, adapter in self._adapters.items():
                    all_weights = {}
                    for layer_name, layer in adapter.layers.items():
                        state = layer.get_lora_state()
                        for key, arr in state.items():
                            all_weights[f"{layer_name}_{key}"] = arr

                    # 메타데이터 저장 / Save metadata
                    metadata = {
                        "adapter_id": adapter.adapter_id,
                        "skill_category": adapter.skill_category,
                        "rank": adapter.rank,
                        "alpha": adapter.alpha,
                        "training_steps": adapter.training_steps,
                        "created_at": adapter.created_at,
                    }

                    np.savez_compressed(
                        save_dir / f"{category}.npz",
                        **all_weights,
                        metadata=json.dumps(metadata),
                    )

            logger.info(
                "어댑터 저장 완료: %s (%d개)",
                save_dir, len(self._adapters),
            )
            return True
        except Exception as e:
            logger.error("어댑터 저장 실패: %s", e)
            return False

    def load_adapters(self, path: Union[str, Path]) -> int:
        """
        디렉토리에서 어댑터 로드 / Load adapters from directory.

        Args:
            path: 로드할 디렉토리 경로

        Returns:
            int: 로드된 어댑터 수
        """
        load_dir = Path(path)
        if not load_dir.exists():
            logger.error("로드 경로 없음: %s", load_dir)
            return 0

        loaded = 0
        try:
            for npz_file in sorted(load_dir.glob("*.npz")):
                category = npz_file.stem
                data = np.load(str(npz_file), allow_pickle=True)

                # 메타데이터 로드 / Load metadata
                metadata = json.loads(str(data.get("metadata", "{}")))

                # 어댑터 생성 / Create adapter
                adapter = self.add_adapter(
                    skill_category=category,
                    rank=int(metadata.get("rank", DEFAULT_LORA_RANK)),
                    alpha=float(metadata.get("alpha", DEFAULT_LORA_ALPHA)),
                )
                adapter.adapter_id = metadata.get("adapter_id", adapter.adapter_id)
                adapter.training_steps = int(metadata.get("training_steps", 0))
                adapter.created_at = metadata.get("created_at", adapter.created_at)

                # 가중치 로드 / Load weights
                for layer_name in adapter.layers:
                    layer = adapter.layers[layer_name]
                    state = {}
                    for key in ["lora_A", "lora_B", "weight"]:
                        arr_key = f"{layer_name}_{key}"
                        if arr_key in data:
                            state[key] = data[arr_key]
                    if state:
                        layer.load_lora_state(state)

                loaded += 1

        except Exception as e:
            logger.error("어댑터 로드 실패: %s", e)

        logger.info("어댑터 로드 완료: %d개", loaded)
        return loaded

    def get_stats(self) -> Dict[str, Any]:
        """관리자 통계 / Return manager statistics."""
        with self._lock:
            return {
                "total_adapters": len(self._adapters),
                "categories": list(self._adapters.keys()),
                "active_category": self._active_category,
                "use_torch": self._use_torch,
                "total_training_steps": sum(
                    a.training_steps for a in self._adapters.values()
                ),
            }


# ─── EWC 정규화기 / EWC Regularizer ─────────────────────────────────────────


@dataclass
class EWCSkillState:
    """
    EWC 스킬 상태 / EWC skill state for a single learned skill.

    스킬 학습 완료 후 Fisher 정보 행렬과 최적 파라미터를 저장하여
    새로운 스킬 학습 시 기존 스킬의 파라미터가 크게 변하지 않도록 합니다.
    """
    skill_category: str = ""
    fisher_diagonal: Dict[str, np.ndarray] = field(default_factory=dict)
    optimal_params: Dict[str, np.ndarray] = field(default_factory=dict)
    sample_count: int = 0
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class EWCRegularizer:
    """
    Elastic Weight Consolidation 정규화기 / EWC Regularizer.

    치명적 망각(catastrophic forgetting)을 방지하기 위해
    이전에 학습한 스킬의 중요 파라미터를 보존합니다.

    EWC 손실 = Σ_i F_i * (θ_i - θ*_i)²

    F_i: Fisher 정보 행렬의 대각 성분 (파라미터 중요도)
    θ*_i: 이전 스킬의 최적 파라미터

    Usage:
        ewc = EWCRegularizer()
        # 스킬 A 학습 완료 후:
        ewc.compute_fisher_information(dataloader, model, skill_category="locomotion")
        # 스킬 B 학습 시:
        penalty = ewc.ewc_penalty(current_params)
        loss = task_loss + ewc_lambda * penalty
    """

    def __init__(self, ewc_lambda: float = 5000.0) -> None:
        """
        EWC 정규화기 초기화 / Initialize EWC regularizer.

        Args:
            ewc_lambda: EWC 정규화 강도 / EWC regularization strength
        """
        self.ewc_lambda = ewc_lambda
        self._skill_states: Dict[str, EWCSkillState] = {}
        self._lock = threading.Lock()

        logger.info(
            "EWCRegularizer 초기화: lambda=%.1f", ewc_lambda
        )

    def compute_fisher_information(
        self,
        dataloader: Any,
        model: Any = None,
        skill_category: str = "",
        n_samples: int = 200,
    ) -> Dict[str, np.ndarray]:
        """
        Fisher 정보 행렬 계산 / Compute Fisher information matrix.

        데이터셋에 대해 모델 파라미터의 기울기 제곱 평균을 계산합니다.
        이는 각 파라미터가 현재 스킬에 얼마나 중요한지를 나타냅니다.

        Args:
            dataloader: 데이터 로더 (torch DataLoader 또는 리스트)
            model: 모델 (torch 모델 또는 None)
            skill_category: 스킬 카테고리명
            n_samples: Fisher 계산에 사용할 샘플 수

        Returns:
            Dict[str, np.ndarray]: 파라미터명 → Fisher 대각 성분
        """
        fisher: Dict[str, np.ndarray] = {}
        optimal_params: Dict[str, np.ndarray] = {}
        sample_count = 0

        if TORCH_AVAILABLE and model is not None and isinstance(model, nn.Module):
            # PyTorch 모델: 실제 기울기 계산 / PyTorch model: actual gradient computation
            fisher, optimal_params, sample_count = self._compute_torch_fisher(
                dataloader, model, n_samples
            )
        else:
            # Numpy 폴백: 경험적 Fisher 추정 / Numpy fallback: empirical Fisher estimation
            fisher, optimal_params, sample_count = self._compute_numpy_fisher(
                dataloader, n_samples
            )

        # 스킬 상태 저장 / Save skill state
        skill_state = EWCSkillState(
            skill_category=skill_category,
            fisher_diagonal=fisher,
            optimal_params=optimal_params,
            sample_count=sample_count,
        )

        with self._lock:
            self._skill_states[skill_category] = skill_state

        logger.info(
            "Fisher 정보 계산 완료: %s (%d 파라미터, %d 샘플)",
            skill_category, len(fisher), sample_count,
        )

        return fisher

    def _compute_torch_fisher(
        self, dataloader: Any, model: nn.Module, n_samples: int
    ) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray], int]:
        """
        PyTorch 모델에 대한 Fisher 정보 계산 / Compute Fisher for PyTorch model.

        Args:
            dataloader: 데이터 로더
            model: PyTorch 모델
            n_samples: 최대 샘플 수

        Returns:
            (fisher_diagonal, optimal_params, sample_count)
        """
        fisher: Dict[str, np.ndarray] = {}
        optimal_params: Dict[str, np.ndarray] = {}
        sample_count = 0

        # 최적 파라미터 저장 / Store optimal parameters
        for name, param in model.named_parameters():
            if param.requires_grad:
                optimal_params[name] = param.data.detach().cpu().numpy().copy()
                fisher[name] = np.zeros_like(optimal_params[name])

        # 기울기 누적 / Accumulate gradients
        model.eval()
        for batch_idx, batch in enumerate(dataloader):
            if sample_count >= n_samples:
                break

            try:
                if isinstance(batch, (list, tuple)):
                    inputs = batch[0]
                    targets = batch[1] if len(batch) > 1 else None
                elif isinstance(batch, dict):
                    inputs = batch.get("state", batch.get("input"))
                    targets = batch.get("action", batch.get("target"))
                else:
                    inputs = batch
                    targets = None

                model.zero_grad()
                outputs = model(inputs)
                if targets is not None:
                    loss = F.mse_loss(outputs, targets)
                else:
                    loss = outputs.sum()
                loss.backward()

                for name, param in model.named_parameters():
                    if param.requires_grad and param.grad is not None:
                        fisher[name] += param.grad.detach().cpu().numpy() ** 2

                sample_count += 1
            except Exception as e:
                logger.warning("Fisher 계산 배치 오류: %s", e)
                continue

        # 평균 / Average
        if sample_count > 0:
            for name in fisher:
                fisher[name] /= sample_count

        return fisher, optimal_params, sample_count

    def _compute_numpy_fisher(
        self, dataloader: Any, n_samples: int
    ) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray], int]:
        """
        Numpy 기반 Fisher 정보 추정 / Numpy-based Fisher estimation.

        torch를 사용할 수 없는 환경에서 대략적인 Fisher 정보를 추정합니다.

        Args:
            dataloader: 데이터 리스트
            n_samples: 최대 샘플 수

        Returns:
            (fisher_diagonal, optimal_params, sample_count)
        """
        fisher: Dict[str, np.ndarray] = {}
        optimal_params: Dict[str, np.ndarray] = {}
        sample_count = 0

        if isinstance(dataloader, list):
            for batch in dataloader[:n_samples]:
                if isinstance(batch, dict):
                    params = batch.get("params", {})
                    for name, val in params.items():
                        arr = np.asarray(val, dtype=np.float64)
                        if name not in fisher:
                            fisher[name] = np.zeros_like(arr)
                            optimal_params[name] = arr.copy()
                        fisher[name] += arr ** 2
                    sample_count += 1

        if sample_count > 0:
            for name in fisher:
                fisher[name] /= sample_count

        return fisher, optimal_params, sample_count

    def ewc_penalty(
        self,
        current_params: Optional[Dict[str, np.ndarray]] = None,
        model: Any = None,
    ) -> float:
        """
        EWC 벌점 계산 / Compute EWC penalty.

        EWC penalty = Σ_skills Σ_params F_i * (θ_i - θ*_i)²

        현재 파라미터가 이전 스킬의 최적 파라미터에서
        얼마나 벗어났는지를 Fisher 정보로 가중하여 계산합니다.

        Args:
            current_params: 현재 파라미터 (numpy 딕셔너리)
            model: 현재 PyTorch 모델 (current_params 대신 사용 가능)

        Returns:
            float: EWC 벌점 값
        """
        penalty = 0.0

        # 현재 파라미터 획득 / Get current parameters
        if current_params is None and model is not None and TORCH_AVAILABLE:
            if isinstance(model, nn.Module):
                current_params = {
                    name: param.data.detach().cpu().numpy()
                    for name, param in model.named_parameters()
                    if param.requires_grad
                }

        if current_params is None:
            return 0.0

        with self._lock:
            for skill_state in self._skill_states.values():
                for param_name, fisher_val in skill_state.fisher_diagonal.items():
                    if param_name not in current_params:
                        continue
                    optimal = skill_state.optimal_params.get(param_name)
                    if optimal is None:
                        continue

                    current = np.asarray(current_params[param_name], dtype=np.float64)
                    diff = current - optimal.astype(np.float64)
                    penalty += float(np.sum(fisher_val * diff ** 2))

        return penalty * self.ewc_lambda

    def get_skill_count(self) -> int:
        """보호 중인 스킬 수 / Number of protected skills."""
        with self._lock:
            return len(self._skill_states)

    def get_stats(self) -> Dict[str, Any]:
        """EWC 통계 / Return EWC statistics."""
        with self._lock:
            return {
                "ewc_lambda": self.ewc_lambda,
                "protected_skills": list(self._skill_states.keys()),
                "total_fisher_params": sum(
                    sum(f.size for f in s.fisher_diagonal.values())
                    for s in self._skill_states.values()
                ),
            }


# ─── 모듈 진입점 / Module Entry Point ───────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)

    print("=" * 60)
    print("LoRA 어댑터 시스템 테스트 / LoRA Adapter System Test")
    print("=" * 60)
    print(f"PyTorch 사용 가능: {TORCH_AVAILABLE}")

    # 관리자 생성 / Create manager
    manager = SkillLoRAManager(in_dim=STATE_DIM, hidden_dim=HIDDEN_DIM, out_dim=32)

    # 어댑터 추가 / Add adapters
    for cat in ["locomotion", "gripping", "manipulation"]:
        manager.add_adapter(cat, rank=8)

    # 활성화 / Activate
    manager.activate_adapter("locomotion")

    # 순전파 테스트 / Forward pass test
    if TORCH_AVAILABLE:
        test_input = torch.randn(4, STATE_DIM)
    else:
        test_input = np.random.randn(4, STATE_DIM).astype(np.float32)

    output = manager.forward(test_input)
    print(f"\n순전파 결과: shape={output.shape if hasattr(output, 'shape') else 'N/A'}")

    # 병합 테스트 / Merge test
    manager.merge_adapters()
    output_merged = manager.forward(test_input)
    print(f"병합 후 순전파: shape={output_merged.shape if hasattr(output_merged, 'shape') else 'N/A'}")

    # 저장/로드 테스트 / Save/Load test
    save_path = "/tmp/lora_test_adapters"
    manager.save_adapters(save_path)

    manager2 = SkillLoRAManager(in_dim=STATE_DIM, hidden_dim=HIDDEN_DIM, out_dim=32)
    n_loaded = manager2.load_adapters(save_path)
    print(f"로드된 어댑터: {n_loaded}")

    # EWC 테스트 / EWC test
    print("\nEWC 정규화기 테스트 / EWC Regularizer Test")
    ewc = EWCRegularizer(ewc_lambda=1000.0)

    # 가상 데이터로 Fisher 계산 / Compute Fisher with dummy data
    dummy_data = [
        {"params": {
            "layer_0_weight": np.random.randn(256, 62) * 0.01,
            "layer_1_weight": np.random.randn(256, 256) * 0.01,
        }}
        for _ in range(50)
    ]

    fisher = ewc.compute_fisher_information(
        dummy_data, skill_category="locomotion", n_samples=50
    )
    print(f"Fisher 정보: {len(fisher)}개 파라미터")

    penalty = ewc.ewc_penalty(current_params={
        "layer_0_weight": np.random.randn(256, 62) * 0.02,
        "layer_1_weight": np.random.randn(256, 256) * 0.02,
    })
    print(f"EWC 벌점: {penalty:.2f}")
    print(f"EWC 통계: {ewc.get_stats()}")
    print(f"관리자 통계: {manager.get_stats()}")
    print("\n모든 테스트 완료 / All tests completed.")
