#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 텔레스코핑 다리 컨트롤러 (Telescoping Leg Controller)
====================================================================

3단 카본 파이프 (Ø30/26/22mm) + GT2 벨트 + 2806 BLDC 600KV ×2
스트로크: 0mm(완전 수축) ~ 1500mm(완전 신장), 1500mm 유효 이동
일정힘 스프링 15N, 무전력 시 자동 수축 (안전 장치)

V8.5 변경사항 / V8.5 Changes from V8.5:
  - 다리 위치 검증 (Leg position verification)
  - 벨트 장력 모니터링 (Belt tension monitoring)
  - 핀 디텐트 확인 (Pin detent confirmation)
  - 무전력 시 긴급 수축 — 재생 제동 (Emergency retract on power loss, PDF #25: regeneration)
  - 일정힘 스프링 건전성 (Constant-force spring health)

카본 ID: 26.5/22.5mm (V8.5: Fusion360 leg_module.py와 일치)
GT2 벨트 장력 조절 슬롯 포함
핀 디텐트 50mm 간격 (Fusion360 모델과 일치)

이중 제어 경로:
  - SimpleFOC Mini (I2C 0x14, 0x15): 승강 모터 직접 제어
  - MKS XDRIVE Mini (CAN 0x203, 0x204): 승강 관절 CAN 제어

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("JihunRobot.V84.TelescopingLeg")


# ============================================================================
# 상수 및 열거형
# ============================================================================

class LegSide(Enum):
    LEFT = "left"
    RIGHT = "right"


class LegState(Enum):
    RETRACTED = "retracted"
    EXTENDING = "extending"
    EXTENDED = "extended"
    RETRACTING = "retracting"
    HOLDING = "holding"
    FAULT = "fault"
    EMERGENCY_RETRACT = "emergency_retract"


# 물리 파라미터 (Fusion360 leg_module.py와 일치)
MIN_HEIGHT_MM = 0.0         # 완전 수축 (Fusion360: MIN_HEIGHT = 0.0)
MAX_HEIGHT_MM = 1500.0      # 완전 신장 1.5m (Fusion360: MAX_HEIGHT = 1500.0)
STROKE_MM = 1500.0          # 유효 이동 거리
SPRING_FORCE_N = 15.0       # 일정힘 스프링 (Fusion360: SPRING_FORCE = 15.0N)
CARBON_ID_MM = [26.5, 22.5] # 카본 파이프 내경 (Fusion360: STAGE1_ID/STAGE2_ID)
CARBON_OD_MM = [30.0, 26.0, 22.0]  # 카본 파이프 외경 (3단)
BELT_PITCH_MM = 2.0         # GT2 벨트 피치
PULLEY_TEETH = 20           # GT2 풀리 이빨 수
GEAR_RATIO = 5.0            # 기어비
MOTOR_KV = 600              # 2806 BLDC 모터 KV
MAX_EXTEND_SPEED_MMPS = 200.0  # 최대 신장 속도 (1.5m 스트로크에 맞게 증가)
PITCH_RANGE_DEG = (-45.0, 45.0) # 다리 피치 각도 범위

# I2C/CAN 주소
SIMPLEFOC_I2C_ADDRESSES: Dict[LegSide, int] = {
    LegSide.LEFT: 0x14,
    LegSide.RIGHT: 0x15,
}

XDRIVE_CAN_IDS: Dict[LegSide, int] = {
    LegSide.LEFT: 0x203,
    LegSide.RIGHT: 0x204,
}

CONTINUOUS_CURRENT_A = 8.0
PEAK_CURRENT_A = 15.0
STALL_TIMEOUT_MS = 500

# V8.5: 위치 검증 상수
POSITION_VERIFY_TOLERANCE_MM = 2.0     # 위치 검증 허용 오차 (mm)
POSITION_VERIFY_DELAY_MS = 100          # 검증 대기 시간 (ms)
POSITION_VERIFY_MAX_RETRIES = 3         # 검증 재시도 횟수

# V8.5: 벨트 장력 모니터링 상수
BELT_TENSION_NOMINAL_N = 15.0          # 정상 벨트 장력 (N)
BELT_TENSION_MIN_N = 8.0               # 최소 장력 (느슨함)
BELT_TENSION_MAX_N = 25.0              # 최대 장력 (너무 팽팽함)
BELT_TENSION_WARNING_PCT = 20.0        # 장력 편차 경고 (%)
BELT_TENSION_CRITICAL_PCT = 40.0       # 장력 편차 위험 (%)

# V8.5: 핀 디텐트 상수
PIN_DETENT_POSITIONS_MM = [0.0, 50.0, 100.0, 150.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0, 650.0, 700.0, 750.0, 800.0, 850.0, 900.0, 950.0, 1000.0, 1050.0, 1100.0, 1150.0, 1200.0, 1250.0, 1300.0, 1350.0, 1400.0, 1450.0, 1500.0]  # 핀 고정 위치 (50mm 간격, Fusion360: DETENT_SPACING = 50.0)
PIN_DETENT_TOLERANCE_MM = 3.0                      # 핀 위치 허용차
PIN_DETENT_FORCE_N = 5.0                           # 핀 체결 확인력

# V8.5: 재생 제동 상수 (PDF #25)
REGEN_VOLTAGE_THRESHOLD_V = 24.0       # 재생 제동 활성 전압
REGEN_MAX_CURRENT_A = 5.0              # 재생 제동 최대 전류
REGEN_SLOWDOWN_FACTOR = 0.7            # 재생 제동 감속 비율

# V8.5: 스프링 건전성 상수
SPRING_FORCE_NOMINAL_N = 15.0          # 정상 스프링 힘 (N) (Fusion360: 15N)
SPRING_FORCE_MIN_N = 9.0               # 최소 허용 힘 (피로 한계)
SPRING_FORCE_MAX_N = 21.0              # 최대 허용 힘
SPRING_FATIGUE_WARNING_PCT = 20.0      # 피로 경고 편차 (%)
SPRING_CYCLE_LIFE = 100000             # 설계 수명 (사이클)


# ============================================================================
# V8.5 데이터 클래스
# ============================================================================

@dataclass
class LegConfig:
    """다리 하드웨어 설정"""
    min_height_mm: float = MIN_HEIGHT_MM
    max_height_mm: float = MAX_HEIGHT_MM
    stroke_mm: float = STROKE_MM
    spring_force_n: float = SPRING_FORCE_N
    carbon_id_mm: list = field(default_factory=lambda: CARBON_ID_MM.copy())
    belt_pitch_mm: float = BELT_PITCH_MM
    pulley_teeth: int = PULLEY_TEETH
    gear_ratio: float = GEAR_RATIO
    motor_kv: int = MOTOR_KV
    max_extend_speed_mmps: float = MAX_EXTEND_SPEED_MMPS
    auto_retract_on_power_loss: bool = True


@dataclass
class LegStatus:
    """다리 상태 데이터"""
    side: LegSide
    state: LegState = LegState.RETRACTED
    current_height_mm: float = MIN_HEIGHT_MM
    target_height_mm: float = MIN_HEIGHT_MM
    current_speed_mmps: float = 0.0
    motor_current_a: float = 0.0
    position_error_mm: float = 0.0
    is_stalled: bool = False
    last_update_s: float = 0.0


@dataclass
class PositionVerification:
    """V8.5: 위치 검증 결과"""
    side: LegSide = LegSide.LEFT
    target_mm: float = 0.0
    actual_mm: float = 0.0
    error_mm: float = 0.0
    is_verified: bool = False
    retry_count: int = 0
    timestamp: float = 0.0


@dataclass
class BeltTensionData:
    """V8.5: 벨트 장력 데이터"""
    side: LegSide = LegSide.LEFT
    estimated_tension_n: float = BELT_TENSION_NOMINAL_N
    is_nominal: bool = True
    is_loose: bool = False
    is_overtight: bool = False
    deviation_pct: float = 0.0
    last_check_time: float = 0.0


@dataclass
class PinDetentData:
    """V8.5: 핀 디텐트 데이터"""
    side: LegSide = LegSide.LEFT
    is_engaged: bool = False
    nearest_position_mm: float = 0.0
    distance_to_nearest_mm: float = 0.0
    is_confirmed: bool = False


@dataclass
class RegenBrakingData:
    """V8.5: 재생 제동 데이터 (PDF #25)"""
    side: LegSide = LegSide.LEFT
    is_active: bool = False
    regen_current_a: float = 0.0
    energy_recovered_j: float = 0.0
    total_energy_recovered_j: float = 0.0


@dataclass
class SpringHealthData:
    """V8.5: 일정힘 스프링 건전성 데이터"""
    side: LegSide = LegSide.LEFT
    estimated_force_n: float = SPRING_FORCE_NOMINAL_N
    is_healthy: bool = True
    fatigue_pct: float = 0.0
    cycle_count: int = 0
    needs_replacement: bool = False


# ============================================================================
# 텔레스코핑 다리 컨트롤러 V8.5
# ============================================================================

class TelescopingLegController:
    """
    텔레스코핑 다리 컨트롤러 V8.5

    V8.5 신규 기능:
    - 다리 위치 검증: 명령 후 실제 위치 확인
    - 벨트 장력 모니터링: 전류 기반 간접 추정
    - 핀 디텐트 확인: 고정 위치에서 핀 체결 검증
    - 무전력 긴급 수축 + 재생 제동 (PDF #25)
    - 일정힘 스프링 건전성: 피로도 추적
    """

    def __init__(
        self,
        config: Optional[LegConfig] = None,
        simplefoc_controller: Optional[object] = None,
        xdrive_controller: Optional[object] = None,
        pid_controller: Optional[object] = None,
    ) -> None:
        self._config = config or LegConfig()
        self._simplefoc = simplefoc_controller
        self._xdrive = xdrive_controller
        self._pid = pid_controller

        # 다리 상태 초기화
        self._legs: Dict[LegSide, LegStatus] = {
            LegSide.LEFT: LegStatus(side=LegSide.LEFT),
            LegSide.RIGHT: LegStatus(side=LegSide.RIGHT),
        }

        # 스톨 감지용 변수
        self._last_height: Dict[LegSide, float] = {
            LegSide.LEFT: MIN_HEIGHT_MM,
            LegSide.RIGHT: MIN_HEIGHT_MM,
        }
        self._stall_start_time: Dict[LegSide, Optional[float]] = {
            LegSide.LEFT: None,
            LegSide.RIGHT: None,
        }

        # 높이→엔코더 변환 상수
        self._mm_to_rad = 2.0 * math.pi / (self._config.belt_pitch_mm * self._config.pulley_teeth)
        self._rad_to_mm = 1.0 / self._mm_to_rad

        # V8.5: 위치 검증 데이터
        self._position_verify: Dict[LegSide, PositionVerification] = {
            s: PositionVerification(side=s) for s in LegSide
        }

        # V8.5: 벨트 장력 데이터
        self._belt_tension: Dict[LegSide, BeltTensionData] = {
            s: BeltTensionData(side=s) for s in LegSide
        }

        # V8.5: 핀 디텐트 데이터
        self._pin_detent: Dict[LegSide, PinDetentData] = {
            s: PinDetentData(side=s) for s in LegSide
        }

        # V8.5: 재생 제동 데이터
        self._regen_data: Dict[LegSide, RegenBrakingData] = {
            s: RegenBrakingData(side=s) for s in LegSide
        }

        # V8.5: 스프링 건전성 데이터
        self._spring_health: Dict[LegSide, SpringHealthData] = {
            s: SpringHealthData(side=s) for s in LegSide
        }

        logger.info(
            "텔레스코핑 다리 V8.5 컨트롤러 초기화 — "
            "스트로크: %.0f~%.0fmm, 스프링: %.0fN, "
            "카본 ID: %s",
            self._config.min_height_mm, self._config.max_height_mm,
            self._config.spring_force_n,
            str(self._config.carbon_id_mm),
        )

    # ========================================================================
    # 공개 메서드 — 이동 명령
    # ========================================================================

    def extend(self, side: LegSide, speed_mmps: float = 50.0) -> None:
        speed_mmps = min(abs(speed_mmps), self._config.max_extend_speed_mmps)
        target = self._config.max_height_mm
        self._set_height_target(side, target, speed_mmps)
        self._update_leg_state(side, LegState.EXTENDING)
        logger.info("다리 신장 — %s: 속도 %.1f mm/s", side.value, speed_mmps)

    def retract(self, side: LegSide, speed_mmps: float = 50.0) -> None:
        speed_mmps = min(abs(speed_mmps), self._config.max_extend_speed_mmps)
        target = self._config.min_height_mm
        self._set_height_target(side, target, speed_mmps)
        self._update_leg_state(side, LegState.RETRACTING)
        logger.info("다리 수축 — %s: 속도 %.1f mm/s", side.value, speed_mmps)

    def set_height(self, side: LegSide, height_mm: float) -> None:
        height_mm = max(
            self._config.min_height_mm,
            min(self._config.max_height_mm, height_mm),
        )
        self._set_height_target(side, height_mm)
        self._update_leg_state(
            side,
            LegState.EXTENDING if height_mm > self._legs[side].current_height_mm
            else LegState.RETRACTING,
        )
        logger.info("목표 높이 설정 — %s: %.1f mm", side.value, height_mm)

    def get_height(self, side: LegSide) -> float:
        return self._legs[side].current_height_mm

    def emergency_retract(self, side: Optional[LegSide] = None) -> None:
        """
        긴급 수축 — 무전력 시 스프링에 의한 자동 수축 + 능동 수축

        V8.5: 재생 제동을 활용한 긴급 수축 (PDF #25).
        모터를 발전기로 사용하여 운동 에너지를 회수하며
        제어된 감속으로 수축.
        """
        sides = [side] if side is not None else list(LegSide)

        for s in sides:
            self._update_leg_state(s, LegState.EMERGENCY_RETRACT)
            self._legs[s].target_height_mm = self._config.min_height_mm

            # V8.5: 재생 제동 활성화
            self._regen_data[s].is_active = True
            logger.info(
                "긴급 수축 + 재생 제동 활성 — %s (PDF #25: regeneration)",
                s.value,
            )

            # 능동 수축 명령 (재생 제동 속도로 제한)
            regen_speed = self._config.max_extend_speed_mmps * REGEN_SLOWDOWN_FACTOR
            self._send_position_command(s, self._config.min_height_mm)
            logger.warning("⚠️ 긴급 수축 — %s (스프링 10N + 재생제동 + 능동 수축)", s.value)

    # ========================================================================
    # 공개 메서드 — 제어 루프
    # ========================================================================

    def update(self, dt: float = 0.01) -> None:
        """제어 루프 업데이트 (100Hz 호출 권장)"""
        for side in LegSide:
            leg = self._legs[side]

            if leg.state in (LegState.FAULT, LegState.EMERGENCY_RETRACT):
                if leg.state == LegState.EMERGENCY_RETRACT:
                    self._handle_emergency_retract(side, dt)
                continue

            if leg.state in (LegState.EXTENDING, LegState.RETRACTING):
                self._run_pid_control(side, dt)
                self._check_stall(side, dt)

            elif leg.state == LegState.HOLDING:
                self._run_pid_control(side, dt)

            # 모터 전류 모니터링
            self._check_current_limit(side)

            # V8.5: 벨트 장력 갱신
            self._update_belt_tension(side)

            # V8.5: 스프링 건전성 갱신
            self._update_spring_health(side)

            # V8.5: 핀 디텐트 확인
            self._check_pin_detent(side)

            leg.last_update_s = time.monotonic()

    def get_status(self, side: LegSide) -> LegStatus:
        return self._legs[side]

    def get_all_status(self) -> Dict[LegSide, LegStatus]:
        return dict(self._legs)

    # ========================================================================
    # V8.5: 위치 검증
    # ========================================================================

    def verify_position(self, side: LegSide) -> PositionVerification:
        """
        V8.5: 다리 위치 검증 / Verify leg position.

        명령 위치와 실제 위치를 비교하여
        위치 제어가 올바르게 수행되었는지 확인.
        """
        leg = self._legs[side]
        verify = self._position_verify[side]

        verify.target_mm = leg.target_height_mm
        verify.actual_mm = leg.current_height_mm
        verify.error_mm = abs(verify.target_mm - verify.actual_mm)
        verify.is_verified = verify.error_mm <= POSITION_VERIFY_TOLERANCE_MM
        verify.timestamp = time.monotonic()

        if not verify.is_verified:
            logger.warning(
                "위치 검증 실패 — %s: 오차=%.1fmm (허용: %.1fmm)",
                side.value, verify.error_mm, POSITION_VERIFY_TOLERANCE_MM,
            )
            # 재시도 로직
            if verify.retry_count < POSITION_VERIFY_MAX_RETRIES:
                verify.retry_count += 1
                self._send_position_command(side, leg.target_height_mm)
                logger.info("위치 재시도 — %s: %d/%d", side.value, verify.retry_count, POSITION_VERIFY_MAX_RETRIES)
        else:
            verify.retry_count = 0

        return verify

    # ========================================================================
    # V8.5: 벨트 장력 모니터링
    # ========================================================================

    def _update_belt_tension(self, side: LegSide) -> BeltTensionData:
        """
        V8.5: 벨트 장력 추정 / Estimate belt tension.

        모터 전류와 이동 방향을 기반으로 벨트 장력을 간접 추정.
        - 이동 중: 전류가 높으면 장력이 높음
        - 정지 중: 유지 전류로 장력 추정
        """
        leg = self._legs[side]
        tension_data = self._belt_tension[side]

        # 간접 장력 추정 (전류 기반)
        # 정상 이동 시: 장력 ≈ 모터 토크 / 풀리 반경
        # 유지 시: 장력 ≈ 유지 전류에 의한 토크
        current = leg.motor_current_a

        # 토크 상수 (KV → Kt) 근사
        kt = 1352.0 / MOTOR_KV / 1000.0  # oz-in/A → Nm/A 근사
        torque_nm = current * kt
        pulley_radius_m = (BELT_PITCH_MM * PULLEY_TEETH) / (2 * math.pi * 1000)
        estimated_tension = torque_nm / pulley_radius_m if pulley_radius_m > 0 else BELT_TENSION_NOMINAL_N

        tension_data.estimated_tension_n = estimated_tension
        tension_data.last_check_time = time.monotonic()

        # 편차 계산
        deviation_pct = abs(estimated_tension - BELT_TENSION_NOMINAL_N) / BELT_TENSION_NOMINAL_N * 100
        tension_data.deviation_pct = deviation_pct

        # 상태 판정
        tension_data.is_nominal = deviation_pct < BELT_TENSION_WARNING_PCT
        tension_data.is_loose = estimated_tension < BELT_TENSION_MIN_N
        tension_data.is_overtight = estimated_tension > BELT_TENSION_MAX_N

        if tension_data.is_loose:
            logger.warning("벨트 장력 부족 — %s: %.1fN (최소: %.1fN)",
                           side.value, estimated_tension, BELT_TENSION_MIN_N)
        elif tension_data.is_overtight:
            logger.warning("벨트 과장력 — %s: %.1fN (최대: %.1fN)",
                           side.value, estimated_tension, BELT_TENSION_MAX_N)
        elif deviation_pct > BELT_TENSION_WARNING_PCT:
            logger.info("벨트 장력 편차 — %s: %.1f%%", side.value, deviation_pct)

        return tension_data

    def get_belt_tension(self, side: LegSide) -> BeltTensionData:
        """V8.5: 벨트 장력 조회."""
        return self._belt_tension[side]

    # ========================================================================
    # V8.5: 핀 디텐트 확인
    # ========================================================================

    def _check_pin_detent(self, side: LegSide) -> PinDetentData:
        """
        V8.5: 핀 디텐트 확인 / Check pin detent.

        현재 높이가 핀 고정 위치 근처인지 확인하고
        핀 체결 상태를 추정.
        """
        leg = self._legs[side]
        detent = self._pin_detent[side]

        current_mm = leg.current_height_mm

        # 가장 가까운 핀 위치 탐색
        min_dist = float('inf')
        nearest_mm = current_mm
        for pos_mm in PIN_DETENT_POSITIONS_MM:
            dist = abs(current_mm - pos_mm)
            if dist < min_dist:
                min_dist = dist
                nearest_mm = pos_mm

        detent.nearest_position_mm = nearest_mm
        detent.distance_to_nearest_mm = min_dist

        # 핀 근처면 체결 가능
        detent.is_engaged = min_dist <= PIN_DETENT_TOLERANCE_MM

        # 체결 확인: 핀 위치에서 유지 전류가 낮으면 핀이 체결됨
        if detent.is_engaged and leg.state == LegState.HOLDING:
            # 유지 전류가 낮으면 핀이 부하를 분산
            detent.is_confirmed = leg.motor_current_a < 2.0
        else:
            detent.is_confirmed = False

        return detent

    def confirm_pin_detent(self, side: LegSide) -> bool:
        """
        V8.5: 핀 디텐트 수동 확인 / Manually confirm pin detent.

        현재 위치에서 핀이 올바르게 체결되었는지 확인.
        """
        detent = self._check_pin_detent(side)
        if detent.is_engaged and detent.is_confirmed:
            logger.info("핀 디텐트 확인 완료 — %s: 위치=%.1fmm", side.value, detent.nearest_position_mm)
            return True
        else:
            logger.warning(
                "핀 디텐트 미확인 — %s: 거리=%.1fmm, 체결=%s",
                side.value, detent.distance_to_nearest_mm, detent.is_confirmed,
            )
            return False

    # ========================================================================
    # V8.5: 일정힘 스프링 건전성
    # ========================================================================

    def _update_spring_health(self, side: LegSide) -> SpringHealthData:
        """
        V8.5: 스프링 건전성 추정 / Estimate spring health.

        수축 시 스프링이 가하는 힘을 추정하고
        피로도를 모니터링.
        """
        leg = self._legs[side]
        spring = self._spring_health[side]

        # 스프링 힘 추정:
        # 수축 시 모터 전류가 낮으면 스프링이 정상 작동
        # 수축 시 모터 전류가 높으면 스프링이 약해짐
        if leg.state == LegState.RETRACTING or leg.state == LegState.EMERGENCY_RETRACT:
            # 정상: 스프링이 수축 방향으로 도움 → 모터 전류가 낮아야 함
            expected_current_no_spring = 4.0  # 스프링 없을 때 예상 전류
            if leg.motor_current_a > 0.1:
                # 스프링 도움 정도 추정
                spring_assist_ratio = 1.0 - (leg.motor_current_a / expected_current_no_spring)
                spring_assist_ratio = max(0.0, min(1.0, spring_assist_ratio))
                spring.estimated_force_n = SPRING_FORCE_NOMINAL_N * spring_assist_ratio
            else:
                spring.estimated_force_n = SPRING_FORCE_NOMINAL_N

        # 피로도 계산 (사이클 기반)
        fatigue_pct = (spring.cycle_count / SPRING_CYCLE_LIFE) * 100
        spring.fatigue_pct = min(fatigue_pct, 100.0)

        # 건전성 판정
        force_deviation = abs(spring.estimated_force_n - SPRING_FORCE_NOMINAL_N) / SPRING_FORCE_NOMINAL_N * 100

        spring.is_healthy = (
            spring.estimated_force_n >= SPRING_FORCE_MIN_N and
            spring.estimated_force_n <= SPRING_FORCE_MAX_N and
            fatigue_pct < 80.0
        )

        spring.needs_replacement = (
            spring.estimated_force_n < SPRING_FORCE_MIN_N or
            fatigue_pct >= 80.0
        )

        if not spring.is_healthy:
            logger.warning(
                "스프링 건전성 저하 — %s: 추정힘=%.1fN, 피로도=%.1f%%",
                side.value, spring.estimated_force_n, spring.fatigue_pct,
            )

        return spring

    def increment_spring_cycle(self, side: LegSide) -> None:
        """V8.5: 스프링 사이클 카운트 증가."""
        self._spring_health[side].cycle_count += 1

    def get_spring_health(self, side: LegSide) -> SpringHealthData:
        """V8.5: 스프링 건전성 조회."""
        return self._spring_health[side]

    # ========================================================================
    # V8.5: 재생 제동 (PDF #25)
    # ========================================================================

    def get_regen_data(self, side: LegSide) -> RegenBrakingData:
        """V8.5: 재생 제동 데이터 조회."""
        return self._regen_data[side]

    # ========================================================================
    # 내부 메서드
    # ========================================================================

    def _set_height_target(self, side: LegSide, target_mm: float, speed_mmps: float = 0.0) -> None:
        leg = self._legs[side]
        leg.target_height_mm = target_mm
        self._send_position_command(side, target_mm)

    def _send_position_command(self, side: LegSide, target_mm: float) -> None:
        target_rad = (target_mm - self._config.min_height_mm) * self._mm_to_rad * self._config.gear_ratio

        if self._simplefoc is not None:
            i2c_addr = SIMPLEFOC_I2C_ADDRESSES[side]
            try:
                self._simplefoc.set_position(i2c_addr, target_rad)
            except Exception as e:
                logger.error("SimpleFOC 위치 명령 실패 (%s): %s", side.value, e)

        if self._xdrive is not None:
            from xdrive_controller import JointID
            joint_map = {
                LegSide.LEFT: JointID.LEFT_LEG_LIFT,
                LegSide.RIGHT: JointID.RIGHT_LEG_LIFT,
            }
            try:
                self._xdrive.set_position(
                    joint_map[side],
                    position=int(target_rad * 1000),
                )
            except Exception as e:
                logger.error("XDRIVE 위치 명령 실패 (%s): %s", side.value, e)

    def _run_pid_control(self, side: LegSide, dt: float) -> None:
        leg = self._legs[side]
        error = leg.target_height_mm - leg.current_height_mm
        leg.position_error_mm = error

        if self._pid is not None:
            output = self._pid.update(error, dt)
            velocity_rad = output * self._mm_to_rad
            i2c_addr = SIMPLEFOC_I2C_ADDRESSES[side]

            if self._simplefoc is not None:
                try:
                    self._simplefoc.set_velocity(i2c_addr, velocity_rad)
                except Exception as e:
                    logger.error("PID 속도 명령 실패 (%s): %s", side.value, e)

        if abs(error) < 1.0 and leg.state in (LegState.EXTENDING, LegState.RETRACTING):
            self._update_leg_state(side, LegState.HOLDING)
            # V8.5: 위치 검증
            self.verify_position(side)
            # V8.5: 스프링 사이클 카운트
            self.increment_spring_cycle(side)
            logger.info("목표 높이 도달 — %s: %.1f mm", side.value, leg.current_height_mm)

    def _check_stall(self, side: LegSide, dt: float) -> None:
        leg = self._legs[side]
        height_change = abs(leg.current_height_mm - self._last_height[side])

        if height_change < 0.1 and leg.state in (LegState.EXTENDING, LegState.RETRACTING):
            if self._stall_start_time[side] is None:
                self._stall_start_time[side] = time.monotonic()
            elif (time.monotonic() - self._stall_start_time[side]) * 1000 > STALL_TIMEOUT_MS:
                leg.is_stalled = True
                self._update_leg_state(side, LegState.FAULT)
                logger.error("⚠️ 스톨 감지 — %s: %.1fmm", side.value, leg.current_height_mm)
        else:
            self._stall_start_time[side] = None
            leg.is_stalled = False

        self._last_height[side] = leg.current_height_mm

    def _check_current_limit(self, side: LegSide) -> None:
        leg = self._legs[side]
        current = leg.motor_current_a

        if current > PEAK_CURRENT_A:
            self._update_leg_state(side, LegState.FAULT)
            logger.error("⚠️ 과전류 — %s: %.1fA", side.value, current)
        elif current > CONTINUOUS_CURRENT_A:
            logger.warning("과전류 경고 — %s: %.1fA", side.value, current)

    def _handle_emergency_retract(self, side: LegSide, dt: float) -> None:
        """긴급 수축 처리 (V8.5: 재생 제동 포함)"""
        leg = self._legs[side]
        regen = self._regen_data[side]

        # 스프링 복원력에 의한 수축
        spring_speed = self._config.spring_force_n / 1.0

        # V8.5: 재생 제동 시 감속 (안전한 수축)
        if regen.is_active:
            effective_speed = spring_speed * REGEN_SLOWDOWN_FACTOR

            # 재생 에너지 추정
            # P = F * v, E = P * dt
            force = self._config.spring_force_n + leg.motor_current_a * 0.5
            power = force * effective_speed / 1000.0  # W
            energy = power * dt
            regen.energy_recovered_j += energy
            regen.total_energy_recovered_j += energy
            regen.regen_current_a = min(leg.motor_current_a, REGEN_MAX_CURRENT_A)
        else:
            effective_speed = spring_speed

        leg.current_height_mm = max(
            self._config.min_height_mm,
            leg.current_height_mm - effective_speed * dt,
        )

        if leg.current_height_mm <= self._config.min_height_mm + 1.0:
            self._update_leg_state(side, LegState.RETRACTED)
            regen.is_active = False
            logger.info("긴급 수축 완료 — %s (회수 에너지: %.1fJ)", side.value, regen.total_energy_recovered_j)

    def _update_leg_state(self, side: LegSide, new_state: LegState) -> None:
        old_state = self._legs[side].state
        if old_state != new_state:
            logger.debug("다리 상태 변경 — %s: %s → %s", side.value, old_state.value, new_state.value)
            self._legs[side].state = new_state
