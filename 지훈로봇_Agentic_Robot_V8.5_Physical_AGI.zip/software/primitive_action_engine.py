#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
primitive_action_engine.py - 프리미티브 액션 엔진 / Primitive Action Engine
===========================================================================

Jihun Robot V8.5 - Physical AGI 핵심 모듈
Core module for Jihun Robot V8.5 - Physical AGI

PRIMITIVE ACTIONS are the atomic building blocks of Physical AGI.
The robot must freely compose, chain, mutate, and optimize these primitives
to accomplish any physical task.

프리미티브 액션은 Physical AGI의 원자적 빌딩 블록이다.
로봇은 어떤 물리적 과업이든 수행하기 위해 이 프리미티브들을 자유롭게
구성(compose), 연결(chain), 변이(mutate), 최적화(optimize)해야 한다.

Architecture:
    PrimitiveAction → ActionComposer → CompositeAction → ActionExecutor → PhysicalExperience
          ↑               ↑                    ↑               ↑                ↑
    ActionMutator ──── ActionComposer ──── ActionExecutor ──── PrimitiveActionEngine

Dependencies: numpy, sqlite3, threading, logging, dataclasses, enum, typing, json, time, uuid

Author: Jihun Robot V8.5 Team
Created: 2024
"""

from __future__ import annotations

import json
import logging
import math
import os
import sqlite3
import threading
import time
import uuid
from copy import deepcopy
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import (
    Any,
    Dict,
    List,
    Optional,
    Tuple,
    Callable,
    Set,
)

import numpy as np

# ============================================================================
# 로깅 설정 / Logging Configuration
# ============================================================================

logger = logging.getLogger("primitive_action_engine")
logger.setLevel(logging.DEBUG)

_formatter = logging.Formatter(
    "[%(asctime)s] %(name)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

_stream_handler = logging.StreamHandler()
_stream_handler.setLevel(logging.INFO)
_stream_handler.setFormatter(_formatter)
logger.addHandler(_stream_handler)

try:
    _log_dir = os.path.dirname(os.path.abspath(__file__))
    _file_handler = logging.FileHandler(
        os.path.join(_log_dir, "primitive_action_engine.log")
    )
    _file_handler.setLevel(logging.DEBUG)
    _file_handler.setFormatter(_formatter)
    logger.addHandler(_file_handler)
except Exception:
    pass

# ============================================================================
# V8.5 의존성 - 액션 진화 모듈 / V8.5 Dependencies - Action Evolution Module
# ============================================================================

try:
    from action_evolution import ActionGenome, ActionEvolver
    _HAS_ACTION_EVOLUTION = True
    logger.debug("action_evolution 모듈 로드 성공 / action_evolution module loaded successfully")
except ImportError:
    _HAS_ACTION_EVOLUTION = False
    ActionGenome = None  # type: ignore[assignment, misc]
    ActionEvolver = None  # type: ignore[assignment, misc]
    logger.debug(
        "action_evolution 모듈 없음 - 폴백 모드 / "
        "action_evolution module not found - fallback mode"
    )


# ============================================================================
# 열거형 / Enumerations
# ============================================================================


class ActionCategory(Enum):
    """
    프리미티브 액션 카테고리 / Primitive action categories.

    LOCOMOTION   - 이동 관련 동작 / Movement-related actions
    MANIPULATION - 조작 관련 동작 / Object manipulation actions
    POSTURE      - 자세 관련 동작 / Body posture actions
    HEAD         - 머리/시선 관련 동작 / Head/gaze actions
    COMPOSITE    - 복합 동작 / Composite (multi-primitive) actions
    TOOL_USE     - 도구 사용 동작 / Tool usage actions (V8.5 Physical AGI)
    SOCIAL       - 사회적 제스처 동작 / Social gesture actions (V8.5 Physical AGI)
    TRANSPORT    - 운반 이동 동작 / Transport while carrying actions (V8.5 Physical AGI)
    """

    LOCOMOTION = "locomotion"
    MANIPULATION = "manipulation"
    POSTURE = "posture"
    HEAD = "head"
    COMPOSITE = "composite"
    TOOL_USE = "tool_use"              # 도구 사용 / Tool operation (V8.5 Physical AGI)
    SOCIAL = "social"                  # 사회적 제스처 / Social gestures (V8.5 Physical AGI)
    TRANSPORT = "transport"            # 운반 이동 / Carrying objects while moving (V8.5 Physical AGI)


class ExecutionStatus(Enum):
    """
    실행 상태 / Execution status.
    """

    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    ABORTED = "aborted"
    TIMEOUT = "timeout"


# ============================================================================
# 데이터 클래스 / Data Classes
# ============================================================================


@dataclass
class PrimitiveAction:
    """
    프리미티브 액션 - Physical AGI의 원자적 빌딩 블록
    Primitive Action - Atomic building block of Physical AGI.

    Attributes:
        action_id: 고유 식별자 / Unique identifier
        category: 액션 카테고리 / Action category
        name: 액션 이름 / Action name
        parameters: 파라미터 딕셔너리 / Parameter dictionary (e.g., {"speed": 0.5, "force": 2.0})
        duration_ms: 예상 실행 시간 (밀리초) / Estimated duration in milliseconds
        preconditions: 실행 전제조건 / Preconditions that must be true before execution
        postconditions: 실행 후 상태 / Postconditions that become true after execution
        energy_cost: 예상 에너지 소비 (줄) / Estimated energy cost in joules
        risk_level: 위험도 (0=안전, 1=위험) / Risk level (0=safe, 1=dangerous)
    """

    action_id: str
    category: ActionCategory
    name: str
    parameters: Dict[str, float]
    duration_ms: int
    preconditions: List[str]
    postconditions: List[str]
    energy_cost: float
    risk_level: float

    def __post_init__(self) -> None:
        """초기화 후 검증 / Post-init validation."""
        if not 0.0 <= self.risk_level <= 1.0:
            raise ValueError(
                f"risk_level은 0.0~1.0 사이여야 합니다 / risk_level must be 0.0-1.0, got {self.risk_level}"
            )
        if self.duration_ms < 0:
            raise ValueError(
                f"duration_ms는 0 이상이어야 합니다 / duration_ms must be >= 0, got {self.duration_ms}"
            )

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary."""
        return {
            "action_id": self.action_id,
            "category": self.category.value,
            "name": self.name,
            "parameters": self.parameters,
            "duration_ms": self.duration_ms,
            "preconditions": self.preconditions,
            "postconditions": self.postconditions,
            "energy_cost": self.energy_cost,
            "risk_level": self.risk_level,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PrimitiveAction":
        """딕셔너리에서 생성 / Create from dictionary."""
        data["category"] = ActionCategory(data["category"])
        return cls(**data)

    def summary(self) -> str:
        """액션 요약 문자열 / Action summary string."""
        param_str = ", ".join(f"{k}={v:.2f}" for k, v in self.parameters.items())
        return (
            f"[{self.category.value}] {self.name}({param_str}) "
            f"duration={self.duration_ms}ms energy={self.energy_cost:.1f}J "
            f"risk={self.risk_level:.2f}"
        )


@dataclass
class CompositeAction:
    """
    복합 액션 - 프리미티브 액션의 순차/병렬 실행 계획
    Composite Action - Sequential/parallel execution plan of primitives.

    Attributes:
        composite_id: 복합 액션 고유 식별자 / Unique composite action ID
        primitives: 순차 실행할 프리미티브 목록 / List of primitives for sequential execution
        parallel_groups: 병렬 실행 그룹 (인덱스 리스트) / Parallel execution groups (index lists)
        transitions: 프리미티브 간 전환 파라미터 / Transition parameters between primitives
        total_duration_ms: 총 예상 실행 시간 / Total estimated duration
        total_energy_cost: 총 예상 에너지 소비 / Total estimated energy cost
    """

    composite_id: str
    primitives: List[PrimitiveAction]
    parallel_groups: List[List[int]]
    transitions: List[Dict[str, Any]]
    total_duration_ms: int
    total_energy_cost: float

    def __post_init__(self) -> None:
        """초기화 후 자동 계산 / Post-init auto-calculation."""
        if self.total_duration_ms == 0 and self.primitives:
            self.total_duration_ms = self._compute_total_duration()
        if self.total_energy_cost == 0.0 and self.primitives:
            self.total_energy_cost = self._compute_total_energy()

    def _compute_total_duration(self) -> int:
        """
        총 실행 시간 계산 (병렬 그룹 고려)
        Compute total duration considering parallel groups.
        """
        if not self.primitives:
            return 0
        if not self.parallel_groups:
            # 순차 실행 / Sequential execution
            return sum(p.duration_ms for p in self.primitives)
        # 병렬 그룹 고려 / Consider parallel groups
        accounted: Set[int] = set()
        total = 0
        for group in self.parallel_groups:
            group_max = max(self.primitives[i].duration_ms for i in group)
            total += group_max
            accounted.update(group)
        # 병렬 그룹에 포함되지 않은 프리미티브는 순차 추가
        for i, p in enumerate(self.primitives):
            if i not in accounted:
                total += p.duration_ms
        return total

    def _compute_total_energy(self) -> float:
        """총 에너지 소비 계산 / Compute total energy cost."""
        return sum(p.energy_cost for p in self.primitives)

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary."""
        return {
            "composite_id": self.composite_id,
            "primitives": [p.to_dict() for p in self.primitives],
            "parallel_groups": self.parallel_groups,
            "transitions": self.transitions,
            "total_duration_ms": self.total_duration_ms,
            "total_energy_cost": self.total_energy_cost,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CompositeAction":
        """딕셔너리에서 생성 / Create from dictionary."""
        data["primitives"] = [PrimitiveAction.from_dict(p) for p in data["primitives"]]
        return cls(**data)

    def summary(self) -> str:
        """복합 액션 요약 / Composite action summary."""
        return (
            f"CompositeAction({self.composite_id}): "
            f"{len(self.primitives)} primitives, "
            f"{len(self.parallel_groups)} parallel groups, "
            f"duration={self.total_duration_ms}ms, "
            f"energy={self.total_energy_cost:.1f}J"
        )


@dataclass
class ExecutionResult:
    """
    실행 결과 / Execution result.

    Attributes:
        action_id: 실행된 액션 ID / Executed action ID
        status: 실행 상태 / Execution status
        actual_params: 실제 파라미터 / Actual parameters used during execution
        sensor_feedback: 센서 피드백 / Sensor feedback data
        duration_actual_ms: 실제 실행 시간 / Actual execution duration
        error_message: 에러 메시지 / Error message (if any)
        timestamp: 실행 타임스탬프 / Execution timestamp
    """

    action_id: str
    status: ExecutionStatus
    actual_params: Dict[str, float]
    sensor_feedback: Dict[str, float]
    duration_actual_ms: int
    error_message: Optional[str] = None
    timestamp: float = field(default_factory=time.time)


@dataclass
class RobotState:
    """
    로봇 현재 상태 / Current robot state.

    Attributes:
        joint_angles: 관절 각도 (라디안) / Joint angles in radians
        joint_velocities: 관절 각속도 (rad/s) / Joint angular velocities
        joint_forces: 관절 토크/힘 (Nm) / Joint torques/forces
        base_position: 베이스 위치 (x, y, z) / Base position
        base_orientation: 베이스 방향 (roll, pitch, yaw) / Base orientation
        balance_score: 균형 점수 (0=불안정, 1=안정) / Balance score
        battery_level: 배터리 잔량 (0~1) / Battery level
        is_emergency: 비상 정지 상태 / Emergency stop state
        gripper_state: 그리퍼 상태 (0=열림, 1=닫힘) / Gripper state
        head_pan: 머리 좌우 각도 / Head pan angle
        head_tilt: 머리 상하 각도 / Head tilt angle
    """

    joint_angles: Dict[str, float] = field(default_factory=dict)
    joint_velocities: Dict[str, float] = field(default_factory=dict)
    joint_forces: Dict[str, float] = field(default_factory=dict)
    base_position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    base_orientation: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    balance_score: float = 1.0
    battery_level: float = 1.0
    is_emergency: bool = False
    gripper_state: float = 0.0
    head_pan: float = 0.0
    head_tilt: float = 0.0
    timestamp: float = field(default_factory=time.time)

    def is_stable(self) -> bool:
        """
        로봇이 안정적인지 확인 / Check if robot is stable.
        균형 점수가 0.5 이상이면 안정으로 판단
        """
        return self.balance_score >= 0.5 and not self.is_emergency

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary."""
        return {
            "joint_angles": self.joint_angles,
            "joint_velocities": self.joint_velocities,
            "joint_forces": self.joint_forces,
            "base_position": list(self.base_position),
            "base_orientation": list(self.base_orientation),
            "balance_score": self.balance_score,
            "battery_level": self.battery_level,
            "is_emergency": self.is_emergency,
            "gripper_state": self.gripper_state,
            "head_pan": self.head_pan,
            "head_tilt": self.head_tilt,
            "timestamp": self.timestamp,
        }


@dataclass
class PhysicalExperience:
    """
    물리적 경험 - 실행 결과와 학습 데이터
    Physical Experience - Execution result and learning data.

    Attributes:
        experience_id: 경험 고유 ID / Unique experience ID
        action: 실행된 액션 / Executed action
        result: 실행 결과 / Execution result
        state_before: 실행 전 로봇 상태 / Robot state before execution
        state_after: 실행 후 로봇 상태 / Robot state after execution
        reward: 보상 신호 / Reward signal (-1.0 ~ 1.0)
        novelty: 새로움 점수 / Novelty score (0=이전 경험과 동일, 1=완전히 새로운)
    """

    experience_id: str
    action: PrimitiveAction
    result: ExecutionResult
    state_before: RobotState
    state_after: RobotState
    reward: float
    novelty: float

    def to_dict(self) -> Dict[str, Any]:
        """딕셔너리로 변환 / Convert to dictionary."""
        return {
            "experience_id": self.experience_id,
            "action": self.action.to_dict(),
            "result": {
                "action_id": self.result.action_id,
                "status": self.result.status.value,
                "actual_params": self.result.actual_params,
                "sensor_feedback": self.result.sensor_feedback,
                "duration_actual_ms": self.result.duration_actual_ms,
                "error_message": self.result.error_message,
                "timestamp": self.result.timestamp,
            },
            "state_before": self.state_before.to_dict(),
            "state_after": self.state_after.to_dict(),
            "reward": self.reward,
            "novelty": self.novelty,
        }


# ============================================================================
# 프리미티브 액션 정의 / Primitive Action Definitions
# ============================================================================


def _generate_id(prefix: str = "act") -> str:
    """고유 ID 생성 / Generate unique ID."""
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def define_locomotion_primitives() -> List[PrimitiveAction]:
    """
    이동 프리미티브 정의 / Define locomotion primitives.
    15+ 개의 이동 관련 원자 동작
    """
    primitives: List[PrimitiveAction] = [
        PrimitiveAction(
            action_id="loco_walk_forward",
            category=ActionCategory.LOCOMOTION,
            name="walk_forward",
            parameters={"speed": 0.5},
            duration_ms=800,
            preconditions=["is_standing", "path_clear"],
            postconditions=["position_advanced"],
            energy_cost=12.0,
            risk_level=0.05,
        ),
        PrimitiveAction(
            action_id="loco_walk_backward",
            category=ActionCategory.LOCOMOTION,
            name="walk_backward",
            parameters={"speed": 0.3},
            duration_ms=900,
            preconditions=["is_standing", "rear_clear"],
            postconditions=["position_retreated"],
            energy_cost=14.0,
            risk_level=0.15,
        ),
        PrimitiveAction(
            action_id="loco_trot",
            category=ActionCategory.LOCOMOTION,
            name="trot",
            parameters={"speed": 1.2},
            duration_ms=500,
            preconditions=["is_standing", "path_clear"],
            postconditions=["position_advanced_fast"],
            energy_cost=22.0,
            risk_level=0.20,
        ),
        PrimitiveAction(
            action_id="loco_crawl",
            category=ActionCategory.LOCOMOTION,
            name="crawl",
            parameters={"speed": 0.15},
            duration_ms=3000,
            preconditions=["ground_contact"],
            postconditions=["position_advanced_low"],
            energy_cost=18.0,
            risk_level=0.10,
        ),
        PrimitiveAction(
            action_id="loco_strafe_left",
            category=ActionCategory.LOCOMOTION,
            name="strafe_left",
            parameters={"speed": 0.4},
            duration_ms=700,
            preconditions=["is_standing", "left_clear"],
            postconditions=["position_shifted_left"],
            energy_cost=10.0,
            risk_level=0.08,
        ),
        PrimitiveAction(
            action_id="loco_strafe_right",
            category=ActionCategory.LOCOMOTION,
            name="strafe_right",
            parameters={"speed": 0.4},
            duration_ms=700,
            preconditions=["is_standing", "right_clear"],
            postconditions=["position_shifted_right"],
            energy_cost=10.0,
            risk_level=0.08,
        ),
        PrimitiveAction(
            action_id="loco_turn_in_place",
            category=ActionCategory.LOCOMOTION,
            name="turn_in_place",
            parameters={"angle": 45.0},
            duration_ms=600,
            preconditions=["is_standing"],
            postconditions=["orientation_changed"],
            energy_cost=6.0,
            risk_level=0.05,
        ),
        PrimitiveAction(
            action_id="loco_climb_step",
            category=ActionCategory.LOCOMOTION,
            name="climb_step",
            parameters={"height": 0.1},
            duration_ms=1200,
            preconditions=["is_standing", "step_detected"],
            postconditions=["on_higher_surface"],
            energy_cost=25.0,
            risk_level=0.30,
        ),
        PrimitiveAction(
            action_id="loco_descend_step",
            category=ActionCategory.LOCOMOTION,
            name="descend_step",
            parameters={"height": 0.1},
            duration_ms=1000,
            preconditions=["is_standing", "lower_surface_detected"],
            postconditions=["on_lower_surface"],
            energy_cost=18.0,
            risk_level=0.25,
        ),
        PrimitiveAction(
            action_id="loco_balance_on_slope",
            category=ActionCategory.LOCOMOTION,
            name="balance_on_slope",
            parameters={"angle": 10.0},
            duration_ms=2000,
            preconditions=["is_standing", "slope_detected"],
            postconditions=["stable_on_slope"],
            energy_cost=20.0,
            risk_level=0.35,
        ),
        PrimitiveAction(
            action_id="loco_jump_small",
            category=ActionCategory.LOCOMOTION,
            name="jump_small",
            parameters={"distance": 0.3},
            duration_ms=400,
            preconditions=["is_standing", "landing_area_clear"],
            postconditions=["position_jumped"],
            energy_cost=35.0,
            risk_level=0.45,
        ),
        PrimitiveAction(
            action_id="loco_recovery_step",
            category=ActionCategory.LOCOMOTION,
            name="recovery_step",
            parameters={"direction": 0.0},
            duration_ms=300,
            preconditions=["is_balancing"],
            postconditions=["balance_recovered"],
            energy_cost=8.0,
            risk_level=0.10,
        ),
        PrimitiveAction(
            action_id="loco_pivot",
            category=ActionCategory.LOCOMOTION,
            name="pivot",
            parameters={"angle": 90.0},
            duration_ms=800,
            preconditions=["is_standing"],
            postconditions=["orientation_pivoted"],
            energy_cost=7.0,
            risk_level=0.08,
        ),
        PrimitiveAction(
            action_id="loco_side_step",
            category=ActionCategory.LOCOMOTION,
            name="side_step",
            parameters={"distance": 0.3},
            duration_ms=650,
            preconditions=["is_standing", "side_clear"],
            postconditions=["position_shifted_sideways"],
            energy_cost=9.0,
            risk_level=0.07,
        ),
        PrimitiveAction(
            action_id="loco_diagonal_step",
            category=ActionCategory.LOCOMOTION,
            name="diagonal_step",
            parameters={"angle": 45.0, "distance": 0.3},
            duration_ms=750,
            preconditions=["is_standing", "diagonal_clear"],
            postconditions=["position_shifted_diagonally"],
            energy_cost=11.0,
            risk_level=0.12,
        ),
        PrimitiveAction(
            action_id="loco_accelerate",
            category=ActionCategory.LOCOMOTION,
            name="accelerate",
            parameters={"target_speed": 1.5, "ramp_time_ms": 500},
            duration_ms=600,
            preconditions=["is_moving"],
            postconditions=["speed_increased"],
            energy_cost=15.0,
            risk_level=0.15,
        ),
        PrimitiveAction(
            action_id="loco_decelerate",
            category=ActionCategory.LOCOMOTION,
            name="decelerate",
            parameters={"target_speed": 0.1, "ramp_time_ms": 400},
            duration_ms=500,
            preconditions=["is_moving"],
            postconditions=["speed_decreased"],
            energy_cost=8.0,
            risk_level=0.05,
        ),
    ]
    logger.info(
        "이동 프리미티브 %d개 정의됨 / Defined %d locomotion primitives",
        len(primitives),
        len(primitives),
    )
    return primitives


def define_manipulation_primitives() -> List[PrimitiveAction]:
    """
    조작 프리미티브 정의 / Define manipulation primitives.
    15+ 개의 조작 관련 원자 동작
    """
    primitives: List[PrimitiveAction] = [
        PrimitiveAction(
            action_id="manip_grip_close",
            category=ActionCategory.MANIPULATION,
            name="grip_close",
            parameters={"force": 5.0},
            duration_ms=300,
            preconditions=["gripper_open", "object_in_range"],
            postconditions=["object_grasped"],
            energy_cost=3.0,
            risk_level=0.05,
        ),
        PrimitiveAction(
            action_id="manip_grip_open",
            category=ActionCategory.MANIPULATION,
            name="grip_open",
            parameters={"speed": 1.0},
            duration_ms=250,
            preconditions=["gripper_has_object_or_closed"],
            postconditions=["gripper_open"],
            energy_cost=1.5,
            risk_level=0.02,
        ),
        PrimitiveAction(
            action_id="manip_grip_hold",
            category=ActionCategory.MANIPULATION,
            name="grip_hold",
            parameters={"force": 3.0},
            duration_ms=500,
            preconditions=["object_grasped"],
            postconditions=["object_held"],
            energy_cost=2.0,
            risk_level=0.03,
        ),
        PrimitiveAction(
            action_id="manip_push",
            category=ActionCategory.MANIPULATION,
            name="push",
            parameters={"force": 10.0, "direction": 0.0},
            duration_ms=600,
            preconditions=["arm_extended", "object_in_range"],
            postconditions=["object_pushed"],
            energy_cost=8.0,
            risk_level=0.15,
        ),
        PrimitiveAction(
            action_id="manip_pull",
            category=ActionCategory.MANIPULATION,
            name="pull",
            parameters={"force": 8.0, "direction": 180.0},
            duration_ms=700,
            preconditions=["arm_extended", "object_grasped"],
            postconditions=["object_pulled"],
            energy_cost=9.0,
            risk_level=0.18,
        ),
        PrimitiveAction(
            action_id="manip_lift",
            category=ActionCategory.MANIPULATION,
            name="lift",
            parameters={"height": 0.2, "force": 15.0},
            duration_ms=800,
            preconditions=["object_grasped", "clearance_above"],
            postconditions=["object_lifted"],
            energy_cost=12.0,
            risk_level=0.25,
        ),
        PrimitiveAction(
            action_id="manip_lower",
            category=ActionCategory.MANIPULATION,
            name="lower",
            parameters={"height": 0.15, "force": 5.0},
            duration_ms=700,
            preconditions=["object_grasped", "object_above_surface"],
            postconditions=["object_lowered"],
            energy_cost=6.0,
            risk_level=0.12,
        ),
        PrimitiveAction(
            action_id="manip_rotate_wrist",
            category=ActionCategory.MANIPULATION,
            name="rotate_wrist",
            parameters={"angle": 45.0},
            duration_ms=350,
            preconditions=["arm_extended"],
            postconditions=["wrist_rotated"],
            energy_cost=2.5,
            risk_level=0.04,
        ),
        PrimitiveAction(
            action_id="manip_pinch",
            category=ActionCategory.MANIPULATION,
            name="pinch",
            parameters={"force": 2.0},
            duration_ms=250,
            preconditions=["gripper_open", "small_object_in_range"],
            postconditions=["object_pinched"],
            energy_cost=1.5,
            risk_level=0.05,
        ),
        PrimitiveAction(
            action_id="manip_release_gently",
            category=ActionCategory.MANIPULATION,
            name="release_gently",
            parameters={"open_speed": 0.3},
            duration_ms=400,
            preconditions=["object_grasped"],
            postconditions=["object_released_gently"],
            energy_cost=1.0,
            risk_level=0.02,
        ),
        PrimitiveAction(
            action_id="manip_palpate",
            category=ActionCategory.MANIPULATION,
            name="palpate",
            parameters={"force": 1.0},
            duration_ms=500,
            preconditions=["arm_extended", "surface_in_range"],
            postconditions=["surface_texture_sensed"],
            energy_cost=2.0,
            risk_level=0.03,
        ),
        PrimitiveAction(
            action_id="manip_tap",
            category=ActionCategory.MANIPULATION,
            name="tap",
            parameters={"force": 3.0},
            duration_ms=200,
            preconditions=["arm_extended", "surface_in_range"],
            postconditions=["surface_tapped"],
            energy_cost=1.5,
            risk_level=0.03,
        ),
        PrimitiveAction(
            action_id="manip_slide",
            category=ActionCategory.MANIPULATION,
            name="slide",
            parameters={"direction": 0.0, "distance": 0.15},
            duration_ms=600,
            preconditions=["object_on_surface", "arm_extended"],
            postconditions=["object_slid"],
            energy_cost=5.0,
            risk_level=0.10,
        ),
        PrimitiveAction(
            action_id="manip_insert",
            category=ActionCategory.MANIPULATION,
            name="insert",
            parameters={"depth": 0.05, "force": 8.0},
            duration_ms=900,
            preconditions=["object_grasped", "target_hole_detected"],
            postconditions=["object_inserted"],
            energy_cost=7.0,
            risk_level=0.30,
        ),
        PrimitiveAction(
            action_id="manip_twist",
            category=ActionCategory.MANIPULATION,
            name="twist",
            parameters={"angle": 90.0, "force": 5.0},
            duration_ms=500,
            preconditions=["object_grasped"],
            postconditions=["object_twisted"],
            energy_cost=4.0,
            risk_level=0.10,
        ),
        PrimitiveAction(
            action_id="manip_place",
            category=ActionCategory.MANIPULATION,
            name="place",
            parameters={"x": 0.0, "y": 0.0, "z": 0.0},
            duration_ms=1000,
            preconditions=["object_grasped", "placement_clear"],
            postconditions=["object_placed"],
            energy_cost=8.0,
            risk_level=0.08,
        ),
    ]
    logger.info(
        "조작 프리미티브 %d개 정의됨 / Defined %d manipulation primitives",
        len(primitives),
        len(primitives),
    )
    return primitives


def define_posture_primitives() -> List[PrimitiveAction]:
    """
    자세 프리미티브 정의 / Define posture primitives.
    10+ 개의 자세 관련 원자 동작
    """
    primitives: List[PrimitiveAction] = [
        PrimitiveAction(
            action_id="post_extend_legs",
            category=ActionCategory.POSTURE,
            name="extend_legs",
            parameters={"height": 0.3},
            duration_ms=600,
            preconditions=["is_standing_or_crouching"],
            postconditions=["legs_extended"],
            energy_cost=10.0,
            risk_level=0.10,
        ),
        PrimitiveAction(
            action_id="post_retract_legs",
            category=ActionCategory.POSTURE,
            name="retract_legs",
            parameters={"height": 0.1},
            duration_ms=500,
            preconditions=["legs_extended"],
            postconditions=["legs_retracted"],
            energy_cost=8.0,
            risk_level=0.08,
        ),
        PrimitiveAction(
            action_id="post_lean_forward",
            category=ActionCategory.POSTURE,
            name="lean_forward",
            parameters={"angle": 15.0},
            duration_ms=400,
            preconditions=["is_standing"],
            postconditions=["leaning_forward"],
            energy_cost=5.0,
            risk_level=0.12,
        ),
        PrimitiveAction(
            action_id="post_lean_back",
            category=ActionCategory.POSTURE,
            name="lean_back",
            parameters={"angle": 10.0},
            duration_ms=400,
            preconditions=["is_standing"],
            postconditions=["leaning_back"],
            energy_cost=5.0,
            risk_level=0.15,
        ),
        PrimitiveAction(
            action_id="post_crouch",
            category=ActionCategory.POSTURE,
            name="crouch",
            parameters={"depth": 0.2},
            duration_ms=600,
            preconditions=["is_standing"],
            postconditions=["crouching"],
            energy_cost=8.0,
            risk_level=0.08,
        ),
        PrimitiveAction(
            action_id="post_stand_tall",
            category=ActionCategory.POSTURE,
            name="stand_tall",
            parameters={"height": 0.35},
            duration_ms=700,
            preconditions=["ground_contact"],
            postconditions=["standing_tall"],
            energy_cost=12.0,
            risk_level=0.05,
        ),
        PrimitiveAction(
            action_id="post_shift_weight",
            category=ActionCategory.POSTURE,
            name="shift_weight",
            parameters={"direction": 0.0, "amount": 0.3},
            duration_ms=400,
            preconditions=["is_standing"],
            postconditions=["weight_shifted"],
            energy_cost=4.0,
            risk_level=0.10,
        ),
        PrimitiveAction(
            action_id="post_stabilize",
            category=ActionCategory.POSTURE,
            name="stabilize",
            parameters={"target_balance": 0.95},
            duration_ms=500,
            preconditions=["is_balancing"],
            postconditions=["stabilized"],
            energy_cost=3.0,
            risk_level=0.02,
        ),
        PrimitiveAction(
            action_id="post_tilt_body",
            category=ActionCategory.POSTURE,
            name="tilt_body",
            parameters={"angle": 10.0, "direction": 0.0},
            duration_ms=450,
            preconditions=["is_standing"],
            postconditions=["body_tilted"],
            energy_cost=5.0,
            risk_level=0.15,
        ),
        PrimitiveAction(
            action_id="post_adjust_com",
            category=ActionCategory.POSTURE,
            name="adjust_center_of_mass",
            parameters={"dx": 0.0, "dy": 0.0},
            duration_ms=350,
            preconditions=["is_standing"],
            postconditions=["com_adjusted"],
            energy_cost=3.0,
            risk_level=0.05,
        ),
        PrimitiveAction(
            action_id="post_lean_left",
            category=ActionCategory.POSTURE,
            name="lean_left",
            parameters={"angle": 10.0},
            duration_ms=400,
            preconditions=["is_standing"],
            postconditions=["leaning_left"],
            energy_cost=5.0,
            risk_level=0.12,
        ),
        PrimitiveAction(
            action_id="post_lean_right",
            category=ActionCategory.POSTURE,
            name="lean_right",
            parameters={"angle": 10.0},
            duration_ms=400,
            preconditions=["is_standing"],
            postconditions=["leaning_right"],
            energy_cost=5.0,
            risk_level=0.12,
        ),
    ]
    logger.info(
        "자세 프리미티브 %d개 정의됨 / Defined %d posture primitives",
        len(primitives),
        len(primitives),
    )
    return primitives


def define_head_primitives() -> List[PrimitiveAction]:
    """
    머리/시선 프리미티브 정의 / Define head/gaze primitives.
    8+ 개의 머리 관련 원자 동작
    """
    primitives: List[PrimitiveAction] = [
        PrimitiveAction(
            action_id="head_look_at",
            category=ActionCategory.HEAD,
            name="look_at",
            parameters={"x": 0.0, "y": 0.0, "z": 1.0},
            duration_ms=200,
            preconditions=["head_operational"],
            postconditions=["gaze_directed"],
            energy_cost=1.0,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="head_scan_area",
            category=ActionCategory.HEAD,
            name="scan_area",
            parameters={"pattern": 0.0},  # 0=horizontal, 1=vertical, 2=spiral
            duration_ms=1500,
            preconditions=["head_operational"],
            postconditions=["area_scanned"],
            energy_cost=2.5,
            risk_level=0.02,
        ),
        PrimitiveAction(
            action_id="head_track_object",
            category=ActionCategory.HEAD,
            name="track_object",
            parameters={"object_id": 0.0},
            duration_ms=1000,
            preconditions=["head_operational", "object_detected"],
            postconditions=["object_tracked"],
            energy_cost=2.0,
            risk_level=0.02,
        ),
        PrimitiveAction(
            action_id="head_look_down",
            category=ActionCategory.HEAD,
            name="look_down",
            parameters={"angle": 30.0},
            duration_ms=180,
            preconditions=["head_operational"],
            postconditions=["gaze_downward"],
            energy_cost=0.8,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="head_look_up",
            category=ActionCategory.HEAD,
            name="look_up",
            parameters={"angle": 30.0},
            duration_ms=180,
            preconditions=["head_operational"],
            postconditions=["gaze_upward"],
            energy_cost=0.8,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="head_pan",
            category=ActionCategory.HEAD,
            name="pan",
            parameters={"angle": 45.0},
            duration_ms=250,
            preconditions=["head_operational"],
            postconditions=["head_panned"],
            energy_cost=1.0,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="head_tilt",
            category=ActionCategory.HEAD,
            name="tilt",
            parameters={"angle": 20.0},
            duration_ms=200,
            preconditions=["head_operational"],
            postconditions=["head_tilted"],
            energy_cost=0.8,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="head_focus_distance",
            category=ActionCategory.HEAD,
            name="focus_distance",
            parameters={"meters": 1.5},
            duration_ms=150,
            preconditions=["head_operational"],
            postconditions=["focus_adjusted"],
            energy_cost=0.5,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="head_nod",
            category=ActionCategory.HEAD,
            name="nod",
            parameters={"angle": 15.0, "reps": 1.0},
            duration_ms=400,
            preconditions=["head_operational"],
            postconditions=["nod_complete"],
            energy_cost=1.2,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="head_shake",
            category=ActionCategory.HEAD,
            name="shake",
            parameters={"angle": 20.0, "reps": 2.0},
            duration_ms=500,
            preconditions=["head_operational"],
            postconditions=["shake_complete"],
            energy_cost=1.5,
            risk_level=0.01,
        ),
    ]
    logger.info(
        "머리 프리미티브 %d개 정의됨 / Defined %d head primitives",
        len(primitives),
        len(primitives),
    )
    return primitives


# ============================================================================
# V8.5 Physical AGI - 도구 사용 프리미티브 / Tool Use Primitives
# ============================================================================


def define_tool_use_primitives() -> List[PrimitiveAction]:
    """
    도구 사용 프리미티브 정의 / Define tool use primitives.
    V8.5 Physical AGI - 가위, 망치, 나사, 붓 등 도구 조작 원자 동작
    """
    primitives: List[PrimitiveAction] = [
        PrimitiveAction(
            action_id="tool_grasp_handle",
            category=ActionCategory.TOOL_USE,
            name="grasp_handle",
            parameters={"grip_width": 0.04, "force": 8.0},
            duration_ms=500,
            preconditions=["gripper_open", "tool_in_range"],
            postconditions=["tool_grasped"],
            energy_cost=4.0,
            risk_level=0.10,
        ),
        PrimitiveAction(
            action_id="tool_swing",
            category=ActionCategory.TOOL_USE,
            name="swing",
            parameters={"angle": 90.0, "speed": 1.5},
            duration_ms=700,
            preconditions=["tool_grasped", "swing_clearance"],
            postconditions=["tool_swing_completed"],
            energy_cost=15.0,
            risk_level=0.55,
        ),
        PrimitiveAction(
            action_id="tool_squeeze",
            category=ActionCategory.TOOL_USE,
            name="squeeze",
            parameters={"force": 20.0, "travel_mm": 30.0},
            duration_ms=400,
            preconditions=["tool_grasped", "object_in_jaws"],
            postconditions=["object_squeezed"],
            energy_cost=10.0,
            risk_level=0.20,
        ),
        PrimitiveAction(
            action_id="tool_cut",
            category=ActionCategory.TOOL_USE,
            name="cut",
            parameters={"blade_depth": 0.01, "speed": 0.3},
            duration_ms=900,
            preconditions=["tool_grasped", "material_in_range"],
            postconditions=["material_cut"],
            energy_cost=12.0,
            risk_level=0.60,
        ),
        PrimitiveAction(
            action_id="tool_hammer_strike",
            category=ActionCategory.TOOL_USE,
            name="hammer_strike",
            parameters={"impact_force": 30.0, "recoil_dampening": 0.7},
            duration_ms=350,
            preconditions=["tool_grasped", "target_aligned"],
            postconditions=["target_struck"],
            energy_cost=18.0,
            risk_level=0.65,
        ),
        PrimitiveAction(
            action_id="tool_turn_screw",
            category=ActionCategory.TOOL_USE,
            name="turn_screw",
            parameters={"torque": 5.0, "rotations": 3.0},
            duration_ms=1200,
            preconditions=["tool_grasped", "screw_engaged"],
            postconditions=["screw_turned"],
            energy_cost=8.0,
            risk_level=0.15,
        ),
        PrimitiveAction(
            action_id="tool_brush_stroke",
            category=ActionCategory.TOOL_USE,
            name="brush_stroke",
            parameters={"pressure": 2.0, "speed": 0.2, "width": 0.05},
            duration_ms=800,
            preconditions=["tool_grasped", "surface_in_range"],
            postconditions=["surface_painted"],
            energy_cost=5.0,
            risk_level=0.05,
        ),
        PrimitiveAction(
            action_id="tool_pour",
            category=ActionCategory.TOOL_USE,
            name="pour",
            parameters={"tilt_angle": 45.0, "duration_ms": 2000},
            duration_ms=2000,
            preconditions=["container_grasped", "receptacle_aligned"],
            postconditions=["liquid_poured"],
            energy_cost=4.0,
            risk_level=0.30,
        ),
        PrimitiveAction(
            action_id="tool_press_button",
            category=ActionCategory.TOOL_USE,
            name="press_button",
            parameters={"force": 3.0, "travel_mm": 5.0},
            duration_ms=250,
            preconditions=["finger_extended", "button_in_range"],
            postconditions=["button_pressed"],
            energy_cost=1.0,
            risk_level=0.02,
        ),
        PrimitiveAction(
            action_id="tool_hold_steady",
            category=ActionCategory.TOOL_USE,
            name="hold_steady",
            parameters={"tremor_limit_mm": 0.5, "duration_ms": 3000},
            duration_ms=3000,
            preconditions=["tool_grasped", "stabilized"],
            postconditions=["tool_held_steady"],
            energy_cost=6.0,
            risk_level=0.08,
        ),
    ]
    logger.info(
        "도구 사용 프리미티브 %d개 정의됨 / Defined %d tool use primitives",
        len(primitives),
        len(primitives),
    )
    return primitives


def define_social_primitives() -> List[PrimitiveAction]:
    """
    사회적 제스처 프리미티브 정의 / Define social gesture primitives.
    V8.5 Physical AGI - 제스처, 가리키기, 인사 등 사회적 상호작용 원자 동작
    """
    primitives: List[PrimitiveAction] = [
        PrimitiveAction(
            action_id="social_wave",
            category=ActionCategory.SOCIAL,
            name="wave",
            parameters={"amplitude": 0.3, "frequency": 2.0},
            duration_ms=1000,
            preconditions=["arm_operational"],
            postconditions=["wave_gesture_complete"],
            energy_cost=3.0,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="social_point",
            category=ActionCategory.SOCIAL,
            name="point",
            parameters={"arm_extension": 0.8, "direction": 0.0},
            duration_ms=600,
            preconditions=["arm_operational", "target_identified"],
            postconditions=["pointing_at_target"],
            energy_cost=2.5,
            risk_level=0.02,
        ),
        PrimitiveAction(
            action_id="social_bow",
            category=ActionCategory.SOCIAL,
            name="bow",
            parameters={"angle": 30.0, "hold_ms": 1500},
            duration_ms=2000,
            preconditions=["is_standing", "balance_stable"],
            postconditions=["bow_complete"],
            energy_cost=5.0,
            risk_level=0.05,
        ),
        PrimitiveAction(
            action_id="social_shake_hand",
            category=ActionCategory.SOCIAL,
            name="shake_hand",
            parameters={"grip_force": 3.0, "shake_count": 3.0},
            duration_ms=1500,
            preconditions=["arm_extended", "hand_in_range"],
            postconditions=["handshake_complete"],
            energy_cost=4.0,
            risk_level=0.03,
        ),
        PrimitiveAction(
            action_id="social_raise_hand",
            category=ActionCategory.SOCIAL,
            name="raise_hand",
            parameters={"height": 0.5, "duration_ms": 3000},
            duration_ms=500,
            preconditions=["arm_operational"],
            postconditions=["hand_raised"],
            energy_cost=2.0,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="social_nod_gesture",
            category=ActionCategory.SOCIAL,
            name="nod_gesture",
            parameters={"angle": 15.0, "reps": 2.0},
            duration_ms=600,
            preconditions=["head_operational"],
            postconditions=["nod_gesture_complete"],
            energy_cost=1.0,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="social_shake_head_no",
            category=ActionCategory.SOCIAL,
            name="shake_head_no",
            parameters={"angle": 20.0, "reps": 2.0},
            duration_ms=700,
            preconditions=["head_operational"],
            postconditions=["head_shake_no_complete"],
            energy_cost=1.2,
            risk_level=0.01,
        ),
        PrimitiveAction(
            action_id="social_open_palm",
            category=ActionCategory.SOCIAL,
            name="open_palm",
            parameters={"spread": 1.0, "orientation": 0.0},
            duration_ms=400,
            preconditions=["arm_operational"],
            postconditions=["palm_open_gesture"],
            energy_cost=1.5,
            risk_level=0.01,
        ),
    ]
    logger.info(
        "사회적 제스처 프리미티브 %d개 정의됨 / Defined %d social primitives",
        len(primitives),
        len(primitives),
    )
    return primitives


def define_transport_primitives() -> List[PrimitiveAction]:
    """
    운반 이동 프리미티브 정의 / Define transport primitives.
    V8.5 Physical AGI - 물체를 들고 이동하는 복합 원자 동작
    """
    primitives: List[PrimitiveAction] = [
        PrimitiveAction(
            action_id="transport_carry_walk",
            category=ActionCategory.TRANSPORT,
            name="carry_walk",
            parameters={"speed": 0.3, "stability_threshold": 0.85},
            duration_ms=1200,
            preconditions=["object_grasped", "is_standing", "path_clear"],
            postconditions=["object_carried_to_new_position"],
            energy_cost=20.0,
            risk_level=0.15,
        ),
        PrimitiveAction(
            action_id="transport_carry_turn",
            category=ActionCategory.TRANSPORT,
            name="carry_turn",
            parameters={"angle": 90.0, "stability_threshold": 0.85},
            duration_ms=900,
            preconditions=["object_grasped", "is_standing"],
            postconditions=["carried_and_turned"],
            energy_cost=12.0,
            risk_level=0.18,
        ),
        PrimitiveAction(
            action_id="transport_two_hand_carry",
            category=ActionCategory.TRANSPORT,
            name="two_hand_carry",
            parameters={"speed": 0.2, "grip_force": 10.0},
            duration_ms=1500,
            preconditions=["object_grasped_both_hands", "is_standing", "path_clear"],
            postconditions=["object_carried_two_handed"],
            energy_cost=25.0,
            risk_level=0.20,
        ),
        PrimitiveAction(
            action_id="transport_place_gently",
            category=ActionCategory.TRANSPORT,
            name="place_gently",
            parameters={"descent_speed": 0.05, "release_delay_ms": 300},
            duration_ms=1200,
            preconditions=["object_grasped", "placement_detected"],
            postconditions=["object_placed_gently"],
            energy_cost=6.0,
            risk_level=0.08,
        ),
        PrimitiveAction(
            action_id="transport_slide_on_surface",
            category=ActionCategory.TRANSPORT,
            name="slide_on_surface",
            parameters={"push_force": 8.0, "direction": 0.0},
            duration_ms=800,
            preconditions=["object_on_surface", "surface_continuous"],
            postconditions=["object_slid_to_target"],
            energy_cost=7.0,
            risk_level=0.10,
        ),
        PrimitiveAction(
            action_id="transport_handover",
            category=ActionCategory.TRANSPORT,
            name="handover",
            parameters={"approach_speed": 0.1, "release_threshold": 0.5},
            duration_ms=1500,
            preconditions=["object_grasped", "recipient_hand_detected"],
            postconditions=["object_handed_over"],
            energy_cost=5.0,
            risk_level=0.15,
        ),
        PrimitiveAction(
            action_id="transport_carry_up_stairs",
            category=ActionCategory.TRANSPORT,
            name="carry_up_stairs",
            parameters={"step_height": 0.15, "stability_threshold": 0.90},
            duration_ms=2000,
            preconditions=["object_grasped", "is_standing", "step_detected"],
            postconditions=["object_carried_up_step"],
            energy_cost=35.0,
            risk_level=0.45,
        ),
        PrimitiveAction(
            action_id="transport_load_into_container",
            category=ActionCategory.TRANSPORT,
            name="load_into_container",
            parameters={"precision": 0.8, "depth": 0.1},
            duration_ms=1100,
            preconditions=["object_grasped", "container_detected"],
            postconditions=["object_loaded"],
            energy_cost=8.0,
            risk_level=0.12,
        ),
    ]
    logger.info(
        "운반 이동 프리미티브 %d개 정의됨 / Defined %d transport primitives",
        len(primitives),
        len(primitives),
    )
    return primitives


def define_all_primitives() -> Dict[str, PrimitiveAction]:
    """
    모든 프리미티브 액션 정의 / Define all primitive actions.

    Returns:
        action_id → PrimitiveAction 매핑 딕셔너리
    """
    all_primitives: List[PrimitiveAction] = (
        define_locomotion_primitives()
        + define_manipulation_primitives()
        + define_posture_primitives()
        + define_head_primitives()
        + define_tool_use_primitives()
        + define_social_primitives()
        + define_transport_primitives()
    )
    primitive_map: Dict[str, PrimitiveAction] = {}
    for p in all_primitives:
        if p.action_id in primitive_map:
            logger.warning(
                "중복 action_id 감지: %s / Duplicate action_id detected: %s",
                p.action_id,
                p.action_id,
            )
        primitive_map[p.action_id] = p

    logger.info(
        "총 프리미티브 %d개 정의 완료 / Total %d primitives defined",
        len(primitive_map),
        len(primitive_map),
    )
    return primitive_map


# ============================================================================
# 액션 컴포저 / Action Composer
# ============================================================================


class ActionComposer:
    """
    프리미티브 액션을 자유롭게 복합 액션으로 구성
    Freely composes primitives into complex action sequences.

    액션 컴포저는 프리미티브들을 순차적, 병렬적, 또는 혼합 방식으로
    조합하여 복잡한 물리적 과업을 수행할 수 있는 실행 계획을 생성한다.
    """

    def __init__(self) -> None:
        self._logger = logging.getLogger("primitive_action_engine.ActionComposer")
        self._transition_cache: Dict[str, Dict[str, Any]] = {}

    def compose_sequential(
        self, primitives: List[PrimitiveAction]
    ) -> CompositeAction:
        """
        프리미티브들을 순차 실행으로 구성 / Compose primitives for sequential execution.

        Args:
            primitives: 순서대로 실행할 프리미티브 목록

        Returns:
            CompositeAction: 순차 실행 복합 액션
        """
        if not primitives:
            raise ValueError(
                "최소 1개의 프리미티브가 필요합니다 / At least 1 primitive required"
            )

        # 전환 파라미터 자동 계산 / Auto-compute transition parameters
        transitions: List[Dict[str, Any]] = []
        for i in range(len(primitives) - 1):
            trans = self.auto_transition(primitives[i], primitives[i + 1])
            transitions.append(trans)

        total_duration = sum(p.duration_ms for p in primitives)
        total_energy = sum(p.energy_cost for p in primitives)

        # 전환 오버헤드 추가 / Add transition overhead
        transition_overhead = sum(
            t.get("overlap_ms", 0) for t in transitions
        )
        total_duration = max(0, total_duration - transition_overhead)

        composite = CompositeAction(
            composite_id=_generate_id("comp_seq"),
            primitives=list(primitives),
            parallel_groups=[],  # 순차 실행이므로 병렬 그룹 없음 / No parallel groups for sequential
            transitions=transitions,
            total_duration_ms=total_duration,
            total_energy_cost=total_energy,
        )

        self._logger.info(
            "순차 복합 액션 구성: %s (%d개 프리미티브, %dms, %.1fJ) / "
            "Sequential composite composed: %s (%d primitives, %dms, %.1fJ)",
            composite.composite_id,
            len(primitives),
            total_duration,
            total_energy,
            composite.composite_id,
            len(primitives),
            total_duration,
            total_energy,
        )
        return composite

    def compose_parallel(
        self, primitives: List[PrimitiveAction]
    ) -> CompositeAction:
        """
        프리미티브들을 병렬 실행으로 구성 / Compose primitives for parallel execution.

        Args:
            primitives: 동시에 실행할 프리미티브 목록

        Returns:
            CompositeAction: 병렬 실행 복합 액션
        """
        if not primitives:
            raise ValueError(
                "최소 1개의 프리미티브가 필요합니다 / At least 1 primitive required"
            )

        # 병렬 실행: 가장 긴 실행 시간이 총 시간 / Parallel: longest duration is total
        total_duration = max(p.duration_ms for p in primitives)
        total_energy = sum(p.energy_cost for p in primitives)

        # 모든 프리미티브가 하나의 병렬 그룹 / All primitives in one parallel group
        parallel_groups = [list(range(len(primitives)))]

        composite = CompositeAction(
            composite_id=_generate_id("comp_par"),
            primitives=list(primitives),
            parallel_groups=parallel_groups,
            transitions=[],  # 병렬 실행이므로 전환 없음 / No transitions for parallel
            total_duration_ms=total_duration,
            total_energy_cost=total_energy,
        )

        self._logger.info(
            "병렬 복합 액션 구성: %s (%d개 프리미티브 병렬, %dms, %.1fJ) / "
            "Parallel composite composed: %s (%d parallel primitives, %dms, %.1fJ)",
            composite.composite_id,
            len(primitives),
            total_duration,
            total_energy,
            composite.composite_id,
            len(primitives),
            total_duration,
            total_energy,
        )
        return composite

    def compose_hybrid(
        self, sequence_plan: List[Dict[str, Any]]
    ) -> CompositeAction:
        """
        순차 + 병렬 혼합 실행 계획 구성 / Compose hybrid sequential+parallel plan.

        Args:
            sequence_plan: 실행 계획 리스트. 각 요소는 다음 형식:
                {"type": "sequential", "primitives": [p1, p2, ...]}
                {"type": "parallel", "primitives": [p1, p2, ...]}

        Returns:
            CompositeAction: 혼합 실행 복합 액션
        """
        all_primitives: List[PrimitiveAction] = []
        parallel_groups: List[List[int]] = []
        transitions: List[Dict[str, Any]] = []
        total_duration = 0

        for step in sequence_plan:
            step_type = step.get("type", "sequential")
            step_primitives = step.get("primitives", [])

            if not step_primitives:
                continue

            start_idx = len(all_primitives)
            indices = list(range(start_idx, start_idx + len(step_primitives)))
            all_primitives.extend(step_primitives)

            if step_type == "parallel":
                # 병렬 그룹으로 등록 / Register as parallel group
                parallel_groups.append(indices)
                # 병렬 실행 시간 = 가장 긴 것 / Parallel duration = longest
                total_duration += max(p.duration_ms for p in step_primitives)
            else:
                # 순차 실행 / Sequential execution
                total_duration += sum(p.duration_ms for p in step_primitives)

            # 이전 스텝과의 전환 계산 / Compute transition from previous step
            if all_primitives and start_idx > 0:
                trans = self.auto_transition(
                    all_primitives[start_idx - 1], all_primitives[start_idx]
                )
                transitions.append(trans)

        # 순차 프리미티브 간 전환 추가 / Add transitions between sequential primitives
        for step in sequence_plan:
            step_type = step.get("type", "sequential")
            step_primitives = step.get("primitives", [])
            if step_type == "sequential":
                for i in range(len(step_primitives) - 1):
                    trans = self.auto_transition(
                        step_primitives[i], step_primitives[i + 1]
                    )
                    transitions.append(trans)

        total_energy = sum(p.energy_cost for p in all_primitives)

        composite = CompositeAction(
            composite_id=_generate_id("comp_hyb"),
            primitives=all_primitives,
            parallel_groups=parallel_groups,
            transitions=transitions,
            total_duration_ms=total_duration,
            total_energy_cost=total_energy,
        )

        self._logger.info(
            "혼합 복합 액션 구성: %s (%d개 프리미티브, %d개 병렬그룹, %dms, %.1fJ) / "
            "Hybrid composite composed: %s (%d primitives, %d parallel groups, %dms, %.1fJ)",
            composite.composite_id,
            len(all_primitives),
            len(parallel_groups),
            total_duration,
            total_energy,
            composite.composite_id,
            len(all_primitives),
            len(parallel_groups),
            total_duration,
            total_energy,
        )
        return composite

    def auto_transition(
        self, primitive_a: PrimitiveAction, primitive_b: PrimitiveAction
    ) -> Dict[str, Any]:
        """
        두 프리미티브 간 부드러운 전환 파라미터 자동 계산
        Auto-compute smooth transition parameters between two primitives.

        전환 파라미터는 프리미티브 간의 물리적 연속성을 보장하며,
        관절 궤도 보간, 속도 램프, 중첩 시간 등을 포함한다.

        Args:
            primitive_a: 선행 프리미티브 / Preceding primitive
            primitive_b: 후행 프리미티브 / Following primitive

        Returns:
            전환 파라미터 딕셔너리 / Transition parameter dictionary
        """
        # 캐시 확인 / Check cache
        cache_key = f"{primitive_a.action_id}->{primitive_b.action_id}"
        if cache_key in self._transition_cache:
            return deepcopy(self._transition_cache[cache_key])

        # 카테고리 유사도 기반 전환 / Category-similarity-based transition
        same_category = primitive_a.category == primitive_b.category
        same_body_region = self._get_body_region(
            primitive_a.category
        ) == self._get_body_region(primitive_b.category)

        # 중첩 시간 계산 (같은 카테고리/영역일수록 더 많이 중첩 가능)
        # Overlap calculation (more overlap for same category/region)
        min_duration = min(primitive_a.duration_ms, primitive_b.duration_ms)
        if same_category:
            overlap_ratio = 0.2  # 같은 카테고리: 20% 중첩 / Same category: 20% overlap
        elif same_body_region:
            overlap_ratio = 0.1  # 같은 영역: 10% 중첩 / Same region: 10% overlap
        else:
            overlap_ratio = 0.05  # 다른 영역: 5% 중첩 / Different region: 5% overlap

        overlap_ms = int(min_duration * overlap_ratio)

        # 보간 곡선 선택 / Interpolation curve selection
        # "ease_in_out" - 부드러운 가감속 / Smooth acceleration/deceleration
        # "linear" - 선형 보간 / Linear interpolation
        # "step" - 즉시 전환 / Immediate switch
        risk_sum = primitive_a.risk_level + primitive_b.risk_level
        if risk_sum > 0.5:
            interpolation = "ease_in_out"  # 위험할수록 부드럽게 / Smoother for riskier
        elif same_category:
            interpolation = "linear"
        else:
            interpolation = "ease_in_out"

        # 파라미터 블렌딩 가중치 / Parameter blending weights
        param_overlap: Dict[str, Tuple[float, float]] = {}
        common_params = set(primitive_a.parameters.keys()) & set(
            primitive_b.parameters.keys()
        )
        for param_name in common_params:
            val_a = primitive_a.parameters[param_name]
            val_b = primitive_b.parameters[param_name]
            # 부드러운 전환을 위한 블렌딩 / Blending for smooth transition
            param_overlap[param_name] = (val_a, val_b)

        transition: Dict[str, Any] = {
            "from": primitive_a.action_id,
            "to": primitive_b.action_id,
            "overlap_ms": overlap_ms,
            "interpolation": interpolation,
            "blend_duration_ms": int(overlap_ms * 1.5),
            "param_overlap": {
                k: list(v) for k, v in param_overlap.items()
            },
            "same_category": same_category,
            "same_body_region": same_body_region,
            "transition_risk": (primitive_a.risk_level + primitive_b.risk_level) / 2,
        }

        self._transition_cache[cache_key] = transition
        return transition

    @staticmethod
    def _get_body_region(category: ActionCategory) -> str:
        """
        카테고리를 신체 영역으로 매핑 / Map category to body region.
        같은 영역의 액션은 병렬 실행이 어려움.
        """
        region_map = {
            ActionCategory.LOCOMOTION: "legs",
            ActionCategory.MANIPULATION: "arms",
            ActionCategory.POSTURE: "torso",
            ActionCategory.HEAD: "head",
            ActionCategory.COMPOSITE: "full_body",
        }
        return region_map.get(category, "unknown")

    def optimize_ordering(self, composite: CompositeAction) -> CompositeAction:
        """
        에너지/시간 효율을 위해 복합 액션의 순서를 최적화
        Optimize ordering of composite action for energy/time efficiency.

        전제조건/사후조건 종속성을 유지하면서, 에너지 소비와
        실행 시간을 최소화하는 순서를 탐욕적으로 탐색한다.

        Args:
            composite: 최적화할 복합 액션

        Returns:
            CompositeAction: 최적화된 복합 액션
        """
        if len(composite.primitives) <= 1:
            return composite

        primitives = list(composite.primitives)

        # 종속성 그래프 구축 / Build dependency graph
        # postcondition → precondition 종속성 확인
        dep_graph: Dict[int, Set[int]] = {i: set() for i in range(len(primitives))}

        for i in range(len(primitives)):
            for j in range(len(primitives)):
                if i == j:
                    continue
                # j의 전제조건이 i의 사후조건에 의존하는지 확인
                # Check if j's preconditions depend on i's postconditions
                for postcond in primitives[i].postconditions:
                    if postcond in primitives[j].preconditions:
                        dep_graph[j].add(i)

        # 위상 정렬 + 에너지 최적화 / Topological sort + energy optimization
        # 위상 정렬에서 선택 가능한 노드 중 에너지 비용이 낮은 것을 우선 선택
        # Among topologically available nodes, prefer lower energy cost
        ordered_indices: List[int] = []
        remaining = set(range(len(primitives)))
        completed: Set[int] = set()

        while remaining:
            # 선택 가능한 노드 (모든 종속성 충족)
            # Available nodes (all dependencies satisfied)
            available = [
                i
                for i in remaining
                if dep_graph[i].issubset(completed)
            ]
            if not available:
                # 순환 종속성 - 강제로 가장 적은 종속성 미충족 노드 선택
                # Circular dependency - force-select node with fewest unsatisfied deps
                self._logger.warning(
                    "순환 종속성 감지, 강제 선택 / Circular dependency detected, force-selecting"
                )
                available = sorted(
                    remaining,
                    key=lambda i: len(dep_graph[i] - completed),
                )
                available = [available[0]]

            # 에너지 비용이 낮은 것을 우선 선택 / Prefer lower energy cost
            available.sort(key=lambda i: primitives[i].energy_cost)
            selected = available[0]
            ordered_indices.append(selected)
            remaining.remove(selected)
            completed.add(selected)

        # 재정렬된 프리미티브 / Reordered primitives
        optimized_primitives = [primitives[i] for i in ordered_indices]

        # 새 전환 계산 / Recompute transitions
        new_transitions: List[Dict[str, Any]] = []
        for i in range(len(optimized_primitives) - 1):
            trans = self.auto_transition(
                optimized_primitives[i], optimized_primitives[i + 1]
            )
            new_transitions.append(trans)

        # 병렬 그룹 인덱스 재매핑 / Remap parallel group indices
        index_map = {old: new for new, old in enumerate(ordered_indices)}
        new_parallel_groups = []
        for group in composite.parallel_groups:
            new_group = [index_map[idx] for idx in group if idx in index_map]
            if len(new_group) > 1:
                new_parallel_groups.append(new_group)

        optimized = CompositeAction(
            composite_id=_generate_id("comp_opt"),
            primitives=optimized_primitives,
            parallel_groups=new_parallel_groups,
            transitions=new_transitions,
            total_duration_ms=0,  # 자동 재계산 / Auto-recalculate
            total_energy_cost=0.0,
        )

        self._logger.info(
            "복합 액션 순서 최적화: %s → %s "
            "(에너지: %.1fJ → %.1fJ, 시간: %dms → %dms)",
            composite.composite_id,
            optimized.composite_id,
            composite.total_energy_cost,
            optimized.total_energy_cost,
            composite.total_duration_ms,
            optimized.total_duration_ms,
        )
        return optimized


# ============================================================================
# 액션 뮤테이터 / Action Mutator
# ============================================================================


class ActionMutator:
    """
    프리미티브 액션 변이 탐색 / Action variation exploration for learning.

    액션 뮤테이터는 가우시안 노이즈, 진화 교차 등의 방법으로
    기존 액션의 변형을 생성하여 로봇이 새로운 동작 전략을
    탐색할 수 있도록 한다. 이것이 Physical AGI의 핵심: 자유로운
    액션 공간 탐색.
    """

    def __init__(self, seed: Optional[int] = None) -> None:
        self._logger = logging.getLogger("primitive_action_engine.ActionMutator")
        self._rng = np.random.default_rng(seed)
        self._mutation_history: List[Dict[str, Any]] = []

    def mutate_parameters(
        self, action: PrimitiveAction, sigma: float = 0.1
    ) -> PrimitiveAction:
        """
        파라미터에 가우시안 노이즈 적용 / Apply Gaussian noise to parameters.

        각 파라미터 값에 N(0, sigma) 노이즈를 추가하여
        새로운 액션 변형을 생성한다.

        Args:
            action: 원본 액션 / Original action
            sigma: 노이즈 표준편차 / Noise standard deviation

        Returns:
            변이된 PrimitiveAction / Mutated PrimitiveAction
        """
        if not action.parameters:
            return deepcopy(action)

        new_params = {}
        for key, value in action.parameters.items():
            # 가우시안 노이즈 적용 (음수 방지를 위해 절대값 사용 가능)
            # Apply Gaussian noise (use abs to prevent negative where needed)
            noise = self._rng.normal(0, sigma * abs(value) if value != 0 else sigma)
            new_value = value + noise
            # 물리적 파라미터는 음수가 될 수 없음 (대부분)
            # Most physical parameters cannot be negative
            if key in ("speed", "force", "height", "distance", "depth", "meters"):
                new_value = max(0.0, new_value)
            new_params[key] = round(new_value, 4)

        # 위험도도 약간 변이 / Slightly mutate risk level too
        risk_noise = self._rng.normal(0, sigma * 0.1)
        new_risk = max(0.0, min(1.0, action.risk_level + risk_noise))

        # 에너지 비용은 파라미터 변화에 비례하여 조정
        # Adjust energy cost proportionally to parameter changes
        param_change_ratio = 1.0
        if action.parameters:
            original_sum = sum(abs(v) for v in action.parameters.values())
            new_sum = sum(abs(v) for v in new_params.values())
            if original_sum > 0:
                param_change_ratio = new_sum / original_sum
        new_energy = action.energy_cost * param_change_ratio

        mutated = PrimitiveAction(
            action_id=_generate_id("mut"),
            category=action.category,
            name=action.name,
            parameters=new_params,
            duration_ms=action.duration_ms,
            preconditions=list(action.preconditions),
            postconditions=list(action.postconditions),
            energy_cost=round(new_energy, 2),
            risk_level=round(new_risk, 4),
        )

        self._mutation_history.append(
            {
                "type": "parameter_mutation",
                "parent_id": action.action_id,
                "child_id": mutated.action_id,
                "sigma": sigma,
                "timestamp": time.time(),
            }
        )

        self._logger.debug(
            "파라미터 변이: %s → %s (sigma=%.3f) / "
            "Parameter mutation: %s → %s (sigma=%.3f)",
            action.action_id,
            mutated.action_id,
            sigma,
            action.action_id,
            mutated.action_id,
            sigma,
        )
        return mutated

    def mutate_timing(
        self, action: PrimitiveAction, sigma_ms: float = 50
    ) -> PrimitiveAction:
        """
        실행 타이밍 변이 / Mutate execution timing.

        액션의 실행 시간(duration_ms)에 가우시안 노이즈를 적용한다.
        더 빠르거나 느린 실행을 탐색하여 최적 타이밍을 발견한다.

        Args:
            action: 원본 액션 / Original action
            sigma_ms: 타이밍 노이즈 표준편차 (밀리초) / Timing noise std dev in ms

        Returns:
            타이밍 변이된 PrimitiveAction / Timing-mutated PrimitiveAction
        """
        noise_ms = self._rng.normal(0, sigma_ms)
        new_duration = max(50, int(action.duration_ms + noise_ms))

        # 실행 시간 변화에 따른 에너지 비용 조정
        # Adjust energy cost based on duration change
        duration_ratio = new_duration / max(1, action.duration_ms)
        # 더 빠르면 더 많은 에너지, 더 느리면 더 적은 에너지 (비선형)
        # Faster = more energy, slower = less energy (nonlinear)
        energy_ratio = duration_ratio ** 0.7
        new_energy = action.energy_cost * energy_ratio

        mutated = PrimitiveAction(
            action_id=_generate_id("mut"),
            category=action.category,
            name=action.name,
            parameters=dict(action.parameters),
            duration_ms=new_duration,
            preconditions=list(action.preconditions),
            postconditions=list(action.postconditions),
            energy_cost=round(new_energy, 2),
            risk_level=action.risk_level,
        )

        self._mutation_history.append(
            {
                "type": "timing_mutation",
                "parent_id": action.action_id,
                "child_id": mutated.action_id,
                "sigma_ms": sigma_ms,
                "timestamp": time.time(),
            }
        )

        self._logger.debug(
            "타이밍 변이: %s → %s (%dms → %dms) / "
            "Timing mutation: %s → %s (%dms → %dms)",
            action.action_id,
            mutated.action_id,
            action.duration_ms,
            new_duration,
            action.action_id,
            mutated.action_id,
            action.duration_ms,
            new_duration,
        )
        return mutated

    def crossover(
        self, action_a: PrimitiveAction, action_b: PrimitiveAction
    ) -> PrimitiveAction:
        """
        진화적 교차 / Evolutionary crossover.

        두 부모 액션의 파라미터를 교차하여 자식 액션을 생성한다.
        같은 카테고리/이름의 액션끼리 교차하는 것이 의미 있음.

        Args:
            action_a: 부모 A / Parent A
            action_b: 부모 B / Parent B

        Returns:
            교차된 자식 PrimitiveAction / Crossover child PrimitiveAction
        """
        # 파라미터 교차 / Parameter crossover
        all_keys = set(action_a.parameters.keys()) | set(
            action_b.parameters.keys()
        )
        new_params: Dict[str, float] = {}

        for key in all_keys:
            val_a = action_a.parameters.get(key)
            val_b = action_b.parameters.get(key)

            if val_a is not None and val_b is not None:
                # 블렌딩 교차 (BLX-α) / Blended crossover (BLX-α)
                alpha = 0.5  # 확장 비율 / Expansion ratio
                min_val = min(val_a, val_b)
                max_val = max(val_a, val_b)
                range_val = max_val - min_val
                low = min_val - alpha * range_val
                high = max_val + alpha * range_val
                new_params[key] = round(float(self._rng.uniform(low, high)), 4)
            elif val_a is not None:
                new_params[key] = val_a
            elif val_b is not None:
                new_params[key] = val_b

        # 메타 파라미터 교차 / Meta-parameter crossover
        # 부모의 중간값 채택 / Adopt midpoint of parents
        crossover_point = self._rng.uniform(0.3, 0.7)
        new_duration = int(
            action_a.duration_ms * crossover_point
            + action_b.duration_ms * (1 - crossover_point)
        )
        new_energy = (
            action_a.energy_cost * crossover_point
            + action_b.energy_cost * (1 - crossover_point)
        )
        new_risk = (
            action_a.risk_level * crossover_point
            + action_b.risk_level * (1 - crossover_point)
        )

        # 사전/사후 조건 병합 / Merge pre/postconditions
        new_preconditions = list(
            set(action_a.preconditions) | set(action_b.preconditions)
        )
        new_postconditions = list(
            set(action_a.postconditions) | set(action_b.postconditions)
        )

        # 이름: 부모 중 우성 선택 / Name: select dominant parent
        dominant_parent = action_a if self._rng.random() > 0.5 else action_b

        child = PrimitiveAction(
            action_id=_generate_id("cross"),
            category=dominant_parent.category,
            name=dominant_parent.name,
            parameters=new_params,
            duration_ms=max(50, new_duration),
            preconditions=new_preconditions,
            postconditions=new_postconditions,
            energy_cost=round(new_energy, 2),
            risk_level=round(min(1.0, max(0.0, new_risk)), 4),
        )

        self._mutation_history.append(
            {
                "type": "crossover",
                "parent_a_id": action_a.action_id,
                "parent_b_id": action_b.action_id,
                "child_id": child.action_id,
                "crossover_point": crossover_point,
                "timestamp": time.time(),
            }
        )

        self._logger.debug(
            "교차: %s × %s → %s / Crossover: %s × %s → %s",
            action_a.action_id,
            action_b.action_id,
            child.action_id,
            action_a.action_id,
            action_b.action_id,
            child.action_id,
        )
        return child

    def mutate_composite(
        self, composite: CompositeAction, mutation_rate: float = 0.1
    ) -> CompositeAction:
        """
        복합 액션 변이 / Mutate composite action.

        각 프리미티브에 독립적으로 변이를 적용하고,
        일부 프리미티브의 순서를 변경할 수 있다.

        Args:
            composite: 원본 복합 액션 / Original composite action
            mutation_rate: 변이 확률 / Mutation probability per primitive

        Returns:
            변이된 CompositeAction / Mutated CompositeAction
        """
        new_primitives: List[PrimitiveAction] = []

        for primitive in composite.primitives:
            if self._rng.random() < mutation_rate:
                # 파라미터 변이 / Parameter mutation
                mutated = self.mutate_parameters(primitive, sigma=0.15)
                new_primitives.append(mutated)
            elif self._rng.random() < mutation_rate * 0.5:
                # 타이밍 변이 / Timing mutation
                mutated = self.mutate_timing(primitive, sigma_ms=80)
                new_primitives.append(mutated)
            else:
                new_primitives.append(deepcopy(primitive))

        # 순서 변이 (swap) / Order mutation (swap)
        if len(new_primitives) > 2 and self._rng.random() < mutation_rate:
            i, j = self._rng.choice(len(new_primitives), size=2, replace=False)
            new_primitives[i], new_primitives[j] = new_primitives[j], new_primitives[i]
            self._logger.debug(
                "순서 변이: 인덱스 %d ↔ %d 교환 / Order mutation: swap indices %d ↔ %d",
                i,
                j,
                i,
                j,
            )

        # 전환 재계산 / Recompute transitions
        new_transitions: List[Dict[str, Any]] = []
        for i in range(len(new_primitives) - 1):
            new_transitions.append(
                {"from": new_primitives[i].action_id, "to": new_primitives[i + 1].action_id}
            )

        mutated_composite = CompositeAction(
            composite_id=_generate_id("comp_mut"),
            primitives=new_primitives,
            parallel_groups=deepcopy(composite.parallel_groups),
            transitions=new_transitions,
            total_duration_ms=0,
            total_energy_cost=0.0,
        )

        self._logger.info(
            "복합 액션 변이: %s → %s (rate=%.2f) / "
            "Composite mutation: %s → %s (rate=%.2f)",
            composite.composite_id,
            mutated_composite.composite_id,
            mutation_rate,
            composite.composite_id,
            mutated_composite.composite_id,
            mutation_rate,
        )
        return mutated_composite

    def generate_variations(
        self, action: PrimitiveAction, n: int = 10
    ) -> List[PrimitiveAction]:
        """
        한 액션의 다양한 변형 생성 / Generate diverse variations of an action.

        파라미터 변이와 타이밍 변이를 혼합하여 n개의 변형을 생성한다.
        이것이 Physical AGI의 창발적 행동 탐색의 핵심이다.

        Args:
            action: 원본 액션 / Original action
            n: 생성할 변형 수 / Number of variations to generate

        Returns:
            변형된 액션 리스트 / List of varied actions
        """
        variations: List[PrimitiveAction] = []

        for i in range(n):
            # 다양한 sigma 값으로 변이 폭 조절 / Vary mutation magnitude
            sigma = 0.05 + (i / max(1, n)) * 0.3  # 0.05 ~ 0.35

            if i % 3 == 0:
                # 파라미터 변이 / Parameter mutation
                varied = self.mutate_parameters(action, sigma=sigma)
            elif i % 3 == 1:
                # 타이밍 변이 / Timing mutation
                varied = self.mutate_timing(action, sigma_ms=int(sigma * 300))
            else:
                # 파라미터 + 타이밍 복합 변이 / Combined parameter + timing mutation
                varied = self.mutate_parameters(action, sigma=sigma * 0.5)
                varied = self.mutate_timing(varied, sigma_ms=int(sigma * 200))

            variations.append(varied)

        self._logger.info(
            "액션 %s의 변형 %d개 생성 / Generated %d variations of %s",
            action.action_id,
            n,
            n,
            action.action_id,
        )
        return variations


# ============================================================================
# 액션 익스큐터 / Action Executor
# ============================================================================


class ActionExecutor:
    """
    프리미티브 및 복합 액션 실행기 / Primitive and composite action executor.

    하드웨어(현재는 시뮬레이션)에 액션을 실행하고, 결과를 수집한다.
    비상 정지 기능과 상태 모니터링을 포함한다.

    Executes actions on hardware (currently simulated), collects results.
    Includes emergency stop and state monitoring.
    """

    def __init__(self) -> None:
        self._logger = logging.getLogger("primitive_action_engine.ActionExecutor")
        self._current_state = RobotState()
        self._is_executing = False
        self._emergency_stop_flag = threading.Event()
        self._execution_lock = threading.Lock()
        self._execution_history: List[ExecutionResult] = []

        # 시뮬레이션 파라미터 / Simulation parameters
        self._sim_noise_level = 0.05  # 센서 노이즈 수준 / Sensor noise level
        self._sim_failure_rate = 0.02  # 무작위 실패 확률 / Random failure probability

        # 관절 초기화 / Initialize joints
        joint_names = [
            "left_hip", "left_knee", "left_ankle",
            "right_hip", "right_knee", "right_ankle",
            "left_shoulder", "left_elbow", "left_wrist",
            "right_shoulder", "right_elbow", "right_wrist",
            "waist", "neck_pan", "neck_tilt",
        ]
        for name in joint_names:
            self._current_state.joint_angles[name] = 0.0
            self._current_state.joint_velocities[name] = 0.0
            self._current_state.joint_forces[name] = 0.0

        self._logger.info("액션 익스큐터 초기화 완료 / Action executor initialized")

    def execute_primitive(self, action: PrimitiveAction) -> ExecutionResult:
        """
        프리미티브 액션 실행 / Execute a primitive action.

        Args:
            action: 실행할 프리미티브 액션

        Returns:
            ExecutionResult: 실행 결과
        """
        start_time = time.time()

        with self._execution_lock:
            # 비상 정지 확인 / Check emergency stop
            if self._emergency_stop_flag.is_set():
                self._logger.warning(
                    "비상 정지 상태에서 실행 시도: %s / "
                    "Execution attempt during emergency stop: %s",
                    action.action_id,
                    action.action_id,
                )
                return ExecutionResult(
                    action_id=action.action_id,
                    status=ExecutionStatus.ABORTED,
                    actual_params={},
                    sensor_feedback={},
                    duration_actual_ms=0,
                    error_message="Emergency stop active",
                )

            self._is_executing = True

        self._logger.info(
            "프리미티브 실행 시작: %s / Starting primitive execution: %s",
            action.summary(),
            action.summary(),
        )

        # 전제조건 확인 / Check preconditions
        precond_met = self._check_preconditions(action.preconditions)
        if not precond_met:
            self._logger.warning(
                "전제조건 미충족: %s - %s / Preconditions not met: %s - %s",
                action.action_id,
                action.preconditions,
                action.action_id,
                action.preconditions,
            )

        # 시뮬레이션 실행 / Simulated execution
        # 실제 실행 시간에 비례하는 대기 (시뮬레이션에서는 축소)
        sim_duration_ms = min(action.duration_ms, 100)  # 시뮬에서는 최대 100ms 대기
        time.sleep(sim_duration_ms / 1000.0)

        # 실행 결과 시뮬레이션 / Simulate execution result
        actual_params = self._simulate_actual_params(action)
        sensor_feedback = self._simulate_sensor_feedback(action)

        # 무작위 실패 시뮬레이션 / Simulate random failure
        if self._rng_random() < self._sim_failure_rate:
            status = ExecutionStatus.FAILED
            error_msg = "Simulated hardware failure"
        elif not precond_met:
            status = ExecutionStatus.PARTIAL
            error_msg = "Some preconditions not met"
        elif action.risk_level > 0.8:
            # 고위험 액션은 실패 확률 높음 / High-risk actions have higher failure rate
            if self._rng_random() < action.risk_level * 0.3:
                status = ExecutionStatus.FAILED
                error_msg = "High-risk action failed"
            else:
                status = ExecutionStatus.SUCCESS
                error_msg = None
        else:
            status = ExecutionStatus.SUCCESS
            error_msg = None

        # 비상 정지로 인한 중단 확인 / Check if aborted by emergency stop
        if self._emergency_stop_flag.is_set():
            status = ExecutionStatus.ABORTED
            error_msg = "Aborted by emergency stop"

        actual_duration_ms = int((time.time() - start_time) * 1000)

        # 로봇 상태 업데이트 / Update robot state
        self._update_state_after_action(action, status)

        result = ExecutionResult(
            action_id=action.action_id,
            status=status,
            actual_params=actual_params,
            sensor_feedback=sensor_feedback,
            duration_actual_ms=actual_duration_ms,
            error_message=error_msg,
        )

        self._execution_history.append(result)
        self._is_executing = False

        self._logger.info(
            "프리미티브 실행 완료: %s → %s (%dms) / "
            "Primitive execution complete: %s → %s (%dms)",
            action.action_id,
            status.value,
            actual_duration_ms,
            action.action_id,
            status.value,
            actual_duration_ms,
        )
        return result

    def execute_composite(
        self, composite: CompositeAction
    ) -> List[ExecutionResult]:
        """
        복합 액션 실행 / Execute a composite action.

        순차 및 병렬 그룹에 따라 프리미티브들을 실행한다.
        병렬 그룹은 스레드로 동시 실행한다.

        Args:
            composite: 실행할 복합 액션

        Returns:
            List[ExecutionResult]: 모든 프리미티브의 실행 결과
        """
        self._logger.info(
            "복합 액션 실행 시작: %s / Starting composite execution: %s",
            composite.summary(),
            composite.summary(),
        )

        results: List[ExecutionResult] = [None] * len(composite.primitives)  # type: ignore
        parallel_set: Set[int] = set()
        for group in composite.parallel_groups:
            parallel_set.update(group)

        # 병렬 그룹별 실행 / Execute parallel groups
        for group in composite.parallel_groups:
            self._logger.debug(
                "병렬 그룹 실행: 인덱스 %s / Executing parallel group: indices %s",
                group,
                group,
            )
            group_results: List[Optional[ExecutionResult]] = [None] * len(group)
            threads: List[threading.Thread] = []

            for thread_idx, prim_idx in enumerate(group):
                if self._emergency_stop_flag.is_set():
                    break

                def _exec_in_thread(
                    p_idx: int, t_idx: int
                ) -> None:
                    group_results[t_idx] = self.execute_primitive(
                        composite.primitives[p_idx]
                    )

                t = threading.Thread(
                    target=_exec_in_thread,
                    args=(prim_idx, thread_idx),
                    daemon=True,
                )
                threads.append(t)
                t.start()

            for t in threads:
                t.join(timeout=30.0)

            for thread_idx, prim_idx in enumerate(group):
                results[prim_idx] = group_results[thread_idx]  # type: ignore

        # 순차 프리미티브 실행 / Execute sequential primitives
        for i, primitive in enumerate(composite.primitives):
            if i in parallel_set:
                continue  # 이미 병렬로 실행됨 / Already executed in parallel
            if self._emergency_stop_flag.is_set():
                results[i] = ExecutionResult(
                    action_id=primitive.action_id,
                    status=ExecutionStatus.ABORTED,
                    actual_params={},
                    sensor_feedback={},
                    duration_actual_ms=0,
                    error_message="Aborted by emergency stop",
                )
                continue
            results[i] = self.execute_primitive(primitive)

        # None 결과 채우기 (비상 정지 등으로 누락된 경우)
        # Fill None results (missed due to emergency stop etc.)
        for i in range(len(results)):
            if results[i] is None:
                results[i] = ExecutionResult(
                    action_id=composite.primitives[i].action_id,
                    status=ExecutionStatus.ABORTED,
                    actual_params={},
                    sensor_feedback={},
                    duration_actual_ms=0,
                    error_message="Not executed",
                )

        success_count = sum(
            1 for r in results if r.status == ExecutionStatus.SUCCESS
        )
        self._logger.info(
            "복합 액션 실행 완료: %s (%d/%d 성공) / "
            "Composite execution complete: %s (%d/%d success)",
            composite.composite_id,
            success_count,
            len(results),
            composite.composite_id,
            success_count,
            len(results),
        )
        return results  # type: ignore

    def emergency_stop(self) -> None:
        """
        비상 정지 / Emergency stop.

        모든 실행 중인 액션을 즉시 중단한다.
        """
        self._emergency_stop_flag.set()
        self._is_executing = False
        self._current_state.is_emergency = True
        self._logger.critical(
            "⚠️ 비상 정지 활성화! / ⚠️ EMERGENCY STOP ACTIVATED!"
        )

    def release_emergency_stop(self) -> None:
        """
        비상 정지 해제 / Release emergency stop.
        """
        self._emergency_stop_flag.clear()
        self._current_state.is_emergency = False
        self._logger.info("비상 정지 해제 / Emergency stop released")

    def get_current_state(self) -> RobotState:
        """
        현재 로봇 상태 반환 / Return current robot state.

        Returns:
            RobotState: 현재 로봇의 관절 각도, 속도, 힘, 균형 등
        """
        # 시뮬레이션: 약간의 노이즈 추가 / Simulation: add slight noise
        state_copy = deepcopy(self._current_state)
        state_copy.timestamp = time.time()
        return state_copy

    def _check_preconditions(self, preconditions: List[str]) -> bool:
        """
        전제조건 확인 / Check preconditions.
        시뮬레이션에서는 대부분 True 반환.
        """
        # 실제 구현에서는 센서 데이터와 상태를 확인
        # In real implementation, check sensor data and state
        for cond in preconditions:
            if cond == "is_standing" and self._current_state.balance_score < 0.3:
                return False
            if cond == "is_emergency" and self._current_state.is_emergency:
                return False
        return True

    def _simulate_actual_params(
        self, action: PrimitiveAction
    ) -> Dict[str, float]:
        """실행 시 실제 파라미터 시뮬레이션 / Simulate actual params during execution."""
        actual = {}
        for key, value in action.parameters.items():
            noise = np.random.normal(0, self._sim_noise_level * abs(value) if value != 0 else 0.01)
            actual[key] = round(value + noise, 4)
        return actual

    def _simulate_sensor_feedback(
        self, action: PrimitiveAction
    ) -> Dict[str, float]:
        """센서 피드백 시뮬레이션 / Simulate sensor feedback."""
        feedback: Dict[str, float] = {
            "joint_torque_max": round(np.random.uniform(0.5, 3.0), 3),
            "imu_accel_x": round(np.random.normal(0, 0.1), 3),
            "imu_accel_y": round(np.random.normal(0, 0.1), 3),
            "imu_accel_z": round(9.81 + np.random.normal(0, 0.05), 3),
            "imu_gyro_x": round(np.random.normal(0, 0.02), 4),
            "imu_gyro_y": round(np.random.normal(0, 0.02), 4),
            "imu_gyro_z": round(np.random.normal(0, 0.02), 4),
            "force_sensor": round(np.random.uniform(0, action.parameters.get("force", 5.0)), 3),
            "current_draw": round(np.random.uniform(0.5, 3.0), 3),
        }

        if action.category == ActionCategory.MANIPULATION:
            feedback["gripper_force"] = round(
                np.random.uniform(0.1, action.parameters.get("force", 5.0)), 3
            )
            feedback["tactile_intensity"] = round(np.random.uniform(0, 1.0), 3)

        if action.category == ActionCategory.LOCOMOTION:
            feedback["odometry_dx"] = round(np.random.normal(0.01, 0.005), 5)
            feedback["odometry_dy"] = round(np.random.normal(0, 0.003), 5)

        return feedback

    def _update_state_after_action(
        self, action: PrimitiveAction, status: ExecutionStatus
    ) -> None:
        """액션 실행 후 로봇 상태 업데이트 / Update robot state after action execution."""
        if status != ExecutionStatus.SUCCESS:
            return

        # 카테고리별 상태 업데이트 / Category-based state update
        if action.category == ActionCategory.LOCOMOTION:
            speed = action.parameters.get("speed", 0.3)
            self._current_state.base_position = (
                self._current_state.base_position[0] + speed * 0.01,
                self._current_state.base_position[1],
                self._current_state.base_position[2],
            )
            self._current_state.balance_score = max(
                0.3,
                self._current_state.balance_score - action.risk_level * 0.1,
            )

        elif action.category == ActionCategory.MANIPULATION:
            if "grip" in action.name:
                self._current_state.gripper_state = (
                    1.0 if "close" in action.name else 0.0
                )

        elif action.category == ActionCategory.POSTURE:
            if "stabilize" in action.name:
                self._current_state.balance_score = min(
                    1.0, self._current_state.balance_score + 0.1
                )

        elif action.category == ActionCategory.HEAD:
            if "pan" in action.name:
                self._current_state.head_pan = action.parameters.get("angle", 0.0)
            elif "tilt" in action.name:
                self._current_state.head_tilt = action.parameters.get("angle", 0.0)

        # 관절 상태 랜덤 업데이트 / Random joint state update
        for joint in self._current_state.joint_angles:
            self._current_state.joint_angles[joint] += np.random.normal(0, 0.02)
            self._current_state.joint_velocities[joint] = np.random.normal(0, 0.1)
            self._current_state.joint_forces[joint] = abs(np.random.normal(0, 0.5))

        # 배터리 소모 / Battery drain
        self._current_state.battery_level = max(
            0.0,
            self._current_state.battery_level - action.energy_cost * 0.0001,
        )

    @staticmethod
    def _rng_random() -> float:
        """0~1 난수 생성 / Generate random number 0-1."""
        return np.random.random()


# ============================================================================
# SQLite 경험 데이터베이스 / SQLite Experience Database
# ============================================================================


class ExperienceDatabase:
    """
    물리적 경험을 SQLite에 저장하고 검색
    Store and retrieve physical experiences in SQLite.

    모든 실행 결과와 경험을 영속적으로 저장하여
    로봇이 과거 경험에서 학습할 수 있도록 한다.
    """

    def __init__(self, db_path: Optional[str] = None) -> None:
        if db_path is None:
            db_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "primitive_experience.db",
            )
        self._db_path = db_path
        self._lock = threading.Lock()
        self._logger = logging.getLogger("primitive_action_engine.ExperienceDatabase")
        self._init_db()

    def _init_db(self) -> None:
        """데이터베이스 스키마 초기화 / Initialize database schema."""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # 프리미티브 액션 테이블 / Primitive actions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS primitive_actions (
                    action_id TEXT PRIMARY KEY,
                    category TEXT NOT NULL,
                    name TEXT NOT NULL,
                    parameters TEXT NOT NULL,
                    duration_ms INTEGER NOT NULL,
                    preconditions TEXT NOT NULL,
                    postconditions TEXT NOT NULL,
                    energy_cost REAL NOT NULL,
                    risk_level REAL NOT NULL,
                    created_at REAL NOT NULL
                )
            """)

            # 복합 액션 테이블 / Composite actions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS composite_actions (
                    composite_id TEXT PRIMARY KEY,
                    primitives_json TEXT NOT NULL,
                    parallel_groups_json TEXT NOT NULL,
                    transitions_json TEXT NOT NULL,
                    total_duration_ms INTEGER NOT NULL,
                    total_energy_cost REAL NOT NULL,
                    created_at REAL NOT NULL
                )
            """)

            # 실행 결과 테이블 / Execution results table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS execution_results (
                    result_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    action_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    actual_params TEXT NOT NULL,
                    sensor_feedback TEXT NOT NULL,
                    duration_actual_ms INTEGER NOT NULL,
                    error_message TEXT,
                    timestamp REAL NOT NULL,
                    FOREIGN KEY (action_id) REFERENCES primitive_actions(action_id)
                )
            """)

            # 물리적 경험 테이블 / Physical experiences table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS physical_experiences (
                    experience_id TEXT PRIMARY KEY,
                    action_json TEXT NOT NULL,
                    result_json TEXT NOT NULL,
                    state_before_json TEXT NOT NULL,
                    state_after_json TEXT NOT NULL,
                    reward REAL NOT NULL,
                    novelty REAL NOT NULL,
                    timestamp REAL NOT NULL
                )
            """)

            # 인덱스 생성 / Create indexes
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_exp_category
                ON primitive_actions(category)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_exp_reward
                ON physical_experiences(reward)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_exp_novelty
                ON physical_experiences(novelty)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_exp_timestamp
                ON physical_experiences(timestamp)
            """)

            conn.commit()

        self._logger.info(
            "경험 데이터베이스 초기화: %s / Experience DB initialized: %s",
            self._db_path,
            self._db_path,
        )

    def _get_connection(self) -> sqlite3.Connection:
        """SQLite 연결 반환 / Return SQLite connection."""
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def store_primitive(self, action: PrimitiveAction) -> None:
        """프리미티브 액션 저장 / Store primitive action."""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    conn.execute(
                        """INSERT OR REPLACE INTO primitive_actions
                           (action_id, category, name, parameters, duration_ms,
                            preconditions, postconditions, energy_cost, risk_level, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            action.action_id,
                            action.category.value,
                            action.name,
                            json.dumps(action.parameters),
                            action.duration_ms,
                            json.dumps(action.preconditions),
                            json.dumps(action.postconditions),
                            action.energy_cost,
                            action.risk_level,
                            time.time(),
                        ),
                    )
                    conn.commit()
            except sqlite3.Error as e:
                self._logger.error(
                    "프리미티브 저장 실패: %s / Failed to store primitive: %s",
                    e,
                    e,
                )

    def store_experience(self, experience: PhysicalExperience) -> None:
        """물리적 경험 저장 / Store physical experience."""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    conn.execute(
                        """INSERT OR REPLACE INTO physical_experiences
                           (experience_id, action_json, result_json, state_before_json,
                            state_after_json, reward, novelty, timestamp)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            experience.experience_id,
                            json.dumps(experience.action.to_dict()),
                            json.dumps({
                                "action_id": experience.result.action_id,
                                "status": experience.result.status.value,
                                "actual_params": experience.result.actual_params,
                                "sensor_feedback": experience.result.sensor_feedback,
                                "duration_actual_ms": experience.result.duration_actual_ms,
                                "error_message": experience.result.error_message,
                                "timestamp": experience.result.timestamp,
                            }),
                            json.dumps(experience.state_before.to_dict()),
                            json.dumps(experience.state_after.to_dict()),
                            experience.reward,
                            experience.novelty,
                            experience.timestamp if hasattr(experience, 'timestamp') else time.time(),
                        ),
                    )
                    conn.commit()
            except sqlite3.Error as e:
                self._logger.error(
                    "경험 저장 실패: %s / Failed to store experience: %s", e, e
                )

    def store_composite(self, composite: CompositeAction) -> None:
        """복합 액션 저장 / Store composite action."""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    conn.execute(
                        """INSERT OR REPLACE INTO composite_actions
                           (composite_id, primitives_json, parallel_groups_json,
                            transitions_json, total_duration_ms, total_energy_cost, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?)""",
                        (
                            composite.composite_id,
                            json.dumps([p.to_dict() for p in composite.primitives]),
                            json.dumps(composite.parallel_groups),
                            json.dumps(composite.transitions),
                            composite.total_duration_ms,
                            composite.total_energy_cost,
                            time.time(),
                        ),
                    )
                    conn.commit()
            except sqlite3.Error as e:
                self._logger.error(
                    "복합 액션 저장 실패: %s / Failed to store composite: %s", e, e
                )

    def get_experiences_by_action_name(
        self, name: str, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """액션 이름으로 경험 검색 / Search experiences by action name."""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.execute(
                        """SELECT * FROM physical_experiences
                           WHERE action_json LIKE ?
                           ORDER BY timestamp DESC LIMIT ?""",
                        (f'%"name": "{name}"%', limit),
                    )
                    return [dict(row) for row in cursor.fetchall()]
            except sqlite3.Error as e:
                self._logger.error("경험 검색 실패: %s / Experience search failed: %s", e, e)
                return []

    def get_top_rewarded_experiences(
        self, limit: int = 50
    ) -> List[Dict[str, Any]]:
        """보상이 가장 높은 경험 검색 / Search top-rewarded experiences."""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.execute(
                        """SELECT * FROM physical_experiences
                           ORDER BY reward DESC LIMIT ?""",
                        (limit,),
                    )
                    return [dict(row) for row in cursor.fetchall()]
            except sqlite3.Error as e:
                self._logger.error("경험 검색 실패: %s / Experience search failed: %s", e, e)
                return []

    def get_experience_count(self) -> int:
        """저장된 경험 수 반환 / Return stored experience count."""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute("SELECT COUNT(*) FROM physical_experiences")
                return cursor.fetchone()[0]
        except sqlite3.Error:
            return 0

    def get_primitive_count(self) -> int:
        """저장된 프리미티브 수 반환 / Return stored primitive count."""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute("SELECT COUNT(*) FROM primitive_actions")
                return cursor.fetchone()[0]
        except sqlite3.Error:
            return 0

    def get_avg_reward_by_action(self) -> Dict[str, float]:
        """액션별 평균 보상 반환 / Return average reward by action."""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute(
                    """SELECT json_extract(action_json, '$.name') as name,
                              AVG(reward) as avg_reward
                       FROM physical_experiences
                       GROUP BY name
                       ORDER BY avg_reward DESC"""
                )
                return {row["name"]: row["avg_reward"] for row in cursor.fetchall()}
        except sqlite3.Error:
            return {}


# ============================================================================
# 프리미티브 액션 엔진 (메인 오케스트레이터) / Primitive Action Engine (Main Orchestrator)
# ============================================================================


class PrimitiveActionEngine:
    """
    프리미티브 액션 엔진 - 메인 오케스트레이터
    Primitive Action Engine - Main Orchestrator.

    Physical AGI의 핵심: 프리미티브 액션을 자유롭게 구성, 실행,
    학습, 개선, 발견하는 통합 엔진.

    Core of Physical AGI: unified engine for freely composing, executing,
    learning, refining, and discovering primitive actions.

    Usage:
        engine = PrimitiveActionEngine()
        engine.initialize()
        composite = engine.compose_for_task("pick up the red cup", robot_state)
        experiences = engine.execute_and_learn(composite)
        refined = engine.refine_from_experience(composite, experiences)
    """

    def __init__(self, db_path: Optional[str] = None) -> None:
        self._logger = logging.getLogger("primitive_action_engine.PrimitiveActionEngine")

        # 핵심 컴포넌트 / Core components
        self._primitives: Dict[str, PrimitiveAction] = {}
        self._composer = ActionComposer()
        self._mutator = ActionMutator(seed=42)
        self._executor = ActionExecutor()
        self._db = ExperienceDatabase(db_path=db_path)

        # 상태 / State
        self._initialized = False
        self._experience_buffer: List[PhysicalExperience] = []
        self._task_history: List[Dict[str, Any]] = []

        # 학습 파라미터 / Learning parameters
        self._novelty_threshold = 0.7  # 새로움 판단 임계값 / Novelty threshold
        self._reward_weights = {
            "success": 1.0,
            "energy_efficiency": 0.3,
            "speed": 0.2,
            "safety": 0.5,
        }

        self._logger.info("프리미티브 액션 엔진 생성 / Primitive Action Engine created")

    def initialize(self) -> None:
        """
        엔진 초기화 - 모든 프리미티브 정의 로드, 하드웨어 연결
        Initialize engine - load all primitive definitions, connect to hardware.
        """
        if self._initialized:
            self._logger.warning("이미 초기화됨 / Already initialized")
            return

        # 모든 프리미티브 정의 로드 / Load all primitive definitions
        self._primitives = define_all_primitives()
        self._logger.info(
            "프리미티브 %d개 로드 완료 / Loaded %d primitives",
            len(self._primitives),
            len(self._primitives),
        )

        # 데이터베이스에 프리미티브 저장 / Store primitives in database
        for action in self._primitives.values():
            self._db.store_primitive(action)

        # 카테고리별 인덱스 구축 / Build category index
        self._category_index: Dict[ActionCategory, List[str]] = {
            cat: [] for cat in ActionCategory
        }
        for action_id, action in self._primitives.items():
            self._category_index[action.category].append(action_id)

        # 이름 기반 인덱스 / Name-based index
        self._name_index: Dict[str, str] = {}
        for action_id, action in self._primitives.items():
            self._name_index[action.name] = action_id

        self._initialized = True
        self._logger.info(
            "✅ 프리미티브 액션 엔진 초기화 완료 "
            "(LOCOMOTION=%d, MANIPULATION=%d, POSTURE=%d, HEAD=%d) / "
            "✅ Primitive Action Engine initialized "
            "(LOCOMOTION=%d, MANIPULATION=%d, POSTURE=%d, HEAD=%d)",
            len(self._category_index[ActionCategory.LOCOMOTION]),
            len(self._category_index[ActionCategory.MANIPULATION]),
            len(self._category_index[ActionCategory.POSTURE]),
            len(self._category_index[ActionCategory.HEAD]),
            len(self._category_index[ActionCategory.LOCOMOTION]),
            len(self._category_index[ActionCategory.MANIPULATION]),
            len(self._category_index[ActionCategory.POSTURE]),
            len(self._category_index[ActionCategory.HEAD]),
        )

    def get_available_primitives(
        self, task_context: Optional[Dict[str, Any]] = None
    ) -> List[PrimitiveAction]:
        """
        과업 컨텍스트에 기반하여 사용 가능한 프리미티브 반환
        Return available primitives based on task context.

        현재 로봇 상태와 과업 요구사항을 고려하여
        실행 가능하고 관련성 높은 프리미티브를 필터링한다.

        Args:
            task_context: 과업 컨텍스트 (선택적) / Task context (optional)
                - "category": ActionCategory 필터링
                - "max_risk": 최대 위험도 필터
                - "max_energy": 최대 에너지 비용 필터
                - "required_postconditions": 필요한 사후조건 리스트

        Returns:
            사용 가능한 PrimitiveAction 리스트
        """
        if not self._initialized:
            raise RuntimeError("엔진이 초기화되지 않았습니다 / Engine not initialized")

        available = list(self._primitives.values())

        if task_context:
            # 카테고리 필터 / Category filter
            if "category" in task_context:
                cat = task_context["category"]
                if isinstance(cat, str):
                    cat = ActionCategory(cat)
                available = [a for a in available if a.category == cat]

            # 위험도 필터 / Risk filter
            if "max_risk" in task_context:
                max_risk = task_context["max_risk"]
                available = [a for a in available if a.risk_level <= max_risk]

            # 에너지 필터 / Energy filter
            if "max_energy" in task_context:
                max_energy = task_context["max_energy"]
                available = [a for a in available if a.energy_cost <= max_energy]

            # 사후조건 필터 / Postcondition filter
            if "required_postconditions" in task_context:
                required = set(task_context["required_postconditions"])
                available = [
                    a
                    for a in available
                    if required.intersection(set(a.postconditions))
                ]

        # 로봇 상태 기반 필터 / Robot state-based filter
        current_state = self._executor.get_current_state()
        if current_state.battery_level < 0.1:
            # 배터리 부족 시 고에너지 액션 제외 / Exclude high-energy actions on low battery
            available = [a for a in available if a.energy_cost < 10.0]

        self._logger.debug(
            "사용 가능 프리미티브: %d개 / Available primitives: %d",
            len(available),
            len(available),
        )
        return available

    def compose_for_task(
        self,
        task_description: str,
        current_state: Optional[RobotState] = None,
    ) -> CompositeAction:
        """
        AI 보조 액션 구성 / AI-assisted action composition.

        과업 설명을 분석하여 적절한 프리미티브들을 선택하고
        실행 순서를 결정하여 복합 액션을 생성한다.

        이것이 Physical AGI의 핵심 능력: 자연어 과업을
        프리미티브 액션 시퀀스로 변환.

        Args:
            task_description: 과업 설명 (자연어) / Task description (natural language)
            current_state: 현재 로봇 상태 / Current robot state

        Returns:
            CompositeAction: 과업 수행을 위한 복합 액션
        """
        if not self._initialized:
            raise RuntimeError("엔진이 초기화되지 않았습니다 / Engine not initialized")

        if current_state is None:
            current_state = self._executor.get_current_state()

        self._logger.info(
            "과업 구성 시작: '%s' / Task composition started: '%s'",
            task_description,
            task_description,
        )

        # 과업 분석 / Task analysis
        # 키워드 기반 프리미티브 매칭 (실제로는 LLM 사용)
        # Keyword-based primitive matching (would use LLM in production)
        task_keywords = task_description.lower().split()
        scored_primitives: List[Tuple[float, PrimitiveAction]] = []

        for action in self._primitives.values():
            score = self._score_action_for_task(action, task_keywords, current_state)
            if score > 0:
                scored_primitives.append((score, action))

        # 점수순 정렬 / Sort by score
        scored_primitives.sort(key=lambda x: x[0], reverse=True)

        # 상위 프리미티브 선택 / Select top primitives
        # 과업 복잡도에 따라 선택 수 조절 / Adjust selection count by task complexity
        complexity = self._estimate_task_complexity(task_keywords)
        num_primitives = min(len(scored_primitives), max(2, complexity * 2))

        selected = [p for _, p in scored_primitives[:num_primitives]]

        if not selected:
            # 기본 안전 액션 선택 / Select default safe actions
            self._logger.warning(
                "매칭된 프리미티브 없음, 기본 액션 선택 / "
                "No matched primitives, selecting default actions"
            )
            selected = [
                self._primitives["post_stabilize"],
                self._primitives["head_scan_area"],
            ]

        # 복합 액션 구성 / Compose composite action
        # 과업 타입에 따라 순차/병렬/혼합 선택
        # Choose sequential/parallel/hybrid based on task type
        categories_in_task = set(a.category for a in selected)

        if len(categories_in_task) == 1:
            # 같은 카테고리 → 순차 실행 / Same category → sequential
            composite = self._composer.compose_sequential(selected)
        elif len(selected) <= 3:
            # 적은 수 → 병렬 시도 / Few primitives → try parallel
            # 독립적 실행 가능성 확인 / Check independence for parallel
            can_parallel = self._can_parallelize(selected)
            if can_parallel:
                composite = self._composer.compose_parallel(selected)
            else:
                composite = self._composer.compose_sequential(selected)
        else:
            # 혼합 실행 계획 / Hybrid execution plan
            sequence_plan = self._build_hybrid_plan(selected)
            composite = self._composer.compose_hybrid(sequence_plan)

        # 최적화 / Optimize
        composite = self._composer.optimize_ordering(composite)

        # 과업 기록 / Record task
        self._task_history.append(
            {
                "task": task_description,
                "composite_id": composite.composite_id,
                "timestamp": time.time(),
            }
        )

        self._logger.info(
            "과업 구성 완료: '%s' → %s / Task composition complete: '%s' → %s",
            task_description,
            composite.summary(),
            task_description,
            composite.summary(),
        )
        return composite

    def execute_and_learn(
        self, composite: CompositeAction
    ) -> List[PhysicalExperience]:
        """
        복합 액션 실행 + 경험 수집 / Execute composite + collect experience.

        액션을 실행하면서 각 프리미티브의 실행 전후 상태를 기록하고,
        보상과 새로움을 계산하여 물리적 경험을 생성한다.

        이것이 로봇 학습의 핵심 루프: 실행 → 경험 → 개선.

        Args:
            composite: 실행할 복합 액션

        Returns:
            List[PhysicalExperience]: 수집된 물리적 경험
        """
        if not self._initialized:
            raise RuntimeError("엔진이 초기화되지 않았습니다 / Engine not initialized")

        self._logger.info(
            "실행+학습 시작: %s / Execute+learn started: %s",
            composite.composite_id,
            composite.composite_id,
        )

        experiences: List[PhysicalExperience] = []

        for i, primitive in enumerate(composite.primitives):
            # 실행 전 상태 / State before execution
            state_before = self._executor.get_current_state()

            # 프리미티브 실행 / Execute primitive
            result = self._executor.execute_primitive(primitive)

            # 실행 후 상태 / State after execution
            state_after = self._executor.get_current_state()

            # 보상 계산 / Compute reward
            reward = self._compute_reward(primitive, result, state_before, state_after)

            # 새로움 계산 / Compute novelty
            novelty = self._compute_novelty(primitive, result)

            # 경험 생성 / Create experience
            experience = PhysicalExperience(
                experience_id=_generate_id("exp"),
                action=primitive,
                result=result,
                state_before=state_before,
                state_after=state_after,
                reward=reward,
                novelty=novelty,
            )

            experiences.append(experience)
            self._experience_buffer.append(experience)

            # 데이터베이스에 저장 / Store in database
            self._db.store_experience(experience)

            # 비상 정지 시 중단 / Abort on emergency stop
            if result.status == ExecutionStatus.ABORTED:
                self._logger.warning(
                    "실행 중단 (비상 정지), %d/%d 완료 / "
                    "Execution aborted (emergency stop), %d/%d complete",
                    i + 1,
                    len(composite.primitives),
                    i + 1,
                    len(composite.primitives),
                )
                break

        # 복합 액션도 데이터베이스에 저장 / Store composite in database too
        self._db.store_composite(composite)

        self._logger.info(
            "실행+학습 완료: %d개 경험 수집 / Execute+learn complete: %d experiences collected",
            len(experiences),
            len(experiences),
        )
        return experiences

    def refine_from_experience(
        self,
        composite: CompositeAction,
        experience: List[PhysicalExperience],
    ) -> CompositeAction:
        """
        경험을 기반으로 복합 액션 개선 / Refine composite based on experience.

        실행 결과의 보상, 실패 패턴, 에너지 효율을 분석하여
        더 나은 액션 구성을 생성한다.

        Args:
            composite: 원본 복합 액션 / Original composite action
            experience: 수집된 경험 / Collected experiences

        Returns:
            CompositeAction: 개선된 복합 액션
        """
        if not experience:
            return composite

        self._logger.info(
            "경험 기반 개선 시작: %s (%d개 경험) / "
            "Experience-based refinement started: %s (%d experiences)",
            composite.composite_id,
            len(experience),
            composite.composite_id,
            len(experience),
        )

        # 경험 분석 / Analyze experiences
        avg_reward = np.mean([e.reward for e in experience])
        success_rate = np.mean(
            [1.0 if e.result.status == ExecutionStatus.SUCCESS else 0.0 for e in experience]
        )
        total_energy = sum(e.action.energy_cost for e in experience)

        self._logger.info(
            "경험 분석: avg_reward=%.3f, success_rate=%.2f, total_energy=%.1fJ / "
            "Experience analysis: avg_reward=%.3f, success_rate=%.2f, total_energy=%.1fJ",
            avg_reward,
            success_rate,
            total_energy,
            avg_reward,
            success_rate,
            total_energy,
        )

        # 개선 전략 선택 / Choose refinement strategy
        if avg_reward < 0.0:
            # 보상이 음수 → 큰 변이로 탈출 / Negative reward → large mutation to escape
            refined = self._mutator.mutate_composite(composite, mutation_rate=0.3)
            self._logger.info("큰 변이 적용 (부정 보상) / Large mutation applied (negative reward)")
        elif success_rate < 0.5:
            # 성공률 낮음 → 타이밍 조정 / Low success rate → adjust timing
            new_primitives = []
            for e in experience:
                if e.result.status != ExecutionStatus.SUCCESS:
                    # 실패한 액션의 타이밍 변이 / Mutate timing of failed actions
                    mutated = self._mutator.mutate_timing(e.action, sigma_ms=100)
                    new_primitives.append(mutated)
                else:
                    new_primitives.append(deepcopy(e.action))
            refined = CompositeAction(
                composite_id=_generate_id("comp_ref"),
                primitives=new_primitives,
                parallel_groups=deepcopy(composite.parallel_groups),
                transitions=[],
                total_duration_ms=0,
                total_energy_cost=0.0,
            )
            self._logger.info("타이밍 조정 적용 (낮은 성공률) / Timing adjustment applied (low success rate)")
        else:
            # 양호한 결과 → 미세 조정 / Good results → fine-tune
            refined = self._mutator.mutate_composite(composite, mutation_rate=0.05)
            self._logger.info("미세 변이 적용 (양호한 결과) / Fine mutation applied (good results)")

        # 순서 최적화 / Optimize ordering
        refined = self._composer.optimize_ordering(refined)

        self._logger.info(
            "개선 완료: %s → %s / Refinement complete: %s → %s",
            composite.composite_id,
            refined.composite_id,
            composite.composite_id,
            refined.composite_id,
        )
        return refined

    def discover_new_combinations(
        self, task_history: Optional[List[Dict[str, Any]]] = None
    ) -> List[CompositeAction]:
        """
        창의적 액션 조합 발견 / Creative action combination discovery.

        기존 경험과 과업 이력을 분석하여 새로운 프리미티브 조합을
        탐색한다. 이것이 Physical AGI의 창발적 행동의 원천이다.

        Emergent behavior source: exploring novel combinations of primitives
        that haven't been tried before.

        Args:
            task_history: 과업 이력 (선택적) / Task history (optional)

        Returns:
            List[CompositeAction]: 발견된 새로운 복합 액션들
        """
        if not self._initialized:
            raise RuntimeError("엔진이 초기화되지 않았습니다 / Engine not initialized")

        if task_history is None:
            task_history = self._task_history

        self._logger.info(
            "새로운 조합 탐색 시작 (이력: %d개) / "
            "New combination discovery started (history: %d)",
            len(task_history),
            len(task_history),
        )

        discoveries: List[CompositeAction] = []

        # 전략 1: 무작위 조합 / Strategy 1: Random combination
        random_composite = self._discover_random_combination()
        if random_composite:
            discoveries.append(random_composite)

        # 전략 2: 보상 기반 조합 / Strategy 2: Reward-based combination
        reward_composite = self._discover_reward_based_combination()
        if reward_composite:
            discoveries.append(reward_composite)

        # 전략 3: 교차 조합 / Strategy 3: Crossover combination
        crossover_composite = self._discover_crossover_combination()
        if crossover_composite:
            discoveries.append(crossover_composite)

        # 전략 4: 빈 공간 탐색 / Strategy 4: Gap exploration
        gap_composite = self._discover_gap_combination()
        if gap_composite:
            discoveries.append(gap_composite)

        self._logger.info(
            "새로운 조합 %d개 발견 / Discovered %d new combinations",
            len(discoveries),
            len(discoveries),
        )
        return discoveries

    # ========================================================================
    # 내부 헬퍼 메서드 / Internal helper methods
    # ========================================================================

    def _score_action_for_task(
        self,
        action: PrimitiveAction,
        task_keywords: List[str],
        current_state: RobotState,
    ) -> float:
        """
        과업 키워드에 대한 액션 관련성 점수 계산
        Compute action relevance score for task keywords.
        """
        score = 0.0

        # 이름 매칭 / Name matching
        action_words = action.name.lower().replace("_", " ").split()
        for keyword in task_keywords:
            for aw in action_words:
                if keyword in aw or aw in keyword:
                    score += 2.0

        # 카테고리 매칭 / Category matching
        category_keywords = {
            ActionCategory.LOCOMOTION: ["walk", "move", "go", "navigate", "이동", "걷기"],
            ActionCategory.MANIPULATION: ["pick", "grab", "push", "pull", "lift", "hold", "조작", "잡기"],
            ActionCategory.POSTURE: ["stand", "sit", "balance", "자세", "균형"],
            ActionCategory.HEAD: ["look", "see", "scan", "find", "바라", "찾기"],
        }
        cat_kw = category_keywords.get(action.category, [])
        for keyword in task_keywords:
            if keyword in cat_kw:
                score += 1.5

        # 사후조건 매칭 / Postcondition matching
        for keyword in task_keywords:
            for postcond in action.postconditions:
                if keyword in postcond.lower():
                    score += 1.0

        # 상태 적합성 / State suitability
        if not current_state.is_stable() and action.category == ActionCategory.POSTURE:
            if "stabilize" in action.name or "balance" in action.name:
                score += 3.0  # 불안정할 때 안정화 액션 가중

        # 위험도 페널티 / Risk penalty
        score -= action.risk_level * 0.5

        return max(0.0, score)

    @staticmethod
    def _estimate_task_complexity(keywords: List[str]) -> int:
        """
        과업 복잡도 추정 (1~5) / Estimate task complexity (1-5).
        """
        complexity_indicators = {
            "and": 1, "then": 1, "after": 1, "while": 2, "simultaneously": 2,
            "complex": 2, "carefully": 1, "quickly": 1, "multiple": 2,
        }
        complexity = 2  # 기본 복잡도 / Default complexity
        for kw in keywords:
            if kw in complexity_indicators:
                complexity += complexity_indicators[kw]
        return min(5, max(1, complexity))

    @staticmethod
    def _can_parallelize(primitives: List[PrimitiveAction]) -> bool:
        """
        프리미티브들이 병렬 실행 가능한지 확인
        Check if primitives can execute in parallel.
        """
        # 다른 신체 영역의 액션은 병렬 가능 / Different body regions can be parallel
        regions = set()
        region_map = {
            ActionCategory.LOCOMOTION: "legs",
            ActionCategory.MANIPULATION: "arms",
            ActionCategory.POSTURE: "torso",
            ActionCategory.HEAD: "head",
        }
        for p in primitives:
            region = region_map.get(p.category, "unknown")
            if region in regions:
                return False  # 같은 영역 중복 → 병렬 불가 / Same region overlap → can't parallelize
            regions.add(region)
        return True

    @staticmethod
    def _build_hybrid_plan(
        primitives: List[PrimitiveAction],
    ) -> List[Dict[str, Any]]:
        """
        혼합 실행 계획 구성 / Build hybrid execution plan.
        """
        # 카테고리별로 그룹화 / Group by category
        groups: Dict[ActionCategory, List[PrimitiveAction]] = {}
        for p in primitives:
            if p.category not in groups:
                groups[p.category] = []
            groups[p.category].append(p)

        plan: List[Dict[str, Any]] = []

        # HEAD를 먼저 (관찰) / HEAD first (observation)
        if ActionCategory.HEAD in groups:
            plan.append(
                {"type": "sequential", "primitives": groups[ActionCategory.HEAD]}
            )

        # POSTURE (준비) / POSTURE (preparation)
        if ActionCategory.POSTURE in groups:
            plan.append(
                {"type": "sequential", "primitives": groups[ActionCategory.POSTURE]}
            )

        # LOCOMOTION + MANIPULATION 병렬 가능 / LOCOMOTION + MANIPULATION can be parallel
        loco = groups.get(ActionCategory.LOCOMOTION, [])
        manip = groups.get(ActionCategory.MANIPULATION, [])

        if loco and manip:
            plan.append(
                {"type": "parallel", "primitives": loco + manip}
            )
        elif loco:
            plan.append({"type": "sequential", "primitives": loco})
        elif manip:
            plan.append({"type": "sequential", "primitives": manip})

        return plan

    def _compute_reward(
        self,
        action: PrimitiveAction,
        result: ExecutionResult,
        state_before: RobotState,
        state_after: RobotState,
    ) -> float:
        """
        보상 신호 계산 / Compute reward signal.

        성공, 에너지 효율, 속도, 안전성을 종합하여 보상을 계산한다.
        """
        # 성공 보상 / Success reward
        success_reward = (
            self._reward_weights["success"]
            if result.status == ExecutionStatus.SUCCESS
            else -0.5 if result.status == ExecutionStatus.FAILED
            else -0.2 if result.status == ExecutionStatus.PARTIAL
            else 0.0
        )

        # 에너지 효율 보상 / Energy efficiency reward
        if action.energy_cost > 0:
            energy_efficiency = 1.0 - (action.energy_cost / 50.0)  # 정규화
            energy_reward = energy_efficiency * self._reward_weights["energy_efficiency"]
        else:
            energy_reward = 0.3

        # 속도 보상 / Speed reward
        if action.duration_ms > 0:
            speed_ratio = result.duration_actual_ms / action.duration_ms
            speed_reward = (1.0 - min(speed_ratio, 2.0) / 2.0) * self._reward_weights["speed"]
        else:
            speed_reward = 0.0

        # 안전 보상 / Safety reward
        balance_delta = state_after.balance_score - state_before.balance_score
        safety_reward = (
            (1.0 - action.risk_level) * self._reward_weights["safety"]
            + balance_delta * 0.5
        )

        # 종합 보상 / Total reward
        total = success_reward + energy_reward + speed_reward + safety_reward
        return round(max(-1.0, min(1.0, total)), 4)

    def _compute_novelty(
        self, action: PrimitiveAction, result: ExecutionResult
    ) -> float:
        """
        새로움 점수 계산 / Compute novelty score.

        과거 경험과의 유사도를 비교하여 새로움을 평가한다.
        완전히 새로운 파라미터 조합일수록 높은 새로움 점수.
        """
        # 데이터베이스에서 같은 액션 이름의 과거 경험 검색
        # Search past experiences with same action name
        past_experiences = self._db.get_experiences_by_action_name(action.name, limit=20)

        if not past_experiences:
            return 1.0  # 처음 실행하는 액션 = 최대 새로움 / First execution = max novelty

        # 파라미터 유사도 계산 / Compute parameter similarity
        min_distance = float("inf")
        for past in past_experiences:
            try:
                past_action_data = json.loads(past["action_json"])
                past_params = past_action_data.get("parameters", {})
                # 유클리디안 거리 / Euclidean distance
                all_keys = set(action.parameters.keys()) | set(past_params.keys())
                distance = 0.0
                for key in all_keys:
                    val_a = action.parameters.get(key, 0.0)
                    val_b = past_params.get(key, 0.0)
                    distance += (val_a - val_b) ** 2
                distance = math.sqrt(distance)
                min_distance = min(min_distance, distance)
            except (json.JSONDecodeError, KeyError):
                continue

        # 거리를 새로움으로 변환 (거리가 멀수록 새로움)
        # Convert distance to novelty (further = more novel)
        if min_distance == float("inf"):
            return 1.0

        # 시그모이드 변환 / Sigmoid transformation
        novelty = 1.0 / (1.0 + math.exp(-2.0 * (min_distance - 1.0)))
        return round(novelty, 4)

    def _discover_random_combination(self) -> Optional[CompositeAction]:
        """
        무작위 조합 발견 / Discover random combination.
        무작위로 2~5개 프리미티브를 선택하여 복합 액션 생성.
        """
        all_actions = list(self._primitives.values())
        if len(all_actions) < 2:
            return None

        n = np.random.randint(2, min(6, len(all_actions) + 1))
        indices = np.random.choice(len(all_actions), size=n, replace=False)
        selected = [all_actions[i] for i in indices]

        return self._composer.compose_sequential(selected)

    def _discover_reward_based_combination(self) -> Optional[CompositeAction]:
        """
        보상 기반 조합 발견 / Discover reward-based combination.
        과거에 높은 보상을 받은 액션들을 조합.
        """
        top_experiences = self._db.get_top_rewarded_experiences(limit=10)
        if len(top_experiences) < 2:
            return None

        actions: List[PrimitiveAction] = []
        seen_names: Set[str] = set()
        for exp in top_experiences:
            try:
                action_data = json.loads(exp["action_json"])
                name = action_data.get("name", "")
                if name not in seen_names and name in self._name_index:
                    action_id = self._name_index[name]
                    actions.append(deepcopy(self._primitives[action_id]))
                    seen_names.add(name)
            except (json.JSONDecodeError, KeyError):
                continue

        if len(actions) < 2:
            return None

        return self._composer.compose_sequential(actions[:4])

    def _discover_crossover_combination(self) -> Optional[CompositeAction]:
        """
        교차 조합 발견 / Discover crossover combination.
        다른 카테고리의 액션을 교차시켜 새로운 조합 생성.
        """
        categories = [
            ActionCategory.LOCOMOTION,
            ActionCategory.MANIPULATION,
            ActionCategory.POSTURE,
            ActionCategory.HEAD,
        ]

        actions: List[PrimitiveAction] = []
        for cat in categories:
            cat_ids = self._category_index.get(cat, [])
            if cat_ids:
                chosen_id = cat_ids[np.random.randint(len(cat_ids))]
                actions.append(deepcopy(self._primitives[chosen_id]))

        if len(actions) < 2:
            return None

        # 각 액션을 약간 변이 / Slightly mutate each action
        mutated = [self._mutator.mutate_parameters(a, sigma=0.05) for a in actions]

        return self._composer.compose_sequential(mutated)

    def _discover_gap_combination(self) -> Optional[CompositeAction]:
        """
        빈 공간 탐색 조합 / Gap exploration combination.
        실행 이력이 적은 액션 조합을 탐색.
        """
        avg_rewards = self._db.get_avg_reward_by_action()

        # 보상이 낮거나 경험이 없는 액션 우선 탐색
        # Prioritize actions with low reward or no experience
        underexplored: List[PrimitiveAction] = []
        for action in self._primitives.values():
            if action.name not in avg_rewards:
                underexplored.append(action)
            elif avg_rewards[action.name] < 0.0:
                underexplored.append(action)

        if len(underexplored) < 2:
            # 모든 액션이 충분히 탐색됨 → 무작위 선택
            all_actions = list(self._primitives.values())
            indices = np.random.choice(len(all_actions), size=min(3, len(all_actions)), replace=False)
            underexplored = [all_actions[i] for i in indices]

        return self._composer.compose_sequential(underexplored[:4])

    # ========================================================================
    # 공개 유틸리티 / Public utilities
    # ========================================================================

    def get_primitive_by_name(self, name: str) -> Optional[PrimitiveAction]:
        """이름으로 프리미티브 조회 / Lookup primitive by name."""
        action_id = self._name_index.get(name)
        if action_id:
            return self._primitives.get(action_id)
        return None

    def get_primitive_by_id(self, action_id: str) -> Optional[PrimitiveAction]:
        """ID로 프리미티브 조회 / Lookup primitive by ID."""
        return self._primitives.get(action_id)

    def get_primitives_by_category(
        self, category: ActionCategory
    ) -> List[PrimitiveAction]:
        """카테고리로 프리미티브 조회 / Lookup primitives by category."""
        ids = self._category_index.get(category, [])
        return [self._primitives[aid] for aid in ids if aid in self._primitives]

    def get_experience_count(self) -> int:
        """저장된 경험 수 / Stored experience count."""
        return self._db.get_experience_count()

    def get_robot_state(self) -> RobotState:
        """현재 로봇 상태 / Current robot state."""
        return self._executor.get_current_state()

    def emergency_stop(self) -> None:
        """비상 정지 / Emergency stop."""
        self._executor.emergency_stop()

    def release_emergency_stop(self) -> None:
        """비상 정지 해제 / Release emergency stop."""
        self._executor.release_emergency_stop()

    @property
    def composer(self) -> ActionComposer:
        """액션 컴포저 접근 / Access action composer."""
        return self._composer

    @property
    def mutator(self) -> ActionMutator:
        """액션 뮤테이터 접근 / Access action mutator."""
        return self._mutator

    @property
    def executor(self) -> ActionExecutor:
        """액션 익스큐터 접근 / Access action executor."""
        return self._executor

    @property
    def primitives(self) -> Dict[str, PrimitiveAction]:
        """모든 프리미티브 접근 / Access all primitives."""
        return self._primitives

    def get_statistics(self) -> Dict[str, Any]:
        """
        엔진 통계 반환 / Return engine statistics.
        """
        return {
            "total_primitives": len(self._primitives),
            "locomotion_count": len(self._category_index.get(ActionCategory.LOCOMOTION, [])),
            "manipulation_count": len(self._category_index.get(ActionCategory.MANIPULATION, [])),
            "posture_count": len(self._category_index.get(ActionCategory.POSTURE, [])),
            "head_count": len(self._category_index.get(ActionCategory.HEAD, [])),
            "experience_count": self._db.get_experience_count(),
            "primitive_db_count": self._db.get_primitive_count(),
            "buffer_size": len(self._experience_buffer),
            "task_history_count": len(self._task_history),
            "initialized": self._initialized,
            "robot_stable": self._executor.get_current_state().is_stable(),
            "battery_level": self._executor.get_current_state().battery_level,
        }


# ============================================================================
# V8.5 액션 임베딩 / V8.5 Action Embedding
# ============================================================================


class ActionEmbedding:
    """
    프리미티브 액션을 64차원 임베딩 벡터로 인코딩
    Encode any primitive action into a 64-dimensional embedding vector.

    임베딩 구조 / Embedding structure (64-dim total):
        - category_onehot(5):  액션 카테고리 원핫 / Category one-hot
        - param_hash(16):      파라미터 해시 / Parameter hash
        - duration_norm(1):    정규화된 실행 시간 / Normalized duration
        - energy_norm(1):      정규화된 에너지 비용 / Normalized energy cost
        - risk_norm(1):        정규화된 위험도 / Normalized risk level
        - learned_proj(40):    학습된 투영 / Learned projection

    V8.5: 하드코딩된 프리미티브가 아닌, 어떤 액션이든 임베딩 가능.
    V8.5: Not hardcoded presets—any action can be embedded.
    """

    # 카테고리 원핫 매핑 / Category one-hot mapping
    _CATEGORY_MAP: Dict[ActionCategory, int] = {
        ActionCategory.LOCOMOTION: 0,
        ActionCategory.MANIPULATION: 1,
        ActionCategory.POSTURE: 2,
        ActionCategory.HEAD: 3,
        ActionCategory.COMPOSITE: 4,
    }

    # 정규화 상수 / Normalization constants
    _MAX_DURATION_MS: float = 10000.0
    _MAX_ENERGY_COST: float = 100.0

    def __init__(self, seed: Optional[int] = 42) -> None:
        self._logger = logging.getLogger("primitive_action_engine.ActionEmbedding")
        self._rng = np.random.default_rng(seed)
        # 학습된 투영 행렬 (초기화: Xavier 초기화)
        # Learned projection matrix (Xavier initialization)
        self._projection_matrix: np.ndarray = self._rng.normal(
            0, np.sqrt(2.0 / (23 + 40)), size=(23, 40)
        ).astype(np.float32)
        self._embedding_cache: Dict[str, np.ndarray] = {}

    def encode(self, action: PrimitiveAction) -> np.ndarray:
        """
        프리미티브 액션을 64차원 임베딩으로 인코딩
        Encode a primitive action into a 64-dim embedding.

        Args:
            action: 인코딩할 프리미티브 액션 / Primitive action to encode

        Returns:
            np.ndarray: 64차원 임베딩 벡터 / 64-dim embedding vector
        """
        # 캐시 확인 / Check cache
        if action.action_id in self._embedding_cache:
            return self._embedding_cache[action.action_id].copy()

        # 1) 카테고리 원핫 (5-dim)
        category_onehot = np.zeros(5, dtype=np.float32)
        cat_idx = self._CATEGORY_MAP.get(action.category, 4)
        category_onehot[cat_idx] = 1.0

        # 2) 파라미터 해시 (16-dim)
        param_hash = self._hash_parameters(action.parameters)

        # 3) 지속 시간 정규화 (1-dim)
        duration_norm = np.array(
            [min(action.duration_ms / self._MAX_DURATION_MS, 1.0)],
            dtype=np.float32,
        )

        # 4) 에너지 비용 정규화 (1-dim)
        energy_norm = np.array(
            [min(action.energy_cost / self._MAX_ENERGY_COST, 1.0)],
            dtype=np.float32,
        )

        # 5) 위험도 정규화 (1-dim) — 이미 0~1 범위
        risk_norm = np.array([action.risk_level], dtype=np.float32)

        # 결합: 5 + 16 + 1 + 1 + 1 = 24-dim (23은 오타 수정: 실제 24)
        # 수동 특성 벡터 / Manual feature vector
        manual_features = np.concatenate([
            category_onehot,   # 5
            param_hash,        # 16
            duration_norm,     # 1
            energy_norm,       # 1
            risk_norm,         # 1
        ])  # 총 24-dim

        # 6) 학습된 투영 (24 → 40-dim) — manual_features[:23]을 투영
        #    실제로는 24-dim 전체를 사용하도록 투영 행렬 재조정
        # Learned projection: adjust projection matrix to accept 24-dim input
        if self._projection_matrix.shape[0] != len(manual_features):
            self._projection_matrix = self._rng.normal(
                0, np.sqrt(2.0 / (len(manual_features) + 40)),
                size=(len(manual_features), 40),
            ).astype(np.float32)

        learned_proj = manual_features @ self._projection_matrix  # (24,) @ (24,40) → (40,)
        learned_proj = np.tanh(learned_proj)  # 활성화 함수 / Activation

        # 최종 임베딩: 24 + 40 = 64-dim
        embedding = np.concatenate([manual_features, learned_proj]).astype(np.float32)

        # L2 정규화 / L2 normalization
        norm = np.linalg.norm(embedding)
        if norm > 1e-8:
            embedding = embedding / norm

        self._embedding_cache[action.action_id] = embedding.copy()
        return embedding

    def _hash_parameters(self, parameters: Dict[str, float]) -> np.ndarray:
        """
        파라미터 딕셔너리를 16차원 해시 벡터로 변환
        Hash parameter dictionary into a 16-dim vector.

        파라미터 키의 해시와 값을 결합하여 결정론적이지만
        분산이 좋은 벡터를 생성한다.
        """
        hash_vec = np.zeros(16, dtype=np.float32)
        if not parameters:
            return hash_vec

        for i, (key, value) in enumerate(parameters.items()):
            # 키 해시로 오프셋 결정 / Key hash determines offset
            key_hash = hash(key) % 16
            # 값을 [-1, 1] 범위로 변환 / Map value to [-1, 1]
            mapped_val = np.tanh(value / 10.0)
            # 해시 위치에 값 추가 (여러 파라미터가 같은 슬롯에 매핑되면 누적)
            # Add value at hash position (accumulate if multiple params map to same slot)
            hash_vec[key_hash] += mapped_val
            # 두 번째 해시로 다른 슬롯에도 분산 / Second hash for dispersion
            key_hash2 = (hash(key) // 16) % 16
            hash_vec[key_hash2] += mapped_val * 0.5

        # 정규화 / Normalize
        max_val = np.max(np.abs(hash_vec))
        if max_val > 1e-8:
            hash_vec = hash_vec / max_val

        return hash_vec

    @staticmethod
    def compute_similarity(a: PrimitiveAction, b: PrimitiveAction) -> float:
        """
        두 액션의 임베딩 간 코사인 유사도 계산
        Compute cosine similarity between embeddings of two actions.

        Args:
            a: 첫 번째 액션 / First action
            b: 두 번째 액션 / Second action

        Returns:
            float: 코사인 유사도 [-1, 1] / Cosine similarity [-1, 1]
        """
        embedder = ActionEmbedding()
        emb_a = embedder.encode(a)
        emb_b = embedder.encode(b)
        dot = np.dot(emb_a, emb_b)
        norm_a = np.linalg.norm(emb_a)
        norm_b = np.linalg.norm(emb_b)
        if norm_a < 1e-8 or norm_b < 1e-8:
            return 0.0
        return float(dot / (norm_a * norm_b))

    def find_similar(
        self,
        action: PrimitiveAction,
        action_pool: List[PrimitiveAction],
        k: int = 5,
    ) -> List[Tuple[PrimitiveAction, float]]:
        """
        액션 풀에서 가장 유사한 k개의 액션 검색
        Find k most similar actions from a pool.

        Args:
            action: 쿼리 액션 / Query action
            action_pool: 검색할 액션 풀 / Action pool to search
            k: 반환할 액션 수 / Number of actions to return

        Returns:
            List of (PrimitiveAction, similarity_score) tuples, sorted by similarity descending
        """
        query_emb = self.encode(action)
        similarities: List[Tuple[PrimitiveAction, float]] = []

        for candidate in action_pool:
            if candidate.action_id == action.action_id:
                continue
            cand_emb = self.encode(candidate)
            dot = np.dot(query_emb, cand_emb)
            norm_q = np.linalg.norm(query_emb)
            norm_c = np.linalg.norm(cand_emb)
            if norm_q < 1e-8 or norm_c < 1e-8:
                sim = 0.0
            else:
                sim = float(dot / (norm_q * norm_c))
            similarities.append((candidate, sim))

        similarities.sort(key=lambda x: x[1], reverse=True)
        return similarities[:k]

    def cluster_actions(
        self,
        actions: List[PrimitiveAction],
        n_clusters: int = 8,
    ) -> Dict[int, List[PrimitiveAction]]:
        """
        임베딩 기반 K-평균 클러스터링
        K-means clustering on action embeddings.

        Args:
            actions: 클러스터링할 액션 리스트 / Actions to cluster
            n_clusters: 클러스터 수 / Number of clusters

        Returns:
            Dict[cluster_id, List[PrimitiveAction]]: 클러스터별 액션 매핑
        """
        if len(actions) == 0:
            return {}

        # 임베딩 행렬 구성 / Build embedding matrix
        embeddings = np.array([self.encode(a) for a in actions])

        # K-평균 구현 (sklearn 의존성 방지) / K-means implementation (no sklearn dependency)
        n_samples = len(actions)
        actual_k = min(n_clusters, n_samples)

        # 초기 중심 랜덤 선택 / Random initial centroid selection
        initial_indices = self._rng.choice(n_samples, size=actual_k, replace=False)
        centroids = embeddings[initial_indices].copy()

        # K-평균 반복 / K-means iterations
        max_iter = 50
        assignments = np.zeros(n_samples, dtype=int)

        for _ in range(max_iter):
            # 할당 단계 / Assignment step
            new_assignments = np.zeros(n_samples, dtype=int)
            for i in range(n_samples):
                distances = np.linalg.norm(embeddings[i] - centroids, axis=1)
                new_assignments[i] = int(np.argmin(distances))

            # 수렴 확인 / Check convergence
            if np.array_equal(assignments, new_assignments):
                break
            assignments = new_assignments

            # 업데이트 단계 / Update step
            for c in range(actual_k):
                members = embeddings[assignments == c]
                if len(members) > 0:
                    centroids[c] = members.mean(axis=0)

        # 결과 구성 / Build result
        clusters: Dict[int, List[PrimitiveAction]] = {}
        for i, cluster_id in enumerate(assignments):
            cid = int(cluster_id)
            if cid not in clusters:
                clusters[cid] = []
            clusters[cid].append(actions[i])

        self._logger.info(
            "액션 %d개를 %d개 클러스터로 분할 / Clustered %d actions into %d clusters",
            len(actions), len(clusters), len(actions), len(clusters),
        )
        return clusters


# ============================================================================
# V8.5 프리미티브 공간 / V8.5 Primitive Space
# ============================================================================


class PrimitiveSpace:
    """
    연속적 프리미티브 액션 공간 - 발견 가능한 프리미티브를 위한
    Continuous action space for discoverable primitives.

    하드코딩된 프리셋이 아님. 액션은 탐색을 통해 발견될 수 있다.
    NOT hardcoded. Actions can be DISCOVERED through exploration.

    V8.5 철학: 프리미티브는 미리 정해진 것이 아니라,
    로봇이 환경과 상호작용하며 발견하고 학습하는 것이다.
    V8.5 philosophy: primitives are not predetermined—they are discovered
    and learned through robot-environment interaction.
    """

    # 카테고리별 파라미터 범위 정의 / Parameter bounds per category
    DEFAULT_PARAMETER_BOUNDS: Dict[str, Dict[str, Tuple[float, float]]] = {
        ActionCategory.LOCOMOTION.value: {
            "speed": (0.0, 3.0),
            "angle": (-180.0, 180.0),
            "distance": (0.0, 2.0),
            "height": (0.0, 0.5),
            "direction": (-180.0, 180.0),
            "target_speed": (0.0, 3.0),
            "ramp_time_ms": (100.0, 2000.0),
        },
        ActionCategory.MANIPULATION.value: {
            "force": (0.0, 50.0),
            "speed": (0.0, 5.0),
            "angle": (-180.0, 180.0),
            "height": (0.0, 1.0),
            "depth": (0.0, 0.5),
            "direction": (-180.0, 180.0),
            "distance": (0.0, 1.0),
            "x": (-1.0, 1.0),
            "y": (-1.0, 1.0),
            "z": (-0.5, 1.5),
            "open_speed": (0.0, 2.0),
        },
        ActionCategory.POSTURE.value: {
            "height": (0.0, 0.5),
            "angle": (-45.0, 45.0),
            "depth": (0.0, 0.5),
            "direction": (-180.0, 180.0),
            "amount": (0.0, 1.0),
            "target_balance": (0.0, 1.0),
            "dx": (-0.3, 0.3),
            "dy": (-0.3, 0.3),
        },
        ActionCategory.HEAD.value: {
            "x": (-5.0, 5.0),
            "y": (-5.0, 5.0),
            "z": (-5.0, 5.0),
            "angle": (-90.0, 90.0),
            "pattern": (0.0, 2.0),
            "object_id": (0.0, 100.0),
            "meters": (0.1, 10.0),
            "reps": (1.0, 5.0),
        },
    }

    # 카테고리별 기본 파라미터 키 / Default parameter keys per category
    _CATEGORY_PARAM_KEYS: Dict[ActionCategory, List[str]] = {
        ActionCategory.LOCOMOTION: ["speed", "angle"],
        ActionCategory.MANIPULATION: ["force", "speed"],
        ActionCategory.POSTURE: ["angle", "height"],
        ActionCategory.HEAD: ["angle"],
    }

    # 카테고리별 기본 메타 범위 / Default meta ranges per category
    _CATEGORY_META_RANGES: Dict[ActionCategory, Dict[str, Tuple[float, float]]] = {
        ActionCategory.LOCOMOTION: {
            "duration_ms": (200, 5000),
            "energy_cost": (3.0, 50.0),
            "risk_level": (0.01, 0.5),
        },
        ActionCategory.MANIPULATION: {
            "duration_ms": (100, 2000),
            "energy_cost": (0.5, 20.0),
            "risk_level": (0.01, 0.4),
        },
        ActionCategory.POSTURE: {
            "duration_ms": (200, 1500),
            "energy_cost": (1.0, 15.0),
            "risk_level": (0.01, 0.3),
        },
        ActionCategory.HEAD: {
            "duration_ms": (100, 2000),
            "energy_cost": (0.2, 5.0),
            "risk_level": (0.0, 0.05),
        },
    }

    def __init__(
        self,
        parameter_bounds: Optional[Dict[str, Dict[str, Tuple[float, float]]]] = None,
        seed: Optional[int] = None,
    ) -> None:
        self._logger = logging.getLogger("primitive_action_engine.PrimitiveSpace")
        self._rng = np.random.default_rng(seed)

        # 파라미터 범위 (커스텀 또는 기본값) / Parameter bounds (custom or default)
        self.parameter_bounds: Dict[str, Dict[str, Tuple[float, float]]] = (
            parameter_bounds if parameter_bounds is not None
            else deepcopy(self.DEFAULT_PARAMETER_BOUNDS)
        )

        # 발견된 프리미티브 저장소 / Discovered primitives store
        self._discovered: Dict[str, PrimitiveAction] = {}

        self._logger.info(
            "프리미티브 공간 초기화 (범위: %d 카테고리) / "
            "Primitive space initialized (bounds: %d categories)",
            len(self.parameter_bounds),
            len(self.parameter_bounds),
        )

    def sample_random(self, category: ActionCategory) -> PrimitiveAction:
        """
        연속 공간에서 무작위 프리미티브 샘플링
        Sample a RANDOM primitive from continuous space.

        하드코딩된 프리셋이 아닌, 파라미터 범위 내에서
        무작위로 프리미티브를 생성한다. 이것이 V8.5의 핵심이다.

        Args:
            category: 액션 카테고리 / Action category

        Returns:
            PrimitiveAction: 무작위로 샘플링된 프리미티브
        """
        cat_key = category.value
        bounds = self.parameter_bounds.get(cat_key, {})

        # 파라미터 샘플링 / Sample parameters
        param_keys = self._CATEGORY_PARAM_KEYS.get(category, ["value"])
        parameters: Dict[str, float] = {}

        for key in param_keys:
            if key in bounds:
                low, high = bounds[key]
                parameters[key] = round(float(self._rng.uniform(low, high)), 4)
            else:
                # 범위에 없는 키는 기본 범위 사용 / Use default range for unknown keys
                parameters[key] = round(float(self._rng.uniform(0.0, 1.0)), 4)

        # 메타 파라미터 샘플링 / Sample meta parameters
        meta_ranges = self._CATEGORY_META_RANGES.get(category, {
            "duration_ms": (200, 3000),
            "energy_cost": (1.0, 20.0),
            "risk_level": (0.01, 0.3),
        })

        duration_ms = int(self._rng.uniform(
            meta_ranges["duration_ms"][0], meta_ranges["duration_ms"][1]
        ))
        energy_cost = round(float(self._rng.uniform(
            meta_ranges["energy_cost"][0], meta_ranges["energy_cost"][1]
        )), 2)
        risk_level = round(float(self._rng.uniform(
            meta_ranges["risk_level"][0], meta_ranges["risk_level"][1]
        )), 4)
        risk_level = min(1.0, max(0.0, risk_level))

        action = PrimitiveAction(
            action_id=_generate_id("disc"),
            category=category,
            name=f"discovered_{category.value}_{uuid.uuid4().hex[:6]}",
            parameters=parameters,
            duration_ms=duration_ms,
            preconditions=[],
            postconditions=[],
            energy_cost=energy_cost,
            risk_level=risk_level,
        )

        # 발견된 프리미티브 저장 / Store discovered primitive
        self._discovered[action.action_id] = action

        self._logger.debug(
            "무작위 프리미티브 샘플링: %s / Random primitive sampled: %s",
            action.summary(), action.summary(),
        )
        return action

    def interpolate(
        self,
        a: PrimitiveAction,
        b: PrimitiveAction,
        t: float,
    ) -> PrimitiveAction:
        """
        두 프리미티브 사이를 부드럽게 보간
        Smoothly interpolate between two primitives.

        Args:
            a: 시작 프리미티브 / Start primitive
            b: 끝 프리미티브 / End primitive
            t: 보간 파라미터 [0, 1] / Interpolation parameter [0, 1]

        Returns:
            PrimitiveAction: 보간된 프리미티브 / Interpolated primitive
        """
        t = max(0.0, min(1.0, t))

        # 카테고리가 다르면 t가 0.5 이하면 a, 초과면 b의 카테고리 사용
        # If different categories, use a's category for t<=0.5, b's for t>0.5
        category = a.category if t <= 0.5 else b.category

        # 파라미터 보간 / Interpolate parameters
        all_keys = set(a.parameters.keys()) | set(b.parameters.keys())
        interp_params: Dict[str, float] = {}
        for key in all_keys:
            val_a = a.parameters.get(key, 0.0)
            val_b = b.parameters.get(key, 0.0)
            interp_params[key] = round(val_a * (1 - t) + val_b * t, 4)

        # 메타 파라미터 보간 / Interpolate meta parameters
        interp_duration = int(a.duration_ms * (1 - t) + b.duration_ms * t)
        interp_energy = round(a.energy_cost * (1 - t) + b.energy_cost * t, 2)
        interp_risk = round(a.risk_level * (1 - t) + b.risk_level * t, 4)
        interp_risk = min(1.0, max(0.0, interp_risk))

        # 이름 보간 / Interpolate name
        name = f"interp_{a.name}_x_{b.name}" if a.name != b.name else a.name

        # 사전/사후조건 병합 / Merge pre/postconditions
        preconditions = list(set(a.preconditions) | set(b.preconditions))
        postconditions = list(set(a.postconditions) | set(b.postconditions))

        interpolated = PrimitiveAction(
            action_id=_generate_id("interp"),
            category=category,
            name=name,
            parameters=interp_params,
            duration_ms=max(50, interp_duration),
            preconditions=preconditions,
            postconditions=postconditions,
            energy_cost=interp_energy,
            risk_level=interp_risk,
        )

        self._discovered[interpolated.action_id] = interpolated
        return interpolated

    def extrapolate(
        self,
        a: PrimitiveAction,
        b: PrimitiveAction,
        t: float,
    ) -> PrimitiveAction:
        """
        두 프리미티브 너머로 외삽
        Extrapolate beyond two primitives.

        t=0이면 a, t=1이면 b, t>1이면 b 너머로 외삽.
        t=0 → a, t=1 → b, t>1 → extrapolate beyond b.

        Args:
            a: 기준 프리미티브 / Reference primitive
            b: 방향 프리미티브 / Direction primitive
            t: 외삽 파라미터 / Extrapolation parameter

        Returns:
            PrimitiveAction: 외삽된 프리미티브 / Extrapolated primitive
        """
        # 방향 벡터: b - a / Direction vector: b - a
        all_keys = set(a.parameters.keys()) | set(b.parameters.keys())
        extrap_params: Dict[str, float] = {}
        for key in all_keys:
            val_a = a.parameters.get(key, 0.0)
            val_b = b.parameters.get(key, 0.0)
            # 선형 외삽: a + t * (b - a) = a * (1-t) + b * t
            extrap_val = val_a * (1 - t) + val_b * t

            # 파라미터 범위 내로 클리핑 / Clip to parameter bounds
            cat_key = b.category.value
            bounds = self.parameter_bounds.get(cat_key, {})
            if key in bounds:
                low, high = bounds[key]
                extrap_val = max(low, min(high, extrap_val))

            extrap_params[key] = round(float(extrap_val), 4)

        # 메타 외삽 / Meta extrapolation
        extrap_duration = int(a.duration_ms * (1 - t) + b.duration_ms * t)
        extrap_energy = a.energy_cost * (1 - t) + b.energy_cost * t
        extrap_risk = a.risk_level * (1 - t) + b.risk_level * t

        # 안전 클리핑 / Safety clipping
        extrap_duration = max(50, extrap_duration)
        extrap_energy = max(0.1, extrap_energy)
        extrap_risk = min(1.0, max(0.0, extrap_risk))

        # 높은 외삽(t>1)일수록 위험도 증가 / Higher extrapolation → higher risk
        if t > 1.0:
            extrap_risk = min(1.0, extrap_risk + (t - 1.0) * 0.1)

        name = f"extrap_{a.name}_to_{b.name}"

        extrapolated = PrimitiveAction(
            action_id=_generate_id("extrap"),
            category=b.category,
            name=name,
            parameters=extrap_params,
            duration_ms=extrap_duration,
            preconditions=list(b.preconditions),
            postconditions=list(b.postconditions),
            energy_cost=round(extrap_energy, 2),
            risk_level=round(extrap_risk, 4),
        )

        self._discovered[extrapolated.action_id] = extrapolated
        return extrapolated

    def discover_from_experience(
        self,
        successful_experiences: List[PhysicalExperience],
    ) -> List[PrimitiveAction]:
        """
        성공적인 경험 패턴에서 새로운 프리미티브 발견
        Discover NEW primitives from successful experience patterns.

        성공한 경험들의 공통 패턴을 추출하여 새로운 프리미티브를
        생성한다. 이것이 V8.5의 핵심: 경험 기반 발견.

        Args:
            successful_experiences: 성공적인 경험 리스트 / List of successful experiences

        Returns:
            List[PrimitiveAction]: 발견된 새로운 프리미티브들
        """
        if not successful_experiences:
            return []

        # 성공한 경험만 필터 / Filter only successful experiences
        successes = [
            e for e in successful_experiences
            if e.result.status == ExecutionStatus.SUCCESS
        ]

        if len(successes) < 2:
            self._logger.info(
                "발견에 필요한 성공 경험 부족 (%d개, 최소 2개 필요) / "
                "Insufficient successful experiences for discovery (%d, need at least 2)",
                len(successes), len(successes),
            )
            return []

        # 카테고리별 그룹화 / Group by category
        category_groups: Dict[ActionCategory, List[PhysicalExperience]] = {}
        for exp in successes:
            cat = exp.action.category
            if cat not in category_groups:
                category_groups[cat] = []
            category_groups[cat].append(exp)

        discovered: List[PrimitiveAction] = []

        for category, experiences in category_groups.items():
            if len(experiences) < 2:
                continue

            # 전략 1: 평균화 발견 — 성공한 액션들의 평균 파라미터
            # Strategy 1: Averaging discovery — average parameters of successful actions
            avg_params: Dict[str, float] = {}
            param_counts: Dict[str, int] = {}
            for exp in experiences:
                for key, val in exp.action.parameters.items():
                    avg_params[key] = avg_params.get(key, 0.0) + val
                    param_counts[key] = param_counts.get(key, 0) + 1
            for key in avg_params:
                avg_params[key] = round(avg_params[key] / param_counts[key], 4)

            avg_duration = int(np.mean([e.action.duration_ms for e in experiences]))
            avg_energy = round(float(np.mean([e.action.energy_cost for e in experiences])), 2)
            avg_risk = round(float(np.mean([e.action.risk_level for e in experiences])), 4)
            avg_risk = min(1.0, max(0.0, avg_risk))

            avg_action = PrimitiveAction(
                action_id=_generate_id("disc_avg"),
                category=category,
                name=f"discovered_avg_{category.value}_{uuid.uuid4().hex[:6]}",
                parameters=avg_params,
                duration_ms=avg_duration,
                preconditions=[],
                postconditions=[f"discovered_{category.value}_pattern"],
                energy_cost=avg_energy,
                risk_level=avg_risk,
            )
            discovered.append(avg_action)
            self._discovered[avg_action.action_id] = avg_action

            # 전략 2: 최적 파라미터 발견 — 보상이 가장 높은 경험의 파라미터 기반
            # Strategy 2: Optimal parameter discovery — based on highest-reward experience
            best_exp = max(experiences, key=lambda e: e.reward)
            best_params = dict(best_exp.action.parameters)

            # 보상이 높은 경험들의 파라미터로 약간 조정
            # Slightly adjust with parameters from high-reward experiences
            high_reward = [e for e in experiences if e.reward > 0.5]
            if high_reward:
                for key in best_params:
                    values = [
                        e.action.parameters.get(key, best_params[key])
                        for e in high_reward
                        if key in e.action.parameters
                    ]
                    if values:
                        # 가중 평균 (보상 가중) / Weighted average (reward-weighted)
                        weights = [e.reward for e in high_reward if key in e.action.parameters]
                        if sum(weights) > 0:
                            best_params[key] = round(
                                sum(v * w for v, w in zip(values, weights)) / sum(weights), 4
                            )

            optimal_action = PrimitiveAction(
                action_id=_generate_id("disc_opt"),
                category=category,
                name=f"discovered_opt_{category.value}_{uuid.uuid4().hex[:6]}",
                parameters=best_params,
                duration_ms=best_exp.action.duration_ms,
                preconditions=[],
                postconditions=[f"optimal_{category.value}_pattern"],
                energy_cost=best_exp.action.energy_cost,
                risk_level=best_exp.action.risk_level,
            )
            discovered.append(optimal_action)
            self._discovered[optimal_action.action_id] = optimal_action

            # 전략 3: 외삽 발견 — 가장 좋은 두 경험의 방향으로 외삽
            # Strategy 3: Extrapolation discovery — extrapolate in direction of top two
            sorted_exps = sorted(experiences, key=lambda e: e.reward, reverse=True)
            if len(sorted_exps) >= 2:
                extrap = self.extrapolate(
                    sorted_exps[1].action,
                    sorted_exps[0].action,
                    t=1.2,  # 약간 너머로 / Slightly beyond
                )
                extrap.name = f"discovered_ext_{category.value}_{uuid.uuid4().hex[:6]}"
                discovered.append(extrap)

        self._logger.info(
            "경험 기반 프리미티브 %d개 발견 / Discovered %d primitives from experience",
            len(discovered), len(discovered),
        )
        return discovered

    def prune_unused(
        self,
        usage_counts: Dict[str, int],
        threshold: int = 3,
    ) -> None:
        """
        사용되지 않는 발견된 프리미티브 제거
        Remove unused discovered primitives.

        Args:
            usage_counts: 액션 ID별 사용 횟수 / Usage counts per action ID
            threshold: 미사용 임계값 (이 횟수 미만이면 제거) / Usage threshold
        """
        to_remove: List[str] = []
        for action_id in self._discovered:
            count = usage_counts.get(action_id, 0)
            if count < threshold:
                to_remove.append(action_id)

        for action_id in to_remove:
            del self._discovered[action_id]

        self._logger.info(
            "미사용 프리미티브 %d개 제거 (임계값=%d, 잔여=%d) / "
            "Pruned %d unused primitives (threshold=%d, remaining=%d)",
            len(to_remove), threshold, len(self._discovered),
            len(to_remove), threshold, len(self._discovered),
        )

    def get_discovered(self) -> Dict[str, PrimitiveAction]:
        """발견된 모든 프리미티브 반환 / Return all discovered primitives."""
        return dict(self._discovered)

    @property
    def discovered_count(self) -> int:
        """발견된 프리미티브 수 / Number of discovered primitives."""
        return len(self._discovered)


# ============================================================================
# V8.5 적응형 프리미티브 엔진 / V8.5 Adaptive Primitive Engine
# ============================================================================


class AdaptivePrimitiveEngine:
    """
    학습 기반 적응형 프리미티브 엔진
    Adaptive primitive engine with learning capabilities.

    PrimitiveActionEngine의 기능을 래핑/확장하여:
    - 진화적 액션 발견 (ActionEvolver 통합)
    - RL 기반 파라미터 최적화 (rl_policy 통합)
    - 새로움 기반 탐색
    - 경험 기반 액션 제안
    - 자동 액션 시퀀스 구성

    Wraps/extends PrimitiveActionEngine with:
    - Evolutionary action discovery (ActionEvolver integration)
    - RL-based parameter optimization (rl_policy integration)
    - Novelty-based exploration
    - Experience-based action suggestion
    - Automatic action sequence composition

    V8.5: 하드코딩된 55개 프리미티브에서 → 무한한 발견 가능한 공간으로.
    V8.5: From 55 hardcoded presets → infinite discoverable space.
    """

    def __init__(
        self,
        base_engine: Optional[PrimitiveActionEngine] = None,
        db_path: Optional[str] = None,
        seed: Optional[int] = 42,
    ) -> None:
        self._logger = logging.getLogger("primitive_action_engine.AdaptivePrimitiveEngine")
        self._rng = np.random.default_rng(seed)

        # 기본 엔진 (래핑) / Base engine (wrapped)
        if base_engine is not None:
            self._engine = base_engine
        else:
            self._engine = PrimitiveActionEngine(db_path=db_path)

        # V8.5 컴포넌트 / V8.5 components
        self._embedding = ActionEmbedding(seed=seed)
        self._space = PrimitiveSpace(seed=seed)

        # 액션 진화기 (선택적) / Action evolver (optional)
        self._evolver: Optional[Any] = None
        if _HAS_ACTION_EVOLUTION and ActionEvolver is not None:
            try:
                self._evolver = ActionEvolver()
                self._logger.info("ActionEvolver 통합 성공 / ActionEvolver integrated successfully")
            except Exception as e:
                self._logger.warning(
                    "ActionEvolver 초기화 실패: %s / ActionEvolver init failed: %s", e, e
                )

        # 실행 추적 / Execution tracking
        self._execution_log: List[Dict[str, Any]] = []
        self._action_usage: Dict[str, int] = {}
        self._action_rewards: Dict[str, List[float]] = {}
        self._novelty_bonus: float = 0.1  # 새로움 보너스 가중치 / Novelty bonus weight

        # RL 정책 (간이 구현) / RL policy (simplified implementation)
        self._rl_policy: Dict[str, Dict[str, float]] = {}  # state_key → {action_id → q_value}
        self._rl_learning_rate: float = 0.1
        self._rl_discount: float = 0.95
        self._rl_epsilon: float = 0.15  # 탐색률 / Exploration rate

        self._logger.info("적응형 프리미티브 엔진 생성 / Adaptive Primitive Engine created")

    def initialize(self) -> None:
        """기본 엔진 초기화 / Initialize base engine."""
        self._engine.initialize()
        self._logger.info(
            "적응형 엔진 초기화 완료 (프리미티브: %d개) / "
            "Adaptive engine initialized (primitives: %d)",
            len(self._engine.primitives),
            len(self._engine.primitives),
        )

    def track_execution(self, action: PrimitiveAction, result: ExecutionResult) -> None:
        """
        실행 결과 추적 (학습용)
        Track execution result for learning.

        모든 실행 결과를 기록하여 향후 액션 제안과
        파라미터 최적화에 활용한다.

        Args:
            action: 실행된 액션 / Executed action
            result: 실행 결과 / Execution result
        """
        # 실행 로그 기록 / Record execution log
        log_entry = {
            "action_id": action.action_id,
            "action_name": action.name,
            "category": action.category.value,
            "parameters": dict(action.parameters),
            "status": result.status.value,
            "duration_actual_ms": result.duration_actual_ms,
            "timestamp": time.time(),
        }
        self._execution_log.append(log_entry)

        # 사용 횟수 증가 / Increment usage count
        self._action_usage[action.action_id] = self._action_usage.get(action.action_id, 0) + 1

        # 보상 기록 / Record reward
        if action.action_id not in self._action_rewards:
            self._action_rewards[action.action_id] = []

        # 간이 보상 계산 / Simplified reward calculation
        if result.status == ExecutionStatus.SUCCESS:
            reward = 1.0
        elif result.status == ExecutionStatus.PARTIAL:
            reward = 0.3
        elif result.status == ExecutionStatus.FAILED:
            reward = -0.5
        elif result.status == ExecutionStatus.ABORTED:
            reward = -1.0
        else:
            reward = -0.2

        # 에너지 효율 보너스 / Energy efficiency bonus
        if action.energy_cost > 0:
            reward += 0.1 * (1.0 - min(action.energy_cost / 50.0, 1.0))

        self._action_rewards[action.action_id].append(reward)

        # RL 정책 업데이트 / Update RL policy
        state_key = action.category.value
        if state_key not in self._rl_policy:
            self._rl_policy[state_key] = {}

        current_q = self._rl_policy[state_key].get(action.action_id, 0.0)
        # Q-러닝 업데이트 / Q-learning update
        self._rl_policy[state_key][action.action_id] = (
            current_q + self._rl_learning_rate * (reward - current_q)
        )

        # 진화기에 피드백 (있는 경우) / Feedback to evolver (if available)
        if self._evolver is not None:
            try:
                if hasattr(self._evolver, 'record_fitness'):
                    self._evolver.record_fitness(action.action_id, reward)
            except Exception as e:
                self._logger.debug("Evolver 피드백 실패: %s / Evolver feedback failed: %s", e, e)

        self._logger.debug(
            "실행 추적: %s → %s (reward=%.3f) / "
            "Execution tracked: %s → %s (reward=%.3f)",
            action.action_id, result.status.value, reward,
            action.action_id, result.status.value, reward,
        )

    def suggest_next_action(
        self,
        task_context: Dict[str, Any],
    ) -> PrimitiveAction:
        """
        경험 기반 다음 액션 제안 (AI 제안)
        AI suggests action based on experience.

        현재 컨텍스트와 과거 경험을 분석하여 최적의 다음 액션을 제안한다.
        새로움 기반 탐색과 RL 정책을 결합한다.

        Args:
            task_context: 과업 컨텍스트 / Task context
                - "category": ActionCategory (선택적)
                - "goal": 목표 설명 (선택적)
                - "state_key": 현재 상태 키 (선택적)

        Returns:
            PrimitiveAction: 제안된 액션 / Suggested action
        """
        category = task_context.get("category", ActionCategory.LOCOMOTION)
        if isinstance(category, str):
            category = ActionCategory(category)

        state_key = task_context.get("state_key", category.value)

        # ε-탐욕 전략 / Epsilon-greedy strategy
        if self._rng.random() < self._rl_epsilon:
            # 탐색: 무작위 또는 새로운 프리미티브 / Explore: random or new primitive
            if self._rng.random() < 0.5 and self._space.discovered_count > 0:
                # 발견된 프리미티브 중 선택 / Choose from discovered primitives
                discovered = list(self._space.get_discovered().values())
                return discovered[int(self._rng.integers(len(discovered)))]
            else:
                # 연속 공간에서 샘플링 / Sample from continuous space
                return self._space.sample_random(category)
        else:
            # 활용: 최적의 알려진 액션 / Exploit: best known action
            policy = self._rl_policy.get(state_key, {})

            if policy:
                # 가장 높은 Q-값의 액션 선택 / Select action with highest Q-value
                best_action_id = max(policy, key=policy.get)  # type: ignore[arg-type]
                action = self._engine.get_primitive_by_id(best_action_id)
                if action is not None:
                    return action

            # 폴백: 기본 엔진에서 사용 가능한 프리미티브 / Fallback: available from base engine
            available = self._engine.get_available_primitives(task_context)
            if available:
                # 새로움 보너스 적용 / Apply novelty bonus
                scored = []
                for a in available:
                    usage = self._action_usage.get(a.action_id, 0)
                    novelty_score = 1.0 / (1.0 + usage)  # 사용이 적을수록 새로움 높음
                    reward_avg = 0.0
                    if a.action_id in self._action_rewards and self._action_rewards[a.action_id]:
                        reward_avg = np.mean(self._action_rewards[a.action_id])
                    total_score = reward_avg + self._novelty_bonus * novelty_score
                    scored.append((total_score, a))

                scored.sort(key=lambda x: x[0], reverse=True)
                return scored[0][1]

            # 최종 폴백: 랜덤 / Final fallback: random
            return self._space.sample_random(category)

    def auto_compose(self, task_description: str) -> CompositeAction:
        """
        과업 설명으로부터 자동으로 액션 시퀀스 구성
        Automatically compose action sequence for task.

        과업 설명을 분석하고, 경험 기반 지식과 새로운 탐색을
        결합하여 최적의 액션 시퀀스를 자동 생성한다.

        Args:
            task_description: 과업 설명 (자연어) / Task description (natural language)

        Returns:
            CompositeAction: 자동 구성된 복합 액션
        """
        self._logger.info(
            "자동 구성 시작: '%s' / Auto-compose started: '%s'",
            task_description, task_description,
        )

        # 1단계: 기본 엔진으로 초기 구성 / Step 1: Initial composition via base engine
        try:
            base_composite = self._engine.compose_for_task(task_description)
        except RuntimeError:
            # 엔진이 초기화되지 않은 경우 / If engine not initialized
            self._engine.initialize()
            base_composite = self._engine.compose_for_task(task_description)

        # 2단계: 경험 기반 파라미터 최적화 / Step 2: Experience-based parameter optimization
        optimized_primitives: List[PrimitiveAction] = []
        for primitive in base_composite.primitives:
            action_id = primitive.action_id
            if action_id in self._action_rewards and self._action_rewards[action_id]:
                rewards = self._action_rewards[action_id]
                avg_reward = float(np.mean(rewards))

                if avg_reward < 0.0:
                    # 나쁜 경험: 변이로 개선 / Bad experience: improve via mutation
                    optimized = self._engine.mutator.mutate_parameters(primitive, sigma=0.2)
                    optimized_primitives.append(optimized)
                elif avg_reward < 0.5:
                    # 보통 경험: 약간 변이 / Average experience: slight mutation
                    optimized = self._engine.mutator.mutate_parameters(primitive, sigma=0.05)
                    optimized_primitives.append(optimized)
                else:
                    # 좋은 경험: 그대로 사용 / Good experience: keep as-is
                    optimized_primitives.append(primitive)
            else:
                # 경험 없음: 새로움 탐색 추가 / No experience: add novelty exploration
                # 기존 액션 + 약간의 탐색 변이 / Existing action + slight exploration mutation
                if self._rng.random() < 0.3:
                    explored = self._space.sample_random(primitive.category)
                    # 기존 액션과 발견된 액션의 보간 / Interpolate between existing and discovered
                    interp = self._space.interpolate(primitive, explored, t=0.3)
                    optimized_primitives.append(interp)
                else:
                    optimized_primitives.append(primitive)

        # 3단계: 진화기가 있으면 교차 적용 / Step 3: Apply crossover if evolver available
        if self._evolver is not None and len(optimized_primitives) >= 2:
            try:
                # 연속 액션 쌍에 대해 교차 수행 / Crossover consecutive action pairs
                evolved_primitives: List[PrimitiveAction] = []
                for i in range(0, len(optimized_primitives) - 1, 2):
                    child = self._engine.mutator.crossover(
                        optimized_primitives[i],
                        optimized_primitives[i + 1],
                    )
                    evolved_primitives.append(child)
                # 홀수개면 마지막 것 추가 / If odd, append last one
                if len(optimized_primitives) % 2 == 1:
                    evolved_primitives.append(optimized_primitives[-1])
                optimized_primitives = evolved_primitives
            except Exception as e:
                self._logger.debug(
                    "진화 교차 실패, 기본 최적화 사용: %s / "
                    "Evolutionary crossover failed, using basic optimization: %s",
                    e, e,
                )

        # 4단계: 복합 액션 구성 / Step 4: Compose composite action
        if optimized_primitives:
            composite = self._engine.composer.compose_sequential(optimized_primitives)
        else:
            composite = base_composite

        # 5단계: 순서 최적화 / Step 5: Optimize ordering
        composite = self._engine.composer.optimize_ordering(composite)

        self._logger.info(
            "자동 구성 완료: '%s' → %s / Auto-compose complete: '%s' → %s",
            task_description, composite.summary(),
            task_description, composite.summary(),
        )
        return composite

    # ========================================================================
    # 기본 엔진 위임 메서드 / Base engine delegation methods
    # ========================================================================

    def execute_and_learn(self, composite: CompositeAction) -> List[PhysicalExperience]:
        """복합 액션 실행 + 학습 (기본 엔진 위임 + 추적) / Execute + learn (delegated + tracked)."""
        experiences = self._engine.execute_and_learn(composite)

        # 실행 결과 추적 / Track execution results
        for exp in experiences:
            self.track_execution(exp.action, exp.result)

        return experiences

    def get_available_primitives(
        self, task_context: Optional[Dict[str, Any]] = None
    ) -> List[PrimitiveAction]:
        """사용 가능한 프리미티브 (기본 + 발견된) / Available primitives (base + discovered)."""
        base = self._engine.get_available_primitives(task_context)
        discovered = list(self._space.get_discovered().values())
        return base + discovered

    def get_primitive_by_name(self, name: str) -> Optional[PrimitiveAction]:
        """이름으로 프리미티브 조회 (기본 + 발견된) / Lookup by name (base + discovered)."""
        result = self._engine.get_primitive_by_name(name)
        if result is not None:
            return result
        # 발견된 프리미티브에서 검색 / Search in discovered primitives
        for action in self._space.get_discovered().values():
            if action.name == name:
                return action
        return None

    def get_statistics(self) -> Dict[str, Any]:
        """적응형 엔진 통계 / Adaptive engine statistics."""
        base_stats = self._engine.get_statistics()
        base_stats.update({
            "discovered_primitives": self._space.discovered_count,
            "total_executions_tracked": len(self._execution_log),
            "unique_actions_used": len(self._action_usage),
            "rl_policy_states": len(self._rl_policy),
            "has_evolver": self._evolver is not None,
            "rl_epsilon": self._rl_epsilon,
        })
        return base_stats

    @property
    def engine(self) -> PrimitiveActionEngine:
        """기본 엔진 접근 / Access base engine."""
        return self._engine

    @property
    def embedding(self) -> ActionEmbedding:
        """임베딩 접근 / Access action embedding."""
        return self._embedding

    @property
    def space(self) -> PrimitiveSpace:
        """프리미티브 공간 접근 / Access primitive space."""
        return self._space


# ============================================================================
# 모듈 레벨 편의 함수 / Module-level convenience functions
# ============================================================================


def create_engine(db_path: Optional[str] = None) -> PrimitiveActionEngine:
    """
    프리미티브 액션 엔진 생성 및 초기화 / Create and initialize Primitive Action Engine.

    Usage:
        engine = create_engine()
        # 또는 커스텀 DB 경로 / Or with custom DB path:
        engine = create_engine("/path/to/experience.db")
    """
    engine = PrimitiveActionEngine(db_path=db_path)
    engine.initialize()
    return engine


def quick_compose(
    task: str, engine: Optional[PrimitiveActionEngine] = None
) -> CompositeAction:
    """
    빠른 과업 구성 / Quick task composition.

    Usage:
        composite = quick_compose("walk forward and pick up the cup")
    """
    if engine is None:
        engine = create_engine()
    return engine.compose_for_task(task)


# ============================================================================
# 메인 엔트리포인트 / Main Entry Point
# ============================================================================


def main() -> None:
    """
    프리미티브 액션 엔진 데모 / Primitive Action Engine demo.

    엔진의 모든 핵심 기능을 시연한다.
    Demonstrates all core capabilities of the engine.
    """
    print("=" * 70)
    print("  Jihun Robot V8.5 - Primitive Action Engine Demo")
    print("  프리미티브 액션 엔진 데모")
    print("=" * 70)

    # 엔진 생성 및 초기화 / Create and initialize engine
    engine = create_engine()

    # 통계 출력 / Print statistics
    stats = engine.get_statistics()
    print(f"\n📊 엔진 통계 / Engine Statistics:")
    for key, value in stats.items():
        print(f"  {key}: {value}")

    # 사용 가능 프리미티브 조회 / Get available primitives
    loco_primitives = engine.get_primitives_by_category(ActionCategory.LOCOMOTION)
    print(f"\n🚶 이동 프리미티브 / Locomotion Primitives ({len(loco_primitives)}):")
    for p in loco_primitives[:5]:
        print(f"  {p.summary()}")
    print(f"  ... and {len(loco_primitives) - 5} more")

    manip_primitives = engine.get_primitives_by_category(ActionCategory.MANIPULATION)
    print(f"\n🤏 조작 프리미티브 / Manipulation Primitives ({len(manip_primitives)}):")
    for p in manip_primitives[:5]:
        print(f"  {p.summary()}")
    print(f"  ... and {len(manip_primitives) - 5} more")

    # 순차 복합 액션 구성 / Compose sequential composite
    print("\n" + "-" * 50)
    print("📋 순차 복합 액션 구성 / Sequential Composite Composition")
    print("-" * 50)

    walk = engine.get_primitive_by_name("walk_forward")
    look = engine.get_primitive_by_name("look_at")
    grip = engine.get_primitive_by_name("grip_close")
    lift = engine.get_primitive_by_name("lift")

    if all([walk, look, grip, lift]):
        sequential = engine.composer.compose_sequential([walk, look, grip, lift])
        print(f"  {sequential.summary()}")
        for i, t in enumerate(sequential.transitions):
            print(f"  Transition {i}: {t['from']} → {t['to']} "
                  f"(overlap={t['overlap_ms']}ms, interp={t['interpolation']})")

    # 과업 기반 구성 / Task-based composition
    print("\n" + "-" * 50)
    print("🎯 과업 기반 구성 / Task-based Composition")
    print("-" * 50)

    composite = engine.compose_for_task("walk forward and grab object")
    print(f"  Task: 'walk forward and grab object'")
    print(f"  Result: {composite.summary()}")
    for i, p in enumerate(composite.primitives):
        print(f"    Step {i+1}: {p.summary()}")

    # 변이 생성 / Generate variations
    print("\n" + "-" * 50)
    print("🧬 액션 변이 / Action Mutations")
    print("-" * 50)

    if walk:
        variations = engine.mutator.generate_variations(walk, n=5)
        print(f"  원본 / Original: {walk.summary()}")
        for i, v in enumerate(variations):
            print(f"  변이 {i+1} / Variation {i+1}: {v.summary()}")

    # 교차 / Crossover
    print("\n" + "-" * 50)
    print("🔀 액션 교차 / Action Crossover")
    print("-" * 50)

    if walk and grip:
        child = engine.mutator.crossover(walk, grip)
        print(f"  부모 A / Parent A: {walk.summary()}")
        print(f"  부모 B / Parent B: {grip.summary()}")
        print(f"  자식 / Child: {child.summary()}")

    # 실행 + 학습 / Execute + Learn
    print("\n" + "-" * 50)
    print("⚡ 실행 + 학습 / Execute + Learn")
    print("-" * 50)

    experiences = engine.execute_and_learn(composite)
    for i, exp in enumerate(experiences):
        print(
            f"  경험 {i+1}: {exp.action.name} → "
            f"status={exp.result.status.value}, "
            f"reward={exp.reward:.3f}, novelty={exp.novelty:.3f}"
        )

    # 경험 기반 개선 / Refine from experience
    print("\n" + "-" * 50)
    print("🔄 경험 기반 개선 / Experience-based Refinement")
    print("-" * 50)

    refined = engine.refine_from_experience(composite, experiences)
    print(f"  원본 / Original: {composite.summary()}")
    print(f"  개선 / Refined: {refined.summary()}")

    # 새로운 조합 발견 / Discover new combinations
    print("\n" + "-" * 50)
    print("💡 새로운 조합 발견 / New Combination Discovery")
    print("-" * 50)

    discoveries = engine.discover_new_combinations()
    for i, disc in enumerate(discoveries):
        print(f"  발견 {i+1}: {disc.summary()}")
        for j, p in enumerate(disc.primitives):
            print(f"    Step {j+1}: {p.name}({', '.join(f'{k}={v:.2f}' for k, v in p.parameters.items())})")

    # 최종 통계 / Final statistics
    print("\n" + "=" * 70)
    print("📊 최종 통계 / Final Statistics")
    print("=" * 70)
    final_stats = engine.get_statistics()
    for key, value in final_stats.items():
        print(f"  {key}: {value}")

    print("\n✅ 프리미티브 액션 엔진 데모 완료 / Primitive Action Engine demo complete!")

# ============================================================================
# V8.5 Physical AGI - 동적 프리미티브 생성기 / Dynamic Primitive Generator
# ============================================================================


class DynamicPrimitiveGenerator:
    """
    동적 프리미티브 생성기 - AI 추론을 통해 새로운 프리미티브를 즉석에서 생성
    Dynamic Primitive Generator - Generates new primitives on-the-fly using AI reasoning.

    정적 하드코딩 프리미티브는 폴백 기본값으로 유지하되, 주 모드는 동적 생성이다.
    Static hardcoded primitives are kept as FALLBACK defaults, but the primary
    mode is dynamic generation based on task context and sensor data.

    핵심 원칙 / Core Principle:
        하드코딩하지 마라 — AI가 스스로 생각하여 동작을 구성해야 한다.
        NEVER hardcode — the AI must think and reason to compose actions.
    """

    def __init__(self, fallback_primitives: Optional[Dict[str, PrimitiveAction]] = None):
        """
        동적 프리미티브 생성기 초기화 / Initialize dynamic primitive generator.

        Args:
            fallback_primitives: 폴백 기본 프리미티브 맵 / Fallback default primitives map
        """
        self._fallback: Dict[str, PrimitiveAction] = fallback_primitives or {}
        self._generated: Dict[str, PrimitiveAction] = {}  # 동적으로 생성된 프리미티브 / Dynamically generated
        self._experience_buffer: List[Dict[str, Any]] = []  # 경험 버퍼 / Experience buffer
        self._mutation_history: List[Dict[str, Any]] = []   # 변이 이력 / Mutation history
        logger.info(
            "DynamicPrimitiveGenerator 초기화: 폴백 %d개 / "
            "Initialized with %d fallback primitives",
            len(self._fallback),
            len(self._fallback),
        )

    def generate_primitive(
        self,
        task_description: str,
        current_state: RobotState,
        sensor_data: Optional[Dict[str, float]] = None,
        category_hint: Optional[ActionCategory] = None,
    ) -> PrimitiveAction:
        """
        과제 맥락과 현재 상태로부터 새 프리미티브를 동적으로 생성
        Dynamically generate a new primitive from task context and current state.

        AI 추론 과정 / AI Reasoning Process:
            1. 과제 분석 → 필요한 동작 유형 파악 / Analyze task → identify needed action type
            2. 센서 데이터 기반 파라미터 계산 / Compute parameters from sensor data
            3. 현재 상태 기반 전제조건/사후조건 추론 / Infer pre/post conditions from state
            4. 에너지/위험 추정 / Estimate energy cost and risk

        Args:
            task_description: 과제 설명 / Task description in natural language
            current_state: 현재 로봇 상태 / Current robot state
            sensor_data: 센서 데이터 / Sensor readings
            category_hint: 카테고리 힌트 / Suggested category

        Returns:
            동적으로 생성된 PrimitiveAction / Dynamically generated PrimitiveAction
        """
        sensor_data = sensor_data or {}

        # 1. 카테고리 추론 / Infer category
        category = category_hint or self._infer_category(task_description)

        # 2. 파라미터 동적 계산 / Dynamically compute parameters
        parameters = self._compute_dynamic_parameters(
            task_description, current_state, sensor_data
        )

        # 3. 지속시간 추정 / Estimate duration
        duration_ms = self._estimate_duration(category, parameters, current_state)

        # 4. 전제/사후조건 추론 / Infer pre/post conditions
        preconditions = self._infer_preconditions(category, parameters, current_state)
        postconditions = self._infer_postconditions(task_description, category, parameters)

        # 5. 에너지/위험 추정 / Estimate energy and risk
        energy_cost = self._estimate_energy(category, parameters, current_state)
        risk_level = self._estimate_risk(category, parameters, current_state, sensor_data)

        # 프리미티브 생성 / Create primitive
        action_id = f"dyn_{category.value}_{uuid.uuid4().hex[:8]}"
        primitive = PrimitiveAction(
            action_id=action_id,
            category=category,
            name=self._generate_name(task_description, category),
            parameters=parameters,
            duration_ms=duration_ms,
            preconditions=preconditions,
            postconditions=postconditions,
            energy_cost=energy_cost,
            risk_level=risk_level,
        )

        self._generated[action_id] = primitive
        logger.info(
            "동적 프리미티브 생성: %s (%s) / "
            "Dynamically generated: %s (%s)",
            primitive.name,
            primitive.summary()[:80],
            primitive.name,
            category.value,
        )
        return primitive

    def mutate_primitive(
        self,
        base_primitive: PrimitiveAction,
        context: Dict[str, Any],
    ) -> PrimitiveAction:
        """
        경험 기반으로 기존 프리미티브를 변이시켜 개선
        Mutate an existing primitive based on experience/context to improve it.

        변이 전략 / Mutation Strategies:
            - 파라미터 미세조정 (속도, 힘, 각도) / Parameter fine-tuning
            - 지속시간 최적화 / Duration optimization
            - 위험도 감소 / Risk reduction
            - 에너지 효율 개선 / Energy efficiency improvement
            - 전제조건 완화/강화 / Precondition relaxation/strengthening

        Args:
            base_primitive: 변이할 기반 프리미티브 / Base primitive to mutate
            context: 변이 맥락 (성공/실패, 센서 피드백 등) / Mutation context

        Returns:
            변이된 새 PrimitiveAction / Mutated new PrimitiveAction
        """
        # 변이 강도 결정 / Determine mutation magnitude
        mutation_strength = context.get("mutation_strength", 0.1)
        success = context.get("success", True)
        reward = context.get("reward", 0.5)

        # 파라미터 변이 / Mutate parameters
        new_params = {}
        for key, val in base_primitive.parameters.items():
            if success and reward > 0.7:
                # 성공 시 미세 조정 / Fine-tune on success
                delta = np.random.normal(0, mutation_strength * 0.1) * val
                new_params[key] = round(val + delta, 4)
            else:
                # 실패 시 더 큰 변이 / Larger mutation on failure
                delta = np.random.normal(0, mutation_strength * 0.3) * val
                new_params[key] = round(val + delta, 4)

        # 지속시간 변이 / Mutate duration
        duration_factor = 1.0 + np.random.normal(0, mutation_strength * 0.05)
        new_duration = max(50, int(base_primitive.duration_ms * duration_factor))

        # 위험도 변이 / Mutate risk
        if success:
            new_risk = max(0.0, base_primitive.risk_level - 0.02)
        else:
            new_risk = min(1.0, base_primitive.risk_level + 0.05)

        # 에너지 변이 / Mutate energy
        if reward > 0.5:
            new_energy = base_primitive.energy_cost * (1.0 - 0.02 * reward)
        else:
            new_energy = base_primitive.energy_cost * (1.0 + 0.05 * (1 - reward))

        mutated = PrimitiveAction(
            action_id=f"mut_{base_primitive.action_id}_{uuid.uuid4().hex[:6]}",
            category=base_primitive.category,
            name=f"{base_primitive.name}_v{len(self._mutation_history) + 1}",
            parameters=new_params,
            duration_ms=new_duration,
            preconditions=base_primitive.preconditions[:],
            postconditions=base_primitive.postconditions[:],
            energy_cost=round(new_energy, 2),
            risk_level=round(new_risk, 3),
        )

        self._mutation_history.append({
            "base_id": base_primitive.action_id,
            "mutated_id": mutated.action_id,
            "context": context,
            "timestamp": time.time(),
        })

        logger.info(
            "프리미티브 변이: %s → %s / "
            "Primitive mutated: %s → %s",
            base_primitive.action_id,
            mutated.action_id,
            base_primitive.name,
            mutated.name,
        )
        return mutated

    def autonomous_compose(
        self,
        task_description: str,
        current_state: RobotState,
    ) -> "CompositeAction":
        """
        과제 설명과 현재 상태로부터 AI 추론으로 복합 액션을 자율 구성
        Autonomously compose a composite action using AI reasoning.

        AI가 하드코딩된 시퀀스 없이 스스로 판단하여:
        1. 필요한 하위 목표 분해 / Decompose into sub-goals
        2. 각 하위 목표에 맞는 프리미티브 선택/생성 / Select/generate primitives
        3. 병렬 가능한 동작 식별 / Identify parallelizable actions
        4. 전환 조건 추론 / Infer transition conditions

        Args:
            task_description: 과제 설명 / Task description
            current_state: 현재 로봇 상태 / Current robot state

        Returns:
            AI 추론으로 구성된 CompositeAction / AI-composed CompositeAction
        """
        # 과제 분해 / Task decomposition
        sub_goals = self._decompose_task(task_description, current_state)

        # 각 하위 목표에 맞는 프리미티브 선택/생성
        primitives: List[PrimitiveAction] = []
        for goal in sub_goals:
            # 먼저 폴백에서 검색 / First search in fallback
            candidate = self._find_best_fallback(goal)
            if candidate is None:
                # 동적 생성 / Generate dynamically
                candidate = self.generate_primitive(
                    goal, current_state, category_hint=None
                )
            primitives.append(candidate)

        # 병렬 그룹 식별 / Identify parallel groups
        parallel_groups = self._identify_parallel_groups(primitives, task_description)

        # 전환 조건 추론 / Infer transitions
        transitions = self._infer_transitions(primitives, task_description)

        composite_id = f"comp_auto_{uuid.uuid4().hex[:8]}"
        composite = CompositeAction(
            composite_id=composite_id,
            primitives=primitives,
            parallel_groups=parallel_groups,
            transitions=transitions,
            total_duration_ms=0,
            total_energy_cost=0.0,
        )

        logger.info(
            "자율 복합 액션 구성: %s (%d 프리미티브, %d 병렬 그룹) / "
            "Autonomous composition: %s (%d primitives, %d parallel groups)",
            task_description[:50],
            len(primitives),
            len(parallel_groups),
            task_description[:50],
            len(primitives),
            len(parallel_groups),
        )
        return composite

    # ─── 내부 추론 메서드 / Internal Reasoning Methods ───

    def _infer_category(self, task_description: str) -> ActionCategory:
        """과제 설명에서 카테고리 추론 / Infer category from task description."""
        desc_lower = task_description.lower()
        # 키워드 기반 추론 (실제 LLM 대체) / Keyword-based inference (placeholder for LLM)
        if any(w in desc_lower for w in ["walk", "move", "go", "이동", "걷", "달리"]):
            return ActionCategory.LOCOMOTION
        elif any(w in desc_lower for w in ["grasp", "grab", "pick", "잡", "집"]):
            return ActionCategory.MANIPULATION
        elif any(w in desc_lower for w in ["stand", "crouch", "서", "앉"]):
            return ActionCategory.POSTURE
        elif any(w in desc_lower for w in ["look", "scan", "보", "찾"]):
            return ActionCategory.HEAD
        elif any(w in desc_lower for w in ["scissor", "hammer", "tool", "도구", "가위", "망치"]):
            return ActionCategory.TOOL_USE
        elif any(w in desc_lower for w in ["wave", "point", "bow", "handshake", "인사", "가리", "손"]):
            return ActionCategory.SOCIAL
        elif any(w in desc_lower for w in ["carry", "transport", "deliver", "나르", "운반", "배달"]):
            return ActionCategory.TRANSPORT
        return ActionCategory.COMPOSITE

    def _compute_dynamic_parameters(
        self,
        task_description: str,
        current_state: RobotState,
        sensor_data: Dict[str, float],
    ) -> Dict[str, float]:
        """
        센서 데이터와 과제 분석으로 동적 파라미터 계산
        Compute dynamic parameters from sensor data and task analysis.
        """
        params: Dict[str, float] = {}

        # 배터리 기반 속도 조절 / Battery-based speed adjustment
        battery = current_state.battery_level
        if battery < 0.2:
            params["speed"] = 0.1  # 저전력 모드 / Low power mode
        elif battery < 0.5:
            params["speed"] = 0.3
        else:
            params["speed"] = 0.5

        # 균형 기반 힘 조절 / Balance-based force adjustment
        balance = current_state.balance_score
        if balance < 0.6:
            params["force"] = 3.0  # 불안정 시 낮은 힘 / Low force when unstable
        elif balance < 0.8:
            params["force"] = 5.0
        else:
            params["force"] = 10.0

        # 센서 데이터 반영 / Incorporate sensor data
        if "object_distance" in sensor_data:
            params["approach_distance"] = sensor_data["object_distance"]
        if "object_weight" in sensor_data:
            params["force"] = max(params.get("force", 5.0), sensor_data["object_weight"] * 2.0)
        if "surface_friction" in sensor_data:
            params["grip_force"] = max(3.0, sensor_data["surface_friction"] * 15.0)

        return params

    def _estimate_duration(
        self,
        category: ActionCategory,
        parameters: Dict[str, float],
        current_state: RobotState,
    ) -> int:
        """카테고리와 파라미터로 지속시간 추정 / Estimate duration from category and params."""
        base_durations = {
            ActionCategory.LOCOMOTION: 800,
            ActionCategory.MANIPULATION: 500,
            ActionCategory.POSTURE: 500,
            ActionCategory.HEAD: 250,
            ActionCategory.COMPOSITE: 2000,
            ActionCategory.TOOL_USE: 700,
            ActionCategory.SOCIAL: 600,
            ActionCategory.TRANSPORT: 1200,
        }
        base = base_durations.get(category, 500)

        # 속도 반비례 / Speed inverse
        speed = parameters.get("speed", 0.5)
        if speed > 0:
            base = int(base / speed * 0.5)

        # 균형 불안정 시 여유 추가 / Add margin when unstable
        if current_state.balance_score < 0.7:
            base = int(base * 1.3)

        return max(50, base)

    def _infer_preconditions(
        self,
        category: ActionCategory,
        parameters: Dict[str, float],
        current_state: RobotState,
    ) -> List[str]:
        """카테고리와 상태로 전제조건 추론 / Infer preconditions from category and state."""
        conditions: List[str] = []

        if category == ActionCategory.LOCOMOTION:
            conditions.append("is_standing")
            if not current_state.is_stable():
                conditions.append("stabilize_first")
        elif category == ActionCategory.MANIPULATION:
            if current_state.gripper_state < 0.3:
                conditions.append("gripper_open")
        elif category == ActionCategory.TOOL_USE:
            conditions.append("tool_available")
            conditions.append("grip_secure")
        elif category == ActionCategory.TRANSPORT:
            conditions.append("object_grasped")
            conditions.append("is_standing")
        elif category == ActionCategory.SOCIAL:
            conditions.append("person_detected")

        # 에너지 확인 / Check energy
        if current_state.battery_level < 0.1:
            conditions.append("low_battery_warning")

        return conditions

    def _infer_postconditions(
        self,
        task_description: str,
        category: ActionCategory,
        parameters: Dict[str, float],
    ) -> List[str]:
        """과제와 카테고리로 사후조건 추론 / Infer postconditions from task and category."""
        conditions: List[str] = []

        if category == ActionCategory.LOCOMOTION:
            conditions.append("position_changed")
        elif category == ActionCategory.MANIPULATION:
            conditions.append("object_state_changed")
        elif category == ActionCategory.TOOL_USE:
            conditions.append("tool_action_completed")
        elif category == ActionCategory.TRANSPORT:
            conditions.append("object_relocated")
        elif category == ActionCategory.SOCIAL:
            conditions.append("gesture_performed")

        return conditions

    def _estimate_energy(
        self,
        category: ActionCategory,
        parameters: Dict[str, float],
        current_state: RobotState,
    ) -> float:
        """에너지 소비 추정 / Estimate energy consumption."""
        base_energy = {
            ActionCategory.LOCOMOTION: 12.0,
            ActionCategory.MANIPULATION: 5.0,
            ActionCategory.POSTURE: 6.0,
            ActionCategory.HEAD: 1.0,
            ActionCategory.COMPOSITE: 25.0,
            ActionCategory.TOOL_USE: 10.0,
            ActionCategory.SOCIAL: 2.5,
            ActionCategory.TRANSPORT: 20.0,
        }
        base = base_energy.get(category, 8.0)

        # 힘에 비례 / Proportional to force
        force = parameters.get("force", 5.0)
        base *= (force / 5.0)

        # 속도에 비례 / Proportional to speed
        speed = parameters.get("speed", 0.5)
        base *= (0.5 + speed)

        return round(base, 2)

    def _estimate_risk(
        self,
        category: ActionCategory,
        parameters: Dict[str, float],
        current_state: RobotState,
        sensor_data: Dict[str, float],
    ) -> float:
        """위험도 추정 / Estimate risk level."""
        base_risk = {
            ActionCategory.LOCOMOTION: 0.10,
            ActionCategory.MANIPULATION: 0.08,
            ActionCategory.POSTURE: 0.10,
            ActionCategory.HEAD: 0.01,
            ActionCategory.COMPOSITE: 0.20,
            ActionCategory.TOOL_USE: 0.40,
            ActionCategory.SOCIAL: 0.02,
            ActionCategory.TRANSPORT: 0.15,
        }
        risk = base_risk.get(category, 0.10)

        # 불안정 시 위험 증가 / Increase risk when unstable
        if current_state.balance_score < 0.6:
            risk += 0.15
        # 저배터리 시 위험 증가 / Increase risk on low battery
        if current_state.battery_level < 0.15:
            risk += 0.10
        # 높은 힘 시 위험 증가 / Increase risk with high force
        force = parameters.get("force", 5.0)
        if force > 15.0:
            risk += 0.10

        return min(1.0, max(0.0, round(risk, 3)))

    def _generate_name(self, task_description: str, category: ActionCategory) -> str:
        """과제 설명으로부터 프리미티브 이름 생성 / Generate primitive name from task."""
        # 간단한 이름 생성 (LLM 대체) / Simple name generation (placeholder for LLM)
        words = task_description.replace(",", " ").replace(".", " ").split()[:3]
        name_base = "_".join(w.lower() for w in words if w.isalpha())
        return f"{category.value}_{name_base}"[:40]

    def _find_best_fallback(self, goal_description: str) -> Optional[PrimitiveAction]:
        """폴백 프리미티브에서 최적 검색 / Find best fallback primitive."""
        goal_lower = goal_description.lower()
        best: Optional[PrimitiveAction] = None
        best_score = 0.0

        for p in self._fallback.values():
            # 이름/사후조건 매칭 / Match name/postconditions
            score = 0.0
            for word in goal_lower.split():
                if word in p.name:
                    score += 0.3
                for cond in p.postconditions:
                    if word in cond:
                        score += 0.2
            if score > best_score:
                best_score = score
                best = p

        # 임계값 이상이면 사용 / Use if above threshold
        if best_score > 0.3:
            return best
        return None

    def _decompose_task(
        self, task_description: str, current_state: RobotState
    ) -> List[str]:
        """
        과제를 하위 목표로 분해 / Decompose task into sub-goals.
        AI 추론으로 과제를 단계별 하위 목표로 나눈다 (하드코딩 없음).
        """
        # 과제 복잡도 추정 / Estimate task complexity
        words = task_description.split()
        complexity = min(len(words) / 5.0, 1.0)
        num_subgoals = max(2, int(complexity * 6) + 2)

        # 기본 분해 전략 / Basic decomposition strategy
        sub_goals = []
        # 1. 관찰 / Observe
        sub_goals.append(f"scan and observe for: {task_description}")
        # 2. 접근 / Approach
        sub_goals.append(f"approach target for: {task_description}")
        # 3. 중간 단계들 / Intermediate steps
        for i in range(num_subgoals - 3):
            sub_goals.append(f"substep {i+1} of: {task_description}")
        # 4. 완료 / Complete
        sub_goals.append(f"complete: {task_description}")

        return sub_goals

    def _identify_parallel_groups(
        self,
        primitives: List[PrimitiveAction],
        task_description: str,
    ) -> List[List[int]]:
        """
        병렬 실행 가능한 프리미티브 그룹 식별 / Identify parallelizable groups.
        서로 간섭하지 않는 동작(예: 걷기+시선 추적)은 병렬 실행 가능.
        """
        parallel_groups: List[List[int]] = []
        # HEAD 카테고리는 다른 동작과 병렬 가능 / HEAD can parallelize with others
        head_indices = [i for i, p in enumerate(primitives) if p.category == ActionCategory.HEAD]

        for head_idx in head_indices:
            # 이전 프리미티브와 병렬 그룹 / Parallelize with previous primitive
            if head_idx > 0:
                parallel_groups.append([head_idx - 1, head_idx])

        return parallel_groups

    def _infer_transitions(
        self,
        primitives: List[PrimitiveAction],
        task_description: str,
    ) -> List[Dict[str, Any]]:
        """프리미티브 간 전환 조건 추론 / Infer transition conditions between primitives."""
        transitions: List[Dict[str, Any]] = []
        for i in range(len(primitives) - 1):
            transitions.append({
                "from": primitives[i].action_id,
                "to": primitives[i + 1].action_id,
                "condition": f"success_of_{primitives[i].name}",
                "failure_action": "retry_or_replan",
            })
        return transitions

    def record_experience(self, experience: Dict[str, Any]) -> None:
        """경험 기록 / Record experience for learning."""
        self._experience_buffer.append(experience)
        if len(self._experience_buffer) > 1000:
            self._experience_buffer = self._experience_buffer[-500:]

    def get_generated_primitives(self) -> Dict[str, PrimitiveAction]:
        """생성된 프리미티브 반환 / Return generated primitives."""
        return self._generated.copy()

    def get_mutation_history(self) -> List[Dict[str, Any]]:
        """변이 이력 반환 / Return mutation history."""
        return self._mutation_history.copy()


# ============================================================================
# V8.5 Physical AGI - 스마트 액션 작곡가 / Smart Action Composer
# ============================================================================


class SmartActionComposer:
    """
    스마트 액션 작곡가 - AI 추론으로 프리미티브를 체인으로 연결
    Smart Action Composer - Chains primitives using AI reasoning, not hardcoded sequences.

    하드코딩된 액션 시퀀스 대신, AI가 과제 맥락을 이해하고
    최적의 프리미티브 체인을 실시간으로 구성한다.

    Instead of hardcoded action sequences, the AI understands task context
    and constructs optimal primitive chains in real-time.
    """

    def __init__(
        self,
        primitive_generator: Optional[DynamicPrimitiveGenerator] = None,
        fallback_primitives: Optional[Dict[str, PrimitiveAction]] = None,
    ):
        """
        스마트 액션 작곡가 초기화 / Initialize Smart Action Composer.

        Args:
            primitive_generator: 동적 프리미티브 생성기 / Dynamic primitive generator
            fallback_primitives: 폴백 프리미티브 / Fallback primitives
        """
        self._generator = primitive_generator or DynamicPrimitiveGenerator(fallback_primitives)
        self._composition_history: List[Dict[str, Any]] = []
        self._success_patterns: Dict[str, List[str]] = {}  # 과제→프리미티브 시퀀스 패턴
        logger.info("SmartActionComposer 초기화 완료 / SmartActionComposer initialized")

    def compose_for_task(
        self,
        task_description: str,
        current_state: RobotState,
        constraints: Optional[Dict[str, Any]] = None,
    ) -> CompositeAction:
        """
        과제에 대한 최적의 액션 구성을 AI 추론으로 생성
        Generate optimal action composition for a task using AI reasoning.

        하드코딩된 시퀀스가 아닌, 과제 맥락 분석을 통한 자율 구성.
        Autonomous composition through task context analysis, NOT hardcoded sequences.

        Args:
            task_description: 과제 설명 / Task description
            current_state: 현재 로봇 상태 / Current robot state
            constraints: 제약 조건 (최대 시간, 최대 에너지 등) / Constraints

        Returns:
            AI 추론으로 구성된 CompositeAction / AI-composed CompositeAction
        """
        constraints = constraints or {}

        # 1. 과제 분석 / Task analysis
        task_analysis = self._analyze_task(task_description, current_state)

        # 2. 필요 프리미티브 식별 / Identify needed primitives
        needed_primitives = self._identify_needed_primitives(task_analysis, current_state)

        # 3. 순서 최적화 / Optimize ordering
        ordered = self._optimize_ordering(needed_primitives, task_analysis, constraints)

        # 4. 병렬화 기회 탐색 / Find parallelization opportunities
        parallel_groups = self._find_parallelization(ordered, task_analysis)

        # 5. 전환 조건 생성 / Generate transition conditions
        transitions = self._generate_transitions(ordered, task_analysis)

        # 6. 복합 액션 구성 / Compose composite action
        composite_id = f"smart_{uuid.uuid4().hex[:8]}"
        composite = CompositeAction(
            composite_id=composite_id,
            primitives=ordered,
            parallel_groups=parallel_groups,
            transitions=transitions,
            total_duration_ms=0,
            total_energy_cost=0.0,
        )

        # 구성 이력 기록 / Record composition history
        self._composition_history.append({
            "task": task_description,
            "composite_id": composite_id,
            "num_primitives": len(ordered),
            "analysis": task_analysis,
            "timestamp": time.time(),
        })

        logger.info(
            "스마트 구성: '%s' → %d개 프리미티브, %d 병렬 그룹 / "
            "Smart composition: '%s' → %d primitives, %d parallel groups",
            task_description[:40],
            len(ordered),
            len(parallel_groups),
            task_description[:40],
            len(ordered),
            len(parallel_groups),
        )
        return composite

    def learn_from_execution(
        self,
        composite: CompositeAction,
        execution_results: List[Dict[str, Any]],
    ) -> None:
        """
        실행 결과로부터 학습하여 향후 구성 개선
        Learn from execution results to improve future compositions.

        Args:
            composite: 실행된 복합 액션 / Executed composite action
            execution_results: 각 프리미티브의 실행 결과 / Per-primitive execution results
        """
        success_rate = sum(1 for r in execution_results if r.get("success", False)) / max(len(execution_results), 1)

        if success_rate >= 0.7:
            # 성공 패턴 저장 / Store success pattern
            pattern_key = composite.primitives[0].category.value if composite.primitives else "unknown"
            pattern = [p.name for p in composite.primitives]
            self._success_patterns[pattern_key] = pattern
            logger.info(
                "성공 패턴 학습: %s (%.0f%% 성공) / "
                "Learned success pattern: %s (%.0f%% success)",
                pattern_key,
                success_rate * 100,
                pattern_key,
                success_rate * 100,
            )
        else:
            logger.info(
                "실패 패턴 기록: %.0f%% 성공 — 향후 회피 / "
                "Failure pattern recorded: %.0f%% success — will avoid in future",
                success_rate * 100,
                success_rate * 100,
            )

    # ─── 내부 메서드 / Internal Methods ───

    def _analyze_task(
        self, task_description: str, current_state: RobotState
    ) -> Dict[str, Any]:
        """과제 분석 / Analyze task."""
        return {
            "description": task_description,
            "complexity": min(len(task_description.split()) / 5.0, 1.0),
            "requires_locomotion": any(
                w in task_description.lower()
                for w in ["move", "go", "walk", "이동", "가"]
            ),
            "requires_manipulation": any(
                w in task_description.lower()
                for w in ["pick", "grab", "hold", "잡", "집"]
            ),
            "requires_tool": any(
                w in task_description.lower()
                for w in ["cut", "hammer", "brush", "자르", "망치", "도구"]
            ),
            "requires_social": any(
                w in task_description.lower()
                for w in ["greet", "wave", "point", "인사", "손"]
            ),
            "requires_transport": any(
                w in task_description.lower()
                for w in ["carry", "deliver", "transport", "나르", "운반"]
            ),
            "current_balance": current_state.balance_score,
            "current_battery": current_state.battery_level,
        }

    def _identify_needed_primitives(
        self,
        task_analysis: Dict[str, Any],
        current_state: RobotState,
    ) -> List[PrimitiveAction]:
        """필요한 프리미티브 식별 / Identify needed primitives."""
        primitives: List[PrimitiveAction] = []

        # 관찰 프리미티브 항상 포함 / Always include observation primitive
        primitives.append(
            self._generator.generate_primitive(
                "scan surroundings", current_state, category_hint=ActionCategory.HEAD
            )
        )

        # 과제 요구사항에 따라 프리미티브 추가 / Add primitives based on task requirements
        if task_analysis.get("requires_locomotion"):
            primitives.append(
                self._generator.generate_primitive(
                    "move to target", current_state, category_hint=ActionCategory.LOCOMOTION
                )
            )

        if task_analysis.get("requires_manipulation"):
            primitives.append(
                self._generator.generate_primitive(
                    "grasp object", current_state, category_hint=ActionCategory.MANIPULATION
                )
            )

        if task_analysis.get("requires_tool"):
            primitives.append(
                self._generator.generate_primitive(
                    "use tool", current_state, category_hint=ActionCategory.TOOL_USE
                )
            )

        if task_analysis.get("requires_social"):
            primitives.append(
                self._generator.generate_primitive(
                    "social interaction", current_state, category_hint=ActionCategory.SOCIAL
                )
            )

        if task_analysis.get("requires_transport"):
            primitives.append(
                self._generator.generate_primitive(
                    "carry object", current_state, category_hint=ActionCategory.TRANSPORT
                )
            )

        # 안정화 프리미티브 / Stabilization primitive
        if current_state.balance_score < 0.7:
            primitives.append(
                self._generator.generate_primitive(
                    "stabilize posture", current_state, category_hint=ActionCategory.POSTURE
                )
            )

        return primitives

    def _optimize_ordering(
        self,
        primitives: List[PrimitiveAction],
        task_analysis: Dict[str, Any],
        constraints: Dict[str, Any],
    ) -> List[PrimitiveAction]:
        """프리미티브 순서 최적화 / Optimize primitive ordering."""
        # 기본 순서: 관찰 → 이동 → 조작 → 도구 → 사회 → 운반
        # Default order: observe → move → manipulate → tool → social → transport
        category_priority = {
            ActionCategory.HEAD: 0,
            ActionCategory.POSTURE: 1,
            ActionCategory.LOCOMOTION: 2,
            ActionCategory.MANIPULATION: 3,
            ActionCategory.TOOL_USE: 4,
            ActionCategory.SOCIAL: 5,
            ActionCategory.TRANSPORT: 6,
            ActionCategory.COMPOSITE: 7,
        }
        return sorted(primitives, key=lambda p: category_priority.get(p.category, 99))

    def _find_parallelization(
        self,
        primitives: List[PrimitiveAction],
        task_analysis: Dict[str, Any],
    ) -> List[List[int]]:
        """병렬화 기회 탐색 / Find parallelization opportunities."""
        parallel_groups: List[List[int]] = []

        # HEAD는 다른 동작과 병렬 가능 / HEAD can parallelize with others
        for i, p in enumerate(primitives):
            if p.category == ActionCategory.HEAD:
                for j, q in enumerate(primitives):
                    if i != j and q.category in (
                        ActionCategory.LOCOMOTION,
                        ActionCategory.TRANSPORT,
                    ):
                        parallel_groups.append([i, j])
                        break

        return parallel_groups

    def _generate_transitions(
        self,
        primitives: List[PrimitiveAction],
        task_analysis: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """전환 조건 생성 / Generate transition conditions."""
        transitions: List[Dict[str, Any]] = []
        for i in range(len(primitives) - 1):
            transitions.append({
                "from": primitives[i].action_id,
                "to": primitives[i + 1].action_id,
                "condition": f"{primitives[i].postconditions[0] if primitives[i].postconditions else 'completed'}",
                "on_failure": "retry_with_adjusted_params",
            })
        return transitions

    def get_composition_history(self) -> List[Dict[str, Any]]:
        """구성 이력 반환 / Return composition history."""
        return self._composition_history.copy()

    def get_success_patterns(self) -> Dict[str, List[str]]:
        """성공 패턴 반환 / Return success patterns."""
        return self._success_patterns.copy()



if __name__ == "__main__":
    main()
