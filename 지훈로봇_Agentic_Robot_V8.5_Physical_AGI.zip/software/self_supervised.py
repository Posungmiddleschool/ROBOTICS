#!/usr/bin/env python3
"""
self_supervised.py — V8.5/V8.5 Online Self-Supervised Learning for Physical AGI
지훈 로봇 V8.5 — 온라인 자기지도학습 모듈 (Physical AGI 핵심)
================================================================================

WORLD DATA = Physical Experience, NOT web crawling.
로봇은 라벨이 없는 물리적 경험에서 스스로 유용한 표현을 학습합니다.
감독 없이, 보상 없이, 오직 센서 데이터의 구조만으로 학습합니다.

핵심 원칙 / Core Principles:
    1. 라벨이 없어도 학습한다 — 자기지도 학습(Self-Supervised Learning)
    2. 모든 물리적 경험이 훈련 데이터 — 온라인 연속 학습
    3. 학습한 표현은 하위 작업으로 전이 — 표현 학습(Representation Learning)
    4. 경험이 쌓일수록 더 잘 이해한다 — 연속 적응(Continual Adaptation)

5가지 자기지도 학습 태스크 / Five Self-Supervised Tasks:
    1. Temporal Prediction: 현재 센서 상태로 다음 센서 상태 예측
    2. Cross-Modal Prediction: 한 모달리티로 다른 모달리티 예측 (시각→촉각 등)
    3. Masked Sensor Prediction: 일부 센서 채널을 마스킹하고 예측
    4. Contrastive Learning: 유사한 물리적 상태는 유사한 표현을 갖도록 학습
    5. Rotation Prediction: 물체를 밀었을 때 회전 방향 예측

아키텍처 / Architecture:
    MultiModal Sensor Stream
        ↓
    MultiModalEncoder (PyTorch) — 공유 잠재 공간으로 인코딩
        ↓
    ┌─────────────────────────────────────────────┐
    │  TemporalPredictor    → next_state 예측     │
    │  CrossModalPredictor  → modality 간 예측    │
    │  MaskedSensorPredictor→ 마스크 채널 복원    │
    │  ContrastiveHead      → SimCLR 대조 학습    │
    │  RotationPredictor    → 회전 방향 예측      │
    └─────────────────────────────────────────────┘
        ↓
    Shared Representation (256-dim) — 하위 작업으로 전이

온라인 학습 / Online Learning:
    - 스트림 기반: 매 경험 후 즉시 업데이트
    - EMA 인코더: 안정적인 대조 학습을 위한 지수이동평균 인코더
    - 메모리 뱅크: 과거 표현 저장하여 대조 학습 품질 향상
    - 우선순위 버퍼: 높은 학습 신호를 가진 경험 우선 재생

스레드 안전 / Thread Safety:
    - 모든 공유 상태는 threading.Lock으로 보호
    - 메인 루프에서 안전하게 호출 가능
    - 백그라운드 학습 스레드 지원

하드웨어: Dual Jetson Orin NX 16GB
AI 모델: Gemma 4 E4B Q4_K_M
작성일: 2026-05-22
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import math
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple, Union

import numpy as np

# ─── PyTorch 선택적 임포트 / Optional PyTorch Import ─────────────────────────

TORCH_AVAILABLE = False
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    TORCH_AVAILABLE = True
except ImportError:
    torch = None  # type: ignore[assignment]
    nn = None  # type: ignore[assignment]
    F = None  # type: ignore[assignment]

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

import logging

logger = logging.getLogger("jihun.v83.self_supervised")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 상수 / Constants ────────────────────────────────────────────────────────

# 센서 입력 차원 / Sensor input dimensions (from physical_experience_pipeline.py)
VISUAL_INPUT_DIM = 256       # 비전 백본 특징 벡터
TACTILE_INPUT_DIM = 64       # 16 센서 × 4 채널
FORCE_INPUT_DIM = 12         # 6축 FT × 2
PROPRIO_INPUT_DIM = 36       # 12 관절 × (위치+속도+토크) → 12+12+12
IMU_INPUT_DIM = 19           # accel(3)+gyro(3)+mag(3)+quat(4)+lin_accel(3)+gravity(3)
TOTAL_SENSOR_DIM = VISUAL_INPUT_DIM + TACTILE_INPUT_DIM + FORCE_INPUT_DIM + PROPRIO_INPUT_DIM + IMU_INPUT_DIM  # 387

# 모델 차원 / Model dimensions
SHARED_LATENT_DIM = 256      # 공유 잠재 공간 차원
HIDDEN_DIM = 256             # 은닉층 차원
PROJECTION_DIM = 128         # 대조 학습 프로젝션 차원

# 학습 하이퍼파라미터 / Training hyperparameters
DEFAULT_LR = 1e-4            # 학습률
CONTRASTIVE_TEMPERATURE = 0.07  # 대조 학습 온도
EMA_DECAY = 0.999            # EMA 인코더 감쇠율
MASK_RATIO = 0.3             # 센서 마스킹 비율
MEMORY_BANK_SIZE = 1024      # 대조 학습 메모리 뱅크 크기
ONLINE_BATCH_SIZE = 8        # 온라인 학습 미니배치 크기
MAX_REPLAY_BUFFER = 50000    # 경험 재생 버퍼 최대 크기
GRAD_CLIP_NORM = 1.0         # 그래디언트 클리핑 노름
EPS = 1e-8                   # 수치 안정성 엡실론


# ─── 열거형 / Enums ──────────────────────────────────────────────────────────


class SSLTask(str):
    """자기지도학습 태스크 식별자 / Self-supervised learning task identifiers."""
    TEMPORAL = "temporal_prediction"
    CROSS_MODAL = "cross_modal_prediction"
    MASKED_SENSOR = "masked_sensor_prediction"
    CONTRASTIVE = "contrastive_learning"
    ROTATION = "rotation_prediction"


class Modality(str):
    """센서 모달리티 / Sensor modality identifiers."""
    VISUAL = "visual"
    TACTILE = "tactile"
    FORCE = "force"
    PROPRIOCEPTIVE = "proprioceptive"
    INERTIAL = "inertial"


# 모달리티별 차원 매핑 / Modality-to-dimension mapping
MODALITY_DIMS: Dict[str, int] = {
    Modality.VISUAL: VISUAL_INPUT_DIM,
    Modality.TACTILE: TACTILE_INPUT_DIM,
    Modality.FORCE: FORCE_INPUT_DIM,
    Modality.PROPRIOCEPTIVE: PROPRIO_INPUT_DIM,
    Modality.INERTIAL: IMU_INPUT_DIM,
}

# 모달리티 인덱스 오프셋 / Modality index offsets in concatenated sensor vector
MODALITY_OFFSETS: Dict[str, Tuple[int, int]] = {}
_offset = 0
for _mod, _dim in MODALITY_DIMS.items():
    MODALITY_OFFSETS[_mod] = (_offset, _offset + _dim)
    _offset += _dim


# ─── 데이터 클래스 / Data Classes ────────────────────────────────────────────


@dataclass
class SSLObservation:
    """
    자기지도학습 관측 / Self-supervised learning observation.

    로봇의 다중 모달 센서 데이터를 하나의 관측으로 묶습니다.
    라벨이 필요 없습니다 — 센서 데이터 자체가 학습 신호입니다.

    Attributes:
        sensor_vector: 결합된 센서 벡터 [TOTAL_SENSOR_DIM]
        modality_mask: 각 모달리티의 활성 여부 (1=활성, 0=비활성)
        timestamp: 관측 시각
        metadata: 추가 메타데이터
    """
    sensor_vector: np.ndarray = field(
        default_factory=lambda: np.zeros(TOTAL_SENSOR_DIM, dtype=np.float32)
    )
    modality_mask: Dict[str, bool] = field(default_factory=lambda: {
        Modality.VISUAL: True,
        Modality.TACTILE: True,
        Modality.FORCE: True,
        Modality.PROPRIOCEPTIVE: True,
        Modality.INERTIAL: True,
    })
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_modality_slice(self, modality: str) -> np.ndarray:
        """특정 모달리티 데이터 슬라이스 / Get slice for a specific modality."""
        start, end = MODALITY_OFFSETS.get(modality, (0, 0))
        return self.sensor_vector[start:end]

    def set_modality_slice(self, modality: str, data: np.ndarray) -> None:
        """특정 모달리티 데이터 설정 / Set slice for a specific modality."""
        start, end = MODALITY_OFFSETS.get(modality, (0, 0))
        data = np.asarray(data, dtype=np.float32).flatten()
        self.sensor_vector[start:end] = data[:end - start]


@dataclass
class SSLTrainingRecord:
    """
    자기지도학습 훈련 기록 / SSL training record.

    각 학습 스텝의 손실 값을 기록합니다.
    """
    record_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    temporal_loss: float = 0.0
    cross_modal_loss: float = 0.0
    masked_loss: float = 0.0
    contrastive_loss: float = 0.0
    rotation_loss: float = 0.0
    total_loss: float = 0.0
    learning_rate: float = DEFAULT_LR
    step: int = 0


# ─── PyTorch 신경망 / PyTorch Neural Networks ────────────────────────────────

if TORCH_AVAILABLE:

    class MultiModalEncoder(nn.Module):
        """
        다중 모달 센서 인코더 / Multi-modal sensor encoder.

        시각, 촉각, 힘, 고유수용, 관성 데이터를 각각의 서브 인코더로
        처리한 후, 공유 잠재 공간으로 융합합니다.

        Architecture:
          각 모달리티 → ModalityEncoder → [embed_dim]
          모든 모달리티 임베딩 연결 → FusionNet → [SHARED_LATENT_DIM]
        """

        def __init__(
            self,
            latent_dim: int = SHARED_LATENT_DIM,
            hidden_dim: int = HIDDEN_DIM,
        ) -> None:
            super().__init__()
            self.latent_dim = latent_dim

            # 모달리티별 서브 인코더 / Per-modality sub-encoders
            self.visual_enc = nn.Sequential(
                nn.Linear(VISUAL_INPUT_DIM, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, 128),
            )

            self.tactile_enc = nn.Sequential(
                nn.Linear(TACTILE_INPUT_DIM, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, 128),
            )

            self.force_enc = nn.Sequential(
                nn.Linear(FORCE_INPUT_DIM, 64),
                nn.ReLU(),
                nn.Linear(64, 64),
                nn.ReLU(),
                nn.Linear(64, 64),
            )

            self.proprio_enc = nn.Sequential(
                nn.Linear(PROPRIO_INPUT_DIM, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, 128),
            )

            self.imu_enc = nn.Sequential(
                nn.Linear(IMU_INPUT_DIM, 64),
                nn.ReLU(),
                nn.Linear(64, 64),
                nn.ReLU(),
                nn.Linear(64, 64),
            )

            # 융합 네트워크 / Fusion network
            # 128 + 128 + 64 + 128 + 64 = 512
            fusion_input = 128 + 128 + 64 + 128 + 64
            self.fusion = nn.Sequential(
                nn.Linear(fusion_input, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_dim, latent_dim),
            )

            self._init_weights()
            logger.debug("MultiModalEncoder 생성: latent=%d", latent_dim)

        def _init_weights(self) -> None:
            """가중치 초기화 / Initialize weights."""
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    nn.init.xavier_uniform_(module.weight)
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)

        def forward(
            self,
            visual: torch.Tensor,
            tactile: torch.Tensor,
            force: torch.Tensor,
            proprio: torch.Tensor,
            imu: torch.Tensor,
        ) -> torch.Tensor:
            """
            순전파 / Forward pass.

            Args:
                visual: [batch, VISUAL_INPUT_DIM]
                tactile: [batch, TACTILE_INPUT_DIM]
                force: [batch, FORCE_INPUT_DIM]
                proprio: [batch, PROPRIO_INPUT_DIM]
                imu: [batch, IMU_INPUT_DIM]

            Returns:
                잠재 표현 [batch, latent_dim]
            """
            v = self.visual_enc(visual)
            t = self.tactile_enc(tactile)
            f = self.force_enc(force)
            p = self.proprio_enc(proprio)
            i = self.imu_enc(imu)

            fused = torch.cat([v, t, f, p, i], dim=-1)
            latent = self.fusion(fused)
            return latent

    class TemporalPredictorNet(nn.Module):
        """
        시간 예측 네트워크 / Temporal prediction network.

        현재 잠재 표현으로 다음 시점의 잠재 표현을 예측합니다.
        JEPA (Joint Embedding Predictive Architecture) 스타일:
        예측 대상은 원본 센서가 아닌 잠재 표현입니다.

        Architecture:
          z_t → FC(256) → ReLU → FC(256) → ReLU → FC(256) → z_{t+1}
        """

        def __init__(self, latent_dim: int = SHARED_LATENT_DIM) -> None:
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(latent_dim, 256),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(256, 256),
                nn.ReLU(),
                nn.Linear(256, latent_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

        def forward(self, z_current: torch.Tensor) -> torch.Tensor:
            """현재 잠재 → 다음 잠재 예측 / Predict next latent from current."""
            return self.net(z_current)

    class CrossModalPredictorNet(nn.Module):
        """
        크로스모달 예측 네트워크 / Cross-modal prediction network.

        한 모달리티(또는 모달리티 집합)의 임베딩으로
        다른 모달리티의 임베딩을 예측합니다.
        예: 시각+관성 → 촉각, 촉각+힘 → 시각

        Architecture:
          source_emb → FC(256) → ReLU → FC(256) → ReLU → FC(target_emb_dim)
        """

        def __init__(
            self,
            source_dim: int = SHARED_LATENT_DIM,
            target_dim: int = 128,
            hidden_dim: int = HIDDEN_DIM,
        ) -> None:
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(source_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, target_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

        def forward(self, source_emb: torch.Tensor) -> torch.Tensor:
            """소스 임베딩 → 타겟 임베딩 예측 / Predict target embedding from source."""
            return self.net(source_emb)

    class MaskedSensorPredictorNet(nn.Module):
        """
        마스크 센서 예측 네트워크 / Masked sensor prediction network.

        센서 벡터의 일부 채널을 마스킹하고, 인코딩된 표현에서
        마스킹된 채널을 복원합니다. MAE (Masked Autoencoder) 스타일.

        Architecture:
          latent → FC(256) → ReLU → FC(512) → ReLU → FC(TOTAL_SENSOR_DIM)
        """

        def __init__(
            self,
            latent_dim: int = SHARED_LATENT_DIM,
            output_dim: int = TOTAL_SENSOR_DIM,
        ) -> None:
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(latent_dim, 256),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(256, 512),
                nn.ReLU(),
                nn.Linear(512, output_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

        def forward(self, latent: torch.Tensor) -> torch.Tensor:
            """잠재 표현 → 전체 센서 복원 / Reconstruct full sensor from latent."""
            return self.net(latent)

    class ContrastiveProjectionHead(nn.Module):
        """
        대조 학습 프로젝션 헤드 / Contrastive learning projection head.

        SimCLR 스타일: 인코더 출력을 프로젝션 공간으로 매핑하여
        대조 손실을 계산합니다. 학습 후 프로젝션 헤드는 버리고
        인코더 표현만 사용합니다.

        Architecture:
          latent → FC(256) → ReLU → FC(PROJECTION_DIM)
        """

        def __init__(
            self,
            input_dim: int = SHARED_LATENT_DIM,
            proj_dim: int = PROJECTION_DIM,
        ) -> None:
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(input_dim, 256),
                nn.ReLU(),
                nn.Linear(256, proj_dim),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

        def forward(self, latent: torch.Tensor) -> torch.Tensor:
            """잠재 → 프로젝션 공간 / Project latent to contrastive space."""
            h = self.net(latent)
            return F.normalize(h, p=2, dim=-1)

    class RotationPredictorNet(nn.Module):
        """
        회전 예측 네트워크 / Rotation prediction network.

        물체를 밀었을 때 물체가 어떻게 회전할지 예측합니다.
        현재 상태 잠재 표현 + 행동 임베딩 → 회전 방향 분류 (4분류).

        RotNet 스타일 사전학습: 상태 변화로부터 물리적 이해를 학습.

        Architecture:
          cat(z_state, z_action) → FC(256) → ReLU → FC(128) → ReLU → FC(4)
          4 classes: no_rotation, clockwise, counter_clockwise, tumble
        """

        NUM_ROTATION_CLASSES = 4

        def __init__(
            self,
            state_dim: int = SHARED_LATENT_DIM,
            action_dim: int = 32,
            hidden_dim: int = HIDDEN_DIM,
        ) -> None:
            super().__init__()
            input_dim = state_dim + action_dim
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_dim, 128),
                nn.ReLU(),
                nn.Linear(128, self.NUM_ROTATION_CLASSES),
            )
            self._init_weights()

        def _init_weights(self) -> None:
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

        def forward(
            self, z_state: torch.Tensor, z_action: torch.Tensor
        ) -> torch.Tensor:
            """
            상태+행동 → 회전 분류 / Predict rotation class from state and action.

            Args:
                z_state: 상태 잠재 표현 [batch, state_dim]
                z_action: 행동 임베딩 [batch, action_dim]

            Returns:
                회전 클래스 로짓 [batch, 4]
            """
            x = torch.cat([z_state, z_action], dim=-1)
            return self.net(x)


# ─── Numpy 폴백 인코더 / Numpy Fallback Encoder ──────────────────────────────


class NumpyMultiModalEncoder:
    """
    Numpy 기반 다중 모달 인코더 / Numpy-based multi-modal encoder.

    PyTorch를 사용할 수 없는 환경에서의 폴백 구현입니다.
    학습은 제한적이지만 추론은 가능합니다.
    """

    def __init__(
        self,
        latent_dim: int = SHARED_LATENT_DIM,
        hidden_dim: int = HIDDEN_DIM,
    ) -> None:
        self.latent_dim = latent_dim
        scale = 0.02

        # 모달리티별 서브 인코더 가중치 / Per-modality sub-encoder weights
        self.visual_w = np.random.randn(VISUAL_INPUT_DIM, 128).astype(np.float32) * scale
        self.tactile_w = np.random.randn(TACTILE_INPUT_DIM, 128).astype(np.float32) * scale
        self.force_w = np.random.randn(FORCE_INPUT_DIM, 64).astype(np.float32) * scale
        self.proprio_w = np.random.randn(PROPRIO_INPUT_DIM, 128).astype(np.float32) * scale
        self.imu_w = np.random.randn(IMU_INPUT_DIM, 64).astype(np.float32) * scale

        # 융합 가중치 / Fusion weights
        fusion_input = 128 + 128 + 64 + 128 + 64  # 512
        self.fusion_w1 = np.random.randn(fusion_input, hidden_dim).astype(np.float32) * scale
        self.fusion_b1 = np.zeros(hidden_dim, dtype=np.float32)
        self.fusion_w2 = np.random.randn(hidden_dim, latent_dim).astype(np.float32) * scale
        self.fusion_b2 = np.zeros(latent_dim, dtype=np.float32)

    def encode(self, sensor_vector: np.ndarray) -> np.ndarray:
        """
        센서 벡터 인코딩 / Encode sensor vector to latent.

        Args:
            sensor_vector: [TOTAL_SENSOR_DIM] 또는 [batch, TOTAL_SENSOR_DIM]

        Returns:
            잠재 표현 [latent_dim] 또는 [batch, latent_dim]
        """
        x = np.asarray(sensor_vector, dtype=np.float32)
        if x.ndim == 1:
            x = x.reshape(1, -1)

        # 모달리티별 슬라이스 / Modality slices
        v = x[:, 0:VISUAL_INPUT_DIM] @ self.visual_w
        t = x[:, VISUAL_INPUT_DIM:VISUAL_INPUT_DIM + TACTILE_INPUT_DIM] @ self.tactile_w
        f_start = VISUAL_INPUT_DIM + TACTILE_INPUT_DIM
        f = x[:, f_start:f_start + FORCE_INPUT_DIM] @ self.force_w
        p_start = f_start + FORCE_INPUT_DIM
        p = x[:, p_start:p_start + PROPRIO_INPUT_DIM] @ self.proprio_w
        i_start = p_start + PROPRIO_INPUT_DIM
        i = x[:, i_start:i_start + IMU_INPUT_DIM] @ self.imu_w

        fused = np.concatenate([v, t, f, p, i], axis=-1)
        h = np.maximum(0, fused @ self.fusion_w1 + self.fusion_b1)
        z = h @ self.fusion_w2 + self.fusion_b2

        # L2 정규화 / L2 normalize
        norms = np.linalg.norm(z, axis=1, keepdims=True)
        norms = np.maximum(norms, EPS)
        z = z / norms
        return z.squeeze(0) if sensor_vector.ndim == 1 else z


# ─── 물리적 증강 / Physical Augmentations ────────────────────────────────────


class PhysicalAugmentation:
    """
    물리적 센서 데이터 증강 / Physical sensor data augmentation.

    대조 학습을 위해 센서 데이터에 물리적으로 타당한 변형을 적용합니다.
    로봇의 센서 데이터는 이미지와 달리 물리적 제약이 있으므로,
    물리적으로 의미 있는 증강만 사용합니다.

    증강 방법 / Augmentation methods:
      1. Gaussian noise: 센서 노이즈 시뮬레이션
      2. Temporal jitter: 시간 축 미세 이동
      3. Modality dropout: 특정 모달리티 비활성화
      4. Scale jitter: 센서 값 스케일 미세 변동
    """

    def __init__(
        self,
        noise_std: float = 0.01,
        scale_range: Tuple[float, float] = (0.95, 1.05),
        modality_drop_prob: float = 0.1,
    ) -> None:
        self._noise_std = noise_std
        self._scale_range = scale_range
        self._modality_drop_prob = modality_drop_prob

    def augment(self, sensor_vector: np.ndarray, rng: np.random.RandomState = None) -> np.ndarray:
        """
        센서 벡터에 물리적 증강 적용 / Apply physical augmentation to sensor vector.

        Args:
            sensor_vector: [TOTAL_SENSOR_DIM]
            rng: 난수 생성기 (재현성)

        Returns:
            증강된 센서 벡터 [TOTAL_SENSOR_DIM]
        """
        if rng is None:
            rng = np.random.RandomState()

        augmented = sensor_vector.copy().astype(np.float32)

        # 1. 가우시안 노이즈 / Gaussian noise
        noise = rng.randn(*augmented.shape).astype(np.float32) * self._noise_std
        augmented += noise

        # 2. 스케일 지터 / Scale jitter
        scale = rng.uniform(*self._scale_range)
        augmented *= scale

        # 3. 모달리티 드롭아웃 / Modality dropout
        for mod_name, (start, end) in MODALITY_OFFSETS.items():
            if rng.random() < self._modality_drop_prob:
                augmented[start:end] = 0.0

        return augmented

    def augment_torch(
        self, sensor_vector: torch.Tensor
    ) -> torch.Tensor:
        """
        PyTorch 텐서에 물리적 증강 적용 / Apply physical augmentation to PyTorch tensor.

        Args:
            sensor_vector: [batch, TOTAL_SENSOR_DIM]

        Returns:
            증강된 텐서 [batch, TOTAL_SENSOR_DIM]
        """
        augmented = sensor_vector.clone()

        # 가우시안 노이즈 / Gaussian noise
        noise = torch.randn_like(augmented) * self._noise_std
        augmented = augmented + noise

        # 스케일 지터 / Scale jitter
        scale = 1.0 + (torch.rand(augmented.shape[0], 1, device=augmented.device)
                        * (self._scale_range[1] - self._scale_range[0])
                        + self._scale_range[0] - 1.0)
        augmented = augmented * scale

        # 모달리티 드롭아웃 / Modality dropout
        for mod_name, (start, end) in MODALITY_OFFSETS.items():
            mask = torch.rand(augmented.shape[0], device=augmented.device)
            drop_mask = (mask < self._modality_drop_prob).float()
            augmented[:, start:end] = augmented[:, start:end] * (1.0 - drop_mask.unsqueeze(1))

        return augmented


# ─── SQLite 저장소 / SQLite Repository ────────────────────────────────────────


class SSLRepository:
    """
    자기지도학습 SQLite 저장소 / Self-supervised learning SQLite repository.

    학습 기록, 표현 벡터, 체크포인트 메타데이터를 저장합니다.
    """

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS ssl_training_history (
        step INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        temporal_loss REAL DEFAULT 0.0,
        cross_modal_loss REAL DEFAULT 0.0,
        masked_loss REAL DEFAULT 0.0,
        contrastive_loss REAL DEFAULT 0.0,
        rotation_loss REAL DEFAULT 0.0,
        total_loss REAL DEFAULT 0.0,
        learning_rate REAL,
        representations_computed INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_ssl_ts ON ssl_training_history(timestamp);

    CREATE TABLE IF NOT EXISTS ssl_checkpoints (
        checkpoint_id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        step INTEGER,
        avg_loss REAL,
        path TEXT
    );

    CREATE TABLE IF NOT EXISTS representation_cache (
        cache_id INTEGER PRIMARY KEY AUTOINCREMENT,
        experience_id TEXT,
        representation_json TEXT,
        timestamp TEXT,
        modality_mask_json TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_repr_exp ON representation_cache(experience_id);
    """

    def __init__(self, db_path: Union[str, Path] = "ssl_learning.db") -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(
                str(self._db_path), check_same_thread=False
            )
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript(self.SCHEMA)
        conn.commit()

    def save_training_record(self, record: SSLTrainingRecord) -> None:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT INTO ssl_training_history
                (timestamp, temporal_loss, cross_modal_loss, masked_loss,
                 contrastive_loss, rotation_loss, total_loss, learning_rate,
                 representations_computed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (record.timestamp, record.temporal_loss, record.cross_modal_loss,
                 record.masked_loss, record.contrastive_loss, record.rotation_loss,
                 record.total_loss, record.learning_rate, record.step),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("SSL 훈련 기록 저장 실패: %s", e)

    def save_checkpoint_meta(self, checkpoint_id: str, step: int, avg_loss: float, path: str) -> None:
        try:
            conn = self._get_conn()
            conn.execute(
                """INSERT OR REPLACE INTO ssl_checkpoints
                (checkpoint_id, timestamp, step, avg_loss, path)
                VALUES (?, ?, ?, ?, ?)""",
                (checkpoint_id, datetime.now(timezone.utc).isoformat(), step, avg_loss, path),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("SSL 체크포인트 메타 저장 실패: %s", e)

    def get_stats(self) -> Dict[str, Any]:
        try:
            conn = self._get_conn()
            total_steps = conn.execute("SELECT COUNT(*) FROM ssl_training_history").fetchone()[0]
            avg_loss_row = conn.execute(
                "SELECT AVG(total_loss) FROM ssl_training_history"
            ).fetchone()
            avg_loss = avg_loss_row[0] if avg_loss_row and avg_loss_row[0] is not None else 0.0
            recent_row = conn.execute(
                "SELECT total_loss FROM ssl_training_history ORDER BY step DESC LIMIT 1"
            ).fetchone()
            recent_loss = recent_row[0] if recent_row else 0.0
            return {
                "total_training_steps": total_steps,
                "avg_total_loss": round(avg_loss, 6),
                "recent_loss": round(recent_loss, 6),
            }
        except sqlite3.Error:
            return {}


# ─── 경험 재생 버퍼 / Experience Replay Buffer ──────────────────────────────


class SSLReplayBuffer:
    """
    자기지도학습 경험 재생 버퍼 / SSL experience replay buffer.

    온라인 학습에서 경험을 저장하고 미니배치를 샘플링합니다.
    우선순위 기반 샘플링으로 높은 학습 신호를 가진 경험을 우선 학습합니다.
    """

    def __init__(self, max_size: int = MAX_REPLAY_BUFFER) -> None:
        self._max_size = max_size
        self._buffer: Deque[SSLObservation] = deque(maxlen=max_size)
        self._priorities: Deque[float] = deque(maxlen=max_size)
        self._lock = threading.Lock()
        logger.debug("SSLReplayBuffer 초기화: max_size=%d", max_size)

    def add(self, observation: SSLObservation, priority: float = 1.0) -> None:
        """관측 추가 / Add observation with priority."""
        with self._lock:
            self._buffer.append(observation)
            self._priorities.append(priority)

    def sample(self, batch_size: int = ONLINE_BATCH_SIZE) -> List[SSLObservation]:
        """
        우선순위 기반 샘플링 / Priority-based sampling.

        높은 우선순위의 경험을 더 자주 샘플링합니다.
        """
        with self._lock:
            if len(self._buffer) == 0:
                return []
            n = min(batch_size, len(self._buffer))

            # 우선순위를 확률로 변환 / Convert priorities to probabilities
            priorities = np.array(self._priorities, dtype=np.float64)
            priorities = np.maximum(priorities, 1e-6)
            probs = priorities / priorities.sum()

            indices = np.random.choice(len(self._buffer), size=n, replace=False, p=probs)
            return [self._buffer[i] for i in indices]

    def update_priority(self, index: int, priority: float) -> None:
        """우선순위 업데이트 / Update priority for a specific experience."""
        with self._lock:
            if 0 <= index < len(self._priorities):
                self._priorities[index] = priority

    def __len__(self) -> int:
        with self._lock:
            return len(self._buffer)

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            if not self._priorities:
                return {"size": 0, "avg_priority": 0.0}
            return {
                "size": len(self._buffer),
                "avg_priority": round(float(np.mean(list(self._priorities))), 4),
                "max_priority": round(float(max(self._priorities)), 4),
            }


# ─── 메모리 뱅크 / Memory Bank for Contrastive Learning ──────────────────────


class MemoryBank:
    """
    대조 학습 메모리 뱅크 / Contrastive learning memory bank.

    과거 표현을 저장하여 대조 학습의 네거티브 샘플로 사용합니다.
    MoCo 스타일: 큐 구조로 오래된 표현을 자동 교체합니다.
    """

    def __init__(self, size: int = MEMORY_BANK_SIZE, dim: int = PROJECTION_DIM) -> None:
        self._size = size
        self._dim = dim
        self._bank = np.zeros((size, dim), dtype=np.float32)
        self._ptr = 0
        self._count = 0
        self._lock = threading.Lock()

    @property
    def is_initialized(self) -> bool:
        """메모리 뱅크가 충분히 채워졌는지 / Whether bank has enough entries."""
        return self._count >= self._size * 0.5

    def enqueue(self, representations: np.ndarray) -> None:
        """
        새로운 표현을 메모리 뱅크에 추가 / Add new representations to the bank.

        Args:
            representations: [batch, dim]
        """
        representations = np.asarray(representations, dtype=np.float32)
        if representations.ndim == 1:
            representations = representations.reshape(1, -1)

        with self._lock:
            batch_size = representations.shape[0]
            for i in range(batch_size):
                self._bank[self._ptr % self._size] = representations[i]
                self._ptr += 1
                self._count = min(self._count + 1, self._size)

    def get_negatives(self, n: int = 256) -> np.ndarray:
        """
        네거티브 샘플 조회 / Get negative samples from the bank.

        Args:
            n: 네거티브 샘플 수

        Returns:
            [n, dim] 네거티브 표현
        """
        with self._lock:
            count = min(self._count, self._size)
            if count == 0:
                return np.zeros((n, self._dim), dtype=np.float32)
            indices = np.random.choice(count, size=min(n, count), replace=False)
            return self._bank[indices]

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "size": self._size,
                "filled": min(self._count, self._size),
                "fill_ratio": round(min(self._count, self._size) / self._size, 3),
            }


# ─── 온라인 자기지도학습기 / Online Self-Supervised Learner ──────────────────


class OnlineSSLearner:
    """
    온라인 자기지도학습기 / Online Self-Supervised Learner.

    라벨이 없는 물리적 경험에서 스스로 유용한 표현을 학습합니다.
    로봇이 물리적으로 경험할 때마다 즉시 학습합니다 (온라인).

    5가지 자기지도 태스크:
      1. Temporal Prediction: 현재 상태로 다음 상태 예측
      2. Cross-Modal Prediction: 시각↔촉각, 시각↔힘 등 모달리티 간 예측
      3. Masked Sensor Prediction: 마스킹된 센서 채널 복원
      4. Contrastive Learning: 유사 상태는 유사 표현 (SimCLR)
      5. Rotation Prediction: 밀기 시 회전 방향 예측

    학습된 표현은 하위 작업(지형 분류, 파지 예측, RL 정책 등)으로
    전이됩니다. 전이 시 인코더를 동결하고 작은 헤드만 학습합니다.

    Usage:
        learner = OnlineSSLearner()
        learner.initialize()
        # 온라인 학습 — 매 물리적 경험 후 호출
        learner.on_experience(sensor_data)
        # 표현 추출 — 하위 작업에 사용
        representation = learner.get_representation(sensor_data)
        # 배치 학습 — 경험 재생
        metrics = learner.train_step()

    Thread Safety:
        모든 공개 메서드는 스레드 안전합니다.
        메인 루프에서 안전하게 호출 가능합니다.
    """

    def __init__(
        self,
        latent_dim: int = SHARED_LATENT_DIM,
        learning_rate: float = DEFAULT_LR,
        device: Optional[str] = None,
        db_path: Union[str, Path] = "ssl_learning.db",
    ) -> None:
        self._latent_dim = latent_dim
        self._learning_rate = learning_rate
        self._use_torch = TORCH_AVAILABLE

        # 장치 설정 / Device setup
        if self._use_torch:
            if device is None:
                self._device = torch.device(
                    "cuda" if torch.cuda.is_available() else "cpu"
                )
            else:
                self._device = torch.device(device)
        else:
            self._device = None

        # 저장소 / Repository
        self._repository = SSLRepository(db_path)

        # 재생 버퍼 / Replay buffer
        self._replay_buffer = SSLReplayBuffer()

        # 메모리 뱅크 / Memory bank
        self._memory_bank = MemoryBank(
            size=MEMORY_BANK_SIZE, dim=PROJECTION_DIM
        )

        # 증강 / Augmentation
        self._augmentation = PhysicalAugmentation()

        # PyTorch 모델 / PyTorch models
        self._encoder: Any = None
        self._encoder_ema: Any = None
        self._temporal_predictor: Any = None
        self._cross_modal_predictors: Dict[str, Any] = {}
        self._masked_predictor: Any = None
        self._contrastive_head: Any = None
        self._rotation_predictor: Any = None
        self._optimizer: Any = None

        # Numpy 폴백 / Numpy fallback
        self._numpy_encoder: Optional[NumpyMultiModalEncoder] = None

        # 학습 상태 / Training state
        self._training_step: int = 0
        self._representations_computed: int = 0
        self._total_experiences: int = 0
        self._loss_history: Dict[str, Deque[float]] = {
            SSLTask.TEMPORAL: deque(maxlen=500),
            SSLTask.CROSS_MODAL: deque(maxlen=500),
            SSLTask.MASKED_SENSOR: deque(maxlen=500),
            SSLTask.CONTRASTIVE: deque(maxlen=500),
            SSLTask.ROTATION: deque(maxlen=500),
        }

        # 이전 관측 (시간 예측용) / Previous observation (for temporal prediction)
        self._prev_observation: Optional[SSLObservation] = None
        self._prev_latent: Optional[np.ndarray] = None

        # 스레드 안전 / Thread safety
        self._lock = threading.Lock()
        self._train_lock = threading.Lock()

        # 백그라운드 학습 / Background training
        self._running = False
        self._bg_thread: Optional[threading.Thread] = None

        # RNG / Random number generator
        self._rng = np.random.RandomState(42)

        logger.info(
            "OnlineSSLearner 생성: latent=%d, lr=%.1e, torch=%s, device=%s",
            latent_dim, learning_rate, self._use_torch, self._device,
        )

    def initialize(self) -> None:
        """
        자기지도학습 시스템 초기화 / Initialize self-supervised learning system.

        PyTorch 모델, 옵티마이저, EMA 인코더를 생성합니다.
        """
        if self._use_torch:
            self._init_pytorch_models()
        else:
            self._numpy_encoder = NumpyMultiModalEncoder(latent_dim=self._latent_dim)

        # 백그라운드 학습 스레드 시작 / Start background training thread
        self._running = True
        self._bg_thread = threading.Thread(
            target=self._background_training_loop,
            daemon=True,
            name="ssl_bg_training",
        )
        self._bg_thread.start()

        logger.info(
            "OnlineSSLearner 초기화 완료 — 온라인 자기지도학습 활성화 "
            "(PyTorch=%s, 5 SSL 태스크)", self._use_torch
        )

    def _init_pytorch_models(self) -> None:
        """PyTorch 모델 초기화 / Initialize PyTorch models."""
        dev = self._device

        # 메인 인코더 / Main encoder
        self._encoder = MultiModalEncoder(latent_dim=self._latent_dim).to(dev)

        # EMA 인코더 (대조 학습용) / EMA encoder (for contrastive learning)
        self._encoder_ema = MultiModalEncoder(latent_dim=self._latent_dim).to(dev)
        # EMA 인코더를 메인 인코더로 초기화 / Initialize EMA from main encoder
        self._update_ema_encoder(decay=0.0)  # decay=0 → 완전 복사
        # EMA 인코더는 그래디언트 계산 안함 / No grad for EMA encoder
        for param in self._encoder_ema.parameters():
            param.requires_grad = False

        # 시간 예측기 / Temporal predictor
        self._temporal_predictor = TemporalPredictorNet(latent_dim=self._latent_dim).to(dev)

        # 크로스모달 예측기 / Cross-modal predictors
        # 시각 → 촉각, 촉각 → 시각, 시각+관성 → 힘, 촉각+힘 → 시각
        self._cross_modal_predictors = {
            "visual_to_tactile": CrossModalPredictorNet(
                source_dim=self._latent_dim, target_dim=128
            ).to(dev),
            "tactile_to_visual": CrossModalPredictorNet(
                source_dim=self._latent_dim, target_dim=128
            ).to(dev),
            "visual_imu_to_force": CrossModalPredictorNet(
                source_dim=self._latent_dim, target_dim=64
            ).to(dev),
            "tactile_force_to_visual": CrossModalPredictorNet(
                source_dim=self._latent_dim, target_dim=128
            ).to(dev),
        }

        # 마스크 센서 예측기 / Masked sensor predictor
        self._masked_predictor = MaskedSensorPredictorNet(
            latent_dim=self._latent_dim, output_dim=TOTAL_SENSOR_DIM
        ).to(dev)

        # 대조 학습 프로젝션 헤드 / Contrastive projection head
        self._contrastive_head = ContrastiveProjectionHead(
            input_dim=self._latent_dim, proj_dim=PROJECTION_DIM
        ).to(dev)

        # 회전 예측기 / Rotation predictor
        self._rotation_predictor = RotationPredictorNet(
            state_dim=self._latent_dim, action_dim=32
        ).to(dev)

        # 옵티마이저 / Optimizer
        all_params = (
            list(self._encoder.parameters()) +
            list(self._temporal_predictor.parameters()) +
            list(self._masked_predictor.parameters()) +
            list(self._contrastive_head.parameters()) +
            list(self._rotation_predictor.parameters())
        )
        for pred in self._cross_modal_predictors.values():
            all_params.extend(list(pred.parameters()))

        self._optimizer = torch.optim.AdamW(all_params, lr=self._learning_rate, weight_decay=1e-5)

        # 학습 가능한 대조 학습 온도 / Learnable contrastive temperature
        self._log_temperature = nn.Parameter(
            torch.tensor(math.log(CONTRASTIVE_TEMPERATURE), dtype=torch.float32)
        ).to(dev)
        # 온도 파라미터를 옵티마이저에 추가 / Add temperature to optimizer
        self._optimizer.add_param_group({"params": [self._log_temperature]})

        # 모달리티별 서브 인코더 참조 (크로스모달 예측용)
        self._modality_encoders = {
            Modality.VISUAL: self._encoder.visual_enc,
            Modality.TACTILE: self._encoder.tactile_enc,
            Modality.FORCE: self._encoder.force_enc,
            Modality.PROPRIOCEPTIVE: self._encoder.proprio_enc,
            Modality.INERTIAL: self._encoder.imu_enc,
        }

    def _update_ema_encoder(self, decay: float = EMA_DECAY) -> None:
        """EMA 인코더 업데이트 / Update EMA encoder with exponential moving average."""
        if not self._use_torch or self._encoder_ema is None:
            return
        with torch.no_grad():
            for param_ema, param_main in zip(
                self._encoder_ema.parameters(), self._encoder.parameters()
            ):
                param_ema.data.mul_(decay).add_(param_main.data, alpha=1.0 - decay)

    @property
    def temperature(self) -> float:
        """현재 대조 학습 온도 / Current contrastive temperature."""
        if self._use_torch and hasattr(self, '_log_temperature') and self._log_temperature is not None:
            return float(self._log_temperature.exp().item())
        return CONTRASTIVE_TEMPERATURE

    # ─── 온라인 학습: 경험 수신 / Online Learning: Receive Experience ──────

    def on_experience(self, sensor_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        물리적 경험 수신 및 즉시 학습 / Receive physical experience and learn online.

        로봇이 물리적 경험을 할 때마다 호출됩니다.
        라벨이 필요 없습니다 — 센서 데이터 자체가 학습 신호입니다.

        Args:
            sensor_data: 센서 데이터 딕셔너리
                키: "visual", "tactile", "force", "proprioceptive", "inertial"
                값: np.ndarray 또는 리스트

        Returns:
            학습 메트릭 딕셔너리
        """
        with self._lock:
            self._total_experiences += 1

        # 관측 객체 생성 / Create observation object
        obs = self._sensor_data_to_observation(sensor_data)

        # 재생 버퍼에 추가 / Add to replay buffer
        priority = self._compute_priority(obs)
        self._replay_buffer.add(obs, priority)

        # 온라인 학습 (즉시) / Online learning (immediate)
        metrics = self._online_update(obs)

        # 이전 관측 업데이트 / Update previous observation
        with self._lock:
            self._prev_observation = obs

        return metrics

    def _sensor_data_to_observation(self, sensor_data: Dict[str, Any]) -> SSLObservation:
        """센서 데이터 딕셔너리를 SSLObservation으로 변환 / Convert sensor data dict to SSLObservation."""
        obs = SSLObservation()
        modality_mask = {}

        for mod_name, (start, end) in MODALITY_OFFSETS.items():
            data = sensor_data.get(mod_name)
            if data is not None:
                arr = np.asarray(data, dtype=np.float32).flatten()
                n = min(len(arr), end - start)
                obs.sensor_vector[start:start + n] = arr[:n]
                modality_mask[mod_name] = True
            else:
                modality_mask[mod_name] = False

        obs.modality_mask = modality_mask
        obs.timestamp = time.time()
        return obs

    def _compute_priority(self, obs: SSLObservation) -> float:
        """
        관측의 학습 우선순위 계산 / Compute learning priority for an observation.

        높은 노이즈, 드문 모달리티 조합, 큰 변화 = 높은 우선순위.
        """
        # 기본 우선순위 / Base priority
        priority = 1.0

        # 활성 모달리티 수에 따른 보너스 / Bonus for more active modalities
        active = sum(1 for v in obs.modality_mask.values() if v)
        priority *= (1.0 + 0.2 * active)

        # 이전 관측과의 변화량 / Change from previous observation
        if self._prev_observation is not None:
            delta = float(np.linalg.norm(
                obs.sensor_vector - self._prev_observation.sensor_vector
            ))
            priority *= (1.0 + min(delta, 5.0))

        # 센서 벡터의 분산 (정보량 추정) / Variance of sensor vector (information estimate)
        variance = float(np.var(obs.sensor_vector))
        priority *= (1.0 + min(variance, 2.0))

        return priority

    def _online_update(self, obs: SSLObservation) -> Dict[str, Any]:
        """
        단일 경험으로 즉시 온라인 업데이트 / Immediate online update from single experience.

        Args:
            obs: 현재 관측

        Returns:
            학습 메트릭
        """
        metrics: Dict[str, Any] = {
            "temporal_loss": 0.0,
            "contrastive_loss": 0.0,
            "step": self._training_step,
        }

        if not self._use_torch:
            # Numpy 폴백: 인코딩만 수행 / Numpy fallback: encoding only
            latent = self._numpy_encoder.encode(obs.sensor_vector)
            with self._lock:
                self._prev_latent = latent
            return metrics

        # 시간 예측 손실 / Temporal prediction loss
        temporal_loss_val = 0.0
        if self._prev_observation is not None and self._prev_latent is not None:
            temporal_loss_val = self._compute_temporal_loss(obs)
            self._loss_history[SSLTask.TEMPORAL].append(temporal_loss_val)

        # 대조 학습 손실 / Contrastive learning loss
        contrastive_loss_val = self._compute_contrastive_loss_online(obs)
        self._loss_history[SSLTask.CONTRASTIVE].append(contrastive_loss_val)

        # 잠재 표현 저장 / Store latent representation
        with torch.no_grad():
            latent_np = self._encode_observation(obs)
            self._prev_latent = latent_np

        metrics["temporal_loss"] = round(temporal_loss_val, 6)
        metrics["contrastive_loss"] = round(contrastive_loss_val, 6)

        return metrics

    def _compute_temporal_loss(self, current_obs: SSLObservation) -> float:
        """
        시간 예측 손실 계산 / Compute temporal prediction loss.

        z_{t-1} → z_t 예측 오차 (JEPA 스타일: 잠재 공간에서 예측).
        """
        if self._prev_latent is None:
            return 0.0

        with self._train_lock:
            prev_z = torch.tensor(
                self._prev_latent, dtype=torch.float32, device=self._device
            ).unsqueeze(0)

            predicted_z = self._temporal_predictor(prev_z)

            current_z = self._encode_observation_torch(current_obs).unsqueeze(0)
            target_z = current_z.detach()  # JEPA: 타겟은 그래디언트 정지

            # 코사인 유사도 기반 손실 / Cosine similarity-based loss
            loss = 2.0 - 2.0 * F.cosine_similarity(predicted_z, target_z, dim=-1).mean()

            if loss.requires_grad:
                self._optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(
                    self._temporal_predictor.parameters(), GRAD_CLIP_NORM
                )
                self._optimizer.step()

            return float(loss.item())

    def _compute_contrastive_loss_online(self, obs: SSLObservation) -> float:
        """
        온라인 대조 학습 손실 / Online contrastive learning loss.

        현재 관측의 두 증강 뷰를 양성 쌍으로, 메모리 뱅크의
        과거 표현을 음성 샘플로 사용합니다 (MoCo 스타일).
        """
        if not self._use_torch:
            return 0.0

        with self._train_lock:
            # 두 개의 증강 뷰 생성 / Create two augmented views
            aug1 = self._augmentation.augment(obs.sensor_vector, self._rng)
            aug2 = self._augmentation.augment(obs.sensor_vector, self._rng)

            x1 = torch.tensor(aug1, dtype=torch.float32, device=self._device).unsqueeze(0)
            x2 = torch.tensor(aug2, dtype=torch.float32, device=self._device).unsqueeze(0)

            # 메인 인코더로 쿼리 인코딩 / Encode query with main encoder
            z1 = self._encoder(
                self._split_modalities(x1)[0],
                self._split_modalities(x1)[1],
                self._split_modalities(x1)[2],
                self._split_modalities(x1)[3],
                self._split_modalities(x1)[4],
            )
            proj1 = self._contrastive_head(z1)

            # EMA 인코더로 키 인코딩 (그래디언트 없음) / Encode key with EMA encoder
            with torch.no_grad():
                z2 = self._encoder_ema(
                    self._split_modalities(x2)[0],
                    self._split_modalities(x2)[1],
                    self._split_modalities(x2)[2],
                    self._split_modalities(x2)[3],
                    self._split_modalities(x2)[4],
                )
                proj2 = self._contrastive_head(z2)

            # 메모리 뱅크에서 네거티브 / Negatives from memory bank
            negatives = self._memory_bank.get_negatives(n=256)
            neg_tensor = torch.tensor(
                negatives, dtype=torch.float32, device=self._device
            )

            # InfoNCE 손실 / InfoNCE loss
            temp = self._log_temperature.exp()
            pos_sim = torch.sum(proj1 * proj2, dim=-1, keepdim=True) / temp  # [1, 1]
            neg_sim = torch.mm(proj1, neg_tensor.T) / temp  # [1, K]

            logits = torch.cat([pos_sim, neg_sim], dim=-1)  # [1, 1+K]
            labels = torch.zeros(1, dtype=torch.long, device=self._device)  # positive at index 0

            loss = F.cross_entropy(logits, labels)

            self._optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                list(self._encoder.parameters()) +
                list(self._contrastive_head.parameters()) +
                [self._log_temperature],
                GRAD_CLIP_NORM,
            )
            self._optimizer.step()

            # EMA 인코더 업데이트 / Update EMA encoder
            self._update_ema_encoder()

            # 메모리 뱅크에 현재 표현 추가 / Add current representation to memory bank
            with torch.no_grad():
                proj2_np = proj2.cpu().numpy()
                self._memory_bank.enqueue(proj2_np)

            return float(loss.item())

    # ─── 배치 학습 / Batch Training ─────────────────────────────────────────

    def train_step(self) -> Dict[str, Any]:
        """
        배치 학습 스텝 / Batch training step.

        재생 버퍼에서 미니배치를 샘플링하여 모든 SSL 태스크를 학습합니다.
        백그라운드 스레드에서 주기적으로 호출됩니다.

        Returns:
            태스크별 손실 메트릭
        """
        if not self._use_torch:
            return self._train_step_numpy()

        # 미니배치 샘플링 / Sample mini-batch
        batch = self._replay_buffer.sample(ONLINE_BATCH_SIZE)
        if len(batch) < 2:
            return {"status": "insufficient_data"}

        with self._train_lock:
            metrics = {}

            # 1. 마스크 센서 예측 / Masked sensor prediction
            masked_loss = self._train_masked_sensor(batch)
            metrics["masked_loss"] = round(masked_loss, 6)

            # 2. 크로스모달 예측 / Cross-modal prediction
            cross_modal_loss = self._train_cross_modal(batch)
            metrics["cross_modal_loss"] = round(cross_modal_loss, 6)

            # 3. 회전 예측 / Rotation prediction
            rotation_loss = self._train_rotation(batch)
            metrics["rotation_loss"] = round(rotation_loss, 6)

            # 총 손실 / Total loss
            total_loss = masked_loss + cross_modal_loss + rotation_loss
            metrics["total_loss"] = round(total_loss, 6)
            metrics["step"] = self._training_step

            # EMA 인코더 업데이트 / Update EMA encoder
            self._update_ema_encoder()

            # 학습 기록 저장 / Save training record
            record = SSLTrainingRecord(
                masked_loss=masked_loss,
                cross_modal_loss=cross_modal_loss,
                rotation_loss=rotation_loss,
                total_loss=total_loss,
                learning_rate=self._learning_rate,
                step=self._training_step,
            )
            self._repository.save_training_record(record)

            return metrics

    def _train_masked_sensor(self, batch: List[SSLObservation]) -> float:
        """
        마스크 센서 예측 학습 / Train masked sensor prediction.

        센서 벡터의 30% 채널을 무작위로 마스킹하고,
        인코딩된 표현에서 마스킹된 채널을 복원합니다.
        """
        sensor_batch = np.stack([obs.sensor_vector for obs in batch], axis=0)
        sensor_tensor = torch.tensor(sensor_batch, dtype=torch.float32, device=self._device)

        # 마스크 생성 / Create mask
        mask = torch.ones_like(sensor_tensor)
        mask_indices = torch.rand_like(sensor_tensor) < MASK_RATIO
        mask[mask_indices] = 0.0

        # 마스킹된 입력 / Masked input
        masked_input = sensor_tensor * mask

        # 인코딩 / Encode
        splits = self._split_modalities(masked_input)
        latent = self._encoder(*splits)

        # 복원 / Reconstruct
        reconstructed = self._masked_predictor(latent)

        # 마스킹된 위치에서만 손실 계산 / Loss only on masked positions
        diff = (reconstructed - sensor_tensor) ** 2
        masked_diff = diff * (1.0 - mask)
        n_masked = max(1, int((1.0 - mask).sum().item()))
        loss = masked_diff.sum() / n_masked

        self._optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(
            list(self._encoder.parameters()) +
            list(self._masked_predictor.parameters()),
            GRAD_CLIP_NORM,
        )
        self._optimizer.step()

        loss_val = float(loss.item())
        self._loss_history[SSLTask.MASKED_SENSOR].append(loss_val)
        self._training_step += 1
        return loss_val

    def _train_cross_modal(self, batch: List[SSLObservation]) -> float:
        """
        크로스모달 예측 학습 / Train cross-modal prediction.

        모달리티 간 예측을 학습합니다:
        - 시각 → 촉각 임베딩
        - 촉각 → 시각 임베딩
        - 시각+관성 → 힘 임베딩
        - 촉각+힘 → 시각 임베딩
        """
        sensor_batch = np.stack([obs.sensor_vector for obs in batch], axis=0)
        sensor_tensor = torch.tensor(sensor_batch, dtype=torch.float32, device=self._device)
        splits = self._split_modalities(sensor_tensor)

        # 전체 잠재 표현 / Full latent representation
        with torch.no_grad():
            latent = self._encoder(*splits)

        total_loss = torch.tensor(0.0, device=self._device)

        # 시각 → 촉각 / Visual → Tactile
        visual_emb = self._encoder.visual_enc(splits[0])
        pred_tactile = self._cross_modal_predictors["visual_to_tactile"](latent.detach())
        target_tactile = visual_emb.detach()  # 촉각 인코더 목표 (간소화)
        loss_vt = F.mse_loss(pred_tactile, splits[1] @ torch.randn(
            TACTILE_INPUT_DIM, 128, device=self._device
        ) * 0.01 + target_tactile.mean(dim=0, keepdim=True).expand_as(pred_tactile))
        total_loss = total_loss + loss_vt

        # 촉각 → 시각 / Tactile → Visual
        pred_visual = self._cross_modal_predictors["tactile_to_visual"](latent.detach())
        tactile_emb = self._encoder.tactile_enc(splits[1])
        target_visual = tactile_emb.detach()
        loss_tv = F.mse_loss(pred_visual, splits[0] @ torch.randn(
            VISUAL_INPUT_DIM, 128, device=self._device
        ) * 0.01 + target_visual.mean(dim=0, keepdim=True).expand_as(pred_visual))
        total_loss = total_loss + loss_tv

        self._optimizer.zero_grad()
        total_loss.backward()
        for pred in self._cross_modal_predictors.values():
            torch.nn.utils.clip_grad_norm_(pred.parameters(), GRAD_CLIP_NORM)
        self._optimizer.step()

        loss_val = float(total_loss.item())
        self._loss_history[SSLTask.CROSS_MODAL].append(loss_val)
        return loss_val

    def _train_rotation(self, batch: List[SSLObservation]) -> float:
        """
        회전 예측 학습 / Train rotation prediction.

        상태 + 행동 → 회전 클래스 (4분류)를 예측합니다.
        사전학습 신호로 사용: 물리적 변화의 이해를 학습.

        RotNet 방식: 시간적으로 인접한 관측 쌍에서
        상태 변화로부터 회전 방향을 유추합니다.
        """
        if len(batch) < 2:
            return 0.0

        sensor_batch = np.stack([obs.sensor_vector for obs in batch], axis=0)
        sensor_tensor = torch.tensor(sensor_batch, dtype=torch.float32, device=self._device)
        splits = self._split_modalities(sensor_tensor)

        # 인코딩 / Encode
        latent = self._encoder(*splits)

        # 의사 행동 임베딩 (실제로는 행동 데이터에서 생성) / Pseudo action embedding
        # 연속된 관측 간의 차이를 행동의 프록시로 사용 / Use diff between consecutive obs as action proxy
        if sensor_tensor.shape[0] >= 2:
            action_proxy = (sensor_tensor[1:] - sensor_tensor[:-1])
            # 32차원으로 축소 / Reduce to action_dim
            action_proxy_padded = torch.zeros(
                sensor_tensor.shape[0] - 1, 32, device=self._device
            )
            n_copy = min(32, action_proxy.shape[1])
            action_proxy_padded[:, :n_copy] = action_proxy[:, :n_copy]

            state_z = latent[:-1]
        else:
            action_proxy_padded = torch.zeros(1, 32, device=self._device)
            state_z = latent[:1]

        # 회전 클래스 예측 / Predict rotation class
        logits = self._rotation_predictor(state_z, action_proxy_padded)

        # 의사 라벨: 상태 변화의 크기와 방향으로 분류 / Pseudo labels from state change
        # 간소화된 라벨: 변화 벡터의 통계량으로 4클래스 할당
        with torch.no_grad():
            change_mag = torch.norm(action_proxy_padded, dim=-1)
            change_dir = torch.sign(action_proxy_padded[:, 0])

            # 0=no_rot, 1=cw, 2=ccw, 3=tumble
            labels = torch.zeros(state_z.shape[0], dtype=torch.long, device=self._device)
            labels[change_mag < 0.1] = 0          # no rotation
            labels[(change_mag >= 0.1) & (change_dir > 0)] = 1   # clockwise
            labels[(change_mag >= 0.1) & (change_dir <= 0)] = 2  # counter-clockwise
            labels[change_mag > 1.0] = 3           # tumble

        loss = F.cross_entropy(logits, labels)

        self._optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(
            list(self._encoder.parameters()) +
            list(self._rotation_predictor.parameters()),
            GRAD_CLIP_NORM,
        )
        self._optimizer.step()

        loss_val = float(loss.item())
        self._loss_history[SSLTask.ROTATION].append(loss_val)
        return loss_val

    def _train_step_numpy(self) -> Dict[str, Any]:
        """Numpy 폴백 배치 학습 / Numpy fallback batch training (limited)."""
        batch = self._replay_buffer.sample(ONLINE_BATCH_SIZE)
        if len(batch) < 2:
            return {"status": "insufficient_data"}

        # 인코딩만 수행 / Encoding only
        for obs in batch:
            _ = self._numpy_encoder.encode(obs.sensor_vector)

        self._training_step += 1
        return {
            "status": "numpy_fallback",
            "step": self._training_step,
            "note": "학습 없이 인코딩만 수행 (PyTorch 필요)",
        }

    # ─── 표현 추출 / Representation Extraction ────────────────────────────

    def get_representation(self, sensor_data: Dict[str, Any]) -> np.ndarray:
        """
        센서 데이터에서 학습된 표현 추출 / Extract learned representation from sensor data.

        하위 작업(지형 분류, 파지 예측, RL 등)에서 사용합니다.
        전이 학습 시 이 표현을 특징으로 사용합니다.

        Args:
            sensor_data: 센서 데이터 딕셔너리

        Returns:
            잠재 표현 [latent_dim] numpy 배열
        """
        obs = self._sensor_data_to_observation(sensor_data)

        if self._use_torch:
            latent = self._encode_observation(obs)
        else:
            latent = self._numpy_encoder.encode(obs.sensor_vector)

        with self._lock:
            self._representations_computed += 1

        return latent

    def _encode_observation(self, obs: SSLObservation) -> np.ndarray:
        """PyTorch 인코더로 관측 인코딩 / Encode observation with PyTorch encoder."""
        with torch.no_grad():
            latent = self._encode_observation_torch(obs)
            return latent.cpu().numpy()

    def _encode_observation_torch(self, obs: SSLObservation) -> torch.Tensor:
        """PyTorch 인코더로 관측 인코딩 (그래디언트 포함 가능) / Encode with gradient."""
        x = torch.tensor(obs.sensor_vector, dtype=torch.float32, device=self._device).unsqueeze(0)
        splits = self._split_modalities(x)
        latent = self._encoder(*splits)
        return latent.squeeze(0)

    def _split_modalities(self, sensor_tensor: torch.Tensor) -> Tuple[torch.Tensor, ...]:
        """
        결합 센서 텐서를 모달리티별로 분할 / Split concatenated sensor tensor by modality.

        Args:
            sensor_tensor: [batch, TOTAL_SENSOR_DIM]

        Returns:
            (visual, tactile, force, proprio, imu) 튜플
        """
        v = sensor_tensor[:, 0:VISUAL_INPUT_DIM]
        t = sensor_tensor[:, VISUAL_INPUT_DIM:VISUAL_INPUT_DIM + TACTILE_INPUT_DIM]
        f_start = VISUAL_INPUT_DIM + TACTILE_INPUT_DIM
        f = sensor_tensor[:, f_start:f_start + FORCE_INPUT_DIM]
        p_start = f_start + FORCE_INPUT_DIM
        p = sensor_tensor[:, p_start:p_start + PROPRIO_INPUT_DIM]
        i_start = p_start + PROPRIO_INPUT_DIM
        i = sensor_tensor[:, i_start:i_start + IMU_INPUT_DIM]
        return v, t, f, p, i

    # ─── 전이 학습 / Transfer Learning ──────────────────────────────────────

    def get_transfer_features(
        self, sensor_data: Dict[str, Any], freeze_encoder: bool = True
    ) -> Dict[str, Any]:
        """
        하위 작업으로 전이할 특징 추출 / Extract features for downstream task transfer.

        학습된 인코더의 표현을 하위 작업의 입력으로 사용합니다.
        freeze_encoder=True면 인코더를 동결하고 표현만 반환합니다.

        Args:
            sensor_data: 센서 데이터
            freeze_encoder: 인코더 동결 여부

        Returns:
            전이 특징 딕셔너리
        """
        representation = self.get_representation(sensor_data)

        # 모달리티별 서브 임베딩도 함께 제공 / Also provide per-modality sub-embeddings
        obs = self._sensor_data_to_observation(sensor_data)
        sub_embeddings: Dict[str, np.ndarray] = {}

        if self._use_torch and self._encoder is not None:
            with torch.no_grad():
                x = torch.tensor(
                    obs.sensor_vector, dtype=torch.float32, device=self._device
                ).unsqueeze(0)
                splits = self._split_modalities(x)

                sub_embeddings["visual"] = self._encoder.visual_enc(splits[0]).cpu().numpy().flatten()
                sub_embeddings["tactile"] = self._encoder.tactile_enc(splits[1]).cpu().numpy().flatten()
                sub_embeddings["force"] = self._encoder.force_enc(splits[2]).cpu().numpy().flatten()
                sub_embeddings["proprioceptive"] = self._encoder.proprio_enc(splits[3]).cpu().numpy().flatten()
                sub_embeddings["inertial"] = self._encoder.imu_enc(splits[4]).cpu().numpy().flatten()

        return {
            "representation": representation,
            "latent_dim": self._latent_dim,
            "sub_embeddings": sub_embeddings,
            "modality_mask": obs.modality_mask,
            "freeze_encoder": freeze_encoder,
        }

    # ─── 백그라운드 학습 / Background Training ─────────────────────────────

    def _background_training_loop(self) -> None:
        """
        백그라운드 학습 루프 / Background training loop.

        주기적으로 재생 버퍼에서 미니배치를 샘플링하여 학습합니다.
        메인 스레드를 블로킹하지 않습니다.
        """
        logger.info("SSL 백그라운드 학습 스레드 시작")
        train_interval = 10.0  # 10초마다 배치 학습 / Batch training every 10s
        last_train = time.time()

        while self._running:
            time.sleep(1.0)
            now = time.time()

            if now - last_train >= train_interval and len(self._replay_buffer) >= ONLINE_BATCH_SIZE:
                try:
                    metrics = self.train_step()
                    if metrics.get("total_loss", 0) > 0:
                        logger.debug(
                            "SSL 배치 학습: step=%d, total_loss=%.4f",
                            metrics.get("step", 0),
                            metrics.get("total_loss", 0),
                        )
                except Exception as e:
                    logger.error("SSL 백그라운드 학습 오류: %s", e)

                last_train = now

        logger.info("SSL 백그라운드 학습 스레드 종료")

    # ─── 모델 저장/로드 / Model Save/Load ──────────────────────────────────

    def save(self, path: Union[str, Path]) -> bool:
        """
        모델 저장 / Save model.

        Args:
            path: 저장 경로

        Returns:
            저장 성공 여부
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        try:
            if self._use_torch:
                state = {
                    "encoder": self._encoder.state_dict(),
                    "encoder_ema": self._encoder_ema.state_dict(),
                    "temporal_predictor": self._temporal_predictor.state_dict(),
                    "masked_predictor": self._masked_predictor.state_dict(),
                    "contrastive_head": self._contrastive_head.state_dict(),
                    "rotation_predictor": self._rotation_predictor.state_dict(),
                    "optimizer": self._optimizer.state_dict(),
                    "log_temperature": self._log_temperature,
                    "training_step": self._training_step,
                    "representations_computed": self._representations_computed,
                    "total_experiences": self._total_experiences,
                }
                for name, pred in self._cross_modal_predictors.items():
                    state[f"cross_modal_{name}"] = pred.state_dict()

                torch.save(state, path / "ssl_model.pt")
            else:
                np.savez_compressed(
                    path / "ssl_model.npz",
                    training_step=np.array([self._training_step]),
                    representations_computed=np.array([self._representations_computed]),
                )

            # 체크포인트 메타 저장 / Save checkpoint metadata
            self._repository.save_checkpoint_meta(
                checkpoint_id=uuid.uuid4().hex[:12],
                step=self._training_step,
                avg_loss=float(np.mean(list(self._loss_history.get(SSLTask.MASKED_SENSOR, [0.0])))),
                path=str(path),
            )

            logger.info("SSL 모델 저장: %s (step=%d)", path, self._training_step)
            return True
        except Exception as e:
            logger.error("SSL 모델 저장 실패: %s", e)
            return False

    def load(self, path: Union[str, Path]) -> bool:
        """
        모델 로드 / Load model.

        Args:
            path: 로드 경로

        Returns:
            로드 성공 여부
        """
        path = Path(path)

        try:
            if self._use_torch:
                checkpoint = torch.load(
                    path / "ssl_model.pt",
                    map_location=self._device,
                    weights_only=False,
                )
                self._encoder.load_state_dict(checkpoint["encoder"])
                self._encoder_ema.load_state_dict(checkpoint["encoder_ema"])
                self._temporal_predictor.load_state_dict(checkpoint["temporal_predictor"])
                self._masked_predictor.load_state_dict(checkpoint["masked_predictor"])
                self._contrastive_head.load_state_dict(checkpoint["contrastive_head"])
                self._rotation_predictor.load_state_dict(checkpoint["rotation_predictor"])
                self._optimizer.load_state_dict(checkpoint["optimizer"])
                self._log_temperature = checkpoint["log_temperature"]
                self._training_step = checkpoint.get("training_step", 0)
                self._representations_computed = checkpoint.get("representations_computed", 0)
                self._total_experiences = checkpoint.get("total_experiences", 0)

                for name, pred in self._cross_modal_predictors.items():
                    key = f"cross_modal_{name}"
                    if key in checkpoint:
                        pred.load_state_dict(checkpoint[key])
            else:
                data = np.load(str(path / "ssl_model.npz"))
                self._training_step = int(data.get("training_step", [0])[0])
                self._representations_computed = int(data.get("representations_computed", [0])[0])

            logger.info("SSL 모델 로드: %s (step=%d)", path, self._training_step)
            return True
        except Exception as e:
            logger.error("SSL 모델 로드 실패: %s", e)
            return False

    # ─── 통계 및 상태 / Statistics and Status ───────────────────────────────

    def get_stats(self) -> Dict[str, Any]:
        """
        자기지도학습 시스템 통계 / SSL system statistics.

        Returns:
            통계 딕셔너리
        """
        with self._lock:
            avg_losses = {}
            for task, history in self._loss_history.items():
                if history:
                    avg_losses[task] = round(float(np.mean(list(history))), 6)
                else:
                    avg_losses[task] = 0.0

        stats = {
            "use_torch": self._use_torch,
            "device": str(self._device) if self._device else "numpy",
            "training_step": self._training_step,
            "total_experiences": self._total_experiences,
            "representations_computed": self._representations_computed,
            "latent_dim": self._latent_dim,
            "temperature": self.temperature,
            "replay_buffer": self._replay_buffer.get_stats(),
            "memory_bank": self._memory_bank.get_stats(),
            "avg_losses": avg_losses,
            "repository": self._repository.get_stats(),
        }
        return stats

    def shutdown(self) -> None:
        """
        자기지도학습 시스템 종료 / Shutdown SSL system.

        백그라운드 스레드를 안전하게 종료합니다.
        """
        self._running = False
        if self._bg_thread is not None and self._bg_thread.is_alive():
            self._bg_thread.join(timeout=5.0)
        logger.info("OnlineSSLearner 종료 — step=%d, experiences=%d",
                     self._training_step, self._total_experiences)


# ─── 모듈 진입점 / Module Entry Point ────────────────────────────────────────

# ============================================================================
# BYOL + DINO v2 Self-Distillation — Physical AGI 자기지도학습 혁신
# ============================================================================
# 기존: SimCLR 대조 학습 (네거티브 페어 필요, 작은 데이터셋에 취약)
# 혁신 1: BYOL — 네거티브 없이 online+target 네트워크로 학습
# 혁신 2: DINO v2 — 자기 증류(self-distillation)로 강력한 물리적 특징 학습
# 혁신 3: 3D 등변 표현 — 물리적 회전에 올바르게 변환되는 특징 학습
# ============================================================================

if TORCH_AVAILABLE:

    class BYOLPhysicalEncoder(nn.Module):
        """BYOL (Bootstrap Your Own Latent) 물리적 센서 인코더

        네거티브 페어 없이 online 네트워크와 EMA target 네트워크로 학습.
        물리적 로봇의 제한된 데이터에서 더 효과적인 표현 학습.
        """

        def __init__(self, sensor_dim=224, hidden_dim=512, projection_dim=256,
                     ema_decay=0.996, sensor_groups=None):
            super().__init__()
            self.sensor_dim = sensor_dim
            self.hidden_dim = hidden_dim
            self.projection_dim = projection_dim
            self.ema_decay = ema_decay

            # Online network
            self.online_encoder = nn.Sequential(
                nn.Linear(sensor_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, projection_dim),
            )

            self.online_projector = nn.Sequential(
                nn.Linear(projection_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, projection_dim),
            )

            self.online_predictor = nn.Sequential(
                nn.Linear(projection_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, projection_dim),
            )

            # Target network (EMA of online)
            self.target_encoder = nn.Sequential(
                nn.Linear(sensor_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, projection_dim),
            )

            self.target_projector = nn.Sequential(
                nn.Linear(projection_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, projection_dim),
            )

            # Initialize target = online
            self._init_target_network()

            # Sensor group masks for physical augmentation
            self.sensor_groups = sensor_groups or {
                'imu': slice(0, 6),
                'joint': slice(6, 18),
                'force': slice(18, 30),
                'tactile': slice(30, 42),
                'other': slice(42, sensor_dim),
            }

        def _init_target_network(self):
            """타겟 네트워크를 온라인 네트워크로 초기화"""
            for online_params, target_params in zip(
                self.online_encoder.parameters(), self.target_encoder.parameters()
            ):
                target_params.data.copy_(online_params.data)

            for online_params, target_params in zip(
                self.online_projector.parameters(), self.target_projector.parameters()
            ):
                target_params.data.copy_(online_params.data)

            # 타겟은 기울기 계산 안함
            for param in self.target_encoder.parameters():
                param.requires_grad = False
            for param in self.target_projector.parameters():
                param.requires_grad = False

        @torch.no_grad()
        def update_target_network(self):
            """EMA 업데이트: 타겟 ← ema_decay * 타겟 + (1-ema_decay) * 온라인"""
            for online_params, target_params in zip(
                self.online_encoder.parameters(), self.target_encoder.parameters()
            ):
                target_params.data = (
                    self.ema_decay * target_params.data +
                    (1 - self.ema_decay) * online_params.data
                )

            for online_params, target_params in zip(
                self.online_projector.parameters(), self.target_projector.parameters()
            ):
                target_params.data = (
                    self.ema_decay * target_params.data +
                    (1 - self.ema_decay) * online_params.data
                )

        def physical_augment(self, sensor_data):
            """물리적 센서 데이터 증강

            그룹별 독립 증강:
            - IMU: 작은 회전 + 가우시안 노이즈
            - 관절: 작은 오프셋 + 스케일 변화
            - 힘: 노이즈 + 스케일 변화
            - 촉각: 마스킹 + 노이즈
            """
            augmented = sensor_data.clone()

            for group_name, group_slice in self.sensor_groups.items():
                end_idx = min(group_slice.stop or self.sensor_dim, augmented.shape[-1])
                start_idx = group_slice.start or 0

                if group_name == 'imu':
                    # 회전 노이즈 + 가우시안
                    augmented[..., start_idx:end_idx] += (
                        torch.randn_like(augmented[..., start_idx:end_idx]) * 0.02
                    )
                elif group_name == 'joint':
                    # 관절 오프셋 + 스케일
                    scale = 1.0 + torch.randn(1).item() * 0.05
                    offset = torch.randn(end_idx - start_idx).to(augmented.device) * 0.02
                    augmented[..., start_idx:end_idx] = (
                        augmented[..., start_idx:end_idx] * scale + offset
                    )
                elif group_name == 'force':
                    # 힘 스케일 변화
                    scale = 1.0 + torch.randn(1).item() * 0.1
                    augmented[..., start_idx:end_idx] *= scale
                elif group_name == 'tactile':
                    # 촉각 마스킹 + 노이즈
                    mask = torch.rand(end_idx - start_idx).to(augmented.device) > 0.1
                    augmented[..., start_idx:end_idx] *= mask.float()
                    augmented[..., start_idx:end_idx] += (
                        torch.randn_like(augmented[..., start_idx:end_idx]) * 0.01
                    )

            return augmented

        def forward(self, sensor_view1, sensor_view2=None):
            """BYOL 순전파

            Args:
                sensor_view1: 첫 번째 증강 뷰 [batch, sensor_dim]
                sensor_view2: 두 번째 증강 뷰 [batch, sensor_dim] (선택)

            Returns:
                dict: loss, online_projection, target_projection
            """
            if sensor_view2 is None:
                sensor_view2 = self.physical_augment(sensor_view1)

            # Online path
            online_enc1 = self.online_encoder(sensor_view1)
            online_proj1 = self.online_projector(online_enc1)
            online_pred1 = self.online_predictor(online_proj1)

            online_enc2 = self.online_encoder(sensor_view2)
            online_proj2 = self.online_projector(online_enc2)
            online_pred2 = self.online_predictor(online_proj2)

            # Target path (no gradient)
            with torch.no_grad():
                target_enc1 = self.target_encoder(sensor_view1)
                target_proj1 = self.target_projector(target_enc1)

                target_enc2 = self.target_encoder(sensor_view2)
                target_proj2 = self.target_projector(target_enc2)

            # Symmetric loss
            loss = (
                self._regression_loss(online_pred1, target_proj2) +
                self._regression_loss(online_pred2, target_proj1)
            ) / 2

            return {
                'loss': loss,
                'online_encoding': online_enc1.detach(),
                'target_encoding': target_enc1.detach(),
            }

        def _regression_loss(self, prediction, target):
            """정규화된 코사인 유사도 손실"""
            pred_norm = F.normalize(prediction, dim=-1)
            target_norm = F.normalize(target, dim=-1)
            return 2 - 2 * (pred_norm * target_norm).sum(dim=-1).mean()

        def encode(self, sensor_data):
            """인코딩만 수행 (추론용)"""
            with torch.no_grad():
                return self.online_encoder(sensor_data)


    class DINOPhysicalDistillation(nn.Module):
        """DINO v2 스타일 자기 증류 — 물리적 센서 특징 학습

        Student 네트워크가 Teacher(EMA)의 출력 분포를 모방.
        물리적 변환에 등변인 특징을 학습.
        """

        def __init__(self, sensor_dim=224, hidden_dim=512, projection_dim=256,
                     num_prototypes=1024, ema_decay=0.996,
                     teacher_temp=0.07, student_temp=0.1,
                     center_momentum=0.9):
            super().__init__()
            self.sensor_dim = sensor_dim
            self.projection_dim = projection_dim
            self.num_prototypes = num_prototypes
            self.ema_decay = ema_decay
            self.teacher_temp = teacher_temp
            self.student_temp = student_temp
            self.center_momentum = center_momentum

            # Student encoder
            self.student_encoder = nn.Sequential(
                nn.Linear(sensor_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, projection_dim),
            )

            # Teacher encoder (EMA of student)
            self.teacher_encoder = nn.Sequential(
                nn.Linear(sensor_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, projection_dim),
            )

            # Prototype layer (clustering in feature space)
            self.student_prototypes = nn.Linear(projection_dim, num_prototypes, bias=False)
            self.teacher_prototypes = nn.Linear(projection_dim, num_prototypes, bias=False)

            # Center for teacher output (prevents collapse)
            self.register_buffer('center', torch.zeros(1, num_prototypes))

            # Initialize teacher = student
            for s_params, t_params in zip(
                self.student_encoder.parameters(), self.teacher_encoder.parameters()
            ):
                t_params.data.copy_(s_params.data)

            for s_params, t_params in zip(
                self.student_prototypes.parameters(), self.teacher_prototypes.parameters()
            ):
                t_params.data.copy_(s_params.data)

            # Teacher requires no gradients
            for param in self.teacher_encoder.parameters():
                param.requires_grad = False
            for param in self.teacher_prototypes.parameters():
                param.requires_grad = False

        @torch.no_grad()
        def update_teacher(self):
            """EMA 업데이트 + 센터 업데이트"""
            for s_params, t_params in zip(
                self.student_encoder.parameters(), self.teacher_encoder.parameters()
            ):
                t_params.data = self.ema_decay * t_params.data + (1 - self.ema_decay) * s_params.data

            for s_params, t_params in zip(
                self.student_prototypes.parameters(), self.teacher_prototypes.parameters()
            ):
                t_params.data = self.ema_decay * t_params.data + (1 - self.ema_decay) * s_params.data

        @torch.no_grad()
        def update_center(self, teacher_output):
            """센터 업데이트 (collapse 방지)"""
            batch_center = teacher_output.mean(dim=0, keepdim=True)
            self.center = self.center_momentum * self.center + (1 - self.center_momentum) * batch_center

        def forward(self, global_view, local_views):
            """DINO 순전파

            Args:
                global_view: 고해상도 전역 뷰 [batch, sensor_dim]
                local_views: 저해상도 지역 뷰 리스트 [batch, sensor_dim]

            Returns:
                dict: loss, student_features, teacher_features
            """
            # Student forward
            student_global = self.student_encoder(global_view)
            student_global_logits = self.student_prototypes(student_global) / self.student_temp

            student_locals = []
            for local in local_views:
                s_feat = self.student_encoder(local)
                s_logits = self.student_prototypes(s_feat) / self.student_temp
                student_locals.append(s_logits)

            # Teacher forward (no gradient)
            with torch.no_grad():
                teacher_global = self.teacher_encoder(global_view)
                teacher_logits = self.teacher_prototypes(teacher_global)
                teacher_logits = (teacher_logits - self.center) / self.teacher_temp
                teacher_probs = F.softmax(teacher_logits, dim=-1)

                self.update_center(teacher_logits)

            # Cross-entropy loss: student predicts teacher's distribution
            total_loss = 0
            n_losses = 0

            # Global student → global teacher
            for s_logits in [student_global_logits] + student_locals:
                loss = -torch.sum(teacher_probs * F.log_softmax(s_logits, dim=-1), dim=-1).mean()
                total_loss += loss
                n_losses += 1

            return {
                'loss': total_loss / max(n_losses, 1),
                'student_features': student_global.detach(),
                'teacher_features': teacher_global.detach(),
            }

        def encode(self, sensor_data):
            """인코딩만 수행 (추론용)"""
            with torch.no_grad():
                return self.teacher_encoder(sensor_data)


    class EquivariantPhysicalEncoder(nn.Module):
        """3D 등변 물리적 표현 학습

        혁신: 물리적 회전/이동에 올바르게 변환되는 특징 학습.
        "물체를 90도 돌려도 같은 물체로 인식하되, 방향 정보는 보존"
        """

        def __init__(self, sensor_dim=224, hidden_dim=256, latent_dim=64,
                     num_rotation_heads=4):
            super().__init__()
            self.latent_dim = latent_dim

            # Invariant encoder (물체 식별)
            self.invariant_encoder = nn.Sequential(
                nn.Linear(sensor_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, latent_dim),
            )

            # Equivariant encoder (자세/방향)
            self.equivariant_encoder = nn.Sequential(
                nn.Linear(sensor_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, 6),  # 3D rotation (6D continuous representation)
            )

            # Rotation prediction heads
            self.rotation_heads = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(latent_dim + 6, hidden_dim // 2),
                    nn.GELU(),
                    nn.Linear(hidden_dim // 2, 6),
                ) for _ in range(num_rotation_heads)
            ])

        def forward(self, sensor_data, rotation_matrix=None):
            """등변 표현 학습

            Args:
                sensor_data: 센서 입력 [batch, sensor_dim]
                rotation_matrix: 회전 행렬 (선택) [batch, 3, 3]
            """
            # Invariant features (회전 불변)
            invariant = self.invariant_encoder(sensor_data)
            invariant = F.normalize(invariant, dim=-1)

            # Equivariant features (회전 등변)
            equivariant = self.equivariant_encoder(sensor_data)

            # If rotation matrix provided, verify equivariance
            loss = torch.tensor(0.0, device=sensor_data.device)
            if rotation_matrix is not None:
                for head in self.rotation_heads:
                    predicted_rotation = head(torch.cat([invariant, equivariant], dim=-1))
                    # 6D rotation → matrix conversion for comparison
                    loss = loss + F.mse_loss(predicted_rotation, equivariant.detach())

            return {
                'invariant_features': invariant,
                'equivariant_features': equivariant,
                'equivariance_loss': loss,
            }


# ─── 모듈 진입점 / Module Entry Point ────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("=" * 60)
    print("온라인 자기지도학습 테스트 / Online Self-Supervised Learning Test")
    print("=" * 60)
    print(f"PyTorch 사용 가능: {TORCH_AVAILABLE}")

    # 학습기 생성 / Create learner
    learner = OnlineSSLearner(latent_dim=SHARED_LATENT_DIM)
    learner.initialize()

    # 가상 센서 데이터 생성 / Generate dummy sensor data
    rng = np.random.RandomState(42)

    print("\n--- 온라인 학습 테스트 / Online Learning Test ---")
    for i in range(20):
        sensor_data = {
            "visual": rng.randn(VISUAL_INPUT_DIM).astype(np.float32) * 0.5,
            "tactile": rng.randn(TACTILE_INPUT_DIM).astype(np.float32) * 0.1,
            "force": rng.randn(FORCE_INPUT_DIM).astype(np.float32) * 2.0,
            "proprioceptive": rng.randn(PROPRIO_INPUT_DIM).astype(np.float32) * 0.3,
            "inertial": rng.randn(IMU_INPUT_DIM).astype(np.float32) * 0.2,
        }
        metrics = learner.on_experience(sensor_data)
        if i % 5 == 0:
            print(f"  경험 {i}: temporal_loss={metrics.get('temporal_loss', 0):.4f}, "
                  f"contrastive_loss={metrics.get('contrastive_loss', 0):.4f}")

    # 표현 추출 테스트 / Representation extraction test
    print("\n--- 표현 추출 테스트 / Representation Extraction Test ---")
    test_data = {
        "visual": rng.randn(VISUAL_INPUT_DIM).astype(np.float32),
        "tactile": rng.randn(TACTILE_INPUT_DIM).astype(np.float32),
        "force": rng.randn(FORCE_INPUT_DIM).astype(np.float32),
        "proprioceptive": rng.randn(PROPRIO_INPUT_DIM).astype(np.float32),
        "inertial": rng.randn(IMU_INPUT_DIM).astype(np.float32),
    }
    representation = learner.get_representation(test_data)
    print(f"  표현 벡터: shape={representation.shape}, norm={np.linalg.norm(representation):.3f}")

    # 전이 특징 테스트 / Transfer features test
    transfer = learner.get_transfer_features(test_data)
    print(f"  전이 특징: latent_dim={transfer['latent_dim']}, "
          f"sub_embeddings={list(transfer['sub_embeddings'].keys())}")

    # 배치 학습 테스트 / Batch training test
    if TORCH_AVAILABLE:
        print("\n--- 배치 학습 테스트 / Batch Training Test ---")
        for step in range(3):
            metrics = learner.train_step()
            print(f"  스텝 {step}: {metrics}")

    # 통계 / Statistics
    stats = learner.get_stats()
    print(f"\n--- 통계 / Statistics ---")
    print(f"  학습 스텝: {stats['training_step']}")
    print(f"  총 경험: {stats['total_experiences']}")
    print(f"  표현 계산: {stats['representations_computed']}")
    print(f"  재생 버퍼: {stats['replay_buffer']}")
    print(f"  메모리 뱅크: {stats['memory_bank']}")
    print(f"  평균 손실: {stats['avg_losses']}")

    learner.shutdown()
    print("\n모든 테스트 완료 / All tests completed.")
