#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 경험 수집기 / Experience Collector
===================================================

V8.5 → V8.5 업그레이드:
  - 인과 맥락 기록 (무엇이 무엇을 일으켰는가)
  - 감성 맥락 기록 (그때 감정 상태는 어땠는가)
  - 세계지식 링크 기록 (어떤 세계 사실을 사용했는가)
  - Affordance 기록 (어떤 행동 가능성을 발견했는가)
  - 참신함 점수 (각 경험의 참신함 평가)
  - 향상된 시퀀스 감지: 서브초 단위 그룹화 (5초 → 서브초)
  - 경험 품질 점수 (성공/실패 이상의 품질 평가)
  - 개념 드리프트 주석 (드리프트를 나타내는 경험 표시)
  - 버퍼: 10000 → 50000 경험

모든 도구 호출, 동작 시퀀스, 대화, 오류 복구 기록
버퍼: 50,000개 경험 (50개마다 DB 플러시)
시퀀스 감지: 서브초 이내 연속 도구 호출 → 자동 시퀀스로 그룹화

검증: 1시간 동작 후 경험 500개 이상 수집

버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import copy
import json
import logging
import math
import os
import sqlite3
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("jihun.v84.experience_collector")
logger.setLevel(logging.INFO)


# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

DEFAULT_DB_PATH = Path(
    os.getenv("EXPERIENCE_DB_PATH", "/home/jihun/data/experience/experiences.db")
)
BUFFER_SIZE = 50000              # V8: 10000 → 50000 경험 버퍼 최대 크기
FLUSH_INTERVAL = 50              # 50개마다 DB 플러시
SEQUENCE_TIMEOUT_S = 1.0         # V8: 5.0 → 1.0 서브초 시퀀스 타임아웃
MIN_SEQUENCE_LENGTH = 2          # 시퀀스 최소 길이
TARGET_HOURLY_RATE = 500         # 1시간 목표 수집 수
NOVELTY_THRESHOLD_HIGH = 0.8     # 높은 참신함 임계값
NOVELTY_THRESHOLD_LOW = 0.3      # 낮은 참신함 임계값


class ExperienceType(Enum):
    """경험 유형"""
    TOOL_CALL = "tool_call"               # 단일 도구 호출
    ACTION_SEQUENCE = "action_sequence"    # 동작 시퀀스
    CONVERSATION = "conversation"          # 대화
    ERROR_RECOVERY = "error_recovery"      # 오류 복구
    OBSERVATION = "observation"            # 관찰
    NOVEL_SITUATION = "novel_situation"    # 새로운 상황
    # V8.5 신규 유형
    CAUSAL_DISCOVERY = "causal_discovery"        # 인과 발견
    AFFORDANCE_DISCOVERY = "affordance_discovery" # Affordance 발견
    CURIOSITY_EXPLORATION = "curiosity_exploration"  # 호기심 탐색
    DREAM_SIMULATION = "dream_simulation"          # 꿈 시뮬레이션 결과


# ──────────────────────────────────────────────────────────────────────────────
# 데이터 클래스 / Data Classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class Experience:
    """경험 기록 — V8: 인과/감성/세계지식/Affordance/참신함 추가"""
    experience_id: str = ""
    experience_type: ExperienceType = ExperienceType.TOOL_CALL
    timestamp: float = field(default_factory=time.time)
    description: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    action_sequence: List[Dict[str, Any]] = field(default_factory=list)
    outcome: str = ""                   # "success", "partial", "failure"
    success_score: float = 0.0          # 0~1
    duration_s: float = 0.0
    owner_present: bool = False
    environment_snapshot: Optional[Dict] = None
    learned: bool = False               # 수면 학습에 반영 여부
    tags: List[str] = field(default_factory=list)
    # V8.5 신규 필드
    causal_context: Optional[Dict[str, Any]] = None      # 인과 맥락
    emotional_context: Optional[Dict[str, Any]] = None    # 감성 맥락
    world_knowledge_links: List[str] = field(default_factory=list)  # 세계지식 링크
    affordance_info: Optional[Dict[str, Any]] = None      # Affordance 정보
    novelty_score: float = 0.0                            # 참신함 점수 (0~1)
    quality_score: float = 0.0                            # 품질 점수 (0~1)
    concept_drift_annotation: Optional[str] = None        # 개념 드리프트 주석

    def __post_init__(self):
        if not self.experience_id:
            self.experience_id = f"exp_{int(self.timestamp * 1000)}"


@dataclass
class CausalContext:
    """V8: 인과 맥락 — 무엇이 무엇을 일으켰는가"""
    cause: str = ""                     # 원인
    effect: str = ""                    # 결과
    cause_type: str = ""                # 원인 유형 ("action", "observation", "external")
    confidence: float = 0.0             # 인과 확신도 (0~1)
    temporal_distance_s: float = 0.0    # 원인-결과 시간 차이 (초)
    related_experiences: List[str] = field(default_factory=list)


@dataclass
class EmotionalContext:
    """V8: 감성 맥락 — 그때 감정 상태는 어땠는가"""
    dominant_emotion: str = "neutral"   # 주 감정
    valence: float = 0.0               # 감정가 (-1 ~ +1)
    arousal: float = 0.5               # 각성도 (0 ~ 1)
    confidence: float = 0.5            # 자신감 (0 ~ 1)
    frustration_level: float = 0.0     # 좌절 수준 (0 ~ 1)
    curiosity_level: float = 0.5       # 호기심 수준 (0 ~ 1)


@dataclass
class AffordanceInfo:
    """V8: Affordance 정보 — 어떤 행동 가능성을 발견했는가"""
    object_name: str = ""              # 대상 객체
    affordance_type: str = ""          # 행동 가능성 (예: "graspable", "pushable")
    confidence: float = 0.0            # 확신도
    discovered_through: str = ""       # 발견 방법 ("visual", "tactile", "inference")
    previous_knowledge: bool = False   # 이전에 알고 있었는지 여부


# ──────────────────────────────────────────────────────────────────────────────
# 경험 수집기 / Experience Collector
# ──────────────────────────────────────────────────────────────────────────────

class ExperienceCollector:
    """
    경험 수집기 V8

    V8.5 기능 + V8.5 업그레이드:
    - 로봇의 모든 상호작용 데이터와 성공/실패 메트릭을 수집
    - 50,000개 경험 버퍼 (50개마다 DB 플러시)
    - 서브초 이내 연속 도구 호출 → 자동 시퀀스 그룹화
    - 빈발 패턴 분석 (스킬 학습용)

    V8.5 추가 수집:
    - 인과 맥락 (무엇이 무엇을 일으켰는가)
    - 감성 맥락 (그때 감정 상태)
    - 세계지식 링크 (어떤 세계 사실을 사용했는가)
    - Affordance 정보 (어떤 행동 가능성을 발견했는가)
    - 참신함 점수 (각 경험의 참신함 평가)
    - 품질 점수 (성공/실패 이상의 품질 평가)
    - 개념 드리프트 주석 (드리프트를 나타내는 경험 표시)

    검증: 1시간 동작 후 경험 500개 이상 수집
    """

    def __init__(self, db_path: Path = DEFAULT_DB_PATH) -> None:
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.RLock()

        # 경험 버퍼 — V8: 50,000개
        self._buffer: deque[Experience] = deque(maxlen=BUFFER_SIZE)
        self._buffer_count_since_flush = 0

        # 자동 시퀀스 감지 — V8: 서브초 그룹화
        self._current_sequence: List[Dict[str, Any]] = []
        self._sequence_start_time: float = 0.0
        self._sequence_context: Dict[str, Any] = {}

        # V8: 이전 경험 (인과 추적용)
        self._previous_experience: Optional[Experience] = None

        # V8: 외부 시스템 참조 (지연 연결)
        self._emotional_intelligence: Optional[Any] = None
        self._knowledge_graph: Optional[Any] = None
        self._affordance_learner: Optional[Any] = None

        # 통계
        self._total_collected: int = 0
        self._start_time: float = time.time()

        # V8: 참신함 추적
        self._seen_descriptions: Dict[str, int] = {}  # 해시 → 빈도

        logger.info(f"경험 수집기 V8.5 초기화: DB={db_path}, 버퍼={BUFFER_SIZE}")

    async def initialize(self) -> None:
        """경험 수집기 초기화"""
        self._conn = sqlite3.connect(
            str(self._db_path), check_same_thread=False,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._create_tables()
        logger.info("경험 수집기 V8.5 초기화 완료")

    def _create_tables(self) -> None:
        """테이블 생성 — V8: 추가 컬럼"""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS experiences (
                experience_id TEXT PRIMARY KEY,
                experience_type TEXT NOT NULL,
                timestamp REAL NOT NULL,
                description TEXT,
                context TEXT DEFAULT '{}',
                action_sequence TEXT DEFAULT '[]',
                outcome TEXT DEFAULT '',
                success_score REAL DEFAULT 0.0,
                duration_s REAL DEFAULT 0.0,
                owner_present INTEGER DEFAULT 0,
                learned INTEGER DEFAULT 0,
                tags TEXT DEFAULT '[]',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                causal_context TEXT DEFAULT NULL,
                emotional_context TEXT DEFAULT NULL,
                world_knowledge_links TEXT DEFAULT '[]',
                affordance_info TEXT DEFAULT NULL,
                novelty_score REAL DEFAULT 0.0,
                quality_score REAL DEFAULT 0.0,
                concept_drift_annotation TEXT DEFAULT NULL
            )
        """)
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_exp_timestamp "
            "ON experiences(timestamp)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_exp_type "
            "ON experiences(experience_type)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_exp_outcome "
            "ON experiences(outcome)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_exp_learned "
            "ON experiences(learned)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_exp_novelty "
            "ON experiences(novelty_score)"
        )
        self._conn.commit()

    # ──────────────────────────────────────────────────────────────────────
    # V8: 외부 시스템 연결
    # ──────────────────────────────────────────────────────────────────────

    def connect_emotional_intelligence(self, emotional_intelligence: Any) -> None:
        """V8: 감성 지능 연결"""
        self._emotional_intelligence = emotional_intelligence
        logger.info("감성 지능 연결 완료")

    def connect_knowledge_graph(self, knowledge_graph: Any) -> None:
        """V8: 지식 그래프 연결"""
        self._knowledge_graph = knowledge_graph
        logger.info("지식 그래프 연결 완료")

    def connect_affordance_learner(self, affordance_learner: Any) -> None:
        """V8: Affordance 학습기 연결"""
        self._affordance_learner = affordance_learner
        logger.info("Affordance 학습기 연결 완료")

    # ──────────────────────────────────────────────────────────────────────
    # V8: 참신함 점수 계산 / Novelty Scoring
    # ──────────────────────────────────────────────────────────────────────

    def _compute_novelty_score(self, description: str) -> float:
        """
        V8: 참신함 점수 계산

        완전히 새로운 경험: 1.0
        이전에 본 적 있는 경험: 점진적 감소
        """
        if not description:
            return 0.5

        # 간단한 해시 기반 참신함
        desc_hash = description[:100]  # 앞 100자로 축약
        count = self._seen_descriptions.get(desc_hash, 0)
        self._seen_descriptions[desc_hash] = count + 1

        # 빈도 기반 참신함 감소
        if count == 0:
            return 1.0  # 완전히 새로움
        elif count < 3:
            return 0.8
        elif count < 10:
            return 0.5
        elif count < 50:
            return 0.3
        else:
            return 0.1  # 매우 익숙함

    # ──────────────────────────────────────────────────────────────────────
    # V8: 품질 점수 계산 / Quality Scoring
    # ──────────────────────────────────────────────────────────────────────

    def _compute_quality_score(
        self,
        success_score: float,
        duration_s: float,
        novelty_score: float,
        experience_type: ExperienceType,
    ) -> float:
        """
        V8: 경험 품질 점수 계산

        단순 성공/실패를 넘어선 종합 품질 평가:
        - 성공 점수 (40%)
        - 효율성 (20%) — 시간 대비 결과
        - 참신함 (20%) — 새로운 것을 배웠는가
        - 완결성 (20%) — 행동이 완결되었는가
        """
        # 성공 점수
        success_component = success_score * 0.4

        # 효율성 (빠를수록 좋음, 하지만 최소 시간 필요)
        if duration_s > 0:
            efficiency = min(1.0, 5.0 / max(duration_s, 0.1))
        else:
            efficiency = 0.5
        efficiency_component = efficiency * 0.2

        # 참신함
        novelty_component = novelty_score * 0.2

        # 완결성 (시퀀스/대화는 완결성 높음)
        completeness = 0.5
        if experience_type in (
            ExperienceType.ACTION_SEQUENCE,
            ExperienceType.CONVERSATION,
        ):
            completeness = 0.8
        elif experience_type == ExperienceType.ERROR_RECOVERY:
            completeness = 0.7
        completeness_component = completeness * 0.2

        return min(1.0, (
            success_component +
            efficiency_component +
            novelty_component +
            completeness_component
        ))

    # ──────────────────────────────────────────────────────────────────────
    # V8: 인과 맥락 추출 / Causal Context Extraction
    # ──────────────────────────────────────────────────────────────────────

    def _extract_causal_context(self, experience: Experience) -> Optional[Dict[str, Any]]:
        """
        V8: 인과 맥락 추출 — 이전 경험과의 인과 관계 파악

        이전 경험의 결과가 현재 경험의 원인이 될 수 있는지 분석
        """
        if not self._previous_experience:
            return None

        prev = self._previous_experience
        time_diff = experience.timestamp - prev.timestamp

        # 시간적 근접성으로 인과 추론 (5초 이내)
        if time_diff > 5.0:
            return None

        causal_context = {
            "cause_experience_id": prev.experience_id,
            "cause_action": str(prev.action_sequence[:2]) if prev.action_sequence else prev.description[:50],
            "cause_outcome": prev.outcome,
            "effect_description": experience.description[:50],
            "temporal_distance_s": time_diff,
            "confidence": max(0.3, 1.0 - time_diff / 5.0),  # 가까울수록 높은 확신
        }

        return causal_context

    # ──────────────────────────────────────────────────────────────────────
    # V8: 감성 맥락 추출 / Emotional Context Extraction
    # ──────────────────────────────────────────────────────────────────────

    def _extract_emotional_context(self) -> Optional[Dict[str, Any]]:
        """V8: 감성 맥락 추출 — 현재 감정 상태"""
        if not self._emotional_intelligence:
            return None

        try:
            state = self._emotional_intelligence.get_current_state()
            return {
                "dominant_emotion": state.get("dominant_tone", "neutral"),
                "valence": state.get("valence", 0.0),
                "arousal": state.get("arousal", 0.5),
                "confidence": state.get("confidence", 0.5),
                "frustration_level": state.get("frustration", 0.0),
                "curiosity_level": state.get("curiosity", 0.5),
            }
        except Exception:
            return None

    # ──────────────────────────────────────────────────────────────────────
    # V8: 세계지식 링크 추출 / World Knowledge Link Extraction
    # ──────────────────────────────────────────────────────────────────────

    def _extract_world_knowledge_links(
        self, description: str,
    ) -> List[str]:
        """V8: 세계지식 링크 추출 — 이 경험에서 사용된 세계 사실"""
        if not self._knowledge_graph:
            return []

        try:
            results = self._knowledge_graph.query(description, top_k=3)
            return [
                r.get("fact_id", "") for r in results
                if r.get("confidence", 0) > 0.5
            ]
        except Exception:
            return []

    # ──────────────────────────────────────────────────────────────────────
    # V8: 개념 드리프트 감지 / Concept Drift Detection
    # ──────────────────────────────────────────────────────────────────────

    def _detect_concept_drift(self, experience: Experience) -> Optional[str]:
        """
        V8: 개념 드리프트 감지

        이전과 다른 결과 패턴이 나타나면 드리프트로 주석
        """
        if not self._previous_experience:
            return None

        prev = self._previous_experience

        # 동일한 행동이 다른 결과를 낳은 경우
        if (prev.action_sequence and experience.action_sequence and
                str(prev.action_sequence[:2]) == str(experience.action_sequence[:2]) and
                prev.outcome != experience.outcome):
            return f"outcome_drift: {prev.outcome} → {experience.outcome}"

        # 성공 점수 급격한 변화
        if abs(prev.success_score - experience.success_score) > 0.5:
            direction = "improving" if experience.success_score > prev.success_score else "degrading"
            return f"performance_drift: {direction}"

        return None

    # ──────────────────────────────────────────────────────────────────────
    # record() — 경험 기록 (공통)
    # ──────────────────────────────────────────────────────────────────────

    def record(self, experience: Experience) -> str:
        """
        경험 기록 — V8: 인과/감성/참신함/품질 자동 계산

        Args:
            experience: 기록할 경험 객체

        Returns:
            경험 ID
        """
        with self._lock:
            # V8: 참신함 점수 자동 계산
            if experience.novelty_score == 0.0:
                experience.novelty_score = self._compute_novelty_score(
                    experience.description
                )

            # V8: 품질 점수 자동 계산
            if experience.quality_score == 0.0:
                experience.quality_score = self._compute_quality_score(
                    experience.success_score,
                    experience.duration_s,
                    experience.novelty_score,
                    experience.experience_type,
                )

            # V8: 인과 맥락 자동 추출
            if experience.causal_context is None:
                experience.causal_context = self._extract_causal_context(experience)

            # V8: 감성 맥락 자동 추출
            if experience.emotional_context is None:
                experience.emotional_context = self._extract_emotional_context()

            # V8: 세계지식 링크 자동 추출
            if not experience.world_knowledge_links:
                experience.world_knowledge_links = self._extract_world_knowledge_links(
                    experience.description
                )

            # V8: 개념 드리프트 감지
            if experience.concept_drift_annotation is None:
                experience.concept_drift_annotation = self._detect_concept_drift(
                    experience
                )

            self._buffer.append(experience)
            self._buffer_count_since_flush += 1
            self._total_collected += 1

            # 이전 경험 업데이트 (인과 추적용)
            self._previous_experience = experience

            # 50개마다 DB 플러시
            if self._buffer_count_since_flush >= FLUSH_INTERVAL:
                self.flush()
                self._buffer_count_since_flush = 0

            return experience.experience_id

    # ──────────────────────────────────────────────────────────────────────
    # 개별 기록 메서드 / Individual Record Methods
    # ──────────────────────────────────────────────────────────────────────

    def record_tool_call(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        result: Any,
        success: bool,
        execution_time_ms: float = 0.0,
        context: Optional[Dict] = None,
    ) -> Experience:
        """단일 도구 호출 기록"""
        exp = Experience(
            experience_type=ExperienceType.TOOL_CALL,
            description=f"도구 호출: {tool_name}",
            context=context or {},
            action_sequence=[{
                "tool": tool_name,
                "args": arguments,
                "result": str(result)[:200],
            }],
            outcome="success" if success else "failure",
            success_score=1.0 if success else 0.0,
            duration_s=execution_time_ms / 1000,
        )

        self.record(exp)

        # 자동 시퀀스 감지에 추가
        self._add_to_current_sequence(tool_name, arguments, success)

        return exp

    def record_action_sequence(
        self,
        description: str,
        actions: List[Dict[str, Any]],
        outcome: str,
        success_score: float,
        duration_s: float = 0.0,
        context: Optional[Dict] = None,
    ) -> Experience:
        """동작 시퀀스 기록"""
        exp = Experience(
            experience_type=ExperienceType.ACTION_SEQUENCE,
            description=description,
            context=context or {},
            action_sequence=actions,
            outcome=outcome,
            success_score=success_score,
            duration_s=duration_s,
        )
        self.record(exp)
        return exp

    def record_conversation(
        self,
        user_input: str,
        robot_response: str,
        success: bool,
        context: Optional[Dict] = None,
    ) -> Experience:
        """대화 기록"""
        exp = Experience(
            experience_type=ExperienceType.CONVERSATION,
            description=f"대화: {user_input[:50]}",
            context=context or {},
            action_sequence=[
                {"role": "user", "content": user_input},
                {"role": "assistant", "content": robot_response},
            ],
            outcome="success" if success else "failure",
            success_score=1.0 if success else 0.0,
        )
        self.record(exp)
        return exp

    def record_error_recovery(
        self,
        error_description: str,
        recovery_actions: List[Dict[str, Any]],
        success: bool,
        context: Optional[Dict] = None,
    ) -> Experience:
        """오류 복구 기록"""
        exp = Experience(
            experience_type=ExperienceType.ERROR_RECOVERY,
            description=f"오류 복구: {error_description}",
            context=context or {},
            action_sequence=recovery_actions,
            outcome="success" if success else "failure",
            success_score=0.8 if success else 0.2,
        )
        self.record(exp)
        return exp

    def record_observation(
        self,
        description: str,
        observation_data: Dict[str, Any],
        importance: float = 0.3,
    ) -> Experience:
        """관찰 기록"""
        exp = Experience(
            experience_type=ExperienceType.OBSERVATION,
            description=description,
            context=observation_data,
            success_score=importance,
            outcome="neutral",
        )
        self.record(exp)
        return exp

    # ──────────────────────────────────────────────────────────────────────
    # V8: 신규 기록 메서드 / New V8.5 Record Methods
    # ──────────────────────────────────────────────────────────────────────

    def record_causal_discovery(
        self,
        cause: str,
        effect: str,
        confidence: float,
        context: Optional[Dict] = None,
    ) -> Experience:
        """V8: 인과 발견 기록"""
        exp = Experience(
            experience_type=ExperienceType.CAUSAL_DISCOVERY,
            description=f"인과 발견: {cause} → {effect}",
            context=context or {},
            outcome="discovery",
            success_score=confidence,
            causal_context={
                "cause": cause,
                "effect": effect,
                "confidence": confidence,
            },
            tags=["causal", "discovery"],
        )
        self.record(exp)
        return exp

    def record_affordance_discovery(
        self,
        object_name: str,
        affordance_type: str,
        confidence: float,
        discovered_through: str = "inference",
        context: Optional[Dict] = None,
    ) -> Experience:
        """V8: Affordance 발견 기록"""
        exp = Experience(
            experience_type=ExperienceType.AFFORDANCE_DISCOVERY,
            description=f"Affordance 발견: {object_name}은(는) {affordance_type}",
            context=context or {},
            outcome="discovery",
            success_score=confidence,
            affordance_info={
                "object_name": object_name,
                "affordance_type": affordance_type,
                "confidence": confidence,
                "discovered_through": discovered_through,
                "previous_knowledge": False,
            },
            tags=["affordance", "discovery", object_name],
        )
        self.record(exp)
        return exp

    def record_curiosity_exploration(
        self,
        target: str,
        information_gain: float,
        result_description: str,
        context: Optional[Dict] = None,
    ) -> Experience:
        """V8: 호기심 탐색 기록"""
        exp = Experience(
            experience_type=ExperienceType.CURIOSITY_EXPLORATION,
            description=f"호기심 탐색: {target}",
            context=context or {},
            outcome="explored",
            success_score=information_gain,
            novelty_score=min(1.0, information_gain + 0.3),  # 탐색은 본질적으로 참신함
            tags=["curiosity", "exploration"],
        )
        self.record(exp)
        return exp

    def record_dream_simulation(
        self,
        scenario: str,
        predicted_outcome: str,
        confidence: float,
        lessons: str = "",
        context: Optional[Dict] = None,
    ) -> Experience:
        """V8: 꿈 시뮬레이션 결과 기록"""
        exp = Experience(
            experience_type=ExperienceType.DREAM_SIMULATION,
            description=f"꿈 시뮬레이션: {scenario[:50]}",
            context=context or {},
            outcome=predicted_outcome,
            success_score=confidence,
            novelty_score=0.7,  # 시뮬레이션은 참신한 가상 경험
            tags=["dream", "simulation", "virtual"],
        )
        self.record(exp)
        return exp

    # ──────────────────────────────────────────────────────────────────────
    # 시퀀스 자동 감지 / Automatic Sequence Detection
    # ──────────────────────────────────────────────────────────────────────

    def _add_to_current_sequence(
        self,
        tool_name: str,
        arguments: Dict,
        success: bool,
    ) -> None:
        """현재 시퀀스에 도구 호출 추가 — V8: 서브초 단위 그룹화"""
        now = time.time()

        # 시퀀스 타임아웃 확인 — V8: 1초
        if self._current_sequence and (
            now - self._sequence_start_time > SEQUENCE_TIMEOUT_S
        ):
            self._finalize_current_sequence()

        # 새 시퀀스 시작
        if not self._current_sequence:
            self._sequence_start_time = now
            self._sequence_context = {}

        self._current_sequence.append({
            "tool": tool_name,
            "args": arguments,
            "success": success,
            "timestamp": now,
        })

    def _finalize_current_sequence(self) -> None:
        """현재 시퀀스를 경험으로 저장 — 2개 이상이면 시퀀스로 기록"""
        if len(self._current_sequence) >= MIN_SEQUENCE_LENGTH:
            all_success = all(
                a.get("success", False) for a in self._current_sequence
            )
            self.record_action_sequence(
                description=f"자동 감지 시퀀스 ({len(self._current_sequence)}개 동작)",
                actions=copy.deepcopy(self._current_sequence),
                outcome="success" if all_success else "partial",
                success_score=1.0 if all_success else 0.5,
                duration_s=time.time() - self._sequence_start_time,
            )

        self._current_sequence = []
        self._sequence_start_time = 0.0

    # ──────────────────────────────────────────────────────────────────────
    # flush() — DB 플러시
    # ──────────────────────────────────────────────────────────────────────

    def flush(self) -> None:
        """버퍼의 경험을 DB에 저장 — V8: 추가 컬럼 포함"""
        if not self._conn:
            return

        with self._lock:
            count = 0
            for exp in self._buffer:
                try:
                    self._conn.execute(
                        """INSERT OR REPLACE INTO experiences
                           (experience_id, experience_type, timestamp,
                            description, context, action_sequence, outcome,
                            success_score, duration_s, owner_present,
                            learned, tags,
                            causal_context, emotional_context,
                            world_knowledge_links, affordance_info,
                            novelty_score, quality_score,
                            concept_drift_annotation)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                                   ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            exp.experience_id,
                            exp.experience_type.value,
                            exp.timestamp,
                            exp.description,
                            json.dumps(exp.context, ensure_ascii=False),
                            json.dumps(
                                exp.action_sequence, ensure_ascii=False
                            ),
                            exp.outcome,
                            exp.success_score,
                            exp.duration_s,
                            int(exp.owner_present),
                            int(exp.learned),
                            json.dumps(exp.tags, ensure_ascii=False),
                            # V8.5 추가 컬럼
                            json.dumps(exp.causal_context, ensure_ascii=False) if exp.causal_context else None,
                            json.dumps(exp.emotional_context, ensure_ascii=False) if exp.emotional_context else None,
                            json.dumps(exp.world_knowledge_links, ensure_ascii=False),
                            json.dumps(exp.affordance_info, ensure_ascii=False) if exp.affordance_info else None,
                            exp.novelty_score,
                            exp.quality_score,
                            exp.concept_drift_annotation,
                        ),
                    )
                    count += 1
                except Exception as e:
                    logger.error(f"경험 DB 저장 오류: {e}")

            self._conn.commit()
            logger.debug(f"경험 DB 플러시: {count}개 저장")

    # ──────────────────────────────────────────────────────────────────────
    # get_sequences() — 시퀀스 조회
    # ──────────────────────────────────────────────────────────────────────

    def get_sequences(
        self,
        min_length: int = 2,
        outcome: Optional[str] = None,
        limit: int = 50,
    ) -> List[Experience]:
        """저장된 동작 시퀀스 조회"""
        with self._lock:
            results = []
            for exp in self._buffer:
                if exp.experience_type != ExperienceType.ACTION_SEQUENCE:
                    continue
                if len(exp.action_sequence) < min_length:
                    continue
                if outcome and exp.outcome != outcome:
                    continue
                results.append(exp)
                if len(results) >= limit:
                    break
            return results

    # ──────────────────────────────────────────────────────────────────────
    # analyze_patterns() — 패턴 분석
    # ──────────────────────────────────────────────────────────────────────

    def analyze_patterns(
        self,
        min_repeats: int = 3,
    ) -> List[Tuple[str, int, float]]:
        """
        빈발 동작 시퀀스 패턴 분석 — 스킬 학습용

        Returns:
            (패턴키, 빈도, 평균성공률) 리스트
        """
        with self._lock:
            patterns: Dict[str, List[float]] = {}

            for exp in self._buffer:
                if exp.experience_type != ExperienceType.ACTION_SEQUENCE:
                    continue
                if not exp.action_sequence:
                    continue

                # 패턴 키 생성
                seq_key = "→".join(
                    a.get("tool", "?") for a in exp.action_sequence
                )

                if seq_key not in patterns:
                    patterns[seq_key] = []
                patterns[seq_key].append(exp.success_score)

            # 빈발 패턴 필터링
            frequent = []
            for pattern_key, scores in patterns.items():
                count = len(scores)
                if count < min_repeats:
                    continue
                avg_score = sum(scores) / count
                frequent.append((pattern_key, count, avg_score))

            frequent.sort(key=lambda x: x[1], reverse=True)
            return frequent

    # ──────────────────────────────────────────────────────────────────────
    # V8: 참신한 경험 조회 / Novel Experiences Query
    # ──────────────────────────────────────────────────────────────────────

    def get_novel_experiences(
        self,
        min_novelty: float = NOVELTY_THRESHOLD_HIGH,
        limit: int = 50,
    ) -> List[Experience]:
        """V8: 참신한 경험 조회"""
        with self._lock:
            results = []
            for exp in self._buffer:
                if exp.novelty_score >= min_novelty:
                    results.append(exp)
                    if len(results) >= limit:
                        break
            results.sort(key=lambda x: x.novelty_score, reverse=True)
            return results

    # ──────────────────────────────────────────────────────────────────────
    # V8: 개념 드리프트 경험 조회 / Concept Drift Experiences
    # ──────────────────────────────────────────────────────────────────────

    def get_drift_experiences(
        self,
        limit: int = 50,
    ) -> List[Experience]:
        """V8: 개념 드리프트가 감지된 경험 조회"""
        with self._lock:
            results = []
            for exp in self._buffer:
                if exp.concept_drift_annotation is not None:
                    results.append(exp)
                    if len(results) >= limit:
                        break
            return results

    # ──────────────────────────────────────────────────────────────────────
    # 통계 / Statistics
    # ──────────────────────────────────────────────────────────────────────

    def get_stats(self) -> Dict[str, Any]:
        """경험 수집 통계 — V8: 추가 정보"""
        elapsed_hours = (time.time() - self._start_time) / 3600
        hourly_rate = (
            self._total_collected / elapsed_hours
            if elapsed_hours > 0 else 0
        )

        type_counts: Dict[str, int] = {}
        avg_novelty = 0.0
        avg_quality = 0.0
        drift_count = 0
        novelty_scores = []
        quality_scores = []

        for exp in self._buffer:
            t = exp.experience_type.value
            type_counts[t] = type_counts.get(t, 0) + 1
            novelty_scores.append(exp.novelty_score)
            quality_scores.append(exp.quality_score)
            if exp.concept_drift_annotation is not None:
                drift_count += 1

        if novelty_scores:
            avg_novelty = sum(novelty_scores) / len(novelty_scores)
        if quality_scores:
            avg_quality = sum(quality_scores) / len(quality_scores)

        return {
            "total_collected": self._total_collected,
            "buffer_size": len(self._buffer),
            "buffer_capacity": BUFFER_SIZE,
            "hourly_rate": hourly_rate,
            "target_hourly_rate": TARGET_HOURLY_RATE,
            "meets_target": hourly_rate >= TARGET_HOURLY_RATE,
            "type_counts": type_counts,
            "current_sequence_length": len(self._current_sequence),
            "elapsed_hours": elapsed_hours,
            # V8.5 추가 통계
            "avg_novelty_score": round(avg_novelty, 3),
            "avg_quality_score": round(avg_quality, 3),
            "concept_drift_count": drift_count,
            "unique_descriptions": len(self._seen_descriptions),
        }

    def get_experiences(
        self,
        experience_type: Optional[ExperienceType] = None,
        outcome: Optional[str] = None,
        min_success_score: float = 0.0,
        min_novelty_score: float = 0.0,        # V8
        limit: int = 100,
        since: Optional[float] = None,
        unlearned_only: bool = False,
        include_drift_only: bool = False,       # V8
    ) -> List[Experience]:
        """경험 조회 — V8: 추가 필터 지원"""
        with self._lock:
            results = []
            for exp in self._buffer:
                if experience_type and exp.experience_type != experience_type:
                    continue
                if outcome and exp.outcome != outcome:
                    continue
                if exp.success_score < min_success_score:
                    continue
                if exp.novelty_score < min_novelty_score:  # V8
                    continue
                if since and exp.timestamp < since:
                    continue
                if unlearned_only and exp.learned:
                    continue
                if include_drift_only and exp.concept_drift_annotation is None:  # V8
                    continue
                results.append(exp)
                if len(results) >= limit:
                    break
            return results

    def mark_learned(self, experience_ids: List[str]) -> int:
        """경험을 학습 완료로 표시"""
        marked = 0
        id_set = set(experience_ids)
        for exp in self._buffer:
            if exp.experience_id in id_set:
                exp.learned = True
                marked += 1
        return marked

    def shutdown(self) -> None:
        """경험 수집기 종료"""
        # 마지막 시퀀스 완료
        if self._current_sequence:
            self._finalize_current_sequence()

        # 남은 버퍼 플러시
        self.flush()

        if self._conn:
            self._conn.close()
            self._conn = None
        logger.info(
            f"경험 수집기 V8.5 종료 — 총 {self._total_collected}개 수집"
        )
