#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — TODO 5: CAN 버스 MCP2515 초기화
=================================================

SPI → MCP2515 → CAN 트랜시버 → 120Ω 종단 저항 → MKS XDRIVE

공학 검증:
  - SPI 클럭 10MHz (IMU와 동일 버스 공유 시 클럭 분산)
  - MCP2515 인터럽트 GPIO 연결
  - CAN 종단저항 양단 120Ω
  - CAN 2.0B 1Mbps 안정

위험:
  - SPI 버스 과부하 — IMU와 MCP2515가 동일 SPI 버스 공유
  - 해결: SPI 클럭 분산, 인터럽트 기반 폴링

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import heapq
import logging
import os
import socket
import struct
import subprocess
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from hardware.config import (
    ActuatorConfig,
    ControlMode,
    JihunRobotV7Config,
    MKSXDriveConfig,
    MotorType,
)

logger = logging.getLogger("jihun.v84.can_bus")

# ============================================================================
# 상수
# ============================================================================

CAN_INTERFACE = "can0"
CAN_BITRATE = 1000000  # 1Mbps

# MCP2515 SPI 설정
SPI_BUS = 1
SPI_DEVICE = 1       # /dev/spidev1.1 (IMU와 SPI1 공유)
SPI_SPEED_HZ = 10_000_000  # 10MHz
SPI_MODE = 0

# MCP2515 레지스터
MCP2515_REG_CANCTRL = 0x0F
MCP2515_REG_CANSTAT = 0x0E
MCP2515_REG_CNF1 = 0x2A
MCP2515_REG_CNF2 = 0x29
MCP2515_REG_CNF3 = 0x28
MCP2515_REG_TXB0CTRL = 0x30
MCP2515_REG_RXB0CTRL = 0x60
MCP2515_REG_CANINTF = 0x2C

# MCP2515 명령
MCP2515_CMD_RESET = 0xC0
MCP2515_CMD_READ = 0x03
MCP2515_CMD_WRITE = 0x02
MCP2515_CMD_RTS_TX0 = 0x81
MCP2515_CMD_READ_STATUS = 0xA0

# CAN 프레임 구조
CAN_FRAME_DLC_MAX = 8  # CAN 2.0B 최대 데이터 길이

# MKS XDRIVE CAN ID
CAN_ID_EMERGENCY_STOP = 0x500
CAN_ID_HEARTBEAT = 0x501

# 인터럽트 GPIO (Jetson #2)
MCP2515_INTERRUPT_GPIO = 27  # Jetson GPIO 27


@dataclass
class CANFrame:
    """CAN 2.0B 프레임"""
    arbitration_id: int = 0
    is_extended: bool = False
    is_remote: bool = False
    dlc: int = 0
    data: bytes = b""
    timestamp: float = 0.0

    def __post_init__(self):
        if self.dlc > CAN_FRAME_DLC_MAX:
            raise ValueError(f"DLC {self.dlc} > {CAN_FRAME_DLC_MAX}")
        if len(self.data) > CAN_FRAME_DLC_MAX:
            raise ValueError(f"데이터 길이 {len(self.data)} > {CAN_FRAME_DLC_MAX}")


@dataclass
class MotorCommand:
    """모터 명령 (XDRIVE 프로토콜)"""
    motor_id: int = 0       # CAN ID (0x201~0x204)
    control_mode: int = 0   # 0=속도, 1=위치, 2=토크
    target_value: float = 0.0
    velocity_limit: float = 0.0
    torque_limit: float = 0.0


@dataclass
class CANBusStatus:
    """CAN 버스 상태"""
    interface: str = CAN_INTERFACE
    is_up: bool = False
    bitrate: int = CAN_BITRATE
    frames_sent: int = 0
    frames_received: int = 0
    errors: int = 0
    bus_off: bool = False
    spi_initialized: bool = False
    terminator_set: bool = False


class CANBus:
    """
    TODO 5: CAN 버스 MCP2515 초기화

    기능:
      - SPI → MCP2515 → CAN 트랜시버 초기화
      - 120Ω 종단 저항 설정
      - 루프백 테스트 (1Mbps)
      - CAN 2.0B 프레임 송수신 (Python socketcan — subprocess fallback)
      - MKS XDRIVE 모터 명령 전송
    """

    # SocketCAN frame format: <IB3x8s  (little-endian)
    #   I  = CAN ID (4 bytes)
    #   B  = DLC + flags (1 byte)
    #   3x = padding (3 bytes)
    #   8s = data (8 bytes)
    _CAN_FRAME_STRUCT = struct.Struct("<IB3x8s")

    # CAN_RAW socket constants (from linux/can.h)
    CAN_RAW = 1
    CAN_EFF_FLAG = 0x80000000  # Extended frame flag
    CAN_RTR_FLAG = 0x40000000  # Remote transmission request
    CAN_ERR_FLAG = 0x20000000  # Error frame

    def __init__(self, config: Optional[JihunRobotV7Config] = None):
        self.config = config or JihunRobotV7Config()
        self.actuator = self.config.actuator
        self.xdrive = self.actuator.xdrive
        self._status = CANBusStatus()
        self._spi_handle = None
        self._lock = threading.Lock()

        # SocketCAN handles — primary fast path (no subprocess overhead)
        self._can_socket: Optional[socket.socket] = None
        self._use_socketcan = False

        # Try to open a Python socketcan socket upfront
        self._init_socketcan()

    # ========================================================================
    # 공용 메서드
    # ========================================================================

    def setup(self) -> bool:
        """전체 CAN 버스 설정"""
        logger.info("=== CAN 버스 MCP2515 초기화 ===")

        # 1. MCP2515 초기화 (SPI)
        if not self.init_mcp2515():
            logger.error("MCP2515 초기화 실패")
            return False

        # 2. 종단 저항 설정
        self.setup_terminator()

        # 3. CAN 인터페이스 활성화
        if not self._bring_up_can_interface():
            logger.error("CAN 인터페이스 활성화 실패")
            return False

        # 4. 루프백 테스트
        if not self.loopback_test():
            logger.warning("루프백 테스트 실패 — 배선 확인 필요")

        logger.info("=== CAN 버스 초기화 완료 ===")
        return True

    def verify(self) -> bool:
        """CAN 버스 상태 검증"""
        return self._status.is_up and self._check_can_interface()

    # ========================================================================
    # TODO 5-1: MCP2515 초기화 (SPI)
    # ========================================================================

    def init_mcp2515(self) -> bool:
        """
        SPI → MCP2515 → CAN 트랜시어 초기화

        과정:
          1. SPI 버스 열기 (/dev/spidev1.1)
          2. MCP2515 리셋
          3. CNF1/CNF2/CNF3 설정 (1Mbps)
          4. 인터럽트 핀 설정
          5. Normal 모드 진입
        """
        logger.info("MCP2515 초기화 중...")

        # 1. SPI 장치 확인
        spi_dev = Path(f"/dev/spidev{SPI_BUS}.{SPI_DEVICE}")
        if not spi_dev.exists():
            logger.error(f"  ✗ SPI 장치 없음: {spi_dev}")
            logger.info("  설정: sudo modprobe spidev")
            return False

        # 2. SPI 초기화
        try:
            import spidev
            self._spi_handle = spidev.SpiDev(SPI_BUS, SPI_DEVICE)
            self._spi_handle.max_speed_hz = SPI_SPEED_HZ
            self._spi_handle.mode = SPI_MODE
            self._status.spi_initialized = True
            logger.info(f"  ✓ SPI 초기화: bus={SPI_BUS}, dev={SPI_DEVICE}, {SPI_SPEED_HZ/1e6}MHz")
        except ImportError:
            logger.warning("  ⚠ spidev 미설치 — SocketCAN 모드로 대체")
            self._status.spi_initialized = False
        except Exception as e:
            logger.warning(f"  ⚠ SPI 초기화 실패: {e} — SocketCAN 모드로 대체")
            self._status.spi_initialized = False

        # 3. MCP2515 리셋 (SPI 가능한 경우)
        if self._status.spi_initialized and self._spi_handle:
            self._mcp2515_reset()
            self._mcp2515_configure_bitrate()
            self._mcp2515_set_normal_mode()

        # 4. GPIO 인터럽트 설정
        self._setup_interrupt_gpio()

        logger.info("  ✓ MCP2515 초기화 완료")
        return True

    def _mcp2515_reset(self) -> bool:
        """MCP2515 소프트웨어 리셋"""
        if not self._spi_handle:
            return False
        try:
            self._spi_handle.writebytes([MCP2515_CMD_RESET])
            time.sleep(0.01)  # 10ms 대기
            logger.info("  ✓ MCP2515 리셋")
            return True
        except Exception as e:
            logger.error(f"  ✗ MCP2515 리셋 실패: {e}")
            return False

    def _mcp2515_configure_bitrate(self) -> bool:
        """
        MCP2515 비트레이트 설정 (1Mbps)

        CNF1: SJW=1, BRP=0 → TQ = 2 * (0+1) / 10MHz = 200ns
        CNF2: BTLMODE=1, SAM=0, PHSEG1=5, PRSEG=1
        CNF3: PHSEG2=5
        → 1Mbps @ 10MHz OSC
        """
        if not self._spi_handle:
            return False

        try:
            # 1Mbps @ 10MHz 클럭
            # CNF1: BRP=0, SJW=1
            self._mcp2515_write_register(MCP2515_REG_CNF1, 0x00)
            # CNF2: BTLMODE=1, SAM=0, PHSEG1=5, PRSEG=1
            self._mcp2515_write_register(MCP2515_REG_CNF2, 0xB1)
            # CNF3: PHSEG2=5
            self._mcp2515_write_register(MCP2515_REG_CNF3, 0x05)

            logger.info("  ✓ MCP2515 비트레이트 설정: 1Mbps")
            return True
        except Exception as e:
            logger.error(f"  ✗ 비트레이트 설정 실패: {e}")
            return False

    def _mcp2515_set_normal_mode(self) -> bool:
        """MCP2515 Normal 모드 설정"""
        if not self._spi_handle:
            return False
        try:
            self._mcp2515_write_register(MCP2515_REG_CANCTRL, 0x00)
            time.sleep(0.01)
            stat = self._mcp2515_read_register(MCP2515_REG_CANSTAT)
            if (stat & 0xE0) == 0x00:
                logger.info("  ✓ MCP2515 Normal 모드")
                return True
            else:
                logger.warning(f"  ⚠ MCP2515 모드 확인 실패: CANSTAT=0x{stat:02X}")
                return False
        except Exception as e:
            logger.error(f"  ✗ Normal 모드 설정 실패: {e}")
            return False

    def _mcp2515_write_register(self, register: int, value: int) -> None:
        """MCP2515 레지스터 쓰기"""
        if self._spi_handle:
            self._spi_handle.writebytes([MCP2515_CMD_WRITE, register, value])

    def _mcp2515_read_register(self, register: int) -> int:
        """MCP2515 레지스터 읽기"""
        if self._spi_handle:
            result = self._spi_handle.xfer2([MCP2515_CMD_READ, register, 0x00])
            return result[2]
        return 0

    def _setup_interrupt_gpio(self) -> None:
        """MCP2515 인터럽트 GPIO 설정"""
        gpio_path = Path(f"/sys/class/gpio/gpio{MCP2515_INTERRUPT_GPIO}")
        try:
            if not gpio_path.exists():
                export_path = Path("/sys/class/gpio/export")
                export_path.write_text(str(MCP2515_INTERRUPT_GPIO))
                time.sleep(0.1)

            # 입력 모드
            (gpio_path / "direction").write_text("in")
            # 엣지 트리거 (하강 에지 = MCP2515 인터럽트 활성)
            (gpio_path / "edge").write_text("falling")
            logger.info(f"  ✓ 인터럽트 GPIO {MCP2515_INTERRUPT_GPIO} 설정")
        except IOError as e:
            logger.warning(f"  ⚠ GPIO 인터럽트 설정 불가: {e}")

    # ========================================================================
    # TODO 5-2: 종단 저항 설정
    # ========================================================================

    def setup_terminator(self) -> bool:
        """
        120Ω 종단 저항 설정 (CAN 양단)

        MCP2515 모듈에 내장 종단 저항 점퍼가 있는 경우 활성화
        외부 120Ω 저항이 양단에 연결되어 있어야 함
        """
        logger.info("CAN 종단 저항 확인 중...")

        # 종단 저항은 하드웨어적으로 연결되어야 함
        # 소프트웨어에서는 CAN 버스 풀업 상태로 간접 확인
        terminator_ohm = self.actuator.can_terminator_ohm
        logger.info(f"  종단 저항 사양: {terminator_ohm}Ω × 2 (양단)")

        # CAN-H / CAN-L 간 저항 측정 (약 60Ω = 120Ω 병렬 2개)
        # 실제 측정은 멀티미터로 수동 확인 필요
        logger.info("  ⚠ 종단 저항 수동 확인 필요:")
        logger.info("    CAN-H ↔ CAN-L 간 저항 ≈ 60Ω (정상)")
        logger.info("    측정 불가 시: 120Ω 저항 양단 연결 확인")

        self._status.terminator_set = True
        return True

    # ========================================================================
    # TODO 5-3: 루프백 테스트
    # ========================================================================

    def loopback_test(self) -> bool:
        """
        CAN 루프백 테스트 — 자기 송수신 확인 (1Mbps)

        과정:
          1. CAN 인터페이스를 루프백 모드로 설정
          2. 테스트 프레임 송신
          3. 동일 프레임 수신 확인
          4. Normal 모드로 복귀
        """
        logger.info("CAN 루프백 테스트 중...")

        # SocketCAN 루프백 모드
        try:
            # 루프백 모드 설정
            subprocess.run(
                ["sudo", "ip", "link", "set", CAN_INTERFACE, "type", "can",
                 "loopback", "on"],
                capture_output=True, text=True, timeout=10,
            )

            # CAN 인터페이스 활성화
            subprocess.run(
                ["sudo", "ip", "link", "set", CAN_INTERFACE, "up"],
                capture_output=True, text=True, timeout=10,
            )

            time.sleep(0.1)

            # candump 백그라운드 실행
            dump_proc = subprocess.Popen(
                ["candump", CAN_INTERFACE, "-t", "a"],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            )

            time.sleep(0.1)

            # 테스트 프레임 송신
            test_id = 0x123
            test_data = bytes([0xDE, 0xAD, 0xBE, 0xEF, 0x01, 0x02, 0x03, 0x04])
            self.send_frame(test_id, test_data)

            time.sleep(0.5)

            # candump 종료 및 결과 확인
            dump_proc.terminate()
            output = dump_proc.stdout.read().decode("utf-8", errors="replace")

            if f"{test_id:03X}" in output:
                logger.info("  ✓ 루프백 테스트 성공 — 송수신 확인")
                with self._lock:
                    self._status.frames_sent += 1
                    self._status.frames_received += 1
            else:
                logger.warning("  ⚠ 루프백 수신 확인 불가 — 배선/드라이버 점검")
                logger.info(f"  candump 출력: {output[:200]}")

            # Normal 모드로 복귀
            subprocess.run(
                ["sudo", "ip", "link", "set", CAN_INTERFACE, "type", "can",
                 "loopback", "off"],
                capture_output=True, text=True, timeout=10,
            )

            return True

        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.error(f"  ✗ 루프백 테스트 실패: {e}")
            return False

    # ========================================================================
    # TODO 5-4: CAN 프레임 송수신
    # ========================================================================

    def _init_socketcan(self) -> None:
        """Python socketcan 소켓 초기화 (subprocess 대체) / Init Python socketcan socket."""
        try:
            self._can_socket = socket.socket(
                socket.PF_CAN, socket.SOCK_RAW, self.CAN_RAW
            )
            self._can_socket.bind((CAN_INTERFACE,))
            self._use_socketcan = True
            logger.info("SocketCAN Python 소켓 초기화 성공 / socketcan socket ready")
        except (OSError, socket.error) as e:
            logger.warning(
                "SocketCAN 소켓 생성 실패 (%s) — subprocess cansend/candump 폴백 사용 / "
                "falling back to subprocess", e,
            )
            self._can_socket = None
            self._use_socketcan = False

    def _socketcan_send(self, arbitration_id: int, data: bytes, is_extended: bool) -> bool:
        """Python socketcan으로 CAN 프레임 전송 / Send via Python socketcan."""
        if self._can_socket is None:
            return False
        try:
            can_id = arbitration_id
            if is_extended:
                can_id |= self.CAN_EFF_FLAG
            # Pad data to 8 bytes for CAN frame struct
            padded = data.ljust(8, b"\x00")
            frame = self._CAN_FRAME_STRUCT.pack(can_id, len(data), padded)
            self._can_socket.send(frame)
            return True
        except (OSError, socket.error) as e:
            logger.warning("SocketCAN send 실패: %s — 폴백으로 전환", e)
            self._use_socketcan = False
            return False

    def _socketcan_recv(self, timeout_ms: int = 100) -> Optional[CANFrame]:
        """Python socketcan으로 CAN 프레임 수신 / Receive via Python socketcan."""
        if self._can_socket is None:
            return None
        try:
            self._can_socket.settimeout(timeout_ms / 1000.0)
            raw = self._can_socket.recv(16)
            if not raw or len(raw) < 16:
                return None
            can_id, dlc, padded = self._CAN_FRAME_STRUCT.unpack(raw)
            is_extended = bool(can_id & self.CAN_EFF_FLAG)
            is_remote = bool(can_id & self.CAN_RTR_FLAG)
            can_id &= ~(self.CAN_EFF_FLAG | self.CAN_RTR_FLAG | self.CAN_ERR_FLAG)
            return CANFrame(
                arbitration_id=can_id,
                is_extended=is_extended,
                is_remote=is_remote,
                dlc=dlc,
                data=padded[:dlc],
                timestamp=time.time(),
            )
        except socket.timeout:
            return None
        except (OSError, socket.error) as e:
            logger.warning("SocketCAN recv 실패: %s", e)
            self._use_socketcan = False
            return None

    def _subprocess_send(self, arbitration_id: int, data: bytes, is_extended: bool) -> bool:
        """cansend 서브프로세스로 CAN 프레임 전송 (폴백) / Send via subprocess (fallback)."""
        data_hex = "".join(f"{b:02X}" for b in data)
        if is_extended:
            can_id_str = f"{arbitration_id:08X}##{len(data)}:{data_hex}"
        else:
            can_id_str = f"{arbitration_id:03X}#{data_hex}"

        result = subprocess.run(
            ["cansend", CAN_INTERFACE, can_id_str],
            capture_output=True, text=True, timeout=5,
        )
        return result.returncode == 0

    def _subprocess_recv(self, timeout_ms: int = 100) -> Optional[CANFrame]:
        """candump 서브프로세스로 CAN 프레임 수신 (폴백) / Receive via subprocess (fallback)."""
        result = subprocess.run(
            ["timeout", f"{timeout_ms / 1000:.1f}", "candump", CAN_INTERFACE, "-t", "a", "-n", "1"],
            capture_output=True, text=True, timeout=timeout_ms / 1000 + 2,
        )
        if result.returncode == 0 and result.stdout.strip():
            line = result.stdout.strip().split("\n")[-1]
            parts = line.split()
            if len(parts) >= 4:
                arb_id = int(parts[2], 16)
                dlc = int(parts[3].strip("[]"))
                data_bytes = bytes(int(b, 16) for b in parts[4:4 + dlc])
                return CANFrame(
                    arbitration_id=arb_id,
                    dlc=dlc,
                    data=data_bytes,
                    timestamp=time.time(),
                )
        return None

    def send_frame(self, arbitration_id: int, data: bytes, is_extended: bool = False) -> bool:
        """
        CAN 2.0B 프레임 송신

        Python socketcan 소켓을 우선 사용하고, 실패 시 subprocess(cansend)로 폴백.

        Args:
            arbitration_id: CAN ID (11bit 표준 / 29bit 확장)
            data: 데이터 (최대 8바이트)
            is_extended: 확장 프레임 여부
        """
        if len(data) > CAN_FRAME_DLC_MAX:
            logger.error(f"  데이터 길이 초과: {len(data)} > {CAN_FRAME_DLC_MAX}")
            return False

        # Primary: Python socketcan (no process spawn overhead)
        if self._use_socketcan:
            if self._socketcan_send(arbitration_id, data, is_extended):
                with self._lock:
                    self._status.frames_sent += 1
                return True
            # Fall through to subprocess on socket error

        # Fallback: subprocess cansend
        try:
            if self._subprocess_send(arbitration_id, data, is_extended):
                with self._lock:
                    self._status.frames_sent += 1
                return True
            else:
                with self._lock:
                    self._status.errors += 1
                logger.error("  ✗ CAN 전송 실패 (subprocess)")
                return False
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            with self._lock:
                self._status.errors += 1
            logger.error(f"  ✗ cansend 실행 불가: {e}")
            return False

    def receive_frame(self, timeout_ms: int = 100) -> Optional[CANFrame]:
        """
        CAN 프레임 수신 (타임아웃 설정)

        Python socketcan 소켓을 우선 사용하고, 실패 시 subprocess(candump)로 폴백.

        Args:
            timeout_ms: 수신 대기 시간 (ms)

        Returns:
            CANFrame 또는 None (타임아웃)
        """
        # Primary: Python socketcan (no process spawn overhead)
        if self._use_socketcan:
            frame = self._socketcan_recv(timeout_ms)
            if frame is not None:
                with self._lock:
                    self._status.frames_received += 1
                return frame
            # None could mean timeout or error; if socket died, fall through

        # Fallback: subprocess candump
        try:
            frame = self._subprocess_recv(timeout_ms)
            if frame is not None:
                with self._lock:
                    self._status.frames_received += 1
                return frame
        except (FileNotFoundError, subprocess.TimeoutExpired, ValueError):
            pass

        return None

    # ========================================================================
    # TODO 5-5: MKS XDRIVE 모터 명령
    # ========================================================================

    def set_motor_command(self, cmd: MotorCommand) -> bool:
        """
        MKS XDRIVE Mini에 모터 명령 전송

        CAN 프레임 구조 (8바이트):
          [0-1]: 목표값 (int16, 속도: 0.01rad/s, 위치: 0.01rad, 토크: 0.01N·m)
          [2-3]: 속도 제한 (int16, 0.01rad/s)
          [4-5]: 토크 제한 (int16, 0.01N·m)
          [6]:   제어 모드 (0=속도, 1=위치, 2=토크)
          [7]:   예비

        CAN ID 매핑:
          0x201: 좌다리피치, 0x202: 우다리피치
          0x203: 좌다리승강, 0x204: 우다리승강
        """
        # 목표값 → int16 변환 (0.01 단위)
        target_raw = int(cmd.target_value * 100)
        vel_limit_raw = int(cmd.velocity_limit * 100)
        torque_limit_raw = int(cmd.torque_limit * 100)

        # 값 범위 검증
        target_raw = max(-32767, min(32767, target_raw))
        vel_limit_raw = max(0, min(65535, vel_limit_raw))
        torque_limit_raw = max(0, min(65535, torque_limit_raw))

        # CAN 프레임 조립
        data = struct.pack(
            "<hhhBB",
            target_raw,          # [0-1]: 목표값
            vel_limit_raw,       # [2-3]: 속도 제한
            torque_limit_raw,    # [4-5]: 토크 제한
            cmd.control_mode,    # [6]: 제어 모드
            0,                   # [7]: 예비
        )

        success = self.send_frame(cmd.motor_id, data)

        if success:
            logger.debug(
                f"  모터 명령: ID=0x{cmd.motor_id:03X} "
                f"모드={cmd.control_mode} "
                f"목표={cmd.target_value:.2f}"
            )
        return success

    def send_emergency_stop(self) -> bool:
        """긴급 정지 — 모든 XDRIVE에 정지 명령 전송"""
        logger.warning("긴급 정지 — CAN Emergency Stop 전송")

        # XDRIVE CAN ID에 모두 정지 명령
        for can_id in self.xdrive.can_ids.values():
            cmd = MotorCommand(
                motor_id=can_id,
                control_mode=ControlMode.VELOCITY,
                target_value=0.0,
                velocity_limit=0.0,
                torque_limit=0.0,
            )
            self.set_motor_command(cmd)

        # 긴급 정지 브로드캐스트
        self.send_frame(CAN_ID_EMERGENCY_STOP, b"\x01\x00\x00\x00\x00\x00\x00\x00")
        return True

    def send_heartbeat(self) -> bool:
        """CAN 버스 하트비트 전송"""
        import struct
        data = struct.pack("<I", int(time.time() * 1000) & 0xFFFFFFFF)
        return self.send_frame(CAN_ID_HEARTBEAT, data.ljust(8, b"\x00"))

    # ========================================================================
    # CAN 인터페이스 관리
    # ========================================================================

    def _bring_up_can_interface(self) -> bool:
        """CAN 인터페이스 활성화 (SocketCAN)"""
        logger.info("CAN 인터페이스 활성화 중...")

        try:
            # 기존 인터페이스 다운
            subprocess.run(
                ["sudo", "ip", "link", "set", CAN_INTERFACE, "down"],
                capture_output=True, text=True, timeout=10,
            )

            # 비트레이트 설정 및 활성화
            result = subprocess.run(
                [
                    "sudo", "ip", "link", "set", CAN_INTERFACE,
                    "type", "can", "bitrate", str(CAN_BITRATE),
                    "restart-ms", "100",  # 버스오프 시 100ms 후 자동 재시작
                ],
                capture_output=True, text=True, timeout=10,
            )

            if result.returncode != 0:
                logger.error(f"  ✗ CAN 설정 실패: {result.stderr}")
                return False

            # 인터페이스 업
            result = subprocess.run(
                ["sudo", "ip", "link", "set", CAN_INTERFACE, "up"],
                capture_output=True, text=True, timeout=10,
            )

            if result.returncode == 0:
                self._status.is_up = True
                logger.info(f"  ✓ CAN 인터페이스 활성화: {CAN_INTERFACE} @ {CAN_BITRATE/1000}kbps")
                return True
            else:
                logger.error(f"  ✗ CAN 업 실패: {result.stderr}")
                return False

        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.error(f"  ✗ ip 명령 불가: {e}")
            return False

    def _check_can_interface(self) -> bool:
        """CAN 인터페이스 상태 확인"""
        try:
            result = subprocess.run(
                ["ip", "-d", "link", "show", CAN_INTERFACE],
                capture_output=True, text=True, timeout=5,
            )
            return "UP" in result.stdout and "CAN" in result.stdout
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def get_status(self) -> CANBusStatus:
        """CAN 버스 상태 반환"""
        with self._lock:
            self._status.is_up = self._check_can_interface()
            return self._status


# ============================================================================
# SPI Bus Arbitration + CAN Bus Robustness — Physical AGI 통신 혁신
# ============================================================================
# 기존 문제: MCP2515(CAN)과 ICM-42688-P(IMU)가 SPI1 공유 → 동시 접근 시 데이터 손상
# 혁신 1: SPI 버스 뮤텍스 — CAN과 IMU 간 안전한 버스 공유
# 혁신 2: CAN 버스 복구 — bus-off 상태에서 자동 복구
# 혁신 3: 메시지 우선순위 큐 — 긴급 메시지 우선 처리
# ============================================================================

class SPIBusArbiter:
    """SPI 버스 중재자 — CAN과 IMU 간 안전한 버스 공유
    
    문제: MCP2515(CAN)와 ICM-42688-P(IMU)가 SPI1 공유
    해결: 뮤텍스 기반 순차 접근 + CS 핀 관리
    """
    
    def __init__(self, can_cs_pin=8, imu_cs_pin=10, 
                 bus_settle_time_us=10, max_wait_ms=50):
        self.can_cs_pin = can_cs_pin
        self.imu_cs_pin = imu_cs_pin
        self.bus_settle_time_us = bus_settle_time_us
        self.max_wait_ms = max_wait_ms
        
        self._lock = threading.Lock()
        self._current_owner = None
        self._access_count = {'can': 0, 'imu': 0}
        self._contention_count = 0
    
    @contextmanager
    def acquire(self, device):
        """SPI 버스 획득 컨텍스트 매니저
        
        Usage:
            with arbiter.acquire('can'):
                can_controller.send_frame(frame)
        """
        start_time = time.time()
        
        acquired = self._lock.acquire(timeout=self.max_wait_ms / 1000.0)
        if not acquired:
            self._contention_count += 1
            logging.warning(f"[SPIArbiter] {device} 버스 획득 타임아웃!")
            raise TimeoutError(f"SPI bus acquisition timeout for {device}")
        
        try:
            self._current_owner = device
            self._access_count[device] = self._access_count.get(device, 0) + 1
            
            # 다른 디바이스 CS 해제 후 현재 디바이스 CS 활성화
            self._deselect_all()
            time.sleep(self.bus_settle_time_us / 1e6)
            self._select_device(device)
            
            yield
        finally:
            self._deselect_all()
            self._current_owner = None
            self._lock.release()
    
    def _select_device(self, device):
        """디바이스 CS 활성화 (LOW)"""
        try:
            import Jetson.GPIO as GPIO
            if device == 'can':
                GPIO.output(self.can_cs_pin, GPIO.LOW)
            elif device == 'imu':
                GPIO.output(self.imu_cs_pin, GPIO.LOW)
        except ImportError:
            pass  # Simulation mode
    
    def _deselect_all(self):
        """모든 CS 해제 (HIGH)"""
        try:
            import Jetson.GPIO as GPIO
            GPIO.output(self.can_cs_pin, GPIO.HIGH)
            GPIO.output(self.imu_cs_pin, GPIO.HIGH)
        except ImportError:
            pass
    
    @property
    def statistics(self):
        return {
            'can_accesses': self._access_count.get('can', 0),
            'imu_accesses': self._access_count.get('imu', 0),
            'contention_count': self._contention_count,
        }


class CANBusRecoveryManager:
    """CAN 버스 복구 관리자 — bus-off 상태에서 자동 복구
    
    CAN 버스 오류 누적 → bus-off 상태 → 통신 불가
    자동 복구: 지수 백오프 + 재초기화
    """
    
    def __init__(self, max_recovery_attempts=5, base_delay_ms=100,
                 max_delay_ms=5000):
        self.max_recovery_attempts = max_recovery_attempts
        self.base_delay_ms = base_delay_ms
        self.max_delay_ms = max_delay_ms
        
        self._error_count = 0
        self._recovery_count = 0
        self._is_bus_off = False
        self._last_error_time = 0
    
    def handle_bus_error(self, error_type, can_controller=None):
        """CAN 버스 오류 처리"""
        self._error_count += 1
        self._last_error_time = time.time()
        
        if error_type in ('bus_off', 'bus-off'):
            self._is_bus_off = True
            return self._attempt_recovery(can_controller)
        
        elif error_type in ('error_passive', 'error-passive'):
            logging.warning("[CANRecovery] Error passive 모드 진입")
            return True  # 아직 통신 가능
        
        return True
    
    def _attempt_recovery(self, can_controller=None):
        """bus-off 복구 시도 (지수 백오프)"""
        for attempt in range(self.max_recovery_attempts):
            delay = min(
                self.base_delay_ms * (2 ** attempt),
                self.max_delay_ms
            )
            
            logging.info(f"[CANRecovery] 복구 시도 {attempt + 1}/{self.max_recovery_attempts} "
                        f"(대기 {delay}ms)")
            time.sleep(delay / 1000.0)
            
            if can_controller and hasattr(can_controller, 'reinitialize'):
                try:
                    can_controller.reinitialize()
                    self._is_bus_off = False
                    self._recovery_count += 1
                    logging.info("[CANRecovery] 복구 성공!")
                    return True
                except Exception as e:
                    logging.error(f"[CANRecovery] 복구 실패: {e}")
            else:
                # 컨트롤러 없으면 성공으로 간주 (시뮬레이션)
                self._is_bus_off = False
                self._recovery_count += 1
                return True
        
        logging.critical("[CANRecovery] 최대 복구 시도 초과!")
        return False
    
    @property
    def is_healthy(self):
        return not self._is_bus_off
    
    @property
    def statistics(self):
        return {
            'error_count': self._error_count,
            'recovery_count': self._recovery_count,
            'is_bus_off': self._is_bus_off,
        }


class PriorityMessageQueue:
    """CAN 메시지 우선순위 큐 — 긴급 메시지 우선 처리
    
    우선순위:
    0: EMERGENCY (E-Stop, 충돌 감지)
    1: HIGH (제어 명령, 안전)
    2: NORMAL (센서 데이터)
    3: LOW (진단, 로깅)
    """
    
    def __init__(self, max_size=1000):
        self.max_size = max_size
        self._queues = {
            0: [],  # EMERGENCY
            1: [],  # HIGH
            2: [],  # NORMAL
            3: [],  # LOW
        }
        self._lock = threading.Lock()
        self._dropped = {p: 0 for p in range(4)}
    
    def enqueue(self, message, priority=2):
        """메시지 큐잉"""
        if priority not in self._queues:
            priority = 2
        
        with self._lock:
            if len(self._queues[priority]) >= self.max_size:
                self._dropped[priority] += 1
                return False
            
            heapq.heappush(self._queues[priority], (time.time(), message))
            return True
    
    def dequeue(self):
        """우선순위 순으로 메시지 반환"""
        with self._lock:
            for priority in sorted(self._queues.keys()):
                if self._queues[priority]:
                    _, message = heapq.heappop(self._queues[priority])
                    return message, priority
        
        return None, None
    
    @property
    def statistics(self):
        return {
            'queue_sizes': {p: len(q) for p, q in self._queues.items()},
            'dropped': dict(self._dropped),
            'total_queued': sum(len(q) for q in self._queues.values()),
        }
