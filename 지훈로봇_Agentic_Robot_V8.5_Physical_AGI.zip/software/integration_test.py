#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 시스템 전체 통합 테스트
========================================

모든 서브시스템 동시 실행, 1시간 연속 동작 검증
음성 명령 → 이동 → 탐지 → 파지 → 복귀 전체 시나리오

TODO 55: integration_test.py

기능:
  - 전체 서브시스템 동시 실행 테스트
  - 1시간 연속 동작 검증
  - 음성→이동→탐지→파지→복귀 전체 시나리오
  - 10회 연속 성공 기준
  - SQLite 이벤트 로깅
  - 오류 시 자동 복구

작성일: 2026-05-19
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ============================================================================
# 열거형 및 상수
# ============================================================================

class TestPhase(Enum):
    """테스트 단계"""
    SETUP = "setup"
    VOICE = "voice"
    NAVIGATION = "navigation"
    DETECTION = "detection"
    GRASP = "grasp"
    RETURN = "return"
    SAFETY = "safety"
    ENDURANCE = "endurance"
    TEARDOWN = "teardown"


class TestResult(Enum):
    """테스트 결과"""
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"
    ERROR = "error"


class Subsystem(Enum):
    """서브시스템 식별"""
    COMPUTE = "compute"
    MOTOR = "motor"
    SENSOR = "sensor"
    AI = "ai"
    AUDIO = "audio"
    POWER = "power"
    SAFETY = "safety"
    DISPLAY = "display"
    NETWORK = "network"


# 테스트 기준
FULL_TEST_DURATION_S = 3600       # 1시간 연속 동작
CONSECUTIVE_SUCCESS_TARGET = 10   # 10회 연속 성공
MAX_ERRORS_BEFORE_ABORT = 5       # 최대 허용 오류
AUTO_RECOVERY_TIMEOUT_S = 30      # 자동 복구 타임아웃
TEST_LOG_DB = "/opt/jihun/test/integration_test.db"

# 성능 기준 (TODO 56 벤치마크와 연동)
TARGET_VOICE_TO_ACTION_MS = 3000  # 음성→행동 <3초
TARGET_GRASP_SUCCESS_RATE = 0.85  # 파지 성공률 >85%
TARGET_UPTIME_HOURS = 1.0         # 연속 동작 >1시간


# ============================================================================
# 데이터 클래스
# ============================================================================

@dataclass
class TestEvent:
    """테스트 이벤트"""
    event_type: str = ""
    phase: TestPhase = TestPhase.SETUP
    subsystem: Subsystem = Subsystem.COMPUTE
    result: TestResult = TestResult.PASS
    message: str = ""
    duration_ms: float = 0.0
    timestamp: float = 0.0
    details: Dict = field(default_factory=dict)

    def __post_init__(self):
        if self.timestamp == 0.0:
            self.timestamp = time.time()


@dataclass
class SubsystemHealth:
    """서브시스템 상태"""
    subsystem: Subsystem = Subsystem.COMPUTE
    is_healthy: bool = True
    last_check: float = 0.0
    error_count: int = 0
    recovery_count: int = 0
    temperature_c: float = 25.0
    details: Dict = field(default_factory=dict)


@dataclass
class TestReport:
    """테스트 결과 보고서"""
    test_id: str = ""
    start_time: float = 0.0
    end_time: float = 0.0
    total_duration_s: float = 0.0
    phases_completed: List[str] = field(default_factory=list)
    consecutive_successes: int = 0
    total_errors: int = 0
    total_recoveries: int = 0
    subsystem_health: Dict[str, Dict] = field(default_factory=dict)
    performance_metrics: Dict = field(default_factory=dict)
    passed: bool = False


# ============================================================================
# SQLite 로거
# ============================================================================

class TestLogDB:
    """테스트 이벤트 SQLite 로거"""

    def __init__(self, db_path: str = TEST_LOG_DB):
        self._db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        self._initialize_db()

    def _initialize_db(self) -> None:
        """데이터베이스 스키마 생성"""
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS test_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                event_type TEXT NOT NULL,
                phase TEXT NOT NULL,
                subsystem TEXT NOT NULL,
                result TEXT NOT NULL,
                message TEXT,
                duration_ms REAL,
                details TEXT
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS test_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id TEXT NOT NULL,
                start_time REAL,
                end_time REAL,
                passed INTEGER,
                consecutive_successes INTEGER,
                total_errors INTEGER
            )
        """)
        self._conn.commit()

    def log_event(self, event: TestEvent) -> None:
        """이벤트 기록"""
        with self._lock:
            if self._conn:
                self._conn.execute(
                    """INSERT INTO test_events
                       (timestamp, event_type, phase, subsystem, result, message, duration_ms, details)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        event.timestamp,
                        event.event_type,
                        event.phase.value,
                        event.subsystem.value,
                        event.result.value,
                        event.message,
                        event.duration_ms,
                        json.dumps(event.details),
                    ),
                )
                self._conn.commit()

    def log_session(self, report: TestReport) -> None:
        """테스트 세션 기록"""
        with self._lock:
            if self._conn:
                self._conn.execute(
                    """INSERT INTO test_sessions
                       (test_id, start_time, end_time, passed, consecutive_successes, total_errors)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        report.test_id,
                        report.start_time,
                        report.end_time,
                        1 if report.passed else 0,
                        report.consecutive_successes,
                        report.total_errors,
                    ),
                )
                self._conn.commit()

    def get_events(self, limit: int = 100) -> List[Dict]:
        """최근 이벤트 조회"""
        with self._lock:
            if not self._conn:
                return []
            cursor = self._conn.execute(
                "SELECT * FROM test_events ORDER BY id DESC LIMIT ?", (limit,)
            )
            return [dict(zip([d[0] for d in cursor.description], row)) for row in cursor.fetchall()]

    def close(self) -> None:
        """연결 종료"""
        if self._conn:
            self._conn.close()


# ============================================================================
# 메인 클래스: SystemIntegrationTest
# ============================================================================

class SystemIntegrationTest:
    """
    지훈 로봇 V8.5 — 시스템 전체 통합 테스트

    모든 서브시스템 동시 실행, 1시간 연속 동작 검증
    - 음성→이동→탐지→파지→복귀 전체 시나리오
    - 10회 연속 성공 기준
    - SQLite 이벤트 로깅
    - 오류 시 자동 복구
    """

    def __init__(self, db_path: str = TEST_LOG_DB):
        self._log_db = TestLogDB(db_path)
        self._test_id = f"test_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self._running = False
        self._current_phase = TestPhase.SETUP
        self._consecutive_successes = 0
        self._total_errors = 0
        self._total_recoveries = 0

        # 서브시스템 상태
        self._subsystem_health: Dict[Subsystem, SubsystemHealth] = {
            s: SubsystemHealth(subsystem=s) for s in Subsystem
        }

        # 성능 측정
        self._voice_to_action_times: List[float] = []
        self._grasp_results: List[bool] = []

        # 테스트 시작 시간
        self._test_start_time = 0.0

        # 콜백 — 실제 하드웨어 제어 함수
        self._voice_cmd_fn: Optional[Callable] = None
        self._nav_fn: Optional[Callable] = None
        self._detect_fn: Optional[Callable] = None
        self._grasp_fn: Optional[Callable] = None
        self._return_fn: Optional[Callable] = None
        self._estop_fn: Optional[Callable] = None

        logger.info("SystemIntegrationTest 인스턴스 생성 (id=%s)", self._test_id)

    # --- 콜백 등록 ---

    def register_voice_handler(self, fn: Callable) -> None:
        self._voice_cmd_fn = fn

    def register_navigation_handler(self, fn: Callable) -> None:
        self._nav_fn = fn

    def register_detection_handler(self, fn: Callable) -> None:
        self._detect_fn = fn

    def register_grasp_handler(self, fn: Callable) -> None:
        self._grasp_fn = fn

    def register_return_handler(self, fn: Callable) -> None:
        self._return_fn = fn

    def register_estop_handler(self, fn: Callable) -> None:
        self._estop_fn = fn

    # --- 개별 테스트 ---

    def test_voice(self, command: str = "앞으로 1미터 가") -> TestEvent:
        """
        음성 명령 테스트

        Args:
            command: 테스트할 음성 명령

        Returns:
            테스트 이벤트
        """
        self._current_phase = TestPhase.VOICE
        start = time.time()
        logger.info("음성 테스트 시작: '%s'", command)

        try:
            if self._voice_cmd_fn:
                result = self._voice_cmd_fn(command)
                duration_ms = (time.time() - start) * 1000
                success = result is not None and duration_ms < TARGET_VOICE_TO_ACTION_MS
                self._voice_to_action_times.append(duration_ms)
            else:
                # 시뮬레이션
                duration_ms = 1500.0  # 시뮬레이션 응답 시간
                success = duration_ms < TARGET_VOICE_TO_ACTION_MS
                self._voice_to_action_times.append(duration_ms)

            event = TestEvent(
                event_type="voice_test",
                phase=TestPhase.VOICE,
                subsystem=Subsystem.AUDIO,
                result=TestResult.PASS if success else TestResult.FAIL,
                message=f"음성 명령: '{command}'",
                duration_ms=duration_ms,
                details={"command": command, "success": success},
            )

            if not success:
                self._total_errors += 1
                self._consecutive_successes = 0
            else:
                self._consecutive_successes += 1

        except Exception as e:
            duration_ms = (time.time() - start) * 1000
            event = TestEvent(
                event_type="voice_test",
                phase=TestPhase.VOICE,
                subsystem=Subsystem.AUDIO,
                result=TestResult.ERROR,
                message=str(e),
                duration_ms=duration_ms,
            )
            self._total_errors += 1
            self._consecutive_successes = 0

        self._log_db.log_event(event)
        logger.info("음성 테스트 결과: %s (%.0fms)", event.result.value, event.duration_ms)
        return event

    def test_navigation(self, target_x: float = 1.0, target_y: float = 0.0) -> TestEvent:
        """이동 테스트"""
        self._current_phase = TestPhase.NAVIGATION
        start = time.time()
        logger.info("이동 테스트: (%.1f, %.1f)", target_x, target_y)

        try:
            if self._nav_fn:
                success = self._nav_fn(target_x, target_y)
            else:
                success = True  # 시뮬레이션

            duration_ms = (time.time() - start) * 1000
            event = TestEvent(
                event_type="navigation_test",
                phase=TestPhase.NAVIGATION,
                subsystem=Subsystem.MOTOR,
                result=TestResult.PASS if success else TestResult.FAIL,
                message=f"이동 목표: ({target_x}, {target_y})",
                duration_ms=duration_ms,
            )

            if not success:
                self._total_errors += 1
                self._consecutive_successes = 0
                self._auto_recover(Subsystem.MOTOR)
            else:
                self._consecutive_successes += 1

        except Exception as e:
            duration_ms = (time.time() - start) * 1000
            event = TestEvent(
                event_type="navigation_test",
                phase=TestPhase.NAVIGATION,
                subsystem=Subsystem.MOTOR,
                result=TestResult.ERROR,
                message=str(e),
                duration_ms=duration_ms,
            )
            self._total_errors += 1
            self._consecutive_successes = 0
            self._auto_recover(Subsystem.MOTOR)

        self._log_db.log_event(event)
        return event

    def test_grasp(self, target_object: str = "컵") -> TestEvent:
        """파지 테스트"""
        self._current_phase = TestPhase.GRASP
        start = time.time()
        logger.info("파지 테스트: '%s'", target_object)

        try:
            # 탐지 단계
            if self._detect_fn:
                detected = self._detect_fn(target_object)
            else:
                detected = True  # 시뮬레이션

            if not detected:
                event = TestEvent(
                    event_type="grasp_test",
                    phase=TestPhase.DETECTION,
                    subsystem=Subsystem.SENSOR,
                    result=TestResult.FAIL,
                    message=f"물체 탐지 실패: '{target_object}'",
                    duration_ms=(time.time() - start) * 1000,
                )
                self._total_errors += 1
                self._log_db.log_event(event)
                return event

            # 파지 단계
            if self._grasp_fn:
                success = self._grasp_fn(target_object)
            else:
                success = True  # 시뮬레이션

            duration_ms = (time.time() - start) * 1000
            self._grasp_results.append(success)

            event = TestEvent(
                event_type="grasp_test",
                phase=TestPhase.GRASP,
                subsystem=Subsystem.MOTOR,
                result=TestResult.PASS if success else TestResult.FAIL,
                message=f"파지 {'성공' if success else '실패'}: '{target_object}'",
                duration_ms=duration_ms,
            )

            if not success:
                self._total_errors += 1
                self._consecutive_successes = 0
            else:
                self._consecutive_successes += 1

        except Exception as e:
            duration_ms = (time.time() - start) * 1000
            event = TestEvent(
                event_type="grasp_test",
                phase=TestPhase.GRASP,
                subsystem=Subsystem.MOTOR,
                result=TestResult.ERROR,
                message=str(e),
                duration_ms=duration_ms,
            )
            self._total_errors += 1
            self._consecutive_successes = 0

        self._log_db.log_event(event)
        return event

    def test_safety(self) -> TestEvent:
        """안전 시스템 테스트"""
        self._current_phase = TestPhase.SAFETY
        start = time.time()
        logger.info("안전 시스템 테스트")

        try:
            # E-Stop 테스트
            if self._estop_fn:
                estop_ok = self._estop_fn()
            else:
                estop_ok = True

            duration_ms = (time.time() - start) * 1000
            event = TestEvent(
                event_type="safety_test",
                phase=TestPhase.SAFETY,
                subsystem=Subsystem.SAFETY,
                result=TestResult.PASS if estop_ok else TestResult.FAIL,
                message=f"E-Stop {'정상' if estop_ok else '비정상'}",
                duration_ms=duration_ms,
            )

            if not estop_ok:
                self._total_errors += 1
            else:
                self._consecutive_successes += 1

        except Exception as e:
            duration_ms = (time.time() - start) * 1000
            event = TestEvent(
                event_type="safety_test",
                phase=TestPhase.SAFETY,
                subsystem=Subsystem.SAFETY,
                result=TestResult.ERROR,
                message=str(e),
                duration_ms=duration_ms,
            )
            self._total_errors += 1

        self._log_db.log_event(event)
        return event

    # --- 전체 시나리오 테스트 ---

    def run_full_test(self, duration_s: float = FULL_TEST_DURATION_S) -> TestReport:
        """
        전체 통합 테스트 실행

        Args:
            duration_s: 테스트 지속 시간 (초), 기본 1시간

        Returns:
            테스트 보고서
        """
        self._test_start_time = time.time()
        self._running = True
        self._consecutive_successes = 0
        self._total_errors = 0
        self._total_recoveries = 0
        self._voice_to_action_times = []
        self._grasp_results = []

        report = TestReport(
            test_id=self._test_id,
            start_time=self._test_start_time,
        )

        logger.info("=== 전체 통합 테스트 시작 (id=%s, %d초) ===", self._test_id, duration_s)

        # 서브시스템 상태 초기화
        for subsystem in Subsystem:
            self._check_subsystem_health(subsystem)

        # 메인 테스트 루프
        scenario_count = 0
        while self._running:
            elapsed = time.time() - self._test_start_time
            if elapsed >= duration_s:
                break

            # 오류 한계 초과 시 중단
            if self._total_errors >= MAX_ERRORS_BEFORE_ABORT:
                logger.error("최대 오류 수 초과 (%d) — 테스트 중단", self._total_errors)
                break

            # 전체 시나리오: 음성→이동→탐지→파지→복귀
            scenario_count += 1
            logger.info("--- 시나리오 #%d ---", scenario_count)

            # 1. 음성 명령
            voice_event = self.test_voice("빨간 컵 가져와")
            if voice_event.result != TestResult.PASS:
                self._auto_recover(Subsystem.AUDIO)
                continue

            # 2. 이동
            nav_event = self.test_navigation(1.5, 0.5)
            if nav_event.result != TestResult.PASS:
                self._auto_recover(Subsystem.MOTOR)
                continue

            # 3. 파지
            grasp_event = self.test_grasp("빨간 컵")
            if grasp_event.result != TestResult.PASS:
                self._auto_recover(Subsystem.MOTOR)
                continue

            # 4. 복귀
            self._current_phase = TestPhase.RETURN
            if self._return_fn:
                self._return_fn()
            else:
                pass  # 시뮬레이션

            # 5. 안전 확인
            self.test_safety()

            # 서브시스템 상태 점검
            for subsystem in Subsystem:
                self._check_subsystem_health(subsystem)

            logger.info("시나리오 #%d 완료 (연속 성공: %d)", scenario_count, self._consecutive_successes)

            # 10회 연속 성공 확인
            if self._consecutive_successes >= CONSECUTIVE_SUCCESS_TARGET:
                logger.info("★ %d회 연속 성공 달성!", CONSECUTIVE_SUCCESS_TARGET)

        # 테스트 종료
        self._running = False
        self._current_phase = TestPhase.TEARDOWN

        # 보고서 작성
        report.end_time = time.time()
        report.total_duration_s = report.end_time - report.start_time
        report.consecutive_successes = self._consecutive_successes
        report.total_errors = self._total_errors
        report.total_recoveries = self._total_recoveries
        report.passed = (
            self._consecutive_successes >= CONSECUTIVE_SUCCESS_TARGET
            and self._total_errors < MAX_ERRORS_BEFORE_ABORT
        )

        # 성능 메트릭
        report.performance_metrics = {
            "voice_to_action_avg_ms": (
                sum(self._voice_to_action_times) / len(self._voice_to_action_times)
                if self._voice_to_action_times else 0
            ),
            "grasp_success_rate": (
                sum(self._grasp_results) / len(self._grasp_results)
                if self._grasp_results else 0
            ),
            "scenario_count": scenario_count,
            "uptime_hours": report.total_duration_s / 3600.0,
        }

        # 서브시스템 상태
        report.subsystem_health = {
            s.value: {"healthy": h.is_healthy, "errors": h.error_count}
            for s, h in self._subsystem_health.items()
        }

        self._log_db.log_session(report)
        logger.info("=== 테스트 완료: %s (%.1f초) ===",
                     "PASS" if report.passed else "FAIL", report.total_duration_s)
        return report

    # --- 자동 복구 ---

    def _auto_recover(self, subsystem: Subsystem) -> bool:
        """서브시스템 자동 복구"""
        logger.warning("자동 복구 시도: %s", subsystem.value)
        start = time.time()

        try:
            # 서브시스템별 복구 로직
            if subsystem == Subsystem.MOTOR:
                # 모터 재초기화
                time.sleep(1.0)
            elif subsystem == Subsystem.AUDIO:
                # 오디오 파이프라인 재시작
                time.sleep(0.5)
            elif subsystem == Subsystem.SENSOR:
                # 센서 재연결
                time.sleep(2.0)
            elif subsystem == Subsystem.AI:
                # AI 모델 재로드
                time.sleep(5.0)

            # 복구 확인
            elapsed = time.time() - start
            if elapsed < AUTO_RECOVERY_TIMEOUT_S:
                self._total_recoveries += 1
                self._subsystem_health[subsystem].recovery_count += 1
                logger.info("자동 복구 성공: %s (%.1f초)", subsystem.value, elapsed)
                return True

        except Exception as e:
            logger.error("자동 복구 실패: %s — %s", subsystem.value, e)

        return False

    def _check_subsystem_health(self, subsystem: Subsystem) -> SubsystemHealth:
        """서브시스템 상태 확인"""
        health = self._subsystem_health[subsystem]
        health.last_check = time.time()
        # 실제 하드웨어 확인 로직 (시뮬레이션에서는 항상 정상)
        health.is_healthy = True
        return health

    # --- 상태 조회 ---

    def get_status(self) -> Dict:
        """테스트 상태 반환"""
        return {
            "test_id": self._test_id,
            "running": self._running,
            "current_phase": self._current_phase.value,
            "consecutive_successes": self._consecutive_successes,
            "total_errors": self._total_errors,
            "total_recoveries": self._total_recoveries,
            "elapsed_s": time.time() - self._test_start_time if self._test_start_time else 0,
        }


# ============================================================================
# 메인 진입점
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    tester = SystemIntegrationTest()
    print("=== 시스템 통합 테스트 ===")

    # 빠른 테스트 (60초)
    report = tester.run_full_test(duration_s=60)

    print(f"\n테스트 ID: {report.test_id}")
    print(f"결과: {'PASS' if report.passed else 'FAIL'}")
    print(f"지속: {report.total_duration_s:.1f}초")
    print(f"연속 성공: {report.consecutive_successes}")
    print(f"총 오류: {report.total_errors}")
    print(f"총 복구: {report.total_recoveries}")
    print(f"성능 메트릭: {json.dumps(report.performance_metrics, indent=2)}")

    tester._log_db.close()
