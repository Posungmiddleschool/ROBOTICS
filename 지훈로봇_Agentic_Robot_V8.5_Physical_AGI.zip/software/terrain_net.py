#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 신경망 지형 분류 모듈
Jihun Robot V8.5 — Neural Terrain Classification Module

V8.5의 휴리스틱 if-else 지형 분류를 실제 학습된 CNN으로 교체합니다.
IMU 6축 진동 데이터로부터 14종 지형을 실시간 분류합니다.

아키텍처:
    TerrainCNN: 1D CNN (Conv1d × 4 + GlobalAvgPool + FC × 3)
    입력: (batch, 6, 200) — 6축 IMU 진동 시퀀스, 500Hz에서 0.4초 윈도우
    출력: 14개 지형 클래스 확률

구성요소:
    1. TerrainCNN       — 1D CNN 지형 분류 신경망
    2. TerrainDataset   — PyTorch Dataset + 데이터 증강
    3. TerrainTrainer   — 학습 파이프라인 (AdamW + CosineAnnealing + Label Smoothing)
    4. TerrainInferenceEngine — 실시간 추론 (슬라이딩 윈도우 + EMA 스무딩)
    5. SyntheticTerrainDataGenerator — 합성 학습 데이터 생성기

14 지형: FLAT, ROUGH, SLOPE, STAIRS, WET, GRAVEL, SAND, NARROW,
         UNEVEN, CARPET, ICE, MUD, OBSTACLE, UNKNOWN

하드웨어: Dual Jetson Orin NX 16GB
작성일: 2026-05-19
버전: V8.5.4 — Physical AGI CNN 지형 분류
"""

from __future__ import annotations

import copy
import logging
import math
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple, Union

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# ─── world_model.py에서 지형 타입/예측 결과 임포트 ────────────────────────────
# Import terrain types and prediction dataclass from world_model
from world_model import TerrainType, TerrainPrediction

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.terrain_net")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 상수 / Constants ───────────────────────────────────────────────────────

NUM_TERRAIN_CLASSES: int = len(TerrainType)          # 14
IMU_CHANNELS: int = 6                                  # acc_x/y/z + gyro_x/y/z
SEQUENCE_LENGTH: int = 200                             # 500Hz × 0.4초
SAMPLING_RATE_HZ: int = 500                            # IMU 샘플링 레이트
CONFIDENCE_THRESHOLD: float = 0.6                      # 낮은 신뢰도 거부 임계값
EMA_ALPHA: float = 0.3                                 # 예측 EMA 스무딩 계수


# ─── 지형별 특성 테이블 / Per-Terrain Property Tables ────────────────────────
# world_model.py의 TerrainPredictor와 동일한 값 사용

TERRAIN_FRICTION: Dict[TerrainType, float] = {
    TerrainType.FLAT: 0.8, TerrainType.ROUGH: 0.7, TerrainType.SLOPE: 0.6,
    TerrainType.STAIRS: 0.75, TerrainType.WET: 0.3, TerrainType.GRAVEL: 0.5,
    TerrainType.SAND: 0.4, TerrainType.NARROW: 0.8, TerrainType.UNEVEN: 0.6,
    TerrainType.CARPET: 0.7, TerrainType.ICE: 0.1, TerrainType.MUD: 0.35,
    TerrainType.OBSTACLE: 0.65, TerrainType.UNKNOWN: 0.5,
}

TERRAIN_HARDNESS: Dict[TerrainType, float] = {
    TerrainType.FLAT: 0.9, TerrainType.ROUGH: 0.7, TerrainType.SLOPE: 0.8,
    TerrainType.STAIRS: 0.9, TerrainType.WET: 0.6, TerrainType.GRAVEL: 0.4,
    TerrainType.SAND: 0.2, TerrainType.NARROW: 0.8, TerrainType.UNEVEN: 0.5,
    TerrainType.CARPET: 0.5, TerrainType.ICE: 0.9, TerrainType.MUD: 0.15,
    TerrainType.OBSTACLE: 0.7, TerrainType.UNKNOWN: 0.5,
}

# TerrainType을 인덱스로 변환 / Map TerrainType enum to integer index
TERRAIN_TO_IDX: Dict[TerrainType, int] = {t: i for i, t in enumerate(TerrainType)}
IDX_TO_TERRAIN: Dict[int, TerrainType] = {i: t for i, t in enumerate(TerrainType)}


# ═══════════════════════════════════════════════════════════════════════════════
# 1. TerrainCNN — 1D CNN 지형 분류 신경망 / 1D CNN Terrain Classifier
# ═══════════════════════════════════════════════════════════════════════════════


class TerrainCNN(nn.Module):
    """
    1D CNN 지형 분류기 / 1D CNN Terrain Classifier.

    IMU 6축 진동 시퀀스를 입력받아 14개 지형 클래스로 분류합니다.
    4개 Conv1d 블록 + GlobalAvgPool + FC 분류 헤드 구조입니다.

    Architecture:
        Input: (batch, 6, 200)
        → Conv1d(6, 32, k=5, s=2) + BN + ReLU + MaxPool  → (B, 32, 49)
        → Conv1d(32, 64, k=5, s=2) + BN + ReLU + MaxPool  → (B, 64, 11)
        → Conv1d(64, 128, k=5, s=2) + BN + ReLU + MaxPool → (B, 128, 2)
        → Conv1d(128, 256, k=3, s=1) + BN + ReLU          → (B, 256, *)
        → GlobalAvgPool                                      → (B, 256)
        → FC(256, 128) + ReLU + Dropout(0.3)
        → FC(128, 14)                                        → (B, 14)

    Usage:
        model = TerrainCNN()
        logits = model(imu_batch)                # (B, 14)
        terrain = model.predict_terrain(imu_data) # TerrainType
        terrain, conf = model.predict_with_confidence(imu_data)
    """

    def __init__(self, num_classes: int = NUM_TERRAIN_CLASSES) -> None:
        super().__init__()
        self._num_classes = num_classes

        # ─── Conv 블록 1: 6 → 32 채널 / Conv Block 1 ───────────────────
        self.conv1 = nn.Conv1d(
            in_channels=IMU_CHANNELS, out_channels=32,
            kernel_size=5, stride=2, padding=2,
        )
        self.bn1 = nn.BatchNorm1d(32)
        self.pool1 = nn.MaxPool1d(kernel_size=2, stride=2)

        # ─── Conv 블록 2: 32 → 64 채널 / Conv Block 2 ──────────────────
        self.conv2 = nn.Conv1d(
            in_channels=32, out_channels=64,
            kernel_size=5, stride=2, padding=2,
        )
        self.bn2 = nn.BatchNorm1d(64)
        self.pool2 = nn.MaxPool1d(kernel_size=2, stride=2)

        # ─── Conv 블록 3: 64 → 128 채널 / Conv Block 3 ─────────────────
        self.conv3 = nn.Conv1d(
            in_channels=64, out_channels=128,
            kernel_size=5, stride=2, padding=2,
        )
        self.bn3 = nn.BatchNorm1d(128)
        self.pool3 = nn.MaxPool1d(kernel_size=2, stride=2)

        # ─── Conv 블록 4: 128 → 256 채널 / Conv Block 4 ────────────────
        self.conv4 = nn.Conv1d(
            in_channels=128, out_channels=256,
            kernel_size=3, stride=1, padding=1,
        )
        self.bn4 = nn.BatchNorm1d(256)

        # ─── Global Average Pooling / 글로벌 평균 풀링 ───────────────────
        self.global_avg_pool = nn.AdaptiveAvgPool1d(1)

        # ─── FC 분류 헤드 / Fully-connected classifier head ──────────────
        self.fc1 = nn.Linear(256, 128)
        self.dropout = nn.Dropout(p=0.3)
        self.fc2 = nn.Linear(128, num_classes)

        # 가중치 초기화 / Weight initialization (Kaiming for Conv, Xavier for FC)
        self._init_weights()

        logger.info(
            "TerrainCNN 초기화: params=%d, classes=%d",
            sum(p.numel() for p in self.parameters()),
            num_classes,
        )

    def _init_weights(self) -> None:
        """가중치 초기화 / Initialize weights with Kaiming/Xavier."""
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        순전파 / Forward pass.

        Args:
            x: IMU 진동 시퀀스 (batch, 6, 200)

        Returns:
            logits: 지형 클래스 로짓 (batch, 14)
        """
        # Conv 블록 1 / Block 1
        x = self.conv1(x)        # (B, 32, 101)
        x = self.bn1(x)
        x = F.relu(x, inplace=True)
        x = self.pool1(x)        # (B, 32, 50)

        # Conv 블록 2 / Block 2
        x = self.conv2(x)        # (B, 64, 26)
        x = self.bn2(x)
        x = F.relu(x, inplace=True)
        x = self.pool2(x)        # (B, 64, 13)

        # Conv 블록 3 / Block 3
        x = self.conv3(x)        # (B, 128, 7)
        x = self.bn3(x)
        x = F.relu(x, inplace=True)
        x = self.pool3(x)        # (B, 128, 3)

        # Conv 블록 4 / Block 4
        x = self.conv4(x)        # (B, 256, 3)
        x = self.bn4(x)
        x = F.relu(x, inplace=True)

        # Global Average Pooling / 글로벌 평균 풀링
        x = self.global_avg_pool(x)  # (B, 256, 1)
        x = x.squeeze(-1)            # (B, 256)

        # FC 분류 헤드 / Classifier head
        x = self.fc1(x)          # (B, 128)
        x = F.relu(x, inplace=True)
        x = self.dropout(x)      # Dropout 0.3
        x = self.fc2(x)          # (B, 14)

        return x

    def predict_terrain(self, imu_data: np.ndarray) -> TerrainType:
        """
        IMU 데이터로 지형 분류 / Classify terrain from IMU data.

        Args:
            imu_data: IMU 진동 데이터, shape (6, 200) 또는 (200, 6)

        Returns:
            예측된 지형 유형
        """
        probs = self._get_probabilities(imu_data)
        pred_idx = int(torch.argmax(probs, dim=-1).item())
        return IDX_TO_TERRAIN[pred_idx]

    def predict_with_confidence(
        self, imu_data: np.ndarray
    ) -> Tuple[TerrainType, float]:
        """
        지형 분류 + 신뢰도 / Classify terrain with confidence score.

        Args:
            imu_data: IMU 진동 데이터, shape (6, 200) 또는 (200, 6)

        Returns:
            (예측 지형, 신뢰도 0~1) 튜플
        """
        probs = self._get_probabilities(imu_data)
        conf, pred_idx = torch.max(probs, dim=-1)
        return IDX_TO_TERRAIN[int(pred_idx.item())], float(conf.item())

    def predict_all_probabilities(self, imu_data: np.ndarray) -> Dict[TerrainType, float]:
        """
        모든 지형 클래스의 확률 반환 / Return probability for all terrain classes.

        Args:
            imu_data: IMU 진동 데이터, shape (6, 200) 또는 (200, 6)

        Returns:
            지형별 확률 딕셔너리
        """
        probs = self._get_probabilities(imu_data)
        return {
            IDX_TO_TERRAIN[i]: float(probs[0, i].item())
            for i in range(self._num_classes)
        }

    def _get_probabilities(self, imu_data: np.ndarray) -> torch.Tensor:
        """
        전처리 → 순전파 → softmax 확률 / Preprocess → forward → softmax probabilities.

        Args:
            imu_data: (6, 200) 또는 (200, 6) numpy 배열

        Returns:
            확률 텐서 (1, 14)
        """
        self.eval()
        with torch.no_grad():
            x = np.asarray(imu_data, dtype=np.float32)
            if x.ndim == 2:
                # (seq_len, channels) → (channels, seq_len) 변환
                if x.shape[0] != IMU_CHANNELS and x.shape[1] == IMU_CHANNELS:
                    x = x.T
                # 배치 차원 추가 / Add batch dimension
                x = x[np.newaxis, :, :]
            elif x.ndim == 3:
                pass  # 이미 (batch, channels, seq_len)
            else:
                raise ValueError(
                    f"IMU 데이터 shape 오류: {x.shape}, "
                    f"예상: (6, 200), (200, 6), 또는 (B, 6, 200)"
                )
            tensor = torch.from_numpy(x).to(next(self.parameters()).device)
            logits = self.forward(tensor)
            probs = F.softmax(logits, dim=-1)
        return probs


# ═══════════════════════════════════════════════════════════════════════════════
# 2. TerrainDataset — PyTorch 데이터셋 + 데이터 증강
#    TerrainDataset — PyTorch Dataset with Data Augmentation
# ═══════════════════════════════════════════════════════════════════════════════


class TerrainDataset(Dataset):
    """
    지형 IMU 데이터셋 / Terrain IMU Dataset with augmentation.

    (imu_sequence, terrain_label) 쌍을 저장하고,
    학습 시 가우시안 노이즈, 시간 이동, 진폭 스케일링 증강을 적용합니다.

    Args:
        imu_sequences: IMU 시퀀스 배열 (N, 6, 200)
        terrain_labels: 지형 라벨 배열 (N,), TerrainType 열거형
        augment: 데이터 증강 활성화 여부

    Usage:
        dataset = TerrainDataset(sequences, labels, augment=True)
        imu, label = dataset[0]
    """

    def __init__(
        self,
        imu_sequences: np.ndarray,
        terrain_labels: np.ndarray,
        augment: bool = True,
    ) -> None:
        super().__init__()
        self._sequences = np.asarray(imu_sequences, dtype=np.float32)
        self._labels = np.asarray(terrain_labels)
        self._augment = augment

        # 라벨을 정수 인덱스로 변환 / Convert TerrainType labels to integer indices
        self._label_indices = np.array(
            [TERRAIN_TO_IDX[t] if isinstance(t, TerrainType) else int(t)
             for t in self._labels],
            dtype=np.int64,
        )

        # 증강 파라미터 / Augmentation parameters
        self._noise_std = 0.02          # 가우시안 노이즈 표준편차
        self._time_shift_max = 10       # 최대 시간 이동 (샘플)
        self._amplitude_range = (0.8, 1.2)  # 진폭 스케일링 범위

        # 통계 / Statistics
        self._n_classes = NUM_TERRAIN_CLASSES
        self._class_counts = self._compute_class_counts()

        logger.info(
            "TerrainDataset 초기화: samples=%d, augment=%s, classes=%s",
            len(self._sequences), augment, dict(self._class_counts),
        )

    def __len__(self) -> int:
        return len(self._sequences)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        증강된 샘플 반환 / Return augmented sample.

        Returns:
            (imu_tensor, label_tensor): (6, 200) IMU 시퀀스와 정수 라벨
        """
        sequence = self._sequences[idx].copy()  # (6, 200)
        label = self._label_indices[idx]

        if self._augment:
            sequence = self._apply_augmentation(sequence)

        return (
            torch.from_numpy(sequence).float(),
            torch.tensor(label, dtype=torch.long),
        )

    def _apply_augmentation(self, sequence: np.ndarray) -> np.ndarray:
        """
        데이터 증강 적용 / Apply data augmentation.

        세 가지 증강 기법을 독립적으로 적용합니다:
        1. 가우시안 노이즈: 센서 잡음 시뮬레이션
        2. 시간 이동: 이벤트 타이밍 변동 시뮬레이션
        3. 진폭 스케일링: 센서 감도 변동 시뮬레이션
        """
        # 1. 가우시안 노이즈 / Gaussian noise
        noise = np.random.normal(0, self._noise_std, sequence.shape).astype(np.float32)
        sequence = sequence + noise

        # 2. 시간 이동 / Time shift
        shift = np.random.randint(-self._time_shift_max, self._time_shift_max + 1)
        if shift != 0:
            sequence = np.roll(sequence, shift, axis=1)
            # 이동으로 생긴 빈 공간 제로 패딩 / Zero-fill wrapped region
            if shift > 0:
                sequence[:, :shift] = 0.0
            else:
                sequence[:, shift:] = 0.0

        # 3. 진폭 스케일링 / Amplitude scaling
        scale = np.random.uniform(*self._amplitude_range)
        sequence = sequence * scale

        return sequence.astype(np.float32)

    def _compute_class_counts(self) -> Dict[int, int]:
        """클래스별 샘플 수 계산 / Count samples per class."""
        counts: Dict[int, int] = {}
        for label_idx in self._label_indices:
            counts[int(label_idx)] = counts.get(int(label_idx), 0) + 1
        return counts

    def get_class_weights(self) -> torch.Tensor:
        """
        클래스 불균형 가중치 계산 / Compute class weights for imbalanced data.

        역 빈도 가중치: w_i = N / (C * n_i)
        여기서 N = 전체 샘플 수, C = 클래스 수, n_i = 클래스 i 샘플 수

        Returns:
            가중치 텐서 (NUM_TERRAIN_CLASSES,)
        """
        total = len(self._label_indices)
        weights = np.ones(self._n_classes, dtype=np.float32)
        for cls_idx in range(self._n_classes):
            n_cls = self._class_counts.get(cls_idx, 1)
            weights[cls_idx] = total / (self._n_classes * n_cls)
        return torch.from_numpy(weights)

    def get_sequence(self, idx: int) -> np.ndarray:
        """원본 시퀀스 반환 (증강 없음) / Return raw sequence without augmentation."""
        return self._sequences[idx].copy()

    def get_label(self, idx: int) -> TerrainType:
        """인덱스로 지형 라벨 반환 / Return terrain label by index."""
        return IDX_TO_TERRAIN[int(self._label_indices[idx])]


# ═══════════════════════════════════════════════════════════════════════════════
# 3. TerrainTrainer — 학습 파이프라인 / Training Pipeline
# ═══════════════════════════════════════════════════════════════════════════════


class TerrainTrainer:
    """
    TerrainCNN 학습 파이프라인 / TerrainCNN training pipeline.

    AdamW 옵티마이저, CosineAnnealingLR 스케줄러,
    Label Smoothing(0.1) 크로스 엔트로피 손실, 얼리 스톱핑을 사용합니다.

    Args:
        model: TerrainCNN 인스턴스
        lr: 학습률 (기본 1e-3)
        device: 학습 디바이스 ('cuda' 또는 'cpu')
        checkpoint_dir: 체크포인트 저장 디렉토리

    Usage:
        trainer = TerrainTrainer(model, lr=1e-3, device='cuda')
        best_acc = trainer.train(train_loader, val_loader, epochs=50, early_stop=10)
    """

    def __init__(
        self,
        model: TerrainCNN,
        lr: float = 1e-3,
        device: str = "cuda",
        checkpoint_dir: str = "checkpoints",
    ) -> None:
        self._device = torch.device(device if torch.cuda.is_available() else "cpu")
        self._model = model.to(self._device)
        self._lr = lr
        self._checkpoint_dir = Path(checkpoint_dir)
        self._checkpoint_dir.mkdir(parents=True, exist_ok=True)

        # 옵티마이저: AdamW (가중치 감쇠 분리) / AdamW optimizer
        self._optimizer = torch.optim.AdamW(
            self._model.parameters(),
            lr=lr,
            weight_decay=1e-4,
            betas=(0.9, 0.999),
        )

        # 손실 함수: Label Smoothing CE / Label smoothing cross-entropy
        self._criterion = nn.CrossEntropyLoss(label_smoothing=0.1)

        # 학습 상태 / Training state
        self._epoch = 0
        self._best_val_acc: float = 0.0
        self._best_model_state: Optional[Dict[str, Any]] = None
        self._train_losses: List[float] = []
        self._val_accs: List[float] = []
        self._scheduler: Optional[Any] = None

        logger.info(
            "TerrainTrainer 초기화: device=%s, lr=%.1e, checkpoint_dir=%s",
            self._device, lr, self._checkpoint_dir,
        )

    def train_epoch(self, dataloader: DataLoader) -> float:
        """
        1 에포크 학습 / Train for one epoch.

        Args:
            dataloader: 학습 데이터 로더

        Returns:
            평균 학습 손실
        """
        self._model.train()
        total_loss: float = 0.0
        n_batches: int = 0
        correct: int = 0
        total: int = 0

        for batch_idx, (sequences, labels) in enumerate(dataloader):
            # 데이터를 디바이스로 이동 / Move data to device
            sequences = sequences.to(self._device)   # (B, 6, 200)
            labels = labels.to(self._device)          # (B,)

            # 순전파 / Forward pass
            logits = self._model(sequences)            # (B, 14)
            loss = self._criterion(logits, labels)

            # 역전파 / Backward pass
            self._optimizer.zero_grad()
            loss.backward()

            # 그래디언트 클리핑 / Gradient clipping (폭주 방지)
            torch.nn.utils.clip_grad_norm_(self._model.parameters(), max_norm=1.0)

            self._optimizer.step()

            # 통계 기록 / Record statistics
            total_loss += loss.item()
            n_batches += 1
            preds = torch.argmax(logits, dim=-1)
            correct += int((preds == labels).sum().item())
            total += labels.size(0)

        avg_loss = total_loss / max(1, n_batches)
        accuracy = correct / max(1, total)

        logger.info(
            "에포크 %d 학습 완료: loss=%.4f, acc=%.4f",
            self._epoch, avg_loss, accuracy,
        )
        return avg_loss

    def evaluate(self, dataloader: DataLoader) -> Tuple[float, Dict[str, float]]:
        """
        검증 평가 / Evaluate on validation set.

        Args:
            dataloader: 검증 데이터 로더

        Returns:
            (정확도, 클래스별 F1 스코어 딕셔너리)
        """
        self._model.eval()
        correct: int = 0
        total: int = 0
        all_preds: List[int] = []
        all_labels: List[int] = []

        with torch.no_grad():
            for sequences, labels in dataloader:
                sequences = sequences.to(self._device)
                labels = labels.to(self._device)

                logits = self._model(sequences)
                preds = torch.argmax(logits, dim=-1)

                correct += int((preds == labels).sum().item())
                total += labels.size(0)

                all_preds.extend(preds.cpu().numpy().tolist())
                all_labels.extend(labels.cpu().numpy().tolist())

        accuracy = correct / max(1, total)

        # 클래스별 F1 스코어 계산 / Compute per-class F1 scores
        per_class_f1 = self._compute_per_class_f1(all_labels, all_preds)

        logger.info(
            "검증 결과: acc=%.4f, macro_f1=%.4f",
            accuracy, np.mean(list(per_class_f1.values())),
        )
        return accuracy, per_class_f1

    def _compute_per_class_f1(
        self, labels: List[int], preds: List[int]
    ) -> Dict[str, float]:
        """
        클래스별 F1 스코어 계산 / Compute per-class F1 scores.

        TP, FP, FN을 직접 계산하여 F1 = 2*P*R/(P+R)을 구합니다.
        sklearn 없이 독립 구현하여 임베디드 환경에서도 동작합니다.
        """
        f1_scores: Dict[str, float] = {}

        for cls_idx in range(NUM_TERRAIN_CLASSES):
            tp = sum(1 for l, p in zip(labels, preds) if l == cls_idx and p == cls_idx)
            fp = sum(1 for l, p in zip(labels, preds) if l != cls_idx and p == cls_idx)
            fn = sum(1 for l, p in zip(labels, preds) if l == cls_idx and p != cls_idx)

            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1 = 2.0 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

            terrain_name = IDX_TO_TERRAIN[cls_idx].value
            f1_scores[terrain_name] = round(f1, 4)

        return f1_scores

    def train(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
        epochs: int = 50,
        early_stop: int = 10,
    ) -> float:
        """
        전체 학습 루프 / Full training loop with early stopping.

        Args:
            train_loader: 학습 데이터 로더
            val_loader: 검증 데이터 로더
            epochs: 최대 에포크 수
            early_stop: 개선 없을 시 조기 종료 에포크 수

        Returns:
            최고 검증 정확도
        """
        # CosineAnnealingLR 스케줄러 초기화 / Initialize cosine annealing scheduler
        self._scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self._optimizer, T_max=epochs, eta_min=1e-6,
        )

        patience_counter: int = 0

        logger.info(
            "학습 시작: epochs=%d, early_stop=%d, device=%s",
            epochs, early_stop, self._device,
        )

        for epoch in range(epochs):
            self._epoch = epoch

            # 학습 / Train
            train_loss = self.train_epoch(train_loader)
            self._train_losses.append(train_loss)

            # 검증 / Validate
            val_acc, per_class_f1 = self.evaluate(val_loader)
            self._val_accs.append(val_acc)

            # 학습률 스케줄링 / Learning rate scheduling
            self._scheduler.step()
            current_lr = self._optimizer.param_groups[0]["lr"]

            logger.info(
                "에포크 %d/%d: loss=%.4f, val_acc=%.4f, lr=%.2e",
                epoch + 1, epochs, train_loss, val_acc, current_lr,
            )

            # 베스트 모델 체크포인트 저장 / Save best model checkpoint
            if val_acc > self._best_val_acc:
                self._best_val_acc = val_acc
                patience_counter = 0
                self._save_checkpoint(epoch, val_acc, per_class_f1)
                self._best_model_state = copy.deepcopy(self._model.state_dict())
                logger.info(
                    "★ 새 베스트 모델: val_acc=%.4f (epoch %d)", val_acc, epoch + 1
                )
            else:
                patience_counter += 1
                logger.info(
                    "개선 없음: %d/%d (best=%.4f)",
                    patience_counter, early_stop, self._best_val_acc,
                )

            # 얼리 스톱 / Early stopping
            if patience_counter >= early_stop:
                logger.info(
                    "얼리 스톱: %d 에포크 동안 개선 없음, 학습 종료", early_stop
                )
                break

        # 베스트 모델 복원 / Restore best model
        if self._best_model_state is not None:
            self._model.load_state_dict(self._best_model_state)
            logger.info("베스트 모델 복원 완료: val_acc=%.4f", self._best_val_acc)

        return self._best_val_acc

    def _save_checkpoint(
        self, epoch: int, val_acc: float, per_class_f1: Dict[str, float]
    ) -> None:
        """모델 체크포인트 저장 / Save model checkpoint."""
        checkpoint_path = self._checkpoint_dir / "terrain_cnn_best.pt"
        checkpoint = {
            "epoch": epoch,
            "model_state_dict": self._model.state_dict(),
            "optimizer_state_dict": self._optimizer.state_dict(),
            "val_acc": val_acc,
            "per_class_f1": per_class_f1,
            "train_losses": self._train_losses,
            "val_accs": self._val_accs,
        }
        # 스케줄러 상태도 저장 / Save scheduler state if available
        if self._scheduler is not None:
            checkpoint["scheduler_state_dict"] = self._scheduler.state_dict()

        torch.save(checkpoint, checkpoint_path)
        logger.info("체크포인트 저장: %s (val_acc=%.4f)", checkpoint_path, val_acc)

    def load_checkpoint(self, path: Optional[str] = None) -> float:
        """
        체크포인트 로드 / Load model checkpoint.

        Args:
            path: 체크포인트 경로 (None이면 기본 경로 사용)

        Returns:
            저장된 검증 정확도
        """
        checkpoint_path = Path(path) if path else self._checkpoint_dir / "terrain_cnn_best.pt"
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"체크포인트 없음: {checkpoint_path}")

        checkpoint = torch.load(checkpoint_path, map_location=self._device)
        self._model.load_state_dict(checkpoint["model_state_dict"])
        self._best_val_acc = checkpoint.get("val_acc", 0.0)
        logger.info("체크포인트 로드: %s (val_acc=%.4f)", checkpoint_path, self._best_val_acc)
        return self._best_val_acc

    def get_training_history(self) -> Dict[str, List[float]]:
        """학습 기록 반환 / Return training history."""
        return {
            "train_losses": self._train_losses,
            "val_accuracies": self._val_accs,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# 4. TerrainInferenceEngine — 실시간 추론 엔진 / Real-time Inference Engine
# ═══════════════════════════════════════════════════════════════════════════════


class TerrainInferenceEngine:
    """
    실시간 지형 분류 추론 엔진 / Real-time terrain classification inference engine.

    슬라이딩 윈도우 버퍼로 IMU 데이터를 관리하고,
    EMA 스무딩으로 예측을 안정화하며,
    신뢰도 임계값으로 낮은 신뢰도 예측을 거부합니다.

    Args:
        model_path: 학습된 모델 체크포인트 경로
        device: 추론 디바이스 ('cuda' 또는 'cpu')
        confidence_threshold: 예측 수락 최소 신뢰도
        ema_alpha: EMA 스무딩 계수 (0~1, 높을수록 최신 예측 반영)

    Usage:
        engine = TerrainInferenceEngine("checkpoints/terrain_cnn_best.pt", device='cuda')
        prediction = engine.classify_realtime(imu_buffer)
        if prediction.confidence > 0.7:
            print(f"지형: {prediction.terrain_type}")
    """

    def __init__(
        self,
        model_path: str,
        device: str = "cuda",
        confidence_threshold: float = CONFIDENCE_THRESHOLD,
        ema_alpha: float = EMA_ALPHA,
    ) -> None:
        self._device = torch.device(device if torch.cuda.is_available() else "cpu")
        self._confidence_threshold = confidence_threshold
        self._ema_alpha = ema_alpha

        # 모델 로드 / Load model
        self._model = TerrainCNN().to(self._device)
        self._load_model(model_path)

        # 슬라이딩 윈도우 버퍼 / Sliding window buffer
        # (6, SEQUENCE_LENGTH) 순환 버퍼
        self._imu_buffer = np.zeros((IMU_CHANNELS, SEQUENCE_LENGTH), dtype=np.float32)
        self._buffer_idx: int = 0
        self._buffer_full: bool = False
        self._buffer_lock = threading.Lock()

        # EMA 스무딩 상태 / EMA smoothing state
        self._ema_probs: Optional[np.ndarray] = None  # (14,) 확률 벡터
        self._last_prediction: TerrainPrediction = TerrainPrediction()
        self._prediction_lock = threading.Lock()

        # 통계 / Statistics
        self._n_inferences: int = 0
        self._n_rejected: int = 0
        self._inference_times: Deque[float] = deque(maxlen=100)

        logger.info(
            "TerrainInferenceEngine 초기화: model=%s, device=%s, "
            "conf_thresh=%.2f, ema_alpha=%.2f",
            model_path, self._device, confidence_threshold, ema_alpha,
        )

    def _load_model(self, model_path: str) -> None:
        """모델 체크포인트 로드 / Load model checkpoint."""
        path = Path(model_path)
        if not path.exists():
            logger.warning(
                "모델 파일 없음: %s — 랜덤 초기화된 모델 사용 (실제 추론 전 학습 필요)",
                model_path,
            )
            return

        checkpoint = torch.load(path, map_location=self._device)
        if "model_state_dict" in checkpoint:
            self._model.load_state_dict(checkpoint["model_state_dict"])
        else:
            self._model.load_state_dict(checkpoint)

        self._model.eval()
        val_acc = checkpoint.get("val_acc", "N/A") if isinstance(checkpoint, dict) else "N/A"
        logger.info("모델 로드 완료: %s (val_acc=%s)", model_path, val_acc)

    def update_buffer(self, imu_sample: np.ndarray) -> None:
        """
        IMU 버퍼에 새 샘플 추가 / Add new IMU sample to sliding buffer.

        Args:
            imu_sample: 6축 IMU 샘플, shape (6,)
        """
        with self._buffer_lock:
            sample = np.asarray(imu_sample, dtype=np.float32).flatten()
            if len(sample) < IMU_CHANNELS:
                sample = np.pad(sample, (0, IMU_CHANNELS - len(sample)))
            sample = sample[:IMU_CHANNELS]

            self._imu_buffer[:, self._buffer_idx] = sample
            self._buffer_idx = (self._buffer_idx + 1) % SEQUENCE_LENGTH
            if self._buffer_idx == 0:
                self._buffer_full = True

    def update_buffer_batch(self, imu_batch: np.ndarray) -> None:
        """
        IMU 버퍼에 여러 샘플 일괄 추가 / Add batch of IMU samples to buffer.

        Args:
            imu_batch: IMU 샘플, shape (N, 6) 또는 (6, N)
        """
        batch = np.asarray(imu_batch, dtype=np.float32)
        if batch.ndim == 2 and batch.shape[0] == IMU_CHANNELS:
            batch = batch.T  # (6, N) → (N, 6)

        for sample in batch:
            self.update_buffer(sample)

    def classify_realtime(self, imu_buffer: Optional[np.ndarray] = None) -> TerrainPrediction:
        """
        실시간 지형 분류 / Real-time terrain classification.

        Args:
            imu_buffer: 외부 IMU 버퍼 (6, 200). None이면 내부 버퍼 사용.

        Returns:
            TerrainPrediction: 지형 예측 결과
        """
        start_time = time.perf_counter()

        # 입력 데이터 준비 / Prepare input data
        if imu_buffer is not None:
            window = np.asarray(imu_buffer, dtype=np.float32)
            if window.ndim == 2 and window.shape[1] == IMU_CHANNELS:
                window = window.T  # (200, 6) → (6, 200)
        else:
            # 내부 슬라이딩 윈도우에서 최신 시퀀스 추출
            # Extract latest sequence from circular buffer
            with self._buffer_lock:
                if self._buffer_full:
                    # 순환 버퍼를 시간순으로 재정렬 / Reorder circular buffer chronologically
                    window = np.roll(self._imu_buffer, -self._buffer_idx, axis=1).copy()
                else:
                    # 아직 버퍼가 안 찼으면 0-패딩된 상태로 사용
                    window = self._imu_buffer.copy()

        # 버퍼가 너무 짧으면 거부 / Reject if buffer too short
        if window.shape[-1] < SEQUENCE_LENGTH // 2:
            logger.warning("버퍼 길이 부족: %d < %d", window.shape[-1], SEQUENCE_LENGTH // 2)
            return TerrainPrediction(
                terrain_type=TerrainType.UNKNOWN,
                confidence=0.0,
            )

        # 시퀀스 길이 맞추기 / Pad or truncate to SEQUENCE_LENGTH
        if window.shape[-1] > SEQUENCE_LENGTH:
            window = window[:, -SEQUENCE_LENGTH:]
        elif window.shape[-1] < SEQUENCE_LENGTH:
            pad_width = SEQUENCE_LENGTH - window.shape[-1]
            window = np.pad(window, ((0, 0), (0, pad_width)), mode="edge")

        # CNN 추론 / CNN inference
        self._model.eval()
        with torch.no_grad():
            tensor = torch.from_numpy(window[np.newaxis, :, :]).to(self._device)
            logits = self._model(tensor)
            raw_probs = F.softmax(logits, dim=-1).cpu().numpy().flatten()  # (14,)

        # EMA 스무딩 적용 / Apply EMA smoothing
        with self._prediction_lock:
            if self._ema_probs is None:
                self._ema_probs = raw_probs.copy()
            else:
                self._ema_probs = (
                    self._ema_alpha * raw_probs
                    + (1.0 - self._ema_alpha) * self._ema_probs
                )
            smoothed_probs = self._ema_probs.copy()

        # 최고 확률 클래스 / Top class
        pred_idx = int(np.argmax(smoothed_probs))
        confidence = float(smoothed_probs[pred_idx])
        terrain = IDX_TO_TERRAIN[pred_idx]

        # 신뢰도 임계값 검사 / Confidence threshold check
        if confidence < self._confidence_threshold:
            self._n_rejected += 1
            terrain = TerrainType.UNKNOWN
            logger.debug(
                "낮은 신뢰도 예측 거부: %s (%.3f < %.3f)",
                IDX_TO_TERRAIN[pred_idx].value, confidence, self._confidence_threshold,
            )

        # TerrainPrediction 생성 / Build TerrainPrediction
        friction = TERRAIN_FRICTION.get(terrain, 0.5)
        hardness = TERRAIN_HARDNESS.get(terrain, 0.5)
        slip_prob = self._estimate_slip_probability(friction, smoothed_probs)

        prediction = TerrainPrediction(
            terrain_type=terrain,
            friction_coefficient=friction,
            hardness=hardness,
            elevation_ahead=0.0,
            slip_probability=slip_prob,
            confidence=confidence,
        )

        # 통계 업데이트 / Update statistics
        elapsed = time.perf_counter() - start_time
        self._inference_times.append(elapsed)
        self._n_inferences += 1
        self._last_prediction = prediction

        return prediction

    def _estimate_slip_probability(
        self, friction: float, class_probs: np.ndarray
    ) -> float:
        """
        미끄러짐 확률 추정 / Estimate slip probability.

        저마찰 지형(ICE, WET, MUD) 확률을 가중합하여 계산합니다.
        """
        low_friction_terrains = {
            TerrainType.ICE: 0.95,
            TerrainType.WET: 0.6,
            TerrainType.MUD: 0.55,
            TerrainType.SAND: 0.4,
        }
        slip_prob = 0.0
        for terrain, base_slip in low_friction_terrains.items():
            idx = TERRAIN_TO_IDX[terrain]
            slip_prob += class_probs[idx] * base_slip
        return float(np.clip(slip_prob, 0.0, 1.0))

    def get_inference_stats(self) -> Dict[str, Any]:
        """추론 통계 반환 / Return inference statistics."""
        avg_time = (
            np.mean(list(self._inference_times)) if self._inference_times else 0.0
        )
        rejection_rate = (
            self._n_rejected / max(1, self._n_inferences)
        )
        return {
            "total_inferences": self._n_inferences,
            "rejection_count": self._n_rejected,
            "rejection_rate": round(rejection_rate, 4),
            "avg_inference_time_ms": round(avg_time * 1000, 2),
            "device": str(self._device),
        }

    def reset_buffer(self) -> None:
        """내부 버퍼 초기화 / Reset internal buffer."""
        with self._buffer_lock:
            self._imu_buffer = np.zeros(
                (IMU_CHANNELS, SEQUENCE_LENGTH), dtype=np.float32
            )
            self._buffer_idx = 0
            self._buffer_full = False
        with self._prediction_lock:
            self._ema_probs = None
        logger.info("추론 버퍼 초기화 완료")


# ═══════════════════════════════════════════════════════════════════════════════
# 5. SyntheticTerrainDataGenerator — 합성 지형 데이터 생성기
#    Synthetic Terrain Data Generator
# ═══════════════════════════════════════════════════════════════════════════════


class SyntheticTerrainDataGenerator:
    """
    합성 지형 IMU 데이터 생성기 / Synthetic terrain IMU data generator.

    실제 데이터가 부족할 때 각 지형별 특징적인 IMU 진동 패턴을
    물리적 모델 기반으로 생성합니다. 각 지형은 고유한 진동 특성을 가집니다:

    - FLAT:    매우 낮은 RMS, 낮은 분산 (균일한 단단한 표면)
    - ROUGH:   중간 RMS, 높은 분산 (불규칙 표면)
    - SLOPE:   중간 RMS, 중간 분산, 지속적 가속도 (경사)
    - STAIRS:  주기적 임펄스 패턴 (계단 오르내림)
    - WET:     중간 RMS + 슬립 서명 (젖은 표면)
    - GRAVEL:  높은 RMS, 버스트 패턴 (자갈)
    - SAND:    중간 RMS, 저주파 우세 (모래)
    - NARROW:  낮은 RMS, 측면 가속도 패턴 (협로)
    - UNEVEN:  높은 RMS, 랜덤 임펄스 (울퉁불퉁)
    - CARPET:  낮은 RMS, 감쇠된 진동 (카펫)
    - ICE:     낮은 RMS + 간헐적 슬립 (얼음)
    - MUD:     중간 RMS, 저주파 + 흡수 패턴 (진흙)
    - OBSTACLE:높은 RMS, 강한 임펄스 (장애물)
    - UNKNOWN: 랜덤 패턴

    또한 현실적인 센서 잡음, 바이어스, 온도 드리프트를 추가합니다.

    Usage:
        gen = SyntheticTerrainDataGenerator(seed=42)
        X, y = gen.generate_balanced_dataset(n_samples_per_class=500)
        # X: (7000, 6, 200), y: (7000,)
    """

    # 지형별 IMU 진동 특성 파라미터 / Per-terrain IMU vibration parameters
    TERRAIN_PARAMS: Dict[TerrainType, Dict[str, Any]] = {
        TerrainType.FLAT: {
            "rms": 0.02, "variance": 0.0005, "freq_hz": 2.0,
            "burst_prob": 0.0, "slip_prob": 0.0, "impulse_prob": 0.0,
            "desc": "평지 — 매우 낮은 진동 / Flat — very low vibration",
        },
        TerrainType.ROUGH: {
            "rms": 0.25, "variance": 0.08, "freq_hz": 15.0,
            "burst_prob": 0.1, "slip_prob": 0.05, "impulse_prob": 0.1,
            "desc": "험로 — 중간 진동, 높은 분산 / Rough — medium vib, high var",
        },
        TerrainType.SLOPE: {
            "rms": 0.15, "variance": 0.03, "freq_hz": 5.0,
            "burst_prob": 0.05, "slip_prob": 0.15, "impulse_prob": 0.05,
            "slope_accel": 0.08,
            "desc": "경사 — 지속적 가속도 / Slope — sustained acceleration",
        },
        TerrainType.STAIRS: {
            "rms": 0.20, "variance": 0.06, "freq_hz": 3.0,
            "burst_prob": 0.3, "slip_prob": 0.1, "impulse_prob": 0.4,
            "impulse_period": 50,
            "desc": "계단 — 주기적 임펄스 / Stairs — periodic impulses",
        },
        TerrainType.WET: {
            "rms": 0.12, "variance": 0.02, "freq_hz": 8.0,
            "burst_prob": 0.05, "slip_prob": 0.4, "impulse_prob": 0.05,
            "desc": "젖은 표면 — 슬립 서명 / Wet — slip signatures",
        },
        TerrainType.GRAVEL: {
            "rms": 0.40, "variance": 0.15, "freq_hz": 25.0,
            "burst_prob": 0.5, "slip_prob": 0.1, "impulse_prob": 0.3,
            "desc": "자갈 — 높은 RMS, 버스트 / Gravel — high RMS, burst",
        },
        TerrainType.SAND: {
            "rms": 0.15, "variance": 0.04, "freq_hz": 4.0,
            "burst_prob": 0.05, "slip_prob": 0.2, "impulse_prob": 0.05,
            "desc": "모래 — 저주파 우세 / Sand — low-freq dominant",
        },
        TerrainType.NARROW: {
            "rms": 0.08, "variance": 0.01, "freq_hz": 6.0,
            "burst_prob": 0.1, "slip_prob": 0.05, "impulse_prob": 0.1,
            "lateral_accel": 0.1,
            "desc": "협로 — 측면 가속도 / Narrow — lateral acceleration",
        },
        TerrainType.UNEVEN: {
            "rms": 0.35, "variance": 0.12, "freq_hz": 12.0,
            "burst_prob": 0.2, "slip_prob": 0.15, "impulse_prob": 0.35,
            "desc": "울퉁불퉁 — 랜덤 임펄스 / Uneven — random impulses",
        },
        TerrainType.CARPET: {
            "rms": 0.05, "variance": 0.002, "freq_hz": 3.0,
            "burst_prob": 0.0, "slip_prob": 0.02, "impulse_prob": 0.0,
            "damping": 0.7,
            "desc": "카펫 — 감쇠된 진동 / Carpet — damped vibration",
        },
        TerrainType.ICE: {
            "rms": 0.03, "variance": 0.001, "freq_hz": 2.0,
            "burst_prob": 0.05, "slip_prob": 0.6, "impulse_prob": 0.05,
            "desc": "얼음 — 낮은 RMS, 간헐적 슬립 / Ice — low RMS, intermittent slips",
        },
        TerrainType.MUD: {
            "rms": 0.18, "variance": 0.05, "freq_hz": 3.5,
            "burst_prob": 0.1, "slip_prob": 0.3, "impulse_prob": 0.1,
            "damping": 0.5,
            "desc": "진흙 — 저주파 + 흡수 / Mud — low-freq + absorption",
        },
        TerrainType.OBSTACLE: {
            "rms": 0.45, "variance": 0.20, "freq_hz": 20.0,
            "burst_prob": 0.3, "slip_prob": 0.1, "impulse_prob": 0.5,
            "desc": "장애물 — 강한 임펄스 / Obstacle — strong impulses",
        },
        TerrainType.UNKNOWN: {
            "rms": 0.15, "variance": 0.05, "freq_hz": 8.0,
            "burst_prob": 0.15, "slip_prob": 0.15, "impulse_prob": 0.15,
            "desc": "알 수 없음 — 랜덤 / Unknown — random pattern",
        },
    }

    def __init__(self, seed: Optional[int] = None) -> None:
        self._rng = np.random.RandomState(seed)
        self._seed = seed

        # 센서 모델 파라미터 / Sensor model parameters
        self._base_noise_std = 0.01      # 기본 센서 잡음 (m/s² or rad/s)
        self._bias_range = (-0.02, 0.02) # 센서 바이어스 범위
        self._drift_rate = 0.001         # 온도 드리프트 비율

        logger.info(
            "SyntheticTerrainDataGenerator 초기화: seed=%s", seed,
        )

    def generate_terrain_pattern(
        self, terrain_type: TerrainType, n_samples: int = 1
    ) -> np.ndarray:
        """
        특정 지형의 IMU 진동 패턴 생성 / Generate IMU vibration patterns for a terrain.

        Args:
            terrain_type: 지형 유형
            n_samples: 생성할 샘플 수

        Returns:
            IMU 시퀀스 배열 (n_samples, 6, 200)
        """
        params = self.TERRAIN_PARAMS[terrain_type]
        sequences = np.zeros((n_samples, IMU_CHANNELS, SEQUENCE_LENGTH), dtype=np.float32)

        for i in range(n_samples):
            sequences[i] = self._generate_single_pattern(params)

        return sequences

    def _generate_single_pattern(self, params: Dict[str, Any]) -> np.ndarray:
        """
        단일 IMU 시퀀스 생성 / Generate a single IMU sequence.

        배치마다 다른 센서 바이어스와 잡음 시드를 적용하여
        동일 지형이라도 다양한 패턴이 생성되도록 합니다.

        Returns:
            IMU 시퀀스 (6, 200)
        """
        rms = params["rms"]
        variance = params["variance"]
        freq = params["freq_hz"]
        burst_prob = params["burst_prob"]
        slip_prob = params["slip_prob"]
        impulse_prob = params["impulse_prob"]

        t = np.linspace(0, SEQUENCE_LENGTH / SAMPLING_RATE_HZ, SEQUENCE_LENGTH)

        # ─── 가속도 3축 (acc_x, acc_y, acc_z) 생성 ─────────────────────
        # Generate 3-axis accelerometer data

        # 기본 진동: 지형 특성 주파수의 정현파 + 노이즈
        # Base vibration: sinusoidal at terrain characteristic freq + noise
        acc_x = rms * np.sin(2 * np.pi * freq * t + self._rng.uniform(0, 2 * np.pi))
        acc_y = rms * 0.7 * np.sin(2 * np.pi * freq * 1.3 * t + self._rng.uniform(0, 2 * np.pi))
        acc_z = rms * 0.5 * np.sin(2 * np.pi * freq * 0.8 * t + self._rng.uniform(0, 2 * np.pi))

        # 분산에 맞는 랜덤 노이즈 / Random noise matching variance
        acc_x += self._rng.normal(0, np.sqrt(variance), SEQUENCE_LENGTH)
        acc_y += self._rng.normal(0, np.sqrt(variance) * 0.7, SEQUENCE_LENGTH)
        acc_z += self._rng.normal(0, np.sqrt(variance) * 0.5, SEQUENCE_LENGTH)

        # ─── 버스트 패턴 / Burst patterns ────────────────────────────────
        if burst_prob > 0 and self._rng.random() < burst_prob + 0.5:
            n_bursts = self._rng.randint(1, 5)
            for _ in range(n_bursts):
                burst_start = self._rng.randint(0, SEQUENCE_LENGTH - 20)
                burst_len = self._rng.randint(5, 20)
                burst_amp = rms * self._rng.uniform(2.0, 5.0)
                acc_x[burst_start:burst_start + burst_len] += burst_amp * self._rng.randn(burst_len)
                acc_y[burst_start:burst_start + burst_len] += burst_amp * 0.6 * self._rng.randn(burst_len)

        # ─── 임펄스 패턴 / Impulse patterns ──────────────────────────────
        if impulse_prob > 0 and self._rng.random() < impulse_prob + 0.3:
            # 계단: 주기적 임펄스 / Stairs: periodic impulses
            impulse_period = params.get("impulse_period", 40)
            n_impulses = SEQUENCE_LENGTH // max(1, impulse_period)
            for k in range(n_impulses):
                if self._rng.random() < impulse_prob + 0.4:
                    idx = k * impulse_period + self._rng.randint(-5, 5)
                    idx = max(0, min(idx, SEQUENCE_LENGTH - 3))
                    impulse_amp = rms * self._rng.uniform(3.0, 8.0)
                    # 임펄스는 z축(수직)에 강하게 / Impulse strong on z-axis (vertical)
                    acc_z[idx:idx + 3] += impulse_amp * np.array([1.0, 0.5, 0.2])
                    acc_x[idx:idx + 2] += impulse_amp * 0.3 * self._rng.randn(2)

        # ─── 슬립 서명 / Slip signatures ─────────────────────────────────
        if slip_prob > 0 and self._rng.random() < slip_prob + 0.2:
            n_slips = self._rng.randint(1, 4)
            for _ in range(n_slips):
                slip_start = self._rng.randint(10, SEQUENCE_LENGTH - 30)
                slip_len = self._rng.randint(10, 30)
                # 슬립: x축(진행방향)의 급격한 변화 + z축 미세 변화
                # Slip: sudden change in x-axis (travel direction) + subtle z-axis change
                slip_amp = rms * self._rng.uniform(1.5, 4.0)
                slip_profile = slip_amp * np.sin(np.linspace(0, np.pi, slip_len))
                acc_x[slip_start:slip_start + slip_len] += slip_profile * self._rng.choice([-1, 1])
                acc_z[slip_start:slip_start + slip_len] -= rms * 0.3

        # ─── 경사 가속도 / Slope sustained acceleration ───────────────────
        slope_accel = params.get("slope_accel", 0.0)
        if slope_accel > 0:
            # 경사면: 지속적인 전방 가속도 (중력 성분)
            # Slope: sustained forward acceleration (gravity component)
            acc_x += slope_accel * self._rng.choice([-1, 1])

        # ─── 측면 가속도 (협로) / Lateral acceleration (narrow) ──────────
        lateral_accel = params.get("lateral_accel", 0.0)
        if lateral_accel > 0:
            acc_y += lateral_accel * np.sin(2 * np.pi * 1.5 * t)

        # ─── 감쇠 (카펫, 진흙) / Damping (carpet, mud) ───────────────────
        damping = params.get("damping", 0.0)
        if damping > 0:
            # 고주파 성분 감쇠: 시간에 따른 진폭 감소
            # Damped high-freq: amplitude decay over time
            decay = np.exp(-damping * t * 5)
            acc_x *= (1.0 - damping * 0.5) + damping * 0.5 * decay
            acc_y *= (1.0 - damping * 0.5) + damping * 0.5 * decay
            acc_z *= (1.0 - damping * 0.3) + damping * 0.3 * decay

        # ─── 자이로 3축 (gyro_x, gyro_y, gyro_z) 생성 ──────────────────
        # Generate 3-axis gyroscope data (회전 속도 / angular velocity)
        gyro_scale = rms * 0.5  # 자이로는 가속도보다 작은 진폭
        gyro_x = gyro_scale * np.sin(2 * np.pi * freq * 0.7 * t + self._rng.uniform(0, 2 * np.pi))
        gyro_y = gyro_scale * 0.6 * np.cos(2 * np.pi * freq * 0.9 * t + self._rng.uniform(0, 2 * np.pi))
        gyro_z = gyro_scale * 0.4 * np.sin(2 * np.pi * freq * 0.5 * t + self._rng.uniform(0, 2 * np.pi))

        # 자이로 노이즈 / Gyroscope noise
        gyro_noise_std = np.sqrt(variance) * 0.3
        gyro_x += self._rng.normal(0, gyro_noise_std, SEQUENCE_LENGTH)
        gyro_y += self._rng.normal(0, gyro_noise_std, SEQUENCE_LENGTH)
        gyro_z += self._rng.normal(0, gyro_noise_std, SEQUENCE_LENGTH)

        # ─── 센서 모델: 바이어스 + 잡음 + 온도 드리프트 ─────────────────
        # Sensor model: bias + noise + temperature drift

        # 센서 바이어스 / Sensor bias (샘플마다 다른 바이어스)
        bias_acc = self._rng.uniform(*self._bias_range, size=3)
        bias_gyro = self._rng.uniform(*self._bias_range, size=3)
        acc_x += bias_acc[0]
        acc_y += bias_acc[1]
        acc_z += bias_acc[2]
        gyro_x += bias_gyro[0]
        gyro_y += bias_gyro[1]
        gyro_z += bias_gyro[2]

        # 기본 센서 잡음 / Base sensor noise
        acc_x += self._rng.normal(0, self._base_noise_std, SEQUENCE_LENGTH)
        acc_y += self._rng.normal(0, self._base_noise_std, SEQUENCE_LENGTH)
        acc_z += self._rng.normal(0, self._base_noise_std, SEQUENCE_LENGTH)
        gyro_x += self._rng.normal(0, self._base_noise_std * 0.5, SEQUENCE_LENGTH)
        gyro_y += self._rng.normal(0, self._base_noise_std * 0.5, SEQUENCE_LENGTH)
        gyro_z += self._rng.normal(0, self._base_noise_std * 0.5, SEQUENCE_LENGTH)

        # 온도 드리프트 / Temperature drift (천천히 변하는 바이어스)
        drift = self._drift_rate * np.cumsum(self._rng.randn(SEQUENCE_LENGTH))
        acc_x += drift * self._rng.uniform(-1, 1)
        acc_y += drift * self._rng.uniform(-1, 1)

        # ─── 6축 IMU 시퀀스 조합 / Combine 6-axis IMU sequence ──────────
        imu_sequence = np.stack([
            acc_x, acc_y, acc_z,
            gyro_x, gyro_y, gyro_z,
        ], axis=0).astype(np.float32)  # (6, 200)

        return imu_sequence

    def generate_balanced_dataset(
        self,
        n_samples_per_class: int = 500,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        균형 잡힌 전체 데이터셋 생성 / Generate balanced dataset for all terrains.

        Args:
            n_samples_per_class: 클래스당 샘플 수

        Returns:
            (X, y): X=(N, 6, 200) IMU 시퀀스, y=(N,) TerrainType 라벨
        """
        all_sequences: List[np.ndarray] = []
        all_labels: List[TerrainType] = []

        for terrain in TerrainType:
            logger.info(
                "지형 %s 샘플 생성 중: %d개", terrain.value, n_samples_per_class
            )
            sequences = self.generate_terrain_pattern(terrain, n_samples_per_class)
            all_sequences.append(sequences)
            all_labels.extend([terrain] * n_samples_per_class)

        X = np.concatenate(all_sequences, axis=0)   # (N, 6, 200)
        y = np.array(all_labels, dtype=object)       # (N,)

        logger.info(
            "균형 데이터셋 생성 완료: %d 샘플, %d 클래스",
            len(X), len(TerrainType),
        )
        return X, y

    def generate_train_val_split(
        self,
        n_samples_per_class: int = 500,
        val_ratio: float = 0.2,
    ) -> Tuple[TerrainDataset, TerrainDataset]:
        """
        학습/검증 분할 데이터셋 생성 / Generate train/val split datasets.

        Args:
            n_samples_per_class: 클래스당 샘플 수
            val_ratio: 검증 비율

        Returns:
            (train_dataset, val_dataset)
        """
        X, y = self.generate_balanced_dataset(n_samples_per_class)

        # 셔플 / Shuffle
        n_total = len(X)
        indices = self._rng.permutation(n_total)
        X = X[indices]
        y = y[indices]

        # 분할 / Split
        n_val = int(n_total * val_ratio)
        X_train, y_train = X[n_val:], y[n_val:]
        X_val, y_val = X[:n_val], y[:n_val]

        train_dataset = TerrainDataset(X_train, y_train, augment=True)
        val_dataset = TerrainDataset(X_val, y_val, augment=False)

        logger.info(
            "학습/검증 분할: train=%d, val=%d", len(X_train), len(X_val),
        )
        return train_dataset, val_dataset


# ═══════════════════════════════════════════════════════════════════════════════
# 유틸리티 함수 / Utility Functions
# ═══════════════════════════════════════════════════════════════════════════════


def train_terrain_model(
    checkpoint_dir: str = "checkpoints",
    n_samples_per_class: int = 500,
    epochs: int = 50,
    batch_size: int = 64,
    lr: float = 1e-3,
    device: str = "cuda",
    seed: int = 42,
) -> TerrainCNN:
    """
    합성 데이터로 TerrainCNN 학습 / Train TerrainCNN on synthetic data.

    전체 파이프라인: 데이터 생성 → 데이터셋 구성 → 학습 → 최종 모델 반환.
    실제 로봇 배포 전 합성 데이터로 사전 학습하는 용도입니다.

    Args:
        checkpoint_dir: 체크포인트 저장 디렉토리
        n_samples_per_class: 클래스당 합성 샘플 수
        epochs: 최대 학습 에포크
        batch_size: 배치 크기
        lr: 학습률
        device: 학습 디바이스
        seed: 난수 시드

    Returns:
        학습된 TerrainCNN 모델
    """
    logger.info("=== 지형 분류 CNN 학습 시작 ===")

    # 합성 데이터 생성 / Generate synthetic data
    generator = SyntheticTerrainDataGenerator(seed=seed)
    train_dataset, val_dataset = generator.generate_train_val_split(
        n_samples_per_class=n_samples_per_class,
        val_ratio=0.2,
    )

    # 데이터 로더 구성 / Create data loaders
    train_loader = DataLoader(
        train_dataset, batch_size=batch_size, shuffle=True,
        num_workers=2, pin_memory=True, drop_last=True,
    )
    val_loader = DataLoader(
        val_dataset, batch_size=batch_size, shuffle=False,
        num_workers=2, pin_memory=True,
    )

    # 모델 + 트레이너 초기화 / Initialize model and trainer
    model = TerrainCNN()
    trainer = TerrainTrainer(model, lr=lr, device=device, checkpoint_dir=checkpoint_dir)

    # 학습 / Train
    best_acc = trainer.train(train_loader, val_loader, epochs=epochs, early_stop=10)

    logger.info("=== 학습 완료: best_val_acc=%.4f ===", best_acc)
    return model


def create_inference_engine(
    model_path: str = "checkpoints/terrain_cnn_best.pt",
    device: str = "cuda",
) -> TerrainInferenceEngine:
    """
    추론 엔진 생성 편의 함수 / Convenience function to create inference engine.

    Args:
        model_path: 모델 체크포인트 경로
        device: 추론 디바이스

    Returns:
        TerrainInferenceEngine 인스턴스
    """
    return TerrainInferenceEngine(model_path=model_path, device=device)


# ═══════════════════════════════════════════════════════════════════════════════
# 모듈 테스트 / Module Self-Test
# ═══════════════════════════════════════════════════════════════════════════════


def _self_test() -> None:
    """
    모듈 자체 테스트 / Module self-test.

    합성 데이터로 빠른 학습→추론 파이프라인을 검증합니다.
    실제 배포 전 모든 컴포넌트가 정상 동작하는지 확인합니다.
    """
    logger.info("═══ terrain_net 자체 테스트 시작 ═══")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    logger.info("디바이스: %s", device)

    # ─── 1. TerrainCNN 순전파 테스트 / Forward pass test ─────────────────
    logger.info("--- 1. TerrainCNN 순전파 테스트 ---")
    model = TerrainCNN()
    dummy_input = torch.randn(4, IMU_CHANNELS, SEQUENCE_LENGTH)
    logits = model(dummy_input)
    assert logits.shape == (4, NUM_TERRAIN_CLASSES), f"로짓 shape 오류: {logits.shape}"
    logger.info("순전파 OK: input=%s → logits=%s", tuple(dummy_input.shape), tuple(logits.shape))

    # ─── 2. predict_terrain 테스트 / predict_terrain test ─────────────────
    logger.info("--- 2. predict_terrain / predict_with_confidence 테스트 ---")
    single_imu = np.random.randn(IMU_CHANNELS, SEQUENCE_LENGTH).astype(np.float32)
    terrain = model.predict_terrain(single_imu)
    assert isinstance(terrain, TerrainType), f"반환 타입 오류: {type(terrain)}"
    terrain2, conf = model.predict_with_confidence(single_imu)
    assert 0.0 <= conf <= 1.0, f"신뢰도 범위 오류: {conf}"
    logger.info("예측 OK: terrain=%s, confidence=%.4f", terrain.value, conf)

    # ─── 3. predict_all_probabilities 테스트 ─────────────────────────────
    logger.info("--- 3. predict_all_probabilities 테스트 ---")
    probs = model.predict_all_probabilities(single_imu)
    assert len(probs) == NUM_TERRAIN_CLASSES, f"확률 수 오류: {len(probs)}"
    total_prob = sum(probs.values())
    assert abs(total_prob - 1.0) < 1e-4, f"확률 합 오류: {total_prob}"
    logger.info("확률 OK: %d 클래스, 합=%.6f", len(probs), total_prob)

    # ─── 4. TerrainDataset 테스트 / Dataset test ─────────────────────────
    logger.info("--- 4. TerrainDataset 테스트 ---")
    gen = SyntheticTerrainDataGenerator(seed=42)
    X, y = gen.generate_balanced_dataset(n_samples_per_class=20)
    assert X.shape == (20 * NUM_TERRAIN_CLASSES, IMU_CHANNELS, SEQUENCE_LENGTH)
    assert len(y) == 20 * NUM_TERRAIN_CLASSES
    dataset = TerrainDataset(X, y, augment=True)
    sample_seq, sample_label = dataset[0]
    assert sample_seq.shape == (IMU_CHANNELS, SEQUENCE_LENGTH)
    assert sample_label.dtype == torch.long
    weights = dataset.get_class_weights()
    assert weights.shape == (NUM_TERRAIN_CLASSES,)
    logger.info("데이터셋 OK: %d 샘플, 가중치 shape=%s", len(dataset), tuple(weights.shape))

    # ─── 5. TerrainTrainer 빠른 학습 테스트 / Quick training test ────────
    logger.info("--- 5. TerrainTrainer 빠른 학습 테스트 ---")
    train_ds, val_ds = gen.generate_train_val_split(n_samples_per_class=30, val_ratio=0.2)
    train_loader = DataLoader(train_ds, batch_size=16, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=16, shuffle=False)

    train_model = TerrainCNN()
    trainer = TerrainTrainer(train_model, lr=1e-3, device=device, checkpoint_dir="/tmp/terrain_test_ckpt")
    best_acc = trainer.train(train_loader, val_loader, epochs=3, early_stop=3)
    logger.info("학습 OK: best_val_acc=%.4f", best_acc)

    # ─── 6. TerrainInferenceEngine 테스트 / Inference engine test ────────
    logger.info("--- 6. TerrainInferenceEngine 테스트 ---")
    engine = TerrainInferenceEngine(
        model_path="/tmp/terrain_test_ckpt/terrain_cnn_best.pt",
        device=device,
    )

    # 슬라이딩 윈도우 버퍼 테스트 / Sliding window buffer test
    for i in range(SEQUENCE_LENGTH + 50):
        sample = np.random.randn(IMU_CHANNELS).astype(np.float32) * 0.1
        engine.update_buffer(sample)

    prediction = engine.classify_realtime()
    assert isinstance(prediction, TerrainPrediction)
    assert isinstance(prediction.terrain_type, TerrainType)
    logger.info("추론 OK: terrain=%s, confidence=%.4f", prediction.terrain_type.value, prediction.confidence)

    # 외부 버퍼로 직접 분류 테스트 / Direct classification with external buffer
    ext_buffer = np.random.randn(IMU_CHANNELS, SEQUENCE_LENGTH).astype(np.float32) * 0.2
    pred2 = engine.classify_realtime(imu_buffer=ext_buffer)
    assert isinstance(pred2, TerrainPrediction)
    logger.info("외부 버퍼 추론 OK: terrain=%s", pred2.terrain_type.value)

    # 통계 확인 / Check stats
    stats = engine.get_inference_stats()
    logger.info("추론 통계: %s", stats)

    # ─── 7. 지형별 특성 데이터 품질 테스트 / Per-terrain data quality ───
    logger.info("--- 7. 지형별 데이터 특성 검증 ---")
    for terrain in TerrainType:
        samples = gen.generate_terrain_pattern(terrain, n_samples=10)
        rms_vals = [float(np.sqrt(np.mean(s ** 2))) for s in samples]
        avg_rms = np.mean(rms_vals)
        expected_rms = gen.TERRAIN_PARAMS[terrain]["rms"]
        logger.info(
            "  %s: avg_rms=%.4f (expected~%.4f)", terrain.value, avg_rms, expected_rms,
        )

    logger.info("═══ terrain_net 자체 테스트 모두 통과 ═══")


if __name__ == "__main__":
    _self_test()
