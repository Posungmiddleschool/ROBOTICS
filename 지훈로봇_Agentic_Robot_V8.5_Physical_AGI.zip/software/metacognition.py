#!/usr/bin/env python3
"""
지훈 로봇 V8.5 - 메타인지 엔진
Jihun Robot V8.5 - Metacognition Engine

TODO 19: 메타인지 엔진
로봇의 자기 인식 및 능력 평가 시스템입니다. 자신이 무엇을 할 수 있고
무엇을 모르는지 파악하여 안전하고 효율적인 행동 결정을 지원합니다.

**Physical AGI Paradigm**: WORLD DATA = Physical interaction experience, NOT web crawling.
The robot assesses its physical capabilities — can it walk on this terrain?
can it grip this object? can it lift this weight? — based on actual embodied
experience, not theoretical knowledge. All self-knowledge comes from doing.

로봇은 자신의 물리적 능력을 평가합니다 — 이 지형을 걸을 수 있는가? 이 객체를
잡을 수 있는가? 이 무게를 들 수 있는가? — 모든 자기 지식은 실제 물리적
경험에서 비롯됩니다. 이론적 지식이 아닌 실행 경험이 자기 인식의 기반입니다.

This module provides:
- MetacognitionEngine: 자기 인식 오케스트레이터
- CapabilityEstimator: 작업 성공 확률 추정 (베이지안 접근)
- UncertaintyQuantifier: 인식적 + 우연적 불확실성 정량화 (적합 예측)
- KnowledgeGapDetector: 지식 격차 탐지기
- PerformanceMonitor: 시간에 따른 성능 추적

핵심 개념:
    메타인지는 "자신의 인지 과정에 대해 아는 것"입니다.
    로봇이 자신의 능력 한계를 인식하고, 불확실성을 정량화하며,
    지식 부족을 식별하여 적절히 도움을 요청하거나 학습할 수 있습니다.

하드웨어: Dual Jetson Orin NX 16GB
AI 모델: Gemma 4 E4B Q4_K_M
작성일: 2024
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import (
    Any,
    Callable,
    Deque,
    Dict,
    List,
    Optional,
    Tuple,
    Union,
)

import numpy as np

# ─── PyTorch 선택적 임포트 / Optional PyTorch Import ─────────────────────────

TORCH_AVAILABLE = False
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    TORCH_AVAILABLE = True
except ImportError:
    torch = None
    nn = None
    F = None

# ─── 로깅 설정 / Logging Configuration ──────────────────────────────────────

logger = logging.getLogger("jihun_v84.metacognition")
logger.setLevel(logging.DEBUG)

_HANDLER = logging.StreamHandler()
_HANDLER.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
)
logger.addHandler(_HANDLER)


# ─── 열거형 / Enums ─────────────────────────────────────────────────────────


class TaskCategory(str, Enum):
    """작업 범주 / Task categories."""
    NAVIGATION = "navigation"
    MANIPULATION = "manipulation"
    PERCEPTION = "perception"
    COMMUNICATION = "communication"
    LEARNING = "learning"
    PLANNING = "planning"
    SAFETY = "safety"
    MAINTENANCE = "maintenance"
    CUSTOM = "custom"


class ConfidenceLevel(str, Enum):
    """신뢰도 수준 / Confidence levels."""
    VERY_HIGH = "very_high"  # > 0.9
    HIGH = "high"           # 0.7 ~ 0.9
    MEDIUM = "medium"       # 0.4 ~ 0.7
    LOW = "low"             # 0.2 ~ 0.4
    VERY_LOW = "very_low"   # < 0.2


class UncertaintyType(str, Enum):
    """불확실성 유형 / Uncertainty types."""
    EPISTEMIC = "epistemic"     # 모델 불확실성 (지식 부족)
    ALEATORIC = "aleatoric"     # 데이터 불확실성 (노이즈)
    TOTAL = "total"             # 총 불확실성


class GapSeverity(str, Enum):
    """지식 격차 심각도 / Knowledge gap severity."""
    CRITICAL = "critical"   # 즉각적 조치 필요
    HIGH = "high"           # 단기 학습 필요
    MEDIUM = "medium"       # 중기 학습 권장
    LOW = "low"             # 장기 학습 고려
    NONE = "none"           # 격차 없음


# ─── 데이터 클래스 / Data Classes ───────────────────────────────────────────


@dataclass
class MetacognitionConfig:
    """
    메타인지 설정 / Metacognition configuration.

    Attributes:
        capability_prior_strength: 베이지안 사전 강도 (경험 수)
        uncertainty_calibration_samples: 적합 예측 보정 샘플 수
        performance_window: 성능 모니터링 윈도우 크기
        gap_detection_threshold: 지식 격차 탐지 임계값
        confidence_decay_rate: 신뢰도 감쇠율 (시간 경과에 따른)
    """
    capability_prior_strength: int = 10
    uncertainty_calibration_samples: int = 1000
    performance_window: int = 100
    gap_detection_threshold: float = 0.3
    confidence_decay_rate: float = 0.01


@dataclass
class TaskDescriptor:
    """
    작업 서술자 / Task descriptor.

    Attributes:
        task_id: 작업 식별자
        category: 작업 범주
        description: 작업 설명
        required_capabilities: 필요 능력 목록
        difficulty: 난이도 (0~1)
        context: 작업 컨텍스트
    """
    task_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    category: TaskCategory = TaskCategory.CUSTOM
    description: str = ""
    required_capabilities: List[str] = field(default_factory=list)
    difficulty: float = 0.5
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CapabilityEstimate:
    """
    능력 추정 결과 / Capability estimation result.

    Attributes:
        capability_name: 능력 이름
        success_probability: 성공 확률 (0~1)
        confidence_interval: 신뢰구간 (하한, 상한)
        sample_count: 기반 샘플 수
        prior_strength: 사전 강도
        last_updated: 마지막 업데이트 시각
    """
    capability_name: str = ""
    success_probability: float = 0.5
    confidence_interval: Tuple[float, float] = (0.0, 1.0)
    sample_count: int = 0
    prior_strength: int = 10
    last_updated: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class UncertaintyReport:
    """
    불확실성 보고서 / Uncertainty report.

    Attributes:
        timestamp: 보고 시각
        query: 쿼리 설명
        epistemic_uncertainty: 인식적 불확실성 (모델 불확실성)
        aleatoric_uncertainty: 우연적 불확실성 (데이터 불확실성)
        total_uncertainty: 총 불확실성
        confidence_level: 신뢰도 수준
        prediction_interval: 예측 구간
        conformal_score: 적합 예측 점수
    """
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    query: str = ""
    epistemic_uncertainty: float = 0.0
    aleatoric_uncertainty: float = 0.0
    total_uncertainty: float = 0.0
    confidence_level: ConfidenceLevel = ConfidenceLevel.MEDIUM
    prediction_interval: Tuple[float, float] = (0.0, 1.0)
    conformal_score: float = 0.0


@dataclass
class KnowledgeGap:
    """
    지식 격차 / Knowledge gap.

    Attributes:
        gap_id: 격차 식별자
        domain: 지식 도메인
        description: 격차 설명
        severity: 심각도
        relevance_score: 현재 작업과의 관련성 (0~1)
        suggested_action: 권장 조치
        timestamp: 탐지 시각
    """
    gap_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    domain: str = ""
    description: str = ""
    severity: GapSeverity = GapSeverity.MEDIUM
    relevance_score: float = 0.5
    suggested_action: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class PerformanceRecord:
    """
    성능 기록 / Performance record.

    Attributes:
        task_category: 작업 범주
        success: 성공 여부
        execution_time: 실행 시간 (초)
        quality_score: 품질 점수 (0~1)
        timestamp: 기록 시각
        metadata: 추가 메타데이터
    """
    task_category: TaskCategory = TaskCategory.CUSTOM
    success: bool = False
    execution_time: float = 0.0
    quality_score: float = 0.0
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    metadata: Dict[str, Any] = field(default_factory=dict)


# ─── SQLite 저장소 / SQLite Repository ──────────────────────────────────────


class MetacognitionRepository:
    """
    메타인지 SQLite 저장소 / Metacognition SQLite repository.
    """

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS capability_history (
        capability_name TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        success_probability REAL,
        sample_count INTEGER,
        confidence_lower REAL,
        confidence_upper REAL
    );

    CREATE INDEX IF NOT EXISTS idx_cap_name ON capability_history(capability_name);

    CREATE TABLE IF NOT EXISTS uncertainty_records (
        record_id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        query_desc TEXT,
        epistemic REAL,
        aleatoric REAL,
        total REAL,
        confidence_level TEXT,
        conformal_score REAL
    );

    CREATE TABLE IF NOT EXISTS knowledge_gaps (
        gap_id TEXT PRIMARY KEY,
        domain TEXT,
        description TEXT,
        severity TEXT,
        relevance_score REAL,
        suggested_action TEXT,
        detected_at TEXT,
        resolved_at TEXT
    );

    CREATE TABLE IF NOT EXISTS performance_log (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_category TEXT,
        success INTEGER,
        execution_time REAL,
        quality_score REAL,
        timestamp TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_perf_category ON performance_log(task_category);
    """

    def __init__(self, db_path: Union[str, Path] = "metacognition.db") -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_db()
        logger.info("MetacognitionRepository 초기화: %s", self._db_path)

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            self._local.conn = sqlite3.connect(
                str(self._db_path), check_same_thread=False
            )
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
        return self._local.conn

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript(self.SCHEMA)
        conn.commit()

    def save_capability_estimate(self, est: CapabilityEstimate) -> None:
        """능력 추정 저장 / Save capability estimate."""
        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT INTO capability_history
                (capability_name, timestamp, success_probability, sample_count,
                 confidence_lower, confidence_upper)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    est.capability_name,
                    est.last_updated,
                    est.success_probability,
                    est.sample_count,
                    est.confidence_interval[0],
                    est.confidence_interval[1],
                ),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("능력 추정 저장 실패: %s", e)

    def save_uncertainty(self, report: UncertaintyReport) -> None:
        """불확실성 기록 저장 / Save uncertainty record."""
        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT INTO uncertainty_records
                (timestamp, query_desc, epistemic, aleatoric, total,
                 confidence_level, conformal_score)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    report.timestamp,
                    report.query,
                    report.epistemic_uncertainty,
                    report.aleatoric_uncertainty,
                    report.total_uncertainty,
                    report.confidence_level.value,
                    report.conformal_score,
                ),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("불확실성 기록 저장 실패: %s", e)

    def save_knowledge_gap(self, gap: KnowledgeGap) -> None:
        """지식 격차 저장 / Save knowledge gap."""
        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT OR REPLACE INTO knowledge_gaps
                (gap_id, domain, description, severity, relevance_score,
                 suggested_action, detected_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    gap.gap_id,
                    gap.domain,
                    gap.description,
                    gap.severity.value,
                    gap.relevance_score,
                    gap.suggested_action,
                    gap.timestamp,
                ),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("지식 격차 저장 실패: %s", e)

    def resolve_knowledge_gap(self, gap_id: str) -> None:
        """지식 격차 해결 표시 / Mark knowledge gap as resolved."""
        try:
            conn = self._get_conn()
            conn.execute(
                "UPDATE knowledge_gaps SET resolved_at = ? WHERE gap_id = ?",
                (datetime.now(timezone.utc).isoformat(), gap_id),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("지식 격차 해결 표시 실패: %s", e)

    def save_performance(self, record: PerformanceRecord) -> None:
        """성능 기록 저장 / Save performance record."""
        try:
            conn = self._get_conn()
            conn.execute(
                """
                INSERT INTO performance_log
                (task_category, success, execution_time, quality_score, timestamp)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    record.task_category.value,
                    int(record.success),
                    record.execution_time,
                    record.quality_score,
                    record.timestamp,
                ),
            )
            conn.commit()
        except sqlite3.Error as e:
            logger.error("성능 기록 저장 실패: %s", e)

    def get_capability_history(
        self, capability_name: str, limit: int = 50
    ) -> List[Dict[str, Any]]:
        """능력 추정 이력 반환 / Return capability estimation history."""
        try:
            conn = self._get_conn()
            rows = conn.execute(
                """
                SELECT * FROM capability_history
                WHERE capability_name = ?
                ORDER BY timestamp DESC LIMIT ?
                """,
                (capability_name, limit),
            ).fetchall()
            return [dict(r) for r in rows]
        except sqlite3.Error:
            return []

    def get_performance_stats(self) -> Dict[str, Any]:
        """성능 통계 반환 / Return performance statistics."""
        try:
            conn = self._get_conn()
            total = conn.execute("SELECT COUNT(*) FROM performance_log").fetchone()[0]
            successes = conn.execute(
                "SELECT COUNT(*) FROM performance_log WHERE success = 1"
            ).fetchone()[0]
            avg_quality = conn.execute(
                "SELECT AVG(quality_score) FROM performance_log"
            ).fetchone()[0] or 0.0
            avg_time = conn.execute(
                "SELECT AVG(execution_time) FROM performance_log"
            ).fetchone()[0] or 0.0
            by_category = dict(
                conn.execute(
                    "SELECT task_category, COUNT(*), AVG(quality_score) "
                    "FROM performance_log GROUP BY task_category"
                ).fetchall()
            )
            return {
                "total_tasks": total,
                "success_rate": successes / max(1, total),
                "avg_quality": round(avg_quality, 3),
                "avg_execution_time": round(avg_time, 2),
                "by_category": by_category,
            }
        except sqlite3.Error:
            return {}


# ─── CapabilityEstimator / 능력 추정기 ──────────────────────────────────────


class CapabilityEstimator:
    """
    능력 추정기 / Capability estimator.

    베이지안 접근법으로 로봇의 각 능력에 대한 성공 확률을 추정합니다.
    경험으로부터 사후 분포를 지속적으로 업데이트합니다.

    베이지안 모델:
        사전: Beta(α₀, β₀) — 초기 신뢰도
        우도: 성공/실패 이벤트
        사후: Beta(α₀ + 성공, β₀ + 실패)

    신뢰구간:
        Beta 분포의 95% 신뢰구간 사용

    Usage:
        estimator = CapabilityEstimator()
        estimator.record_outcome("navigation_indoor", success=True)
        est = estimator.estimate("navigation_indoor")
    """

    def __init__(
        self,
        prior_alpha: float = 1.0,
        prior_beta: float = 1.0,
        prior_strength: int = 10,
        repository: Optional[MetacognitionRepository] = None,
    ) -> None:
        self._prior_alpha = prior_alpha
        self._prior_beta = prior_beta
        self._prior_strength = prior_strength
        self._repository = repository or MetacognitionRepository()

        # 능력별 베이지안 상태 / Per-capability Bayesian state
        # {name: (alpha, beta, sample_count)}
        self._capabilities: Dict[str, Tuple[float, float, int]] = {}
        self._lock = threading.Lock()

        # 기본 능력 초기화 / Initialize default capabilities
        self._init_default_capabilities()
        logger.info(
            "CapabilityEstimator 초기화: prior=Beta(%.1f, %.1f), 강도=%d",
            prior_alpha, prior_beta, prior_strength,
        )

    def _init_default_capabilities(self) -> None:
        """기본 능력 초기화 / Initialize default capabilities."""
        defaults = {
            # 내비게이션 / Navigation
            "navigation_indoor": (7.0, 3.0),     # 사전: 70% 성공 예상
            "navigation_outdoor": (5.0, 5.0),    # 50%
            "navigation_narrow": (4.0, 6.0),     # 40%
            # 조작 / Manipulation
            "grasp_small_objects": (6.0, 4.0),   # 60%
            "grasp_large_objects": (7.0, 3.0),   # 70%
            "precise_placement": (3.0, 7.0),     # 30%
            # 지각 / Perception
            "object_recognition": (8.0, 2.0),    # 80%
            "face_recognition": (6.0, 4.0),      # 60%
            "speech_understanding_korean": (7.0, 3.0),  # 70%
            "speech_understanding_english": (5.0, 5.0),  # 50%
            # 통신 / Communication
            "natural_conversation": (6.0, 4.0),  # 60%
            "task_explanation": (5.0, 5.0),      # 50%
            # 안전 / Safety
            "obstacle_avoidance": (8.0, 2.0),    # 80%
            "emergency_stop": (9.0, 1.0),        # 90%
            # 학습 / Learning
            "new_skill_acquisition": (4.0, 6.0), # 40%
            "concept_learning": (5.0, 5.0),      # 50%
        }

        for name, (alpha, beta) in defaults.items():
            self._capabilities[name] = (alpha, beta, 0)

    def record_outcome(
        self,
        capability_name: str,
        success: bool,
        count: int = 1,
    ) -> None:
        """
        능력 수행 결과 기록 / Record capability outcome.

        Args:
            capability_name: 능력 이름
            success: 성공 여부
            count: 결과 횟수 (기본 1)
        """
        with self._lock:
            if capability_name not in self._capabilities:
                # 새 능력: 사전 분포로 초기화 / New capability: init with prior
                self._capabilities[capability_name] = (
                    self._prior_alpha * self._prior_strength,
                    self._prior_beta * self._prior_strength,
                    0,
                )

            alpha, beta, n = self._capabilities[capability_name]
            if success:
                alpha += count
            else:
                beta += count
            n += count
            self._capabilities[capability_name] = (alpha, beta, n)

        # 저장소에 기록 / Save to repository
        est = self.estimate(capability_name)
        self._repository.save_capability_estimate(est)

        logger.debug(
            "능력 결과 기록: %s 성공=%s (α=%.1f, β=%.1f, n=%d)",
            capability_name, success, alpha, beta, n,
        )

    def estimate(self, capability_name: str) -> CapabilityEstimate:
        """
        능력 추정 / Estimate capability.

        Args:
            capability_name: 능력 이름

        Returns:
            능력 추정 결과
        """
        with self._lock:
            if capability_name not in self._capabilities:
                # 알 수 없는 능력 / Unknown capability
                return CapabilityEstimate(
                    capability_name=capability_name,
                    success_probability=0.5,
                    confidence_interval=(0.0, 1.0),
                    sample_count=0,
                    prior_strength=self._prior_strength,
                )

            alpha, beta, n = self._capabilities[capability_name]

        # 사후 평균 (성공 확률 추정치) / Posterior mean
        mean = alpha / (alpha + beta)

        # 95% 신뢰구간 (Beta 분포) / 95% confidence interval
        ci_lower, ci_upper = self._beta_ci(alpha, beta, 0.95)

        return CapabilityEstimate(
            capability_name=capability_name,
            success_probability=round(mean, 4),
            confidence_interval=(round(ci_lower, 4), round(ci_upper, 4)),
            sample_count=n,
            prior_strength=self._prior_strength,
        )

    def estimate_task(
        self, task: TaskDescriptor
    ) -> Dict[str, Any]:
        """
        작업 수행 능력 추정 / Estimate capability for a task.

        Args:
            task: 작업 서술자

        Returns:
            작업 능력 추정 결과
        """
        estimates = []
        for cap_name in task.required_capabilities:
            est = self.estimate(cap_name)
            estimates.append(est)

        if not estimates:
            return {
                "task_id": task.task_id,
                "overall_probability": 0.5,
                "confidence_level": ConfidenceLevel.VERY_LOW.value,
                "required_capabilities": [],
                "weakest_capability": None,
                "recommendation": "필요 능력이 정의되지 않았습니다.",
            }

        # 전체 성공 확률: 독립 가정하에 곱 / Overall: product under independence
        overall_prob = 1.0
        weakest_cap = estimates[0]
        for est in estimates:
            overall_prob *= est.success_probability
            if est.success_probability < weakest_cap.success_probability:
                weakest_cap = est

        # 난이도 조정 / Adjust for difficulty
        overall_prob *= (1.0 - task.difficulty * 0.3)

        # 신뢰도 수준 결정 / Determine confidence level
        confidence = self._probability_to_confidence(overall_prob)

        # 권장 사항 생성 / Generate recommendation
        recommendation = self._generate_recommendation(overall_prob, weakest_cap)

        return {
            "task_id": task.task_id,
            "overall_probability": round(max(0.0, min(1.0, overall_prob)), 4),
            "confidence_level": confidence.value,
            "required_capabilities": [
                {
                    "name": e.capability_name,
                    "probability": e.success_probability,
                    "interval": e.confidence_interval,
                    "samples": e.sample_count,
                }
                for e in estimates
            ],
            "weakest_capability": weakest_cap.capability_name,
            "recommendation": recommendation,
        }

    @staticmethod
    def _beta_ci(
        alpha: float, beta: float, confidence: float = 0.95
    ) -> Tuple[float, float]:
        """
        Beta 분포 신뢰구간 계산 / Compute Beta distribution confidence interval.

        정규 근사법을 사용합니다.
        """
        mean = alpha / (alpha + beta)
        variance = (alpha * beta) / ((alpha + beta) ** 2 * (alpha + beta + 1))
        std = math.sqrt(max(0, variance))
        z = {0.90: 1.645, 0.95: 1.96, 0.99: 2.576}.get(confidence, 1.96)
        ci_lower = max(0.0, mean - z * std)
        ci_upper = min(1.0, mean + z * std)
        return ci_lower, ci_upper

    @staticmethod
    def _probability_to_confidence(prob: float) -> ConfidenceLevel:
        """확률을 신뢰도 수준으로 변환 / Convert probability to confidence level."""
        if prob > 0.9:
            return ConfidenceLevel.VERY_HIGH
        elif prob > 0.7:
            return ConfidenceLevel.HIGH
        elif prob > 0.4:
            return ConfidenceLevel.MEDIUM
        elif prob > 0.2:
            return ConfidenceLevel.LOW
        else:
            return ConfidenceLevel.VERY_LOW

    @staticmethod
    def _generate_recommendation(
        overall_prob: float, weakest: CapabilityEstimate
    ) -> str:
        """권장 사항 생성 / Generate recommendation."""
        if overall_prob > 0.8:
            return "작업 수행 가능. 높은 성공 확률."
        elif overall_prob > 0.5:
            return f"작업 수행 가능하나 주의 필요. 취약 능력: '{weakest.capability_name}' ({weakest.success_probability:.1%})"
        elif overall_prob > 0.3:
            return f"작업 수행 위험. '{weakest.capability_name}' 능력 부족. 인간 지원 권장."
        else:
            return f"작업 수행 불가. '{weakest.capability_name}' 능력 심각 부족. 인간 개입 필수."

    def get_all_estimates(self) -> Dict[str, CapabilityEstimate]:
        """모든 능력 추정 반환 / Return all capability estimates."""
        with self._lock:
            return {name: self.estimate(name) for name in self._capabilities}


# ─── UncertaintyQuantifier / 불확실성 정량화기 ──────────────────────────────


class UncertaintyQuantifier:
    """
    불확실성 정량화기 / Uncertainty quantifier.

    적합 예측(Conformal Prediction)을 사용하여 불확실성을 정량화합니다.
    인식적 불확실성(모델 불확실성)과 우연적 불확실성(데이터 불확실성)을
    분리하여 측정합니다.

    적합 예측:
        1. 보정 데이터에서 비적합성 점수 계산
        2. 점수 분포의 분위수로 예측 구간 설정
        3. 새 데이터에 적용하여 보장된 커버리지 제공

    인식적 불확실성:
        - 모델 앙상블 또는 MC Dropout 기반
        - 예측 분산으로 측정
        - 데이터가 더 많으면 감소

    우연적 불확실성:
        - 데이터 자체의 노이즈
        - 예측 구간 폭으로 측정
        - 데이터가 더 많아도 감소하지 않음

    Usage:
        quantifier = UncertaintyQuantifier()
        quantifier.calibrate(calibration_features, calibration_labels)
        report = quantifier.quantify(features, prediction)
    """

    def __init__(
        self,
        n_calibration: int = 1000,
        alpha: float = 0.05,
        repository: Optional[MetacognitionRepository] = None,
    ) -> None:
        self._n_calibration = n_calibration
        self._alpha = alpha  # 유의수준 (1 - alpha = 커버리지)
        self._repository = repository or MetacognitionRepository()

        # 보정 통계 / Calibration statistics
        self._calibration_scores: Deque[float] = deque(maxlen=n_calibration)
        self._feature_stats: Dict[str, Tuple[float, float]] = {}  # mean, std
        self._is_calibrated: bool = False

        # 잔차 통계 (우연적 불확실성 추정용) / Residual statistics
        self._residual_history: Deque[float] = deque(maxlen=n_calibration)

        self._lock = threading.Lock()
        logger.info(
            "UncertaintyQuantifier 초기화: n_calibration=%d, alpha=%.2f",
            n_calibration, alpha,
        )

    def calibrate(
        self,
        features: np.ndarray,
        predictions: np.ndarray,
        targets: np.ndarray,
    ) -> Dict[str, Any]:
        """
        적합 예측 보정 / Calibrate conformal prediction.

        Args:
            features: 특징 행렬 (n, d)
            predictions: 모델 예측값 (n,)
            targets: 실제값 (n,)

        Returns:
            보정 결과
        """
        features = np.asarray(features, dtype=np.float64)
        predictions = np.asarray(predictions, dtype=np.float64).flatten()
        targets = np.asarray(targets, dtype=np.float64).flatten()

        n = len(predictions)
        if n < 10:
            logger.warning("보정 데이터 부족: %d < 10", n)
            return {"status": "insufficient_data", "n_samples": n}

        # 비적합성 점수 계산 / Calculate nonconformity scores
        residuals = np.abs(predictions - targets)
        for r in residuals:
            self._calibration_scores.append(float(r))
            self._residual_history.append(float(r))

        # 특징 통계 저장 / Store feature statistics
        if features.ndim == 2:
            for i in range(features.shape[1]):
                self._feature_stats[f"feat_{i}"] = (
                    float(np.mean(features[:, i])),
                    float(np.std(features[:, i])),
                )

        self._is_calibrated = True
        logger.info("적합 예측 보정 완료: %d 샘플", n)

        return {
            "status": "success",
            "n_samples": n,
            "mean_residual": float(np.mean(residuals)),
            "std_residual": float(np.std(residuals)),
        }

    def quantify(
        self,
        features: np.ndarray,
        prediction: float,
        n_mc_samples: int = 30,
    ) -> UncertaintyReport:
        """
        불확실성 정량화 / Quantify uncertainty.

        Args:
            features: 입력 특징
            prediction: 모델 예측값
            n_mc_samples: MC Dropout 샘플 수 (인식적 불확실성 추정)

        Returns:
            불확실성 보고서
        """
        features = np.asarray(features, dtype=np.float64).flatten()

        # ── 우연적 불확실성 / Aleatoric uncertainty ──
        if self._residual_history:
            aleatoric = float(np.mean(list(self._residual_history)[-100:]))
        else:
            aleatoric = 0.5  # 기본값

        # ── 인식적 불확실성 / Epistemic uncertainty ──
        # 특징이 학습 데이터 분포에서 벗어난 정도로 측정
        epistemic = self._estimate_epistemic(features)

        # ── 총 불확실성 / Total uncertainty ──
        total = math.sqrt(epistemic ** 2 + aleatoric ** 2)

        # ── 적합 예측 구간 / Conformal prediction interval ──
        conformal_score = 0.0
        ci_lower = prediction - aleatoric
        ci_upper = prediction + aleatoric

        with self._lock:
            if self._calibration_scores:
                scores = sorted(list(self._calibration_scores))
                idx = int((1 - self._alpha) * len(scores))
                idx = min(idx, len(scores) - 1)
                conformal_score = scores[idx]
                ci_lower = prediction - conformal_score
                ci_upper = prediction + conformal_score

        # ── 신뢰도 수준 / Confidence level ──
        normalized_total = min(1.0, total / max(0.01, conformal_score + 0.01))
        if normalized_total < 0.1:
            confidence = ConfidenceLevel.VERY_HIGH
        elif normalized_total < 0.3:
            confidence = ConfidenceLevel.HIGH
        elif normalized_total < 0.6:
            confidence = ConfidenceLevel.MEDIUM
        elif normalized_total < 0.8:
            confidence = ConfidenceLevel.LOW
        else:
            confidence = ConfidenceLevel.VERY_LOW

        report = UncertaintyReport(
            query=f"prediction={prediction:.4f}",
            epistemic_uncertainty=round(epistemic, 4),
            aleatoric_uncertainty=round(aleatoric, 4),
            total_uncertainty=round(total, 4),
            confidence_level=confidence,
            prediction_interval=(round(ci_lower, 4), round(ci_upper, 4)),
            conformal_score=round(conformal_score, 4),
        )

        # 저장소에 기록 / Save to repository
        self._repository.save_uncertainty(report)

        return report

    def _estimate_epistemic(self, features: np.ndarray) -> float:
        """
        인식적 불확실성 추정 / Estimate epistemic uncertainty.

        특징이 훈련 데이터 분포에서 얼마나 벗어났는지
        Mahalanobis 거리로 측정합니다.
        """
        if not self._feature_stats:
            return 0.5  # 보정 전 기본값

        # 각 특징 차원에서 z-score 계산 / Calculate z-score per feature dimension
        z_scores = []
        for i, val in enumerate(features):
            stat_key = f"feat_{i}"
            if stat_key in self._feature_stats:
                mean, std = self._feature_stats[stat_key]
                if std > 1e-8:
                    z_scores.append(abs(val - mean) / std)

        if not z_scores:
            return 0.5

        # 평균 z-score → 인식적 불확실성 / Mean z-score → epistemic uncertainty
        avg_z = float(np.mean(z_scores))
        # 0에 가까우면 낮은 불확실성, 높으면 높은 불확실성
        epistemic = min(1.0, avg_z / 3.0)  # 3-sigma 범위 정규화
        return epistemic

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        return {
            "is_calibrated": self._is_calibrated,
            "n_calibration_scores": len(self._calibration_scores),
            "n_residuals": len(self._residual_history),
            "n_features_tracked": len(self._feature_stats),
            "alpha": self._alpha,
        }


# ─── KnowledgeGapDetector / 지식 격차 탐지기 ───────────────────────────────


class KnowledgeGapDetector:
    """
    지식 격차 탐지기 / Knowledge gap detector.

    로봇이 무엇을 모르는지 식별합니다. 관련 기억이 없거나
    기존 지식과 충돌하는 상황을 탐지합니다.

    탐지 방법:
        1. 기억 부재: 관련 메모리가 전혀 없는 경우
        2. 기억 희소성: 관련 메모리가 너무 적은 경우
        3. 일관성 부족: 기억들 간 모순이 있는 경우
        4. 신뢰도 부족: 기억의 신뢰도가 낮은 경우
        5. 커버리지 부족: 작업에 필요한 지식 도메인이 누락된 경우

    Usage:
        detector = KnowledgeGapDetector()
        gaps = detector.detect(task, available_memories)
    """

    def __init__(
        self,
        min_memory_threshold: int = 3,
        consistency_threshold: float = 0.5,
        confidence_threshold: float = 0.3,
        repository: Optional[MetacognitionRepository] = None,
    ) -> None:
        self._min_memory_threshold = min_memory_threshold
        self._consistency_threshold = consistency_threshold
        self._confidence_threshold = confidence_threshold
        self._repository = repository or MetacognitionRepository()

        # 도메인별 기억 통계 / Per-domain memory statistics
        self._domain_stats: Dict[str, Dict[str, Any]] = {}
        self._detected_gaps: List[KnowledgeGap] = []
        self._lock = threading.Lock()

        logger.info(
            "KnowledgeGapDetector 초기화: min_memory=%d, consistency=%.2f",
            min_memory_threshold, consistency_threshold,
        )

    def update_domain_stats(
        self,
        domain: str,
        memory_count: int,
        avg_confidence: float,
        consistency_score: float,
    ) -> None:
        """
        도메인 기억 통계 업데이트 / Update domain memory statistics.

        Args:
            domain: 지식 도메인
            memory_count: 기억 수
            avg_confidence: 평균 신뢰도
            consistency_score: 일관성 점수
        """
        with self._lock:
            self._domain_stats[domain] = {
                "memory_count": memory_count,
                "avg_confidence": avg_confidence,
                "consistency_score": consistency_score,
                "last_updated": datetime.now(timezone.utc).isoformat(),
            }

    def detect(
        self,
        task: Optional[TaskDescriptor] = None,
        required_domains: Optional[List[str]] = None,
    ) -> List[KnowledgeGap]:
        """
        지식 격차 탐지 / Detect knowledge gaps.

        Args:
            task: 작업 서술자 (None이면 전체 도메인 검사)
            required_domains: 필요 도메인 목록

        Returns:
            탐지된 지식 격차 목록
        """
        gaps: List[KnowledgeGap] = []

        with self._lock:
            domains_to_check = required_domains or []
            if task:
                domains_to_check.extend(task.required_capabilities)

            # 작업이 지정되지 않으면 모든 도메인 검사 / Check all if no task
            if not domains_to_check:
                domains_to_check = list(self._domain_stats.keys())

            for domain in domains_to_check:
                gap = self._check_domain(domain, task)
                if gap:
                    gaps.append(gap)
                    self._detected_gaps.append(gap)
                    self._repository.save_knowledge_gap(gap)

        # 심각도순 정렬 / Sort by severity
        severity_order = {
            GapSeverity.CRITICAL: 0,
            GapSeverity.HIGH: 1,
            GapSeverity.MEDIUM: 2,
            GapSeverity.LOW: 3,
        }
        gaps.sort(key=lambda g: severity_order.get(g.severity, 4))

        return gaps

    def _check_domain(
        self, domain: str, task: Optional[TaskDescriptor]
    ) -> Optional[KnowledgeGap]:
        """단일 도메인 지식 격차 확인 / Check single domain for knowledge gap."""
        stats = self._domain_stats.get(domain, {})

        memory_count = stats.get("memory_count", 0)
        avg_confidence = stats.get("avg_confidence", 0.0)
        consistency = stats.get("consistency_score", 1.0)

        # 관련성 점수 / Relevance score
        relevance = 1.0 if task and domain in task.required_capabilities else 0.3

        # ── 기억 부재 / Memory absence ──
        if memory_count == 0:
            return KnowledgeGap(
                domain=domain,
                description=f"'{domain}' 도메인에 관련 기억이 전혀 없습니다.",
                severity=GapSeverity.CRITICAL if relevance > 0.5 else GapSeverity.HIGH,
                relevance_score=relevance,
                suggested_action=f"'{domain}' 도메인에 대한 데이터 수집 및 학습이 시급합니다.",
            )

        # ── 기억 희소성 / Memory sparsity ──
        if memory_count < self._min_memory_threshold:
            return KnowledgeGap(
                domain=domain,
                description=(
                    f"'{domain}' 도메인의 기억이 부족합니다. "
                    f"({memory_count}개, 최소 {self._min_memory_threshold}개 필요)"
                ),
                severity=GapSeverity.HIGH if relevance > 0.5 else GapSeverity.MEDIUM,
                relevance_score=relevance,
                suggested_action=f"'{domain}' 도메인의 추가 경험 수집이 필요합니다.",
            )

        # ── 신뢰도 부족 / Low confidence ──
        if avg_confidence < self._confidence_threshold:
            return KnowledgeGap(
                domain=domain,
                description=(
                    f"'{domain}' 도메인의 기억 신뢰도가 낮습니다. "
                    f"(평균 신뢰도: {avg_confidence:.2f})"
                ),
                severity=GapSeverity.MEDIUM,
                relevance_score=relevance,
                suggested_action=f"'{domain}' 도메인의 기억 검증 및 보정이 필요합니다.",
            )

        # ── 일관성 부족 / Inconsistency ──
        if consistency < self._consistency_threshold:
            return KnowledgeGap(
                domain=domain,
                description=(
                    f"'{domain}' 도메인의 기억들 간 모순이 있습니다. "
                    f"(일관성: {consistency:.2f})"
                ),
                severity=GapSeverity.HIGH,
                relevance_score=relevance,
                suggested_action=f"'{domain}' 도메인의 모순된 기억을 정리해야 합니다.",
            )

        return None

    def resolve_gap(self, gap_id: str) -> None:
        """지식 격차 해결 표시 / Mark gap as resolved."""
        self._repository.resolve_knowledge_gap(gap_id)
        logger.info("지식 격차 해결: %s", gap_id)

    def get_active_gaps(self) -> List[KnowledgeGap]:
        """활성 지식 격차 반환 / Return active knowledge gaps."""
        return [g for g in self._detected_gaps if g.severity != GapSeverity.NONE]

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        return {
            "tracked_domains": len(self._domain_stats),
            "total_gaps_detected": len(self._detected_gaps),
            "active_gaps": len(self.get_active_gaps()),
            "domain_stats": self._domain_stats,
        }


# ─── PerformanceMonitor / 성능 모니터 ───────────────────────────────────────


class PerformanceMonitor:
    """
    성능 모니터 / Performance monitor.

    시간에 따른 로봇의 성능 변화를 추적합니다. 성능 저하를
    조기에 감지하고 트렌드를 분석합니다.

    추적 지표:
        - 성공률 (범주별)
        - 평균 실행 시간
        - 품질 점수
        - 성능 트렌드 (개선/악화/안정)

    Usage:
        monitor = PerformanceMonitor()
        monitor.record(PerformanceRecord(task_category=TaskCategory.NAVIGATION, success=True))
        trend = monitor.get_trend(TaskCategory.NAVIGATION)
    """

    def __init__(
        self,
        window_size: int = 100,
        trend_window: int = 20,
        repository: Optional[MetacognitionRepository] = None,
    ) -> None:
        self._window_size = window_size
        self._trend_window = trend_window
        self._repository = repository or MetacognitionRepository()

        # 범주별 성능 기록 / Per-category performance records
        self._records: Dict[str, Deque[PerformanceRecord]] = {}
        self._lock = threading.Lock()

        logger.info(
            "PerformanceMonitor 초기화: window=%d, trend=%d",
            window_size, trend_window,
        )

    def record(self, perf: PerformanceRecord) -> None:
        """
        성능 기록 / Record performance.

        Args:
            perf: 성능 기록 항목
        """
        with self._lock:
            category = perf.task_category.value
            if category not in self._records:
                self._records[category] = deque(maxlen=self._window_size)
            self._records[category].append(perf)

        # 저장소에 기록 / Save to repository
        self._repository.save_performance(perf)

        logger.debug(
            "성능 기록: %s 성공=%s 품질=%.2f",
            category, perf.success, perf.quality_score,
        )

    def get_trend(
        self, category: TaskCategory
    ) -> Dict[str, Any]:
        """
        성능 트렌드 분석 / Analyze performance trend.

        Args:
            category: 작업 범주

        Returns:
            트렌드 분석 결과
        """
        with self._lock:
            records = list(self._records.get(category.value, []))

        if len(records) < 5:
            return {
                "category": category.value,
                "trend": "insufficient_data",
                "sample_count": len(records),
            }

        # 최근 vs 이전 성공률 비교 / Compare recent vs previous success rate
        n = len(records)
        recent = records[-self._trend_window:]
        previous = records[-2 * self._trend_window:-self._trend_window] if n >= 2 * self._trend_window else records[:n // 2]

        recent_success_rate = sum(1 for r in recent if r.success) / len(recent)
        previous_success_rate = sum(1 for r in previous if r.success) / len(previous) if previous else 0.0

        recent_quality = np.mean([r.quality_score for r in recent])
        previous_quality = np.mean([r.quality_score for r in previous]) if previous else 0.0

        # 트렌드 판정 / Determine trend
        delta = recent_success_rate - previous_success_rate
        if delta > 0.1:
            trend = "improving"
        elif delta < -0.1:
            trend = "degrading"
        else:
            trend = "stable"

        return {
            "category": category.value,
            "trend": trend,
            "delta": round(delta, 3),
            "recent_success_rate": round(recent_success_rate, 3),
            "previous_success_rate": round(previous_success_rate, 3),
            "recent_quality": round(recent_quality, 3),
            "previous_quality": round(previous_quality, 3),
            "sample_count": n,
        }

    def get_summary(self) -> Dict[str, Any]:
        """전체 성능 요약 / Return performance summary."""
        with self._lock:
            summary = {}
            for category, records in self._records.items():
                if not records:
                    continue
                success_rate = sum(1 for r in records if r.success) / len(records)
                avg_quality = float(np.mean([r.quality_score for r in records]))
                avg_time = float(np.mean([r.execution_time for r in records]))
                summary[category] = {
                    "success_rate": round(success_rate, 3),
                    "avg_quality": round(avg_quality, 3),
                    "avg_execution_time": round(avg_time, 2),
                    "sample_count": len(records),
                }
            return summary


# ─── MetacognitionEngine / 메타인지 엔진 ─────────────────────────────────────


class MetacognitionEngine:
    """
    메타인지 엔진 / Metacognition engine.

    로봇의 자기 인식을 종합적으로 관리하는 오케스트레이터입니다.

    구성 요소:
        - CapabilityEstimator: 능력 추정 (베이지안)
        - UncertaintyQuantifier: 불확실성 정량화 (적합 예측)
        - KnowledgeGapDetector: 지식 격차 탐지
        - PerformanceMonitor: 성능 모니터링

    출력:
        - 신뢰도 점수
        - 능력 경계
        - 지식 격차 보고서
        - 행동 권장 사항

    Usage:
        engine = MetacognitionEngine()
        # 작업 평가
        assessment = engine.assess_task(task)
        # 불확실성 정량화
        report = engine.quantify_uncertainty(features, prediction)
        # 종합 상태
        state = engine.get_self_awareness_state()
    """

    def __init__(
        self,
        config: Optional[MetacognitionConfig] = None,
        db_path: Union[str, Path] = "metacognition.db",
    ) -> None:
        self._config = config or MetacognitionConfig()
        self._repository = MetacognitionRepository(db_path)

        # 구성 요소 초기화 / Initialize components
        self._capability_estimator = CapabilityEstimator(
            prior_strength=self._config.capability_prior_strength,
            repository=self._repository,
        )
        self._uncertainty_quantifier = UncertaintyQuantifier(
            n_calibration=self._config.uncertainty_calibration_samples,
            repository=self._repository,
        )
        self._gap_detector = KnowledgeGapDetector(
            repository=self._repository,
        )
        self._performance_monitor = PerformanceMonitor(
            window_size=self._config.performance_window,
            repository=self._repository,
        )

        # 종합 상태 / Overall state
        self._self_confidence: float = 0.5
        self._last_assessment_time: float = 0.0

        logger.info("MetacognitionEngine 초기화 완료")

    def assess_task(self, task: TaskDescriptor) -> Dict[str, Any]:
        """
        작업 평가 / Assess task.

        작업 수행 능력, 불확실성, 지식 격차를 종합 평가합니다.

        Args:
            task: 작업 서술자

        Returns:
            종합 평가 결과
        """
        # 능력 추정 / Capability estimation
        capability_assessment = self._capability_estimator.estimate_task(task)

        # 지식 격차 탐지 / Knowledge gap detection
        gaps = self._gap_detector.detect(
            task=task,
            required_domains=task.required_capabilities,
        )

        # 종합 신뢰도 계산 / Calculate overall confidence
        cap_prob = capability_assessment.get("overall_probability", 0.5)
        gap_penalty = sum(
            0.1 * (4 - list(GapSeverity).index(g.severity))
            for g in gaps
            if g.relevance_score > 0.5
        )
        overall_confidence = max(0.0, min(1.0, cap_prob - gap_penalty))

        # 행동 권장 / Action recommendation
        if overall_confidence > 0.7:
            action = "proceed"
            recommendation = "작업을 수행할 수 있습니다. 높은 신뢰도."
        elif overall_confidence > 0.4:
            action = "proceed_with_caution"
            recommendation = "작업 수행 가능하나 주의가 필요합니다."
            if gaps:
                recommendation += f" ({len(gaps)}개 지식 격차 존재)"
        elif overall_confidence > 0.2:
            action = "request_assistance"
            recommendation = "인간 지원과 함께 작업을 수행하세요."
        else:
            action = "abort"
            recommendation = "작업 수행이 위험합니다. 중단하세요."

        self._self_confidence = overall_confidence
        self._last_assessment_time = time.time()

        logger.info(
            "작업 평가: %s — 신뢰도=%.2f, 행동=%s",
            task.task_id, overall_confidence, action,
        )

        return {
            "task_id": task.task_id,
            "task_category": task.category.value,
            "overall_confidence": round(overall_confidence, 4),
            "confidence_level": capability_assessment.get("confidence_level", "medium"),
            "capability_assessment": capability_assessment,
            "knowledge_gaps": [
                {
                    "domain": g.domain,
                    "severity": g.severity.value,
                    "description": g.description,
                    "suggested_action": g.suggested_action,
                }
                for g in gaps
            ],
            "recommended_action": action,
            "recommendation": recommendation,
        }

    def quantify_uncertainty(
        self,
        features: np.ndarray,
        prediction: float,
    ) -> UncertaintyReport:
        """
        불확실성 정량화 / Quantify uncertainty.

        Args:
            features: 입력 특징
            prediction: 모델 예측값

        Returns:
            불확실성 보고서
        """
        return self._uncertainty_quantifier.quantify(features, prediction)

    def record_outcome(
        self,
        capability_name: str,
        success: bool,
        task_category: TaskCategory = TaskCategory.CUSTOM,
        execution_time: float = 0.0,
        quality_score: float = 0.0,
    ) -> None:
        """
        결과 기록 / Record outcome.

        Args:
            capability_name: 능력 이름
            success: 성공 여부
            task_category: 작업 범주
            execution_time: 실행 시간
            quality_score: 품질 점수
        """
        # 능력 추정 업데이트 / Update capability estimation
        self._capability_estimator.record_outcome(capability_name, success)

        # 성능 기록 / Record performance
        self._performance_monitor.record(PerformanceRecord(
            task_category=task_category,
            success=success,
            execution_time=execution_time,
            quality_score=quality_score,
        ))

        logger.info(
            "결과 기록: %s 성공=%s (%.1fs, 품질=%.2f)",
            capability_name, success, execution_time, quality_score,
        )

    def calibrate_uncertainty(
        self,
        features: np.ndarray,
        predictions: np.ndarray,
        targets: np.ndarray,
    ) -> Dict[str, Any]:
        """
        불확실성 보정 / Calibrate uncertainty quantifier.

        Args:
            features: 특징 행렬
            predictions: 예측값
            targets: 실제값

        Returns:
            보정 결과
        """
        return self._uncertainty_quantifier.calibrate(
            features, predictions, targets
        )

    def update_domain_knowledge(
        self,
        domain: str,
        memory_count: int,
        avg_confidence: float,
        consistency_score: float,
    ) -> None:
        """
        도메인 지식 통계 업데이트 / Update domain knowledge statistics.

        Args:
            domain: 지식 도메인
            memory_count: 기억 수
            avg_confidence: 평균 신뢰도
            consistency_score: 일관성 점수
        """
        self._gap_detector.update_domain_stats(
            domain, memory_count, avg_confidence, consistency_score
        )

    def get_self_awareness_state(self) -> Dict[str, Any]:
        """
        자기 인식 상태 반환 / Return self-awareness state.

        Returns:
            종합 자기 인식 상태
        """
        all_caps = self._capability_estimator.get_all_estimates()
        performance_summary = self._performance_monitor.get_summary()
        gap_stats = self._gap_detector.get_stats()
        uncertainty_stats = self._uncertainty_quantifier.get_stats()

        # 능력 요약 / Capability summary
        strong_capabilities = [
            name for name, est in all_caps.items()
            if est.success_probability > 0.7
        ]
        weak_capabilities = [
            name for name, est in all_caps.items()
            if est.success_probability < 0.4
        ]

        return {
            "self_confidence": round(self._self_confidence, 4),
            "last_assessment_time": self._last_assessment_time,
            "capabilities": {
                "total_tracked": len(all_caps),
                "strong": strong_capabilities,
                "weak": weak_capabilities,
                "all": {
                    name: {
                        "probability": est.success_probability,
                        "interval": est.confidence_interval,
                        "samples": est.sample_count,
                    }
                    for name, est in all_caps.items()
                },
            },
            "performance": performance_summary,
            "knowledge_gaps": gap_stats,
            "uncertainty": uncertainty_stats,
        }

    def get_capability_estimate(self, capability_name: str) -> CapabilityEstimate:
        """특정 능력 추정 / Estimate specific capability."""
        return self._capability_estimator.estimate(capability_name)

    def get_performance_trend(
        self, category: TaskCategory
    ) -> Dict[str, Any]:
        """성능 트렌드 반환 / Return performance trend."""
        return self._performance_monitor.get_trend(category)

    def get_stats(self) -> Dict[str, Any]:
        """전체 통계 반환 / Return full statistics."""
        return {
            "self_confidence": round(self._self_confidence, 4),
            "repository": self._repository.get_performance_stats(),
            "uncertainty": self._uncertainty_quantifier.get_stats(),
            "gap_detector": self._gap_detector.get_stats(),
        }

    # ------------------------------------------------------------------
    # Physical AGI Methods / Physical AGI 메서드
    # ------------------------------------------------------------------

    def assess_physical_capability(self, task_type: str) -> Dict[str, Any]:
        """
        물리적 작업 수행 능력 평가 / Assess whether the robot can physically accomplish a task.

        Physical AGI 핵심 메서드: 로봇이 특정 유형의 물리적 작업을 수행할 수
        있는지 평가합니다. 걷기, 파지, 운반, 조작 등 각 물리적 작업 유형에
        대해 현재 능력 수준, 필요 조건, 안전 여부를 종합 판단합니다.

        Physical AGI core method: assesses whether the robot can physically
        accomplish a task type (walking, gripping, lifting, crafting, etc.)
        based on its embodied experience and current physical capability state.

        Args:
            task_type: 작업 유형 (walking, gripping, lifting, crafting,
                terrain_navigation, precision_manipulation, force_control,
                balance, tool_use, social_interaction)

        Returns:
            Dict[str, Any]: 평가 결과
                - can_attempt (bool): 시도 가능 여부
                - success_probability (float): 성공 확률 0~1
                - physical_requirements (Dict): 필요 물리 조건
                - risk_level (float): 위험 수준 0~1
                - recommendation (str): 권장 행동
        """
        # 물리적 작업 유형별 능력 매핑 / Physical task-to-capability mapping
        task_capability_map: Dict[str, List[str]] = {
            "walking": ["navigation_indoor", "navigation_outdoor", "navigation_narrow"],
            "gripping": ["grasp_small_objects", "grasp_large_objects"],
            "lifting": ["grasp_large_objects", "precise_placement"],
            "crafting": ["new_skill_acquisition", "precise_placement", "grasp_small_objects"],
            "terrain_navigation": ["navigation_outdoor", "navigation_narrow", "obstacle_avoidance"],
            "precision_manipulation": ["precise_placement", "grasp_small_objects"],
            "force_control": ["grasp_large_objects", "obstacle_avoidance"],
            "balance": ["navigation_narrow", "obstacle_avoidance"],
            "tool_use": ["new_skill_acquisition", "grasp_small_objects", "concept_learning"],
            "social_interaction": ["natural_conversation", "task_explanation"],
        }

        required_caps = task_capability_map.get(task_type, [])
        if not required_caps:
            return {
                "can_attempt": False,
                "success_probability": 0.0,
                "physical_requirements": {},
                "risk_level": 1.0,
                "recommendation": f"알 수 없는 작업 유형: {task_type} / Unknown task type: {task_type}",
            }

        # 각 필요 능력 평가 / Assess each required capability
        cap_estimates = []
        weakest_cap = ""
        weakest_prob = 1.0
        for cap_name in required_caps:
            est = self._capability_estimator.estimate(cap_name)
            cap_estimates.append(est)
            if est.success_probability < weakest_prob:
                weakest_prob = est.success_probability
                weakest_cap = cap_name

        # 전체 성공 확률 / Overall success probability
        overall_prob = 1.0
        for est in cap_estimates:
            overall_prob *= est.success_probability
        overall_prob = max(0.0, min(1.0, overall_prob))

        # 위험 수준 산출 / Compute risk level
        risk_level = 1.0 - overall_prob

        # 필요 물리 조건 / Physical requirements
        physical_requirements: Dict[str, Any] = {
            "required_capabilities": required_caps,
            "weakest_capability": weakest_cap,
            "minimum_grip_force_N": 5.0 if "grasp" in task_type else 0.0,
            "minimum_balance_score": 0.6 if "terrain" in task_type or "balance" in task_type else 0.0,
            "minimum_precision_score": 0.5 if "precision" in task_type else 0.0,
        }

        # 권장 행동 / Recommendation
        can_attempt = overall_prob > 0.2
        if overall_prob > 0.7:
            recommendation = f"물리적 작업 수행 가능 / Physically capable: {task_type}"
        elif overall_prob > 0.4:
            recommendation = f"주의 필요, 취약 능력: {weakest_cap} / Caution: weak capability {weakest_cap}"
        elif overall_prob > 0.2:
            recommendation = f"위험, 인간 지원 권장 / Risky, human assistance recommended for {task_type}"
        else:
            recommendation = f"수행 불가, 능력 부족 / Incapable: insufficient physical ability for {task_type}"

        logger.info(
            "물리적 능력 평가: %s → 확률=%.2f, 위험=%.2f / Physical capability: %s → prob=%.2f, risk=%.2f",
            task_type, overall_prob, risk_level, task_type, overall_prob, risk_level,
        )

        return {
            "can_attempt": can_attempt,
            "success_probability": round(overall_prob, 4),
            "physical_requirements": physical_requirements,
            "risk_level": round(risk_level, 4),
            "recommendation": recommendation,
        }

    def check_physical_uncertainty(self) -> Dict[str, Any]:
        """
        물리적 불확실성 점검 / Check physical uncertainty across all physical skills.

        Physical AGI 핵심 메서드: 로봇의 모든 물리적 스킬 영역에서 불확실성을
        점검합니다. 불확실성이 높은 영역은 추가 물리적 연습이 필요함을
        의미합니다. 이 정보는 호기심 엔진과 연동되어 탐색 방향을 결정합니다.

        Physical AGI core method: checks uncertainty across all physical skill
        areas. High uncertainty indicates need for more physical practice.
        This information feeds into the curiosity engine to guide exploration.

        Returns:
            Dict[str, Any]: 물리적 불확실성 보고서
                - high_uncertainty_skills (List[str]): 불확실성이 높은 스킬
                - low_uncertainty_skills (List[str]): 불확실성이 낮은 스킬
                - average_physical_uncertainty (float): 평균 물리적 불확실성
                - practice_recommendations (List[str]): 연습 권장 사항
        """
        # 물리적 능력 목록 / Physical capability list
        physical_capabilities = [
            "navigation_indoor", "navigation_outdoor", "navigation_narrow",
            "grasp_small_objects", "grasp_large_objects", "precise_placement",
            "obstacle_avoidance", "new_skill_acquisition",
        ]

        high_uncertainty: List[str] = []
        low_uncertainty: List[str] = []
        uncertainties: List[float] = []

        for cap_name in physical_capabilities:
            est = self._capability_estimator.estimate(cap_name)
            # 불확실성 = 신뢰구간 폭 / Uncertainty = confidence interval width
            ci_width = est.confidence_interval[1] - est.confidence_interval[0]
            uncertainties.append(ci_width)

            if ci_width > 0.5:
                high_uncertainty.append(cap_name)
            elif ci_width < 0.2:
                low_uncertainty.append(cap_name)

        avg_uncertainty = sum(uncertainties) / max(len(uncertainties), 1)

        # 연습 권장 사항 생성 / Generate practice recommendations
        recommendations: List[str] = []
        for skill in high_uncertainty:
            if "navigation" in skill:
                recommendations.append(
                    f"{skill}: 다양한 지형에서 보행 연습 필요 / Practice walking on varied terrain"
                )
            elif "grasp" in skill:
                recommendations.append(
                    f"{skill}: 다양한 크기/형태 객체 파지 연습 필요 / Practice gripping varied objects"
                )
            elif "precise" in skill:
                recommendations.append(
                    f"{skill}: 정밀 조작 연습 필요 / Practice precise manipulation"
                )
            elif "obstacle" in skill:
                recommendations.append(
                    f"{skill}: 장애물 회피 훈련 필요 / Practice obstacle avoidance"
                )
            else:
                recommendations.append(
                    f"{skill}: 추가 물리적 연습 필요 / Additional physical practice needed"
                )

        result = {
            "high_uncertainty_skills": high_uncertainty,
            "low_uncertainty_skills": low_uncertainty,
            "average_physical_uncertainty": round(avg_uncertainty, 4),
            "practice_recommendations": recommendations,
        }

        logger.info(
            "물리적 불확실성 점검: 높음=%d, 낮음=%d, 평균=%.3f / "
            "Physical uncertainty: high=%d, low=%d, avg=%.3f",
            len(high_uncertainty), len(low_uncertainty), avg_uncertainty,
            len(high_uncertainty), len(low_uncertainty), avg_uncertainty,
        )
        return result


# ─── 진입점 / Entry Point ────────────────────────────────────────────────────


def main() -> None:
    """데모 실행 / Demo execution."""
    engine = MetacognitionEngine(db_path="/tmp/jihun_v84_metacognition.db")

    # 작업 평가 / Task assessment
    task = TaskDescriptor(
        category=TaskCategory.NAVIGATION,
        description="실내 복도 내비게이션",
        required_capabilities=["navigation_indoor", "obstacle_avoidance"],
        difficulty=0.3,
    )
    assessment = engine.assess_task(task)
    print("=== 작업 평가 ===")
    print(json.dumps(assessment, indent=2, default=str, ensure_ascii=False))

    # 결과 기록 / Record outcomes
    for _ in range(5):
        engine.record_outcome(
            capability_name="navigation_indoor",
            success=True,
            task_category=TaskCategory.NAVIGATION,
            execution_time=2.5,
            quality_score=0.8,
        )
    engine.record_outcome(
        capability_name="navigation_indoor",
        success=False,
        task_category=TaskCategory.NAVIGATION,
        execution_time=5.0,
        quality_score=0.2,
    )

    # 불확실성 정량화 / Quantify uncertainty
    cal_features = np.random.randn(100, 10)
    cal_preds = np.random.randn(100) * 0.5
    cal_targets = cal_preds + np.random.randn(100) * 0.1
    engine.calibrate_uncertainty(cal_features, cal_preds, cal_targets)

    test_features = np.random.randn(10)
    test_prediction = 0.7
    report = engine.quantify_uncertainty(test_features, test_prediction)
    print(f"\n=== 불확실성 보고서 ===")
    print(f"  인식적: {report.epistemic_uncertainty:.4f}")
    print(f"  우연적: {report.aleatoric_uncertainty:.4f}")
    print(f"  총: {report.total_uncertainty:.4f}")
    print(f"  신뢰도 수준: {report.confidence_level.value}")

    # 자기 인식 상태 / Self-awareness state
    state = engine.get_self_awareness_state()
    print(f"\n=== 자기 인식 ===")
    print(f"  자신감: {state['self_confidence']:.4f}")
    print(f"  강한 능력: {state['capabilities']['strong']}")
    print(f"  약한 능력: {state['capabilities']['weak']}")


# ============================================================================
# Deep Ensemble Epistemic Uncertainty + K-WIK Architecture
# ============================================================================
# 기존: z-score 휴리스틱 → 한계: 실제 불확실성과 무관
# 혁신 1: Deep Ensemble — 5개 모델 앙상블로 진정한 에피스템믹 불확실성 측정
# 혁신 2: K-WIK (Knows-What-It-Knows) — 지식 경계 명시적 표현
# 혁신 3: 자기 교정 캘리브레이션 — 예측 신뢰도가 실제 정확도와 일치
# ============================================================================

if TORCH_AVAILABLE:

    class DeepEnsembleUncertainty(nn.Module):
        """Deep Ensemble 에피스템믹 불확실성 추정기
        
        5개의 독립적으로 학습된 모델로 예측 분산을 계산하여
        "내가 모르는 것"을 정량화.
        
        Physical AGI에 필수: 불확실할 때 조심하고, 확실할 때 자신감 있게 행동.
        """
        
        def __init__(self, input_dim=62, hidden_dim=256, output_dim=1,
                     num_ensemble=5, dropout=0.1):
            super().__init__()
            self.num_ensemble = num_ensemble
            self.input_dim = input_dim
            self.output_dim = output_dim
            
            # 앙상블 멤버
            self.ensemble = nn.ModuleList([
                self._create_member(input_dim, hidden_dim, output_dim, dropout)
                for _ in range(num_ensemble)
            ])
        
        def _create_member(self, input_dim, hidden_dim, output_dim, dropout):
            """단일 앙상블 멤버 생성"""
            return nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, output_dim),
            )
        
        def forward(self, x, return_uncertainty=True):
            """앙상블 예측 + 불확실성
            
            Returns:
                dict: mean_prediction, epistemic_uncertainty, aleatoric_uncertainty, predictions
            """
            if isinstance(x, np.ndarray):
                x = torch.FloatTensor(x)
            if x.dim() == 1:
                x = x.unsqueeze(0)
            
            # 각 멤버의 예측 수집
            predictions = []
            for member in self.ensemble:
                pred = member(x)
                predictions.append(pred)
            
            predictions = torch.stack(predictions, dim=0)  # [ensemble, batch, output]
            
            # 평균 예측
            mean_pred = predictions.mean(dim=0)  # [batch, output]
            
            if return_uncertainty:
                # 에피스템믹 불확실성 (모델 간 분산)
                epistemic = predictions.var(dim=0)  # [batch, output]
                
                # 알렉토릭 불확실성 (평균 예측의 엔트로피 등)
                aleatoric = F.relu(mean_pred) * 0.1  # 간소화
                
                return {
                    'mean_prediction': mean_pred,
                    'epistemic_uncertainty': epistemic,
                    'aleatoric_uncertainty': aleatoric,
                    'total_uncertainty': epistemic + aleatoric,
                    'predictions': predictions,
                    'confidence': 1.0 / (1.0 + epistemic.mean()),
                }
            
            return mean_pred
        
        def predict_with_confidence(self, x, confidence_threshold=0.7):
            """신뢰도 기반 예측: 신뢰도가 낮으면 "모름" 반환"""
            result = self.forward(x)
            confidence = result['confidence'].item()
            
            if confidence < confidence_threshold:
                return {
                    'prediction': None,
                    'confidence': confidence,
                    'should_defer': True,  # 인간에게 결정 위임
                    'uncertainty_source': 'epistemic' if result['epistemic_uncertainty'].mean() > result['aleatoric_uncertainty'].mean() else 'aleatoric',
                }
            
            return {
                'prediction': result['mean_prediction'],
                'confidence': confidence,
                'should_defer': False,
                'uncertainty_source': None,
            }


class KWIKArchitecture:
    """K-WIK (Knows-What-It-Knows) 아키텍처
    
    로봇이 자신의 지식 경계를 명시적으로 표현:
    "이건 알아" (높은 신뢰도) vs "이건 몰라" (낮은 신뢰도)
    
    Physical AGI에 필수: 모르는 것을 모르는 상태(unknown unknowns) 방지.
    """
    
    def __init__(self, confidence_threshold=0.7, calibration_window=100,
                 domain_names=None):
        self.confidence_threshold = confidence_threshold
        self.calibration_window = calibration_window
        self.domain_names = domain_names or [
            'locomotion', 'manipulation', 'terrain', 'grasping',
            'navigation', 'tool_use', 'physical_reasoning', 'safety'
        ]
        
        # 도메인별 지식 상태
        self.knowledge_state = {
            domain: {
                'known_items': set(),
                'unknown_items': set(),
                'confidence_history': [],
                'calibration_error': 0.0,
                'boundary_examples': [],
            }
            for domain in self.domain_names
        }
        
        # 캘리브레이션 데이터
        self.calibration_data = {
            'predicted_confidence': [],
            'actual_accuracy': [],
        }
    
    def update_knowledge(self, domain, item_id, predicted_confidence, actual_success):
        """지식 상태 업데이트
        
        Args:
            domain: 지식 도메인
            item_id: 항목 ID (예: "wet_tile_terrain")
            predicted_confidence: 예측된 신뢰도
            actual_success: 실제 성공 여부
        """
        if domain not in self.knowledge_state:
            return
        
        state = self.knowledge_state[domain]
        
        # 지식 분류
        if predicted_confidence >= self.confidence_threshold and actual_success:
            state['known_items'].add(item_id)
            state['unknown_items'].discard(item_id)
        elif predicted_confidence >= self.confidence_threshold and not actual_success:
            # 과신(overconfidence) 감지
            state['unknown_items'].add(item_id)
            state['known_items'].discard(item_id)
            state['boundary_examples'].append({
                'item': item_id,
                'predicted': predicted_confidence,
                'actual': actual_success,
                'type': 'overconfident',
            })
        elif predicted_confidence < self.confidence_threshold:
            state['unknown_items'].add(item_id)
        
        # 캘리브레이션 데이터 누적
        state['confidence_history'].append({
            'predicted': predicted_confidence,
            'actual': float(actual_success),
        })
        
        # 캘리브레이션 오차 계산
        if len(state['confidence_history']) >= 10:
            self._compute_calibration(domain)
    
    def _compute_calibration(self, domain):
        """캘리브레이션 오차 계산 (ECE - Expected Calibration Error)"""
        history = self.knowledge_state[domain]['confidence_history']
        
        # 구간별 캘리브레이션
        n_bins = 10
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        
        ece = 0.0
        total = len(history)
        
        for i in range(n_bins):
            lower = bin_boundaries[i]
            upper = bin_boundaries[i + 1]
            
            bin_items = [
                h for h in history
                if lower <= h['predicted'] < upper
            ]
            
            if bin_items:
                avg_confidence = np.mean([h['predicted'] for h in bin_items])
                avg_accuracy = np.mean([h['actual'] for h in bin_items])
                bin_weight = len(bin_items) / total
                ece += bin_weight * abs(avg_confidence - avg_accuracy)
        
        self.knowledge_state[domain]['calibration_error'] = ece
    
    def get_knowledge_boundary(self, domain):
        """지식 경계 반환: 알고 있는 것과 모르는 것의 경계"""
        if domain not in self.knowledge_state:
            return None
        
        state = self.knowledge_state[domain]
        return {
            'known_count': len(state['known_items']),
            'unknown_count': len(state['unknown_items']),
            'calibration_error': state['calibration_error'],
            'boundary_examples': state['boundary_examples'][-10:],
            'knowledge_ratio': len(state['known_items']) / max(
                len(state['known_items']) + len(state['unknown_items']), 1
            ),
        }
    
    def should_explore(self, domain, candidate_items):
        """탐색 우선순위: 지식 경계 근처 항목 우선 탐색"""
        if domain not in self.knowledge_state:
            return candidate_items
        
        unknown = self.knowledge_state[domain]['unknown_items']
        priority_items = [item for item in candidate_items if item in unknown]
        
        return priority_items if priority_items else candidate_items


class ConfidenceCalibrator:
    """자기 교정 캘리브레이터
    
    예측 신뢰도가 실제 정확도와 일치하도록 교정.
    온도 스케일링(Platt scaling) + 등방 회귀(isotonic regression).
    """
    
    def __init__(self, method='temperature_scaling'):
        self.method = method
        self.temperature = 1.0  # For temperature scaling
        self.isotonic_regressor = None  # For isotonic regression
        self.calibrated = False
    
    def calibrate(self, confidences, accuracies):
        """캘리브레이션 수행
        
        Args:
            confidences: 예측 신뢰도 리스트
            accuracies: 실제 정확도 리스트 (0 or 1)
        """
        confidences = np.array(confidences)
        accuracies = np.array(accuracies)
        
        if self.method == 'temperature_scaling':
            self._fit_temperature(confidences, accuracies)
        elif self.method == 'isotonic':
            self._fit_isotonic(confidences, accuracies)
        
        self.calibrated = True
    
    def _fit_temperature(self, confidences, accuracies):
        """온도 스케일링: logit → logit/T"""
        if SCIPY_AVAILABLE:
            from scipy.optimize import minimize_scalar
            
            logits = np.log(confidences / (1 - confidences + 1e-8))
            
            def nll(T):
                scaled_logits = logits / T
                scaled_probs = 1 / (1 + np.exp(-scaled_logits))
                nll = -np.mean(
                    accuracies * np.log(scaled_probs + 1e-8) +
                    (1 - accuracies) * np.log(1 - scaled_probs + 1e-8)
                )
                return nll
            
            result = minimize_scalar(nll, bounds=(0.1, 10.0), method='bounded')
            self.temperature = result.x
        else:
            # Fallback: simple heuristic
            self.temperature = 1.0
    
    def _fit_isotonic(self, confidences, accuracies):
        """등방 회귀"""
        try:
            from sklearn.isotonic import IsotonicRegression
            self.isotonic_regressor = IsotonicRegression(out_of_bounds='clip')
            self.isotonic_regressor.fit(confidences, accuracies)
        except ImportError:
            # sklearn 없으면 온도 스케일링으로 대체
            self._fit_temperature(confidences, accuracies)
            self.method = 'temperature_scaling'
    
    def calibrate_confidence(self, confidence):
        """신뢰도 교정"""
        if not self.calibrated:
            return confidence
        
        if self.method == 'temperature_scaling':
            logit = np.log(confidence / (1 - confidence + 1e-8))
            calibrated_logit = logit / self.temperature
            return 1 / (1 + np.exp(-calibrated_logit))
        
        elif self.method == 'isotonic' and self.isotonic_regressor is not None:
            return float(self.isotonic_regressor.predict([confidence])[0])
        
        return confidence


# Need scipy for ConfidenceCalibrator
try:
    import scipy
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False


if __name__ == "__main__":
    main()


# ═══════════════════════════════════════════════════════════════════════════
# V8.5 Physical AGI 추가 클래스 / V8.5 Physical AGI Additional Classes
# ═══════════════════════════════════════════════════════════════════════════


class PhysicalMetacognition:
    """
    물리적 메타인지 / Physical Metacognition.

    로봇이 자신의 물리적 능력과 한계를 인식합니다.
    "이 지형을 걸을 수 있는가?", "이 물체를 잡을 수 있는가?",
    "이 무게를 들 수 있는가?" — 모든 자기 지식은
    실제 물리적 경험에서 비롯됩니다.

    핵심 개념:
        메타인지는 "자신이 무엇을 할 수 있고 무엇을 할 수 없는지 아는 것"입니다.
        물리적 메타인지는 특히 로봇의 안전과 효율성에 중요합니다.

    Usage:
        meta = PhysicalMetacognition()
        meta.record_outcome("walk_on_ice", success=False, confidence=0.3)
        assessment = meta.assess_capability("walk_on_ice")
        should_proceed = meta.should_attempt("walk_on_ice", risk_tolerance=0.3)
    """

    # 물리적 능력 카테고리 / Physical capability categories
    PHYSICAL_CAPABILITIES = {
        "locomotion": [
            "walk_flat", "walk_rough", "walk_slope", "walk_stairs",
            "walk_wet", "walk_ice", "walk_narrow", "run_flat",
        ],
        "manipulation": [
            "grasp_small", "grasp_large", "grasp_fragile",
            "precision_place", "tool_use", "insertion",
        ],
        "carrying": [
            "carry_light", "carry_medium", "carry_heavy",
            "carry_on_slope", "carry_on_stairs",
        ],
        "craftwork": [
            "simple_assembly", "precise_cutting", "gluing",
            "sanding", "painting",
        ],
    }

    def __init__(
        self,
        capability_estimator: Optional[CapabilityEstimator] = None,
        confidence_threshold: float = 0.4,
        safety_margin: float = 0.2,
    ) -> None:
        """
        Args:
            capability_estimator: 능력 추정기 (없으면 자동 생성)
            confidence_threshold: 시도 여부 결정 임계값
            safety_margin: 안전 여유 (이 값만큼 보수적으로 판단)
        """
        self._capability_estimator = capability_estimator or CapabilityEstimator()
        self._confidence_threshold = confidence_threshold
        self._safety_margin = safety_margin

        # 물리적 경험 기록 / Physical experience records
        self._physical_outcomes: Dict[str, Deque[Dict[str, Any]]] = {}
        self._capability_models: Dict[str, Dict[str, float]] = {}

        # 안전 규칙 / Safety rules
        self._safety_rules: List[Dict[str, Any]] = []
        self._init_safety_rules()

        self._lock = threading.Lock()

        logger.info(
            "PhysicalMetacognition 초기화: confidence_threshold=%.2f, safety_margin=%.2f",
            confidence_threshold, safety_margin,
        )

    def _init_safety_rules(self) -> None:
        """기본 안전 규칙 초기화 / Initialize default safety rules."""
        self._safety_rules = [
            {"condition": "predicted_fall_probability > 0.3", "action": "stop", "severity": "critical"},
            {"condition": "predicted_slip_probability > 0.5", "action": "slow_down", "severity": "high"},
            {"condition": "grip_confidence < 0.4", "action": "increase_grip_force", "severity": "medium"},
            {"condition": "stability_margin < 0.2", "action": "stabilize", "severity": "critical"},
            {"condition": "object_weight > max_carry_weight", "action": "refuse", "severity": "critical"},
        ]

    def record_outcome(
        self,
        task: str,
        success: bool,
        confidence: float = 0.5,
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        물리적 수행 결과 기록 / Record a physical task outcome.

        Args:
            task: 작업 이름
            success: 성공 여부
            confidence: 수행 전 자신감
            context: 추가 컨텍스트 (지형, 물체 특성 등)
        """
        outcome = {
            "task": task,
            "success": success,
            "confidence": confidence,
            "overconfident": confidence > 0.7 and not success,
            "underconfident": confidence < 0.3 and success,
            "context": context or {},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        with self._lock:
            if task not in self._physical_outcomes:
                self._physical_outcomes[task] = deque(maxlen=100)
            self._physical_outcomes[task].append(outcome)

        # 능력 추정기 업데이트 / Update capability estimator
        self._capability_estimator.record_outcome(task, success)

        # 능력 모델 업데이트 / Update capability model
        self._update_capability_model(task, success, confidence)

        # 과신 감지 / Detect overconfidence
        if outcome["overconfident"]:
            logger.warning(
                "물리적 과신 감지: task='%s', confidence=%.2f but failed",
                task, confidence,
            )

    def _update_capability_model(
        self, task: str, success: bool, confidence: float
    ) -> None:
        """능력 모델 업데이트 / Update internal capability model."""
        with self._lock:
            if task not in self._capability_models:
                self._capability_models[task] = {
                    "success_rate": 0.5,
                    "avg_confidence": 0.5,
                    "calibration_error": 0.0,
                    "n_attempts": 0,
                }

            model = self._capability_models[task]
            n = model["n_attempts"] + 1
            alpha = 1.0 / n

            # 성공률 업데이트 / Update success rate
            model["success_rate"] = (1 - alpha) * model["success_rate"] + alpha * float(success)
            # 평균 자신감 업데이트 / Update average confidence
            model["avg_confidence"] = (1 - alpha) * model["avg_confidence"] + alpha * confidence
            # 보정 오차 (자신감과 실제 성공률의 차이) / Calibration error
            model["calibration_error"] = abs(model["avg_confidence"] - model["success_rate"])
            model["n_attempts"] = n

    def assess_capability(self, task: str) -> Dict[str, Any]:
        """
        물리적 능력 평가 / Assess physical capability for a task.

        Args:
            task: 작업 이름

        Returns:
            능력 평가 결과
        """
        with self._lock:
            model = self._capability_models.get(task, None)
            cap_est = self._capability_estimator.estimate(task)

        if model is None:
            return {
                "task": task,
                "known": False,
                "estimated_success_rate": cap_est.success_probability,
                "confidence_interval": cap_est.confidence_interval,
                "recommendation": "데이터 부족 — 조심스럽게 시도하며 데이터 수집 권장",
            }

        # 보정된 성공 확률 / Calibrated success probability
        calibrated = model["success_rate"] - self._safety_margin
        calibrated = max(0.0, calibrated)

        # 보정 오차에 따른 신뢰도 / Reliability based on calibration error
        calibration = model["calibration_error"]
        reliability = max(0.0, 1.0 - calibration)

        return {
            "task": task,
            "known": True,
            "estimated_success_rate": round(model["success_rate"], 3),
            "calibrated_success_rate": round(calibrated, 3),
            "calibration_error": round(calibration, 3),
            "reliability": round(reliability, 3),
            "n_attempts": model["n_attempts"],
            "bayesian_estimate": cap_est.success_probability,
        }

    def should_attempt(
        self, task: str, risk_tolerance: float = 0.3
    ) -> Dict[str, Any]:
        """
        작업 시도 여부 결정 / Decide whether to attempt a physical task.

        Args:
            task: 작업 이름
            risk_tolerance: 위험 감수 수준 (0=보수적, 1=공격적)

        Returns:
            시도 여부와 이유
        """
        assessment = self.assess_capability(task)
        calibrated = assessment.get("calibrated_success_rate", 0.5)

        # 위험 감수 수준에 따른 임계값 조정 / Adjust threshold by risk tolerance
        threshold = self._confidence_threshold * (1.0 - risk_tolerance)

        should = calibrated >= threshold

        if should:
            reason = f"예상 성공률 {calibrated:.1%} ≥ 임계값 {threshold:.1%}"
            recommendation = "진행 가능"
        else:
            reason = f"예상 성공률 {calibrated:.1%} < 임계값 {threshold:.1%}"
            if calibrated < 0.2:
                recommendation = "위험 — 인간 도움 필요"
            elif calibrated < threshold:
                recommendation = "주의 — 더 쉬운 연습 먼저 수행"
            else:
                recommendation = "신중하게 시도"

        return {
            "task": task,
            "should_attempt": should,
            "calibrated_success_rate": round(calibrated, 3),
            "threshold": round(threshold, 3),
            "reason": reason,
            "recommendation": recommendation,
        }

    def get_safety_assessment(
        self, context: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        안전 평가 / Assess safety of a physical situation.

        Args:
            context: 현재 물리적 상황 (fall_prob, slip_prob 등)

        Returns:
            안전 평가 결과
        """
        violations = []

        # 안전 규칙 검사 / Check safety rules
        for rule in self._safety_rules:
            condition = rule["condition"]
            violated = self._evaluate_safety_condition(condition, context)
            if violated:
                violations.append({
                    "rule": condition,
                    "action": rule["action"],
                    "severity": rule["severity"],
                })

        # 최대 심각도 / Maximum severity
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        max_severity = "low"
        if violations:
            max_severity = min(
                (v["severity"] for v in violations),
                key=lambda s: severity_order.get(s, 4),
            )

        return {
            "safe": len(violations) == 0 or max_severity in ("low", "medium"),
            "violations": violations,
            "max_severity": max_severity,
            "recommended_action": violations[0]["action"] if violations else "proceed",
        }

    def _evaluate_safety_condition(
        self, condition: str, context: Dict[str, float]
    ) -> bool:
        """안전 규칙 조건 평가 / Evaluate a safety rule condition."""
        # 간소화된 조건 파싱 / Simplified condition parsing
        if "fall_probability > " in condition:
            threshold = float(condition.split("> ")[1])
            return context.get("fall_probability", 0) > threshold
        if "slip_probability > " in condition:
            threshold = float(condition.split("> ")[1])
            return context.get("slip_probability", 0) > threshold
        if "grip_confidence < " in condition:
            threshold = float(condition.split("< ")[1])
            return context.get("grip_confidence", 1) < threshold
        if "stability_margin < " in condition:
            threshold = float(condition.split("< ")[1])
            return context.get("stability_margin", 1) < threshold
        if "object_weight > max_carry_weight" in condition:
            return context.get("object_weight", 0) > context.get("max_carry_weight", 10)
        return False

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        with self._lock:
            total_tasks = len(self._capability_models)
            well_calibrated = sum(
                1 for m in self._capability_models.values()
                if m["calibration_error"] < 0.2 and m["n_attempts"] >= 5
            )
            overconfident_tasks = sum(
                1 for m in self._capability_models.values()
                if m["avg_confidence"] > model["success_rate"] + 0.2
                for model in [m]  # 편법 / trick for nested access
            ) if self._capability_models else 0

            return {
                "total_tasks_tracked": total_tasks,
                "well_calibrated_tasks": well_calibrated,
                "total_experiences": sum(
                    len(v) for v in self._physical_outcomes.values()
                ),
            }


class ConfidenceCalibration:
    """
    신뢰도 보정 / Confidence Calibration.

    로봇의 자신감(예측 신뢰도)이 실제 성능과 일치하도록 보정합니다.
    잘 보정된 로봇은 "90% 확신한다"고 말할 때 실제로 90% 성공합니다.

    보정 방법:
        1. 온도 스케일링 (Temperature Scaling): 간단하고 효과적
        2. 등위 보정 (Isotonic Regression): 더 정확하지만 복잡
        3. Platt Scaling: 로지스틱 보정

    Usage:
        calibrator = ConfidenceCalibration()
        calibrator.update(true_label=True, predicted_confidence=0.7)
        calibrated = calibrator.calibrate(0.7)
    """

    def __init__(self, method: str = "temperature_scaling") -> None:
        """
        Args:
            method: 보정 방법 ("temperature_scaling", "histogram", "platt")
        """
        self._method = method
        self._temperature = 1.0  # 온도 파라미터 (1.0=보정 없음)
        self._platt_a = 1.0     # Platt scaling a
        self._platt_b = 0.0     # Platt scaling b

        # 보정 데이터 / Calibration data
        self._confidences: Deque[float] = deque(maxlen=5000)
        self._accuracies: Deque[float] = deque(maxlen=5000)

        # 히스토그램 보정 / Histogram binning
        self._n_bins = 10
        self._bin_confidences: List[List[float]] = [[] for _ in range(self._n_bins)]
        self._calibrated = False

        self._lock = threading.Lock()

        logger.info("ConfidenceCalibration 초기화: method='%s'", method)

    def update(
        self, true_label: bool, predicted_confidence: float
    ) -> None:
        """
        보정 데이터 업데이트 / Update calibration with a new observation.

        Args:
            true_label: 실제 결과 (성공=True)
            predicted_confidence: 예측된 신뢰도 (0~1)
        """
        with self._lock:
            self._confidences.append(predicted_confidence)
            self._accuracies.append(1.0 if true_label else 0.0)

            # 히스토그램 빈 업데이트 / Update histogram bin
            bin_idx = min(int(predicted_confidence * self._n_bins), self._n_bins - 1)
            self._bin_confidences[bin_idx].append(1.0 if true_label else 0.0)

        # 50개마다 재보정 / Re-calibrate every 50 updates
        if len(self._confidences) % 50 == 0:
            self._fit()

    def _fit(self) -> None:
        """보정 모델 학습 / Fit calibration model."""
        with self._lock:
            if len(self._confidences) < 20:
                return

            confs = np.array(self._confidences)
            accs = np.array(self._accuracies)

            if self._method == "temperature_scaling":
                self._fit_temperature(confs, accs)
            elif self._method == "platt":
                self._fit_platt(confs, accs)
            # histogram은 실시간 업데이트만 사용 / Histogram uses real-time updates only

            self._calibrated = True

    def _fit_temperature(self, confs: np.ndarray, accs: np.ndarray) -> None:
        """온도 스케일링 학습 / Fit temperature scaling."""
        # NLL 최소화로 최적 온도 찾기 / Find optimal temperature by minimizing NLL
        best_temp = 1.0
        best_nll = float('inf')

        for temp in np.linspace(0.1, 5.0, 50):
            scaled = self._scale_with_temperature(confs, temp)
            # NLL = -[y*log(p) + (1-y)*log(1-p)]
            nll = -np.mean(
                accs * np.log(scaled + 1e-8)
                + (1 - accs) * np.log(1 - scaled + 1e-8)
            )
            if nll < best_nll:
                best_nll = nll
                best_temp = temp

        self._temperature = best_temp
        logger.debug("온도 스케일링 학습: T=%.3f", self._temperature)

    def _fit_platt(self, confs: np.ndarray, accs: np.ndarray) -> None:
        """Platt scaling 학습 / Fit Platt scaling (logistic calibration)."""
        # 간소화된 Platt scaling / Simplified Platt scaling
        logits = np.log(confs / (1 - confs + 1e-8))
        # 로지스틱 회귀로 a, b 찾기 / Find a, b via logistic regression
        from numpy.linalg import lstsq
        X = np.column_stack([logits, np.ones(len(logits))])
        try:
            result = lstsq(X, accs, rcond=None)
            self._platt_a = float(result[0][0])
            self._platt_b = float(result[0][1])
        except Exception:
            self._platt_a = 1.0
            self._platt_b = 0.0

    def calibrate(self, confidence: float) -> float:
        """
        신뢰도 보정 / Calibrate a confidence value.

        Args:
            confidence: 원시 신뢰도 (0~1)

        Returns:
            보정된 신뢰도 (0~1)
        """
        if not self._calibrated:
            return confidence

        if self._method == "temperature_scaling":
            return self._scale_with_temperature(np.array([confidence]), self._temperature)[0]
        elif self._method == "platt":
            logit = self._platt_a * np.log(confidence / (1 - confidence + 1e-8)) + self._platt_b
            return float(1.0 / (1.0 + np.exp(-logit)))
        elif self._method == "histogram":
            return self._histogram_calibrate(confidence)

        return confidence

    def _scale_with_temperature(
        self, confs: np.ndarray, temperature: float
    ) -> np.ndarray:
        """온도 스케일링 적용 / Apply temperature scaling."""
        logits = np.log(confs / (1 - confs + 1e-8)) / temperature
        return 1.0 / (1.0 + np.exp(-logits))

    def _histogram_calibrate(self, confidence: float) -> float:
        """히스토그램 보정 / Apply histogram binning calibration."""
        bin_idx = min(int(confidence * self._n_bins), self._n_bins - 1)
        bin_data = self._bin_confidences[bin_idx]
        if len(bin_data) >= 5:
            return float(np.mean(bin_data))
        return confidence  # 데이터 부족 시 원래 값 반환

    def get_calibration_error(self) -> float:
        """
        보정 오차(ECE) 계산 / Compute Expected Calibration Error.

        Returns:
            ECE 값 (0=완벽 보정, 1=최악)
        """
        with self._lock:
            if len(self._confidences) < 20:
                return 1.0

            confs = np.array(self._confidences)
            accs = np.array(self._accuracies)

            ece = 0.0
            for i in range(self._n_bins):
                lower = i / self._n_bins
                upper = (i + 1) / self._n_bins
                mask = (confs >= lower) & (confs < upper)
                n = mask.sum()
                if n > 0:
                    avg_conf = confs[mask].mean()
                    avg_acc = accs[mask].mean()
                    ece += n * abs(avg_acc - avg_conf)
            ece /= len(confs)

            return round(float(ece), 4)

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        return {
            "method": self._method,
            "calibrated": self._calibrated,
            "temperature": round(self._temperature, 4),
            "ece": self.get_calibration_error(),
            "n_samples": len(self._confidences),
        }


class AskingForHelp:
    """
    도움 요청 시스템 / Asking For Help System.

    로봇이 언제 인간의 도움을 요청해야 하는지 인식합니다.
    불확실성이 높거나, 과거에 실패한 작업이거나, 안전 위험이
    있을 때 적절히 도움을 요청합니다.

    핵심 원칙:
        - 도움 요청은 실패가 아님, 현명한 판단입니다
        - 너무 자주 요청하면 비효율적, 너무 안 하면 위험
        - 적절한 타이밍과 적절한 종류의 도움 요청이 중요

    Usage:
        helper = AskingForHelp()
        helper.record_outcome("lift_heavy", success=False, asked_for_help=False)
        decision = helper.should_ask_for_help("lift_heavy", confidence=0.3)
    """

    # 도움 요청 레벨 / Help request levels
    class HelpLevel(str, Enum):
        """도움 요청 수준 / Help request level."""
        NONE = "none"                  # 도움 불필요
        HINT = "hint"                  # 힌트만 필요
        GUIDANCE = "guidance"          # 가이드 필요
        ASSISTANCE = "assistance"      # 물리적 보조 필요
        TAKEOVER = "takeover"          # 인간이 직접 수행

    def __init__(
        self,
        confidence_threshold: float = 0.3,
        failure_streak_threshold: int = 3,
        safety_risk_threshold: float = 0.5,
        max_help_requests_per_hour: int = 10,
    ) -> None:
        """
        Args:
            confidence_threshold: 이 이하면 도움 요청 고려
            failure_streak_threshold: 연속 실패 시 도움 요청
            safety_risk_threshold: 안전 위험도 임계값
            max_help_requests_per_hour: 시간당 최대 도움 요청 수
        """
        self._confidence_threshold = confidence_threshold
        self._failure_streak_threshold = failure_streak_threshold
        self._safety_risk_threshold = safety_risk_threshold
        self._max_help_per_hour = max_help_requests_per_hour

        # 작업별 기록 / Per-task records
        self._task_history: Dict[str, Deque[Dict[str, Any]]] = {}
        self._current_failure_streaks: Dict[str, int] = {}

        # 도움 요청 기록 / Help request records
        self._help_requests: List[Dict[str, Any]] = []
        self._recent_requests: Deque[float] = deque(maxlen=100)  # timestamps

        self._lock = threading.Lock()

        logger.info(
            "AskingForHelp 초기화: conf_threshold=%.2f, failure_streak=%d",
            confidence_threshold, failure_streak_threshold,
        )

    def record_outcome(
        self,
        task: str,
        success: bool,
        asked_for_help: bool = False,
        confidence: float = 0.5,
        safety_risk: float = 0.0,
    ) -> None:
        """
        작업 결과 기록 / Record a task outcome.

        Args:
            task: 작업 이름
            success: 성공 여부
            asked_for_help: 도움을 요청했는지
            confidence: 수행 전 자신감
            safety_risk: 안전 위험도 (0~1)
        """
        record = {
            "task": task,
            "success": success,
            "asked_for_help": asked_for_help,
            "confidence": confidence,
            "safety_risk": safety_risk,
            "timestamp": time.time(),
        }

        with self._lock:
            if task not in self._task_history:
                self._task_history[task] = deque(maxlen=50)
            self._task_history[task].append(record)

            # 연속 실패 추적 / Track failure streak
            if success:
                self._current_failure_streaks[task] = 0
            else:
                self._current_failure_streaks[task] = (
                    self._current_failure_streaks.get(task, 0) + 1
                )

    def should_ask_for_help(
        self,
        task: str,
        confidence: float = 0.5,
        safety_risk: float = 0.0,
        time_pressure: float = 0.0,
    ) -> Dict[str, Any]:
        """
        도움 요청 여부 결정 / Decide whether to ask for human help.

        Args:
            task: 작업 이름
            confidence: 현재 자신감 (0~1)
            safety_risk: 안전 위험도 (0~1)
            time_pressure: 시간 압박 (0=여유, 1=긴급)

        Returns:
            도움 요청 결정
        """
        with self._lock:
            help_level = self.HelpLevel.NONE
            reasons: List[str] = []

            # 1. 자신감 기반 판단 / Confidence-based decision
            if confidence < self._confidence_threshold * 0.5:
                help_level = self.HelpLevel.ASSISTANCE
                reasons.append(f"매우 낮은 자신감 ({confidence:.1%})")
            elif confidence < self._confidence_threshold:
                help_level = self.HelpLevel.GUIDANCE
                reasons.append(f"낮은 자신감 ({confidence:.1%})")
            elif confidence < self._confidence_threshold * 1.5:
                help_level = self.HelpLevel.HINT
                reasons.append(f"보통 자신감 ({confidence:.1%})")

            # 2. 연속 실패 기반 / Failure streak-based
            streak = self._current_failure_streaks.get(task, 0)
            if streak >= self._failure_streak_threshold:
                if help_level.value < self.HelpLevel.ASSISTANCE.value:
                    help_level = self.HelpLevel.ASSISTANCE
                reasons.append(f"연속 {streak}회 실패")

            # 3. 안전 위험 기반 / Safety risk-based
            if safety_risk > self._safety_risk_threshold:
                help_level = self.HelpLevel.TAKEOVER
                reasons.append(f"높은 안전 위험 ({safety_risk:.1%})")
            elif safety_risk > self._safety_risk_threshold * 0.7:
                if help_level.value < self.HelpLevel.ASSISTANCE.value:
                    help_level = self.HelpLevel.ASSISTANCE
                reasons.append(f"보통 안전 위험 ({safety_risk:.1%})")

            # 4. 시간 압박 / Time pressure
            if time_pressure > 0.7 and help_level == self.HelpLevel.NONE:
                help_level = self.HelpLevel.HINT
                reasons.append("시간 압박으로 힌트 요청")

            # 5. 도움 요청 빈도 제한 / Rate limit help requests
            recent_count = self._count_recent_requests(window_seconds=3600)
            if recent_count >= self._max_help_per_hour:
                help_level = self.HelpLevel.NONE
                reasons = ["시간당 최대 도움 요청 수 초과 — 자율 해결 시도"]

            # 도움 요청 기록 / Record help request
            if help_level != self.HelpLevel.NONE:
                self._help_requests.append({
                    "task": task,
                    "level": help_level.value,
                    "confidence": confidence,
                    "safety_risk": safety_risk,
                    "reasons": reasons,
                    "timestamp": time.time(),
                })
                self._recent_requests.append(time.time())

        return {
            "task": task,
            "should_ask": help_level != self.HelpLevel.NONE,
            "help_level": help_level.value,
            "reasons": reasons,
            "suggested_message": self._generate_help_message(task, help_level, reasons),
        }

    def _count_recent_requests(self, window_seconds: int = 3600) -> int:
        """최근 도움 요청 수 / Count recent help requests."""
        now = time.time()
        return sum(1 for ts in self._recent_requests if now - ts < window_seconds)

    def _generate_help_message(
        self, task: str, level: "AskingForHelp.HelpLevel", reasons: List[str]
    ) -> str:
        """도움 요청 메시지 생성 / Generate help request message."""
        if level == self.HelpLevel.HINT:
            return f"'{task}' 작업에 대한 힌트가 필요합니다. 이유: {', '.join(reasons)}"
        elif level == self.HelpLevel.GUIDANCE:
            return f"'{task}' 작업을 수행하는 방법을 가이드해주세요. 이유: {', '.join(reasons)}"
        elif level == self.HelpLevel.ASSISTANCE:
            return f"'{task}' 작업에 물리적 보조가 필요합니다. 이유: {', '.join(reasons)}"
        elif level == self.HelpLevel.TAKEOVER:
            return f"안전! '{task}' 작업을 인간이 직접 수행해주세요. 이유: {', '.join(reasons)}"
        return ""

    def get_stats(self) -> Dict[str, Any]:
        """통계 반환 / Return statistics."""
        with self._lock:
            return {
                "total_help_requests": len(self._help_requests),
                "tasks_tracked": len(self._task_history),
                "recent_requests_1h": self._count_recent_requests(3600),
                "by_level": {
                    level.value: sum(
                        1 for r in self._help_requests if r["level"] == level.value
                    )
                    for level in self.HelpLevel
                    if level != self.HelpLevel.NONE
                },
            }
