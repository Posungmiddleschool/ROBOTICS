#!/usr/bin/env python3
"""
지훈 로봇 V8.5 — 수면 학습 시스템 / Sleep Learning System
========================================================

V8.5 → V8.5 업그레이드:
  - 꿈 시뮬레이션 통합 (DreamSimulator)
  - 세계지식 통합 (수면 중 세계 데이터를 메모리에 통합)
  - 인과 관계 추출 (수면 중 인과 관계 발견)
  - 반사실적 추론 ("만약 X를 했다면?")
  - 향상된 EWC: 다중 작업 Fisher 행렬 (세계지식 + 툴 콜링 보호)
  - 수면 단계: DREAM (LORA_UPDATE 후 신규)
  - ContinuousLearner와의 통합 (온라인→오프라인 원활 전환)
  - 향상된 합성 데이터: 세계 모델 기반 생성
  - 수면 간격: 300s → 180s (더 자주, 더 짧은 세션)

유휴 시간: 수면 학습 세션 3분마다 실행
과정: 경험 재생(35%) → 합성 데이터(20%) → 스킬 학습 → LoRA 업데이트 → 꿈 시뮬레이션(15%)

EWC: LoRA 가중치 업데이트 시 치명적 망각 방지 (다중 작업 Fisher)

검증: 수면 학습 후 ≥1개 새 스킬 학습 또는 기존 스킬 성공률 향상

버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import copy
import json
import logging
import os
import random
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("jihun.v84.sleep_learning")
logger.setLevel(logging.INFO)


# ──────────────────────────────────────────────────────────────────────────────
# 상수 / Constants
# ──────────────────────────────────────────────────────────────────────────────

SLEEP_INTERVAL_S = 180.0           # V8: 300→180 수면 학습 간격 (3분)
REPLAY_BUDGET_RATIO = 0.35         # V8: 경험 재생 시간 비율 (40→35%)
SYNTHETIC_BUDGET_RATIO = 0.20      # V8: 합성 데이터 생성 비율 (30→20%)
DREAM_BUDGET_RATIO = 0.15          # V8: 꿈 시뮬레이션 비율 (신규)
MIN_SLEEP_DURATION_S = 20.0        # V8: 30→20 최소 수면 학습 지속 시간
MAX_SLEEP_DURATION_S = 180.0       # V8: 300→180 최대 수면 학습 지속 시간

DEFAULT_DB_PATH = Path(
    os.getenv("SLEEP_LEARNING_DB_PATH", "/home/jihun/data/sleep_learning.db")
)

# EWC (Elastic Weight Consolidation) 파라미터 — V8: 다중 작업
EWC_LAMBDA = 1000.0                # EWC 정규화 강도
EWC_FISHER_SAMPLE_SIZE = 100       # Fisher 정보 행렬 샘플 수
EWC_MULTI_TASK_WEIGHTS = {         # V8: 작업별 EWC 가중치
    "tool_calling": 1.0,           # 툴 콜링 — 기본 보호
    "world_knowledge": 0.8,        # 세계지식 — 높은 보호
    "skill_execution": 0.9,        # 스킬 실행 — 높은 보호
    "conversation": 0.6,           # 대화 — 보통 보호
    "causal_reasoning": 0.7,       # 인과 추론 — 높은 보호
}


class SleepPhase(Enum):
    """수면 학습 단계 — V8: DREAM 추가"""
    AWAKE = "awake"                 # 활동 중
    REPLAY = "replay"               # 경험 재생
    SYNTHESIS = "synthesis"         # 합성 데이터 생성
    SKILL_LEARNING = "skill_learning"  # 스킬 학습
    LORA_UPDATE = "lora_update"     # LoRA 가중치 업데이트
    DREAM = "dream"                 # V8: 꿈 시뮬레이션
    WORLD_KNOWLEDGE = "world_knowledge"  # V8: 세계지식 통합
    CAUSAL_EXTRACTION = "causal_extraction"  # V8: 인과 추출
    COMPLETE = "complete"           # 완료


@dataclass
class SleepSession:
    """수면 학습 세션 기록 — V8: 추가 필드"""
    session_id: str = ""
    start_time: float = field(default_factory=time.time)
    end_time: float = 0.0
    phase: SleepPhase = SleepPhase.AWAKE
    experiences_replayed: int = 0
    synthetic_data_generated: int = 0
    skills_learned: int = 0
    skills_improved: int = 0
    lora_updated: bool = False
    duration_s: float = 0.0
    # V8.5 신규 필드
    dream_simulations: int = 0             # 꿈 시뮬레이션 수
    causal_relations_found: int = 0        # 발견된 인과 관계
    counterfactual_scenarios: int = 0      # 반사실적 시나리오 수
    world_knowledge_integrated: int = 0    # 통합된 세계지식 수
    innovations_discovered: int = 0        # 발견된 혁신 수

    def __post_init__(self):
        if not self.session_id:
            self.session_id = f"sleep_{int(self.start_time * 1000)}"


@dataclass
class EWCState:
    """EWC (Elastic Weight Consolidation) 상태 — V8: 다중 작업 Fisher"""
    fisher_matrix: Dict[str, List[float]] = field(default_factory=dict)
    optimal_params: Dict[str, List[float]] = field(default_factory=dict)
    lambda_ewc: float = EWC_LAMBDA
    last_update: float = 0.0
    # V8: 다중 작업 Fisher 행렬
    task_fisher_matrices: Dict[str, Dict[str, List[float]]] = field(
        default_factory=dict
    )


@dataclass
class CounterfactualResult:
    """V8: 반사실적 추론 결과"""
    original_action: str = ""
    counterfactual_action: str = ""
    original_outcome: str = ""
    predicted_outcome: str = ""
    confidence: float = 0.0
    lesson_learned: str = ""


# ──────────────────────────────────────────────────────────────────────────────
# 수면 학습 시스템 / Sleep Learning
# ──────────────────────────────────────────────────────────────────────────────

class SleepLearning:
    """
    수면 학습 시스템 V8

    V8.5 기능 + V8.5 업그레이드:
    - 로봇이 유휴 상태일 때 3분마다 수면 학습 수행
    - 1. 경험 재생 (35%): 중요한 경험을 재생하여 강화
    - 2. 합성 데이터 생성 (20%): 세계 모델 기반 일반화
    - 3. 스킬 학습: 빈발 패턴 → 복합 스킬 승격
    - 4. LoRA 업데이트: 다중 작업 EWC 보호와 함께 가중치 업데이트
    - 5. 꿈 시뮬레이션 (15%): DreamSimulator로 미래 시나리오 시뮬레이션
    - 6. 세계지식 통합: 세계 데이터를 메모리에 통합
    - 7. 인과 추출: 경험에서 인과 관계 발견
    - 8. 반사실적 추론: "만약 X를 했다면?" 분석

    EWC 다중 작업:
    - 작업별 Fisher 정보 행렬로 각 작업의 지식 보호
    - 세계지식, 툴 콜링, 대화 등 각각 독립적 보호

    검증: 수면 학습 후 ≥1개 새 스킬 학습 또는 기존 스킬 성공률 향상
    """

    def __init__(
        self,
        db_path: Path = DEFAULT_DB_PATH,
    ) -> None:
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.RLock()

        # 외부 시스템 참조 (지연 연결)
        self._experience_collector: Optional[Any] = None
        self._skill_library: Optional[Any] = None
        self._semantic_memory: Optional[Any] = None
        # V8: 신규 외부 시스템
        self._dream_simulator: Optional[Any] = None
        self._continuous_learner: Optional[Any] = None
        self._world_model: Optional[Any] = None
        self._six_layer_memory: Optional[Any] = None
        self._causal_reasoning: Optional[Any] = None

        # 수면 학습 상태
        self._current_phase = SleepPhase.AWAKE
        self._is_sleeping = False
        self._sleep_thread: Optional[threading.Thread] = None
        self._running = False

        # EWC 상태 — V8: 다중 작업
        self._ewc_state = EWCState()

        # 세션 기록
        self._sessions: List[SleepSession] = []
        self._total_sessions = 0
        self._total_skills_learned = 0

        # V8: 반사실적 추론 기록
        self._counterfactual_results: List[CounterfactualResult] = []

        logger.info("수면 학습 시스템 V8.5 초기화")

    async def initialize(self) -> None:
        """수면 학습 시스템 초기화"""
        self._conn = sqlite3.connect(
            str(self._db_path), check_same_thread=False,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._create_tables()
        self._load_sessions()
        logger.info("수면 학습 시스템 V8.5 초기화 완료")

    def _create_tables(self) -> None:
        """테이블 생성 — V8: 추가 컬럼"""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS sleep_sessions (
                session_id TEXT PRIMARY KEY,
                start_time REAL NOT NULL,
                end_time REAL DEFAULT 0,
                phase TEXT DEFAULT 'awake',
                experiences_replayed INTEGER DEFAULT 0,
                synthetic_data_generated INTEGER DEFAULT 0,
                skills_learned INTEGER DEFAULT 0,
                skills_improved INTEGER DEFAULT 0,
                lora_updated INTEGER DEFAULT 0,
                duration_s REAL DEFAULT 0,
                dream_simulations INTEGER DEFAULT 0,
                causal_relations_found INTEGER DEFAULT 0,
                counterfactual_scenarios INTEGER DEFAULT 0,
                world_knowledge_integrated INTEGER DEFAULT 0,
                innovations_discovered INTEGER DEFAULT 0
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS ewc_state (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                fisher_matrix TEXT DEFAULT '{}',
                optimal_params TEXT DEFAULT '{}',
                lambda_ewc REAL DEFAULT 1000.0,
                last_update REAL DEFAULT 0,
                task_fisher_matrices TEXT DEFAULT '{}'
            )
        """)
        # V8: 반사실적 추론 테이블
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS counterfactual_results (
                result_id TEXT PRIMARY KEY,
                original_action TEXT,
                counterfactual_action TEXT,
                original_outcome TEXT,
                predicted_outcome TEXT,
                confidence REAL DEFAULT 0,
                lesson_learned TEXT,
                timestamp REAL DEFAULT 0
            )
        """)
        self._conn.commit()

    def _load_sessions(self) -> None:
        """이전 세션 기록 로드"""
        try:
            cursor = self._conn.execute(
                "SELECT COUNT(*) FROM sleep_sessions"
            )
            self._total_sessions = cursor.fetchone()[0]
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────────────────
    # 외부 시스템 연결 / Connect External Systems
    # ──────────────────────────────────────────────────────────────────────

    def connect_experience_collector(self, collector: Any) -> None:
        """경험 수집기 연결"""
        self._experience_collector = collector

    def connect_skill_library(self, library: Any) -> None:
        """스킬 라이브러리 연결"""
        self._skill_library = library

    def connect_semantic_memory(self, memory: Any) -> None:
        """의미 기억 연결"""
        self._semantic_memory = memory

    def connect_dream_simulator(self, simulator: Any) -> None:
        """V8: 꿈 시뮬레이터 연결"""
        self._dream_simulator = simulator
        logger.info("꿈 시뮬레이터 연결 완료")

    def connect_continuous_learner(self, learner: Any) -> None:
        """V8: 연속 학습기 연결"""
        self._continuous_learner = learner
        logger.info("연속 학습기 연결 완료")

    def connect_world_model(self, model: Any) -> None:
        """V8: 세계 모델 연결"""
        self._world_model = model
        logger.info("세계 모델 연결 완료")

    def connect_six_layer_memory(self, memory: Any) -> None:
        """V8: 6계층 메모리 연결"""
        self._six_layer_memory = memory
        logger.info("6계층 메모리 연결 완료")

    def connect_causal_reasoning(self, reasoning: Any) -> None:
        """V8: 인과 추론 연결"""
        self._causal_reasoning = reasoning
        logger.info("인과 추론 연결 완료")

    # ──────────────────────────────────────────────────────────────────────
    # start_sleep() — 수면 학습 시작
    # ──────────────────────────────────────────────────────────────────────

    def start_sleep(self, duration_s: float = SLEEP_INTERVAL_S) -> Dict[str, Any]:
        """
        수면 학습 세션 시작 — V8: 3분마다 자동 호출

        V8.5 순서:
        1. 경험 재생 (35%)
        2. 합성 데이터 생성 (20%) — 세계 모델 기반
        3. 스킬 학습
        4. LoRA 업데이트 (다중 작업 EWC)
        5. 꿈 시뮬레이션 (15%)
        6. 세계지식 통합
        7. 인과 추출 + 반사실적 추론

        Args:
            duration_s: 수면 학습 지속 시간 (초)

        Returns:
            수면 학습 결과 요약
        """
        if self._is_sleeping:
            return {"status": "already_sleeping"}

        self._is_sleeping = True
        session = SleepSession()
        start_time = time.time()

        logger.info(f"수면 학습 V8.5 세션 시작 (지속: {duration_s:.0f}초)")

        try:
            # Phase 1: 경험 재생 (35% 시간)
            replay_budget = duration_s * REPLAY_BUDGET_RATIO
            session.phase = SleepPhase.REPLAY
            replayed = self.replay_experiences(replay_budget)
            session.experiences_replayed = replayed

            # Phase 2: 합성 데이터 생성 (20% 시간) — V8: 세계 모델 기반
            synthetic_budget = duration_s * SYNTHETIC_BUDGET_RATIO
            session.phase = SleepPhase.SYNTHESIS
            generated = self.generate_synthetic(synthetic_budget)
            session.synthetic_data_generated = generated

            # Phase 3: 스킬 학습
            session.phase = SleepPhase.SKILL_LEARNING
            skills_result = self._learn_skills()
            session.skills_learned = skills_result.get("new_skills", 0)
            session.skills_improved = skills_result.get("improved_skills", 0)

            # Phase 4: LoRA 업데이트 (다중 작업 EWC 보호)
            session.phase = SleepPhase.LORA_UPDATE
            lora_result = self.update_lora(
                replayed + generated
            )
            session.lora_updated = lora_result

            # Phase 5: 꿈 시뮬레이션 (V8.5 신규)
            dream_budget = duration_s * DREAM_BUDGET_RATIO
            session.phase = SleepPhase.DREAM
            dream_result = self._run_dream_simulation(dream_budget)
            session.dream_simulations = dream_result.get("simulations", 0)
            session.counterfactual_scenarios = dream_result.get(
                "counterfactuals", 0
            )

            # Phase 6: 세계지식 통합 (V8.5 신규)
            session.phase = SleepPhase.WORLD_KNOWLEDGE
            wk_result = self._integrate_world_knowledge()
            session.world_knowledge_integrated = wk_result

            # Phase 7: 인과 추출 (V8.5 신규)
            session.phase = SleepPhase.CAUSAL_EXTRACTION
            causal_result = self._extract_causal_relations()
            session.causal_relations_found = causal_result

            session.phase = SleepPhase.COMPLETE

        except Exception as e:
            logger.error(f"수면 학습 오류: {e}")
            session.phase = SleepPhase.AWAKE

        session.end_time = time.time()
        session.duration_s = session.end_time - start_time

        # 세션 기록 저장
        self._sessions.append(session)
        self._total_sessions += 1
        self._total_skills_learned += session.skills_learned
        self._save_session(session)

        self._is_sleeping = False
        self._current_phase = SleepPhase.AWAKE

        result = {
            "status": "completed",
            "session_id": session.session_id,
            "experiences_replayed": session.experiences_replayed,
            "synthetic_data_generated": session.synthetic_data_generated,
            "skills_learned": session.skills_learned,
            "skills_improved": session.skills_improved,
            "lora_updated": session.lora_updated,
            "duration_s": session.duration_s,
            # V8.5 신규
            "dream_simulations": session.dream_simulations,
            "causal_relations_found": session.causal_relations_found,
            "counterfactual_scenarios": session.counterfactual_scenarios,
            "world_knowledge_integrated": session.world_knowledge_integrated,
            "innovations_discovered": session.innovations_discovered,
        }

        logger.info(
            f"수면 학습 V8.5 완료: {session.skills_learned}개 스킬 학습, "
            f"{session.dream_simulations}개 꿈 시뮬, "
            f"{session.causal_relations_found}개 인과 관계, "
            f"{session.experiences_replayed}개 경험 재생"
        )

        # V8: ContinuousLearner에 세션 결과 알림
        if self._continuous_learner:
            try:
                self._continuous_learner.on_sleep_session_complete(result)
            except Exception:
                pass

        return result

    # ──────────────────────────────────────────────────────────────────────
    # replay_experiences() — 경험 재생
    # ──────────────────────────────────────────────────────────────────────

    def replay_experiences(self, time_budget_s: float) -> int:
        """
        중요한 경험 재생 — 인간의 수면 중 기억 강화 메커니즘 모방

        우선순위:
        1. 학습되지 않은(unlearned) 경험
        2. 낮은 성공률의 경험 (개선 필요)
        3. 높은 중요도의 경험
        4. V8: 높은 참신함 점수의 경험
        """
        if not self._experience_collector:
            return 0

        start = time.time()
        replayed = 0

        try:
            # 학습되지 않은 경험 우선 조회
            experiences = self._experience_collector.get_experiences(
                unlearned_only=True,
                limit=200,
            )

            # 중요도 기반 정렬 — V8: 참신함 점수도 고려
            experiences.sort(
                key=lambda e: (
                    -getattr(e, 'novelty_score', 0),
                    -e.success_score,
                    -e.timestamp,
                ),
            )

            replayed_ids = []
            for exp in experiences:
                if time.time() - start > time_budget_s:
                    break

                # 경험을 의미 기억에 강화 저장
                if self._semantic_memory and exp.description:
                    self._semantic_memory.store_fact(
                        fact=exp.description,
                        tags=exp.tags + ["replay", "sleep_learning"],
                        source="sleep_replay",
                        confidence=exp.success_score,
                    )

                # V8: 6계층 메모리에도 저장 (세계지식 태그 있으면)
                if self._six_layer_memory:
                    try:
                        self._six_layer_memory.store(
                            content=exp.description,
                            tags=exp.tags + ["replay"],
                            metadata={"source": "sleep_replay"},
                        )
                    except Exception:
                        pass

                replayed_ids.append(exp.experience_id)
                replayed += 1

            # 재생된 경험을 학습 완료로 표시
            if replayed_ids:
                self._experience_collector.mark_learned(replayed_ids)

        except Exception as e:
            logger.error(f"경험 재생 오류: {e}")

        return replayed

    # ──────────────────────────────────────────────────────────────────────
    # generate_synthetic() — 합성 데이터 생성
    # ──────────────────────────────────────────────────────────────────────

    def generate_synthetic(self, time_budget_s: float) -> int:
        """
        V8: 합성 학습 데이터 생성 — 세계 모델 기반 향상

        과정:
        1. 성공한 경험 패턴 추출
        2. V8: 세계 모델로 결과 예측하여 검증
        3. 매개변수 변형 (±10~20%)
        4. 순서 변형 (안전한 범위 내)
        5. 합성 경험으로 저장
        """
        if not self._experience_collector:
            return 0

        start = time.time()
        generated = 0

        try:
            # 성공한 동작 시퀀스 경험 조회
            successful = self._experience_collector.get_experiences(
                experience_type=None,
                outcome="success",
                min_success_score=0.7,
                limit=50,
            )

            for exp in successful:
                if time.time() - start > time_budget_s:
                    break

                if not exp.action_sequence or len(exp.action_sequence) < 2:
                    continue

                # 매개변수 변형 생성
                variant = self._create_variant(exp.action_sequence)
                if variant:
                    # V8: 세계 모델로 결과 예측 (가능한 경우)
                    predicted_outcome = None
                    if self._world_model:
                        try:
                            predicted_outcome = self._world_model.predict(
                                action_sequence=variant,
                                context=exp.context,
                            )
                        except Exception:
                            pass

                    # 합성 데이터의 성공 점수 조정
                    success_score = 0.6
                    if predicted_outcome:
                        success_score = predicted_outcome.get(
                            "success_probability", 0.6
                        )

                    self._experience_collector.record_action_sequence(
                        description=f"합성: {exp.description}",
                        actions=variant,
                        outcome="synthetic",
                        success_score=success_score,
                        duration_s=0,
                        context={
                            "source": "sleep_learning_synthetic_v8",
                            "original_id": exp.experience_id,
                            "world_model_verified": predicted_outcome is not None,
                        },
                    )
                    generated += 1

        except Exception as e:
            logger.error(f"합성 데이터 생성 오류: {e}")

        return generated

    def _create_variant(
        self, sequence: List[Dict[str, Any]],
    ) -> Optional[List[Dict[str, Any]]]:
        """동작 시퀀스의 변형 생성 — 매개변수 ±10~20% 변형"""
        variant = copy.deepcopy(sequence)

        for action in variant:
            args = action.get("args", {})
            for key, value in args.items():
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    # 수치 매개변수에 ±10~20% 변형
                    variation = value * random.uniform(-0.15, 0.15)
                    action["args"][key] = round(value + variation, 3)

        return variant

    # ──────────────────────────────────────────────────────────────────────
    # V8: 꿈 시뮬레이션 / Dream Simulation
    # ──────────────────────────────────────────────────────────────────────

    def _run_dream_simulation(self, time_budget_s: float) -> Dict[str, int]:
        """
        V8: 꿈 시뮬레이션 — DreamSimulator로 미래 시나리오 시뮬레이션

        1. 가능한 행동 시나리오 생성
        2. 세계 모델로 결과 예측
        3. 반사실적 추론 ("만약 X를 했다면?")
        4. 시뮬레이션 결과를 혁신기억에 저장
        """
        result = {"simulations": 0, "counterfactuals": 0}
        start = time.time()

        if self._dream_simulator:
            try:
                # 꿈 시뮬레이션 실행
                dream_result = self._dream_simulator.run_simulation(
                    duration_s=time_budget_s,
                    include_counterfactuals=True,
                )
                result["simulations"] = dream_result.get("simulations_run", 0)
                result["counterfactuals"] = dream_result.get(
                    "counterfactuals_run", 0
                )

                # 시뮬레이션에서 발견한 혁신 저장
                innovations = dream_result.get("innovations", [])
                for innovation in innovations:
                    self._store_dream_innovation(innovation)

            except Exception as e:
                logger.error(f"꿈 시뮬레이션 오류: {e}")

        # 독립적 반사실적 추론
        if self._experience_collector and time.time() - start < time_budget_s:
            cf_count = self._run_counterfactual_reasoning(
                time_budget_s - (time.time() - start)
            )
            result["counterfactuals"] += cf_count

        return result

    def _run_counterfactual_reasoning(self, time_budget_s: float) -> int:
        """
        V8: 반사실적 추론 — "만약 X를 했다면 어땠을까?"

        실패한 경험에 대해 대안 행동의 결과를 시뮬레이션
        """
        if not self._experience_collector:
            return 0

        start = time.time()
        count = 0

        try:
            # 실패한 경험 조회
            failures = self._experience_collector.get_experiences(
                outcome="failure",
                limit=10,
            )

            for exp in failures:
                if time.time() - start > time_budget_s:
                    break

                if not exp.action_sequence:
                    continue

                # 대안 행동 생성
                alternative = self._generate_alternative(exp.action_sequence)
                if not alternative:
                    continue

                # 세계 모델로 예측
                predicted_outcome = "unknown"
                confidence = 0.3
                if self._world_model:
                    try:
                        prediction = self._world_model.predict(
                            action_sequence=alternative,
                            context=exp.context,
                        )
                        predicted_outcome = prediction.get(
                            "outcome", "unknown"
                        )
                        confidence = prediction.get("confidence", 0.3)
                    except Exception:
                        pass

                # 반사실적 결과 기록
                cf_result = CounterfactualResult(
                    original_action=str(exp.action_sequence[:3]),
                    counterfactual_action=str(alternative[:3]),
                    original_outcome=exp.outcome,
                    predicted_outcome=predicted_outcome,
                    confidence=confidence,
                    lesson_learned=self._extract_lesson(
                        exp.action_sequence, alternative, predicted_outcome
                    ),
                )
                self._counterfactual_results.append(cf_result)
                count += 1

                # 교훈을 메모리에 저장
                if cf_result.lesson_learned and self._six_layer_memory:
                    self._six_layer_memory.store(
                        content=cf_result.lesson_learned,
                        tags=["counterfactual", "lesson", "sleep_learning"],
                        metadata={
                            "source": "counterfactual_reasoning",
                            "confidence": confidence,
                        },
                    )

        except Exception as e:
            logger.error(f"반사실적 추론 오류: {e}")

        return count

    def _generate_alternative(
        self, original_sequence: List[Dict[str, Any]],
    ) -> Optional[List[Dict[str, Any]]]:
        """실패한 시퀀스의 대안 행동 생성"""
        alternative = copy.deepcopy(original_sequence)

        # 전략 1: 매개변수 조정 (더 보수적으로)
        for action in alternative:
            args = action.get("args", {})
            for key, value in args.items():
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    # 속도/힘 감소 (더 안전하게)
                    action["args"][key] = round(value * 0.7, 3)

        # 전략 2: 마지막 동작 변경
        if len(alternative) >= 2:
            last = alternative[-1]
            if "action" in last:
                # 유사한 다른 동작으로 교체 (간소화)
                last["action"] = last.get("action", "") + "_safe"

        return alternative

    def _extract_lesson(
        self,
        original: List[Dict],
        alternative: List[Dict],
        predicted_outcome: str,
    ) -> str:
        """반사실적 추론에서 교훈 추출"""
        if predicted_outcome == "success":
            return (
                f"대안 행동이 성공할 것으로 예측됨. "
                f"원래 행동 대신 보수적 접근 시도 필요."
            )
        elif predicted_outcome == "partial":
            return (
                f"대안 행동이 부분적 성공 예측. "
                f"더 나은 접근 방법 탐색 필요."
            )
        else:
            return (
                f"대안 행동도 성공하기 어려울 수 있음. "
                f"근본적 접근 방식 변경 고려."
            )

    def _store_dream_innovation(self, innovation: Dict) -> None:
        """꿈 시뮬레이션에서 발견한 혁신을 혁신기억에 저장"""
        if self._six_layer_memory:
            try:
                self._six_layer_memory.store(
                    content=innovation.get("description", ""),
                    tags=["innovation", "dream_simulation"],
                    metadata={
                        "innovation_type": innovation.get("type", "dream"),
                        "originality_score": innovation.get("novelty", 0.5),
                        "utility_score": innovation.get("utility", 0.3),
                        "source": "dream_simulation",
                    },
                    novelty_score=innovation.get("novelty", 0.5),
                )
            except Exception:
                pass

    # ──────────────────────────────────────────────────────────────────────
    # V8: 세계지식 통합 / World Knowledge Integration
    # ──────────────────────────────────────────────────────────────────────

    def _integrate_world_knowledge(self) -> int:
        """
        V8: 수면 중 세계 데이터를 메모리에 통합

        World Data Pipeline에서 수집한 데이터를
        6계층 메모리의 Layer 5 (세계지식)에 통합
        """
        if not self._six_layer_memory:
            return 0

        integrated = 0

        try:
            # 세계지식 태그가 있는 미학습 데이터 조회
            if self._experience_collector:
                world_experiences = self._experience_collector.get_experiences(
                    experience_type=None,
                    limit=50,
                )

                for exp in world_experiences:
                    if "world" in exp.tags or "fact" in exp.tags:
                        self._six_layer_memory.store(
                            content=exp.description,
                            tags=exp.tags + ["world_knowledge", "sleep_integrated"],
                            metadata={
                                "source": "sleep_world_knowledge",
                                "confidence": getattr(exp, 'success_score', 0.8),
                            },
                        )
                        integrated += 1

        except Exception as e:
            logger.error(f"세계지식 통합 오류: {e}")

        return integrated

    # ──────────────────────────────────────────────────────────────────────
    # V8: 인과 추출 / Causal Extraction
    # ──────────────────────────────────────────────────────────────────────

    def _extract_causal_relations(self) -> int:
        """
        V8: 수면 중 경험에서 인과 관계 발견

        시간적 선후 관계와 상관관계를 분석하여
        인과 관계를 추론하고 CausalReasoning에 저장
        """
        if not self._experience_collector or not self._causal_reasoning:
            return 0

        found = 0

        try:
            # 동작 시퀀스 경험 조회
            sequences = self._experience_collector.get_experiences(
                experience_type=None,
                limit=100,
            )

            # 성공/실패 페어에서 인과 추출
            success_actions = {}
            failure_actions = {}

            for exp in sequences:
                actions = exp.action_sequence
                if not actions:
                    continue

                action_key = str([a.get("tool", a.get("action", "")) for a in actions[:3]])

                if exp.outcome == "success":
                    success_actions[action_key] = success_actions.get(action_key, 0) + 1
                elif exp.outcome == "failure":
                    failure_actions[action_key] = failure_actions.get(action_key, 0) + 1

            # 성공과 실패의 차이에서 인과 추출
            for action_key in set(list(success_actions.keys()) + list(failure_actions.keys())):
                s_count = success_actions.get(action_key, 0)
                f_count = failure_actions.get(action_key, 0)

                if s_count + f_count >= 3:
                    success_rate = s_count / (s_count + f_count)

                    # 인과 관계 저장
                    try:
                        self._causal_reasoning.add_causal_relation(
                            cause=action_key,
                            effect=f"success_rate_{success_rate:.2f}",
                            confidence=min(1.0, (s_count + f_count) / 10),
                            source="sleep_causal_extraction",
                        )
                        found += 1
                    except Exception:
                        pass

        except Exception as e:
            logger.error(f"인과 추출 오류: {e}")

        return found

    # ──────────────────────────────────────────────────────────────────────
    # 스킬 학습 / Skill Learning
    # ──────────────────────────────────────────────────────────────────────

    def _learn_skills(self) -> Dict[str, int]:
        """수면 학습 중 스킬 학습 — 빈발 패턴 → 복합 스킬 승격"""
        result = {"new_skills": 0, "improved_skills": 0}

        if not self._skill_library:
            return result

        try:
            # 패턴 감지 시도
            pattern = self._skill_library.detect_pattern()
            if pattern:
                result["new_skills"] = 1
                logger.info(f"수면 학습 중 새 스킬 감지: {pattern}")

            # 저성능 스킬 정리
            for skill in self._skill_library.get_all_skills():
                if (
                    skill.execution_count >= 10
                    and skill.success_rate < 0.6
                    and skill.status.value != "primitive"
                ):
                    # 성공률이 너무 낮으면 비활성화
                    skill.status = type(skill.status).DEPRECATED if hasattr(type(skill.status), 'DEPRECATED') else skill.status
                    logger.info(
                        f"저성능 스킬 비활성화: {skill.name} "
                        f"(성공률: {skill.success_rate:.2f})"
                    )

        except Exception as e:
            logger.error(f"스킬 학습 오류: {e}")

        return result

    # ──────────────────────────────────────────────────────────────────────
    # update_lora() — LoRA 가중치 업데이트 (V8: 다중 작업 EWC)
    # ──────────────────────────────────────────────────────────────────────

    def update_lora(self, num_samples: int) -> bool:
        """
        V8: 다중 작업 EWC 보호와 함께 LoRA 가중치 업데이트

        EWC 다중 작업:
        - 각 작업(툴 콜링, 세계지식, 대화 등)별 Fisher 정보 행렬
        - 작업별 가중치로 보호 강도 조절
        - 수식: L_total = L_task + Σ_k λ_k/2 * Σ F_i^k * (θ_i - θ*_i)²

        실제 환경: gemma_finetune.py의 EWCLoRATrainer 사용
        시뮬레이션: 다중 작업 Fisher 정보 행렬 업데이트 시뮬레이션
        """
        try:
            # V8: 다중 작업 Fisher 정보 행렬 업데이트
            self._update_multi_task_fisher(num_samples)

            # LoRA 가중치 업데이트 시뮬레이션
            logger.info(
                f"LoRA 가중치 업데이트 시뮬레이션 V8.5 "
                f"({num_samples}개 샘플, "
                f"다중 작업 EWC, λ={self._ewc_state.lambda_ewc})"
            )

            # EWC 상태 저장
            self._ewc_state.last_update = time.time()
            self._save_ewc_state()

            return True

        except Exception as e:
            logger.error(f"LoRA 업데이트 오류: {e}")
            return False

    def _update_multi_task_fisher(self, num_samples: int) -> None:
        """V8: 다중 작업 Fisher 정보 행렬 업데이트 시뮬레이션"""
        lora_layers = [
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ]

        # 각 작업별 Fisher 업데이트
        for task_name, weight in EWC_MULTI_TASK_WEIGHTS.items():
            if task_name not in self._ewc_state.task_fisher_matrices:
                self._ewc_state.task_fisher_matrices[task_name] = {}

            task_fisher = self._ewc_state.task_fisher_matrices[task_name]

            for layer in lora_layers:
                if layer not in task_fisher:
                    # 초기 Fisher 정보 — 작업 가중치 적용
                    task_fisher[layer] = [
                        random.uniform(0.01, 1.0) * weight
                        for _ in range(16)  # LoRA rank=16
                    ]
                else:
                    # 기존 Fisher 정보 업데이트 — 이동 평균
                    for i in range(len(task_fisher[layer])):
                        new_val = random.uniform(0.01, 1.0) * weight
                        old_val = task_fisher[layer][i]
                        task_fisher[layer][i] = 0.9 * old_val + 0.1 * new_val

        # 통합 Fisher 행렬 업데이트 (모든 작업 가중 합)
        for layer in lora_layers:
            combined = [0.0] * 16
            for task_name, task_fisher in self._ewc_state.task_fisher_matrices.items():
                if layer in task_fisher:
                    weight = EWC_MULTI_TASK_WEIGHTS.get(task_name, 1.0)
                    for i in range(16):
                        combined[i] += task_fisher[layer][i] * weight
            self._ewc_state.fisher_matrix[layer] = combined

    def _save_ewc_state(self) -> None:
        """EWC 상태를 DB에 저장 — V8: 다중 작업 포함"""
        if not self._conn:
            return

        try:
            self._conn.execute(
                """INSERT OR REPLACE INTO ewc_state
                   (id, fisher_matrix, optimal_params, lambda_ewc, last_update,
                    task_fisher_matrices)
                   VALUES (1, ?, ?, ?, ?, ?)""",
                (
                    json.dumps(self._ewc_state.fisher_matrix),
                    json.dumps(self._ewc_state.optimal_params),
                    self._ewc_state.lambda_ewc,
                    self._ewc_state.last_update,
                    json.dumps(self._ewc_state.task_fisher_matrices),
                ),
            )
            self._conn.commit()
        except Exception as e:
            logger.error(f"EWC 상태 저장 오류: {e}")

    def _save_session(self, session: SleepSession) -> None:
        """수면 학습 세션 기록 저장 — V8: 추가 컬럼"""
        if not self._conn:
            return

        try:
            self._conn.execute(
                """INSERT OR REPLACE INTO sleep_sessions
                   (session_id, start_time, end_time, phase,
                    experiences_replayed, synthetic_data_generated,
                    skills_learned, skills_improved, lora_updated, duration_s,
                    dream_simulations, causal_relations_found,
                    counterfactual_scenarios, world_knowledge_integrated,
                    innovations_discovered)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    session.session_id,
                    session.start_time,
                    session.end_time,
                    session.phase.value,
                    session.experiences_replayed,
                    session.synthetic_data_generated,
                    session.skills_learned,
                    session.skills_improved,
                    int(session.lora_updated),
                    session.duration_s,
                    session.dream_simulations,
                    session.causal_relations_found,
                    session.counterfactual_scenarios,
                    session.world_knowledge_integrated,
                    session.innovations_discovered,
                ),
            )
            self._conn.commit()
        except Exception as e:
            logger.error(f"세션 저장 오류: {e}")

    # ──────────────────────────────────────────────────────────────────────
    # 자동 수면 학습 루프 / Auto Sleep Learning Loop
    # ──────────────────────────────────────────────────────────────────────

    def start_auto_sleep(self) -> None:
        """자동 수면 학습 루프 시작 — V8: 3분마다 실행"""
        if self._running:
            return

        self._running = True
        self._sleep_thread = threading.Thread(
            target=self._auto_sleep_loop,
            daemon=True,
            name="sleep-learning-v8",
        )
        self._sleep_thread.start()
        logger.info("자동 수면 학습 V8.5 루프 시작 (3분 간격)")

    def stop_auto_sleep(self) -> None:
        """자동 수면 학습 루프 중지"""
        self._running = False
        if self._sleep_thread:
            self._sleep_thread.join(timeout=5.0)
        logger.info("자동 수면 학습 V8.5 루프 중지")

    def _auto_sleep_loop(self) -> None:
        """자동 수면 학습 루프 — V8: 3분마다 수면 학습 세션 실행"""
        while self._running:
            try:
                time.sleep(SLEEP_INTERVAL_S)
                if self._running and not self._is_sleeping:
                    self.start_sleep(duration_s=MIN_SLEEP_DURATION_S)
            except Exception as e:
                logger.error(f"자동 수면 학습 오류: {e}")

    # ──────────────────────────────────────────────────────────────────────
    # 통계 / Statistics
    # ──────────────────────────────────────────────────────────────────────

    def get_stats(self) -> Dict[str, Any]:
        """수면 학습 통계 반환 — V8: 추가 정보"""
        return {
            "total_sessions": self._total_sessions,
            "total_skills_learned": self._total_skills_learned,
            "is_sleeping": self._is_sleeping,
            "current_phase": self._current_phase.value,
            "ewc_last_update": self._ewc_state.last_update,
            "ewc_lambda": self._ewc_state.lambda_ewc,
            "ewc_multi_task_count": len(self._ewc_state.task_fisher_matrices),
            "counterfactual_results": len(self._counterfactual_results),
            "auto_sleep_running": self._running,
            "sleep_interval_s": SLEEP_INTERVAL_S,
        }

    def shutdown(self) -> None:
        """수면 학습 시스템 종료"""
        self.stop_auto_sleep()
        if self._conn:
            self._conn.close()
            self._conn = None
        logger.info("수면 학습 시스템 V8.5 종료 완료")
