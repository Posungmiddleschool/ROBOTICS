#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
grip_predictor_net.py - Neural Grasp Outcome Prediction Network
파지 결과 예측 신경망

지훈 로봇 V8.5 Physical AGI — 모델 기반 파지 예측 시스템
Jihun Robot V8.5 Physical AGI — Model-Based Grasp Prediction System

파지 실행 전 성공 확률, 슬립 확률, 최적 파지력, 최적 접근 각도를 예측.
Predicts grasp success probability, slip probability, optimal force,
and optimal approach angle before execution.

아키텍처 / Architecture:
  - 입력: 객체 특징(크기, 무게, 재질, 형상), 핸드 구성, 접근 각도, 힘 프로파일
  - 공유 백본: Residual FC 네트워크 + LayerNorm + Dropout
  - 멀티 헤드 출력: 성공 확률, 슬립 확률, 최적 파지력, 최적 접근 보정
  - 학습된 불확실성 가중치 (Kendall et al.) 멀티태스크 손실
  - MC Dropout 기반 신뢰도 추정
  - 경험 재생(Experience Replay) 온라인 학습
  - 피우샷 적응 (MAML-style inner loop)

설계 원칙 / Design Principles:
  - 물리적 파지 경험으로부터 학습 (Learn from physical grasp experiences)
  - 행동 전 예측 (Predict before acting — model-based grasping)
  - 새로운 객체에 피우샷 적응 (Few-shot adaptation to new objects)
  - 힘 최적화: 슬립 최소화하면서 파손 방지 (Force optimization)

작성일: 2026-05-20
버전: V8.5.4
라이선스: MIT
"""

from __future__ import annotations

import logging
import math
import sqlite3
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.utils.data import Dataset, DataLoader
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    nn = object
    Dataset = object

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


# ═══════════════════════════════════════════════════════════════════════
# 상수 정의 / Constants
# ═══════════════════════════════════════════════════════════════════════

# 입력 특징 차원 / Input feature dimensions
OBJECT_FEATURE_DIM = 32       # 객체 특징 차원 (크기3 + 무게1 + 재질16 + 형상12)
HAND_CONFIG_DIM = 16          # 핸드 구성 차원 (손가락 위치5 + 손목 자세6 + 파지 개구5)
APPROACH_DIM = 4              # 접근 각도 차원 (방위각1 + 고도각1 + 거리1 + 속도1)
FORCE_PROFILE_DIM = 8         # 힘 프로파일 차원 (목표력1 + 기울기2 + 지속시간1 + 곡선특징4)
TOTAL_INPUT_DIM = OBJECT_FEATURE_DIM + HAND_CONFIG_DIM + APPROACH_DIM + FORCE_PROFILE_DIM  # 60

# 네트워크 구조 / Network architecture
SHARED_HIDDEN_DIM = 256       # 공유 백본 은닉 차원
SHARED_NUM_LAYERS = 4         # 공유 백본 레이어 수
HEAD_HIDDEN_DIM = 64          # 태스크 헤드 은닉 차원
DROPOUT_RATE = 0.15           # 드롭아웃 비율 (MC Dropout에도 사용)

# 접근 보정 출력 차원 / Approach correction output dimension
APPROACH_CORRECTION_DIM = 3   # (delta_elevation, delta_azimuth, delta_distance)

# 학습 파라미터 / Training parameters
LEARNING_RATE = 1e-4
WEIGHT_DECAY = 1e-5
BATCH_SIZE = 32
MAX_EPOCHS = 100
GRAD_CLIP_NORM = 1.0
REPLAY_BUFFER_SIZE = 10000
REPLAY_BATCH_SIZE = 64
FEWSHOT_INNER_STEPS = 5
FEWSHOT_INNER_LR = 1e-3

# 파지력 범위 / Grip force range (N)
FORCE_MIN = 0.5
FORCE_MAX = 15.0
FORCE_DEFAULT = 5.0

# 접근 각도 범위 (rad) / Approach angle range
APPROACH_ELEV_RANGE = (-math.pi / 2, math.pi / 2)
APPROACH_AZIM_RANGE = (-math.pi, math.pi)

# MC Dropout 샘플 수 / MC Dropout samples for uncertainty
MC_DROPOUT_SAMPLES = 10

# 신뢰도 임계값 / Confidence thresholds
LOW_CONFIDENCE_THRESHOLD = 0.3
HIGH_CONFIDENCE_THRESHOLD = 0.7

# 데이터베이스 / Database
DB_PATH = "grip_predictor.db"

# 재질 클래스 / Material categories
MATERIAL_CLASSES = [
    "rigid", "soft", "elastic", "fragile", "sticky",
    "slippery", "porous", "metallic", "wooden", "plastic",
    "glass", "fabric", "rubber", "ceramic", "foam", "composite"
]
NUM_MATERIAL_CLASSES = len(MATERIAL_CLASSES)  # 16

# 형상 클래스 / Shape categories
SHAPE_CLASSES = [
    "sphere", "cylinder", "box", "cone", "torus",
    "flat", "elongated", "irregular", "concave", "convex",
    "thin", "bulky"
]
NUM_SHAPE_CLASSES = len(SHAPE_CLASSES)  # 12


# ═══════════════════════════════════════════════════════════════════════
# 열거형 / Enumerations
# ═══════════════════════════════════════════════════════════════════════

class GraspOutcome(Enum):
    """파지 실제 결과 / Actual grasp outcome."""
    SUCCESS = "success"
    SLIP = "slip"
    DROP = "drop"
    CRUSH = "crush"
    MISS = "miss"
    TIMEOUT = "timeout"


class ConfidenceLevel(Enum):
    """신뢰도 수준 / Confidence level."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


# ═══════════════════════════════════════════════════════════════════════
# 데이터 클래스 / Data Classes
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class ObjectFeatures:
    """객체 특징 / Object features for grasp prediction."""
    size: np.ndarray = field(default_factory=lambda: np.array([0.1, 0.1, 0.1], dtype=np.float32))
    weight: float = 0.5                    # kg
    material_probs: np.ndarray = field(default_factory=lambda: np.zeros(NUM_MATERIAL_CLASSES, dtype=np.float32))
    shape_probs: np.ndarray = field(default_factory=lambda: np.zeros(NUM_SHAPE_CLASSES, dtype=np.float32))
    fragility: float = 0.0                 # 0=robust, 1=very fragile
    deformability: float = 0.0             # 0=rigid, 1=very deformable

    def to_vector(self) -> np.ndarray:
        """특징 벡터로 변환 / Convert to feature vector (OBJECT_FEATURE_DIM=32)."""
        vec = np.concatenate([
            self.size.astype(np.float32),           # 3
            np.array([self.weight], dtype=np.float32),  # 1
            self.material_probs,                    # 16
            self.shape_probs,                       # 12
        ])
        assert vec.shape[0] == OBJECT_FEATURE_DIM, f"Expected {OBJECT_FEATURE_DIM}, got {vec.shape[0]}"
        return vec


@dataclass
class HandConfiguration:
    """핸드 구성 / Hand configuration features."""
    finger_positions: np.ndarray = field(default_factory=lambda: np.zeros(5, dtype=np.float32))
    wrist_pose: np.ndarray = field(default_factory=lambda: np.zeros(6, dtype=np.float32))  # x,y,z,roll,pitch,yaw
    grip_aperture: float = 0.05             # meters
    palm_orientation: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 1.0], dtype=np.float32))

    def to_vector(self) -> np.ndarray:
        """특징 벡터로 변환 / Convert to feature vector (HAND_CONFIG_DIM=16)."""
        vec = np.concatenate([
            self.finger_positions,                          # 5
            self.wrist_pose,                                # 6
            np.array([self.grip_aperture], dtype=np.float32),  # 1
            self.palm_orientation[:3],                      # 3 (use first 3 of orientation)
            np.array([0.0], dtype=np.float32),              # 1 padding
        ])
        assert vec.shape[0] == HAND_CONFIG_DIM, f"Expected {HAND_CONFIG_DIM}, got {vec.shape[0]}"
        return vec


@dataclass
class ApproachAngle:
    """접근 각도 / Approach angle specification."""
    elevation_rad: float = 0.0      # -π/2 ~ π/2
    azimuth_rad: float = 0.0        # -π ~ π
    distance_m: float = 0.3         # approach distance
    speed_ms: float = 0.1           # approach speed

    def to_vector(self) -> np.ndarray:
        """특징 벡터로 변환 / Convert to feature vector (APPROACH_DIM=4)."""
        return np.array([
            self.elevation_rad, self.azimuth_rad,
            self.distance_m, self.speed_ms
        ], dtype=np.float32)


@dataclass
class ForceProfile:
    """힘 프로파일 / Force profile for grasp."""
    target_force_n: float = FORCE_DEFAULT    # 목표 파지력 (N)
    ramp_rate: float = 10.0                  # N/s
    hold_duration_s: float = 1.0             # 유지 시간
    curve_type: int = 0                      # 0=linear, 1=exponential, 2=adaptive
    curve_features: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 0.0, 0.0], dtype=np.float32))

    def to_vector(self) -> np.ndarray:
        """특징 벡터로 변환 / Convert to feature vector (FORCE_PROFILE_DIM=8)."""
        vec = np.concatenate([
            np.array([self.target_force_n, self.ramp_rate,
                      self.hold_duration_s, float(self.curve_type)], dtype=np.float32),
            self.curve_features,
        ])
        assert vec.shape[0] == FORCE_PROFILE_DIM, f"Expected {FORCE_PROFILE_DIM}, got {vec.shape[0]}"
        return vec


@dataclass
class GripPrediction:
    """파지 예측 결과 / Grasp prediction result."""
    success_probability: float        # 0~1, 파지 성공 확률
    slip_probability: float           # 0~1, 슬립 확률
    optimal_force_n: float            # 최적 파지력 (N)
    optimal_approach: ApproachAngle   # 최적 접근 각도 (보정치 포함)
    confidence: float                 # 0~1, 예측 신뢰도
    confidence_level: ConfidenceLevel # 신뢰도 수준
    force_margin_n: float             # 안전 여유력 (N) — 슬립 방지 최소 초과력
    damage_risk: float                # 0~1, 파손 위험도
    num_similar_experiences: int = 0  # 유사 과거 경험 수
    prediction_id: int = 0            # 예측 식별자

    @property
    def should_grasp(self) -> bool:
        """파지 실행 권장 여부 / Whether grasp execution is recommended."""
        return (self.success_probability > 0.5
                and self.damage_risk < 0.5
                and self.confidence > LOW_CONFIDENCE_THRESHOLD)


@dataclass
class GraspExperience:
    """파지 경험 기록 / Grasp experience record for learning."""
    object_features: np.ndarray      # (OBJECT_FEATURE_DIM,)
    hand_config: np.ndarray          # (HAND_CONFIG_DIM,)
    approach: np.ndarray             # (APPROACH_DIM,)
    force_profile: np.ndarray        # (FORCE_PROFILE_DIM,)
    outcome: GraspOutcome = GraspOutcome.SUCCESS
    actual_force_n: float = 0.0
    was_successful: bool = True
    slipped: bool = False
    object_damaged: bool = False
    timestamp: float = field(default_factory=time.time)

    def to_input_tensor(self) -> np.ndarray:
        """신경망 입력 텐서로 변환 / Convert to network input tensor."""
        return np.concatenate([
            self.object_features, self.hand_config,
            self.approach, self.force_profile
        ])

    @property
    def success_label(self) -> float:
        """성공 레이블 / Success label (1.0 if success, 0.0 otherwise)."""
        return 1.0 if self.was_successful else 0.0

    @property
    def slip_label(self) -> float:
        """슬립 레이블 / Slip label (1.0 if slipped, 0.0 otherwise)."""
        return 1.0 if self.slipped else 0.0

    @property
    def force_label(self) -> float:
        """최적력 레이블 / Optimal force label (actual force if success, adjusted if slip)."""
        if self.was_successful and not self.slipped:
            return self.actual_force_n
        elif self.slipped:
            return min(FORCE_MAX, self.actual_force_n * 1.3)  # 슬립 시 더 큰 힘 필요
        else:
            return max(FORCE_MIN, self.actual_force_n * 0.7)  # 실패 시 더 작은 힘


# ═══════════════════════════════════════════════════════════════════════
# Residual Block / 잔차 블록
# ═══════════════════════════════════════════════════════════════════════

if HAS_TORCH:
    class ResidualBlock(nn.Module):
        """
        잔차 연결 블록 / Residual connection block.
        FC → LayerNorm → ReLU → Dropout → FC → LayerNorm + skip → ReLU
        """
        def __init__(self, dim: int, dropout: float = DROPOUT_RATE):
            super().__init__()
            self.fc1 = nn.Linear(dim, dim)
            self.ln1 = nn.LayerNorm(dim)
            self.fc2 = nn.Linear(dim, dim)
            self.ln2 = nn.LayerNorm(dim)
            self.dropout = nn.Dropout(dropout)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            residual = x
            out = self.dropout(F.relu(self.ln1(self.fc1(x))))
            out = self.ln2(self.fc2(out))
            out = F.relu(out + residual)
            return out


# ═══════════════════════════════════════════════════════════════════════
# GripPredictorNet / 파지 예측 신경망
# ═══════════════════════════════════════════════════════════════════════

if HAS_TORCH:
    class GripPredictorNet(nn.Module):
        """
        파지 결과 예측 멀티헤드 신경망
        Multi-head neural network for grasp outcome prediction.

        Architecture:
          Input (60) → FC(60→256) → [ResidualBlock × 4] → shared (256)
            → success_head:  FC(256→64→1) + Sigmoid → success_prob
            → slip_head:     FC(256→64→1) + Sigmoid → slip_prob
            → force_head:    FC(256→64→1) + Softplus → optimal_force (N)
            → approach_head: FC(256→64→3) + Tanh*π  → approach_correction

        Loss: 학습된 불확실성 가중치 (Kendall et al., 2018) 멀티태스크 손실
              L = Σ (1/2σ²) L_i + log(σ)
        """

        def __init__(
            self,
            input_dim: int = TOTAL_INPUT_DIM,
            shared_hidden: int = SHARED_HIDDEN_DIM,
            num_residual_blocks: int = SHARED_NUM_LAYERS,
            head_hidden: int = HEAD_HIDDEN_DIM,
            dropout: float = DROPOUT_RATE,
        ):
            super().__init__()
            self.input_dim = input_dim
            self.shared_hidden = shared_hidden

            # ── 입력 프로젝션 / Input projection ──
            self.input_proj = nn.Sequential(
                nn.Linear(input_dim, shared_hidden),
                nn.LayerNorm(shared_hidden),
                nn.ReLU(),
                nn.Dropout(dropout),
            )

            # ── 공유 잔차 백본 / Shared residual backbone ──
            self.residual_blocks = nn.ModuleList([
                ResidualBlock(shared_hidden, dropout)
                for _ in range(num_residual_blocks)
            ])

            # ── 성공 확률 헤드 / Success probability head ──
            self.success_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.LayerNorm(head_hidden),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(head_hidden, 1),
                nn.Sigmoid(),
            )

            # ── 슬립 확률 헤드 / Slip probability head ──
            self.slip_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.LayerNorm(head_hidden),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(head_hidden, 1),
                nn.Sigmoid(),
            )

            # ── 최적 파지력 헤드 / Optimal force head ──
            # Softplus 출력: 항상 양수, 부드러운 ReLU 근사
            self.force_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.LayerNorm(head_hidden),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(head_hidden, 1),
                nn.Softplus(),
            )

            # ── 접근 각도 보정 헤드 / Approach correction head ──
            # Tanh * π: [-π, π] 범위 보정치
            self.approach_head = nn.Sequential(
                nn.Linear(shared_hidden, head_hidden),
                nn.LayerNorm(head_hidden),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(head_hidden, APPROACH_CORRECTION_DIM),
                nn.Tanh(),
            )

            # ── 학습된 불확실성 로그 분산 / Learned log variance (Kendall et al.) ──
            # 4개 태스크: success, slip, force, approach
            self.log_vars = nn.Parameter(torch.zeros(4))

            self._init_weights()
            total_params = sum(p.numel() for p in self.parameters())
            logger.info(f"GripPredictorNet 초기화: params={total_params:,} / Initialized")

        def _init_weights(self):
            """가중치 초기화 / Initialize weights with Kaiming normal."""
            for module in self.modules():
                if isinstance(module, nn.Linear):
                    nn.init.kaiming_normal_(module.weight, nonlinearity="relu")
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)

        def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
            """
            순전파 / Forward pass.

            Args:
                x: (batch, TOTAL_INPUT_DIM) — 결합 특징 벡터
            Returns:
                Dict with success_prob, slip_prob, optimal_force, approach_correction
            """
            # 공유 백본 / Shared backbone
            h = self.input_proj(x)                         # (batch, 256)
            for block in self.residual_blocks:
                h = block(h)                               # (batch, 256)

            # 멀티 헤드 출력 / Multi-head outputs
            success_prob = self.success_head(h)             # (batch, 1), [0,1]
            slip_prob = self.slip_head(h)                   # (batch, 1), [0,1]
            optimal_force = self.force_head(h)              # (batch, 1), (0,∞)
            approach_correction = self.approach_head(h) * math.pi  # (batch, 3), [-π,π]

            return {
                "success_prob": success_prob,
                "slip_prob": slip_prob,
                "optimal_force": optimal_force,
                "approach_correction": approach_correction,
            }

        def compute_loss(
            self,
            predictions: Dict[str, torch.Tensor],
            targets: Dict[str, torch.Tensor],
        ) -> torch.Tensor:
            """
            학습된 불확실성 가중치 멀티태스크 손실
            Multi-task loss with learned uncertainty weighting (Kendall et al.).
            L = Σ_i (1/2σ²_i) * L_i + log(σ_i)
            """
            # 성공 손실: BCE / Success loss
            success_loss = F.binary_cross_entropy(
                predictions["success_prob"].squeeze(-1),
                targets["success"].clamp(0.0, 1.0),
            )

            # 슬립 손실: BCE / Slip loss
            slip_loss = F.binary_cross_entropy(
                predictions["slip_prob"].squeeze(-1),
                targets["slip"].clamp(0.0, 1.0),
            )

            # 파지력 손실: Smooth L1 (이상치에 강건) / Force loss: Smooth L1
            force_loss = F.smooth_l1_loss(
                predictions["optimal_force"].squeeze(-1),
                targets["optimal_force"],
            )

            # 접근 보정 손실: MSE / Approach correction loss: MSE
            approach_loss = F.mse_loss(
                predictions["approach_correction"],
                targets["approach_correction"],
            )

            # 불확실성 가중치 적용 / Apply uncertainty weighting
            precisions = torch.exp(-self.log_vars)
            total_loss = (
                0.5 * precisions[0] * success_loss + 0.5 * self.log_vars[0] +
                0.5 * precisions[1] * slip_loss + 0.5 * self.log_vars[1] +
                0.5 * precisions[2] * force_loss + 0.5 * self.log_vars[2] +
                0.5 * precisions[3] * approach_loss + 0.5 * self.log_vars[3]
            )
            return total_loss

else:
    # PyTorch 미설치 시 스텁 클래스 / Stub classes when PyTorch is unavailable
    class ResidualBlock:
        """스텁: PyTorch 미설치 / Stub for when PyTorch is not installed."""
        pass

    class GripPredictorNet:
        """
        스텁: PyTorch 미설치 / Stub for when PyTorch is not installed.
        실제 기능은 PyTorch 설치 시 활성화됨.
        """
        def __init__(self, *args, **kwargs):
            raise RuntimeError(
                "PyTorch 설치 필요 / PyTorch required for GripPredictorNet. "
                "Install with: pip install torch"
            )


# ═══════════════════════════════════════════════════════════════════════
# Experience Replay Buffer / 경험 재생 버퍼
# ═══════════════════════════════════════════════════════════════════════

class ReplayBuffer:
    """
    파지 경험 재생 버퍼 / Grasp experience replay buffer.
    우선순위 샘플링으로 드문 경험(실패, 슬립)을 더 자주 재생.
    Priority sampling replays rare experiences (failures, slips) more often.
    """

    def __init__(self, capacity: int = REPLAY_BUFFER_SIZE):
        self.capacity = capacity
        self._buffer: deque = deque(maxlen=capacity)
        self._priorities: deque = deque(maxlen=capacity)
        self._lock = threading.Lock()
        self._next_id = 0

    def __len__(self) -> int:
        return len(self._buffer)

    def push(self, experience: GraspExperience, priority: Optional[float] = None) -> int:
        """
        경험 추가 / Add experience to buffer.
        실패/슬립 경험에 높은 우선순위 부여.
        """
        if priority is None:
            # 실패, 슬립, 파손 경험에 높은 우선순위 / High priority for failures
            if not experience.was_successful:
                priority = 3.0
            elif experience.slipped:
                priority = 2.5
            elif experience.object_damaged:
                priority = 2.0
            else:
                priority = 1.0

        with self._lock:
            exp_id = self._next_id
            self._next_id += 1
            self._buffer.append(experience)
            self._priorities.append(priority)
        return exp_id

    def sample(self, batch_size: int = REPLAY_BATCH_SIZE) -> List[GraspExperience]:
        """
        우선순위 샘플링 / Priority-based sampling.
        """
        with self._lock:
            n = len(self._buffer)
            if n == 0:
                return []

            priorities = np.array(self._priorities, dtype=np.float64)
            probs = priorities / priorities.sum()

            batch_size = min(batch_size, n)
            indices = np.random.choice(n, size=batch_size, replace=False, p=probs)
            return [self._buffer[i] for i in indices]

    def sample_tensors(self, batch_size: int = REPLAY_BATCH_SIZE, device: str = "cpu"
                       ) -> Optional[Dict[str, torch.Tensor]]:
        """
        샘플링 후 텐서로 변환 / Sample and convert to tensors.
        """
        if not HAS_TORCH:
            return None

        experiences = self.sample(batch_size)
        if not experiences:
            return None

        inputs = np.stack([e.to_input_tensor() for e in experiences])
        success_labels = np.array([e.success_label for e in experiences], dtype=np.float32)
        slip_labels = np.array([e.slip_label for e in experiences], dtype=np.float32)
        force_labels = np.array([e.force_label for e in experiences], dtype=np.float32)
        # 접근 보정 타겟: 실제 접근 - 계획 접근 (간소화: 0 벡터 사용)
        approach_labels = np.zeros((len(experiences), APPROACH_CORRECTION_DIM), dtype=np.float32)

        return {
            "input": torch.FloatTensor(inputs).to(device),
            "success": torch.FloatTensor(success_labels).to(device),
            "slip": torch.FloatTensor(slip_labels).to(device),
            "optimal_force": torch.FloatTensor(force_labels).to(device),
            "approach_correction": torch.FloatTensor(approach_labels).to(device),
        }


# ═══════════════════════════════════════════════════════════════════════
# Grasp Experience Dataset / 파지 경험 데이터셋
# ═══════════════════════════════════════════════════════════════════════

class GraspExperienceDataset(Dataset if HAS_TORCH else object):
    """
    파지 경험 PyTorch Dataset / Grasp experience PyTorch Dataset.
    SQLite 영속화 + 인메모리 캐시.
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._ensure_schema()
        self._indices: List[int] = self._load_indices()
        self._cache: Dict[int, GraspExperience] = {}
        logger.info(f"GraspExperienceDataset: {len(self._indices)} 샘플 / samples")

    def _ensure_schema(self):
        """데이터베이스 스키마 보장 / Ensure database schema."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS grasp_experiences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                input_vector BLOB NOT NULL,
                object_features BLOB NOT NULL,
                hand_config BLOB NOT NULL,
                approach BLOB NOT NULL,
                force_profile BLOB NOT NULL,
                outcome TEXT NOT NULL,
                actual_force_n REAL DEFAULT 0,
                was_successful INTEGER DEFAULT 1,
                slipped INTEGER DEFAULT 0,
                object_damaged INTEGER DEFAULT 0,
                timestamp REAL DEFAULT 0
            )
        """)
        self._conn.commit()

    def _load_indices(self) -> List[int]:
        rows = self._conn.execute("SELECT id FROM grasp_experiences").fetchall()
        return [r[0] for r in rows]

    def __len__(self) -> int:
        return len(self._indices)

    def __getitem__(self, idx: int) -> Tuple:
        seq_id = self._indices[idx]
        row = self._conn.execute(
            "SELECT input_vector, outcome, actual_force_n, was_successful, "
            "slipped, object_damaged FROM grasp_experiences WHERE id=?",
            (seq_id,)
        ).fetchone()

        if row is None:
            return self._zero_sample()

        input_vec = np.frombuffer(row[0], dtype=np.float32).copy()
        success_label = float(row[3])
        slip_label = float(row[4])

        # 최적력 타겟 계산 / Compute optimal force target
        actual_force = row[2]
        if success_label > 0.5 and slip_label < 0.5:
            force_target = actual_force
        elif slip_label > 0.5:
            force_target = min(FORCE_MAX, actual_force * 1.3)
        else:
            force_target = max(FORCE_MIN, actual_force * 0.7)

        approach_correction = np.zeros(APPROACH_CORRECTION_DIM, dtype=np.float32)

        return (
            torch.FloatTensor(input_vec) if HAS_TORCH else input_vec,
            torch.tensor(success_label, dtype=torch.float32) if HAS_TORCH else success_label,
            torch.tensor(slip_label, dtype=torch.float32) if HAS_TORCH else slip_label,
            torch.tensor(force_target, dtype=torch.float32) if HAS_TORCH else force_target,
            torch.FloatTensor(approach_correction) if HAS_TORCH else approach_correction,
        )

    def _zero_sample(self) -> Tuple:
        z = torch.zeros(TOTAL_INPUT_DIM) if HAS_TORCH else np.zeros(TOTAL_INPUT_DIM)
        za = torch.zeros(APPROACH_CORRECTION_DIM) if HAS_TORCH else np.zeros(APPROACH_CORRECTION_DIM)
        return (z, torch.tensor(0.0), torch.tensor(0.0), torch.tensor(FORCE_DEFAULT), za)

    def add_experience(self, exp: GraspExperience) -> int:
        """새 파지 경험 추가 / Add a new grasp experience."""
        input_vec = exp.to_input_tensor()
        cursor = self._conn.execute(
            "INSERT INTO grasp_experiences "
            "(input_vector, object_features, hand_config, approach, force_profile, "
            "outcome, actual_force_n, was_successful, slipped, object_damaged, timestamp) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (input_vec.astype(np.float32).tobytes(),
             exp.object_features.astype(np.float32).tobytes(),
             exp.hand_config.astype(np.float32).tobytes(),
             exp.approach.astype(np.float32).tobytes(),
             exp.force_profile.astype(np.float32).tobytes(),
             exp.outcome.value, exp.actual_force_n,
             int(exp.was_successful), int(exp.slipped),
             int(exp.object_damaged), exp.timestamp)
        )
        row_id = cursor.lastrowid
        self._conn.commit()
        self._indices.append(row_id)
        return row_id


# ═══════════════════════════════════════════════════════════════════════
# GripInferenceEngine / 파지 추론 엔진
# ═══════════════════════════════════════════════════════════════════════

class GripInferenceEngine:
    """
    파지 예측 추론 엔진 / Grasp prediction inference engine.

    GripPredictorNet을 래핑하여 고수준 예측 API 제공.
    온라인 학습, 경험 재생, 피우샷 적응, 신뢰도 추정 지원.

    Wraps GripPredictorNet for high-level prediction API.
    Supports online learning, experience replay, few-shot adaptation,
    and confidence estimation.

    Usage (main.py):
        engine = GripInferenceEngine(device='cpu')
        prediction = engine.predict(obj_features, hand_config, approach, force)
        engine.record_outcome(prediction, actual_outcome, actual_force)
    """

    def __init__(self, device: str = 'cpu'):
        """
        파지 추론 엔진 초기화 / Initialize grasp inference engine.

        Args:
            device: 연산 디바이스 ('cpu' or 'cuda')
        """
        if not HAS_TORCH:
            raise RuntimeError("PyTorch 설치 필요 / PyTorch required for GripInferenceEngine")

        self.device = torch.device(device)
        self.model = GripPredictorNet().to(self.device)
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY
        )
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer, T_0=10, T_mult=2
        )

        # 경험 재생 버퍼 / Experience replay buffer
        self._replay_buffer = ReplayBuffer(REPLAY_BUFFER_SIZE)

        # 영속 데이터셋 / Persistent dataset
        self._dataset = GraspExperienceDataset(DB_PATH)

        # 상태 추적 / State tracking
        self._prediction_counter = 0
        self._total_predictions = 0
        self._total_recorded = 0
        self._online_train_steps = 0
        self._last_train_time = 0.0
        self._lock = threading.Lock()

        # 신뢰도 추적 (EMA) / Confidence tracking (exponential moving average)
        self._confidence_ema = 0.5
        self._accuracy_history: deque = deque(maxlen=100)

        # 피우샷 적응 상태 / Few-shot adaptation state
        self._adaptation_cache: Dict[str, List[GraspExperience]] = {}

        # MC Dropout 활성화 플래그 / MC Dropout active flag
        self._mc_dropout_active = False

        logger.info(f"GripInferenceEngine 초기화: device={self.device} / Initialized")

    # ── 핵심 예측 API / Core Prediction API ───────────────────────────

    def predict(
        self,
        object_features: ObjectFeatures,
        hand_config: HandConfiguration,
        approach: ApproachAngle,
        force_profile: ForceProfile,
    ) -> GripPrediction:
        """
        파지 결과 예측 / Predict grasp outcome.

        행동 실행 전 호출하여 성공 확률, 슬립 확률, 최적력, 최적 접근 각도를 예측.
        MC Dropout으로 신뢰도 추정.

        Args:
            object_features: 객체 특징 (크기, 무게, 재질, 형상)
            hand_config: 핸드 구성 (손가락, 손목, 파지 개구)
            approach: 접근 각도 (고도, 방위, 거리, 속도)
            force_profile: 힘 프로파일 (목표력, 기울기, 지속시간)

        Returns:
            GripPrediction: 파지 예측 결과
        """
        self.model.eval()
        input_vec = np.concatenate([
            object_features.to_vector(),
            hand_config.to_vector(),
            approach.to_vector(),
            force_profile.to_vector(),
        ])

        input_tensor = torch.FloatTensor(input_vec).unsqueeze(0).to(self.device)

        # MC Dropout으로 불확실성 추정 / Uncertainty estimation via MC Dropout
        predictions_list = []
        for _ in range(MC_DROPOUT_SAMPLES):
            self._enable_mc_dropout()
            with torch.no_grad():
                preds = self.model(input_tensor)
                predictions_list.append({
                    k: v.cpu().numpy().squeeze()
                    for k, v in preds.items()
                })

        # 평균 및 표준편차 계산 / Compute mean and std
        success_probs = np.array([p["success_prob"] for p in predictions_list])
        slip_probs = np.array([p["slip_prob"] for p in predictions_list])
        optimal_forces = np.array([p["optimal_force"] for p in predictions_list])
        approach_corrections = np.array([p["approach_correction"] for p in predictions_list])

        mean_success = float(np.mean(success_probs))
        mean_slip = float(np.mean(slip_probs))
        mean_force = float(np.mean(optimal_forces))
        mean_correction = np.mean(approach_corrections, axis=0)

        # 신뢰도: 예측 분산의 역수로 추정 / Confidence from inverse prediction variance
        success_std = float(np.std(success_probs))
        slip_std = float(np.std(slip_probs))
        force_std = float(np.std(optimal_forces))

        # 낮은 분산 = 높은 신뢰도 / Low variance = high confidence
        variance_score = (success_std + slip_std + force_std / FORCE_MAX) / 3.0
        confidence = float(np.clip(1.0 - variance_score * 2.0, 0.05, 0.99))

        # EMA 업데이트 / EMA update
        self._confidence_ema = 0.9 * self._confidence_ema + 0.1 * confidence

        # 최적 접근 각도 계산 / Compute optimal approach angle
        optimal_approach = ApproachAngle(
            elevation_rad=np.clip(
                approach.elevation_rad + mean_correction[0],
                *APPROACH_ELEV_RANGE
            ),
            azimuth_rad=np.clip(
                approach.azimuth_rad + mean_correction[1],
                *APPROACH_AZIM_RANGE
            ),
            distance_m=max(0.05, approach.distance_m + mean_correction[2] * 0.1),
            speed_ms=approach.speed_ms,
        )

        # 파지력 범위 클리핑 / Clip force to valid range
        optimal_force = float(np.clip(mean_force, FORCE_MIN, FORCE_MAX))

        # 안전 여유력: 최적력 - (슬립 방지 최소력 추정) / Safety margin
        slip_threshold_force = optimal_force * mean_slip  # 슬립 시 필요한 추가력 추정
        force_margin = max(0.0, optimal_force * (1.0 - mean_slip) - slip_threshold_force)

        # 파손 위험도: 객체 취약성 × 적용력 기반 / Damage risk from fragility × force
        damage_risk = float(np.clip(
            object_features.fragility * (optimal_force / FORCE_MAX) + mean_slip * 0.2,
            0.0, 1.0
        ))

        # 신뢰도 수준 / Confidence level
        if confidence < LOW_CONFIDENCE_THRESHOLD:
            conf_level = ConfidenceLevel.LOW
        elif confidence < HIGH_CONFIDENCE_THRESHOLD:
            conf_level = ConfidenceLevel.MEDIUM
        else:
            conf_level = ConfidenceLevel.HIGH

        # 유사 경험 수 / Count similar experiences
        num_similar = self._count_similar_experiences(input_vec)

        with self._lock:
            self._prediction_counter += 1
            self._total_predictions += 1
            pred_id = self._prediction_counter

        prediction = GripPrediction(
            success_probability=mean_success,
            slip_probability=mean_slip,
            optimal_force_n=optimal_force,
            optimal_approach=optimal_approach,
            confidence=confidence,
            confidence_level=conf_level,
            force_margin_n=force_margin,
            damage_risk=damage_risk,
            num_similar_experiences=num_similar,
            prediction_id=pred_id,
        )

        logger.debug(
            f"파지 예측 #{pred_id}: 성공={mean_success:.2f}, 슬립={mean_slip:.2f}, "
            f"최적력={optimal_force:.1f}N, 신뢰도={confidence:.2f}({conf_level.value})"
        )

        return prediction

    def predict_simple(
        self,
        object_size: Tuple[float, float, float] = (0.1, 0.1, 0.1),
        object_weight: float = 0.5,
        approach_elevation: float = 0.0,
        approach_azimuth: float = 0.0,
        target_force: float = FORCE_DEFAULT,
    ) -> GripPrediction:
        """
        간소화된 예측 API / Simplified prediction API.
        기본값으로 빠르게 파지 예측.
        """
        obj_feat = ObjectFeatures(
            size=np.array(object_size, dtype=np.float32),
            weight=object_weight,
            material_probs=np.zeros(NUM_MATERIAL_CLASSES, dtype=np.float32),
            shape_probs=np.zeros(NUM_SHAPE_CLASSES, dtype=np.float32),
        )
        hand_cfg = HandConfiguration()
        approach = ApproachAngle(
            elevation_rad=approach_elevation,
            azimuth_rad=approach_azimuth,
        )
        force_prof = ForceProfile(target_force_n=target_force)

        return self.predict(obj_feat, hand_cfg, approach, force_prof)

    # ── 온라인 학습 / Online Learning ─────────────────────────────────

    def record_outcome(
        self,
        prediction: GripPrediction,
        actual_outcome: GraspOutcome,
        actual_force_n: float = 0.0,
        object_features: Optional[ObjectFeatures] = None,
        hand_config: Optional[HandConfiguration] = None,
        approach: Optional[ApproachAngle] = None,
        force_profile: Optional[ForceProfile] = None,
    ) -> bool:
        """
        파지 결과 기록 및 온라인 학습 / Record grasp outcome and learn online.

        예측 후 실제 결과를 기록하여 경험 재생 버퍼에 저장하고,
        일정 횟수 이상이면 온라인 학습 수행.

        Args:
            prediction: 이전 파지 예측 결과
            actual_outcome: 실제 파지 결과
            actual_force_n: 실제 적용 파지력 (N)
            object_features: 객체 특징 (없으면 기본값)
            hand_config: 핸드 구성 (없으면 기본값)
            approach: 접근 각도 (없으면 기본값)
            force_profile: 힘 프로파일 (없으면 기본값)

        Returns:
            기록 성공 여부
        """
        was_successful = actual_outcome in (GraspOutcome.SUCCESS,)
        slipped = actual_outcome == GraspOutcome.SLIP
        object_damaged = actual_outcome == GraspOutcome.CRUSH

        # 기본값 생성 / Create defaults if not provided
        if object_features is None:
            object_features = ObjectFeatures()
        if hand_config is None:
            hand_config = HandConfiguration()
        if approach is None:
            approach = ApproachAngle()
        if force_profile is None:
            force_profile = ForceProfile()

        # 경험 생성 / Create experience
        experience = GraspExperience(
            object_features=object_features.to_vector(),
            hand_config=hand_config.to_vector(),
            approach=approach.to_vector(),
            force_profile=force_profile.to_vector(),
            outcome=actual_outcome,
            actual_force_n=actual_force_n if actual_force_n > 0 else prediction.optimal_force_n,
            was_successful=was_successful,
            slipped=slipped,
            object_damaged=object_damaged,
        )

        # 재생 버퍼에 추가 / Add to replay buffer
        self._replay_buffer.push(experience)

        # 영속 데이터셋에 추가 / Add to persistent dataset
        try:
            self._dataset.add_experience(experience)
        except Exception as e:
            logger.debug(f"경험 영속화 실패: {e}")

        # 정확도 기록 / Track accuracy
        predicted_success = prediction.success_probability > 0.5
        self._accuracy_history.append(1.0 if predicted_success == was_successful else 0.0)

        with self._lock:
            self._total_recorded += 1

        # 일정 횟수마다 온라인 학습 / Online learning periodically
        if self._total_recorded % 5 == 0 and len(self._replay_buffer) >= REPLAY_BATCH_SIZE:
            self._online_train_step()

        # 피우샷 적응 캐시 업데이트 / Update few-shot cache
        obj_key = self._object_key(object_features)
        if obj_key not in self._adaptation_cache:
            self._adaptation_cache[obj_key] = []
        self._adaptation_cache[obj_key].append(experience)
        # 캐시 크기 제한 / Limit cache size
        if len(self._adaptation_cache[obj_key]) > 50:
            self._adaptation_cache[obj_key] = self._adaptation_cache[obj_key][-50:]

        logger.info(
            f"파지 결과 기록: 예측={prediction.success_probability:.2f}, "
            f"실제={actual_outcome.value}, 힘={actual_force_n:.1f}N"
        )
        return True

    def _online_train_step(self) -> float:
        """
        경험 재생 기반 온라인 학습 스텝 / Online training step with experience replay.

        Returns:
            훈련 손실값
        """
        batch = self._replay_buffer.sample_tensors(REPLAY_BATCH_SIZE, str(self.device))
        if batch is None:
            return 0.0

        self.model.train()
        self.optimizer.zero_grad()

        predictions = self.model(batch["input"])
        targets = {
            "success": batch["success"],
            "slip": batch["slip"],
            "optimal_force": batch["optimal_force"],
            "approach_correction": batch["approach_correction"],
        }

        loss = self.model.compute_loss(predictions, targets)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), GRAD_CLIP_NORM)
        self.optimizer.step()

        self._online_train_steps += 1
        self._last_train_time = time.time()

        loss_val = loss.item()
        if self._online_train_steps % 10 == 0:
            logger.debug(f"온라인 학습 스텝 {self._online_train_steps}: loss={loss_val:.4f}")

        self.model.eval()
        return loss_val

    # ── 배치 훈련 / Batch Training ─────────────────────────────────────

    def train_from_replay(self, epochs: int = 10, batch_size: int = BATCH_SIZE) -> List[float]:
        """
        경험 재생으로 전체 훈련 / Full training from experience replay.

        Args:
            epochs: 훈련 에포크 수
            batch_size: 배치 크기

        Returns:
            에포크별 손실 리스트
        """
        if len(self._replay_buffer) < batch_size:
            logger.warning("경험 부족으로 훈련 불가 / Insufficient experience for training")
            return []

        self.model.train()
        epoch_losses = []

        for epoch in range(epochs):
            epoch_loss = 0.0
            num_steps = 0

            for _ in range(max(1, len(self._replay_buffer) // batch_size)):
                batch = self._replay_buffer.sample_tensors(batch_size, str(self.device))
                if batch is None:
                    continue

                self.optimizer.zero_grad()
                predictions = self.model(batch["input"])
                targets = {
                    "success": batch["success"],
                    "slip": batch["slip"],
                    "optimal_force": batch["optimal_force"],
                    "approach_correction": batch["approach_correction"],
                }
                loss = self.model.compute_loss(predictions, targets)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), GRAD_CLIP_NORM)
                self.optimizer.step()

                epoch_loss += loss.item()
                num_steps += 1

            self.scheduler.step()
            avg_loss = epoch_loss / max(1, num_steps)
            epoch_losses.append(avg_loss)

            if (epoch + 1) % 5 == 0:
                log_vars = self.model.log_vars.detach().cpu().numpy()
                logger.info(
                    f"[파지예측/GripPred] epoch {epoch+1}/{epochs} "
                    f"loss={avg_loss:.4f} log_vars={log_vars.round(2)}"
                )

        self.model.eval()
        logger.info(f"경험 재생 훈련 완료: {epochs} epochs / Replay training complete")
        return epoch_losses

    def train_from_dataset(self, epochs: int = MAX_EPOCHS, batch_size: int = BATCH_SIZE) -> List[float]:
        """
        영속 데이터셋으로 훈련 / Train from persistent dataset.

        Args:
            epochs: 훈련 에포크 수
            batch_size: 배치 크기

        Returns:
            에포크별 손실 리스트
        """
        if len(self._dataset) < batch_size:
            logger.warning("데이터 부족 / Insufficient data")
            return []

        dataloader = DataLoader(self._dataset, batch_size=batch_size,
                                shuffle=True, drop_last=True)
        optimizer = torch.optim.AdamW(self.model.parameters(),
                                       lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

        self.model.train()
        epoch_losses = []

        for epoch in range(epochs):
            epoch_loss = 0.0
            count = 0

            for input_vec, success, slip, force, approach_corr in dataloader:
                input_vec = input_vec.to(self.device)
                predictions = self.model(input_vec)
                targets = {
                    "success": success.to(self.device),
                    "slip": slip.to(self.device),
                    "optimal_force": force.to(self.device),
                    "approach_correction": approach_corr.to(self.device),
                }

                loss = self.model.compute_loss(predictions, targets)
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), GRAD_CLIP_NORM)
                optimizer.step()

                epoch_loss += loss.item()
                count += 1

            scheduler.step()
            avg_loss = epoch_loss / max(1, count)
            epoch_losses.append(avg_loss)

            if (epoch + 1) % 10 == 0:
                logger.info(f"[파지예측/DS] epoch {epoch+1}/{epochs} loss={avg_loss:.4f}")

        self.model.eval()
        logger.info("데이터셋 훈련 완료 / Dataset training complete")
        return epoch_losses

    # ── 피우샷 적응 / Few-Shot Adaptation ──────────────────────────────

    def adapt_to_object(
        self,
        object_features: ObjectFeatures,
        examples: Optional[List[GraspExperience]] = None,
        inner_steps: int = FEWSHOT_INNER_STEPS,
        inner_lr: float = FEWSHOT_INNER_LR,
    ) -> Dict[str, Any]:
        """
        새로운 객체에 피우샷 적응 / Few-shot adaptation to a new object.

        MAML-style 내부 루프로 소수의 예제로 빠르게 적응.
        적응 후 가중치는 임시이며, 결과가 좋으면 record_outcome으로 영구 학습.

        Args:
            object_features: 새 객체 특징
            examples: 피우샷 예제 (없으면 캐시에서 검색)
            inner_steps: 내부 최적화 스텝 수
            inner_lr: 내부 학습률

        Returns:
            적응 결과 (loss 감소율, 적응 전후 비교)
        """
        obj_key = self._object_key(object_features)

        # 예제 확보 / Get examples
        if examples is None:
            examples = self._adaptation_cache.get(obj_key, [])
        if len(examples) < 2:
            logger.info(f"피우샷 예제 부족 ({len(examples)}개): 적응 생략 / Too few examples")
            return {"adapted": False, "reason": "insufficient_examples", "num_examples": len(examples)}

        # 현재 가중치 백업 / Backup current weights
        original_state = {k: v.clone() for k, v in self.model.state_dict().items()}

        # 예제를 텐서로 변환 / Convert examples to tensors
        inputs = np.stack([e.to_input_tensor() for e in examples])
        success_labels = np.array([e.success_label for e in examples], dtype=np.float32)
        slip_labels = np.array([e.slip_label for e in examples], dtype=np.float32)
        force_labels = np.array([e.force_label for e in examples], dtype=np.float32)
        approach_labels = np.zeros((len(examples), APPROACH_CORRECTION_DIM), dtype=np.float32)

        input_t = torch.FloatTensor(inputs).to(self.device)
        target_dict = {
            "success": torch.FloatTensor(success_labels).to(self.device),
            "slip": torch.FloatTensor(slip_labels).to(self.device),
            "optimal_force": torch.FloatTensor(force_labels).to(self.device),
            "approach_correction": torch.FloatTensor(approach_labels).to(self.device),
        }

        # 적응 전 손실 / Pre-adaptation loss
        self.model.eval()
        with torch.no_grad():
            pre_preds = self.model(input_t)
            pre_loss = self.model.compute_loss(pre_preds, target_dict).item()

        # 내부 루프 최적화 / Inner loop optimization
        self.model.train()
        inner_optimizer = torch.optim.SGD(self.model.parameters(), lr=inner_lr)

        step_losses = []
        for step in range(inner_steps):
            predictions = self.model(input_t)
            loss = self.model.compute_loss(predictions, target_dict)
            inner_optimizer.zero_grad()
            loss.backward()
            inner_optimizer.step()
            step_losses.append(loss.item())

        # 적응 후 손실 / Post-adaptation loss
        self.model.eval()
        with torch.no_grad():
            post_preds = self.model(input_t)
            post_loss = self.model.compute_loss(post_preds, target_dict).item()

        # 원래 가중치 복원 / Restore original weights
        # (피우샷 적응은 일시적; 결과에 따라 record_outcome으로 영구 반영)
        self.model.load_state_dict(original_state)

        improvement = pre_loss - post_loss
        logger.info(
            f"피우샷 적응 ({obj_key}): {len(examples)}예제, "
            f"loss {pre_loss:.4f}→{post_loss:.4f} (Δ={improvement:+.4f})"
        )

        return {
            "adapted": True,
            "num_examples": len(examples),
            "inner_steps": inner_steps,
            "pre_loss": pre_loss,
            "post_loss": post_loss,
            "improvement": improvement,
            "step_losses": step_losses,
            "should_apply": improvement > 0.01,
        }

    def apply_adaptation(self, object_features: ObjectFeatures,
                         inner_steps: int = FEWSHOT_INNER_STEPS,
                         inner_lr: float = FEWSHOT_INNER_LR) -> bool:
        """
        피우샷 적응 결과를 영구 적용 / Permanently apply few-shot adaptation.
        (주의: 치명적 망각 위험 — 과적합 방지 위해 제한적 사용)
        """
        result = self.adapt_to_object(object_features, inner_steps=inner_steps, inner_lr=inner_lr)
        if not result.get("should_apply", False):
            return False

        # 적응 적용: 내부 루프 다시 실행 (가중치 복원하지 않음)
        obj_key = self._object_key(object_features)
        examples = self._adaptation_cache.get(obj_key, [])
        if len(examples) < 2:
            return False

        inputs = np.stack([e.to_input_tensor() for e in examples])
        success_labels = np.array([e.success_label for e in examples], dtype=np.float32)
        slip_labels = np.array([e.slip_label for e in examples], dtype=np.float32)
        force_labels = np.array([e.force_label for e in examples], dtype=np.float32)
        approach_labels = np.zeros((len(examples), APPROACH_CORRECTION_DIM), dtype=np.float32)

        input_t = torch.FloatTensor(inputs).to(self.device)
        target_dict = {
            "success": torch.FloatTensor(success_labels).to(self.device),
            "slip": torch.FloatTensor(slip_labels).to(self.device),
            "optimal_force": torch.FloatTensor(force_labels).to(self.device),
            "approach_correction": torch.FloatTensor(approach_labels).to(self.device),
        }

        self.model.train()
        inner_optimizer = torch.optim.SGD(self.model.parameters(), lr=inner_lr * 0.5)
        for _ in range(inner_steps):
            predictions = self.model(input_t)
            loss = self.model.compute_loss(predictions, target_dict)
            inner_optimizer.zero_grad()
            loss.backward()
            inner_optimizer.step()

        self.model.eval()
        logger.info(f"피우샷 적응 영구 적용: {obj_key}")
        return True

    # ── 신뢰도 및 메트릭 / Confidence & Metrics ────────────────────────

    def get_confidence(self) -> float:
        """현재 평균 신뢰도 반환 / Return current average confidence."""
        return self._confidence_ema

    def get_accuracy(self) -> float:
        """최근 예측 정확도 반환 / Return recent prediction accuracy."""
        if not self._accuracy_history:
            return 0.0
        return sum(self._accuracy_history) / len(self._accuracy_history)

    def get_metrics(self) -> Dict[str, Any]:
        """
        엔진 메트릭 조회 / Get engine metrics.

        Returns:
            메트릭 딕셔너리
        """
        return {
            "total_predictions": self._total_predictions,
            "total_recorded": self._total_recorded,
            "online_train_steps": self._online_train_steps,
            "replay_buffer_size": len(self._replay_buffer),
            "dataset_size": len(self._dataset),
            "confidence_ema": round(self._confidence_ema, 3),
            "recent_accuracy": round(self.get_accuracy(), 3),
            "adaptation_cache_size": len(self._adaptation_cache),
            "device": str(self.device),
            "model_params": sum(p.numel() for p in self.model.parameters()) if HAS_TORCH else 0,
        }

    # ── 저장/로드 / Save/Load ──────────────────────────────────────────

    def save(self, path: str = "grip_predictor_net.pt"):
        """모델 저장 / Save model checkpoint."""
        if not HAS_TORCH:
            return
        checkpoint = {
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "online_train_steps": self._online_train_steps,
            "total_predictions": self._total_predictions,
            "total_recorded": self._total_recorded,
            "confidence_ema": self._confidence_ema,
        }
        torch.save(checkpoint, path)
        logger.info(f"모델 저장: {path} / Model saved")

    def load(self, path: str = "grip_predictor_net.pt") -> bool:
        """모델 로드 / Load model checkpoint."""
        if not HAS_TORCH:
            return False
        try:
            checkpoint = torch.load(path, map_location=self.device, weights_only=False)
            self.model.load_state_dict(checkpoint["model_state_dict"])
            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
            self._online_train_steps = checkpoint.get("online_train_steps", 0)
            self._total_predictions = checkpoint.get("total_predictions", 0)
            self._total_recorded = checkpoint.get("total_recorded", 0)
            self._confidence_ema = checkpoint.get("confidence_ema", 0.5)
            logger.info(f"모델 로드: {path} / Model loaded")
            return True
        except Exception as e:
            logger.warning(f"모델 로드 실패: {e}")
            return False

    # ── 내부 유틸리티 / Internal Utilities ─────────────────────────────

    def _enable_mc_dropout(self):
        """MC Dropout 활성화: eval 모드에서도 dropout 유지 / Enable dropout in eval mode."""
        self.model.eval()  # BatchNorm/LayerNorm은 eval 모드
        for module in self.model.modules():
            if isinstance(module, nn.Dropout):
                module.train()  # Dropout만 train 모드

    def _count_similar_experiences(self, input_vec: np.ndarray, threshold: float = 2.0) -> int:
        """
        유사 과거 경험 수 카운트 / Count similar past experiences.
        코사인 유사도 기반.
        """
        if len(self._replay_buffer) == 0:
            return 0

        sample = self._replay_buffer.sample(min(200, len(self._replay_buffer)))
        if not sample:
            return 0

        stored_vecs = np.stack([e.to_input_tensor() for e in sample])
        input_norm = np.linalg.norm(input_vec)
        if input_norm < 1e-8:
            return 0

        similarities = np.dot(stored_vecs, input_vec) / (
            np.linalg.norm(stored_vecs, axis=1) * input_norm + 1e-8
        )
        return int(np.sum(similarities > (1.0 - threshold * 0.1)))

    def _object_key(self, obj_features: ObjectFeatures) -> str:
        """객체 특징에서 해시 키 생성 / Generate hash key from object features."""
        size_str = "_".join(f"{x:.2f}" for x in obj_features.size)
        return f"obj_{size_str}_w{obj_features.weight:.1f}"

    def suggest_force(self, object_features: ObjectFeatures) -> float:
        """
        객체 특징 기반 파지력 제안 / Suggest grip force based on object features.
        모델 예측 없이 휴리스틱으로 빠르게 제안.
        """
        # 무게에 기반한 최소 파지력 (마찰계수 ≈ 0.5 가정)
        min_force = object_features.weight * 9.81 / 0.5  # F = mg/μ

        # 취약성에 따른 상한선 / Upper limit from fragility
        max_safe_force = FORCE_MAX * (1.0 - 0.7 * object_features.fragility)

        # 변형성에 따른 조정 / Adjust for deformability
        if object_features.deformability > 0.5:
            max_safe_force *= (1.0 - 0.3 * object_features.deformability)

        suggested = np.clip(min_force * 1.5, FORCE_MIN, min(max_safe_force, FORCE_MAX))
        return float(suggested)

    def suggest_approach(self, object_features: ObjectFeatures) -> ApproachAngle:
        """
        객체 특징 기반 접근 각도 제안 / Suggest approach angle based on object features.
        """
        # 형상 기반 기본 접근 각도 / Shape-based default approach
        shape_idx = int(np.argmax(object_features.shape_probs)) if object_features.shape_probs.any() else 0

        # 형상별 기본 접근 전략 / Shape-based default approach strategy
        shape_approaches = {
            0: ApproachAngle(elevation_rad=0.3, azimuth_rad=0.0),       # sphere: 위에서
            1: ApproachAngle(elevation_rad=0.0, azimuth_rad=0.0),       # cylinder: 옆에서
            2: ApproachAngle(elevation_rad=0.5, azimuth_rad=0.0),       # box: 위에서
            3: ApproachAngle(elevation_rad=0.2, azimuth_rad=0.3),       # cone: 비스듬히
            5: ApproachAngle(elevation_rad=0.7, azimuth_rad=0.0),       # flat: 수직
        }

        return shape_approaches.get(shape_idx, ApproachAngle())


# ============================================================================
# MC Dropout Fix + MAML Few-Shot Adaptation — Physical AGI 파지 혁신
# ============================================================================
# 기존 문제:
# 1. Approach correction 타겟이 항상 0 → 학습 안 됨
# 2. MC Dropout가 Sigmoid 뒤에 위치 → 불확실성 보정 불량
# 3. MAML 선언만 있고 구현 없음
# 혁신:
# 1. 올바른 MC Dropout 위치 + 베이지안 파지 예측
# 2. MAML 내부 루프 구현 — 5샷 적응으로 새 물체 파지
# 3. 손상 인지 파지 강화 학습
# ============================================================================

if HAS_TORCH:

    class BayesianGraspPredictor(nn.Module):
        """베이지안 파지 예측기 — 올바른 MC Dropout 적용
        
        핵심 수정:
        - Dropout을 Sigmoid 앞에 배치 (뒤가 아님!)
        - MC 샘플링으로 불확실성 정량화
        - 손상 위험 계산에 불확실성 통합
        """
        
        def __init__(self, input_dim=64, hidden_dim=128, num_mc_samples=20):
            super().__init__()
            self.num_mc_samples = num_mc_samples
            
            # Backbone
            self.backbone = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(0.1),  # MC Dropout 위치 1
                nn.Linear(hidden_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(0.1),  # MC Dropout 위치 2
            )
            
            # Heads (Dropout BEFORE activation!)
            self.success_head = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim // 2),
                nn.GELU(),
                nn.Dropout(0.1),  # MC Dropout 위치 3 (Sigmoid 앞!)
                nn.Linear(hidden_dim // 2, 1),
                nn.Sigmoid(),
            )
            
            self.slip_head = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim // 2),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_dim // 2, 1),
                nn.Sigmoid(),
            )
            
            self.force_head = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim // 2),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_dim // 2, 1),
                nn.Softplus(),  # Force is always positive
            )
            
            self.approach_head = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim // 2),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_dim // 2, 2),  # 2D approach correction (x, y)
                nn.Tanh(),  # Bounded correction ±1
            )
        
        def forward(self, x, num_mc_samples=None):
            """베이지안 파지 예측"""
            if num_mc_samples is None:
                num_mc_samples = self.num_mc_samples
            
            if isinstance(x, np.ndarray):
                x = torch.FloatTensor(x)
            if x.dim() == 1:
                x = x.unsqueeze(0)
            
            # MC Dropout 샘플링
            all_success = []
            all_slip = []
            all_force = []
            all_approach = []
            
            for _ in range(num_mc_samples):
                features = self.backbone(x)
                all_success.append(self.success_head(features))
                all_slip.append(self.slip_head(features))
                all_force.append(self.force_head(features))
                all_approach.append(self.approach_head(features))
            
            success_stack = torch.stack(all_success, dim=0)
            slip_stack = torch.stack(all_slip, dim=0)
            force_stack = torch.stack(all_force, dim=0)
            approach_stack = torch.stack(all_approach, dim=0)
            
            # 평균 + 불확실성
            return {
                'success_prob': success_stack.mean(dim=0).squeeze(-1),
                'success_uncertainty': success_stack.std(dim=0).squeeze(-1),
                'slip_prob': slip_stack.mean(dim=0).squeeze(-1),
                'slip_uncertainty': slip_stack.std(dim=0).squeeze(-1),
                'optimal_force': force_stack.mean(dim=0).squeeze(-1),
                'force_uncertainty': force_stack.std(dim=0).squeeze(-1),
                'approach_correction': approach_stack.mean(dim=0),
                'approach_uncertainty': approach_stack.std(dim=0),
                'should_grasp': success_stack.mean(dim=0).squeeze(-1) > 0.7,
                'damage_risk': self._compute_damage_risk(
                    success_stack.mean(dim=0).squeeze(-1),
                    slip_stack.mean(dim=0).squeeze(-1),
                    force_stack.mean(dim=0).squeeze(-1),
                ),
            }
        
        def _compute_damage_risk(self, success_prob, slip_prob, force):
            """손상 위험 계산 (불확실성 가중)"""
            # 기본 손상 위험: 슬립 × 힘
            base_risk = slip_prob * force / (force.max() + 1e-8)
            
            # 불확실성 페널티: 확실하지 않으면 더 조심
            uncertainty_penalty = 1.0 - success_prob
            
            return torch.clamp(base_risk + 0.2 * uncertainty_penalty, 0, 1)


    class MAMLGraspAdapter:
        """MAML (Model-Agnostic Meta-Learning) 파지 적응
        
        새로운 물체를 5번만 파지해도 최적의 파지 전략을 학습.
        Physical AGI 핵심: 처음 보는 물체도 안전하게 잡기.
        """
        
        def __init__(self, model, inner_lr=1e-3, num_inner_steps=5,
                     second_order=True):
            self.model = model
            self.inner_lr = inner_lr
            self.num_inner_steps = num_inner_steps
            self.second_order = second_order
            self.task_adapted_params = {}
        
        def adapt_to_object(self, support_features, support_labels,
                            object_id=None):
            """새 물체에 대한 MAML 적응
            
            Args:
                support_features: [n_support, feature_dim] 파지 특징
                support_labels: [n_support] 성공/실패 라벨
                object_id: 물체 식별자 (캐시용)
            """
            # 캐시 확인
            cache_key = object_id or id(support_features)
            if cache_key in self.task_adapted_params:
                return self.task_adapted_params[cache_key]
            
            # 내부 루프: support set으로 빠른 적응
            fast_weights = {
                name: param.clone()
                for name, param in self.model.named_parameters()
            }
            
            for step in range(self.num_inner_steps):
                # 순전파 (fast weights 사용)
                predictions = self._forward_with_weights(
                    support_features, fast_weights
                )
                
                # 손실 계산
                labels = torch.FloatTensor(support_labels)
                loss = F.binary_cross_entropy(
                    predictions['success_prob'], labels
                )
                
                # 그래디언트 계산
                grads = torch.autograd.grad(
                    loss, fast_weights.values(),
                    create_graph=self.second_order
                )
                
                # 빠른 가중치 업데이트
                fast_weights = {
                    name: w - self.inner_lr * g
                    for (name, w), g in zip(fast_weights.items(), grads)
                }
            
            # 캐시에 저장
            self.task_adapted_params[cache_key] = fast_weights
            return fast_weights
        
        def _forward_with_weights(self, x, weights):
            """임의 가중치로 순전파 (MAML 내부 루프용)"""
            # 간소화: 모델의 가중치를 일시적으로 교체
            original_params = {
                name: param.data.clone()
                for name, param in self.model.named_parameters()
            }
            
            # fast weights 로드
            for name, param in self.model.named_parameters():
                if name in weights:
                    param.data.copy_(weights[name])
            
            # 순전파
            result = self.model(x, num_mc_samples=1)
            
            # 원래 가중치 복원
            for name, param in self.model.named_parameters():
                if name in original_params:
                    param.data.copy_(original_params[name])
            
            return result
        
        def meta_train_step(self, tasks):
            """메타 학습 스텝 (외부 루프)
            
            Args:
                tasks: [(support_features, support_labels, query_features, query_labels), ...]
            """
            meta_loss = 0
            
            for support_feat, support_labels, query_feat, query_labels in tasks:
                # 내부 루프 적응
                fast_weights = self.adapt_to_object(support_feat, support_labels)
                
                # 쿼리 셋에서 평가
                predictions = self._forward_with_weights(query_feat, fast_weights)
                labels = torch.FloatTensor(query_labels)
                task_loss = F.binary_cross_entropy(
                    predictions['success_prob'], labels
                )
                meta_loss += task_loss
            
            meta_loss /= len(tasks)
            return meta_loss

else:
    # PyTorch 미설치 시 스텁 클래스 / Stub classes when PyTorch is unavailable
    class BayesianGraspPredictor:
        """스텁: PyTorch 미설치 / Stub for when PyTorch is not installed."""
        pass

    class MAMLGraspAdapter:
        """스텁: PyTorch 미설치 / Stub for when PyTorch is not installed."""
        pass


# ═══════════════════════════════════════════════════════════════════════
# 모듈 레벨 데모 / Module-Level Demo
# ═══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")

    if not HAS_TORCH:
        logger.error("PyTorch 설치 필요 / PyTorch required")
    else:
        logger.info("═══ grip_predictor_net.py 데모 시작 / Demo Start ═══")

        # 1. 엔진 초기화 / Initialize engine
        engine = GripInferenceEngine(device='cpu')
        logger.info(f"엔진 메트릭: {engine.get_metrics()}")

        # 2. 가상 파지 예측 / Synthetic grasp prediction
        obj = ObjectFeatures(
            size=np.array([0.08, 0.08, 0.12], dtype=np.float32),
            weight=0.3,
            material_probs=np.eye(NUM_MATERIAL_CLASSES)[9],  # plastic
            shape_probs=np.eye(NUM_SHAPE_CLASSES)[1],        # cylinder
            fragility=0.2,
            deformability=0.1,
        )
        hand = HandConfiguration(
            grip_aperture=0.08,
            finger_positions=np.array([0.3, 0.5, 0.5, 0.5, 0.3], dtype=np.float32),
        )
        approach = ApproachAngle(elevation_rad=0.2, azimuth_rad=0.0)
        force = ForceProfile(target_force_n=5.0)

        prediction = engine.predict(obj, hand, approach, force)
        logger.info(f"파지 예측: 성공={prediction.success_probability:.2f}, "
                     f"슬립={prediction.slip_probability:.2f}, "
                     f"최적력={prediction.optimal_force_n:.1f}N, "
                     f"신뢰도={prediction.confidence:.2f}")
        logger.info(f"파지 실행 권장: {prediction.should_grasp}")

        # 3. 결과 기록 / Record outcome
        engine.record_outcome(
            prediction=prediction,
            actual_outcome=GraspOutcome.SUCCESS,
            actual_force_n=4.8,
            object_features=obj,
            hand_config=hand,
            approach=approach,
            force_profile=force,
        )

        # 4. 다양한 파지 경험 추가 / Add diverse grasp experiences
        outcomes = [GraspOutcome.SUCCESS, GraspOutcome.SLIP, GraspOutcome.SUCCESS,
                     GraspOutcome.CRUSH, GraspOutcome.SUCCESS, GraspOutcome.MISS,
                     GraspOutcome.SUCCESS, GraspOutcome.SUCCESS, GraspOutcome.SLIP,
                     GraspOutcome.SUCCESS]
        forces = [4.8, 3.2, 5.0, 8.5, 4.5, 2.0, 5.2, 4.0, 3.5, 5.5]

        for i, (outcome, f) in enumerate(zip(outcomes, forces)):
            pred = engine.predict_simple(
                object_size=(0.06 + i * 0.01, 0.06, 0.1),
                object_weight=0.2 + i * 0.05,
                target_force=f,
            )
            engine.record_outcome(
                prediction=pred,
                actual_outcome=outcome,
                actual_force_n=f,
                object_features=ObjectFeatures(
                    size=np.array([0.06 + i * 0.01, 0.06, 0.1], dtype=np.float32),
                    weight=0.2 + i * 0.05,
                    material_probs=np.eye(NUM_MATERIAL_CLASSES)[i % NUM_MATERIAL_CLASSES],
                    shape_probs=np.eye(NUM_SHAPE_CLASSES)[i % NUM_SHAPE_CLASSES],
                    fragility=0.1 + i * 0.05,
                ),
            )

        # 5. 경험 재생 훈련 / Train from replay
        losses = engine.train_from_replay(epochs=5, batch_size=8)
        logger.info(f"훈련 손실: {losses}")

        # 6. 최종 메트릭 / Final metrics
        metrics = engine.get_metrics()
        logger.info(f"최종 메트릭: {metrics}")
        logger.info(f"최근 정확도: {engine.get_accuracy():.2f}")
        logger.info(f"평균 신뢰도: {engine.get_confidence():.2f}")

        # 7. 모델 저장 / Save model
        engine.save("/tmp/grip_predictor_demo.pt")
        logger.info("═══ grip_predictor_net.py 데모 완료 / Demo Complete ═══")
