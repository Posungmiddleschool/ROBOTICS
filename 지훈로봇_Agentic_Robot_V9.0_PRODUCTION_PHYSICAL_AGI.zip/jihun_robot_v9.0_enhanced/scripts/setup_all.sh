#!/bin/bash
# 지훈 로봇 V9.0 — 원클릭 설치 스크립트
# ========================================
# Jetson Orin NX 또는 x86 Ubuntu에서 실행

set -e

echo "========================================"
echo "지훈 로봇 V9.0 — 설치 시작"
echo "========================================"

# Python 버전 확인
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python: $PYTHON_VERSION"

# 1. 시스템 의존성
echo "[1/6] 시스템 의존성 설치..."
sudo apt-get update
sudo apt-get install -y \
    build-essential cmake git curl \
    libopenblas-dev libomp-dev \
    libgl1-mesa-glx libglib2.0-0 \
    htop iperf3 \
    || echo "Some system packages failed (ok for container)"

# 2. Python 의존성
echo "[2/6] Python 패키지 설치..."
pip install --upgrade pip
pip install -r docker/requirements.txt

# 3. Jetson 특화 설정
echo "[3/6] Jetson 감지 및 설정..."
if [ -f /etc/nv_tegra_release ]; then
    echo "Jetson detected!"
    
    # jetson-stats
    pip install jetson-stats || true
    
    # CUDA 경로
    export PATH=/usr/local/cuda/bin:$PATH
    export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH
    
    # 성능 모드
    sudo nvpmodel -m 0 || true
    sudo jetson_clocks || true
    
    echo "Jetson configured for MAX performance"
else
    echo "Not a Jetson — using CPU mode"
fi

# 4. CAN 버스 설정
echo "[4/6] CAN 버스 설정..."
bash scripts/setup_can.sh || echo "CAN setup skipped"

# 5. Docker 설치 (선택)
echo "[5/6] Docker 확인..."
if ! command -v docker &> /dev/null; then
    echo "Docker not found. Install? (y/n)"
    read -r answer
    if [ "$answer" = "y" ]; then
        bash scripts/install_docker.sh
    fi
else
    echo "Docker: $(docker --version)"
fi

# 6. 환경 변수
echo "[6/6] 환경 설정..."
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
{
    echo ""
    echo "# 지훈 로봇 V9.0"
    echo "export JIHUN_ROBOT_HOME=$PROJECT_DIR"
    echo "export PYTHONPATH=\$JIHUN_ROBOT_HOME:\$PYTHONPATH"
    echo "export JIHUN_ROBOT_MODE=simulation"
    echo "export PATH=\$JIHUN_ROBOT_HOME/scripts:\$PATH"
} >> ~/.bashrc

echo ""
echo "========================================"
echo "설치 완료!"
echo "========================================"
echo ""
echo "사용법:"
echo "  source ~/.bashrc"
echo "  make demo          # 파이프라인 실행"
echo "  make dashboard     # 대시보드 실행"
echo "  make test          # 테스트 실행"
echo ""
echo "Docker:"
echo "  make docker-up     # 전체 스택"
echo ""
