#!/bin/bash
# 지훈 로봇 V9.0 — 데모 스크립트
# ==============================

set -e

echo "=========================================="
echo "지훈 로봇 V9.0 — 통합 데모"
echo "=========================================="
echo ""

# 모드 선택
MODE=${1:-simulation}
echo "Mode: $MODE"
export JIHUN_ROBOT_MODE=$MODE

# API 서버 백그라운드 시작
echo "[1/3] API 서버 시작..."
python docker/api_server.py &
API_PID=$!
sleep 3

# 상태 확인
echo "[2/3] 상태 확인..."
curl -s http://localhost:8000/health | python3 -m json.tool || echo "API not ready yet"

echo ""
echo "=========================================="
echo "데모 메뉴:"
echo "  1. 통합 파이프라인 (콘솔)"
echo "  2. 컵 잡기 시뮬레이션"
echo "  3. 납비게이션 시뮬레이션"
echo "  4. API 테스트"
echo "  5. 종료"
echo "=========================================="
echo ""

read -p "선택 (1-5): " choice

case $choice in
    1)
        echo "통합 파이프라인 시작..."
        python -m software.integration_pipeline
        ;;
    2)
        echo "컵 잡기 시뮬레이션..."
        python -m simulation.isaac_sim.bridge.isaac_bridge --scenario demo_cup --duration 60
        ;;
    3)
        echo "납비게이션 시뮬레이션..."
        python -m simulation.isaac_sim.bridge.isaac_bridge --scenario demo_nav --duration 60
        ;;
    4)
        echo "API 테스트..."
        echo "Health:"
        curl -s http://localhost:8000/health | python3 -m json.tool
        echo ""
        echo "Status:"
        curl -s http://localhost:8000/status | python3 -m json.tool
        echo ""
        read -p "명령 입력: " cmd
        curl -s -X POST http://localhost:8000/command \
            -H "Content-Type: application/json" \
            -d "{\"command\": \"$cmd\"}" | python3 -m json.tool
        ;;
    5)
        echo "종료."
        ;;
    *)
        echo "잘못된 선택."
        ;;
esac

# 정리
echo "API 서버 종료..."
kill $API_PID 2>/dev/null || true
echo "데모 완료."
