#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — 통합 파이프라인 테스트
=========================================
pytest 기반 자동화 테스트.

실제 하드웨어 없이 시뮬레이션 모드로 모든 테스트 실행.
coverage 목표: 핵심 5모듈 80%+

실행:
    pytest tests/ -v --cov=software --cov-report=html
"""

import json
import sys
import time
from pathlib import Path

import numpy as np
import pytest

# 소프트웨어 경로
sys.path.insert(0, str(Path(__file__).parent.parent / "software"))


# === Fixtures ===

@pytest.fixture
def hal():
    """시뮬레이션 HAL 픽스처."""
    from hardware_abstraction import create_hal
    h = create_hal("simulation")
    h.initialize()
    yield h
    h.shutdown()


@pytest.fixture
def pipeline():
    """통합 파이프라인 픽스처."""
    from integration_pipeline import IntegrationPipeline
    p = IntegrationPipeline()
    p.initialize()
    yield p
    p.shutdown()


@pytest.fixture
def safety_engine():
    """안전 엔진 픽스처."""
    from safety_engine import SafetyEngine
    se = SafetyEngine()
    se.activate()
    yield se


# === HAL 테스트 ===

class TestHAL:
    """하드웨어 추상화 레이어 테스트."""
    
    def test_initialization(self, hal):
        """HAL 초기화 테스트."""
        assert hal is not None
        state = hal.get_state()
        assert state is not None
    
    def test_state_structure(self, hal):
        """상태 데이터 구조 테스트."""
        state = hal.get_state()
        assert hasattr(state, 'position_m')
        assert hasattr(state, 'velocity_m_s')
        assert hasattr(state, 'battery_percent')
        assert state.battery_percent > 0
    
    def test_motor_command(self, hal):
        """모터 명령 테스트."""
        result = hal.send_motor_command("wheel_fr", 0.5, 1.0, 0.1)
        assert result is True
        
        state = hal.get_state()
        assert "wheel_fr" in state.motors
        assert state.motors["wheel_fr"].position_rad == 0.5
    
    def test_emergency_stop(self, hal):
        """비상 정지 테스트."""
        hal.send_motor_command("wheel_fr", 1.0, 2.0, 0.5)
        hal.emergency_stop()
        
        state = hal.get_state()
        assert state.estop_active is True
        assert state.safety_status == "ESTOP"
        assert state.motors["wheel_fr"].velocity_rad_s == 0
    
    def test_multiple_motors(self, hal):
        """다중 모터 제어 테스트."""
        motors = ["wheel_fr", "wheel_fl", "wheel_rr", "wheel_rl"]
        
        for i, m in enumerate(motors):
            hal.send_motor_command(m, i * 0.1, i * 0.2, 0.05)
        
        state = hal.get_state()
        for m in motors:
            assert m in state.motors


# === 파이프라인 테스트 ===

class TestIntegrationPipeline:
    """통합 파이프라인 테스트."""
    
    def test_initialization(self, pipeline):
        """파이프라인 초기화."""
        assert pipeline is not None
        assert pipeline.state is not None
    
    def test_metrics(self, pipeline):
        """메트릭 수집."""
        m = pipeline.get_metrics()
        assert hasattr(m, 'loop_hz')
        assert hasattr(m, 'total_experiences')
        assert m.uptime_seconds >= 0
    
    def test_command_queue(self, pipeline):
        """명령 큐."""
        pipeline.send_command("앞으로 가")
        pipeline.send_command("멈춰")
        assert len(pipeline._command_queue) == 2
    
    def test_simple_parser(self, pipeline):
        """간단 명령 파서."""
        # 한국어 명령
        result = pipeline._simple_parser("앞으로 가")
        assert result["action"] == "move_forward"
        
        result = pipeline._simple_parser("멈춰")
        assert result["action"] == "stop"
        
        result = pipeline._simple_parser("컵 잡아")
        assert result["action"] == "grip"
    
    def test_experience_collection(self, pipeline):
        """경험 수집."""
        from hardware_abstraction import RobotState
        
        state = RobotState()
        state.position_m = np.array([0.1, 0.2, 0.0])
        
        pipeline._collect_experience(state)
        assert len(pipeline._experience_buffer) > 0


# === 안전 엔진 테스트 ===

class TestSafetyEngine:
    """7계층 안전 엔진 테스트."""
    
    def test_activation(self, safety_engine):
        """활성화."""
        assert safety_engine is not None
    
    def test_verify_safe_state(self, safety_engine, hal):
        """안전 상태 검증."""
        state = hal.get_state()
        result = safety_engine.verify(state)
        assert isinstance(result, bool)


# === 시뮬레이션 브리지 테스트 ===

class TestIsaacBridge:
    """Isaac Sim 브리지 테스트."""
    
    def test_mock_initialization(self):
        """Mock 모드 초기화."""
        from isaac_sim.bridge.isaac_bridge import IsaacSimBridge, SimConfig
        
        bridge = IsaacSimBridge(SimConfig(headless=True))
        result = bridge.initialize()
        
        assert result is True
        assert bridge._running is True
        bridge.shutdown()
    
    def test_mock_step(self):
        """Mock 스텝."""
        from isaac_sim.bridge.isaac_bridge import IsaacSimBridge
        
        bridge = IsaacSimBridge()
        bridge.initialize()
        
        obs = bridge.step()
        assert "timestamp" in obs
        assert "step" in obs
        
        bridge.shutdown()
    
    def test_scenario_loading(self):
        """시나리오 로드."""
        from isaac_sim.bridge.isaac_bridge import IsaacSimBridge
        
        bridge = IsaacSimBridge()
        bridge.initialize()
        
        result = bridge.load_scenario("empty")
        assert result is True
        
        result = bridge.load_scenario("demo_cup")
        assert result is True
        
        bridge.shutdown()


# === 성능 벤치마크 ===

class TestPerformance:
    """성능 벤치마크 테스트."""
    
    def test_hal_latency(self, hal):
        """HAL 지연 시간."""
        latencies = []
        
        for _ in range(100):
            t0 = time.time()
            hal.get_state()
            t1 = time.time()
            latencies.append((t1 - t0) * 1000)  # ms
        
        avg_latency = np.mean(latencies)
        max_latency = np.max(latencies)
        
        # 평균 1ms 이하, 최대 5ms 이하
        assert avg_latency < 1.0, f"HAL avg latency: {avg_latency:.2f}ms"
        assert max_latency < 5.0, f"HAL max latency: {max_latency:.2f}ms"
    
    def test_motor_command_throughput(self, hal):
        """모터 명령 처리량."""
        t0 = time.time()
        
        for i in range(1000):
            hal.send_motor_command("wheel_fr", i * 0.001, 0.5, 0.1)
        
        elapsed = time.time() - t0
        throughput = 1000 / elapsed
        
        # 초당 10000개 이상
        assert throughput > 10000, f"Motor command throughput: {throughput:.0f}/s"


# === 부하 테스트 ===

class TestStress:
    """부하/스트레스 테스트."""
    
    def test_rapid_estop_toggle(self, hal):
        """빠른 E-Stop 토글."""
        for _ in range(100):
            hal.send_motor_command("wheel_fr", 1.0, 2.0, 0.5)
            hal.emergency_stop()
            state = hal.get_state()
            assert state.estop_active is True
            assert state.motors["wheel_fr"].velocity_rad_s == 0
    
    def test_memory_stability(self, pipeline):
        """메모리 안정성."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_mem = process.memory_info().rss / 1024 / 1024  # MB
        
        # 1000개 명령 처리
        for i in range(1000):
            pipeline.send_command(f"test_command_{i}")
        
        final_mem = process.memory_info().rss / 1024 / 1024
        mem_growth = final_mem - initial_mem
        
        # 50MB 이하 메모리 증가
        assert mem_growth < 50, f"Memory growth: {mem_growth:.1f}MB"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
