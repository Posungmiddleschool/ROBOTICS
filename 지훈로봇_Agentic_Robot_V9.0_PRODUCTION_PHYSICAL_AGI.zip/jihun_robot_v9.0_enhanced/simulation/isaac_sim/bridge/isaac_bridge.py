#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — Isaac Sim Bridge
=====================================
NVIDIA Isaac Sim 연동 브리지

기능:
- URDF/USD 로봇 모델 로드
- 물리 시뮬레이션 (1000Hz)
- 칼라/깊이 칩라 치어
- LiDAR 시뮬레이션
- 조인트 제어 인터페이스
- 시나리오 관리

요구사항: Isaac Sim 4.0+, omni.isaac.core
"""

from __future__ import annotations

import json
import logging
import math
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("jihun_v90.isaac_bridge")

# Isaac Sim 가용성 확인
try:
    import omni.isaac.core as isaac_core
    from omni.isaac.core import World
    from omni.isaac.core.robots import Robot
    from omni.isaac.core.utils.stage import add_reference_to_stage
    from omni.isaac.sensor import Camera, LidarRtx
    ISAC_AVAILABLE = True
except ImportError:
    ISAC_AVAILABLE = False
    logger.warning("Isaac Sim not available. Running in mock mode.")


@dataclass
class SimConfig:
    """시뮬레이션 설정."""
    physics_dt: float = 1.0 / 1000.0  # 1000Hz
    rendering_dt: float = 1.0 / 60.0  # 60Hz
    gravity: Tuple[float, float, float] = (0.0, 0.0, -9.81)
    robot_usd_path: str = ""
    environment_usd: str = ""
    headless: bool = False


class IsaacSimBridge:
    """
    Isaac Sim 연동 브리지.
    
    Isaac Sim이 설치되어 있으면 실제 시뮬레이션,
    없으면 mock 모드로 동작 (데모용).
    """
    
    def __init__(self, config: Optional[SimConfig] = None):
        self.config = config or SimConfig()
        self.world: Optional[Any] = None
        self.robot: Optional[Any] = None
        self.cameras: Dict[str, Any] = {}
        self.lidar: Optional[Any] = None
        self._running = False
        self._step_count = 0
        self._mock_mode = not ISAC_AVAILABLE
        
        # Mock 상태
        self._mock_state = {
            "position": np.zeros(3),
            "velocity": np.zeros(3),
            "joint_positions": np.zeros(11),  # 8 BLDC + 3 servo
            "joint_velocities": np.zeros(11),
        }
    
    def initialize(self) -> bool:
        """Isaac Sim 월드 초기화."""
        if self._mock_mode:
            logger.info("Isaac Sim Bridge: MOCK MODE")
            self._running = True
            return True
        
        try:
            # Isaac Sim 월드 생성
            self.world = World(
                physics_dt=self.config.physics_dt,
                rendering_dt=self.config.rendering_dt,
                stage_units_in_meters=1.0
            )
            self.world.scene.add_default_ground_plane()
            
            # 로봇 로드
            self._load_robot()
            
            # 센서 설정
            self._setup_cameras()
            self._setup_lidar()
            
            # 시뮬레이션 시작
            self.world.reset()
            self._running = True
            
            logger.info("Isaac Sim Bridge initialized")
            return True
            
        except Exception as e:
            logger.error(f"Isaac Sim init failed: {e}")
            logger.info("Falling back to mock mode")
            self._mock_mode = True
            self._running = True
            return True
    
    def _load_robot(self) -> None:
        """로봇 USD 로드."""
        if not self.config.robot_usd_path or not os.path.exists(self.config.robot_usd_path):
            # 기본 박스 로봇 생성
            logger.info("Creating default robot prototype")
            return
        
        add_reference_to_stage(
            usd_path=self.config.robot_usd_path,
            prim_path="/World/jihun_robot"
        )
        
        self.robot = Robot(
            prim_path="/World/jihun_robot",
            name="jihun_robot",
            position=np.array([0.0, 0.0, 0.3])
        )
        self.world.scene.add(self.robot)
    
    def _setup_cameras(self) -> None:
        """칩라 설정."""
        if self._mock_mode:
            return
        
        # RGB 칩라
        self.cameras["rgb"] = Camera(
            prim_path="/World/jihun_robot/camera_rgb",
            frequency=30,
            resolution=(640, 480),
            position=np.array([0.1, 0.0, 0.15])
        )
        
        # 깊이 칩라
        self.cameras["depth"] = Camera(
            prim_path="/World/jihun_robot/camera_depth",
            frequency=30,
            resolution=(640, 480),
            position=np.array([0.1, 0.0, 0.15])
        )
    
    def _setup_lidar(self) -> None:
        """LiDAR 설정."""
        if self._mock_mode:
            return
        
        try:
            self.lidar = LidarRtx(
                prim_path="/World/jihun_robot/lidar",
                position=np.array([0.0, 0.0, 0.2]),
                resolution=(1, 360),
            )
        except Exception as e:
            logger.warning(f"LiDAR setup failed: {e}")
    
    def step(self) -> Dict[str, Any]:
        """
        한 스텝 시뮬레이션 진행.
        
        Returns:
            관찰 데이터 (칩라, LiDAR, 조인트 상태 등)
        """
        if not self._running:
            return {}
        
        self._step_count += 1
        
        if self._mock_mode:
            return self._mock_step()
        
        # Isaac Sim 스텝
        self.world.step(render=not self.config.headless)
        
        # 관찰 데이터 수집
        observations = {
            "timestamp": time.time(),
            "step": self._step_count,
        }
        
        # 로봇 상태
        if self.robot:
            observations["position"] = self.robot.get_world_pose()[0]
            observations["orientation"] = self.robot.get_world_pose()[1]
            observations["joint_positions"] = self.robot.get_joint_positions()
            observations["joint_velocities"] = self.robot.get_joint_velocities()
        
        # 칩라 데이터
        for name, camera in self.cameras.items():
            try:
                observations[f"camera_{name}"] = camera.get_rgba()
            except:
                pass
        
        return observations
    
    def _mock_step(self) -> Dict[str, Any]:
        """Mock 시뮬레이션 — Isaac Sim 없이도 작동."""
        dt = self.config.physics_dt
        
        # 간단한 물리
        if self._mock_state["position"][2] > 0:
            self._mock_state["velocity"][2] -= 9.81 * dt
        else:
            self._mock_state["position"][2] = 0
            self._mock_state["velocity"][2] = max(0, self._mock_state["velocity"][2])
        
        self._mock_state["position"] += self._mock_state["velocity"] * dt
        
        return {
            "timestamp": time.time(),
            "step": self._step_count,
            "position": self._mock_state["position"].copy(),
            "velocity": self._mock_state["velocity"].copy(),
            "joint_positions": self._mock_state["joint_positions"].copy(),
            "camera_rgb": np.zeros((480, 640, 4), dtype=np.uint8),
            "camera_depth": np.zeros((480, 640), dtype=np.float32),
            "mock": True,
        }
    
    def set_joint_positions(self, positions: np.ndarray) -> None:
        """조인트 위치 설정."""
        if self._mock_mode:
            self._mock_state["joint_positions"] = positions.copy()
            return
        
        if self.robot:
            self.robot.set_joint_positions(positions)
    
    def apply_force(self, body_name: str, force: np.ndarray) -> None:
        """특정 바디에 힘 적용."""
        if not self._mock_mode and self.robot:
            # Isaac Sim API
            pass
    
    def spawn_object(self, name: str, position: np.ndarray, 
                     usd_path: Optional[str] = None) -> bool:
        """환경에 오브젝트 생성 (예: 컵, 상자)."""
        if self._mock_mode:
            logger.info(f"[Mock] Spawned {name} at {position}")
            return True
        
        try:
            add_reference_to_stage(
                usd_path=usd_path or "/Isaac/Props/Blocks/basic_block.usd",
                prim_path=f"/World/objects/{name}"
            )
            return True
        except Exception as e:
            logger.error(f"Spawn failed: {e}")
            return False
    
    def load_scenario(self, scenario_name: str) -> bool:
        """
        미리 정의된 시나리오 로드.
        
        시나리오:
        - apartment: 아파트 실내 환경
        - office: 사무실 환경
        - empty: 빈 환경
        - demo_cup: 컵 잡기 데모
        - demo_nav: 납비게이션 데모
        """
        scenarios = {
            "empty": self._scenario_empty,
            "demo_cup": self._scenario_cup_grasp,
            "demo_nav": self._scenario_navigation,
        }
        
        scenario_fn = scenarios.get(scenario_name)
        if scenario_fn:
            scenario_fn()
            logger.info(f"Scenario loaded: {scenario_name}")
            return True
        else:
            logger.warning(f"Unknown scenario: {scenario_name}")
            return False
    
    def _scenario_empty(self) -> None:
        """빈 환경."""
        pass
    
    def _scenario_cup_grasp(self) -> None:
        """컵 잡기 데모 시나리오."""
        self.spawn_object("cup", np.array([0.5, 0.0, 0.05]))
        self.spawn_object("table", np.array([0.5, 0.0, 0.0]))
        logger.info("Cup grasp scenario ready — 'cup' at (0.5, 0, 0.05)")
    
    def _scenario_navigation(self) -> None:
        """납비게이션 데모 시나리오."""
        # 장애물 배치
        for i, pos in enumerate([(1, 0), (2, 0.5), (3, -0.3)]):
            self.spawn_object(f"obstacle_{i}", np.array([pos[0], pos[1], 0.1]))
        logger.info("Navigation scenario ready — 3 obstacles placed")
    
    def run_demo(self, scenario: str, duration_s: float = 30.0) -> None:
        """
        데모 실행 — 원클릭.
        
        Args:
            scenario: 시나리오 이름
            duration_s: 실행 시간 (초)
        """
        self.load_scenario(scenario)
        
        logger.info(f"Running demo '{scenario}' for {duration_s}s...")
        start = time.time()
        
        while time.time() - start < duration_s:
            obs = self.step()
            
            # 1Hz 로그
            if self._step_count % 1000 == 0:
                pos = obs.get("position", [0, 0, 0])
                logger.info(f"Step {self._step_count} | Pos: [{pos[0]:.2f}, {pos[1]:.2f}, {pos[2]:.2f}]")
        
        logger.info("Demo complete")
    
    def shutdown(self) -> None:
        """종료."""
        self._running = False
        if not self._mock_mode and self.world:
            # Isaac Sim 정리
            pass
        logger.info("Isaac Sim Bridge shutdown")


# ====== 편의 함수 ======

def run_scenario(scenario_name: str, duration: float = 30.0) -> None:
    """시나리오 실행 편의 함수."""
    logging.basicConfig(level=logging.INFO)
    
    bridge = IsaacSimBridge()
    if bridge.initialize():
        bridge.run_demo(scenario_name, duration)
        bridge.shutdown()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", default="demo_cup", 
                       choices=["empty", "demo_cup", "demo_nav"])
    parser.add_argument("--duration", type=float, default=30.0)
    args = parser.parse_args()
    
    run_scenario(args.scenario, args.duration)
