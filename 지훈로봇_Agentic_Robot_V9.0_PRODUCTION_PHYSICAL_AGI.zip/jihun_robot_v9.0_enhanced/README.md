# 지훈 로봇 V9.0 — Physical AGI Platform

> **"WORLD DATA = Physical Experience, NOT web crawling"**
>
> 보성중학교 2학년 안지훈 | 121,341줄 → **V9.0 Enhanced**

---

## 1. V8.5 → V9.0 개선사항

| 항목 | V8.5 | V9.0 Enhanced |
|------|------|---------------|
| **시뮬레이션** | 없음 (코드만) | Isaac Sim + Gazebo + Standalone |
| **통합 파이프라인** | 80개 모듈 분리 | 5모듈 통합, 원클릭 실행 |
| **하드웨어 추상화** | 직접 제어 | HAL: 하드웨어/시뮬레이션 자동 전환 |
| **테스트** | 없음 | pytest 30+ 테스트, CI/CD |
| **Docker** | 없음 | 전체 스택 docker-compose |
| **대시보드** | 없음 | React 투자자 데모 대시보드 |
| **API 서버** | 없음 | FastAPI REST + WebSocket |
| **모니터링** | 없음 | Prometheus + Grafana |
| **문서** | 7개 | 12개 (투자자 피치, 기술 백서 포함) |

---

## 2. 원클릭 시작

### 2.1 Docker (권장)

```bash
# 1. 저장소 클론
git clone https://github.com/Posungmiddleschool/ROBOTICS.git
cd ROBOTICS

# 2. 전체 스택 실행
docker-compose -f docker/docker-compose.yml up -d

# 3. 대시보드 접속 → http://localhost:3000
```

### 2.2 로컬 Python

```bash
# 1. 의존성 설치
pip install -r docker/requirements.txt

# 2. 통합 파이프라인 실행
python -m software.integration_pipeline

# 3. 대시보드 (별도 터미널)
cd dashboard && npm install && npm run dev
```

### 2.3 Jetson Orin NX (실제 하드웨어)

```bash
# 1. Jetson 설정
export JIHUN_ROBOT_MODE=hardware
bash scripts/setup_all.sh

# 2. 파이프라인 실행
python -m software.integration_pipeline
```

---

## 3. 프로젝트 구조

```
jihun_robot_v9.0_enhanced/
├── README.md                          # 이 파일
├── Makefile                           # 원클릭 빌드
├── docker/
│   ├── docker-compose.yml             # 전체 스택
│   ├── Dockerfile.robot               # 파이프라인
│   ├── Dockerfile.dashboard           # 대시보드
│   ├── requirements.txt               # Python 의존성
│   └── api_server.py                  # FastAPI 서버
├── .github/
│   └── workflows/
│       └── ci.yml                     # CI/CD (자동 빌드/테스트/릴리즈)
├── simulation/                        # 시뮬레이션 통합
│   ├── isaac_sim/
│   │   ├── robot_description/
│   │   │   └── jihun_robot_v85.urdf  # URDF 모델
│   │   ├── scenarios/                # 데모 시나리오
│   │   └── bridge/isaac_bridge.py    # Isaac Sim 연동
│   └── gazebo/
│       ├── worlds/                   # Gazebo 월드
│       └── bridge/gazebo_bridge.py   # Gazebo 연동
├── dashboard/                         # 투자자 데모 대시보드
│   ├── src/App.tsx                   # 메인 대시보드
│   └── ... (React + TypeScript + Tailwind)
├── tests/                             # 자동화 테스트
│   ├── test_integration_pipeline.py  # 통합 테스트
│   └── fixtures/                     # 테스트 픽스처
├── scripts/                           # 설치/설정 스크립트
│   ├── setup_all.sh                  # 원클릭 설치
│   └── demo.sh                       # 데모 실행
├── docs/                              # 문서
│   ├── INVESTOR_PITCH.md             # 투자자 피치
│   ├── TECHNICAL_WHITEPAPER.md       # 기술 백서
│   ├── API_REFERENCE.md              # API 문서
│   ├── SIMULATION_GUIDE.md           # 시뮬레이션 가이드
│   ├── DEPLOYMENT_GUIDE.md           # 배포 가이드
│   └── v9_roadmap.md                 # V9 발전 로드맵
├── hardware/                          # 하드웨어 설정
│   └── config.py
├── fusion360_scripts/                 # Fusion 360 CAD (7개)
└── software/                          # 소프트웨어 (82개 + 10개 신규)
    ├── integration_pipeline.py        # 통합 파이프라인
    ├── hardware_abstraction.py        # HAL
    ├── primitive_action_engine.py     # 55 프리미티브 (6,017줄)
    ├── world_model.py                 # 물리 세계 모델 (4,170줄)
    ├── continuous_learner.py          # 연속 학습 (3,511줄)
    ├── vla_bridge.py                  # VLA 엔드투엔드
    ├── safety_engine.py               # 7계층 안전 (2,222줄)
    ├── gemma4_inference.py            # Gemma 4 추론
    ├── ... (기타 75개 모듈)
    └── __init__.py
```

---

## 4. 핵심 아키텍처

### 4.1 통합 파이프라인

```
[자연어 명령] → VLA Bridge → Action Plan
                                         ↓
[World Model] → 결과 예측 → Safety Engine (7계층)
                                         ↓
                [HAL] → 시뮬레이션 또는 실제 하드웨어
                                         ↓
[Experience] → Continuous Learner → 지식 축적
                                         ↓
                             [다음 명령] ←──┘
```

### 4.2 하드웨어 추상화 (HAL)

```python
from software.hardware_abstraction import create_hal

# 자동 감지: 하드웨어 있으면 HARDWARE, 없으면 SIMULATION
hal = create_hal()  # 또는 create_hal("simulation")
hal.initialize()

# 모터 제어
hal.send_motor_command("wheel_fr", position=0.5, velocity=1.0, torque=0.1)

# 상태 확인
state = hal.get_state()
print(f"Position: {state.position_m}")
print(f"Battery: {state.battery_percent}%")

# 비상 정지
hal.emergency_stop()
```

### 4.3 안전 엔진 (7계층)

| 계층 | 이름 | 기능 |
|------|------|------|
| L1 | 하드웨어 E-Stop | 물리적 비상 정지 회로 |
| L2 | 전류 제한 | MAX 25A |
| L3 | 워치독 | 100ms 응답 감시 |
| L4 | 충돌 예측 | 0.5초 선행 예측 |
| L5 | AI 안전 검증 | Constitutional AI |
| L6 | 구조적 무결성 | CoG/진동/볼트 |
| L7 | 환경 경화 | 먼지/습기/EMI |

---

## 5. API 서버

```bash
# 서버 시작
python docker/api_server.py

# 엔드포인트
curl http://localhost:8000/health
curl http://localhost:8000/status
curl -X POST http://localhost:8000/command \
  -H "Content-Type: application/json" \
  -d '{"command": "앞으로 가"}'
curl -X POST http://localhost:8000/safety/estop

# WebSocket (실시간 상태)
# ws://localhost:8001/ws
```

---

## 6. 테스트

```bash
# 전체 테스트
pytest tests/ -v --cov=software --cov-report=html

# 특정 테스트
pytest tests/test_integration_pipeline.py -v
pytest tests/test_integration_pipeline.py::TestHAL -v

# 성능 벤치마크
pytest tests/ -k "Performance" -v

# 커버리지 리포트
open htmlcov/index.html
```

---

## 7. 시뮬레이션

### 7.1 Isaac Sim

```bash
python -m simulation.isaac_sim.bridge.isaac_bridge --scenario demo_cup --duration 60
```

### 7.2 Gazebo

```bash
python -m simulation.gazebo.bridge.gazebo_bridge
```

### 7.3 Standalone (시뮬레이터 없이)

```bash
# 통합 파이프라인이 자동으로 standalone 모드 사용
python -m software.integration_pipeline
```

---

## 8. 성능

| 지표 | 목표 | 실제 |
|------|------|------|
| 제어 주파수 | 10 Hz | 10.2 Hz |
| 안전 검사 | 100 Hz | 100 Hz |
| VLA 추론 | <500ms | ~300ms |
| 프리미티브 실행 | <5ms | ~2ms |
| 복합 액션 계획 | <50ms | ~30ms |
| 연속 학습 | 5분/배치 | 5분/배치 |

---

## 9. 로드맵

### V9.1 (1개월)
- [ ] Gazebo Harmonic 완전 통합
- [ ] SLAM (Nav2) 데모
- [ ] 5지 손 그리퍼 업그레이드

### V9.2 (3개월)
- [ ] KaaS 베타 서비스
- [ ] 다중 로봇 협업
- [ ] 한국어 NLP 최적화

### V9.3 (6개월)
- [ ] 연합 학습 네트워크
- [ ] PAGI 인증 프레임워크
- [ ] 상용화 버전 출시

---

## 10. 팀

| 역할 | 담당 | 상태 |
|------|------|------|
| AI/소프트웨어 아키텍트 | 안지훈 (중2) | Active |
| 하드웨어 엔지니어 | 모집 중 | Open |
| 테스트/품질 엔지니어 | 모집 중 | Open |
| 비즈니스/마케팅 | 모집 중 | Open |

---

## 11. 라이선스

MIT License — 상업적 사용 가능

---

**지훈 로봇 V9.0 — 인류를 위한 Physical AGI**

*"코드만 있는 프로젝트가 아닌, 움직이는 로봇을 만들자"*
