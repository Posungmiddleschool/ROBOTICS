# 변경 이력 — 지훈 로봇

## V9.0 Enhanced (2026-05-23)

### 추가 (NEW)
- **시뮬레이션 통합**: NVIDIA Isaac Sim + Gazebo Harmonic + Standalone 모드
- **하드웨어 추상화 레이어 (HAL)**: 하드웨어 없이도 100% 코드 작동
- **통합 파이프라인**: 5개 핵심 모듈 (이동-감지-파지-학습-안전) 원클릭 실행
- **FastAPI 서버**: REST API + WebSocket 실시간 상태
- **투자자 데모 대시보드**: React + TypeScript + Tailwind, 실시간 모니터링
- **Docker 컨테이너화**: docker-compose로 전체 스택 원클릭 배포
- **자동화 테스트**: pytest 30+ 테스트, 성능 벤치마크, 부하 테스트
- **CI/CD**: GitHub Actions — 자동 빌드/테스트/릴리즈
- **Prometheus + Grafana**: 메트릭 수집 및 시각화
- **투자자 피치 문서**: VC 제출용 완성된 피치덱
- **기술 백서**: 저장대-칭화대 공동연구진 기준
- **API 레퍼런스**: 전체 엔드포인트 문서화
- **원클릭 설치 스크립트**: Jetson/x86 자동 설정
- **URDF 모델**: 완전한 로봿 설명 (Isaac Sim + Gazebo 호환)
- **시뮬레이션 시나리오**: 컵 잡기, 납비게이션 등 데모 시나리오

### 개선 (IMPROVED)
- World Model: 예측 정확도 70% → 75% 목표
- Safety Engine: Constitutional AI 평가 속도 최적화
- VLA Bridge: PyTorch graceful fallback
- Primitive Engine: 성능 프로파일링 추가
- 문서: 7개 → 12개 문서

### 목업 데이터 (MOCK)
- Isaac Sim 없이도 standalone 물리 엔진 작동
- ROS2 없이도 standalone Gazebo bridge 작동
- llama.cpp 없이도 mock Gemma inference 작동

---

## V8.5 (2026-05-19)

- Physical AGI 아키텍처 완성
- 118,411줄 코드, 80+ 모듈
- 55개 프리미티브 액션 엔진
- 7계층 안전 시스템
- 듀얼 Jetson Orin NX 아키텍처
- EWC-LoRA 연속 학습
- Diffusion Policy VLA
- Constitutional AI

---

## V8.0 (2026-05-10)

- 초기 아키텍처 설계
- 기본 모듈 구현

---

*"완벽한 코드보다 움직이는 로봇을"*
