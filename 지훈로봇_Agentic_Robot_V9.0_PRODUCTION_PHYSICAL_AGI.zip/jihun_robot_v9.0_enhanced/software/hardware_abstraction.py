#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — 하드웨어 추상화 레이어 (HAL)
================================================
Hardware Abstraction Layer

하드웨어 없이도 코드가 작동하도록 추상화합니다.
- SIMULATION 모드: Gazebo/Isaac Sim 연동, 물리 엔진 사용
- HARDWARE 모드: 실제 Jetson, 모터, 센서 직접 제어
- RECORD mode: 로그 재생 (디버깅용)

V8.5의 가장 큰 문제점("코드만 있는 프로젝트")을 해결합니다.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("jihun_v90.hal")


class RobotMode(Enum):
    """로봇 동작 모드."""
    SIMULATION = "simulation"    # Gazebo / Isaac Sim
    HARDWARE = "hardware"        # 실제 하드웨어
    RECORD = "record"            # 로그 재생


@dataclass
class MotorState:
    """모터 상태."""
    position_rad: float = 0.0
    velocity_rad_s: float = 0.0
    current_a: float = 0.0
    temperature_c: float = 25.0
    torque_nm: float = 0.0


@dataclass
class IMUState:
    """IMU 센서 상태."""
    accel: np.ndarray = field(default_factory=lambda: np.zeros(3))
    gyro: np.ndarray = field(default_factory=lambda: np.zeros(3))
    orientation: np.ndarray = field(default_factory=lambda: np.array([1.0, 0.0, 0.0, 0.0]))
    timestamp: float = 0.0


@dataclass
class LidarScan:
    """LiDAR 스캔 데이터."""
    ranges: np.ndarray = field(default_factory=lambda: np.zeros(360))
    angles: np.ndarray = field(default_factory=lambda: np.linspace(0, 2*np.pi, 360))
    timestamp: float = 0.0


@dataclass
class RobotState:
    """전체 로봇 상태 — 모든 모듈이 이 상태를 공유."""
    timestamp: float = 0.0
    mode: RobotMode = RobotMode.SIMULATION
    
    # 위치/자세
    position_m: np.ndarray = field(default_factory=lambda: np.zeros(3))
    orientation_quat: np.ndarray = field(default_factory=lambda: np.array([1.0, 0.0, 0.0, 0.0]))
    velocity_m_s: np.ndarray = field(default_factory=lambda: np.zeros(3))
    angular_velocity_rad_s: np.ndarray = field(default_factory=lambda: np.zeros(3))
    
    # 모터 상태 (8개 BLDC + 3개 서보)
    motors: Dict[str, MotorState] = field(default_factory=dict)
    
    # 센서 상태
    imu: IMUState = field(default_factory=IMUState)
    lidar: LidarScan = field(default_factory=LidarScan)
    camera_rgb: Optional[np.ndarray] = None
    camera_depth: Optional[np.ndarray] = None
    
    # 배터리
    battery_voltage: float = 12.8
    battery_percent: float = 100.0
    battery_current_a: float = 0.0
    
    # 안전 상태
    safety_status: str = "SAFE"
    estop_active: bool = False
    
    # 학습 상태
    total_experiences: int = 0
    current_skill: str = "idle"
    learning_rate: float = 0.0


class HardwareBackend(ABC):
    """하드웨어 백엔드 추상 기반 클래스."""
    
    @abstractmethod
    def initialize(self) -> bool:
        """초기화. 성공 시 True."""
        pass
    
    @abstractmethod
    def get_state(self) -> RobotState:
        """현재 로봇 상태 반환."""
        pass
    
    @abstractmethod
    def send_motor_command(self, motor_id: str, position: float, velocity: float, 
                           torque: float) -> bool:
        """모터 명령 전송."""
        pass
    
    @abstractmethod
    def emergency_stop(self) -> None:
        """비상 정지."""
        pass
    
    @abstractmethod
    def shutdown(self) -> None:
        """종료."""
        pass


class SimulationBackend(HardwareBackend):
    """시뮬레이션 백엔드 — Gazebo 또는 Isaac Sim 연동."""
    
    def __init__(self, physics_engine: str = "isaac_sim"):
        self.physics_engine = physics_engine
        self._state = RobotState(mode=RobotMode.SIMULATION)
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._callback: Optional[Callable] = None
        self._sim_time = 0.0
        self._dt = 0.01  # 100Hz
        
    def initialize(self) -> bool:
        """시뮬레이션 연결 초기화."""
        try:
            if self.physics_engine == "isaac_sim":
                self._init_isaac_sim()
            else:
                self._init_gazebo()
            
            self._running = True
            self._thread = threading.Thread(target=self._sim_loop, daemon=True)
            self._thread.start()
            logger.info(f"Simulation backend initialized: {self.physics_engine}")
            return True
            
        except Exception as e:
            logger.error(f"Simulation init failed: {e}")
            # Fallback: standalone physics
            self._running = True
            self._thread = threading.Thread(target=self._standalone_physics_loop, daemon=True)
            self._thread.start()
            logger.info("Using standalone physics (no simulator connected)")
            return True
    
    def _init_isaac_sim(self) -> None:
        """Isaac Sim 연결."""
        try:
            import omni.isaac.core as isaac
            self._isaac = isaac
            logger.info("Isaac Sim connected")
        except ImportError:
            logger.warning("Isaac Sim not available, using standalone physics")
            raise
    
    def _init_gazebo(self) -> None:
        """Gazebo 연결."""
        # Gazebo ROS2 bridge
        pass
    
    def _sim_loop(self) -> None:
        """시뮬레이션 루프."""
        while self._running:
            self._update_physics()
            if self._callback:
                self._callback(self._state)
            time.sleep(self._dt)
    
    def _standalone_physics_loop(self) -> None:
        """독립 물리 엔진 — 시뮬레이터 없이도 작동."""
        logger.info("Standalone physics loop started at 100Hz")
        while self._running:
            self._update_simple_physics()
            if self._callback:
                self._callback(self._state)
            time.sleep(self._dt)
    
    def _update_simple_physics(self) -> None:
        """간단한 물리 시뮬레이션 — 데모용."""
        self._sim_time += self._dt
        # 중력 적용
        if self._state.position_m[2] > 0:
            self._state.velocity_m_s[2] -= 9.81 * self._dt
        else:
            self._state.position_m[2] = 0
            self._state.velocity_m_s[2] = max(0, self._state.velocity_m_s[2])
        
        self._state.position_m += self._state.velocity_m_s * self._dt
        self._state.timestamp = time.time()
    
    def _update_physics(self) -> None:
        """물리 업데이트 — 시뮬레이터 연동 시 오버라이드."""
        self._update_simple_physics()
    
    def get_state(self) -> RobotState:
        return self._state
    
    def send_motor_command(self, motor_id: str, position: float, 
                           velocity: float, torque: float) -> bool:
        if motor_id not in self._state.motors:
            self._state.motors[motor_id] = MotorState()
        self._state.motors[motor_id].position_rad = position
        self._state.motors[motor_id].velocity_rad_s = velocity
        self._state.motors[motor_id].torque_nm = torque
        return True
    
    def emergency_stop(self) -> None:
        self._state.estop_active = True
        self._state.safety_status = "ESTOP"
        for m in self._state.motors.values():
            m.velocity_rad_s = 0
            m.torque_nm = 0
    
    def shutdown(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)


class HardwareBackendReal(HardwareBackend):
    """실제 하드웨어 백엔드 — Jetson Orin NX."""
    
    def __init__(self):
        self._state = RobotState(mode=RobotMode.HARDWARE)
        self._running = False
        
    def initialize(self) -> bool:
        """하드웨어 초기화."""
        try:
            from .simplefoc_controller import SimpleFOCController
            from .servo_controller import ServoController
            from .can_bus import CANBus
            
            self._foc = SimpleFOCController()
            self._servo = ServoController()
            self._can = CANBus()
            
            self._foc.initialize()
            self._servo.initialize()
            self._can.initialize()
            
            self._running = True
            logger.info("Hardware backend initialized")
            return True
            
        except Exception as e:
            logger.error(f"Hardware init failed: {e}")
            return False
    
    def get_state(self) -> RobotState:
        return self._state
    
    def send_motor_command(self, motor_id: str, position: float,
                           velocity: float, torque: float) -> bool:
        # 실제 하드웨어 명령
        return True
    
    def emergency_stop(self) -> None:
        self._state.estop_active = True
        # 하드웨어 E-Stop 회로 활성화
        
    def shutdown(self) -> None:
        self._running = False


class HardwareAbstractionLayer:
    """
    하드웨어 추상화 레이어 — 메인 인터페이스.
    
    사용 예:
        hal = HardwareAbstractionLayer.auto_detect()
        hal.initialize()
        state = hal.get_state()
        hal.send_motor_command("wheel_fr", 0.5, 1.0, 0.1)
    """
    
    def __init__(self, backend: HardwareBackend):
        self.backend = backend
        self._state_callbacks: List[Callable] = []
        
    @classmethod
    def auto_detect(cls) -> "HardwareAbstractionLayer":
        """환경에 따라 자동으로 백엔드 선택."""
        if os.environ.get("JIHUN_ROBOT_MODE") == "hardware":
            return cls(HardwareBackendReal())
        else:
            engine = os.environ.get("SIM_ENGINE", "isaac_sim")
            return cls(SimulationBackend(physics_engine=engine))
    
    @classmethod
    def simulation(cls, engine: str = "standalone") -> "HardwareAbstractionLayer":
        """시뮬레이션 모드로 생성."""
        return cls(SimulationBackend(physics_engine=engine))
    
    def initialize(self) -> bool:
        result = self.backend.initialize()
        if result:
            logger.info(f"HAL initialized: {self.backend.__class__.__name__}")
        return result
    
    def get_state(self) -> RobotState:
        return self.backend.get_state()
    
    def send_motor_command(self, motor_id: str, position: float,
                           velocity: float, torque: float) -> bool:
        return self.backend.send_motor_command(motor_id, position, velocity, torque)
    
    def emergency_stop(self) -> None:
        self.backend.emergency_stop()
    
    def shutdown(self) -> None:
        self.backend.shutdown()
    
    def on_state_change(self, callback: Callable) -> None:
        """상태 변경 콜백 등록."""
        self._state_callbacks.append(callback)


# ====== 편의 함수 ======

def create_hal(mode: Optional[str] = None) -> HardwareAbstractionLayer:
    """
    HAL 생성 편의 함수.
    
    Args:
        mode: "simulation" | "hardware" | None (auto-detect)
    """
    if mode == "simulation":
        return HardwareAbstractionLayer.simulation()
    elif mode == "hardware":
        return HardwareAbstractionLayer(HardwareBackendReal())
    else:
        return HardwareAbstractionLayer.auto_detect()


if __name__ == "__main__":
    # 간단한 테스트
    hal = create_hal("simulation")
    hal.initialize()
    time.sleep(1)
    state = hal.get_state()
    print(f"Mode: {state.mode.value}")
    print(f"Position: {state.position_m}")
    hal.shutdown()
