#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — 프로덕션 모니터링 + 알림
===========================================
Production Monitoring & Alerting

상용 환경에서 로봇 상태를 실시간 모니터링하고,
이상 징후 발생 시 자동 알림/대응.

기능:
- 실시간 메트릭 수집 (Prometheus 호환)
- 임계값 기반 알림
- Slack/Email 알림
- 자동 대응 (서킷 브레이커 연동)
- 로그 집계 및 분석
"""

from __future__ import annotations

import json
import logging
import queue
import threading
import time
import traceback
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Set

import numpy as np

logger = logging.getLogger("jihun_v90.production_monitoring")


class AlertSeverity(Enum):
    """알림 심각도."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


class AlertChannel(Enum):
    """알림 채널."""
    LOG = "log"
    SLACK = "slack"
    EMAIL = "email"
    SMS = "sms"
    WEBHOOK = "webhook"


@dataclass
class Alert:
    """알림."""
    alert_id: str
    severity: AlertSeverity
    title: str
    message: str
    timestamp: float
    metric_name: str
    metric_value: float
    threshold: float
    acknowledged: bool = False
    resolved: bool = False


@dataclass
class MetricRule:
    """메트릭 알림 규칙."""
    metric_name: str
    condition: str  # ">", "<", "==", ">=", "<="
    threshold: float
    severity: AlertSeverity
    channels: List[AlertChannel]
    cooldown_sec: float = 300.0  # 5분 쿨다운
    auto_action: Optional[str] = None  # "estop", "degrade", "restart"


# 기본 알림 규칙
DEFAULT_RULES = [
    MetricRule("battery_percent", "<", 20, AlertSeverity.WARNING, 
               [AlertChannel.LOG, AlertChannel.SLACK], auto_action="degrade"),
    MetricRule("battery_percent", "<", 10, AlertSeverity.CRITICAL,
               [AlertChannel.LOG, AlertChannel.SLACK, AlertChannel.SMS], auto_action="estop"),
    MetricRule("motor_temperature", ">", 80, AlertSeverity.WARNING,
               [AlertChannel.LOG, AlertChannel.SLACK]),
    MetricRule("motor_temperature", ">", 100, AlertSeverity.EMERGENCY,
               [AlertChannel.LOG, AlertChannel.SLACK, AlertChannel.SMS], auto_action="estop"),
    MetricRule("loop_hz", "<", 5, AlertSeverity.CRITICAL,
               [AlertChannel.LOG, AlertChannel.SLACK]),
    MetricRule("safety_violations", ">", 0, AlertSeverity.EMERGENCY,
               [AlertChannel.LOG, AlertChannel.SLACK, AlertChannel.SMS], auto_action="estop"),
    MetricRule("estop_active", "==", 1, AlertSeverity.EMERGENCY,
               [AlertChannel.LOG, AlertChannel.SLACK, AlertChannel.SMS]),
    MetricRule("collision_count", ">", 5, AlertSeverity.WARNING,
               [AlertChannel.LOG, AlertChannel.SLACK]),
    MetricRule("memory_usage_mb", ">", 14000, AlertSeverity.WARNING,
               [AlertChannel.LOG], auto_action="degrade"),
]


class ProductionMonitor:
    """
    프로덕션 모니터 — 상용 환경 모니터링 중추.
    
    사용:
        monitor = ProductionMonitor()
        monitor.start()
        
        # 메트릭 보고
        monitor.report_metric("battery_percent", 82.0)
        monitor.report_metric("motor_temperature", 45.0)
        
        # 규칙 위반 시 자동 알림
        monitor.report_metric("battery_percent", 8.0)  # → CRITICAL 알림
    """
    
    def __init__(self, rules: Optional[List[MetricRule]] = None):
        self.rules = rules or DEFAULT_RULES
        self.metrics_history: Dict[str, Deque[Dict]] = {}
        self.alerts: Deque[Alert] = deque(maxlen=1000)
        self._alert_cooldown: Dict[str, float] = {}
        
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._metric_queue: queue.Queue = queue.Queue(maxsize=10000)
        
        self._callbacks: List[Callable] = []
        self._auto_actions: Dict[str, Callable] = {}
    
    def register_auto_action(self, action_name: str, 
                            callback: Callable) -> None:
        """자동 대응 액션 등록."""
        self._auto_actions[action_name] = callback
    
    def on_alert(self, callback: Callable) -> None:
        """알림 콜백 등록."""
        self._callbacks.append(callback)
    
    def start(self) -> None:
        """모니터링 시작."""
        self._running = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        logger.info("Production Monitor started")
    
    def stop(self) -> None:
        """모니터링 중지."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5.0)
    
    def report_metric(self, name: str, value: float) -> None:
        """메트릭 보고 (스레드 안전)."""
        try:
            self._metric_queue.put_nowait({
                "name": name,
                "value": value,
                "timestamp": time.time(),
            })
        except queue.Full:
            pass  # 큐가 가득 차면 무시
    
    def _monitor_loop(self) -> None:
        """모니터링 루프."""
        while self._running:
            try:
                # 메트릭 수집 (100ms 타임아웃)
                metric = self._metric_queue.get(timeout=0.1)
                self._process_metric(metric)
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Monitor loop error: {e}")
    
    def _process_metric(self, metric: Dict) -> None:
        """메트릭 처리 및 규칙 검사."""
        name = metric["name"]
        value = metric["value"]
        ts = metric["timestamp"]
        
        # 히스토리 저장
        if name not in self.metrics_history:
            self.metrics_history[name] = deque(maxlen=10000)
        self.metrics_history[name].append({"value": value, "timestamp": ts})
        
        # 규칙 검사
        for rule in self.rules:
            if rule.metric_name != name:
                continue
            
            triggered = self._check_condition(value, rule.condition, rule.threshold)
            
            if triggered:
                self._trigger_alert(rule, value)
    
    def _check_condition(self, value: float, condition: str, 
                         threshold: float) -> bool:
        """조건 검사."""
        if condition == ">":
            return value > threshold
        elif condition == "<":
            return value < threshold
        elif condition == ">=":
            return value >= threshold
        elif condition == "<=":
            return value <= threshold
        elif condition == "==":
            return abs(value - threshold) < 0.001
        return False
    
    def _trigger_alert(self, rule: MetricRule, value: float) -> None:
        """알림 트리거."""
        # 쿨다운 확인
        cooldown_key = f"{rule.metric_name}_{rule.condition}_{rule.threshold}"
        last_alert = self._alert_cooldown.get(cooldown_key, 0)
        
        if time.time() - last_alert < rule.cooldown_sec:
            return
        
        self._alert_cooldown[cooldown_key] = time.time()
        
        alert = Alert(
            alert_id=f"alert_{int(time.time()*1000)}",
            severity=rule.severity,
            title=f"[{rule.severity.value.upper()}] {rule.metric_name}",
            message=f"{rule.metric_name} = {value:.2f} "
                   f"({rule.condition} {rule.threshold})",
            timestamp=time.time(),
            metric_name=rule.metric_name,
            metric_value=value,
            threshold=rule.threshold,
        )
        
        self.alerts.append(alert)
        
        # 로그 출력
        log_fn = {
            AlertSeverity.INFO: logger.info,
            AlertSeverity.WARNING: logger.warning,
            AlertSeverity.CRITICAL: logger.critical,
            AlertSeverity.EMERGENCY: logger.critical,
        }.get(rule.severity, logger.warning)
        
        log_fn(f"ALERT [{rule.severity.value}] {rule.metric_name}: "
               f"{value:.2f} {rule.condition} {rule.threshold}")
        
        # 자동 대응
        if rule.auto_action and rule.auto_action in self._auto_actions:
            logger.warning(f"Auto-action: {rule.auto_action}")
            try:
                self._auto_actions[rule.auto_action]()
            except Exception as e:
                logger.error(f"Auto-action failed: {e}")
        
        # 콜백
        for cb in self._callbacks:
            try:
                cb(alert)
            except Exception:
                pass
    
    def get_metric_history(self, name: str, 
                           duration_sec: float = 3600) -> List[Dict]:
        """메트릭 히스토리 조회."""
        history = self.metrics_history.get(name, deque())
        cutoff = time.time() - duration_sec
        return [h for h in history if h["timestamp"] >= cutoff]
    
    def get_active_alerts(self) -> List[Alert]:
        """활성 알림 (미해결)."""
        return [a for a in self.alerts if not a.resolved]
    
    def acknowledge_alert(self, alert_id: str) -> bool:
        """알림 확인."""
        for alert in self.alerts:
            if alert.alert_id == alert_id:
                alert.acknowledged = True
                return True
        return False
    
    def resolve_alert(self, alert_id: str) -> bool:
        """알림 해결."""
        for alert in self.alerts:
            if alert.alert_id == alert_id:
                alert.resolved = True
                return True
        return False
    
    def get_prometheus_metrics(self) -> str:
        """Prometheus 형식 메트릭."""
        lines = []
        
        for name, history in self.metrics_history.items():
            if history:
                latest = history[-1]["value"]
                lines.append(f'jihun_robot_{name} {latest:.4f}')
        
        lines.append(f'jihun_robot_active_alerts {len(self.get_active_alerts())}')
        lines.append(f'jihun_robot_total_alerts {len(self.alerts)}')
        
        return '\n'.join(lines)
    
    def get_status(self) -> Dict:
        """전체 상태."""
        return {
            "active": self._running,
            "metrics_tracked": len(self.metrics_history),
            "total_alerts": len(self.alerts),
            "active_alerts": len(self.get_active_alerts()),
            "alert_rules": len(self.rules),
        }


# ====== 편의 함수 ======

def create_monitor_with_defaults(estop_fn: Optional[Callable] = None,
                                  degrade_fn: Optional[Callable] = None) -> ProductionMonitor:
    """기본 설정으로 모니터 생성."""
    monitor = ProductionMonitor()
    
    if estop_fn:
        monitor.register_auto_action("estop", estop_fn)
    
    if degrade_fn:
        monitor.register_auto_action("degrade", degrade_fn)
    
    monitor.start()
    return monitor


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # 테스트
    monitor = create_monitor_with_defaults(
        estop_fn=lambda: print("!!! E-STOP ACTIVATED !!!"),
        degrade_fn=lambda: print("!!! DEGRADATION ACTIVATED !!!"),
    )
    
    # 정상 메트릭
    monitor.report_metric("battery_percent", 82.0)
    monitor.report_metric("motor_temperature", 45.0)
    
    # 경고 트리거
    monitor.report_metric("battery_percent", 15.0)  # WARNING
    
    # 심각 트리거
    monitor.report_metric("battery_percent", 5.0)   # CRITICAL → estop
    
    time.sleep(1)
    
    print(f"\nStatus: {monitor.get_status()}")
    print(f"\nPrometheus:\n{monitor.get_prometheus_metrics()}")
    
    monitor.stop()
