#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — 서킷 브레이커 + Graceful Degradation
=======================================================
Circuit Breaker & Graceful Degradation

상용 환경에서 오류가 발생핼 때도 로봇이 안전하게 동작하도록 보장합니다.
- 서킷 브레이커: 연속 오류 시 자동 차단 → 복구 시 자동 재개
- Graceful Degradation: 기능 점진적 축소 (전체 정지 대신)
- Fallback Chain: LLM → 휴리스틱 → 안전 모드

Boston Dynamics, Tesla와 동일한 상용 패턴.
"""

from __future__ import annotations

import functools
import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, Generic, List, Optional, TypeVar

import numpy as np

logger = logging.getLogger("jihun_v90.circuit_breaker")

T = TypeVar('T')


class CircuitState(Enum):
    """서킷 브레이커 상태."""
    CLOSED = "closed"       # 정상 (오류 카운트 중)
    OPEN = "open"           # 차단 (모든 요청 거부)
    HALF_OPEN = "half_open" # 복구 시험 (제한적 요청 허용)


@dataclass
class DegradationLevel:
    """성능 저하 단계."""
    level: int                          # 0=정상, 1=경고, 2=제한, 3=최소, 4=안전모드
    name: str                           # "normal" | "reduced" | "minimal" | "safe"
    active_features: List[str]          # 활성 기능 목록
    disabled_features: List[str]        # 비활성 기능 목록
    max_speed: float                    # 최대 속도 제한 (m/s)
    max_force: float                    # 최대 힘 제한 (N)
    llm_enabled: bool                   # LLM 사용 여부
    vision_enabled: bool                # 비전 사용 여부
    learning_enabled: bool              # 학습 사용 여부


# 성능 저하 단계 정의
DEGRADATION_LEVELS = {
    0: DegradationLevel(
        level=0, name="normal",
        active_features=["vla", "world_model", "learning", "vision", "navigation", "grasp", "voice"],
        disabled_features=[],
        max_speed=0.5, max_force=20.0,
        llm_enabled=True, vision_enabled=True, learning_enabled=True,
    ),
    1: DegradationLevel(
        level=1, name="reduced",
        active_features=["world_model", "vision", "navigation", "grasp"],
        disabled_features=["vla", "learning", "voice"],
        max_speed=0.3, max_force=15.0,
        llm_enabled=False, vision_enabled=True, learning_enabled=False,
    ),
    2: DegradationLevel(
        level=2, name="minimal",
        active_features=["vision", "navigation"],
        disabled_features=["vla", "world_model", "learning", "grasp", "voice"],
        max_speed=0.15, max_force=10.0,
        llm_enabled=False, vision_enabled=True, learning_enabled=False,
    ),
    3: DegradationLevel(
        level=3, name="safe",
        active_features=["estop", "basic_move"],
        disabled_features=["vla", "world_model", "learning", "vision", "navigation", "grasp", "voice"],
        max_speed=0.05, max_force=5.0,
        llm_enabled=False, vision_enabled=False, learning_enabled=False,
    ),
}


class CircuitBreaker:
    """
    서킷 브레이커 — 오류 자동 차단/복구.
    
    사용:
        cb = CircuitBreaker(failure_threshold=5, recovery_timeout=30)
        
        @cb.protected
        def move_robot(speed):
            ...
        
        try:
            move_robot(0.3)
        except CircuitOpenError:
            # 서킷 오픈 — 복구 대기
            pass
    """
    
    def __init__(self, name: str = "default",
                 failure_threshold: int = 5,
                 recovery_timeout: float = 30.0,
                 half_open_max_calls: int = 3):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[float] = None
        self.half_open_calls = 0
        
        self._lock = threading.RLock()
        
        # 메트릭
        self.total_calls = 0
        self.total_failures = 0
        self.total_successes = 0
    
    @property
    def is_open(self) -> bool:
        return self.state == CircuitState.OPEN
    
    def can_execute(self) -> bool:
        """실행 가능 여부."""
        with self._lock:
            if self.state == CircuitState.CLOSED:
                return True
            
            if self.state == CircuitState.OPEN:
                # 복구 시간 지났는지 확인
                if self.last_failure_time and \
                   time.time() - self.last_failure_time >= self.recovery_timeout:
                    self.state = CircuitState.HALF_OPEN
                    self.half_open_calls = 0
                    logger.info(f"[{self.name}] Circuit HALF_OPEN — testing recovery")
                    return True
                return False
            
            if self.state == CircuitState.HALF_OPEN:
                if self.half_open_calls < self.half_open_max_calls:
                    self.half_open_calls += 1
                    return True
                return False
            
            return False
    
    def record_success(self) -> None:
        """성공 기록."""
        with self._lock:
            self.total_successes += 1
            self.total_calls += 1
            
            if self.state == CircuitState.HALF_OPEN:
                self.success_count += 1
                if self.success_count >= self.half_open_max_calls:
                    self._close()
            else:
                self.failure_count = max(0, self.failure_count - 1)
    
    def record_failure(self) -> None:
        """실패 기록."""
        with self._lock:
            self.total_failures += 1
            self.total_calls += 1
            
            if self.state == CircuitState.HALF_OPEN:
                self._open()
                return
            
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.failure_threshold:
                self._open()
    
    def _open(self) -> None:
        """서킷 오픈."""
        if self.state != CircuitState.OPEN:
            self.state = CircuitState.OPEN
            logger.warning(f"[{self.name}] Circuit OPEN — "
                          f"{self.failure_count} consecutive failures")
    
    def _close(self) -> None:
        """서킷 클로즈 (정상)."""
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.half_open_calls = 0
        logger.info(f"[{self.name}] Circuit CLOSED — recovered")
    
    def protected(self, func: Callable[..., T]) -> Callable[..., T]:
        """데코레이터: 함수를 서킷 브레이커로 보호."""
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if not self.can_execute():
                raise CircuitOpenError(f"Circuit '{self.name}' is OPEN")
            
            try:
                result = func(*args, **kwargs)
                self.record_success()
                return result
            except Exception as e:
                self.record_failure()
                raise
        
        return wrapper
    
    def get_status(self) -> Dict:
        """현재 상태 반환."""
        return {
            "name": self.name,
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "total_calls": self.total_calls,
            "total_failures": self.total_failures,
            "failure_rate": (self.total_failures / max(self.total_calls, 1)) * 100,
        }


class CircuitOpenError(Exception):
    """서킷 오픈 예외."""
    pass


class GracefulDegradation:
    """
    Graceful Degradation 매니저.
    
    시스템 리소스/오류 상태에 따라 기능을 점진적으로 축소.
    전체 정지 대신 안전한 최소 기능 유지.
    """
    
    def __init__(self):
        self.current_level = 0
        self._cb_system = CircuitBreaker("system", failure_threshold=10)
        self._cb_vla = CircuitBreaker("vla", failure_threshold=3)
        self._cb_vision = CircuitBreaker("vision", failure_threshold=5)
        self._cb_motor = CircuitBreaker("motor", failure_threshold=5)
        
        self._circuit_breakers = {
            "system": self._cb_system,
            "vla": self._cb_vla,
            "vision": self._cb_vision,
            "motor": self._cb_motor,
        }
        
        self._callbacks: List[Callable] = []
    
    @property
    def level(self) -> DegradationLevel:
        """현재 성능 저하 단계."""
        return DEGRADATION_LEVELS.get(self.current_level, DEGRADATION_LEVELS[0])
    
    def on_degradation_change(self, callback: Callable) -> None:
        """저하 단계 변경 콜백 등록."""
        self._callbacks.append(callback)
    
    def _notify_change(self) -> None:
        """변경 알림."""
        for cb in self._callbacks:
            try:
                cb(self.current_level, self.level)
            except Exception:
                pass
    
    def escalate(self, levels: int = 1) -> DegradationLevel:
        """
        성능 저하 단계 상승 (더 제한적으로).
        
        예: 정상(0) → 경고(1) → 제한(2) → 안전(3)
        """
        old = self.current_level
        self.current_level = min(self.current_level + levels, 3)
        
        if self.current_level != old:
            level = self.level
            logger.warning(f"DEGRADATION: Level {old} → {self.current_level} "
                          f"({level.name})")
            logger.warning(f"  Disabled: {level.disabled_features}")
            logger.warning(f"  Max speed: {level.max_speed} m/s")
            logger.warning(f"  Max force: {level.max_force} N")
            self._notify_change()
        
        return self.level
    
    def recover(self, levels: int = 1) -> DegradationLevel:
        """
        성능 저하 단계 하강 (더 정상으로).
        """
        old = self.current_level
        self.current_level = max(self.current_level - levels, 0)
        
        if self.current_level != old:
            level = self.level
            logger.info(f"RECOVERY: Level {old} → {self.current_level} "
                       f"({level.name})")
            logger.info(f"  Active: {level.active_features}")
            self._notify_change()
        
        return self.level
    
    def report_component_health(self, component: str, healthy: bool) -> None:
        """컴포넌트 건강 상태 보고."""
        cb = self._circuit_breakers.get(component)
        if not cb:
            return
        
        if healthy:
            cb.record_success()
            # 서킷이 복구되면 전체 시스템도 복구 시도
            if cb.state == CircuitState.CLOSED and self.current_level > 0:
                self.recover()
        else:
            cb.record_failure()
            
            # 컴포넌트별 대응
            if component == "vla" and cb.is_open:
                logger.warning("VLA failed — falling back to heuristic policy")
                self.escalate(1)  # LLM 비활성화
            
            elif component == "vision" and cb.is_open:
                logger.warning("Vision failed — LiDAR-only navigation")
                self.escalate(1)
            
            elif component == "motor" and cb.is_open:
                logger.critical("Motor control failed — EMERGENCY STOP")
                self.escalate(3)  # 안전 모드
    
    def is_feature_enabled(self, feature: str) -> bool:
        """기능 사용 가능 여부."""
        return feature in self.level.active_features
    
    def get_constraints(self) -> Dict:
        """현재 물리적 제약 조건."""
        level = self.level
        return {
            "max_speed_m_s": level.max_speed,
            "max_force_n": level.max_force,
            "llm_available": level.llm_enabled,
            "vision_available": level.vision_enabled,
            "learning_available": level.learning_enabled,
        }
    
    def get_status(self) -> Dict:
        """전체 상태."""
        return {
            "degradation_level": self.current_level,
            "degradation_name": self.level.name,
            "active_features": self.level.active_features,
            "disabled_features": self.level.disabled_features,
            "constraints": self.get_constraints(),
            "circuit_breakers": {
                name: cb.get_status()
                for name, cb in self._circuit_breakers.items()
            },
        }


class FallbackChain:
    """
    Fallback Chain — 기능별 대체 체인.
    
    VLA(LLM) → Heuristic(휴리스틱) → Safe Mode(안전)
    """
    
    def __init__(self):
        self._fallbacks: Dict[str, List[Callable]] = {}
    
    def register(self, feature: str, *handlers: Callable) -> None:
        """fallback 체인 등록 (우선순위 순)."""
        self._fallbacks[feature] = list(handlers)
    
    def execute(self, feature: str, *args, **kwargs) -> Any:
        """
        최상위 핸들러부터 순차 시도.
        
        모든 핸들러가 실패하면 예외 발생.
        """
        handlers = self._fallbacks.get(feature, [])
        
        if not handlers:
            raise RuntimeError(f"No fallback handlers for: {feature}")
        
        errors = []
        for i, handler in enumerate(handlers):
            try:
                result = handler(*args, **kwargs)
                if i > 0:
                    logger.info(f"Fallback [{i}] succeeded for {feature}")
                return result
            except Exception as e:
                errors.append(f"[{i}]: {e}")
                continue
        
        # 모두 실패
        error_msg = f"All fallbacks failed for {feature}: {'; '.join(errors)}"
        logger.critical(error_msg)
        raise RuntimeError(error_msg)


# ====== 편의 함수 ======

def create_protection() -> Tuple[GracefulDegradation, FallbackChain]:
    """상용 환경 보호 시스템 생성."""
    gd = GracefulDegradation()
    fc = FallbackChain()
    
    # VLA fallback 체인
    def vla_llm(command): return {"action": "llm_parsed", "command": command}
    def vla_heuristic(command): return {"action": "heuristic", "command": command}
    def vla_safe(command): return {"action": "stop", "reason": "safe_mode"}
    
    fc.register("vla", vla_llm, vla_heuristic, vla_safe)
    
    # Navigation fallback
    def nav_full(goal): return {"path": "a_star", "goal": goal}
    def nav_lidar(goal): return {"path": "lidar_only", "goal": goal}
    def nav_backup(goal): return {"path": "reverse", "goal": goal}
    
    fc.register("navigation", nav_full, nav_lidar, nav_backup)
    
    return gd, fc


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # 서킷 브레이커 테스트
    cb = CircuitBreaker("test", failure_threshold=3, recovery_timeout=5)
    
    @cb.protected
    def risky_operation(fail: bool = False):
        if fail:
            raise RuntimeError("Failed!")
        return "success"
    
    # 정상
    print(risky_operation(False))  # success
    
    # 3번 실패 → OPEN
    for _ in range(3):
        try:
            risky_operation(True)
        except Exception:
            pass
    
    # 차단됨
    try:
        risky_operation(False)
    except CircuitOpenError as e:
        print(f"Blocked: {e}")
    
    # Graceful Degradation 테스트
    gd, fc = create_protection()
    print(f"Level: {gd.level.name}")
    
    # VLA 실패 보고
    gd.report_component_health("vla", False)
    gd.report_component_health("vla", False)
    gd.report_component_health("vla", False)
    
    print(f"Level after VLA failure: {gd.level.name}")
    print(f"LLM available: {gd.level.llm_enabled}")
    
    # Fallback
    result = fc.execute("vla", "앞으로 가")
    print(f"Fallback result: {result}")
