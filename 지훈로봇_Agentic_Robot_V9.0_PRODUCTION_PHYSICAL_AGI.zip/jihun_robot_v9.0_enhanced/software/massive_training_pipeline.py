#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — 대규모 병렬 시뮬레이션 훈련 파이프라인
============================================================
Massive Parallel Simulation Training Pipeline

Boston Dynamics 방식:
    1. 수천 개의 가상 환경을 병렬로 실행
    2. 각 환경에서 수만 에피소드 반복 훈련
    3. 도메인 랜덤라이제이션으로 다양한 조건 학습
    4. 체크포인트 저장 → Sim-to-Real 전이

목표:
    - 10,000+ 에피소드/시간
    - 100+ 병렬 환경
    - 자동 커리큘럼 학습 (쉬운 것 → 어려운 것)
    - 실시간 메트릭 추적

하드웨어: RTX 4090 × 4 또는 Jetson Orin NX 클러스터
"""

from __future__ import annotations

import json
import logging
import math
import multiprocessing as mp
import os
import pickle
import signal
import sys
import threading
import time
import uuid
from collections import deque
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("jihun_v90.massive_training")


# ─── 상수 ──────────────────────────────────────────────────────────────────

DEFAULT_NUM_ENVS = min(os.cpu_count() or 4, 16)  # 기본 병렬 환경 수
EPISODES_PER_ENV = 1000  # 환경당 에피소드 수
STEPS_PER_EPISODE = 500  # 에피소드당 스텝 수
CHECKPOINT_INTERVAL = 100  # 체크포인트 저장 간격 (에피소드)
SAVE_DIR = Path("checkpoints")


@dataclass
class EpisodeResult:
    """단일 에피소드 결과."""
    episode_id: int
    env_id: int
    total_reward: float
    steps: int
    success: bool
    task_name: str
    duration_sec: float
    final_position: List[float]
    collisions: int
    curriculum_level: int


@dataclass
class TrainingMetrics:
    """훈련 메트릭."""
    total_episodes: int = 0
    total_steps: int = 0
    total_envs: int = 0
    success_rate: float = 0.0
    avg_reward: float = 0.0
    avg_episode_length: float = 0.0
    throughput_eps_per_hour: float = 0.0
    best_reward: float = -float('inf')
    curriculum_level: int = 1
    sim_to_real_gap: float = 1.0  # 1.0 = 전혀 전이 안 됨, 0.0 = 완벽
    training_time_sec: float = 0.0
    checkpoint_path: str = ""


class CurriculumScheduler:
    """
    자동 커리큘럼 스케줄러.
    
    성공률이 80% 이상이면 다음 난이도로,
    50% 이하면 이전 난이도로.
    """
    
    LEVELS = {
        1: {"name": "flat_empty", "friction": (0.8, 0.8), "obstacles": 0, "lighting": "bright"},
        2: {"name": "flat_minor_noise", "friction": (0.6, 1.0), "obstacles": 0, "lighting": "bright"},
        3: {"name": "few_obstacles", "friction": (0.5, 0.9), "obstacles": 3, "lighting": "bright"},
        4: {"name": "slippery_floor", "friction": (0.1, 0.5), "obstacles": 3, "lighting": "bright"},
        5: {"name": "dim_light", "friction": (0.3, 0.8), "obstacles": 5, "lighting": "dim"},
        6: {"name": "cluttered", "friction": (0.2, 0.9), "obstacles": 10, "lighting": "normal"},
        7: {"name": " uneven_terrain", "friction": (0.2, 0.7), "obstacles": 8, "lighting": "normal", "slope": 0.1},
        8: {"name": "dark_cluttered", "friction": (0.1, 0.6), "obstacles": 12, "lighting": "dark"},
        9: {"name": "dynamic_objects", "friction": (0.1, 0.8), "obstacles": 15, "lighting": "variable"},
        10: {"name": "full_chaos", "friction": (0.05, 0.95), "obstacles": 20, "lighting": "variable", "slope": 0.2},
    }
    
    def __init__(self, max_level: int = 10):
        self.current_level = 1
        self.max_level = max_level
        self.success_history: Deque[bool] = deque(maxlen=100)
        self.threshold_up = 0.80
        self.threshold_down = 0.50
    
    def report(self, success: bool) -> None:
        """에피소드 결과 보고."""
        self.success_history.append(success)
    
    def update(self) -> int:
        """성공률에 따라 레벨 조정."""
        if len(self.success_history) < 20:
            return self.current_level
        
        rate = sum(self.success_history) / len(self.success_history)
        
        if rate >= self.threshold_up and self.current_level < self.max_level:
            self.current_level += 1
            logger.info(f"Curriculum UP: Level {self.current_level} "
                       f"({self.LEVELS[self.current_level]['name']})")
        elif rate <= self.threshold_down and self.current_level > 1:
            self.current_level -= 1
            logger.info(f"Curriculum DOWN: Level {self.current_level} "
                       f"({self.LEVELS[self.current_level]['name']})")
        
        return self.current_level
    
    def get_config(self) -> Dict:
        """현재 레벨 설정 반환."""
        return self.LEVELS.get(self.current_level, self.LEVELS[1])


class DomainRandomizer:
    """
    고급 도메인 랜덤라이제이션.
    
    Boston Dynamics 스타일 — 물리, 시각, 동역학 전 영역 랜덤화.
    """
    
    # 물리 파라미터 범위
    PHYSICS_RANGES = {
        "gravity": (8.5, 11.0),           # m/s²
        "friction": (0.05, 0.95),          # 마찰계수
        "restitution": (0.0, 0.5),         # 탄성계수
        "mass_scale": (0.7, 1.3),          # 질량 배율
        "motor_strength": (0.8, 1.2),      # 모터 힘 배율
        "joint_damping": (0.01, 0.1),      # 관절 감쇠
        "surface_roughness": (0.0, 0.02),  # 표면 거칠기
    }
    
    # 센서 노이즈 파라미터
    SENSOR_RANGES = {
        "imu_noise": (0.001, 0.05),        # IMU 노이즈 (rad/s)
        "lidar_noise": (0.001, 0.02),      # LiDAR 노이즈 (m)
        "camera_noise": (0, 15),           # 칩라 노이즈 (pixel std)
        "latency_ms": (0, 50),             # 액추에이터 지연 (ms)
        "dropout_prob": (0.0, 0.05),       # 패킷 드롭 확률
    }
    
    # 환경 파라미터
    ENV_RANGES = {
        "lighting_intensity": (0.3, 1.0),
        "object_color_jitter": (0.0, 0.3),
        "texture_randomization": True,
        "background_randomization": True,
    }
    
    def __init__(self, seed: Optional[int] = None):
        self.rng = np.random.RandomState(seed)
        self.current_params: Dict[str, Any] = {}
        self.randomize()
    
    def randomize(self) -> Dict[str, Any]:
        """모든 파라미터 새로 랜덤화."""
        self.current_params = {
            "physics": {
                k: self.rng.uniform(*v) if isinstance(v, tuple) else v
                for k, v in self.PHYSICS_RANGES.items()
            },
            "sensor": {
                k: self.rng.uniform(*v) if isinstance(v, tuple) else v
                for k, v in self.SENSOR_RANGES.items()
            },
            "environment": {
                k: self.rng.uniform(*v) if isinstance(v, tuple) else v
                for k, v in self.ENV_RANGES.items()
            },
        }
        return self.current_params
    
    def get_physics_params(self) -> Dict:
        return self.current_params.get("physics", {})
    
    def get_sensor_params(self) -> Dict:
        return self.current_params.get("sensor", {})
    
    def apply_noise(self, sensor_type: str, data: np.ndarray) -> np.ndarray:
        """센서 데이터에 노이즈 적용."""
        sensor = self.current_params.get("sensor", {})
        
        if sensor_type == "imu":
            noise_std = sensor.get("imu_noise", 0.01)
            return data + self.rng.normal(0, noise_std, data.shape)
        elif sensor_type == "lidar":
            noise_std = sensor.get("lidar_noise", 0.005)
            return np.maximum(0, data + self.rng.normal(0, noise_std, data.shape))
        elif sensor_type == "camera":
            noise_std = sensor.get("camera_noise", 5)
            noisy = data.astype(np.float32) + self.rng.normal(0, noise_std, data.shape)
            return np.clip(noisy, 0, 255).astype(np.uint8)
        
        return data


class ParallelEnvWorker:
    """
    단일 병렬 환경 워커.
    
    multiprocessing.Process에서 실행됨.
    """
    
    def __init__(self, env_id: int, num_episodes: int, steps_per_ep: int,
                 curriculum: CurriculumScheduler, dr: DomainRandomizer):
        self.env_id = env_id
        self.num_episodes = num_episodes
        self.steps_per_ep = steps_per_ep
        self.curriculum = curriculum
        self.dr = dr
        self.results: List[EpisodeResult] = []
    
    def run(self) -> List[EpisodeResult]:
        """에피소드 실행."""
        logger.info(f"[Env {self.env_id}] Starting {self.num_episodes} episodes")
        
        for ep in range(self.num_episodes):
            # 50 에피소드마다 도메인 랜덤라이제이션 갱신
            if ep % 50 == 0:
                self.dr.randomize()
                self.curriculum.update()
            
            result = self._run_episode(ep)
            self.results.append(result)
            
            # 성공률 보고
            self.curriculum.report(result.success)
        
        logger.info(f"[Env {self.env_id}] Complete: "
                   f"{sum(r.success for r in self.results)}/{self.num_episodes} success")
        return self.results
    
    def _run_episode(self, episode_id: int) -> EpisodeResult:
        """단일 에피소드 시뮬레이션."""
        t0 = time.time()
        
        # 환경 설정 (커리큘럼 레벨 기반)
        config = self.curriculum.get_config()
        physics = self.dr.get_physics_params()
        
        # 초기 상태
        pos = np.zeros(3)
        vel = np.zeros(3)
        
        total_reward = 0.0
        collisions = 0
        
        # 에피소드 스텝
        for step in range(self.steps_per_ep):
            # 물리 적용 (간단화된)
            dt = 0.01
            
            # 중력 + 랜덤화
            gravity = physics.get("gravity", 9.81)
            if pos[2] > 0:
                vel[2] -= gravity * dt
            else:
                pos[2] = 0
                vel[2] = max(0, vel[2])
            
            # 마찰
            friction = physics.get("friction", 0.8)
            vel[0] *= (1 - friction * 0.01)
            vel[1] *= (1 - friction * 0.01)
            
            # 센서 노이즈 적용
            noisy_pos = self.dr.apply_noise("imu", pos)
            
            # 보상 계산 (간단화)
            reward = self._compute_reward(pos, vel, config)
            total_reward += reward
            
            # 위치 업데이트
            pos += vel * dt
            
            # 충돌 검사 (장애물)
            if config.get("obstacles", 0) > 0:
                for obs_idx in range(config["obstacles"]):
                    obs_pos = np.array([0.5 + obs_idx * 0.3, 0.1 * (obs_idx % 3 - 1), 0])
                    dist = np.linalg.norm(pos[:2] - obs_pos[:2])
                    if dist < 0.15:
                        collisions += 1
                        vel *= -0.5  # 반발
            
            # 성공 조건: 목표 지점 도달
            goal = np.array([2.0, 0.0, 0.0])
            if np.linalg.norm(pos[:2] - goal[:2]) < 0.2:
                total_reward += 100  # 목표 도달 본너스
                break
        
        success = np.linalg.norm(pos[:2] - goal[:2]) < 0.3
        
        return EpisodeResult(
            episode_id=episode_id,
            env_id=self.env_id,
            total_reward=total_reward,
            steps=step + 1,
            success=success,
            task_name=config["name"],
            duration_sec=time.time() - t0,
            final_position=pos.tolist(),
            collisions=collisions,
            curriculum_level=self.curriculum.current_level,
        )
    
    def _compute_reward(self, pos: np.ndarray, vel: np.ndarray, 
                       config: Dict) -> float:
        """보상 함수."""
        goal = np.array([2.0, 0.0, 0.0])
        dist_to_goal = np.linalg.norm(pos[:2] - goal[:2])
        
        # 거리 기반 보상
        reward = -dist_to_goal * 0.1
        
        # 속도 보상 (전진)
        reward += vel[0] * 0.5
        
        # 에너지 페널티
        reward -= np.linalg.norm(vel) * 0.01
        
        return reward


def _worker_process(args: Tuple[int, int, int, int]) -> List[Dict]:
    """
    multiprocessing 워커 프로세스 함수.
    
    반드시 모듈 레벨에 정의 (pickle 가능).
    """
    env_id, num_episodes, steps_per_ep, seed = args
    
    # 각 워커별 독립 랜덤 상태
    curriculum = CurriculumScheduler()
    dr = DomainRandomizer(seed=seed + env_id)
    
    worker = ParallelEnvWorker(env_id, num_episodes, steps_per_ep, 
                               curriculum, dr)
    results = worker.run()
    
    # pickle 가능한 dict로 변환
    return [asdict(r) for r in results]


class MassiveTrainingPipeline:
    """
    대규모 병렬 시뮬레이션 훈련 파이프라인.
    
    사용:
        pipeline = MassiveTrainingPipeline(num_envs=16)
        metrics = pipeline.train(target_episodes=100000)
        pipeline.save_checkpoint("v9_production.pt")
    """
    
    def __init__(self, num_envs: int = DEFAULT_NUM_ENVS,
                 episodes_per_env: int = EPISODES_PER_ENV,
                 steps_per_episode: int = STEPS_PER_EPISODE,
                 save_dir: str = "checkpoints"):
        self.num_envs = num_envs
        self.episodes_per_env = episodes_per_env
        self.steps_per_episode = steps_per_episode
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(exist_ok=True)
        
        self.metrics = TrainingMetrics()
        self.all_results: List[EpisodeResult] = []
        self.start_time: float = 0.0
        
        # 진행 상황 콜백
        self._progress_callback: Optional[Callable] = None
        self._stop_requested = False
    
    def train(self, target_episodes: Optional[int] = None) -> TrainingMetrics:
        """
        대규모 병렬 훈련 실행.
        
        Args:
            target_episodes: 목표 에피소드 수 (None = episodes_per_env * num_envs)
        
        Returns:
            훈련 메트릭
        """
        if target_episodes is None:
            target_episodes = self.episodes_per_env * self.num_envs
        
        self.start_time = time.time()
        logger.info("="*60)
        logger.info("MASSIVE PARALLEL SIMULATION TRAINING")
        logger.info(f"Environments: {self.num_envs}")
        logger.info(f"Episodes/env: {self.episodes_per_env}")
        logger.info(f"Total target: {target_episodes:,} episodes")
        logger.info(f"Steps/episode: {self.steps_per_episode}")
        logger.info(f"Parallelism: {self.num_envs} processes")
        logger.info("="*60)
        
        # 워커 인자 준비
        worker_args = [
            (i, self.episodes_per_env, self.steps_per_episode, 
             int(time.time()))
            for i in range(self.num_envs)
        ]
        
        # 병렬 실행
        all_results_raw: List[List[Dict]] = []
        
        with ProcessPoolExecutor(max_workers=self.num_envs) as executor:
            futures = {executor.submit(_worker_process, args): args[0] 
                      for args in worker_args}
            
            completed_envs = 0
            for future in as_completed(futures):
                env_id = futures[future]
                try:
                    results = future.result()
                    all_results_raw.append(results)
                    completed_envs += 1
                    
                    total_done = sum(len(r) for r in all_results_raw)
                    logger.info(f"Progress: {completed_envs}/{self.num_envs} envs, "
                               f"{total_done:,} episodes complete")
                    
                    if self._stop_requested:
                        logger.info("Stop requested, waiting for remaining...")
                        break
                        
                except Exception as e:
                    logger.error(f"Env {env_id} failed: {e}")
        
        # 결과 수집
        self.all_results = [EpisodeResult(**r) for batch in all_results_raw for r in batch]
        
        # 메트릭 계산
        self._compute_metrics()
        
        # 체크포인트 저장
        self.save_checkpoint()
        
        return self.metrics
    
    def _compute_metrics(self) -> None:
        """훈련 메트릭 계산."""
        if not self.all_results:
            return
        
        r = self.all_results
        n = len(r)
        
        self.metrics.total_episodes = n
        self.metrics.total_steps = sum(ep.steps for ep in r)
        self.metrics.total_envs = self.num_envs
        self.metrics.success_rate = sum(1 for ep in r if ep.success) / n * 100
        self.metrics.avg_reward = sum(ep.total_reward for ep in r) / n
        self.metrics.avg_episode_length = sum(ep.steps for ep in r) / n
        self.metrics.best_reward = max(ep.total_reward for ep in r)
        self.metrics.training_time_sec = time.time() - self.start_time
        
        # 처리량 (에피소드/시간)
        hours = self.metrics.training_time_sec / 3600
        if hours > 0:
            self.metrics.throughput_eps_per_hour = n / hours
        
        # 최종 커리큘럼 레벨
        self.metrics.curriculum_level = max(ep.curriculum_level for ep in r)
        
        logger.info("="*60)
        logger.info("TRAINING COMPLETE")
        logger.info(f"  Total episodes: {n:,}")
        logger.info(f"  Success rate: {self.metrics.success_rate:.1f}%")
        logger.info(f"  Avg reward: {self.metrics.avg_reward:.2f}")
        logger.info(f"  Best reward: {self.metrics.best_reward:.2f}")
        logger.info(f"  Throughput: {self.metrics.throughput_eps_per_hour:.0f} eps/hour")
        logger.info(f"  Curriculum level: {self.metrics.curriculum_level}/10")
        logger.info(f"  Time: {self.metrics.training_time_sec:.1f}s")
        logger.info("="*60)
    
    def save_checkpoint(self, name: Optional[str] = None) -> str:
        """체크포인트 저장."""
        if name is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            name = f"checkpoint_{ts}_ep{self.metrics.total_episodes}"
        
        path = self.save_dir / f"{name}.pkl"
        
        checkpoint = {
            "version": "9.0",
            "metrics": asdict(self.metrics),
            "results": [asdict(r) for r in self.all_results[-1000:]],  # 최근 1000개만
            "timestamp": datetime.now().isoformat(),
        }
        
        with open(path, 'wb') as f:
            pickle.dump(checkpoint, f)
        
        self.metrics.checkpoint_path = str(path)
        logger.info(f"Checkpoint saved: {path}")
        
        # 메트릭 JSON도 저장
        json_path = self.save_dir / f"{name}_metrics.json"
        with open(json_path, 'w') as f:
            json.dump(asdict(self.metrics), f, indent=2)
        
        return str(path)
    
    def load_checkpoint(self, path: str) -> None:
        """체크포인트 로드."""
        with open(path, 'rb') as f:
            ckpt = pickle.load(f)
        
        self.metrics = TrainingMetrics(**ckpt["metrics"])
        logger.info(f"Checkpoint loaded: {path}")
    
    def get_report(self) -> Dict:
        """훈련 보고서 생성."""
        return {
            "summary": asdict(self.metrics),
            "curriculum_progression": self._get_curriculum_stats(),
            "task_breakdown": self._get_task_stats(),
            "recommendation": self._get_recommendation(),
        }
    
    def _get_curriculum_stats(self) -> Dict:
        """커리큘럼 진행 통계."""
        stats = {}
        for ep in self.all_results:
            level = ep.curriculum_level
            if level not in stats:
                stats[level] = {"total": 0, "success": 0}
            stats[level]["total"] += 1
            if ep.success:
                stats[level]["success"] += 1
        
        return {f"level_{k}": {
            "total": v["total"],
            "success_rate": v["success"] / v["total"] * 100 if v["total"] > 0 else 0
        } for k, v in sorted(stats.items())}
    
    def _get_task_stats(self) -> Dict:
        """태스크별 통계."""
        stats = {}
        for ep in self.all_results:
            task = ep.task_name
            if task not in stats:
                stats[task] = {"total": 0, "success": 0, "avg_reward": 0.0}
            stats[task]["total"] += 1
            if ep.success:
                stats[task]["success"] += 1
            stats[task]["avg_reward"] += ep.total_reward
        
        for task in stats:
            n = stats[task]["total"]
            stats[task]["avg_reward"] /= n
            stats[task]["success_rate"] = stats[task]["success"] / n * 100
        
        return stats
    
    def _get_recommendation(self) -> str:
        """훈련 결과 기반 권장사항."""
        if self.metrics.success_rate >= 90:
            return "Sim-to-Real 전이 준비 완료. 도메인 적응을 시작하세요."
        elif self.metrics.success_rate >= 70:
            return "추가 훈련 권장. 목표: 90%+ 성공률."
        elif self.metrics.success_rate >= 50:
            return "커리큘럼 학습 진행 중. 더 많은 에피소드 필요."
        else:
            return "훈련 실패. 보상 함수/정책 아키텍처 검토 필요."
    
    def stop(self) -> None:
        """훈련 중지 요청."""
        self._stop_requested = True
        logger.info("Stop requested")


# ====== 편의 함수 ======

def run_massive_training(num_envs: int = 16, 
                         episodes_per_env: int = 1000) -> TrainingMetrics:
    """
    대규모 훈련 원클릭 실행.
    
    예:
        metrics = run_massive_training(num_envs=32, episodes_per_env=5000)
        print(f"Success rate: {metrics.success_rate:.1f}%")
    """
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%H:%M:%S",
    )
    
    pipeline = MassiveTrainingPipeline(num_envs=num_envs,
                                        episodes_per_env=episodes_per_env)
    
    try:
        metrics = pipeline.train()
        
        # 보고서 저장
        report = pipeline.get_report()
        with open("training_report.json", 'w') as f:
            json.dump(report, f, indent=2, default=str)
        logger.info("Report saved: training_report.json")
        
        return metrics
        
    except KeyboardInterrupt:
        logger.info("Training interrupted by user")
        pipeline.stop()
        return pipeline.metrics


if __name__ == "__main__":
    # 기본: 8 환경 × 1000 에피소드 = 8,000 에피소드
    # 고성능: 32 환경 × 5000 에피소드 = 160,000 에피소드
    
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--envs", type=int, default=8)
    parser.add_argument("--episodes", type=int, default=1000)
    args = parser.parse_args()
    
    run_massive_training(num_envs=args.envs, episodes_per_env=args.episodes)
