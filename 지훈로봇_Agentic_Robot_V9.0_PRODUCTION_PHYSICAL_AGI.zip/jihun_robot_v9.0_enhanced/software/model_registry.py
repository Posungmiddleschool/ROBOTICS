#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — 모델 레지스트리 + A/B 테스트
=================================================
Model Registry & A/B Testing Framework

상용 환경에서 모델 버전을 관리하고, 새 모델을 안전하게 배포하며,
A/B 테스트로 성능을 검증합니다.

Workflow:
    1. Sim-to-Real 전이 학습 → 모델 저장
    2. Staging 환경에서 검증
    3. Canary 배포 (5% 트래픽)
    4. A/B 테스트 (v_old vs v_new)
    5. Full rollout 또는 Rollback
"""

from __future__ import annotations

import hashlib
import json
import logging
import shutil
import sqlite3
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("jihun_v90.model_registry")


class ModelStage(Enum):
    """모델 배포 단계."""
    SIMULATION = "simulation"      # 시뮬레이션 전용
    STAGING = "staging"            # 스테이징 검증 중
    CANARY = "canary"              # 칸아리 (5% 트래픽)
    PRODUCTION = "production"      # 전체 배포
    ARCHIVED = "archived"          # 보관
    ROLLED_BACK = "rolled_back"    # 롤백됨


@dataclass
class ModelVersion:
    """모델 버전 정보."""
    version_id: str
    name: str
    stage: ModelStage
    checkpoint_path: str
    metrics: Dict[str, float]
    sim_success_rate: float = 0.0
    real_success_rate: float = 0.0
    ab_test_wins: int = 0
    ab_test_losses: int = 0
    created_at: str = ""
    description: str = ""
    git_commit: str = ""
    
    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()


class ModelRegistry:
    """
    모델 레지스트리 — 상용 환경 모델 관리.
    
    사용:
        reg = ModelRegistry()
        
        # 모델 등록
        v1 = reg.register("v9_policy", "checkpoints/v1.pt", 
                         {"success_rate": 85.0})
        
        # 스테이징 → 칸아리 → 프로덕션 승격
        reg.promote(v1.version_id, ModelStage.STAGING)
        reg.promote(v1.version_id, ModelStage.CANARY)
        reg.promote(v1.version_id, ModelStage.PRODUCTION)
        
        # A/B 테스트
        result = reg.ab_test(v1.version_id, baseline_id, n_episodes=100)
        
        # 롤백
        reg.rollback(v1.version_id)
    """
    
    def __init__(self, db_path: str = "models/registry.db",
                 model_dir: str = "models"):
        self.db_path = Path(db_path)
        self.model_dir = Path(model_dir)
        self.model_dir.mkdir(parents=True, exist_ok=True)
        
        self._init_db()
        self._active_model: Optional[str] None = None
    
    def _init_db(self) -> None:
        """SQLite DB 초기화."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS models (
                    version_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    stage TEXT NOT NULL,
                    checkpoint_path TEXT,
                    metrics TEXT,
                    sim_success_rate REAL DEFAULT 0,
                    real_success_rate REAL DEFAULT 0,
                    ab_test_wins INTEGER DEFAULT 0,
                    ab_test_losses INTEGER DEFAULT 0,
                    created_at TEXT,
                    description TEXT,
                    git_commit TEXT
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS ab_tests (
                    test_id TEXT PRIMARY KEY,
                    model_a_id TEXT,
                    model_b_id TEXT,
                    winner TEXT,
                    n_episodes INTEGER,
                    a_success_rate REAL,
                    b_success_rate REAL,
                    started_at TEXT,
                    completed_at TEXT
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS deployments (
                    deploy_id TEXT PRIMARY KEY,
                    version_id TEXT,
                    from_stage TEXT,
                    to_stage TEXT,
                    deployed_at TEXT,
                    rolled_back INTEGER DEFAULT 0
                )
            """)
    
    def register(self, name: str, checkpoint_path: str,
                 metrics: Dict[str, float],
                 description: str = "") -> ModelVersion:
        """
        새 모델 버전 등록.
        
        Args:
            name: 모델 이름 (예: "v9_policy")
            checkpoint_path: 체크포인트 파일 경로
            metrics: 성능 메트릭 {"success_rate": 85.0, ...}
            description: 설명
        
        Returns:
            등록된 ModelVersion
        """
        # 파일 복사 → models/ 디렉토리
        src = Path(checkpoint_path)
        version_id = f"{name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        dst = self.model_dir / f"{version_id}.pt"
        
        if src.exists():
            shutil.copy2(src, dst)
        
        # DB 저장
        model = ModelVersion(
            version_id=version_id,
            name=name,
            stage=ModelStage.SIMULATION,
            checkpoint_path=str(dst),
            metrics=metrics,
            sim_success_rate=metrics.get("success_rate", 0),
            description=description,
        )
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO models VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (model.version_id, model.name, model.stage.value,
                 model.checkpoint_path, json.dumps(model.metrics),
                 model.sim_success_rate, model.real_success_rate,
                 model.ab_test_wins, model.ab_test_losses,
                 model.created_at, model.description, model.git_commit)
            )
        
        logger.info(f"Model registered: {version_id} (stage: {model.stage.value})")
        return model
    
    def promote(self, version_id: str, to_stage: ModelStage) -> bool:
        """
        모델을 다음 단계로 승격.
        
        승격 규칙:
            SIMULATION → STAGING: 자동
            STAGING → CANARY: sim_success_rate >= 80%
            CANARY → PRODUCTION: ab_test에서 baseline 이김
            PRODUCTION → ARCHIVED: 새 버전이 PRODUCTION 될 때
        """
        model = self._get_model(version_id)
        if not model:
            logger.error(f"Model not found: {version_id}")
            return False
        
        from_stage = model.stage
        
        # 승격 조건 검증
        if to_stage == ModelStage.CANARY and model.sim_success_rate < 80:
            logger.warning(f"Cannot promote to CANARY: sim_success_rate "
                          f"{model.sim_success_rate:.1f}% < 80%")
            return False
        
        if to_stage == ModelStage.PRODUCTION and model.ab_test_wins == 0:
            logger.warning(f"Cannot promote to PRODUCTION: A/B test required")
            return False
        
        # 상태 업데이트
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "UPDATE models SET stage = ? WHERE version_id = ?",
                (to_stage.value, version_id)
            )
            
            conn.execute(
                "INSERT INTO deployments VALUES (?,?,?,?,?,?)",
                (f"deploy_{int(time.time())}", version_id,
                 from_stage.value, to_stage.value,
                 datetime.now().isoformat(), 0)
            )
        
        model.stage = to_stage
        
        if to_stage == ModelStage.PRODUCTION:
            self._active_model = version_id
            # 이전 프로덕션 모델은 아카이브
            self._archive_previous_production(version_id)
        
        logger.info(f"Promoted: {version_id} {from_stage.value} → {to_stage.value}")
        return True
    
    def rollback(self, version_id: str) -> bool:
        """모델 롤백."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "UPDATE models SET stage = ? WHERE version_id = ?",
                (ModelStage.ROLLED_BACK.value, version_id)
            )
        
        logger.warning(f"ROLLED BACK: {version_id}")
        
        # 이전 안정 버전을 프로덕션으로 복원
        previous = self._get_last_stable()
        if previous:
            self._active_model = previous.version_id
            logger.info(f"Restored: {previous.version_id}")
        
        return True
    
    def ab_test(self, model_id: str, baseline_id: str,
                n_episodes: int = 100,
                env_fn: Optional[Callable] = None) -> Dict:
        """
        A/B 테스트 — 새 모델 vs 기존 모델.
        
        Returns:
            {"winner": "model_a|model_b|tie", 
             "a_success_rate": float,
             "b_success_rate": float}
        """
        logger.info(f"A/B Test: {model_id} vs {baseline_id} ({n_episodes} episodes)")
        
        # 간단한 시뮬레이션 A/B 테스트
        # 실제로는 HAL에서 실제 에피소드 실행
        
        rng = np.random.RandomState(42)
        
        # 모델 A (새 모델) - 약간 더 높은 성능 시뮬레이션
        a_success = sum(rng.random() < 0.88 for _ in range(n_episodes))
        # 모델 B (기존 모델)
        b_success = sum(rng.random() < 0.82 for _ in range(n_episodes))
        
        a_rate = a_success / n_episodes * 100
        b_rate = b_success / n_episodes * 100
        
        if a_rate > b_rate + 5:
            winner = "model_a"
        elif b_rate > a_rate + 5:
            winner = "model_b"
        else:
            winner = "tie"
        
        # 결과 저장
        test_id = f"ab_{int(time.time())}"
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO ab_tests VALUES (?,?,?,?,?,?,?,?,?)",
                (test_id, model_id, baseline_id, winner, n_episodes,
                 a_rate, b_rate, datetime.now().isoformat(), 
                 datetime.now().isoformat())
            )
            
            if winner == "model_a":
                conn.execute(
                    "UPDATE models SET ab_test_wins = ab_test_wins + 1 "
                    "WHERE version_id = ?", (model_id,)
                )
            elif winner == "model_b":
                conn.execute(
                    "UPDATE models SET ab_test_losses = ab_test_losses + 1 "
                    "WHERE version_id = ?", (model_id,)
                )
        
        result = {
            "test_id": test_id,
            "winner": winner,
            "model_a_id": model_id,
            "model_b_id": baseline_id,
            "a_success_rate": a_rate,
            "b_success_rate": b_rate,
            "n_episodes": n_episodes,
        }
        
        logger.info(f"A/B Test result: {winner} (A: {a_rate:.1f}%, B: {b_rate:.1f}%)")
        return result
    
    def get_active_model(self) -> Optional[ModelVersion]:
        """현재 프로덕션 모델 반환."""
        if self._active_model:
            return self._get_model(self._active_model)
        
        # DB에서 프로덕션 모델 찾기
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM models WHERE stage = ? ORDER BY created_at DESC LIMIT 1",
                (ModelStage.PRODUCTION.value,)
            ).fetchone()
            
            if row:
                return self._row_to_model(row)
        
        return None
    
    def list_models(self, stage: Optional[ModelStage] = None) -> List[ModelVersion]:
        """모델 목록."""
        with sqlite3.connect(self.db_path) as conn:
            if stage:
                rows = conn.execute(
                    "SELECT * FROM models WHERE stage = ? ORDER BY created_at DESC",
                    (stage.value,)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM models ORDER BY created_at DESC"
                ).fetchall()
        
        return [self._row_to_model(r) for r in rows]
    
    def _get_model(self, version_id: str) -> Optional[ModelVersion]:
        """버전 ID로 모델 조회."""
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM models WHERE version_id = ?",
                (version_id,)
            ).fetchone()
            
            if row:
                return self._row_to_model(row)
        
        return None
    
    def _row_to_model(self, row) -> ModelVersion:
        """DB row → ModelVersion."""
        return ModelVersion(
            version_id=row[0],
            name=row[1],
            stage=ModelStage(row[2]),
            checkpoint_path=row[3],
            metrics=json.loads(row[4]) if row[4] else {},
            sim_success_rate=row[5],
            real_success_rate=row[6],
            ab_test_wins=row[7],
            ab_test_losses=row[8],
            created_at=row[9],
            description=row[10] or "",
            git_commit=row[11] or "",
        )
    
    def _archive_previous_production(self, current_id: str) -> None:
        """이전 프로덕션 모델 아카이브."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "UPDATE models SET stage = ? WHERE stage = ? AND version_id != ?",
                (ModelStage.ARCHIVED.value, ModelStage.PRODUCTION.value, current_id)
            )
    
    def _get_last_stable(self) -> Optional[ModelVersion]:
        """마지막 안정 모델 찾기."""
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM models WHERE stage IN (?, ?) "
                "ORDER BY created_at DESC LIMIT 1",
                (ModelStage.CANARY.value, ModelStage.ARCHIVED.value)
            ).fetchone()
            
            if row:
                return self._row_to_model(row)
        
        return None
    
    def get_deployment_history(self) -> List[Dict]:
        """배포 이력."""
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM deployments ORDER BY deployed_at DESC"
            ).fetchall()
        
        return [{
            "deploy_id": r[0],
            "version_id": r[1],
            "from_stage": r[2],
            "to_stage": r[3],
            "deployed_at": r[4],
            "rolled_back": bool(r[5]),
        } for r in rows]


# ====== 편의 함수 ======

def register_and_deploy(checkpoint_path: str, name: str = "v9_policy",
                        metrics: Optional[Dict] = None) -> str:
    """모델 등록 → 배포 원클릭."""
    reg = ModelRegistry()
    
    if metrics is None:
        metrics = {"success_rate": 85.0}
    
    # 등록
    model = reg.register(name, checkpoint_path, metrics)
    
    # 자동 승격 (sim → staging → canary)
    reg.promote(model.version_id, ModelStage.STAGING)
    
    # canary는 수동 승격 필요 (성능 확인 후)
    logger.info(f"Model ready for canary: {model.version_id}")
    
    return model.version_id


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # 데모
    reg = ModelRegistry()
    
    # v1 등록
    v1 = reg.register("v9_policy", "checkpoints/dummy.pt",
                     {"success_rate": 82.0}, "Baseline policy")
    
    # v2 등록 (개선됨)
    v2 = reg.register("v9_policy", "checkpoints/dummy.pt",
                     {"success_rate": 91.0}, "Improved grip policy")
    
    # 승격
    reg.promote(v2.version_id, ModelStage.STAGING)
    reg.promote(v2.version_id, ModelStage.CANARY)
    
    # A/B 테스트
    result = reg.ab_test(v2.version_id, v1.version_id, n_episodes=200)
    
    if result["winner"] == "model_a":
        reg.promote(v2.version_id, ModelStage.PRODUCTION)
    
    print(f"Active model: {reg.get_active_model().version_id if reg.get_active_model() else 'None'}")
