#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — 통합 파이프라인 (Integration Pipeline)
=========================================================

V8.5의 최대 약점: "80개 모듈이 있지만 통합되어 있지 않음"
→ 이 모듈이 5개 핵심 모듈을 하나의 파이프라인으로 연결합니다.

핵심 파이프라인: 이동 → 감지 → 파지 → 학습 → 안전
                      ↑_________________________↓
                              (피드백 루프)

실행 흐름:
    1. VLA Bridge가 자연어 명령을 파싱 ("저 컵을 들어줘")
    2. Primitive Action Engine이 액션 시퀀스 생성
    3. World Model이 결과 예측 ("생각한 후 행동")
    4. Safety Engine이 안전 검증 (7계층)
    5. HAL이 하드웨어/시뮬레이션에 명령 전달
    6. Continuous Learner가 경험 저장 → 지식 축적
    7. 다음 명령으로 순환

이 파일 하나로 전체 시스템이 작동합니다.
"""

from __future__ import annotations

import json
import logging
import os
import signal
import sys
import threading
import time
import traceback
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger("jihun_v90.pipeline")


class PipelineState(Enum):
    """파이프라인 상태."""
    IDLE = "idle"
    INITIALIZING = "initializing"
    READY = "ready"
    RUNNING = "running"
    LEARNING = "learning"
    SAFETY_STOP = "safety_stop"
    ERROR = "error"
    SHUTDOWN = "shutdown"


@dataclass
class PipelineMetrics:
    """파이프라인 성능 메트릭."""
    loop_hz: float = 0.0
    inference_ms: float = 0.0
    safety_checks_ps: float = 0.0
    total_experiences: int = 0
    successful_actions: int = 0
    failed_actions: int = 0
    uptime_seconds: float = 0.0
    memory_mb: float = 0.0


class IntegrationPipeline:
    """
    통합 파이프라인 — 전체 로봇 시스템의 중추.
    
    하드웨어 없이도 시뮬레이션으로 작동합니다.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        self.state = PipelineState.IDLE
        self.config = self._load_config(config_path)
        self.metrics = PipelineMetrics()
        
        # 핵심 모듈 (지연 로딩)
        self._hal = None
        self._vla = None
        self._primitive_engine = None
        self._world_model = None
        self._safety_engine = None
        self._learner = None
        
        # 파이프라인 스레드
        self._running = False
        self._main_thread: Optional[threading.Thread] = None
        self._safety_thread: Optional[threading.Thread] = None
        self._learning_thread: Optional[threading.Thread] = None
        
        # 명령 큐
        self._command_queue: Deque[str] = deque(maxlen=100)
        self._experience_buffer: List[Dict] = []
        
        # 콜백
        self._state_callbacks: List[Callable] = []
        
        # 신호 핸들러
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
    def _load_config(self, path: Optional[str]) -> Dict:
        """설정 로드."""
        default = {
            "target_hz": 10,
            "safety_hz": 100,
            "learning_interval_s": 300,
            "simulation": True,
            "log_experiences": True,
            "max_experience_buffer": 1000,
        }
        if path and os.path.exists(path):
            with open(path) as f:
                loaded = json.load(f)
                default.update(loaded)
        return default
    
    def _signal_handler(self, signum, frame):
        """종료 신호 핸들러."""
        logger.info(f"Signal {signum} received, shutting down...")
        self.shutdown()
        sys.exit(0)
    
    def initialize(self) -> bool:
        """
        전체 파이프라인 초기화.
        
        순서: HAL → Safety → VLA → World Model → Primitive → Learner
        """
        self.state = PipelineState.INITIALIZING
        start_time = time.time()
        
        try:
            # 1. HAL (하드웨어/시뮬레이션)
            logger.info("[1/6] Initializing HAL...")
            from .hardware_abstraction import create_hal
            mode = "simulation" if self.config["simulation"] else "hardware"
            self._hal = create_hal(mode)
            if not self._hal.initialize():
                raise RuntimeError("HAL initialization failed")
            logger.info("HAL ready")
            
            # 2. Safety Engine (가장 먼저 — 모든 것을 보호)
            logger.info("[2/6] Initializing Safety Engine...")
            from .safety_engine import SafetyEngine
            self._safety_engine = SafetyEngine()
            self._safety_engine.activate()
            logger.info("Safety Engine ready (7 layers)")
            
            # 3. VLA Bridge (시각-언어-행동)
            logger.info("[3/6] Initializing VLA Bridge...")
            try:
                from .vla_bridge import VLABridge
                self._vla = VLABridge()
                logger.info("VLA Bridge ready")
            except Exception as e:
                logger.warning(f"VLA Bridge init skipped: {e}")
                self._vla = None
            
            # 4. World Model (물리 예측)
            logger.info("[4/6] Initializing World Model...")
            try:
                from .world_model import WorldModel
                self._world_model = WorldModel()
                logger.info("World Model ready")
            except Exception as e:
                logger.warning(f"World Model init skipped: {e}")
                self._world_model = None
            
            # 5. Primitive Action Engine
            logger.info("[5/6] Initializing Primitive Action Engine...")
            try:
                from .primitive_action_engine import PrimitiveActionEngine
                self._primitive_engine = PrimitiveActionEngine()
                logger.info("Primitive Action Engine ready (55 primitives)")
            except Exception as e:
                logger.warning(f"Primitive Engine init skipped: {e}")
                self._primitive_engine = None
            
            # 6. Continuous Learner
            logger.info("[6/6] Initializing Continuous Learner...")
            try:
                from .continuous_learner import ContinuousLearner
                self._learner = ContinuousLearner()
                logger.info("Continuous Learner ready")
            except Exception as e:
                logger.warning(f"Learner init skipped: {e}")
                self._learner = None
            
            init_time = time.time() - start_time
            self.state = PipelineState.READY
            logger.info(f"Pipeline initialized in {init_time:.1f}s")
            return True
            
        except Exception as e:
            self.state = PipelineState.ERROR
            logger.error(f"Pipeline initialization failed: {e}")
            logger.error(traceback.format_exc())
            return False
    
    def start(self) -> None:
        """파이프라인 시작 — 3개 스레드 실행."""
        if self.state != PipelineState.READY:
            logger.error("Pipeline not ready. Call initialize() first.")
            return
        
        self._running = True
        self.state = PipelineState.RUNNING
        
        # 메인 루프 (VLA + Planning + Execution)
        self._main_thread = threading.Thread(target=self._main_loop, daemon=True)
        self._main_thread.start()
        
        # 안전 모니터링 (100Hz)
        self._safety_thread = threading.Thread(target=self._safety_loop, daemon=True)
        self._safety_thread.start()
        
        # 학습 루프 (5분 간격)
        if self._learner:
            self._learning_thread = threading.Thread(target=self._learning_loop, daemon=True)
            self._learning_thread.start()
        
        logger.info("Pipeline started — 3 threads running")
        
        # 콘솔 명령 수신
        self._console_loop()
    
    def _main_loop(self) -> None:
        """메인 제어 루프 — 10Hz."""
        target_period = 1.0 / self.config["target_hz"]
        
        while self._running:
            loop_start = time.time()
            
            try:
                # 1. 명령 수신
                if self._command_queue:
                    command = self._command_queue.popleft()
                    self._process_command(command)
                
                # 2. 상태 업데이트
                robot_state = self._hal.get_state()
                
                # 3. 안전 검증
                if self._safety_engine and not self._safety_engine.verify(robot_state):
                    self._handle_safety_violation()
                    continue
                
                # 4. 학습 데이터 수집
                if self.config["log_experiences"]:
                    self._collect_experience(robot_state)
                
                # 메트릭 업데이트
                self.metrics.loop_hz = 1.0 / (time.time() - loop_start + 0.001)
                self.metrics.uptime_seconds = time.time() - self._start_time
                
            except Exception as e:
                logger.error(f"Main loop error: {e}")
            
            # 주기 유지
            elapsed = time.time() - loop_start
            if elapsed < target_period:
                time.sleep(target_period - elapsed)
    
    def _safety_loop(self) -> None:
        """안전 모니터링 루프 — 100Hz."""
        target_period = 0.01  # 100Hz
        
        while self._running:
            loop_start = time.time()
            
            try:
                if self._safety_engine and self._hal:
                    state = self._hal.get_state()
                    safe = self._safety_engine.verify(state)
                    
                    if not safe:
                        self._hal.emergency_stop()
                        self.state = PipelineState.SAFETY_STOP
                        logger.warning("SAFETY VIOLATION — E-Stop activated")
                    
                    self.metrics.safety_checks_ps = 1.0 / (time.time() - loop_start + 0.001)
                    
            except Exception as e:
                logger.error(f"Safety loop error: {e}")
            
            elapsed = time.time() - loop_start
            if elapsed < target_period:
                time.sleep(target_period - elapsed)
    
    def _learning_loop(self) -> None:
        """연속 학습 루프 — 5분 간격."""
        interval = self.config["learning_interval_s"]
        
        while self._running:
            time.sleep(interval)
            
            try:
                if self._learner and self._experience_buffer:
                    self.state = PipelineState.LEARNING
                    experiences = self._experience_buffer[:]
                    self._experience_buffer.clear()
                    
                    self._learner.learn_from_experiences(experiences)
                    self.metrics.total_experiences += len(experiences)
                    
                    logger.info(f"Learning batch complete: {len(experiences)} experiences")
                    self.state = PipelineState.RUNNING
                    
            except Exception as e:
                logger.error(f"Learning loop error: {e}")
    
    def _process_command(self, command: str) -> None:
        """자연어 명령 처리."""
        logger.info(f"Processing command: {command}")
        
        try:
            # VLA 파싱
            if self._vla:
                action_plan = self._vla.parse_command(command)
            else:
                action_plan = self._simple_parser(command)
            
            # World Model 예측
            if self._world_model:
                predicted = self._world_model.predict(action_plan)
                logger.info(f"World model prediction: {predicted}")
            
            # Primitive Action 실행
            if self._primitive_engine:
                result = self._primitive_engine.execute(action_plan)
                if result:
                    self.metrics.successful_actions += 1
                else:
                    self.metrics.failed_actions += 1
            
        except Exception as e:
            logger.error(f"Command processing failed: {e}")
            self.metrics.failed_actions += 1
    
    def _simple_parser(self, command: str) -> Dict:
        """간단한 명령 파서 (VLA 없이도 작동)."""
        command = command.lower().strip()
        
        actions = {
            "앞": {"action": "move_forward", "speed": 0.3},
            "뒤": {"action": "move_backward", "speed": 0.3},
            "왼쪽": {"action": "turn_left", "speed": 0.5},
            "오른쪽": {"action": "turn_right", "speed": 0.5},
            "멈춰": {"action": "stop"},
            "서": {"action": "stop"},
            "줘": {"action": "grip", "target": "object"},
            "잡아": {"action": "grip", "target": "object"},
        }
        
        for keyword, action in actions.items():
            if keyword in command:
                return action
        
        return {"action": "idle"}
    
    def _collect_experience(self, state) -> None:
        """학습 경험 수집."""
        exp = {
            "timestamp": time.time(),
            "state": self._serialize_state(state),
            "action": state.current_skill if hasattr(state, 'current_skill') else "idle",
        }
        self._experience_buffer.append(exp)
        
        # 버퍼 오버플로우 방지
        max_buf = self.config["max_experience_buffer"]
        if len(self._experience_buffer) > max_buf:
            self._experience_buffer = self._experience_buffer[-max_buf:]
    
    def _serialize_state(self, state) -> Dict:
        """상태 직렬화."""
        return {
            "position": state.position_m.tolist() if hasattr(state.position_m, 'tolist') else list(state.position_m),
            "velocity": state.velocity_m_s.tolist() if hasattr(state.velocity_m_s, 'tolist') else list(state.velocity_m_s),
            "battery": state.battery_percent,
        }
    
    def _handle_safety_violation(self) -> None:
        """안정 위반 처리."""
        logger.critical("SAFETY VIOLATION HANDLER")
        if self._hal:
            self._hal.emergency_stop()
    
    def _console_loop(self) -> None:
        """콘솔 입력 루프."""
        print("\n" + "="*60)
        print("지훈 로봇 V9.0 — 통합 파이프라인")
        print("Integration Pipeline Ready")
        print("="*60)
        print("Commands: move | grab | stop | status | quit")
        print("Or type natural language (Korean/English)")
        print("-"*60 + "\n")
        
        while self._running:
            try:
                cmd = input("Robot> ").strip()
                if not cmd:
                    continue
                if cmd.lower() in ("quit", "exit", "q"):
                    break
                elif cmd.lower() == "status":
                    self._print_status()
                else:
                    self._command_queue.append(cmd)
                    
            except (EOFError, KeyboardInterrupt):
                break
        
        self.shutdown()
    
    def _print_status(self) -> None:
        """현재 상태 출력."""
        print(f"\n--- Pipeline Status ---")
        print(f"State: {self.state.value}")
        print(f"Uptime: {self.metrics.uptime_seconds:.0f}s")
        print(f"Loop Hz: {self.metrics.loop_hz:.1f}")
        print(f"Safety checks/s: {self.metrics.safety_checks_ps:.0f}")
        print(f"Experiences: {self.metrics.total_experiences}")
        print(f"Actions: {self.metrics.successful_actions} OK / {self.metrics.failed_actions} FAIL")
        if self._hal:
            s = self._hal.get_state()
            print(f"Battery: {s.battery_percent:.0f}%")
            print(f"Position: [{s.position_m[0]:.2f}, {s.position_m[1]:.2f}, {s.position_m[2]:.2f}]")
        print("-" * 30 + "\n")
    
    def send_command(self, command: str) -> None:
        """외부에서 명령 전송."""
        self._command_queue.append(command)
    
    def get_metrics(self) -> PipelineMetrics:
        """현재 메트릭 반환."""
        return self.metrics
    
    def shutdown(self) -> None:
        """전체 파이프라인 종료."""
        logger.info("Shutting down pipeline...")
        self._running = False
        self.state = PipelineState.SHUTDOWN
        
        if self._hal:
            self._hal.shutdown()
        
        threads = [t for t in [self._main_thread, self._safety_thread, self._learning_thread] if t]
        for t in threads:
            t.join(timeout=3.0)
        
        logger.info("Pipeline shutdown complete")


# ====== 편의 함수 ======

def run_pipeline() -> None:
    """파이프라인 실행 — 원클릭 시작."""
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(name)s %(levelname)s — %(message)s",
        datefmt="%H:%M:%S"
    )
    
    pipeline = IntegrationPipeline()
    
    if pipeline.initialize():
        pipeline.start()
    else:
        logger.error("Failed to start pipeline")
        sys.exit(1)


if __name__ == "__main__":
    run_pipeline()
