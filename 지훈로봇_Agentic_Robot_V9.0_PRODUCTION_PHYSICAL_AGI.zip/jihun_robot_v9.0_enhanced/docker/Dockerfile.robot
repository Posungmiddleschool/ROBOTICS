# 지훈 로봇 V9.0 — Robot Pipeline Dockerfile
# ==========================================
# 핵심 파이프라인 컨테이너
# 하드웨어 없이 시뮬레이션 모드로 작동

FROM python:3.10-slim-bookworm

LABEL maintainer="Jihun Robot Team"
LABEL version="9.0"
LABEL description="Jihun Robot V9.0 — Physical AGI Pipeline"

# 시스템 의존성
RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential \
    cmake \
    git \
    curl \
    libopenblas-dev \
    libomp-dev \
    libgl1-mesa-glx \
    libglib2.0-0 \
    && rm -rf /var/lib/apt/lists/*

# 작업 디렉토리
WORKDIR /app

# Python 의존성
COPY docker/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 소프트웨어 복사
COPY software/ ./software/
COPY hardware/ ./hardware/
COPY docs/ ./docs/
COPY scripts/ ./scripts/

# 설정
COPY docker/config/pipeline.yaml ./config/

# API 서버
COPY docker/api_server.py ./

# 환경 변수
ENV JIHUN_ROBOT_MODE=simulation
ENV SIM_ENGINE=standalone
ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1

# 포트
EXPOSE 8000 8001

# 헬스체크
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# 실행
CMD ["python", "-m", "software.integration_pipeline"]
