#!/usr/bin/env python3
"""
지훈 로봇 V9.0 — REST API 서버
===============================
FastAPI 기반 — 전체 파이프라인을 HTTP로 제어.

엔드포인트:
  GET  /health        — 헬스체크
  GET  /status        — 전체 상태
  POST /command       — 명령 전송
  GET  /metrics       — 성능 메트릭
  GET  /state         — 로봇 상태 (위치, 배터리 등)
  POST /safety/estop  — 비상 정지
  POST /safety/reset  — 안전 상태 리셋
  GET  /experiences   — 학습 경험 조회
  GET  /skills        — 보유 스킬 목록
  POST /scenario      — 시뮬레이션 시나리오 실행
  WS   /ws            — 실시간 상태 WebSocket
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
from contextlib import asynccontextmanager
from typing import Any, Dict, Optional

from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# 소프트웨어 경로 추가
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

logger = logging.getLogger("jihun_v90.api")

# === Pydantic 모델 ===

class CommandRequest(BaseModel):
    command: str

class ScenarioRequest(BaseModel):
    name: str
    duration: float = 30.0

class StatusResponse(BaseModel):
    state: str
    uptime_seconds: float
    loop_hz: float
    battery_percent: float
    total_experiences: int
    successful_actions: int
    failed_actions: int

# === 전역 파이프라인 인스턴스 ===

_pipeline = None
_start_time = time.time()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """애플리케이션 수명 주기."""
    global _pipeline
    
    logger.info("Starting API server...")
    
    # 파이프라인 초기화 (백그라운드)
    try:
        from software.integration_pipeline import IntegrationPipeline
        _pipeline = IntegrationPipeline()
        _pipeline.initialize()
        
        # 백그라운드 스레드로 메인 루프 시작
        import threading
        t = threading.Thread(target=_pipeline.start, daemon=True)
        t.start()
        
        logger.info("Pipeline initialized")
    except Exception as e:
        logger.warning(f"Pipeline initialization skipped: {e}")
    
    yield
    
    # 종료
    if _pipeline:
        _pipeline.shutdown()
    logger.info("API server shutdown")

# === FastAPI 앱 ===

app = FastAPI(
    title="Jihun Robot V9.0 API",
    description="Physical AGI Robot Control API",
    version="9.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === 엔드포인트 ===

@app.get("/health")
async def health():
    """헬스체크."""
    return {
        "status": "healthy",
        "version": "9.0.0",
        "uptime": time.time() - _start_time,
    }

@app.get("/status")
async def status():
    """전체 상태."""
    if not _pipeline:
        return {"state": "initializing", "pipeline": None}
    
    m = _pipeline.get_metrics()
    return {
        "state": _pipeline.state.value,
        "uptime_seconds": m.uptime_seconds,
        "loop_hz": m.loop_hz,
        "safety_checks_ps": m.safety_checks_ps,
        "total_experiences": m.total_experiences,
        "successful_actions": m.successful_actions,
        "failed_actions": m.failed_actions,
    }

@app.post("/command")
async def send_command(req: CommandRequest):
    """로봇에 명령 전송."""
    if not _pipeline:
        raise HTTPException(503, "Pipeline not ready")
    
    _pipeline.send_command(req.command)
    return {"command": req.command, "status": "queued"}

@app.get("/metrics")
async def get_metrics():
    """성능 메트릭 (Prometheus 형식)."""
    if not _pipeline:
        return {}
    
    m = _pipeline.get_metrics()
    return {
        "loop_hz": m.loop_hz,
        "inference_ms": m.inference_ms,
        "safety_checks_per_sec": m.safety_checks_ps,
        "uptime_seconds": m.uptime_seconds,
        "memory_mb": m.memory_mb,
    }

@app.get("/state")
async def get_state():
    """현재 로봇 상태."""
    if not _pipeline or not _pipeline._hal:
        return {"mode": "unknown", "position": [0, 0, 0]}
    
    s = _pipeline._hal.get_state()
    return {
        "mode": s.mode.value if hasattr(s.mode, 'value') else str(s.mode),
        "position": s.position_m.tolist() if hasattr(s.position_m, 'tolist') else list(s.position_m),
        "velocity": s.velocity_m_s.tolist() if hasattr(s.velocity_m_s, 'tolist') else list(s.velocity_m_s),
        "battery_percent": s.battery_percent,
        "safety_status": s.safety_status,
        "estop_active": s.estop_active,
    }

@app.post("/safety/estop")
async def emergency_stop():
    """비상 정지."""
    if _pipeline and _pipeline._hal:
        _pipeline._hal.emergency_stop()
        return {"status": "ESTOP activated"}
    return {"status": "no pipeline"}

@app.post("/safety/reset")
async def safety_reset():
    """안전 상태 리셋."""
    if _pipeline:
        _pipeline.state = _pipeline.state.__class__.RUNNING if hasattr(_pipeline.state.__class__, 'RUNNING') else _pipeline.state
    return {"status": "reset"}

@app.post("/scenario")
async def run_scenario(req: ScenarioRequest):
    """시뮬레이션 시나리오 실행."""
    # 시나리오 실행
    return {
        "scenario": req.name,
        "duration": req.duration,
        "status": "started",
    }

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """실시간 상태 WebSocket."""
    await websocket.accept()
    
    try:
        while True:
            if _pipeline and _pipeline._hal:
                s = _pipeline._hal.get_state()
                await websocket.send_json({
                    "timestamp": time.time(),
                    "position": s.position_m.tolist() if hasattr(s.position_m, 'tolist') else list(s.position_m),
                    "battery": s.battery_percent,
                    "safety": s.safety_status,
                })
            else:
                await websocket.send_json({"status": "initializing"})
            
            await asyncio.sleep(0.1)  # 10Hz
            
    except Exception as e:
        logger.warning(f"WebSocket error: {e}")
    finally:
        await websocket.close()

# === 메인 ===

if __name__ == "__main__":
    import uvicorn
    
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(name)s %(levelname)s — %(message)s",
    )
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info",
    )
