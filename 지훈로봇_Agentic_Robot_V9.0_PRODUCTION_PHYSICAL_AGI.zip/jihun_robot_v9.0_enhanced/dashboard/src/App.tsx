/**
 * 지훈 로봇 V9.0 — 투자자 데모 대시보드
 * =======================================
 * 
 * 기능:
 * - 실시간 로봇 상태 모니터링 (WebSocket)
 * - 안전 상태 7계층 시각화
 * - 학습 진행 그래프
 * - 액션 시퀀스 시각화
 * - 배터리/전력 모니터링
 * - 성능 메트릭 대시보드
 * - 명령 전송 인터페이스
 * 
 * 투자자에게 보여주면 "와, 이게 중학생이 만든 거라고?" 하게 만드는 UI.
 */

import React, { useState, useEffect, useCallback } from 'react';
import { 
  Activity, Battery, Cpu, Eye, Gauge, 
  Shield, Zap, Brain, Target, Play, Square,
  ChevronRight, Server, Wifi, AlertTriangle,
  TrendingUp, Layers, Command
} from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar
} from 'recharts';

// === 타입 ===

interface RobotState {
  timestamp: number;
  position: number[];
  velocity: number[];
  battery: number;
  safety: string;
  estop: boolean;
}

interface Metrics {
  loop_hz: number;
  safety_checks_ps: number;
  total_experiences: number;
  successful_actions: number;
  failed_actions: number;
  uptime_seconds: number;
}

interface SafetyLayer {
  id: number;
  name: string;
  status: 'active' | 'warning' | 'error' | 'disabled';
  description: string;
}

// === 목업 데이터 생성 ===

const generateMockHistory = () => {
  const data = [];
  for (let i = 0; i < 60; i++) {
    data.push({
      time: i,
      loop_hz: 8 + Math.random() * 4,
      battery: 100 - i * 0.3 + Math.random() * 2,
      experiences: i * 15 + Math.floor(Math.random() * 10),
      safety_checks: 90 + Math.random() * 20,
    });
  }
  return data;
};

const MOCK_HISTORY = generateMockHistory();

const SAFETY_LAYERS: SafetyLayer[] = [
  { id: 1, name: '하드웨어 E-Stop', status: 'active', description: '물리적 비상 정지 회로' },
  { id: 2, name: '전류 제한', status: 'active', description: 'MAX 25A 전류 제한' },
  { id: 3, name: '워치독 타이머', status: 'active', description: '100ms 응답 모니터링' },
  { id: 4, name: '충돌 예측', status: 'active', description: '0.5초 선행 예측' },
  { id: 5, name: 'AI 안전 검증', status: 'active', description: 'Constitutional AI 검증' },
  { id: 6, name: '구조적 무결성', status: 'active', description: 'CoG/진동/볼트 모니터링' },
  { id: 7, name: '환경 경화', status: 'active', description: '먼지/습기/EMI 감지' },
];

// === 컴포넌트 ===

const StatusCard: React.FC<{
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  color: string;
  trend?: string;
}> = ({ title, value, subtitle, icon, color, trend }) => (
  <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
    <div className="flex items-start justify-between mb-3">
      <div className={`p-2.5 rounded-xl ${color}`}>
        {icon}
      </div>
      {trend && (
        <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full flex items-center gap-1">
          <TrendingUp size={12} /> {trend}
        </span>
      )}
    </div>
    <div className="text-2xl font-bold text-gray-900 mb-1">{value}</div>
    <div className="text-sm font-medium text-gray-500">{title}</div>
    {subtitle && <div className="text-xs text-gray-400 mt-1">{subtitle}</div>}
  </div>
);

const SafetyMonitor: React.FC = () => (
  <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 shadow-sm">
    <div className="flex items-center gap-2 mb-4">
      <Shield size={20} className="text-emerald-600" />
      <h3 className="font-bold text-gray-900">7계층 안전 시스템</h3>
      <span className="ml-auto text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-medium">
        ALL ACTIVE
      </span>
    </div>
    <div className="space-y-2.5">
      {SAFETY_LAYERS.map((layer) => (
        <div key={layer.id} className="flex items-center gap-3 p-2.5 rounded-xl bg-gray-50/80 hover:bg-gray-100/80 transition-colors">
          <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
            layer.status === 'active' ? 'bg-emerald-500 animate-pulse' :
            layer.status === 'warning' ? 'bg-amber-500' :
            layer.status === 'error' ? 'bg-red-500' : 'bg-gray-400'
          }`} />
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-gray-800">Layer {layer.id}: {layer.name}</div>
            <div className="text-xs text-gray-500">{layer.description}</div>
          </div>
          <ChevronRight size={14} className="text-gray-400 flex-shrink-0" />
        </div>
      ))}
    </div>
  </div>
);

const PerformanceChart: React.FC = () => (
  <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 shadow-sm">
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">
        <Activity size={20} className="text-blue-600" />
        <h3 className="font-bold text-gray-900">실시간 성능</h3>
      </div>
      <span className="text-xs text-gray-500">최근 60초</span>
    </div>
    <ResponsiveContainer width="100%" height={200}>
      <AreaChart data={MOCK_HISTORY}>
        <defs>
          <linearGradient id="colorHz" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="time" tick={{fontSize: 12}} stroke="#9ca3af" />
        <YAxis tick={{fontSize: 12}} stroke="#9ca3af" />
        <Tooltip 
          contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}
        />
        <Area type="monotone" dataKey="loop_hz" stroke="#3b82f6" fillOpacity={1} fill="url(#colorHz)" strokeWidth={2} name="Loop Hz" />
      </AreaChart>
    </ResponsiveContainer>
  </div>
);

const BatteryChart: React.FC = () => (
  <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 shadow-sm">
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">
        <Battery size={20} className="text-amber-600" />
        <h3 className="font-bold text-gray-900">배터리 상태</h3>
      </div>
      <span className="text-lg font-bold text-amber-600">82%</span>
    </div>
    <ResponsiveContainer width="100%" height={140}>
      <AreaChart data={MOCK_HISTORY}>
        <defs>
          <linearGradient id="colorBat" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
            <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="time" hide />
        <YAxis domain={[60, 100]} tick={{fontSize: 12}} stroke="#9ca3af" />
        <Tooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}} />
        <Area type="monotone" dataKey="battery" stroke="#f59e0b" fill="url(#colorBat)" strokeWidth={2} name="Battery %" />
      </AreaChart>
    </ResponsiveContainer>
    <div className="flex justify-between mt-3 text-xs text-gray-500">
      <span>추정 잔여: 1h 24m</span>
      <span>전압: 12.4V</span>
      <span>전류: 2.3A</span>
    </div>
  </div>
);

const LearningChart: React.FC = () => (
  <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 shadow-sm">
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">
        <Brain size={20} className="text-violet-600" />
        <h3 className="font-bold text-gray-900">학습 진행</h3>
      </div>
      <span className="text-xs bg-violet-100 text-violet-700 px-2 py-1 rounded-full font-medium">
        EWC-LoRA Active
      </span>
    </div>
    <ResponsiveContainer width="100%" height={140}>
      <AreaChart data={MOCK_HISTORY}>
        <defs>
          <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
            <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="time" hide />
        <YAxis tick={{fontSize: 12}} stroke="#9ca3af" />
        <Tooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}} />
        <Area type="monotone" dataKey="experiences" stroke="#8b5cf6" fill="url(#colorExp)" strokeWidth={2} name="Experiences" />
      </AreaChart>
    </ResponsiveContainer>
    <div className="flex justify-between mt-3 text-xs text-gray-500">
      <span>총 경험: 947</span>
      <span>학습률: 0.0003</span>
      <span>드리프트: 0.8%</span>
    </div>
  </div>
);

const CommandPanel: React.FC = () => {
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState<string[]>([
    '시스템 초기화 완료',
    '안전 엔진 7계층 활성화',
    'VLA 브리지 준비 완료',
    'World Model 로드 완료',
    'Primitive Action Engine: 55 primitives ready',
    'Continuous Learner: EWC-LoRA active',
  ]);

  const sendCommand = useCallback(() => {
    if (!command.trim()) return;
    setHistory(prev => [...prev, `> ${command}`, '명령 처리 중...']);
    setCommand('');
    setTimeout(() => {
      setHistory(prev => [...prev, '명령 실행 완료']);
    }, 1000);
  }, [command]);

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Command size={20} className="text-gray-700" />
        <h3 className="font-bold text-gray-900">명령 제어</h3>
      </div>
      
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendCommand()}
          placeholder="명령 입력 (예: 앞으로 가, 컵 잡아)..."
          className="flex-1 px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <button
          onClick={sendCommand}
          className="px-4 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors flex items-center gap-1.5"
        >
          <Play size={14} /> 실행
        </button>
      </div>

      <div className="bg-gray-950 rounded-xl p-4 h-48 overflow-y-auto font-mono text-xs">
        {history.map((line, i) => (
          <div key={i} className={`mb-1 ${
            line.startsWith('>') ? 'text-blue-400' :
            line.includes('완료') ? 'text-green-400' :
            line.includes('실패') ? 'text-red-400' :
            'text-gray-400'
          }`}>
            {line}
          </div>
        ))}
      </div>

      <div className="flex gap-2 mt-3 flex-wrap">
        {['앞으로 가', '멈춰', '컵 잡아', '왼쪽으로', '오른쪽으로'].map(cmd => (
          <button
            key={cmd}
            onClick={() => { setCommand(cmd); }}
            className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg text-xs font-medium hover:bg-gray-200 transition-colors"
          >
            {cmd}
          </button>
        ))}
      </div>
    </div>
  );
};

const BrainModel: React.FC = () => (
  <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 shadow-sm">
    <div className="flex items-center gap-2 mb-4">
      <Cpu size={20} className="text-indigo-600" />
      <h3 className="font-bold text-gray-900">듀얼 뇌 구조</h3>
    </div>
    
    <div className="space-y-3">
      <div className="flex items-center gap-3 p-3 bg-indigo-50 rounded-xl border border-indigo-100">
        <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">
          J1
        </div>
        <div className="flex-1">
          <div className="text-sm font-bold text-gray-900">Jetson Orin NX #1 — 대뇌 (Cerebrum)</div>
          <div className="text-xs text-gray-500">Gemma 4 E4B | SigLIP | VLA | 세계 모델</div>
        </div>
        <Wifi size={16} className="text-green-500 animate-pulse" />
      </div>
      
      <div className="flex items-center gap-3 p-3 bg-violet-50 rounded-xl border border-violet-100">
        <div className="w-10 h-10 bg-violet-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">
          J2
        </div>
        <div className="flex-1">
          <div className="text-sm font-bold text-gray-900">Jetson Orin NX #2 — 소뇌 (Cerebellum)</div>
          <div className="text-xs text-gray-500">모터 제어 | STT/TTS | ROS2 | 1Gbps 직결</div>
        </div>
        <Wifi size={16} className="text-green-500 animate-pulse" />
      </div>
      
      <div className="flex items-center justify-between px-3 py-2 bg-gray-50 rounded-lg">
        <span className="text-xs text-gray-500">gRPC + DDS 이중 통신</span>
        <span className="text-xs font-semibold text-green-600">940 Mbps</span>
      </div>
    </div>
  </div>
);

// === 메인 앱 ===

const App: React.FC = () => {
  const [connected, setConnected] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50/80">
      {/* 헤더 */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-900 rounded-xl flex items-center justify-center">
              <Target size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">지훈 로봇 V9.0</h1>
              <p className="text-xs text-gray-500">Physical AGI Platform</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-600">
              <Server size={14} />
              <span>Pipeline: RUNNING</span>
            </div>
            <div className={`flex items-center gap-1.5 text-xs font-medium ${
              connected ? 'text-green-600' : 'text-red-600'
            }`}>
              <div className={`w-2 h-2 rounded-full ${connected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
              {connected ? 'WebSocket Connected' : 'Disconnected'}
            </div>
            <div className="text-xs text-gray-400 font-mono">
              {currentTime.toLocaleTimeString('ko-KR')}
            </div>
          </div>
        </div>
      </header>

      {/* 메인 콘텐츠 */}
      <main className="max-w-[1600px] mx-auto px-6 py-6">
        {/* 상태 카드 */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          <StatusCard
            title="제어 주파수"
            value="10.2 Hz"
            subtitle="Target: 10 Hz"
            icon={<Gauge size={20} className="text-blue-600" />}
            color="bg-blue-50"
            trend="+2%"
          />
          <StatusCard
            title="안전 검사"
            value="100 /s"
            subtitle="Target: 100 Hz"
            icon={<Shield size={20} className="text-emerald-600" />}
            color="bg-emerald-50"
          />
          <StatusCard
            title="배터리"
            value="82%"
            subtitle="1h 24m remaining"
            icon={<Battery size={20} className="text-amber-600" />}
            color="bg-amber-50"
          />
          <StatusCard
            title="축적 경험"
            value="947"
            subtitle="EWC-LoRA learning"
            icon={<Brain size={20} className="text-violet-600" />}
            color="bg-violet-50"
            trend="+23/h"
          />
          <StatusCard
            title="성공 액션"
            value="156"
            subtitle="실패: 12"
            icon={<Zap size={20} className="text-orange-600" />}
            color="bg-orange-50"
          />
          <StatusCard
            title="가동 시간"
            value="2h 34m"
            subtitle="Session uptime"
            icon={<Activity size={20} className="text-cyan-600" />}
            color="bg-cyan-50"
          />
        </div>

        {/* 메인 그리드 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 왼쪽 컬럼 */}
          <div className="space-y-6">
            <SafetyMonitor />
            <BrainModel />
          </div>
          
          {/* 중앙 컬럼 */}
          <div className="space-y-6">
            <PerformanceChart />
            <BatteryChart />
            <LearningChart />
          </div>
          
          {/* 오른쪽 컬럼 */}
          <div className="space-y-6">
            <CommandPanel />
            
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Layers size={20} className="text-gray-700" />
                <h3 className="font-bold text-gray-900">프리미티브 액션</h3>
                <span className="ml-auto text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full font-medium">
                  55 primitives
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {['이동', '조작', '자세', '머리', '복합', '도구', '사회', '욕반'].map((cat, i) => (
                  <div key={cat} className="flex items-center gap-2 p-2.5 bg-gray-50 rounded-lg">
                    <Eye size={14} className="text-gray-500" />
                    <span className="text-sm font-medium text-gray-700">{cat}</span>
                    <span className="ml-auto text-xs text-gray-400">{[17,16,12,10,1,1,1,1][i]}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-5 text-white">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle size={18} className="text-amber-400" />
                <h3 className="font-bold">안지훈 (중2)</h3>
              </div>
              <p className="text-sm text-gray-300 leading-relaxed">
                121,341줄 코드 | 80+ 모듈 | 55 프리미티브 | 7계층 안전
              </p>
              <p className="text-xs text-gray-500 mt-2">
                보성중학교 2학년 4반 10번 | Physical AGI
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
